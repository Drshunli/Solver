# M8A.3B-T4-S2 — real native crossing and destination support failure

2026-10-04. **PARTIAL / MPI_COMMUNICATION_BLOCKER. STOP.** No S3 or active integration.

## Actual execution and bounded conclusion

The frozen revalidated S1 checkpoint was opened and checked: archive SHA/CRC/per-file SHA/live manifest PASS. S1/serial/C2/R2/K1/active implementations remain unchanged. New standalone `tests/fiveEqDPMMigrationS2` instantiates the actual C2 `LazySprayCloud`, published S1 carrier owner and a project-local `S1CarrierBridge` binding adapter. `cloud.evolve()` invokes the unchanged native tracking and processor transfer; no manual remove/add, teleport or test reconstruction is used for transfer. Only the initial source parcel is constructed and added to its source cloud, as fixture initialization.

The initial test omitted the required frozen I1 ExceptionSafeConeInjection mapping and aborted before tracking; retained in attempt1. Mapping was corrected using the existing frozen class, with no I1/source change. The next run injected84882 additional native parcels from the copied fixture and completed successfully; logs/results retained. The bounded single-parcel fixture delays SOI to1s, outside the0.004s test step. This changes only a new test input, not production or model physics.

Controlled valid run: before step, source rank0 has identity(0,0) at x=3.9, localcell3/tetFace20/tetPt1/face=-1; rank1 has none. After native step, rank0 has none and rank1 has the same identity at x=4.088, localcell0/tetFace20/tetPt2/face=-1. Both result files have0failures; each rank reports1constructed/1destroyed/live0 after teardown. Aggregate2constructed=2destroyed. This proves one actual stable-owner crossing. Destination provider records2fresh queries through its rank-local S1 owner. No transferred source-side provider/token is serialized. The binding adapter is a candidate, not a completed migration certificate.

Native transfer source audit: `Cloud::move` tracks real parcels, calls `prepareForParallelTransfer`, removes them into neighbour transfer lists, serializes lists through native UOPstream/PstreamBuffers, receives through UIPstream and `ParticleType::iNew`, calls `correctAfterParallelTransfer`, adds the reconstructed object, and continues tracking. We did not replace these functions or introduce a serializer. Actual sender/receiver boundary semantic snapshots of every authoritative field are still missing, so full C2 migration equality is **not** asserted merely from successful end-step identity.

Observed end-step U/T are preserved, but d and nParticle change during native spray evolution (d1e-3 ->9.2276528805908473e-8 m; nParticle1 ->1.2727006106626177e12). Comparing before/after cloud.evolve therefore cannot isolate codec fidelity from physics. This is not labeled codec field loss; a native boundary audit and reference continuation are still required. No global source/energy closure is inferred from these values.

Negative run: only rank1 cell authorities are generated as valid pure liquid(P2 alphaG=0,mG=0); independently prescribed physical-face authorities remain all-gas. No physical face value substitutes for a processor neighbour. On this transverse one-cell wall fixture, native point contributors are physical-face authorities, so source support is valid while destination own-cell scalar support is absent. The parcel genuinely arrives on rank1, identity(0,0), cell0, generation1. S1 preflight rejects `EXACT_GAS_ABSENT` before dependent property/recovery access. Destination rho/T/Y/Cp/mu/kappa/recovery counters are all0.

The exception is caught **outside** native cloud.evolve on rank1 and recorded. The MPI run does not complete and reaches the25s timeout(exit124); rank0 never writes its final result. Timeout cleanup leaves no testNativeCrossing process in the post-timeout audit. This establishes a communication/failure-termination blocker for the current external rank-local catch strategy. The exact blocked collective stack was not captured; we do not claim a pinpointed MPI call or certify stable negative ownership/lifetime. It is not an observed duplicate/loss/codec failure. We do not bypass invalid support, return fake gas or accept the failed step.

## Required39-item report

| # | Item | Result |
|---|---|---|
| 1 | S2 | PARTIAL / MPI_COMMUNICATION_BLOCKER |
| 2 | Native crossing | One bounded valid crossing completed |
| 3 | Transfer path | Actual C2 cloud.evolve ->native tracking/Cloud::move ->native streams/iNew/correction |
| 4 | Before owner | rank0=1, rank1=0 for(0,0) |
| 5 | After owner | rank0=0, rank1=1 for(0,0) |
| 6 | Exactly-one stable owner | PASS for valid single-parcel step only |
| 7 | Duplicate/loss | None observed for valid step; negative/stress not certified |
| 8 | Lifetime | Valid aggregate2ctor=2dtor/live0; perrank1/1/0 |
| 9 | origProc/origId | (0,0) preserved in valid/negative destination observations |
| 10 | All migrated fields | NOT CLOSED; selected end-step fields logged, physical d/nParticle changes cannot prove codec fidelity |
| 11 | Stream semantics | Native path used/audited; complete handoff field equality NOT CERTIFIED |
| 12 | Destination pose | Native destinationcell0/tetFace20/tetPt2 vs sourcecell3/tetPt1 recorded |
| 13 | Support invalidation | Destination has independent rank-local provider/session; full handoff token audit remains open |
| 14 | Destination rebuild | Actual S1 current-rank preflight/materialize exercised in valid run |
| 15 | Coupled destination query | S1 backend exercised; actual migrated-pose contributor dump not yet complete |
| 16 | Invalid destination | Actual migrated rank1cell0 EXACT_GAS_ABSENT detected before thermo |
| 17 | Counters | rho/T/Y/Cp/mu/kappa/recovery all0 on invalid destination |
| 18 | RNG | Not audited; no serial RNG certificate promoted to MPI |
| 19 | Stochastic spot | Native stochasticDispersionRAS selected/evolved; dedicated state/native-reference spot not certified |
| 20 | Drag spot | Native sphereDrag selected/evolved; nonzero source spot not certified |
| 21 | KH boundary case | Not certified; stopped before dedicated child test |
| 22 | Injection boundary case | Actual84882birth run retained; near-processor injection case not certified |
| 23 | Rebound then crossing | Not exercised/certified |
| 24 | VoidFraction | Native function selected/evolved; segment accounting spot not certified |
| 25 | >=10crossings | Not performed |
| 26 | >=1000crossings | Not performed; STOP at communication blocker |
| 27 | Registry | Long-cycle growth not certified |
| 28 | Communication | Valid run completes; invalid destination/external catch fails termination, timeout124 |
| 29 | S1 regression | Frozen checkpoint/live dependencies unchanged; no fresh S1 suite after STOP |
| 30 | Serial regression | Hash-protected frozen support/I1/C2 evidence retained; no fresh serial suite after STOP |
| 31 | Hashes | Fresh6717Foundation/19nativeparcel and 2730protected project/evidence files unchanged |
| 32 | Active solver | NONE |
| 33 | Production mesh/BC | NONE |
| 34 | S2 COMPLETE? | NO |
| 35 | S3 permitted? | NO; S2 not complete |
| 36 | T4 | PARTIAL |
| 37 | M8A | PARTIAL |
| 38 | M6B/CFD | NO; production restart NOT CERTIFIED |
| 39 | Matrix | Serial/S1 remain COMPLETE/FROZEN; S2 PARTIAL; S3 not started |

## Next permitted work

Repair the isolated **S2 local support-failure disposition/communication boundary**, preserving support rejection and native transfer semantics. Returning from an external rank-local catch cannot serve as termination policy for an in-flight native transfer loop. A future design must finish or explicitly terminate compatible native communication phases without evaluating invalid thermo or accepting failed continuation, then expose failure coherently. This is not permission to implement S3 global prepare/commit/discard. Resume handoff field audit, RNG, model continuation/birth/segment checks and crossing stress only after the S2 failure boundary is resolved.

Added only isolated S2 main/Make files, carrier binding adapter, copied fixtures, logs/audits and status docs. No Foundation/C2/S1/serial/P2/EOS/source-adapter/active/production edits. No new serializer, no global transaction certificate, no CFD. **STOP per requested MPI_COMMUNICATION_BLOCKER condition.**
