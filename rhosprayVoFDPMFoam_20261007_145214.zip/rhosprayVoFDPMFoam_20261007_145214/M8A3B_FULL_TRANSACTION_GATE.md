# M8A.3B — 支撑可行性与完整事务门槛报告

日期：2026-10-01。证据目录：`fitting/dpm/m8a3b_v1`。
所有测试为被动 harness 或冻结离线回归；没有运行 CFD。

## 1. M8A.3B status

**PARTIAL / INTENDED_TOPOLOGY_INPUT_REQUIRED**。
实际网格诊断扫描通过，但预定初始液柱拓扑及边界 P2 状态缺失，
不能判定生产严格支撑可行性。没有把诊断图的不合法注入点冒充实际
DPM_CARRIER_INTERPOLATION_BLOCKER，也没有把数值扫描通过冒充全部门槛通过。

## 2. Selected transaction architecture

选择 **A：dual-cloud logical role swap**，设计已固定；尚未实现。
详见 `docs/M8A3B_ROLE_SWAP_DESIGN.md`。禁止成员 copy-back 混合方案。
实际 active 为固定栈对象 parcels，evolve/Srho/SYi/SU/Sh 等直接使用它；
未来激活需要角色访问器。内部模型引用使用冻结 3A 重建绑定；外部长期引用
不得跨角色发布。载气视图、SLGThermo、registry 名和输出名仍需实现及验证。

## 3. Cloud/Q atomic commit

未实现，未声称通过。设计要求将 Q/P2、cloud、缓存代际、待发布输出和
并行事务状态作为一个拥有明确寿命的 aggregate，在一个逻辑点发布。

## 4. Source accumulator transaction

冻结 3A 的 trial source 独立性回归通过。完整 cloud/Q 事务的源项发布一次性、
失败回滚和不重复累加尚未实现；冻结 source/energy 公式未修改。

## 5. Support-probe scalability fix

新增 serial fixed-mesh `NativeSparsePointSupport`，动态 vector/map/set，
无 256 实体上限。将点足迹不重叠的候选实体染色，逐轴调用本机 OF7
volPointInterpolation，获取原生张量系数；actual mesh 为 8 色。
非零判断逐分量 `!=0`，不平方权重。不重新实现距离权重、不归一化。
empty patch 的字段实际长度为零，其原生贡献为零；仍计入候选总数。
对非 empty 存储不匹配、coupled 和 MPI 当前明确拒绝，不静默遗漏。

稀疏点场、所有单元中心 cellPoint 查询和分布于各边界的独立单实体基底
共 **1,725,880 比较，0 失败**，最大绝对差 **3.84593e-16**。
这是所测 serial 网格的原生数值一致性证据，不是任意网格的数学证明。
旧 bounded probe 保留于冻结历史代码；新实现未接管生产调用。
因此“生产 probe 上限移除”尚未全部完成。

## 6. Full 300_2D mesh support scan

实际网格：**21000 cells、42622 points、63620 candidate entities**。
扫描全部实体及单元；候选包含 42620 个 boundary faces。
原算例中文快捷方式使 OF7 目录读取失败，使用只复制 0/constant/system
的独立 fixture；所有复制输入与原文件哈希一致，原算例未修改。

whole-cell stencil 为该单元所有点贡献的并集，另含标量强制 own-cell 读取；
它是全单元覆盖包络，不能视为某条轨迹的实际位置 stencil。
贡献数直方图：**4 cells 为 8，20996 cells 为 9**。

| 诊断图 | gas-present cells | own-cell 存在性合法 | whole-cell U 存在性合法 | 排除的气相单元 |
|---|---:|---:|---:|---:|
| sharp |12000|12000|11900|100|
| 1-cell trace |12100|12100|12000|100|
| 2-cell trace |12200|12200|12100|100|
| 3-cell trace |12300|12300|12200|100|
| legacy all-gas |21000|21000|21000|0|

诊断 plane x=0.015m，gas 在右侧；trace 采用实际前 1/2/3 排非均匀网格，
P2 gas minority=1e-20。使用冻结 EOS/reconstruction/recovery 的 p=3MPa、
TG=800K、TL=300K 合法测试状态，mG 来自 EOS，未用 nominal rho 构造。
这些测试状态并非用户工况或预定液柱。

排除带指标为“合法气相但 whole-cell 支撑不合法单元中心，到 trace 边界
的最大距离”：各 mixed 图 **25μm**。这里只是中心距离；该处一排 dx=50μm，
不能把 25μm 称为完整物理排除带厚度。

| Patch |候选 boundary faces|非零点贡献引用数|
|---|---:|---:|
| inlet |100|400|
| outlet |100|400|
| bottomWall |210|840|
| top |210|840|
| frontAndBack/empty |42000|0|

`support_topologies.csv` 的 invalidBoundaryReferences/invalidCellReferences
是所有扫描单元内重复出现的无气相引用次数，不是唯一实体数，也不只统计气相侧。
sharp 为 836/80162；trace1 为 830/79268；trace2 为 824/78374；
trace3 为 818/77480。原因均为诊断拓扑中气相严格缺失；其他生产原因未验证。

实际 sprayCloudProperties 的 rho,p,T,Cp,mu,kappa 为 cell，U 为 cellPoint。
上述 own-cell 计数可用于六类标量支撑几何的共同存在性筛查。
但是 Cp/mu/kappa/Y 的完整载气字段、边界值合法性和 scalar thermo queries
未逐项执行；**fully DPM-valid cells 数量尚未认证**。
CSV 明确使用 presence-only 名称；不得把该表升级为完整属性门槛 PASS。

## 7. Strict-support feasibility

**UNKNOWN / BLOCKED BY INPUT**。300_2D/0 无 alphaL/P2 初始液柱场；
setFieldsDict 只有 legacy 气相区设定。缺少液柱位置、长度/形状及 DPM
相对液柱位置与预期喷滴运动区域。已向用户请求这些输入。

实际旧 DPM 点 (0.015,5e-6,0.015) 位于 cell 1514，位置 stencil 为 6 实体。
sharp 诊断图含无气相实体 1514、1544、21289，因此该图不允许此注入；
三个 trace 图及 all-gas 图仅存在性通过。不得人为增加 trace gas 来解决。
该结果不能推断缺失的 intended topology YES 或 NO。

## 8. Local support query design

新增 geometry cache 的 query 仅访问 containing-cell 与当前 tet 三个顶点的
局部稀疏表，不逐 parcel 扫描全网格。production runtime hook、Q/P2
代际失效、trial/committed cache 隔离未接入。MPI/coupled 查询未实现。

## 9. Injection hook result

actual position stencil 诊断完成；真实注入前 support→carrier query hook 未实现。

## 10. Tracking hook result

未实现。不可用单元中心或 whole-cell 包络代替真实 crossing 后当前位置查询。

## 11. Deposition hook result

未实现。冻结 source adapter 不变；完整原生 transfer→QTrial→recovery 待接入。

## 12. Breakup child retry

未执行完整事务强制 child/retry。3A ordinary atomization/breakup 回归通过。

## 13. ReitzKHRT transaction

未执行强制 parent/child mutation 的完整拒绝重试，不能以 ordinary calls 替代。

## 14. ORourke collision transaction

未执行强制碰撞 mutation/retry；模型未关闭。

## 15. Merge/delete transaction

未执行 native 支持分支的 count-changing event 门槛。

## 16. Rebound transaction

冻结 3A actual rebound 一致性回归通过；完整 cloud/Q 拒绝重试未执行。

## 17. Stochastic retry

冻结 3A 每 seed 10 次真实 normal renewal/future equivalence 通过；
完整事务拒绝后重试的随机序列门槛未执行。

## 18. Ongoing injection retry

冻结 3A 非零 evolved history 及后续注入一致性通过；large-reject/small-retry 未执行。

## 19. Parcel deletion retry

未执行 minimum-mass 及碰撞/破碎 count reduction 的完整重试。

## 20. Combined-event retry

未执行完整 combined-event 拒绝重试。

## 21. Support-failure retry

未执行实际 parcel crossing 后拒绝重试。诊断 sharp 的无气相实体不是该测试。

## 22. Source-thermo-failure retry

未执行非零原生源项使 QTrial recovery 失败后的原子回滚。

## 23. Native-vs-transaction accepted regression

冻结 3A 原生与重建 trial 的 10 accepted future steps 回归通过。
尚无 role-swap + Eulerian Q 发布，不能称完整 accepted transaction 通过。

## 24. Direct-small-step equivalence

完整 whole-S large-reject/small-accept 对 direct-small 的比较未执行。

## 25. Accepted output commit

未实现 accepted output 一次发布。

## 26. Rejected output behavior

冻结 3A trial 无永久输出回归通过；完整拒绝事务输出门槛未执行。

## 27. VoidFraction result

未改变 native semantics：preEvolve 清零、postMove 累加 dt*nParticle*volume、
postEvolve 除以全步 dt*cellVolume。未改成 final occupancy。
完整 accepted trajectory integral 发布/重试对照尚未实现。

## 28. Repeated lifecycle result

重跑冻结 A/B/C 各 1000 begin/minimal-evolve/destroy，共 3000 次，
各 2125 检查，合计 **6375，0 失败**。这不是完整 cloud/Q repeated commit。

## 29. Registry/reference result

冻结 3A registry、owner/properties/RNG、source 地址独立性与 committed sentinel
检查通过。选定 role-swap 的外部 stale references 尚未实现验证。

## 30. MPI real crossing

未执行；没有把 serial 扫描升级为 MPI PASS。

## 31. MPI global commit/discard

未实现 collective full-state decision/publication。

## 32. Communication drain

未实现或测试 trial sends/receives/source drain。

## 33. MPI reject-after-crossing

未执行 receiver trial 收到真实 parcel 后的 global reject。

## 34. MPI retry equivalence

未执行 distributed whole-S golden。

## 35. Global conservation

冻结 source/energy conservation 回归通过；processor crossing + native source
同时发生的 MPI 全局守恒尚未验证。

## 36. Particle identity

冻结 3A allocator restoration 和 accepted parcel identity 一致性通过；
跨 rank origProc/origId uniqueness/restoration 尚未验证。

## 37. Frozen M8A regression

**9288 检查，0 失败**。八组 zero/heat/momentum/mass/evaporation/combined/
disappearance/permuted 的 32 个 golden_energy/ledger/results/failures 文件
与 m8a_v1 字节完全一致。公式、alpha-source policy 未修改。

## 38. Frozen M8A.3A regression

**6375 检查，0 失败**，A/B/C seedSteps=5/7/9，futureSteps=10，
每 seed lifecycle=1000、randomRenewals=10。冻结 P2/recovery/R1
**105775 reported checks，0 失败**，另每格式 sub-ULP 1000 步；
temporal/restart **9663，0 失败**。全部写入新证据目录，旧证据不覆盖。

## 39. Performance/memory cost

扫描+原生验证+CSV 约 0.458s；整个进程 wall 0.71s，最大 RSS 161020KiB。
该值包含加载的 OF7 库、mesh、basis/验证和诊断输出，不是纯 cache 成本。
3A lifecycle A/B/C 约 54.76/53.39/56.96s；warm 后峰值增长
分别 3/42/4 pages（4KiB/page），通过冻结 5MiB obvious-growth 门槛。
不是严格 leak proof；完整事务/MPI 性能未测。

## 40. Project-local overrides

仅新增 tests/fiveEqDPMSupportScan 下两个 headers、main 和 Make，
tools/m8a3b_* 准备/汇总脚本、新证据/报告/设计。
复用冻结 3A executable/adapters，不改旧语义或本机 FOAM_SRC。
两次初始扫描失败日志保留：中文快捷方式读取、empty 字段越界；
后者已修复并通过独立原生比较。最终 wmake 成功；日志含 clock-skew warning，
实际重新编译和运行验证均完成。没有编译 active solver。

## 41. Active solver impact

**NONE**。预先 SHA-256 manifest 比较：覆盖的现有文件无改动（排除
构建目录、lnInclude 和 Make），之后仅允许
MILESTONE_STATUS.md 追加本轮记录。原算例必要输入与 fixture 哈希一致。
cloud/evolve/source matrices、rho/alpha/time loop、P2/R1/thermo 未修改。

## 42. Remaining blockers

首先需要 intended liquid/P2 topology、对应 boundary states、旧 DPM 点是否
仍为独立喷滴入口及预期 spray region。补齐后才可完成逐属性支撑/可行性判定。
若真实拓扑为 NO，按用户要求停止并另立 mixed-topology carrier 设计。
不得用诊断 trace buffer、权重 masking 或 gas creation 绕过。
完整事务、强制事件重试、输出发布和 MPI 全部仍待实现，不能转成已通过。

## 43. Whether M8A.3B COMPLETE

**NO**。完整门槛不满足。

## 44. Whether M8A COMPLETE

**NO / PARTIAL**。TRIAL-INDEPENDENT 不等于 FULL TRANSACTION-SAFE。

## 45. M6B.0 start permission

**BLOCKED**。未执行 M6B.0。

## 46. M6B.1 permission

**NO**。没有激活 two-phase KT 或 active solver。

## 47. Updated milestone matrix

| Milestone | Status |
|---|---|
| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE |
| M8A source/energy | PASS / FROZEN |
| M8A.1 | PARTIAL / historical |
| M8A.2 | PARTIAL / historical |
| M8A.3 historical copy gate | PARTIAL / preserved evidence |
| M8A.3A | COMPLETE / selected serial evolved scope |
| M8A.3B | PARTIAL / intended topology input required |
| M8A overall | PARTIAL |
| M6B.0 | BLOCKED |
| M6B.1 | NO |

STOP。本轮不执行 M6B、CFD 或支撑绕过。
