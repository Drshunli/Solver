# M8A.3B-T4-S2-KH-FPE2-NATIVE

2026-10-04 — COMPLETE / DIAGNOSIS ONLY — CLASS E

## 1. FPE2 status

**COMPLETE / DIAGNOSIS ONLY**。归类 CLASS E / NATIVE_REITZKHRT_REACHABLE_LIMITATION。此结论仅为诊断完成，不代表模型修复或S2通过。

## 2. Exact reproduction

复用原reverse的69个输入文件，逐文件SHA一致；原Release程序参数保持 -reverse -steps1 -dt0.004 -gasUx-47。再次rank1 signal8，mpirun exit136。原exe SHA `9b657ceec703051276d829bf7ebe0efb95d7b9631db0c1815b2444216d898dab`。同源独立debug也重现相同表达式；原程序实际映射的122个.so均保存SHA，无.so读取错误。gdb在SIGFPE停止读取后退出，不将异常转为正常运行或reject。

## 3. Failing rank

**rank1**。发生在source rank自身第一次tracking/model更新；不是已经到达destination的parcel。

## 4. Failing parcel

**origProc=1 / origId=0**。position=(4.0435999999999996,0.5,0.5)m；cell0、tetFace20、tetPt1、face-1；stepFraction=0.29999999999999999；generation1。tracking前initial=(4.0999999999999996,0.5,0.5)，processor平面x4尚未到达。

## 5. Parent/child/rebound classification

初始seed/accepted-baseline的原有parent，trial复制保留pair(1,0)。本次第一次KH调用前没有native child出生、没有descendant、没有processor transfer、没有wall rebound。Reverse是冻结初始方向参数，不是反弹生成的路径。before stable trial全球1parcel，两个rank的before日志只有rank1一行，无重复fullpair；baseline与disposabletrial是不同事务scope，不把baseline副本误作重复trial owner。

## 6. Exact source line

本机 Foundation7 `src/lagrangian/spray/submodels/BreakupModel/ReitzKHRT/ReitzKHRT.C:254`。lnInclude符号链接对应同一文件；字节SHA见native_model_source.sha256。gdb符号化backtrace、指令和局部变量均定位同一行。

## 7. Exact arithmetic expression

`nParticle = mass/massDrop;`。直接operand：mass=3.7972413229794661e-7kg，massDrop=0kg。x86 `divsd`；MXCSR=0x1924含ZE，SIGFPE si_code=3 (FPE_FLTDIV)。不是历史line161的overflow。

## 8. Operand table

全精度native输入及6个模型参数、owner averageParcelMass共34标量分量，finite/sign/zero全部见本轮NATIVE_OPERANDS.md；完整parcel/td/materializedCarrier及分支中间量见JSON。下面列关键数据，未列不代表忽略。Reitz本体不直接读取T/Cp/Y/RNG；muc、y/yDot属于signature输入，当前本体未读；T等记录为caller context。

| 关键量 | 原生pre-call/失败捕获值 |
|---|---|
| dt (segment) | 0.0011999999999999999 s |
| d / nParticle | 0.0009999999999999998 m / 1 |
| rhoL / muL / sigma | 725.21967199798883 / 0.00084834571996310901 / 0.023208780744580066 |
| U / Urel / Urmag | (-47,0,0) / (0,0,0) / 0 |
| rhoc argument / muc | 1.9592230801339412 / 2.3440715507331707e-5 |
| tMom | 1.7188034113149944 s |
| tc / ms / KHindex / y / yDot | 0 / 0 / 0 / 0 / 0 |
| B0 / B1 / Ctau / CRT / msLimit / WeberLimit | 0.61 / 15 / 1 / 0.1 / 0.2 / 6 |
| averageParcelMass | 2.4800000094247781e-11 kg |
| failure mass / massDrop | 3.7972413229794661e-7 / 0 kg |

## 9. Finite/domain audit

进入update时 d>0、nParticle>0、rho>0、mu>0、sigma>0、tMom>0、mag(U)=47>0、dt>0，全部实际输入有限。零slip/Weber/Re非负；sqrt/pow均合法，trajectory及acceleration分母非零。lambdaRT=2.8238097729461284e307、tauRT=4.4942328371557898e307均有限，排除旧CRT1e9 overflow机制。明确除零是native分支先使d为0，再得到massDrop0。没有观察到失败前overflow/invalid sqrt/log/pow/underflow作为触发；不能把所有理论域问题一概排除到其他工况。

## 10. Parcel state

Pre-call d=0.0009999999999999998m、d0=0.001m、nParticle=1、rho=725.21967199798883kg/m³、T=300K、Cp=2220.0513054784406J/(kgK)、U=(-47,0,0)、Y=[1]、liquidCore0、UTurb=(0,0,0)、tTurb=0.0011999999999999999s。失败时d已被原生分支改0，KHindex已改1，不能将post-mutation `d=0` 误当成非法pre-call输入。parcel.mass0_为0但当前Reitz的local mass0由nParticle*d0³*rhopi6计算，值3.7972413229794688e-7，未读取parcel.mass0_。

## 11. Breakup history

Pre-call tc=0、ms=0、KHindex=0、y=0、yDot=0；这是第一次nativeKH调用。solveTABEq按现有solveOscillationEq yes运行并返回，y/yDot仍0。native较大液滴分支后ms=0、KHindex=1、d=0；initial diameter变量d0仍为0.001m。没有上一次KH、newborn copy或migration correct污染history。

## 12. Carrier state

最后S1 materialized packet：rho=1.6326859001116176、U=(-47,0,0)、T=400.00000000000006、p=188330.30700000006、Cp=1023.2519011518189、mu=2.3440715507331707e-5、kappa=0.034703071017040246、Y=(0,0.22800000000000001,0.77200000000000002)。Reitz argument rhoc=1.9592230801339412是原生calcBreakup按Taverage计算的rhoAv，不是S1packet rho；其muAv等于TD mu。此区别来自实际native caller源码，不是字段混用猜测。

## 13. Slip/relative velocity

Pre-call Uparcel=Uc=(-47,0,0)，Urel=(0,0,0)，Urmag=0。tMom=1.7188034113149944s；omegaKH=172.03439534513493s^-1、lambdaKH=0.0045099999999999993m、dc=0.0055021999999999988m。RT分支未满足；dc>=d，KHindex<0.5进入line239较大液滴分支。line245 lengthScale=min(lambdaKH,twoPi*Urmag/omegaKH)=0，line246 diameterLargerDrop=cbrt(1.5*d*d*lengthScale)=0，line247写入d=0，line253massDrop=0，line254positive/0。该链来自GDB真实中间量；offline工具仅计算最后商。

## 14. Support/generation

LazyCarrierSession valid_=true、requirements255、generation1；S1ticket valid=true/reasonOK、packet properties255/generation1、ready/sampled均true；last query pose与parcel identity/coordinates完全一致。查询包含9entries/4remote contributor，preflight先于materialize/thermo。不是PROJECT_SUPPORT_ORDERING_BUG。

## 15. Migration boundary comparison

**Failing parcel：NOT APPLICABLE / zero boundary events**。在x>4、stepFraction0.3的第一次KH就失败，四阶段native boundary日志都为空；不能伪造不存在的sender/receiver或称其PASS。成功forward counterpart新一条native事件全部C2语义/geometry/RNG equalityPASS；不是失败parcel的对照packet。无迁移控制再次失败进一步排除本次processor codec为必要原因。

## 16. Rebound relevance

未触壁、未调用rebound；before/after rebound数据不适用。tracking、dispersion、drag前后U均(-47,0,0)，本轮共速状态来自冻结初始parcel/S1gas，而不是rebound产生。不归CLASS F。

## 17. RNG relevance

failure前Random.x_=13070、scalarNormalStored_=false、scalarNormalValue_=0。实际dispersion一次更新tTurb至0.0012s，UTurb仍0，没有实际RNG更新。Reitz在失败line前不读取RNG，仅读取owner averageParcelMass；因此RNG非直接原因。没有开展禁止的RNGnext-resultclosure。

## 18. No-migration native control

**串行 FPE YES，同native line254**。独立控制将GDB入口捕获的参数传给同一OF7 nativeupdate；全部非指针arguments、系数及owner averageParcelMass精确匹配。没有Cloud::move、tracking、手写KH公式或parcel内部state伪造。gdb控制程序exit0只是调试器在捕获SIGFPE后quit的返回码，不能当作被调程序正常物理运行。

## 19. Rank1 direct control

**FEASIBLE / FPE YES，同line254**。两rank初始化原生cloud，只有rank1执行同一 captured arguments 的nativeupdate；没有reverse crossing。arguments/coeffs/averageParcelMass精确匹配；gdb捕获后结束，两rankMPI工作停止，未继续物理过程。

## 20. Forward successful comparison

冻结成功正向输入原样重放，nativeevolve两rankglobalFailures0，pair(0,0)rank0->1迁移PASS。第一KH pre-call d/rho/T/history/dt同类状态；U=(47,0,0)、实际Uc=(46.999999999999986,0,0)，slip=1.4210854715202004e-14m/s（舍入残余），tMom=1.7188034081020949。omegaKH170.45807490533744、lambdaKH0.0047051652605331817、lengthScale5.2382049720206657e-16、diameterLargerDrop9.2276528805908473e-8>0，因此未除零；之后KHindex1，不再进入同一分支。该PASS仅为native调用/迁移证据，不认证这种近零slip破碎的物理准确性。原forward bounded迁移结论不撤销。

## 21. Offline expression result

tools/auditKHFPE2Native.py仅对captured `mass/massDrop` 做Decimal计算：**DivisionByZero**。未实现任何KH波长/频率/动力学公式，未写solver dictionary。离线assertions：9组69输入hash无变化、34scalarcomponents finite、两个directcontrols全部arguments+model+averageMass一致、nativefailureline254、freshforward boundaryPASS。

## 22. Root-cause class A-H

**CLASS E / NATIVE_REITZKHRT_REACHABLE_LIMITATION**。finite且physically/contract-valid的共速液滴；d/rho/sigma/mu/tMom/速度模均为正。Native SprayParcelI.H默认liquidCore0/KHindex0，nativecaller非core直接调用calcBreakup，没有要求Urmag严格正的入口合同；零slip不是新造非法模型系数。函数自身将合法正径改成零并除零。原生同状态无MPI复现，support合法，失败前不存在migration/newborn/rebound。CLASS D需输入违反独立native准入合同的证据，本轮无此证据；不能事后把产生massDrop0作为input-invalid理由。

## 23. Whether root cause established

**YES，在这个精确fixture与原生调用路径范围内**。zero-slip不是事先假设：line239/245/246/247/253/254及实际operands、ZE/si_code、两个nativecontrols组成直接因果证据。对其它KH/RT工况不作外推。

## 24. Whether any source changed

Foundation、sharedC2/S1/N1/ID1/transactionState/sourceadapter均**NONE**。独立diagnostic wmake PASS；新增独立诊断target、readonlyGDB observer、captured-call flag和offline工具；initial debug main与冻结release main字节相同，随后本地control分支diff保存。未改变formula、coefficients、dt/U/carrier/RNG、未addSMALL/clamp/skipKH/换模型/信号恢复/修改原fixture。

## 25. Foundation hashes

fresh **6717/6717 Foundation PASS /19/19 nativeparcel PASS**；Reitz字节不变。debug native template直接包含本机Foundation源码。实际loaded原release122.so SHA、debug/control mappedSHA、两个debugexe SHA均保存，未编译覆盖安装库。

## 26. Project hashes

**18971 protected entries /0变化**（写阶段append前），上轮557-entry checkpoint SHA/CRC/per-fileSHA独立PASS。旧失败fixture、通过证据、checkpoint均不改。结束仅授权追加MILESTONE_STATUS，新的报告/工具/target/输出单独封存。

## 27. Active solver impact

**NONE**。没有active方程/Make/flux/source/alpha/thermo/runtime激活或集成。

## 28. Production mesh/BC impact

**NONE**。exact geometry/decomposition/conditions复制于新隔离目录；未运行CFD或更改production输入。productionrestart **NOTCERTIFIED**。

## 29. FPE2 COMPLETE?

**YES / DIAGNOSIS ONLY**。全部诊断gate有证据；failing migration boundary为已证明“首次transfer之前”的N/A，非未调查或伪造PASS。原有coneMPI、VFsingle、forwardmigration、destinationS1/native snapshots bounded结果仍保持。

## 30. T4-S2 status

**PARTIAL / native KH reachable limitation unresolved policy**。R1仍PARTIAL，remaining S2 gates本轮未执行，不能升级COMPLETE。

## 31. Next permitted action

**Owner policy decision required; NO AUTOMATIC S2 RESUME**。先对CLASS E决定后续模型适用域与处理路线，再单独授权相应工作。当前不修root cause，不改fixture/模型/guard，不恢复stress，不执行S3。

## 32. T4/M8A/M6B/CFD matrix

见下表。FPE2仅关闭诊断，其他阶段状态不提升。

| Milestone | Status |
|---|---|
| R2-FINAL / T3 | COMPLETE / FROZEN |
| T4-S1 / C1-N1 | COMPLETE / FROZEN |
| KH-FPE1 | COMPLETE / DIAGNOSIS ONLY / historical CLASS D |
| ID1-NATIVE / fixture | COMPLETE / FROZEN / isolated identity scope |
| KH-FPE2-NATIVE | COMPLETE / DIAGNOSIS ONLY / CLASS E |
| R1-NATIVE-RESUME / T4-S2 | PARTIAL / PARTIAL |
| T4-S3 | NOT AUTHORIZED |
| T4 / M8A | PARTIAL / PARTIAL |
| M6B / CFD | NO / NO |
| production restart | NOT CERTIFIED |

## Evidence directory

`fitting/dpm/m8a3b_t4_s2_kh_fpe2_native_v1/`: diagnosis_result.json, NATIVE_OPERANDS.md, PARCEL_CONTEXT.json, exact_input_hashes.json, binary_provenance.json, native_ReitzKHRT.C.reference, native_caller_contract.txt, exact_debug_final/failure.rank1.json, calls.rank1.jsonl, log.exact.release, log.exact_debug_final, log.serial_control, log.rank1_direct_control, log.forward_debug_scales, release_gdb/loaded_sha.rank1.json, installed_source_verification.txt, native_parcel_verification.txt, previous_checkpoint_verification.json, protected_preclosing_audit.json.

**STOP after diagnosis. No repair or remaining S2 execution.**
