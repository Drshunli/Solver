#include "fiveEqLiquidThermoEvaluator.H"
namespace fiveEq {
std::array<double,2> fiveEqLiquidThermoEvaluator::pressureInterval(double rho,unsigned* queryCalls) const {
    if(!std::isfinite(rho)||rho<=0)throw RecoveryError("INVALID_LIQUID_RHO");
    double lo=50000,hi=12000000;
    auto density=[&](double p,double T){if(queryCalls)++*queryCalls;return eos_->evaluatePT(p,T).rho;};
    if(rho<density(lo,400)||rho>density(hi,265))throw RecoveryError("NO_LIQUID_PRESSURE_INTERVAL");
    auto crossing=[&](double T,bool lower){
        double a=50000,b=12000000;
        for(unsigned n=0;n<80&&b-a>1e-7;++n){double p=(a+b)/2;
            if(density(p,T)<rho)a=p;else b=p;
        }
        return lower?b:a; // inward admissible endpoints; never clamps query.
    };
    if(rho>density(lo,265))lo=crossing(265,true);
    if(rho<density(hi,400))hi=crossing(400,false);
    if(lo>hi)throw RecoveryError("EMPTY_LIQUID_PRESSURE_INTERVAL");
    return {{lo,hi}};
}
}
