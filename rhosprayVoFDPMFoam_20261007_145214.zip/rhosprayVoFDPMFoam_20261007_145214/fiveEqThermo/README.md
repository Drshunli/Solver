# Standalone five-equation recovery API and numerical policy

No active solver include/link/runtime connection exists. Units are SI; double
precision. Immutable OF7 species and frozen ndecane_gibbs_v1 coefficients are
read only. Local mixtures and temporary states are query owned. recover throws
structured reason strings; tryRecover returns INVALID plus diagnosticFlags.
Absent phase properties remain zero and validity ABSENT; callers must branch
on recoveryMode rather than treating zeros as a phase EOS result.

Input: alphaL,mG,mL,M[3],Et,YG[C10H22,O2,N2]. Derived rhoMix=mG+mL,
U=M/rhoMix, Eint=Et-|M|^2/(2*rhoMix). Negative sensible Eint is not rejected
by sign alone: admissible EOS energy brackets decide physical validity.

## Presence, checked before m/alpha

alphaPresenceTol=64*double epsilon=1.4210854715202004e-14, dimensionless.
massPresenceRelativeTol=64*epsilon times total density; absolute mass tolerance
is zero kg/m3. These are arithmetic inconsistency diagnostics, not transport
floors. Exact alpha=mass=0 is absent. Exact pure states use surviving intrinsic
density=m and never query the other EOS. Nonzero consistent traces are retained
as MIXED, including both-small states; no conservative mass is silently dropped.
Zero alpha with mass, positive alpha with zero mass, or tiny alpha with significant
mass is rejected. EOS domains then determine valid intrinsic densities.

## Liquid and gas pressure domains

Liquid rho-p interval is built from candidate HARD cold/hot density curves,
using monotonic bisection and inward endpoints. No reference backend query,
fuzzy domain or extrapolation. Gas interval uses actual Rmix and JANAF bounds;
floating endpoints are rounded inward only when necessary for valid T.
Mixed bracket intersects both. Negative width rejects. User explicitly approved
exact singleton acceptance: EOS-valid singleton with energy residual passing
is accepted, with EXACT_LEGAL_SINGLETON flag. Otherwise it is NO PHYSICAL ROOT.
This exception is needed at the two extreme HARD corner densities and does
not enlarge HARD coordinates or accept near-singleton states.

## Root and acoustics

R(p)=mG*eG(rhoG,p,Y)+mL*eL_solver(rhoL,p)-Eint;
R'=mG*betaG+mL*betaL, required finite positive. Strict endpoint roots are
accepted within arithmetic energy tolerance; otherwise signs must bracket zero.
Safeguarded Newton uses bisection for outside/nonfinite/overlarge steps and
invalid-domain trial EOS queries; a nonpositive thermodynamic derivative fails.
Maximum100 iterations. Default initial guess midpoint; optional provided pressure
or endpoint energy-secant estimate. No prior pressure is required. The energy
secant incorporates phase-weighted endpoint energies, not a guessed mean pressure.

Pressure test: 1e-4 Pa+2e-11*abs(p); energy residual:
abs(R)/max(abs(Eint),rhoMix*1e5 J/kg)<=2e-12. Pressure increment and energy
must both pass; the implied Newton correction is an increment test when the
residual is small. Fresh final EOS values reconstruct Et and are rechecked.
Arithmetic cancellation at high kinetic energy is covered by 2013.039 m/s
tests; these tolerances are not a discretization or CFD error claim.

Offline external recovery budget: abs dp<0.02 Pa+2e-9*p,
abs dTG<2e-6 K,abs dTL<2e-7 K; derivative FD relative2e-4.
These are stricter than liquid reference-fit inverse budgets; the pressure
allowance covers root tolerance plus conservative energy construction/subtraction
roundoff. Detailed observed maxima are in test_results.json. No EOS fit threshold
or domain was changed.

xi_k=rho_k*beta_k; w_k=m_k/rhoMix;
cMix^2=(wG*xiG*cG^2+wL*xiL*cL^2)/(alphaG*xiG+alphaL*xiL).
Numerator,denominator and cMix must be positive finite. Pure acoustic limits are
returned directly. K=0; no Kapila or flux discretization.

For alpha-pressure diagnostic, at fixed mG,mL,M,Et:
e_rho|p=-beta*dp_drho|e;
R_alpha=mG*eG_rho*rhoG/alphaG-mL*eL_rho*rhoL/alphaL;
dp/dalpha=-R_alpha/R'. This is tested with centered alpha perturbations1e-8.

## Energy references and scope

Liquid solver e=native e+C_L, C_L=369229.9537234281 J/kg, exclusively inside
standalone liquid adapter. Gas JANAF Es unshifted. Artificial liquid offset
changes are validation only, paired with Et+=mL*DeltaC. DPM heat/phase-change
and VOF-to-parcel energy transfer remain blocked pending the separate energy
ledger. They do not block this standalone recovery stage.

## Safety and measurement

No mutable static caches or global thermo field writes; readonly coefficients
and per-query state/counters. Determinism is checked by repeated queries.
Thread/MPI safety is architectural; no distributed MPI test or thread stress
run was performed. Raw warm timing outliers are retained. API-call counters
include gas/phase queries and liquid PT domain-bracket queries; frozen EOS
internal polynomial evaluations are not separate API calls. Pure-phase inner
inversion iterations are reported; no claim of instrumenting frozen private
methods. Standalone benchmarks are not CFD throughput measurements.
