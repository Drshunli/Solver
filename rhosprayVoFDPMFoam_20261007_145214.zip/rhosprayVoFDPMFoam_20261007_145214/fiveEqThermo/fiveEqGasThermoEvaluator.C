#include "fiveEqGasThermoEvaluator.H"
#include "IFstream.H"
#include "dictionary.H"
#include <cmath>
#include <algorithm>
namespace fiveEq {
std::vector<GasThermo> fiveEqGasThermoEvaluator::load(const std::string& path) {
    Foam::IFstream stream(path); Foam::dictionary d(stream);
    return {GasThermo(d.subDict("C10H22")),GasThermo(d.subDict("O2")),GasThermo(d.subDict("N2"))};
}
GasThermo fiveEqGasThermoEvaluator::mixture(const std::vector<double>& Y) const {
    if(Y.size()!=species_.size()) throw RecoveryError("INVALID_GAS_COMPOSITION_SIZE");
    double sum=0; for(double y:Y){if(!std::isfinite(y)||y<0)throw RecoveryError("INVALID_GAS_COMPOSITION");sum+=y;}
    if(std::abs(sum-1)>1e-12)throw RecoveryError("INVALID_GAS_COMPOSITION_SUM");
    GasThermo mix=Y[0]*species_[0];
    for(unsigned i=1;i<Y.size();++i) mix+=Y[i]*species_[i];
    return mix; // OF7 local value: never changes global mixture_/thermo fields.
}
GasState fiveEqGasThermoEvaluator::evaluatePT(double p,double T,const std::vector<double>& Y) const {
    const GasThermo mix=mixture(Y);
    if(!std::isfinite(p)||p<=0||!std::isfinite(T)||T<mix.Tlow()||T>mix.Thigh())throw RecoveryError("INVALID_GAS_PT");
    GasState s; s.p=p;s.T=T;s.R=mix.R();s.rho=p/(s.R*T);
    s.Cp=mix.Cp(p,T);s.Cv=mix.Cv(p,T);s.e=mix.HE(p,T);
    s.c=std::sqrt(mix.gamma(p,T)/mix.psi(p,T));s.beta=s.Cv/(s.rho*s.R);
    s.dpDrhoE=p/s.rho; // e(T,Y) independent of density for perfectGas.
    if(!(s.R>0&&s.Cv>0&&s.Cp>0&&s.beta>0&&std::isfinite(s.c)&&std::isfinite(s.e)))throw RecoveryError("INVALID_GAS_THERMO");
    return s;
}
GasState fiveEqGasThermoEvaluator::evaluateRhoP(double rho,double p,const std::vector<double>& Y) const {
    if(!std::isfinite(rho)||rho<=0)throw RecoveryError("INVALID_GAS_RHO");
    const auto mix=mixture(Y); return evaluatePT(p,p/(rho*mix.R()),Y);
}
std::array<double,2> fiveEqGasThermoEvaluator::pressureInterval(double rho,const std::vector<double>& Y) const {
    if(!std::isfinite(rho)||rho<=0)throw RecoveryError("INVALID_GAS_RHO");
    const auto mix=mixture(Y);const double factor=rho*mix.R();
    double lo=factor*mix.Tlow(),hi=factor*mix.Thigh();
    // Round computed interval endpoints inward, never expand temperature validity.
    while(lo/factor<mix.Tlow())lo=std::nextafter(lo,std::numeric_limits<double>::infinity());
    while(hi/factor>mix.Thigh())hi=std::nextafter(hi,0.);
    return {{lo,hi}};
}
GasState fiveEqGasThermoEvaluator::recoverRhoE(double rho,double target,const std::vector<double>& Y) const {
    if(!std::isfinite(rho)||rho<=0||!std::isfinite(target))throw RecoveryError("INVALID_GAS_RHO_E");
    const auto mix=mixture(Y); const double R=mix.R();
    // Split JANAF branches: coefficients may have small discontinuities at Tcommon.
    // Never pretend a discontinuity gap is a physical root.
    const double edges[4]={mix.Tlow(),std::nextafter(mix.Tcommon(),mix.Tlow()),mix.Tcommon(),mix.Thigh()};
    double tol=2e-12*std::max(1e5,std::abs(target));
    for(unsigned branch=0;branch<2;++branch){
        double lo=edges[2*branch],hi=edges[2*branch+1];
        auto at=[&](double T){return evaluatePT(rho*R*T,T,Y);};
        auto sl=at(lo),sh=at(hi);double fl=sl.e-target,fh=sh.e-target;
        if(std::abs(fl)<=tol)return sl;
        if(std::abs(fh)<=tol)return sh;
        if(!(fl<0&&fh>0))continue;
        double T=(lo+hi)/2,delta=hi-lo;
        for(unsigned n=1;n<=100;++n){auto s=at(T);double f=s.e-target;
            if(std::abs(f)<=tol&&std::abs(delta)<=1e-9+2e-11*T){s.iterations=n;return s;}
            if(f<0)lo=T;else hi=T;
            double next=T-f/s.Cv;
            if(next==T&&std::abs(f)<=tol){s.iterations=n;return s;}
            if(!(next>lo&&next<hi))next=(lo+hi)/2;
            delta=next-T;T=next;
        }
        throw RecoveryError("GAS_INVERSION_NOT_CONVERGED");
    }
    throw RecoveryError("NO_GAS_ENERGY_ROOT_IN_JANAF_DOMAIN");
}
}
