# Phase-fraction precision contract — C.1 standalone

## Scope and ownership

P2 is the selected standalone representation. There is exactly one physical
alpha degree of freedom. A signed minority coordinate s owns that quantity:
s>=+0 gives alphaL=s, alphaG=1-s; s<=-0 gives alphaG=-s, alphaL=1+s.
The sign of zero distinguishes pure gas (+0) from pure liquid (-0).
The absolute coordinate is at most 0.5. At half crossing, transform the
coordinate using 1-minority and change the sign. Alpha projections are views.
Do not recreate the coordinate from rounded dominant alpha or transport alphaG
independently. DD hi/lo arithmetic in updates is temporary numerical precision.

## Mathematical equation and coefficient identity

Only the original Allaire K=0 alpha equation is represented: D alphaL/Dt=0.
For unit-area left/right faces, let S_f=Aplus_f+Aminus_f, G=meshPhi_R-meshPhi_L,
Vnew=Vold+dt*G. The old finite-volume form is

Vnew*anew=Vold*aold-dt*(Falpha_R-Falpha_L)
           +dt*aold*((S_R+meshPhi_R)-(S_L+meshPhi_L)).

Rearranging with identical coefficients gives anew=aold+dt*N/Vnew where
N=sumLeft A±*(aface-aold)-sumRight A±*(aface-aold).
Face fractions retain minority information. Structured differences and FMA/DD
postpone cancellation. The PDE and physical source do not change. An
independently rounded phiStar may not overwrite this coefficient identity.
Periodic conservative quantities still use the frozen flux-divergence update.

## Supported finite precision

The runtime prototype uses IEEE binary64 (53-bit significand); no Boost,
Decimal or long double in its closure/update. High precision is diagnostic.
The stored minority itself has finite ULP; sub-ULP in the dominant alpha is not
the same as sub-ULP in the stored coordinate. P2 does not magically preserve
arbitrarily small increments relative to its own coordinate.

Full intrinsic recovery requires normal positive fractions and normal positive
phase masses, finite division, no underflowed positive-phase mass, correct
nonnegative species, legal EOS bounds and a converged energy root. Actual static
witnesses extend to DBL_MIN on both sides; long-time operator certification is
restricted to the documented contacts and 1e-8...1e-20 trace evolution matrix.
There is no universal guarantee for every normal state or cancellation history.
EOS accuracy/error budget is distinct from representation roundoff.

Subnormal present fraction or mass causes PRESENT_PHASE_SUBNORMAL_PRECISION_UNRESOLVED.
Positive fraction with zero mass and zero fraction with positive mass reject.
True absent phase requires both fraction=0 and mass=0. No empirical alpha floor,
mass/energy/species deletion, density overwriting or asymptotic mode is permitted.
Below support, retain diagnostics and stop before committing an invalid update.

## Species ownership

Use N-1 independent species; the last dependent species is the residual
mY_N=mG-sum(first N-1). Negative residual is inadmissible and reduces theta/dt;
never clip or normalize. Evaluate FY_i=KT(mYi) for independent species and
FY_N=FmG-sum(first N-1 fluxes). This is mathematically KT of the residual species.
The frozen per-species conservative update is retained and roundoff closure is
audited separately from each species' conservation. Runtime species mapping
must be preserved; the dependent slot cannot silently change on restart.

## Future M5C.3 / M6B integration requirements (not performed)

The signed coordinate is not a [0,1] volScalarField and must not be passed to
legacy alpha BCs. A future authoritative field and explicit gas/liquid getters
are needed. Recovery must receive that authoritative field. Boundary, parallel
exchange, mesh mapping, reconstruction, startup, binary/text restart, sign-of-zero
serialization and remapping require tests. Preserve enough coordinate digits;
reading only alphaL is irreversibly lossy. MaterialCell ABI cannot silently be
reinterpreted. New precision-aware recovery has a distinct API/type and the frozen
shared library is not replaced. No active solver include or dictionary changed.

## Evidence and limitations

See M5C2C1_PRECISION_CLOSURE_GATE.md and fitting/reconstruction/m5c2c1_v1.
R1/R2 standalone variants use the frozen EOS/root tolerances and no generic FCT.
Connected dt uses 32 samples and 52 bisections: evidence, not interval proof.
R2-HYBRID uses R1-bounded true fraction before its primitive construction;
remaining formal-order/stress selection is open. P3 is not evaluated.
