# Final future five-equation ownership — v2, M5C.2D

Versioned refinement of FIVE_EQ_FIELD_OWNERSHIP_FINAL.md. That historical
document is retained byte-for-byte. This version describes future numerical
ownership; the CURRENT active solver remains legacy gas KT + provisional
MULES alpha and existing DPM. No new runtime conservative fields are active.

| State/view | Authoritative writer/storage | Consumers |
|---|---|---|
| physical alphaL | ONE material alpha equation | model definition |
| phaseFractionCoordinate (P2) | authoritative numerical encoding of physical alphaL | reconstruction, alpha update, recovery |
| decoded alphaL | P2 getter/output view | diagnostics; never sole trace-recovery source |
| decoded alphaG | P2 getter/output view | diagnostics/carrier-volume view; no independent PDE |
| mG,mL | respective conservative phase-mass updates | intrinsic density recovery |
| M,Et | conservative mixture momentum/total-energy updates | U, internal energy and common pressure recovery |
| independent mYi | conservative gas-species transport | canonical gas composition |
| dependent mY_N | residual conservative identity | sum mYi=mG; positivity checked |
| FY_N | residual flux FmG-sum independent FYi | conservative species update |
| p,TG,TL,rhoG,rhoL,cMix | recovery from conservative Q AND P2 | common KT wave speeds and diagnostics |

Physical alphaL remains the authoritative physical variable. P2 is its
authoritative numerical storage near precision-degenerate limits and the
single storage format chosen for the standalone path. There is one physical
DOF, even if a registry later retains conventional decoded output fields.
Neither decoded alpha nor a thermo module may overwrite the P2 coordinate.
Recovery must not compute a lost minority by subtracting decoded dominant
alpha. No mG/mL correction may be used to repair representation or EOS bounds.

All existing dimensions/energy references in the historical contract remain.
See FIVE_EQ_PHASE_FRACTION_NUMERICAL_REPRESENTATION.md for mapping, half ties,
future field/storage/BC/MPI/restart contracts. Their implementation belongs
to later permitted milestones. The active Make, gas equations, alphaEqn,
reconstruction, timestep, cloud mapping and capillary coupling are unchanged.
