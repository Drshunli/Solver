# M8A.3B-T3B-R2C-R1 — remaining full-graph serial transaction closure

## 1. R2C-R1 resumed status

PARTIAL / KH_SPATIAL_INVALID_SUPPORT_UNCLOSED。本轮允许的其余最终门槛已执行；13969 checks / 0 failures。真实 KH 空间无效项按用户确认保持未闭合。

## 2. C2 frozen contract

FROZEN：NATIVE-COMPATIBLE / SEMANTIC-NONCANONICAL；transactionState-v1 是事务权威；raw parcel padding/hash 不作为物理相等权威。C1 历史 PARTIAL 不改，production restart / MPI migration NOT CERTIFIED。

## 3. Runtime support result

PASS：87 checks / 0 failures；ctor=53，dtor=53，live=0。记录首个无效 owner、alphaG/mG、实际当前 tet 的 U-cellPoint 贡献矩阵、requirements=255、错误及六种物性 at/after 计数。固定 native 全 parcel profile：rho,p,T,Cp,mu,kappa,Y,U；不是仅 drag 的最小 profile。Cp 计数包含 native kappa 的内部 Cp。

## 4. Pure-liquid owner crossing

PASS：87 checks / 0 failures；ctor=53，dtor=53，live=0。独立受控 native particle::track 位移后，真实 setCellValues 查询在 owner cell2、alphaG=mG=0 拒绝；不是宣称完整 kinetic move 能越过其更早的 strict-stencil 拒绝。没有假气体、删除、冻结或反射；discard 后 native 小步 motion 与 direct 路径一致。

## 5. Strict-stencil crossing

PASS：87 checks / 0 failures；ctor=53，dtor=53，live=0。完整 native cloud.motion；首个拒绝 owner cell1 仍 gas-valid，alphaG=1，mG=13.003901969784536；实际非零 stencil 含 gas-absent contributor。rho/T/Y/Cp/mu/kappa at=(6,6,6,12,6,6)，after 相同，增量全部0。

## 6. Trace transaction

PASS：150 checks / 0 failures；ctor=53，dtor=53，live=0。alphaG=1e-20，signed P2 hi/lo bit-exact；实际运动、随机/drag、非零源、QTrial、prepare/publish/flush、prepared discard、retry 和10 future steps。intrinsic rhoG 为有效气相恢复值，未通过 1-alphaL 重构 trace。

## 7. Mixed 0.1

PASS：150 checks / 0 failures；ctor=53，dtor=53，live=0。完整事务及 native 小步运动、query、source、accept、reject/retry、10 future。

## 8. Mixed 0.5

PASS：150 checks / 0 failures；ctor=53，dtor=53，live=0。同上。

## 9. Mixed 0.9

PASS：150 checks / 0 failures；ctor=53，dtor=53，live=0。同上。有效支撑只 materialize 已声明的 native All packet；无效点后无依赖物性求值。

## 10. Rebound mixed

PASS：106 checks / 0 failures；ctor=10590，dtor=10590，live=0。实际 native rebound；输出 Theta 对照 trial-owned field；rollback、retry、10 future。

## 11. Rebound invalid

PASS：109 checks / 0 failures；ctor=10166，dtor=10166，live=0。先执行实际 native patch correct 并 invalidateAfterRebound，再 native motion 到无效 stencil；记录真实 wall event，首个无效 query 后不求气相物性；没有复用 pre-wall token。不是仅通过设置反弹速度伪造事件。

## 12. KH invalid-child

PASS：108 checks / 0 failures；ctor=11135，dtor=11135，live=0。USER-AUTHORIZED TEST_ONLY_KH_CHILD_SUPPORT_REJECT。真实 ReitzKHRT 创建子对象，child origId/identity 不同；共享 trackingData session 失效后按 child identity 重新校验。拒绝发生在子对象首个 carrier-dependent preflight，unique_ptr 删除 child，trial 无 orphan。真实空间无效支撑未证明、未关闭。

## 13. KH retry

PASS：106 checks / 0 failures；ctor=11562，dtor=11562，live=0。实际有效子对象接受；fault-large/discard/small-retry 与 direct-small 的父/子字段、IDs、allocator、RNG、source、output、carrier 和10 future 完全一致。

## 14. Injection I1 regression

FRESH PASS：A-H/1000 stress 12083/0；native move(false)18/0；support retry61/0/10future；旧 orphan 对照单独复现并 diagnostic cleanup，guarded 目标正常闭合。

## 15. ORourke no-collision

PASS：105 checks / 0 failures；ctor=10639，dtor=10639，live=0。正式实际无碰撞分支；native reference/direct versus observed local/retry 的完整后续事务相等。

## 16. ORourke grazing

PASS：105 checks / 0 failures；ctor=10639，dtor=10639，live=0。实际 grazing，native equality、reject/retry/10future/lifetime；保留 event ledger 的 KE-change 诊断，不补偿 native KE loss。

## 17. ORourke coalescence

PASS：105 checks / 0 failures；ctor=10639，dtor=10639，live=0。实际 native coalescence，完整事务；不以 C2 IO fixture 证书代替本轮 branch gate。

## 18. ORourke cleanup

PASS：107 checks / 0 failures；ctor=59，dtor=59，live=0。独立20um立方单元网格 V=8e-15 m3；native seed1，nu=5.7008588702644376，xx=.041630344465374947，prob=.45449244463816285；positive residual约5.45513e-16kg，native min-mass cleanup 删除。fixture 使用独立 native Random 副本选择初始 seed；实际 kernel 没有额外 draw、概率或公式修改。保留 native truncation limitation。

## 19. ORourke count reduction

PASS：cleanup 实际 population2->1，检查正剩余、native reference、完整 IDs/allocator/RNG/10future，live 数量与 cloud-owned 数量一致。

## 20. ORourke lifetime

四分支每个接受步、discard 和终态均检查 ctor=dtor+cloud-owned-live；无 unowned live。不宣称 FULL-CONSERVATION-SAFE。

## 21. Minimum-mass deletion

PASS：104 checks / 0 failures；ctor=10550，dtor=10550，live=0。实际 native physical deletion 事件与 failed-trial 对象销毁分开。物理删除保留 native source semantics；discard 不发布该源或输出。

## 22. Combined mixed event

PASS：116 checks / 0 failures；ctor=11660，dtor=11660，live=0。实际注入、nonzero UTurb、sphereDrag 源、KH child、blobs core transition、native wall、movement、lazy query/cache invalidation、output staging；多种副作用后 deliberate reject，数值及所有权恢复。

## 23. Canonical equality

PASS：transactionState-v1 覆盖 Q/P2、parcel 字段/IDs、RNG/cached normal、allocator、model history、源、time/index/generation、pending ticket。discard=pretrial、retry=direct；不比较 raw padding。

## 24. Ownership equality

PASS：最终每组 ctor/dtor/live 和 cloud-owned 计数检查；KH/injection guard 在异常退出前释放对象。外部 hooks，不增加 parcel member，不拦截全局 allocator。

## 25. Future equivalence

六组 runtime、各事件组均含首次接受+10 future steps；direct/retry 的 canonical、carrier snapshot、实际 query strings 一致；ORourke 同时 native reference 一致。

## 26. Output semantics

每个拒绝 zero accepted publication；接受 exactly once，重复发布 ticket 幂等，retry/direct 等价。reference roleC，accepted/trial 专用 roleA/roleB；最终检查 registry lookup Theta == 实际 trial-owned native VF field，避免参考 cloud 影子字段。

## 27. Sequential lifecycle

PASS：11602 checks / 0 failures；ctor=1440062，dtor=1440062，live=0。100 个 native whole-cloud 接受步，每步有实际 lazy query 和非零 source；序列包含实际注入及 KH 首次真实事件，其他正向组合见 combined。

## 28. Alternating lifecycle

100 次 accept/reject 交替；六类 rejection 覆盖 existing support、injection、测试专用 KH child、mixed stencil、output staging、真实 rebound-invalid。

## 29. Discard stress

额外4x250=1000 grouped discard：existing movement、invalid injection、KH test failpoint、mixed-support；不是仅改 U/RNG 后直接 discard。加交替后每组前四类267次，output16次，rebound16次，总1100。真实 KH 空间无效仍未闭合。

## 30. Registry

PASS：最终生命周期每次 discard 回基线，100接受/1100拒绝记录的 registry count 一致。先前 warm roleA 参考与活动 roleA 名称冲突的失败 fixture 保留，最终参考 roleC/单活动图证据独立。

## 31. RNG

PASS：完整48-bit native state/cached normal 在 canonical 内；reject 显式比较 RNG，retry/direct future exact；没有改变 native 抽样算法或额外消费模型 draw。

## 32. Allocator

PASS：accepted allocator 和 particleCount_ 在 reject 后恢复；IDs 唯一且 future exact。

## 33. Carrier generation

PASS：accept+1，reject不变；publication 与 committed generation 一致。

## 34. Lazy cache

PASS：native pose/tet、move/rebound/child identity/generation 失效机制；无效支撑之后 thermo counter 增量0；没有全域虚构气相字段。

## 35. Eight-model capability matrix

NOT CLOSED。coneInjection、sphereDrag、stochasticDispersionRAS、blobsSheetAtomization、ORourke、rebound、voidFraction 的本轮事务门槛通过；ReitzKHRT 真实空间 invalid-child 项 UNCLOSED。整体 capability 不升级；ORourke 保留 NATIVE-PHYSICS-LIMITATION。

## 36. Source/energy regression

FRESH9288/0，8 golden_energy.csv byte-identical。

## 37. M8A.3A regression

FRESH6375/0。

## 38. T2 regression

FRESH1725880/0；21000/21000 all-gas full-support；native comparison maxError3.84593e-16。

## 39. T3A regression

FRESH64395/0。

## 40. P2/R1 regression

FRESH105775/0。

## 41. Temporal/restart regression

FRESH9663/0。这是既有 temporal contract 回归，不是 production DPM restart certification。

## 42. R2B/I1/C2 regression

FRESH R2B252194/0，I1 A-H12083/0+1000stress、nativefalse18/0、retry61/0；C2 required basic subset17/0。C2 parcel family/type/layout 源码及其原证据保持冻结；额外 R2A273263/0。

## 43. Foundation hashes

最终6717 installed source/Make、19 native parcel、ORourke source hash unchanged。protected145、R2B30、I1/R2B240、C1 113、C2/R1/production288 均 unchanged。

## 44. Active solver impact

NONE：无 active equation/EOS/recovery/KT/source adapter/cloud runtime 修改；只新增两个 standalone test targets、工具、fixture、报告及 append-only milestone。两目标 Foundation OF7 wmake PASS。

## 45. Production mesh/BC impact

NONE；20um cleanup_fixture 仅在新阶段目录，生产300_2D源码/网格边界定义 hash unchanged；未运行 blockMesh/checkMesh/CFD solver。

## 46. Whether R2C COMPLETE

NO。真实 KH 空间无效支撑及整体8-model closure 未满足。不得以 test-only 注入替代。

## 47. Whether R2-FINAL may start NEXT ROUND ONLY

NO：R2C仍PARTIAL，本轮或下一轮都未自动获得 R2-FINAL 权限；必须先处理未闭合条件并得到后续授权。

## 48. T3B/T3 status

PARTIAL。

## 49. T4/M8A/M6B permissions

T4 NO；M8A PARTIAL；M6B.0/.1 NO；CFD NO。

## 50. Updated milestone matrix

见下表；本轮结束，STOP。

| Milestone | Status |
|---|---|
| R2B | COMPLETE / FROZEN |
| R2C-I1 | COMPLETE / FROZEN |
| R2C-C1 | HISTORICAL PARTIAL / NONDETERMINISTIC_BINARY_BLOCKER |
| R2C-C2 | COMPLETE / FROZEN / semantic-noncanonical |
| R2C-R1 | PARTIAL / KH_SPATIAL_INVALID_SUPPORT_UNCLOSED |
| R2C | PARTIAL |
| R2-FINAL | NOT AUTHORIZED |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / .1 | NO |
| CFD | NO |

## Exact remaining gate

Current source creates KH child by copying the parent's identical position/cell/tet, assigns a new origId, invalidates shared trackingData session and preflights that child before adding it to cloud. Fixed support map + identical All requirement implies equal physical support. A valid parent cannot have an immediately spatial-invalid child at that same state. NativePose identity independently forces revalidation, which the authorized test-only failpoint verifies.

User explicitly allowed the test-only injection and required the real spatial-invalid item to remain unclosed. It is not a guessed PASS or a native physical failure. No mandatory STOP-class orphan/native mismatch/invalid-thermo/new-ledger/semantic-IO failure occurred in final runs. R2C cannot be COMPLETE under the current checklist. A future user decision must define a reachable physical child-first-query scenario or explicitly revise the unreachable gate; this turn does neither.

## Harness attempts and repairs retained

- pure_v1 remained in gas owner cell1 and hit strict stencil; displacement corrected using actual native geometry, pure_final enters owner2. No budget/physics changes.
- minimum_mass_v1 performed direct calc without injector clock synchronization and hit frozen50000-query budget later. Corrected native injector synchronization; final deletion case passes. Budget never raised.
- rebound_invalid_v1 did not produce an actual wall event before rejection. Final driver explicitly performs native patch correct, invalidates token, then native motion. Accepted direct/retry still executes native evolution.
- lifecycle_v1 retained warm reference roleA, creating registry-name conflicts with alternating active/trial roles. Final selected graph uses reference roleC; lifecycle releases reference before long sequence. Final field-owned Theta check included. Earlier limited passes are not used to replace final evidence.
- Two test compilation errors (C++11 mixed auto deductions and non-STL Foam iterator) repaired incrementally; logs preserved.
- Copied R2B runner retained old stage variable and wrote fresh results into historical I1 evidence folder. Fresh misrouted evidence copied separately, 8 historical files restored byte-exact from frozen I1 checkpoint, runner corrected, and R2B replayed into this round directory. Source/model was never altered. Repair log records entry hashes; no historical record silently reclassified.

## Paths, authority and scope

New targets: tests/fiveEqDPMTransactionR2CR1Resume and tests/fiveEqDPMTransactionR2CR1Events. Full selected graph uses r2::BoundCloud with native model wrappers; fallback old subset graph and arbitrary model recipes are not certified. Canonical codec and numerical formulas retained. External C2 parcel family reused unchanged. Fitting directory: fitting/dpm/m8a3b_t3br2c_r1_resume_v1. Compiler: Foundation7 GCC11.4 C++11 DPInt32 x86-64 serial. No MPI/AMR/dynamic-mesh/cross-ABI/restart claims. No active solver activation, EOS/pressure recovery, VOF-DPM transfer or CFD.
