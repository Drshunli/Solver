# M6A1b-1: constant stiffened-gas adequacy gate

## Exact local candidate convention

`rhosprayLiquidThermo.C` implements

```text
p = (gamma-1)*rho*(e-q) - gamma*pInf
e = q + Cv*T + pInf/rho
p+pInf = (gamma-1)*rho*Cv*T
```

This convention alone is assessed. No published SG parameters are copied across conventions. Required local state checks: `gamma>1`, `Cv>0`, `rho>0`, `T>0`, `p+pInf>0`, `c²>0`; current C++ constructor additionally requires `pInf>=0` and finite `q`.

## Derived properties and coupled restrictions

```text
rho(p,T) = (p+pInf)/[(gamma-1) Cv T]
e(rho,p) = q + (p+gamma*pInf)/[(gamma-1)rho]
T(rho,p) = (p+pInf)/[(gamma-1)rho Cv]
h(p,T) = e+p/rho = q+gamma Cv T
Cp = (dh/dT)|p = gamma Cv              Cv = constant
c² = (dp/drho)|s = gamma(p+pInf)/rho = gamma(gamma-1)Cv T
Ks = rho*c² = gamma(p+pInf)
alpha_p = -(1/rho)(drho/dT)|p = 1/T
kappa_T = (1/rho)(drho/dp)|T = 1/(p+pInf)
drho/dp|T = 1/[(gamma-1)Cv T] = rho/(p+pInf)
de/dp|rho = 1/[(gamma-1)rho]
dc/dp|T = 0;  dh/dp|T = 0;  dCp/dT = 0
```

`gamma,pInf,Cv` jointly fix density, acoustic stiffness, expansion and both heat capacities. `q` only shifts energy and cannot improve any mechanical or `Cp` shape error. At fixed `p`, `rho*T` is constant; at fixed `T`, sound speed is pressure independent; at fixed `p`, sound speed *increases* as `sqrt(T)`. These are algebraic restrictions, independent of optimizer quality. Thermodynamic consistency of `c²` follows from `ds=Cv dT/T-(gamma-1)Cv d(rho)/rho`, or direct isentropic differentiation; code round trips are separate from physical adequacy.

## Predeclared selection criterion

Before fitting: reject the model for the intended compressible liquid if an unavoidable, systematic single-property shape error greatly exceeds published measurement/reference uncertainty in states likely to include the nominal 300 K liquid. This is an uncertainty-relative **model selection gate**, not a relaxed, post-hoc CFD tolerance. The actual project p/T target is not approved, so no global percentage acceptance threshold or solver parameters are declared.

## Reproducible limited-domain test

Run `python3 fitting/m6a1b1_shape_gate.py`. Strategy A projects seven P24 densities at 0.1 MPa onto `rho=a/T`; B adds seven P24 sound speeds onto `c=b*sqrt(T)`; C adds ten R17 `Cp` values onto a constant. Each family minimizes squared relative error separately. This is a **relaxed shape projection**: it does not enforce all cross-property parameter relations, so a full SG fit cannot do better than these family-specific lower bounds. The datasets do not span a common multi-pressure p/T grid; these are not accepted `(gamma,pInf,Cv)` fits. `q` is absent.

| Strategy / property | MARE | RMS relative | Maximum relative | Reference-state signed relative | First→last signed relative |
|---|---:|---:|---:|---:|---:|
| A rho, 288.15–333.15 K | 2.882% | 3.269% | 5.399% | +1.804% at 298.15 K | +4.253%→−5.399% |
| B rho | 2.882% | 3.269% | 5.399% | +1.804% at 298.15 K | +4.253%→−5.399% |
| B c, 288.15–333.15 K | 6.700% | 7.527% | 12.447% | −5.240% at 298.15 K | −9.759%→+12.447% |
| C rho/c | same relaxed lower bounds as B | same | same | same | same |
| C Cp, 323.15–403.15 K, ~0.12/10.17 MPa | 3.909% | 4.556% | 7.095% | +5.708% at 323.15 K/0.12 MPa | +5.708%→−6.051% (last at 10.17 MPa) |

These trends are much larger than R17's 0.4% expanded `Cp` uncertainty; the acoustic mismatch also far exceeds the <1.7% expanded uncertainty reported for Z20 pressure measurements, though this *specific* P24 c series has no accepted numerical uncertainty in the present audit. The direct P24 endpoints `c(288.15)=1274.3`, `c(333.15)=1099.6 m/s` fall while SG demands an increase by `sqrt(333.15/288.15)=1.075`; no positive parameter choice reverses this. R17's Cp rises from 2293 to 2609 J/(kg K) over 323.15–403.15 K at ~0.12 MPa, contradicting constant Cp.

At ~298.15 K, a finite difference from P24 density at 293.15/303.15 K gives `alpha_p≈0.001044 K^-1`; SG requires `1/298.15=0.003354 K^-1`, **3.21 times larger**. This derivative estimate has discretization/measurement error not yet propagated; its factor-of-three gap is still a strong structural signal. `rho*T` from the P24 endpoints is not constant. The 2020 Z20 pressure-isobar sound-speed data are directly relevant to `dc/dp|T=0`, but accessible per-state pairs were not imported, so a numeric pressure-slope statistic is pending.

### Extrapolation and positivity

For any hypothetical valid parameters with `pInf>=0`, positive `p,T` yield `rho>0`, `c²>0`, `drho/dp|T>0`; below `p=-pInf`, the model fails positivity. No actual parameter set is approved, so numeric checks below `p_min` and above `p_max` cannot honestly be reported. The target `p_min/p_max/TL_min/TL_max` are also open. M6A1b-2 must test a selected alternative EOS on an expanded domain and require monotonic pressure response, positive density/temperature/acoustic square and phase validity.

## Verdict: REJECT constant-parameter SG as final n-decane EOS

The verdict is on **model structure**, already falsified over a modest liquid temperature interval surrounding the plausible 300 K parcel state. This is not a claim of a complete target-envelope numerical fit. **M6A1b-1 model gate is COMPLETE; its operating envelope remains INCOMPLETE.** The later M6A1b-2A envelope lock is blocked by missing future inlet conditions. Do not promote `gamma`, `pInf`, `Cv`, or `q`.

## Alternative architecture shortlist (no implementation this round)

| Model | Density / acoustic / caloric capability | Five-equation inversion and derivatives | Main risk/cost |
|---|---|---|---|
| NASG (Noble–Abel stiffened gas) | Adds co-volume, improving liquid compression; constant thermal laws still restrictive. | Analytic `p(rho,e)`, `e(rho,p)`, `T`, `c`, derivatives; attractive KT/M6A2 path. | Check `dc/dp|T` and `Cp(T)` against data; may still fail. |
| Tait + thermodynamically consistent caloric extension | Can fit measured `rho(p,T)` and acoustic response if `B(T),n(T)` chosen; caloric closure must be derived. | Numerical inversions/derivatives; integrability and energy reference must be proved. | A density-only Tait law is insufficient; extrapolation and thermal consistency. |
| Mie–Grüneisen type | Compression and acoustics can be flexible with reference curve and `Gamma(rho)`; caloric reference curve required. | Usually direct `p(rho,e)` and derivative access; suitable for KT and scalar pressure root. | Complex temperature/phase dependence, more calibration data. |
| Tabulated Helmholtz/reference EOS | Best path to consistent rho, c, Cp, Cv, h/e, expansion and compressibility across documented single-phase range. | Build monotone `(rho,e)↔(p,T)` tables and verified derivatives; KT and M6A2 root possible. | Table generation, interpolation consistency, phase masking, memory/performance and energy-zero alignment. |

For M6A2/KT specifically: NASG has cheap analytic `p(rho,e)`, `e(rho,p)`, `T(rho,p)`, `c` and derivatives, but poor temperature-shape flexibility. A complete Mie–Grüneisen law also has a cheap `p(rho,e)` and usually an explicit `e(rho,p)`; temperature and sound speed need consistent reference/caloric curves. Tait plus caloric extension requires a thermodynamic potential or integrability proof before it may supply `e(rho,p)` and sound speed; a standalone `rho(p,T)` correlation is disqualified. A Helmholtz table derives `p,e,c,Cp,Cv` and derivatives from one potential, but M6A2 evaluates `T(rho,p)` by a safeguarded scalar solve and KT must use interpolated derivative-consistent `c`; table edges and phase boundaries need explicit guards. Computation and storage rank approximately NASG lowest, Mie–Grüneisen moderate, Tait-extension moderate, Helmholtz table highest. Extrapolation is safest only where each model has a documented monotonic physical extension; a reference table should reject out-of-domain states rather than silently extrapolate.

**Recommendation for next gate:** prioritize a single-phase Helmholtz/reference-EOS table based on Lemmon–Span/validated REFPROP or CoolProp export, then compare a compact thermodynamically complete Mie–Grüneisen/NASG surrogate if cost justifies it. Do not select `rho(T)` or OF7 spray `liquidProperties::rho(p,T)` as the five-equation EOS: those lack the required compressible acoustic/caloric closure.
