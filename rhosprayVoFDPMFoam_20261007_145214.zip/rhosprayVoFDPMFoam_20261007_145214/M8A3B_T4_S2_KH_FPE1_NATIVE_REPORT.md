# M8A.3B-T4-S2-KH-FPE1-NATIVE report

2026-10-04. Evidence: fitting/dpm/m8a3b_t4_s2_kh_fpe1_native_v1.

## 1. FPE1 status

**COMPLETE / DIAGNOSIS ONLY.** Failure diagnosed, not repaired.

## 2. Exact fixture reproduction

Final isolated exact_final_fixture contains69 byte-identical inputs; d=.0003 m,dt=1e-5 s,startX3.9999 m,p3MPa,TG800K,CRT1e9 retained. Native second evolve SIGFPE reproduced; debugger terminates stopped inferior, not a clean trial rejection. Original non-debug exit136 remains frozen evidence.

## 3. First-step identity uniqueness

6 parcels/6 unique pairs: (0,0),(0,1),(1,0..3). First-step full trajectory rows equal frozen ID1 exactly, not only within tolerance.

## 4. Failing rank

rank1.

## 5. Failing parcel identity

(origProc,origId)=(1,0). Position(4.0063528433679441,0.5000114411347838,0.50000751260865317)m; cell0,face-1,tetFace20,tetPt2,stepFraction0.89999999999999991.

## 6. Parent/child classification

Destination-born child of migrated parent(0,0), confirmed by copy-before-identity/after-identity/initialization observations. Not migrated parent or source-born child. Carrier generation1; no custom genealogical ID introduced.

## 7. Exact native library/function

Native Foam::ReitzKHRT<selected LazySprayCloud>::update instantiated in testKHFPE1Native executable; no separate shared update library. Executable SHA256 657222383cd67bbe48d9a4a0e2212b4715f35fc4883a0594fbd5379fa29dddd4. Loaded library paths/SHA saved; installed OF7 libraries retained.

## 8. Exact source file/line

Foundation7 src/lagrangian/spray/submodels/BreakupModel/ReitzKHRT/ReitzKHRT.C:161. Exact symbolized backtrace and JSON frames saved. Same unchanged source via lnInclude.

## 9. Exact arithmetic expression

`constant::mathematical::twoPi*cRT_/(KRT+vSmall)`; trapped x86 divsd, MXCSR overflow flag OE.

## 10. Operand values

twoPi6.2831853071795862,cRT1e9,KRT0,vSmall2.2250738585072014e-308. Quotient≈2.8238097729461284e317 > double maximum1.7976931348623157e308. All native arguments and members are tabulated in KH_SIGFPE_EXPRESSION_AUDIT_v1.md and failure.rank1.json.

## 11. Finite/domain audit

34 scalar components including all call arguments/coefficients/average mass finite. No prior negative radicands or invalid fractional-power domain. U magnitude nonzero, tMom positive; divisor positive, not zero. First violation is representability overflow at161. Unassigned lambdaRT/later locals in raw debugger capture are not valid output.

## 12. Parcel state before update

17-digit state table below; liquid T300K,d3.9922177082177593e-8m,nParticle2296664553.4200964,rho725.21967199798883. Identity/geometry/history and values captured before call, without mutation.

## 13. Breakup history before update

tc0,ms=-4503599627370496 (native -great sentinel),KHindex1,y0,yDot0,d0=d. These sentinel/history values are not the failed operand.

## 14. Carrier state before update

Materialized rhoc13.003901969784536,Tc800.00000000000023,pc3000000.0000000014,Cpc1105.699039909468,muc3.8978930586897334e-5. Uc=(47.471629073545508,0.86856375485953841,0.57032625730456021), exactly equals parcel U. Native KH rhoc input is temperature-averaged rhoAv22.292403376773496, not a corrupted materialized density; follows existing calcBreakup perfect-gas/Taverage calculation.

## 15. Support/generation state

Last session valid=true,requirements255,generation1; pose pointer/identity/geometry correspond to failing parcel(1,0). S1 last preflight row agrees. No support rejection, invalid gas or fallback.

## 16. RNG state

x_=110983831113855,scalarNormalStored_=false,scalarNormalValue_=0. Actual native update body performs no Random call, before or after161. RNG consumption elsewhere remains native.

## 17. Sender/receiver relevant fields

2 actual0→1 boundary transfers PASS for identity, raw C2/native stream physical/history values, position/barycentric correction, prepare/correct RNG. No authoritative operand corruption observed.

## 18. Migration relevance

Failing child born on rank1, not received through migration. Serial same-input native control and rank1 no-crossing control both reproduce161. MPI transport not necessary for the overflow; no serializer redesign.

## 19. Newborn initialization relevance

Captured actual child copy, identity-only assignment and initialized state. d/nParticle/rho/T/history finite; native negative ms sentinel expected. Initial and pre-failure states saved in diagnosis_result.json. No illegal physical child initialization demonstrated.

## 20. Identity-fix neutrality

8 observed identity assignments: every physical/geometry/history field and RNG equal immediately before/after assignment; only identity changes. Frozen serial K1 evidence inherited under exact authorized shared-source SHA:22 full states byte equal,108 checks/0 failures.

## 21. Serial native control

Same captured native arguments, model coefficients and computed averageParcelMass exactly equal; native update raises SIGFPE at161 without Cloud::move/MPI. No copied runtime KH formula. Initial S1_TWO_RANK_FIXED_MESH_ONLY attempt preserved as not a KH control result; final control executes before S1 construction.

## 22. No-crossing control

rank1 direct captured-state native call with no processor transfer reproduces161; same argument/coefficient/averageMass check PASS. Initial attempt blocked by rank-only collective cloud construction preserved; final harness constructs native clouds on all ranks first.

## 23. Offline expression reproduction

tools/auditNativeKHFailure.py computes only the one captured failed expression using80-digit Decimal. No runtime solver changes; no alternate KH implementation. expression_audit.json confirms positive divisor and double overflow.

## 24. Classification A-F

**CLASS D / FIXTURE_DOMAIN_INVALID:** source-implied finite-output arithmetic domain violated by fixed CRT1e9 when KRT=0. Not a guessed physical correlation limit; see derived domain inequality. No evidence for A/B/C. Not classified E mathematical singularity because divisor remains nonzero.

## 25. Whether root cause established

YES for this exact overflow: native source/line/instruction, all operands, register flag, source-implied bound and two native no-migration reproductions agree. Does not certify all other KH states or resolve all ID1 gates.

## 26. Whether source fix made

NO. No physical model, coefficient, identity adapter, source adapter, native allocator, tracking, transport, support, latch, quarantine or stateCodec changed. Only new isolated diagnostic target/debugger/offline tool and documentation.

## 27. Foundation hashes

Fresh6717 installed-source and19 native-parcel checks PASS. Included ReitzKHRT source byte-identical to audited native source and reference snapshot. Debug-only exe, no installed library replacement.

## 28. Project hashes

3767 protected entries all unchanged before authorized milestone append; previous ID1 checkpoint exact SHA/CRC PASS. Closing entry append-only, old evidence/checkpoints unchanged. New diagnostic files separately hashed.

## 29. Active solver impact

**NONE.** No active equation/flux/thermo/source changes.

## 30. Production mesh/BC impact

**NONE.** Isolated fixture copies only; no CFD, production restart or boundary edits.

## 31. FPE1 COMPLETE?

YES / DIAGNOSIS ONLY. All diagnosis gates closed. No fix or clean fatal-trial rollback certificate claimed.

## 32. ID1 status

PARTIAL / KH_SIGFPE_BLOCKER; pending separately authorized resolution and remaining identity gates.

## 33. T4-S2 status

PARTIAL. S1/N1 frozen scoped evidence remains valid. Fresh minimal S1 audit and N1 valid/forward-invalid spots globalFailures0; no giant regression suite rerun.

## 34. Next permitted milestone

No automatic continuation. Owner decision/authorization required for fixture activation-domain policy or any model/guard change. Only after separate blocker resolution may ID1 closure resume; no remaining ID1/R1/S3 executed.

## 35. T4/M8A/M6B/CFD matrix

See matrix below; T4/M8A PARTIAL, M6B/CFD NO, S3 NOT AUTHORIZED, production restart NOT CERTIFIED. STOP.

## Exact pre-call parcel fields

| Field | Value |
|---|---|
| d_ | 3.9922177082177593e-08 |
| d0_ | 3.9922177082177593e-08 |
| nParticle_ | 2296664553.4200964 |
| U_ | (47.471629073545508, 0.86856375485953841, 0.57032625730456021) |
| rho_ | 725.21967199798883 |
| T_ | 300 |
| Cp_ | 2220.0513054784406 |
| mu_ | 0.00084834571996310901 |
| sigma_ | 0.023208780744580066 |
| age_ | 1.289999999999979e-05 |
| tTurb_ | 2.1899999999999787e-05 |
| UTurb_ | (0.47162907354550648, 0.86856375485953841, 0.57032625730456021) |
| mass0_ | 2.4160774308013954e-20 |
| tc_ | 0 |
| ms_ | -4503599627370496 |
| KHindex_ | 1 |
| y_ | 0 |
| yDot_ | 0 |
| tMom_ | 1.6473868106346646e-09 |

## Milestone matrix

| Milestone | Status |
|---|---|
| R2-FINAL/T3 | COMPLETE / FROZEN |
| T4-S1 | COMPLETE / FROZEN |
| T4-S2-C1-N1 | COMPLETE / FROZEN, isolated scope |
| T4-S2-KH-FPE1-NATIVE | COMPLETE / DIAGNOSIS ONLY; CLASS D |
| T4-S2-ID1-NATIVE | PARTIAL / KH_SIGFPE_BLOCKER |
| T4-S2-R1-NATIVE / S2 | PARTIAL / PARTIAL |
| T4 / M8A | PARTIAL / PARTIAL |
| T4-S3 | NOT AUTHORIZED |
| M6B / CFD | NO / NO |
| Production restart | NOT CERTIFIED |

Both isolated build and captured-state controls retain actual native ReitzKHRT. Debugger quit kills the stopped inferior: job status is not a production pass or transaction discard. Early observer verbose/type-display attempts and watchdogs retained, not counted as clean model tests. exact_fixture contains appended exploratory replay diagnostics; authoritative single replay is exact_final_fixture. No more model runs after final diagnosis. STOP.
