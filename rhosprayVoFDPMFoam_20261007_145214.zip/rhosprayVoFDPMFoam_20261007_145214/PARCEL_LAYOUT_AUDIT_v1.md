# PARCEL_LAYOUT_AUDIT_v1 — C1 instrumentation separation

## Status and environment

C1 PARTIAL / NONDETERMINISTIC_BINARY_BLOCKER / STOP. Original outer-Spray overrun mechanically removed in the isolated C1 family, not promoted into frozen I1 or active solver.

Actual compiler: Ubuntu g++ 11.4.0; OF7 WM_COMPILER=Gcc, linux64GccDPInt32Opt, C++11, x86-64 Itanium C++ ABI, DP scalar=8 bytes, label=4 bytes. Intel2021 is NOT the configured compiler; no Intel or cross-compiler certification. Every offset below is measured relative to that layer's object address through protected-member pointers, not guessed from sizeof(base).

## Measured native/local layout

| Type | Base size | Size | Align | First | End | Raw extent | Physical span |
|---|---:|---:|---:|---:|---:|---:|---:|
| localKinematic | 112 | 216 | 8 | 108 | 216 | 108 | 108 |
| localThermo | 216 | 232 | 8 | 216 | 232 | 16 | 16 |
| localReacting | 232 | 264 | 8 | 232 | 240 | 8 | 8 |
| localSpray | 264 | 384 | 8 | 264 | 384 | 120 | 120 |
| nativeKinematic | 112 | 216 | 8 | 108 | 216 | 108 | 108 |
| nativeThermo | 216 | 232 | 8 | 216 | 232 | 16 | 16 |
| nativeReacting | 232 | 264 | 8 | 232 | 240 | 8 | 8 |
| nativeSpray | 264 | 384 | 8 | 264 | 384 | 120 | 120 |

Reacting raw block is only mass0 (8 bytes). Y is explicitly serialized as a dynamic scalar list; its pointer/list object metadata is not dumped. Reacting end=240 is the end of mass0, not the end of Y's 24-byte in-object list representation. No field is omitted because the raw block is shorter than the object delta.

Kinematic first=108 is smaller than sizeof(particle)=112: this ABI reuses base tail padding. The inherited Kinematic length is sizeof(Kinematic)-offsetof(active), NOT simply sizeof(Kinematic)-sizeof(particle). Its 108-byte span includes native in-object padding. Equality of raw extent and span proves containment, not that every byte is an authoritative scalar.

## Physical member ownership map

| Layer/category | Members | Native IO contract |
|---|---|---|
| particle A: authoritative tracking/identity | coordinates, cell, tetFace, tetPt, face, stepFraction, behind, nBehind, origProc, origId | ASCII individual fields; native binary raw coordinates-to-size block |
| Kinematic A: parcel state | active, typeId, nParticle, d, dTarget, U, rho, age | native Kinematic block |
| Kinematic B: persisted model history | tTurb, UTurb | native contract explicitly persists these |
| Thermo A/B: liquid temperature and derived stored heat capacity | T, Cp | native two-scalar block; Cp stored despite being derived |
| Reacting A | mass0, Y | scalar raw block plus explicit dynamic scalar list |
| Spray A: initial/atomization/breakup/history state | d0, position0, liquidCore, KHindex, y, yDot, tc, ms, injector, user | native Spray block |
| Spray B: derived stored physical properties | sigma, mu, tMom | native contract explicitly persists these |
| B transient, outside physical parcel | GasSupportMap/interpolation/property cache, generation token/address, transaction pending output | not parcel raw payload; existing transaction/cache owners retained |
| C test instrumentation | address-keyed map, constructed/destroyed/live, guard/cloud counters/hooks | external passive harness only; zero parcel members |

## Binary extent expressions retained

Kinematic: sizeof(localKinematic)-offsetof(active_); Thermo: sizeof(localThermo)-offsetof(T_); Reacting: sizeof(scalar), then Y list; Spray: sizeof(localSpray)-sizeof(ParcelType). No magic 120-byte constant, serializer replacement, new restart format, object memset, or padding normalization introduced.

C1 local outer size 384, native outer size 384; prior instrumented I1 outer size 392. Outer raw extent now120 and starts264, ends384 exactly. Total stream bytes both355 (prior local363). Leading/trailing32-byte fences stay intact on writer/readback. Fence-only mutation cannot affect bytes. Controlled source and decoded ASCII physical representations match.

## Determinism failure

Two placement copy constructions of the same physical parcel use separate storage allocations pre-poisoned A5/5A before any object lifetime starts; they retain different untouched padding. This is a diagnostic challenge, not zeroing or normalizing padding to manufacture a PASS. No live-object bytes are changed. Fence-only mutation affects only reserved bytes outside the object.

Outputs differ at stream offsets78,79,80,84,85,86,91,92,93,94: A5 versus5A. ASCII physical state is equal. Same-object repeated write is identical. The unmodified native parcel pair also differs, so the strict C1 byte-canonical requirement exceeds what this native raw layout guarantees. This is not a new native physical-field-loss or out-of-object-memory bug.

Current native particleIO.C writes from coordinates through sizeof(particle), including base tail padding; KinematicParcelIO.C writes from active through sizeof(KinematicParcel), including alignment padding around bool/label/scalar. The measured active at108 and base size112 explain duplicated base-tail bytes in layered blocks. These raw native expressions are retained exactly. Native source hashes and source copies are in the evidence directory.

Therefore binary deterministic/address-independent canonical certification remains BLOCKED. Do not clear padding, adjust length, switch serializer or downgrade to ASCII-only certification this round. Future alternative policy/serializer work requires a separate authorization. Production restart remains uncertified.
