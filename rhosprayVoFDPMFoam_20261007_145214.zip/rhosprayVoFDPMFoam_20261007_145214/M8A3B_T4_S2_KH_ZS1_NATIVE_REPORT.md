# M8A.3B-T4-S2-KH-ZS1-NATIVE — COMPLETE

Date: 2026-10-04. Scope: isolated parcel compatibility gate, two-rank fixed-mesh support fixtures and serial captured-state controls. No CFD, production solver activation, remaining R1, 1000-crossing stress, S3 or M6B.

## 1. ZS1 status

**COMPLETE within the authorized isolated scope.** `ZS1_gate.json`: 75 gates, zero failures. This does not complete S2 or certify production restart.

## 2. Exact compatibility condition

Only `Urmag == 0 && this->KHindex() < 0.5`. No SMALL, velocity or Weber tolerance. Initialize `khIndexEval` from real history; set only the temporary to 1 when this exact condition holds. Call native breakup update on every path. Copy the native index result back only when compatibility is inactive.

## 3. Local source delta

Only shared implementation delta: `tests/fiveEqDPMParcelC2/parcel/LazySprayParcel.C:263–301`. Before SHA256 `487efe1c7b329dad9bcb24a80f6b37d20e88f5ded085b7ba74ad4e08ce1ea94f`; after `c264b0b22cb95d96dc6349fdb40f2993e04a146958cc9f881f15ef54aaf007b5`. See `source_delta.diff`. Existing child allocation, identity, support, rollback and transfer bodies remain unchanged. New test targets and offline audit/observer scripts are independent additions; old targets/binaries/evidence remain frozen.

## 4. Why this compatibility is needed

Frozen FPE2 diagnosis established a contract-valid zero-slip input reaching native larger-drop evaluation: lengthScale=0 → d=0 → massDrop=0 → positive mass/massDrop at native line254. Temporary index avoids that native larger-drop branch without rewriting it and without skipping earlier RT evaluation. This is the explicitly authorized policy, not a claim that this adapter is the only conceivable model design.

## 5. ReitzKHRT source status

Foundation ReitzKHRT implementation, equations and coefficients unchanged. No model clone/fork. Actual unchanged production-intended coefficients in observed native calls: B0=.61, B1=15, Ctau=1, CRT=.1, msLimit=.2, WeberLimit=6. Average parcel mass `2.4800000094247781e-11` remains equal to captured FPE2. No epsilon, diameter/mass clamp, random perturbation or signal recovery.

## 6. Exact-zero MPI result — A

Replay of the frozen FPE2 reverse fixture: all69 input files byte equal; same native evolve arguments `-reverse -steps1 -dt.004 -gasUx-47`, two ranks. Normal exit, no SIGFPE, globalFailures=0 on both ranks. First breakup on rank1: Urmag exactly0, real KHindex0, temporary1. After native return d=`0.0009999999999999998`, nParticle=1, real index0. Native reverse crossing subsequently completes. Full final identity remains (1,0), rank0 x=3.912, Ux=-47. Source/owner teardown follows the existing disposable trial path; this is not global accepted-MPI-transaction certification.

## 7. Exact-zero serial result — B

No MPI, no transport. The same project `calcBreakup` method is exposed by a test-only derived probe, bound through the existing serial R2C carrier-support implementation. Native consumed arguments all equal frozen captured FPE2 except the intentional temporary KHindex; native coefficient and average-mass values equal. No FPE; finite state, no child, unchanged sources and RNG. Initial serial scaffold hit S1_TWO_RANK_FIXED_MESH_ONLY before any KH call; retained as a setup attempt. Corrected scaffold uses existing serial support, without changing S1 or its guard.

## 8. d/nParticle result

| Control | d (m) | nParticle | Per-droplet mass (kg) | Result |
|---|---:|---:|---:|---|
| Serial exact zero, no RT | .0009999999999999998 | 1 | 3.7972413229794656e-7 | Neutral, positive |
| Serial near nonzero | 9.2276528805908473e-8 | 1272700610662.6177 | 2.9836092566990073e-19 | Native bit parity |
| Serial positive slip7m/s | .00019276634620528629 | .13960672950042993 | 2.7199557905034757e-9 | Native bit parity |
| Serial RT-active zero slip | .00012492224107319488 | 512.95669170682163 | 7.4026548134979073e-10 | Native bit parity |
| Final reverse MPI | 7.3239929447904915e-8 | 2545401221464.0679 | Finite, positive | Native evolve completes |

Mass column is mass of one represented droplet, not nParticle-weighted parcel mass. No d=0, inf or NaN in observed post-update states. Very small native diameter/large represented counts are retained; this gate does not certify their physical suitability.

## 9. Real KHindex result

Compatibility-active exact-zero calls preserve real index0; serial noRT and RT controls both retain0. MPI's next call has nonzero rounding slip `7.1054273576010019e-15`; compatibility is inactive and native larger-drop mutation correctly writes real index1. Final MPI index1 is therefore an observed native nonzero mutation, not fabricated shim history. No tolerance is introduced to suppress it. Read-only `PROJECT_AFTER_INDEX_WRITEBACK` witnesses establish both cases.

## 10. RT preservation — F

**PASS / ACTUALLY REACHED.** Test-only control starts from the same captured liquid/carrier state with nonzero U=-47, exactzero slip, native tc=1 and g=(-1e7,0,0)m/s². These are explicit RT-test initial/history/loading inputs, not production edits. Both project compatibility path and direct unchanged native call execute ReitzKHRT.C:179. Diameter, nParticle, tc, ms, y/yDot and realKHindex compare bitwise equal. Native tc becomes `-4503599627370496` (its -great sentinel); realKHindex remains0. No hand-coded RT formula or bypass. The noRT zero control retains native tc0.

## 11. Near-zero native parity — C

Exact slip `1.4210854715202004e-14` observed. Compatibility inactive. Scalar d/nParticle/KHindex/tc/ms/y/yDot bit parity against direct native call, no child and source bytes/RNG unchanged. Complete two-rank forward replay against frozen unmodified native-path executable: both ranks' full accepted-output state, trajectory, continuation/source/VF diagnostics, RNG state and next32 draws byte equal (10 comparisons). Native diameter and index mutation remain untouched.

## 12. Positive-slip native parity — D

Serial slip7m/s: inactive compatibility and direct-native bit parity. Full forward native-evolve control with gasUx40: both ranks' corresponding10 state/trajectory/source/RNG artifacts byte equal to frozen unmodified executable. No trajectory tuning. The captured serial positive case uses d=.0001; full MPI control retains the frozen .001 initial diameter; each is compared against its own identical native reference input.

## 13. Native KH birth parity — E

One fresh replay of frozen accepted ID1 fixture, ten native evolves, CRT=.1. Eighteen natural births: rank0=1, migrated-parent rank1=17. Parent(0,0), sourcechild(0,1), destinationchildren(1,0..16), final19parcels. Both rank-local `ID1_local_accepted.bin` payloads, trajectories, continuation/source diagnostics, textual native state and birth logs byte equal frozen accepted_direct (10comparisons). Existing rank-local prepare/publish/flush remains the only acceptance scope; no global transaction certificate is asserted.

## 14. RNG

Shim has no RNG call and consumes zero draws. Every serial control retains the complete native RNG state; sources remain byte equal and momentum source magnitude0. Nonzero full MPI parity includes next32 RNG draws. Native migration prepare/correct consumes no extra draw. Native KH formulas remain responsible for state changes.

## 15. Identity

Frozen ID1 birth-rank origProc plus native local origId allocation unchanged. Accepted18birth identities/logs/payloads exact. K1 fresh identity checks:92births and92negative checks, laterchildqueries5694; true spatial-invalid-at-birth item remains false/unclosed as previously documented. No claim of physically invalid child support is manufactured.

## 16. Migration

Native Cloud::move/streams/iNew/processor transfer untouched. Existing C2 is a read-only audit oracle, never a serializer. Fresh boundary oracle: exact-zero reverse1event1→0 PASS; near forward1event0→1 PASS; positive forward1event0→1 PASS; ID1birth fixture2events0→1 PASS (parent and sourceborn child). Scalar/history/identity, barycentric reflection, tet and RNG prepare/correct checks pass. Scope remains axis-aligned fixed two-rank processor patch.

## 17. Serial regressions

Fresh current-source independent builds and runs:

| Gate | Checks | Failures |
|---|---:|---:|
| K1 |108|0|
| C2 |17|0|
| I1 |12083|0|
| R2B |252194|0|

K1 additional22 complete direct/retry states byte equal frozen baseline. Existing adapters and lifetime/registry checks remain in force. No old executable overwritten.

## 18. S1/N1 regressions

Fresh S1 coupled-support replay:20051checks total, zero global failures. S1 backend and binary unchanged; its1000support validity/stale cycles are the requested support regression, not1000parcel-crossing R1stress. New current-source N1 valid/forward-invalid/reverse-invalid runs all globalFailures0. Invalid destination uses exact-gas-absent support rejection, existing latch/quarantine/drain/reduction/discard; full rollback/registry/live-owner checks pass. S1 and N1 implementation files unchanged.

## 19. Foundation hashes

Fresh6717 installed Foundation-source checks PASS;19native parcel checks PASS. ReitzKHRT.C and native SprayParcel bytes unchanged. See native/installed verification logs.

## 20. Project hashes

Pre-history-append audit:19841frozen entries,19840unchanged, one authorized LazySprayParcel delta, zero unexpected changes. Prior reports/checkpoints/targets/identity/transport/S1/N1/production records remain frozen. This report and milestone entry are new authorized documentation. The closing manifest records the changed source and append-only milestone, preserving earlier history bytes.

## 21. Active solver impact

**NONE.** No active equation, runtime cloud/model binding, pressure recovery, gas/liquid EOS, mG/mL/cL/cMix, KT flux or surface-tension activation change. All protected active records retain their baseline hashes.

## 22. Production impact

**NONE.** Production mesh, BCs, operating conditions, coefficients and restart files unchanged. Cloned input-case hashes retain their source bytes. New controls are disposable test targets; no CFD case or production restart run. CompilationPASS for7 independent current-source targets plus corrected serial harness. Initial stream-option construction compile error is preserved and fixed only in the new harness. Initial read-only observer line selections missed the desired post-write/RT witness; corrected to project301/native179 with fresh cloned output folders, final observations authoritative. All attempts are retained rather than hidden.

## 23. Whether ZS1 COMPLETE

**YES**, every authorized A–F gate closes; RT is reached, not waived. `ZS1_gate.json` and `k1_fullstate_parity.json` support the certificate. Valid only for the explicit exactzero policy and isolated tested scope; it is not a general ReitzKHRT applicability certificate or full conservation-safe spray certification.

## 24. Whether R1 may resume

**NEXT ROUND ONLY.** The diagnosed zero-slip blocker is addressed within this policy. No remaining R1 test,1000crossing stress or broader MPI accepted-ledger/source/output/concurrency gate executed this round. Future R1 authorization remains required.

## 25. T4-S2/T4/M8A status

| Milestone | Status |
|---|---|
| KH-FPE2-NATIVE | COMPLETE / DIAGNOSIS ONLY / FROZEN |
| KH-ZS1-NATIVE | COMPLETE / isolated exactzero gate |
| ID1-NATIVE / accepted fixture | COMPLETE / FROZEN / isolated identity scope |
| T4-S2-R1-NATIVE | PARTIAL; may resume next round only |
| T4-S2 | PARTIAL |
| T4 | PARTIAL |
| M8A | PARTIAL |
| S3 | NOT AUTHORIZED / NOT EXECUTED |
| Production restart | NOT CERTIFIED |

Prior ORourke and true spatial-invalid child-support limitations remain open. No frozen gate is retroactively promoted.

## 26. M6B / CFD permissions

**M6B NO; CFD NO.** Active integration, production restart, S3 and remainingR1 not executed. STOP.
