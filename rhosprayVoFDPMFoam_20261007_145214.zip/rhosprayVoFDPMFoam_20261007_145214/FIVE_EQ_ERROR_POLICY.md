# Recovery error and diagnostic contract

tryRecover returns bool plus enum status/code; no FatalError in recovery.
recoverOrFail throws a recoverable C++ exception after lazy formatting; it does
not terminate OpenFOAM. Future caller decides policy. Startup dictionary IO and
OF7 JANAF construction follow Foundation validation; malformed configuration
must be handled before queries, and is not a physical state-recovery policy.

Codes: INVALID_ALPHA, NEGATIVE_PARTIAL_MASS, INVALID_TOTAL_DENSITY,
PHASE_PRESENCE_INCONSISTENT, GAS_EOS_INVALID, LIQUID_EOS_INVALID,
NO_COMMON_PRESSURE_INTERVAL, NO_PRESSURE_ROOT, NONPOSITIVE_ROOT_DERIVATIVE,
ROOT_NOT_CONVERGED, INVALID_SOUND_SPEED, NONFINITE_STATE,
INTERNAL_PROGRAM_ERROR; additional INVALID_COMPOSITION and INVALID_DIMENSIONS.
Physical failures are STATE_FAILURE. Dimension-contract errors are
CONFIGURATION_FAILURE; unknown/coding/option failures INTERNAL_FAILURE.
A failed recovered output is reset INVALID, never stale accepted data.

Diagnostic is enum/numeric data: input alpha/masses/rhoMix, attempted mode,
legal bracket, last valid trial p/residual, iterations/fallback, phase validity,
cell/face context and guess flags. Availability bits distinguish unavailable
zero placeholders. Input nonfinite values may be retained for reporting only;
failed output is never usable as physics. A last trial is not an accepted root.
FormatDiagnostic is lazy and produces strings only when caller requests it.
Kernel uses existing fixed validity/reason strings; no complex formatted message
is constructed on successful bridge queries. Not claimed allocation-free.

No common domain/root causes a diagnostic, not clipping/extrapolation or a fake
bracket. The accepted exact-singleton policy from M6A2.1 is retained.

Future caller policy: collect first invalid cell/face/rank ID, Q and diagnostic,
then controlled FatalError until explicit rollback is implemented. No rollback
here. Reconstruction policy: try high-order conservative Q -> recover -> caller
may reconstruct lower-order conservative Q -> recover again -> controlled fail.
No reconstruction, interpolation or thermodynamic clamping in bridge/kernel.

Caller/rank/thread-owned counters count pure/mixed/liquid successes, invalid
queries, last BUFFER liquid states, scalar root/Newton iteration attempts
(including fallback iterations), fallback steps, maximum iterations and no-root
failures. nNewtonIterations is the attempt count, not accepted Newton-only steps.
merge sums counts and takes maximum iteration count. Future MPI reductions are
once per caller loop/timestep, using SUM/MAX outside queries; wide counter
conversion must preserve uint64 values. No singleton or MPI calls in recovery.
Thread/MPI design is documented; no distributed integration test was performed.
