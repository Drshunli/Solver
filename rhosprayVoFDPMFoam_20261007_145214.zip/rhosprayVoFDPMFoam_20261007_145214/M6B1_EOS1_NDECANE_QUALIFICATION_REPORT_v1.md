# M6B.1-EOS1-NDECANE — admissibility extension qualification

## 1. EOS1 status

**PARTIAL / CAPTURE EVIDENCE INCOMPLETE — NOT DESIGN QUALIFIED.** 本轮仅EOS设计/离线资格测试，没有active安装或时间策略修复。独立参考确认首次拒绝由320 K table边界造成；86个可重建记录已恢复，98个缺失输入，不能满足全部184点门槛。日期2026-10-05。

## 2. Exact failed candidate

SR1 cell24：P2=+9.0196079636474302e−22、mG=13.869723487241057、mL=6.4254079426687836e−19、rhoL=712.38217542998609 kg/m³、Eint=4325279.2929416951 J/m³。exact_first_bitcheck.json验证从保存anchor/face/记录dt单cell表达式重建的12字段binary64全部一致；未推进TemporalState/PDE。旧bracket与两端负残差使用封存SR1 query原值，未修改或换参考零点。

## 3. Current v1 limiting boundary

v1共同压力bracket [399968.12647470122,3232891.4142302852] Pa，上端由该rhoL在TL=320 K的液体边界限制，远低于全局12 MPa p上限。fLo=−7460692.4881426226、fHi=−114938.15962614212 J/m³。R1在迭代前正确拒绝无域内根，不能称为R1 root algorithm bug。

## 4. Required common pressure

独立FULL残差reference求根 p*≈3273273.8951882571 Pa。65个实际冻结JANAF eG(p)查询，9点degree5单JANAF分支表示、56点holdout；最大eG误差2.91038e-10 J/kg，估计pressure贡献≤1.75505e-09 Pa。liquid用独立CoolProp HEOS rho,p→T/e，60位decimal求和/二分，保留mL eL；没有把trace设ABSENT。

60位仅减小离线求和/根算术误差，不提高CoolProp/native binary64或reference-EOS的物理准确度。independent_common_reference_root.json保留数值精度/误差边界。该独立根约高于v1 pHi 40.38 kPa。

## 5. Required liquid temperature

TL*=320.0472350234204 K，约高于320 K **0.047235 K**；rhoL=712.38217542998609，eL_solver=44508.505801134568 J/kg，betaL=0.0021774322906333685，cL=1170.229442900908 m/s。独立reference物性与frozen-gas共同根；TG约818.383686 K。不是拿gas TG作为liquid TL。

## 6. Rejected-state T envelope

已知86点：shadow TL [320.00000000000358,320.04723502284918] K；独立reference TL [320.00000000057742,320.04723502341926] K。完整184点maxTL **UNKNOWN**；不能把已知最大值伪装为全体envelope。EOS_REQUIRED_DOMAIN.csv共184行，缺失98行明确MISSING_ANCHOR_Q而非省略。

## 7. Rejected-state p envelope

已知86点 requiredp [3273273.8951882557,3273744.2860372164] Pa，rhoL [712.38217542998609,712.41859059982926] kg/m³。未知98点全局p/rho范围OPEN。

## 8. Accepted-state envelope

M6B.0十个final Q控制、M6B.1十五个正常退出case的initial/latest、SR1 A/B/C+latest137，共5200合法状态已配对v1/v2 recovery。p [99999.999999999971,3299974.4143263092] Pa、有效TL [286.4375643909226,320.00000000000335] K、有效TG [299.99999999999994,820.28550168664106] K。无新增invalid。

accepted106/107未保存完整Q，无法只靠事件CSV提取；这些邻域仍缺失。未从anchor105推进PDE补造106/107。states_manifest.json记录每行出处；不存在把旧未运行case当作通过。

## 9. Pressure extension needed?

已评估状态无需扩大p，均在0.05–12 MPa内。shadow保持原HARD p；未知98点尚不能给全体无扩p必要的最终认证。

## 10. Temperature extension needed?

首次和86已知点确认需要覆盖320 K之上，reference有效；v1域不足。全体最大需求和margin选择尚不闭合，不确定最终Tmax。

## 11. Candidate domain

**ndecane_gibbs_v2_candidate：PROVISIONAL SHADOW ONLY**。NORMAL仍0.1–8 MPa、295–305 K；候选HARD为0.05–12 MPa、285–330 K。330/350/400三个选项均做参考grid比较，均通过原TABLE-B BUFFER物性预算。330是测试选项中最小，距已知最高TL约9.95 K，有显式余量且远离critical/saturation；不是320.0001机械扩边。

这仍是部分证据支持的提案，不是完整184 envelope下的最终设计选择；不认证production/high-Mach实际长期温度范围。

## 12. Candidate table construction

不refit：沿用同一degree8×8 Gibbs potential与81原系数，以及从同一potential解析生成的导数数组；将其continuation在新的有限HARD域内独立资格测试。没有runtime超域查询，也没有拼接两个panel。

候选header/metadata/coefficients各在独立目录；活跃factory仍ndecane_gibbs_v1。shadow-recovery副本仅注入候选EOS、为pressureInterval使用候选Tmax，R1 residual/derivative源码与原版一致。未改变P2、gas、Allaire、KT、reconstruction或temporal-driver公式。

## 13. C_L status

C_L=369229.9537234281 J/kg binary64保持；e_solver=e_native+C_L、h_solver=h_native+C_L。原系数未refit，未调能量零点。候选coefficients.json逐字节同v1，候选构造默认生产offset值同原类。

## 14. Old-domain error

61×61=3721个原HARD p/T格点：native直接PT rho/e/h/beta/c查询ptMismatch=0，maxE/H/beta/c difference均0；原NORMAL包含在其中。保持同potential同运算，不声称所有反演API bit parity。

反演rho,p→T最大自误差1.53477e-12 K；rho,e→p最大自误差3.61446e-06 Pa；newInvalid=0。5200合法历史recovery old/new maxΔp=3.01143e-06 Pa、maxrelativeΔp=9.19931e-13、maxΔTG=7.52834e-10 K、maxΔTL=3.9222e-12 K。不是失控refit。

## 15. Extension-domain error

每选项61×41=2501个参考点，p完整0.05–12 MPa，T分别320–330/350/400 K。密度、e/h、Cp/Cv、beta、c、dp/de|rho、dp/drho|e均检查；使用原m6a1b2b_config.json预定义BUFFER预算，无放宽。

| Quantity, extension 320–330 K | Max absolute error | RMS absolute error | Max relative error | RMS relative error |
|---|---:|---:|---:|---:|
| rho | 1.4094792e-07 | 2.4927547e-08 | 1.9826893e-10 | 3.5142986e-11 |
| e | 0.00020557252 | 5.4605998e-05 | 6.7160389e-10 | 1.7867781e-10 |
| h | 0.00020401535 | 5.470805e-05 | 7.0531983e-10 | 1.8446818e-10 |
| c | 0.00016137468 | 2.2633804e-05 | 1.3529407e-07 | 1.9563782e-08 |
| Cp | 7.7345268e-05 | 2.3522577e-05 | 3.3597658e-08 | 1.0211789e-08 |
| Cv | 0.00018488648 | 3.0678849e-05 | 9.7019409e-08 | 1.6153326e-08 |
| beta | 7.5574701e-10 | 1.0483654e-10 | 3.3614451e-07 | 4.5858213e-08 |
| dpDe | 0.0001495118 | 2.0080421e-05 | 3.361444e-07 | 4.5858209e-08 |
| dpDrho | 0.38143056 | 0.052192553 | 2.7009883e-07 | 3.9104254e-08 |

误差是对CoolProp8 HEOS生成参考，不是实验误差。e/h相对误差以native DEF参考绝对值定义；加固定C_L后绝对误差不变，未用near-zero solver energy构造误导性相对误差。350/400完整分项在extension_accuracy.json。

## 16. Beta accuracy

beta=(de/dp)|rho从同Gibbs potential解析求导，与reference analytic partial derivative比较；最大/RMS误差见第15节。全部测试grid正有限。不是独立拼合Cp/rho相关式或数值任意体力参数。

## 17. cL accuracy

cL从Gibbs Hessian导出，reference speed_of_sound直接比对，完整误差见第15节；nativeexact首次cL=1170.2294431480332 m/s，reference1170.229442900908。未只验证pressure。

## 18. Continuity

v1与candidate使用一个相同全局polynomial，T=320 K不是panel接缝：g及所有解析导数C∞，e/beta/acoustic相关导数不存在人为jump；域分类边界改变不改变potential。旧直接PT bit parity支持值一致。反演不同搜索区间的浮点微差已量化，不能误称inv API全bit相同。

## 19. Exact candidate recovery

使用shadow、冻结R1：p=3273273.8951882557 Pa，TG=818.383685729842 K，TL=320.04723502284918 K，iterations=5，normalized residual=1.0766039734535505e-15，通过原energy/pressure容差；cL=1170.2294431480332、cA=564.61173096386119 m/s均正有限。Q/P2完全相同，没有phase删除、floor、clamp、normalization。v1同输入仍NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN。

## 20. 184-state classification

3 main +83 probe =86点 **RECOVERED_WITH_EXTENSION**，STILL_NO_ROOT=0、OTHER_DOMAIN_FAILURE=0（仅已知输入集合）。剩余3 main+95 probe=98点 **MISSING_ANCHOR_Q / UNTESTED**，不能写成恢复或domain failure。

缺失anchor steps106/107/108；日志仅有step/cell/dt/exception而没有完整Q/P2/face。A105/B132/latest137允许冻结单cell表达式重建86已记录candidate；不更新任何accepted state、时间或PDE。其余98无法按本轮禁令补齐。all184 classification gate仍OPEN。

## 21. Pure-liquid regression

既有M6B.0纯液体+M6B.1纯液体initial/latest全通过。扩展控制p=.1/3/8/12 MPa，TL=300/320/325/330 K，U=(47,0,0)含纯液体：16/16 PASS。只做单态R1，不推进case。

## 22. Mixed regression

alphaL=.1/.5/.9，三种各16个扩展控制，共48/48 PASS；既有各M6B.0/M6B.1混合状态pair recovery无新增失效。无需换common-velocity/common-pressure模型。

## 23. Trace regression

P2=+1e−20 traceL 与−1e−20 traceG，各16控制，共32/32 PASS；既有trace控制保留并恢复。正/负zero pure-phase分别测试。trace质量未删除，phase presence判断/R1公式未改。

首次控制生成器漏初始化My/Mz导致错误测试输出，initial_control_fixture文件保留；只修测试生成器给定U=(47,0,0)的明确零值，未调模型/参数/容差。最终112/112 controls PASS，初始错误不作为模型证据。

## 24. Sound-speed validity

全部候选reference grid cL、Cp/Cv/beta及导数符号合法；5287条shadow recovery正有限cA，有液体时cL正有限（absent输出marker0不当物理声速）。112控制包括混合与trace；没有runtime cL/cMix field activation。未给未定义阈值强贴PASS：cA这里为finite-positive资格；reference cA精度完整全域专项没有伪造结果。

## 25. Physical liquid validity

首次TL≈320.047 K、p≈3.273 MPa，reference饱和压≈736.18 Pa，T明显低于Tc≈617.699 K，仍是稳定压缩液态branch。CoolProp对p>pc且T<Tc标supercritical_liquid；不能误读为气态或T超临界。三个扩展参考grid也检查对应branch为liquid/supercritical_liquid，无phase forcing/flash切换。

CoolProp n-decane model为Lemmon–Span 2006 reference EOS（DOI10.1021/je050186n）；来源：[CoolProp官方n-Decane文档](https://coolprop.org/fluid_properties/fluids/n-Decane.html)。本机报告backend边界Tmin243.5 K/Tmax675 K/pmax800 MPa，仅为backend validity，不等同全域实验精度认证。仍只用single liquid branch，不加phase-equilibrium模型。

## 26. Root-cause class A–D

**CLASS A / ARTIFICIAL_TABLE_DOMAIN_LIMIT（首次与86已评估记录）**。独立reference存在有效液态支撑，原320 K切断需要的root；非R1算法bug。98个未评估状态保持UNRESOLVED，不能把CLASS A结论外推为184全体证书。没有证据证明CLASS B/C true model limit。

## 27. Whether v2 justified

版本设计选择 **B / extension justified for studied states**，候选330 K已有物性与recovery证据；完整qualification尚未通过。不得安装/冻结成active v2，也不得以B设计证据提升EOS1 COMPLETE。candidate coeff/header SHA及部分资格JSON可复核。

## 28. Any source changes

所有新代码仅tools、tests/fiveEqEOS1Extract与独立stage/shadow_recovery。现有active求解器、factory、v1、R1、P2、temporal策略等无变化。shadow副本只改liquid evaluator注入与domainTmax；其余冻结编译源逐字節比对。没有动态solver运行、EOS2、时间修复或其他M6B.1case。参考EOS仅在离线Python，native候选不调用CoolProp。

## 29. Foundation hashes

本轮 fresh Foundation6717 / nativeparcel19 SHA全部PASS，原本机OF7；没改FOAM_SRC。日志在stage。

## 30. Project hashes

冻结基线34234项应全部一致（授权status history append之前）；实际checked项见project_verification.json，数值源与active factory不变。shadow_source_verification.json比对R1/gas/driver原字节；候选文件SHA如下。

coefficients.json SHA256 `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`

header SHA256 `d01111a65603901e986ed2aca8ec0d8cf30e1b00353e56c10abd2e68d21af93e`。

## 31. EOS1 COMPLETE?

**NO — PARTIAL。** 未满足all184 survey/classification、accepted106/107邻域及全体design envelope。即使现有数值测试均通过，也不能称DESIGN QUALIFIED。Missing-data inventory明确98条所需完整anchor Q/P2（steps106/107/108），以及这两个accepted邻域；没有偷偷重放PDE。

## 32. Next permitted action

本轮STOP。下一轮需先单独授权补全捕获证据（保持v1、原case/算法/时间策略，测试专用读取失败candidate与anchor），或提供缺失完整Q/P2；再按本轮offline资格工具评估98点与邻域并完成final envelope。EOS1未COMPLETE，**EOS2安装前置条件不满足**。时间修复TD1、剩余网格、高速/2D/production/DPM均不允许进入。

## 33. M6B.1 status

仍PARTIAL / STOP。首次320 K边界原因得到确认并有shadow可行提案；时间继承/representability完全未修复。M6B.1完整动态资格仍未闭合。

## 34. Milestone matrix

| Milestone | Status |
|---|---|
| M6B.0 | COMPLETE / FROZEN |
| M6B.1-SR1 | COMPLETE / DIAGNOSIS ONLY / CLASS F |
| M6B.1-EOS1 | PARTIAL / missing184 capture evidence |
| ndecane_gibbs_v2_candidate | SHADOW / NOT ACTIVE / NOT PROMOTABLE |
| EOS2 / TD1 | NOT EXECUTED / prerequisite unmet |
| M6B.1 / M6B | PARTIAL / STOP |
| T4-S1 / T4-S2 | COMPLETE / FROZEN |
| T4-S3 | DEFERRED / NOT CERTIFIED |
| M8A | PARTIAL |
| active DPM / production CFD | NO |

**STOP.**
