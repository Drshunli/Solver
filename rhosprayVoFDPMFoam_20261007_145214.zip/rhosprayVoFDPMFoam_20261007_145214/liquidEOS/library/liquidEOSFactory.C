#include "liquidEOSFactory.H"
#include "../ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H"
namespace liquidEOS {
std::unique_ptr<rhosprayLiquidEOS> makeProductionLiquidEOS(double offset){
    return std::unique_ptr<rhosprayLiquidEOS>(new GibbsPotentialLiquidEOSV3(offset));
}
const char* productionLiquidEOSVersion(){return "ndecane_gibbs_v3";}
}
