# Accepted standalone liquid EOS API

Version: ndecane_gibbs_v1. Foundation OF7 adapter/runtime connection NOT implemented.
SI units: Pa, K, kg/m3, J/kg; Cp/Cv in J/(kg K), c in m/s.
The default GibbsPotentialLiquidEOS constructor uses the frozen production C_L.
Explicit energyOffset=0 is native-reference validation mode only.

Unified immutable state queries: evaluatePT, classifyRhoP, evaluateRhoP, recoverRhoE.
Convenience accessors: e,T,c,deDpRho,pFromRhoE,rhoFromPT,Cp,Cv.
LiquidEOSState returns p/T/rho/e/h/Cp/Cv/c/beta, pressure derivatives, validity,
iterations and residuals. EOSQueryError contains reason, queried rho/p/T and model.
Use ONE evaluateRhoP state per phase/root iteration and reuse its properties.
All six potential derivatives share one local PT basis; Newton iterates recompute
their local basis as needed. No global, cross-cell, thread or MPI state cache.

NORMAL p=0.10–8 MPa, T=295–305 K; HARD p=0.05–12 MPa, T=285–320 K.
rho,p validity uses THIS model's cold/hot density curves, never reference curves.
Production initialization uses THIS model's rho(p,T) and sensible e(p,T).
Conserved-state intrinsic liquid density is mL/alphaL in the future five-equation
solver, tested against R_MODEL. Pure-phase limits must avoid pathological m/alpha.
No clamps, fuzzy thermodynamic domain, CoolProp fallback or runtime extrapolation.
No common-pressure mixture solve, flux, source, parcel transfer or mesh is present.

Acceptance uses direct cross-EOS properties at matched PT and model-generated
self roundtrips. NORMAL/interior cross-inverse remains mandatory. Exact reference
boundary-image inclusion is diagnostic under the explicit user semantics correction.
Reference EOS approximation acceptance is not experimental or CFD validation.
The two native cost budgets use warm mean per call and mean scalar-loop batch,
as in the original frozen benchmark contract; maxima remain reported and are
not realtime guarantees. Current standalone measurements exclude CFD overhead.
