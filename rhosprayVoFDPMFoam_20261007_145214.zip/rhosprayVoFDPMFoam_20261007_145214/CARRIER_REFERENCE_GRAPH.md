# M8A.3B-T3A carrier reference graph

Scope: passive serial native-OF7 harness; fixed topology and explicit owner-Q test boundaries. This is not production carrier activation. Original OF7 files were read from `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src` and retained, with their original relative paths, in `fitting/dpm/m8a3b_t3a_v1/native_sources`.

## Authority and lifetime

`Q = {P2,mG,mL,M,Et,mYi}` is the only Eulerian authority. Recovery uses Q and the frozen EOS, never the existing registered carrier fields. `rhoG,p,TG,YG,U,Cp,mu,kappa,he,psi,alpha` are derived views.

The mesh, native `psiReactionThermo`, `SLGThermo`, rho and U live outside both cloud roles and outlive them. `StableCommittedCarrierView` manages their contents; it owns only the additional diagnostic `carrier:Cp` and `carrier:kappa` fields. Cloud role A/B own parcels/models/source buffers, not these stable carrier objects. Immutable species and liquid property objects remain shared.

## Actual field paths

| Property | Native ownership/reference | Native parcel query | Refresh contract |
|---|---|---|---|
| rhoG | Harness stable rho; `KinematicCloud::rho_` const reference | `KinematicParcel::trackingData::rhoInterp_` | Intrinsic gas density from accepted Q, never mixture density |
| U | Harness stable U; `KinematicCloud::U_` const reference | `UInterp_`, configured `cellPoint`; wall `patchData` | M/(mG+mL); stable internal and boundary storage |
| mu | `psiThermo::mu_`, registered `thermo:mu`; `mu()` returns a borrowed tmp; cloud base retains reference | `muInterp_` | Native Sutherland mixture evaluated at accepted p/TG/YG |
| TG | Native thermo T; `ThermoCloud::T_` const reference | `ThermoParcel::trackingData::TInterp_` | Accepted gas temperature, not TL or mixture T |
| p | Native thermo p; `ThermoCloud::p_` const reference | `ReactingParcel::trackingData::pInterp_` | Frozen common-pressure recovery from Q |
| Cp | `heThermo::Cp()` computes a new field from `cellMixture/patchFaceMixture` | Thermo trackingData owns Cp_ copy and CpInterp_ | New trackingData each native evolve/query; no retained old Cp copy |
| kappa | `heThermo::kappa()` creates Cp()*native alpha_ field | Thermo trackingData owns kappa_ copy and kappaInterp_ | Publish native alpha_=alphah(p,T,Y), then reconstruct trackingData |
| Y | Native composition fields; `SLGThermo` references carrier thermo | Reacting composition accesses carrier Y; mixture recomputes from Y | Runtime species order, N−1 independent plus residual last; no normalization/clipping |
| he | Native thermo sensibleInternalEnergy field | Native thermo/transport object graph | Recovered gas sensible e; do not call thermo.correct to reinvert T |
| psi, alpha | Native `thermo:psi`, `thermo:alpha` registered fields | Density/transport paths | Derived native coefficients published with p/T/Y |

Source locations: `lagrangian/intermediate/clouds/Templates/{KinematicCloud,ThermoCloud,ReactingCloud}`, `lagrangian/intermediate/parcels/Templates/{KinematicParcel,ThermoParcel,ReactingParcel}/*TrackingDataI.H`, `thermophysicalModels/basic/{psiThermo,heThermo}`, and `thermophysicalModels/reactionThermo/mixtures/multiComponentMixture`.

## Actual eight-model graph

| Model | Carrier and other references | Lifetime/cache behavior |
|---|---|---|
| coneInjection | Cloud owner, mesh/time, root RNG, immutable input functions; pressure-driven option uses owner.pAmbient(), parcel rho | Fresh owner-bound model plus frozen typed mutable-state import; selected fixture uses constantVelocity. pAmbient is model input, not local common-pressure field |
| stochasticDispersionRAS | Owner mesh registry turbulence model selected by U.group(); k/epsilon pointers, owner RNG | `DispersionRASModel::cacheFields(true)` in preEvolve, false in postEvolve. Turbulence solution itself is an external prescribed field in this passive harness |
| sphereDrag | TrackingData carrier values/Re and muc argument | `calcCoupled` uses supplied current muc, parcel rho/d; no private carrier field copy |
| blobsSheetAtomization | Owner/injector and update arguments including gas averaged density and relative velocity | Carrier arguments supplied through current parcel/TD path; mutable history retained on parcel |
| ReitzKHRT | Owner.averageParcelMass(), update rhoc/muc/Urel, parcel history | Current TD-derived arguments; no private gas volField copy. Child/retry transaction remains T3 work |
| ORourke | Owner mesh/parcel occupancy/RNG and immutable liquids reference | Collision refresh calls parcel.setCellValues(owner,td); liquid properties use td.pc(). Collision retry remains T3 work |
| standardWallInteraction | Owner.patchData, parcel U, immutable wall coefficients, mutable counters | Static fixed-value wall path can read U.oldTime(); see contract below |
| voidFraction | Owner mesh/time and model-owned cloudNameTheta | Computes native parcel trajectory-time diagnostic. It is not alphaL, alphaG, gas support authority, or a carrier density. Persistent output promotion remains T3 work |

Model source files are retained under the original `lagrangian/{intermediate,turbulence,spray}/submodels` paths in the native-source archive. No system library was edited.

## Interpolation cache and event publication

`interpolationCell` borrows the volume field. `interpolationCellPoint` owns a **const point field psip_** evaluated at construction; old interpolation instances cannot refresh it in place. Its constructor calls `volPointInterpolation::interpolate(vf,name,true)`. Actual OF7 `volPointInterpolate.C` checks `pf.upToDate(vf)` and deletes/recomputes the registry cache when the volume-field event is newer.

Prepare reserves a new mesh event. Publish assigns that event through the actual mutable `regIOobject::eventNo()` reference. Next native evolve constructs new trackingData/interpolators; new point caches are compared with an independently constructed **cache=false** native point interpolation. Old trackingData, including scalar Cp/kappa copies, is generation-invalid and must be destroyed before reuse.

Harness-only dictionary interpolation-factory specializations wrap native cell/cellPoint calls with generation assertions; the native word factory, interpolation weights and equations are unchanged. This is not a production runtime-selection modification.

## Boundary and oldTime contract

All known nonempty test patch values are staged from explicit owner-cell Q; empty patch storage is retained. Dimensions, patch types/layouts, registered identities and data addresses are checked before publication. No `correctBoundaryConditions()` callback is allowed inside publication. The future nozzle and any dynamic/prescribed production wall treatment remain **FUTURE_PATCH_DEPENDENT**.

Actual `KinematicCloud::patchData` reads current and U.oldTime() wall values only for a nonmoving wall whose velocity patch fixesValue(), interpolating them by parcel.currentTimeFraction(). No old-old-time DPM access was found in the audited selected graph. The harness preallocates U_0 and explicitly publishes the same frozen Qn carrier velocity to current and old slots; throughout the following n→n+1 trial both describe Qn. This freeze contract is specific to the carrier view; it is not a new Eulerian time-discretization convention or proof for moving walls. The test U uses zeroGradient, so fixed-value wall execution is source-audited rather than dynamically validated.

## Publication primitive verified in local OF7

`GeometricField::primitiveFieldRef()` and `boundaryFieldRef()` call setUpToDate/storeOldTimes and offer no bool suppression overload. They are therefore called only during view construction, where mutable scalar/vector slot addresses are cached and U_0 is allocated. Publication uses bounded element writes through those prepared addresses plus mutable timeIndex/eventNo references; no field assignment/transfer, registration, oldTime creation, EOS call, boundary callback, or point interpolation allocation occurs after the first committed write.

Serial observers are excluded for the entire field publication plus cloud/Q role-pointer swap. New trackingData is allocated only before the **next** trial/evolve/query, when the already accepted coherent state exists. Failure to create next-step trackingData is a next-step failure, not a rollback of the committed physics. This provides logical serial atomicity under the explicit harness contract; it is not MPI/thread/hardware atomicity.
