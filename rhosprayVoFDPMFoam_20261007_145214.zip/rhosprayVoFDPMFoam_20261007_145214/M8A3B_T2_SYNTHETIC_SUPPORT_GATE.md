# M8A.3B-T2 Synthetic strict carrier-support gate

2026-10-01。证据目录 fitting/dpm/m8a3b_t2_v1。
所有几何均标记 **SYNTHETIC SUPPORT TOPOLOGY**，不是 CFD 初始条件或运行结果。

## 1. M8A.3B-T2 status

**COMPLETE / STRICT-SUPPORT FEASIBLE**，限本轮 serial 合成 Mapping-A 气相侧几何门槛。
future inlet patch 的未知边界贡献保持 FUTURE_PATCH_DEPENDENT，不计入 full认证。
没有证明生产边界、实际 parcel trajectory 或完整事务合法性。

## 2. All-gas baseline

21000/21000 cells 的 rho/p/T/Cp/mu/kappa/species、U及full支撑通过。
一个连通合法分量，远场边界不合法单元为零。
无 SUPPORT_IMPLEMENTATION_BLOCKER。

## 3. Ideal Mapping-A geometry

x=[14.2931416529423,15.7068583470577]mm，y=[0,L]，z覆盖50μm。
中心x=15mm、方向+y，严格使用理想连续边缘，不采用28/30面近似。
长度L=0.3/0.6/1.5/3.0mm；L/Dphysical=1/2/5/10，L/w2D=
0.2122065908/0.4244131816/1.0610329539/2.1220659079。

## 4. Cell geometric-fraction method

实际mesh cellPoints建立axis-aligned cell bounds；全部21000个bbox体积与native
mesh.V一致（相对容差1e-10）。alphaL=overlapX*overlapY/(cellDX*cellDY)，
整单元包含时精确指定1，无重叠指定0，其余保留mixed。
不按中心阈值赋相；每场ΣalphaGeom*V与w2D*L*bz一致。
距离统计使用单元中心，**相分配不是中心阈值**。

## 5. P2 construction

P2 signed-minority为authority；sharp气相/液相含精确零，mixed正常PRESENT。
TRACE通过minority(1e-20,true,P2)直接存入−1e-20；mG不从1−decoded alphaL获取。
CSV保留原始P2 payload，pure-liquid −0不会被重新解码生成gas。

## 6. EOS-consistent state construction

共同压力p=188330.307Pa，TG=400K，TL=300K。gas Y={C10H22:0,O2:.228,N2:.772}
来自冻结测试/actual case组成，rho由Foundation7 JANAF/perfectGas计算，
不是强行使用nominal rho∞=1.6338。
生产ndecane_gibbs_v1液相使用同一p和TL，避免mixed cell两相压力不一致。
参考rhoG=1.632685900112、rhoL=725.160516600440kg/m³，CpG=1023.251901151819，
muG=2.344071550733e-5Pa·s，kappaG=.034703071017W/(m·K)。
mu/kappa来自本机OF7 sutherlandTransport和actual thermal.dat；不猜物性。
3MPa仍为喷孔参考状态，本轮不是该入口边界实现。

每个P2精确值由冻结PrecisionReconstruction构造mG/mL/M/Et/mYi，op.recover验证。
25种精确重复状态缓存复用已验证Q/恢复/物性结果；每个单元与每个边界实体
均处理，非sampling或truncation。exact gas-absent不查询gas物性。

## 7. L/D=1 result

Sharp：gas-present20664，full认证20608，已知stencil排除54。

## 8. L/D=2 result

Sharp：gas-present20552，full认证20488，已知stencil排除62。

## 9. L/D=5 result

Sharp：gas-present20160，full认证20068，已知stencil排除90。

## 10. L/D=10 result

Sharp：gas-present19320，full认证19168，已知stencil排除150。

## 11. Sharp-interface summary

|场景|纯气|几何mixed|纯液/GAS ABSENT|TRACE|scalar合法|full认证|已知stencil排除|仅future未知|
|---|---|---|---|---|---|---|---|---|
|ALL_GAS|21000|0|0|0|21000|21000|0|0|
|L1_SHARP|20610|54|336|0|20664|20608|54|2|
|L1_TRACE1|20610|54|286|50|20714|20660|50|4|
|L1_TRACE2|20610|54|240|96|20760|20708|46|6|
|L1_TRACE3|20610|54|198|138|20802|20752|42|8|
|L2_SHARP|20490|62|448|0|20552|20488|62|2|
|L2_TRACE1|20490|62|390|58|20610|20548|58|4|
|L2_TRACE2|20490|62|336|112|20664|20604|54|6|
|L2_TRACE3|20490|62|286|162|20714|20656|50|8|
|L5_SHARP|20100|60|840|0|20160|20068|90|2|
|L5_TRACE1|20100|60|754|86|20246|20156|86|4|
|L5_TRACE2|20100|60|672|168|20328|20240|82|6|
|L5_TRACE3|20100|60|594|246|20406|20320|78|8|
|L10_SHARP|19200|120|1680|0|19320|19168|150|2|
|L10_TRACE1|19200|120|1534|146|19466|19316|146|4|
|L10_TRACE2|19200|120|1392|288|19608|19460|142|6|
|L10_TRACE3|19200|120|1254|426|19746|19600|138|8|

所有pure-liquid core GAS ABSENT/DPM-invalid属预期，不计入气相排除带。
mixed状态自身合法，可能因U stencil触及别的pure-liquid单元而受限。

## 12. TRACE1 summary

从与mixed/gas邻接的pure-liquid内侧开始，按actual internal-face adjacency
向内取1层，仅用于buffer层数，不替代真实插值贡献。
四长度已知排除50/58/86/146，均位于core内部TRACE层；外部gas/mixed的
已知排除变为0。边界未知仍独立保留。

## 13. TRACE2 summary

取2层，已知排除46/54/82/142，外部非TRACE已知排除0。

## 14. TRACE3 summary

取3层，已知排除42/50/78/138，外部非TRACE已知排除0。
trace stress仅敏感性诊断，不是数值扩散模型、生产建议或人为气相创建。
内部trace到原几何边界距离增加，表示排除区向内移动，不表示外部带增厚。

## 15. Scalar carrier-support result

rho/p/T/Cp/mu/kappa/species逐项有限/正值/组成和检查，native cell路径只读own cell。
各项合法计数等于表中scalar合法；本轮gas自身合法时scalar-only排除带为零。
CSV七列属性旗标分别输出；不把mixture density作为parcel gas carrier density。

## 16. U cellPoint support result

复用冻结NativeSparsePointSupport；全native非零tensor分量，不平方小权重。
实际cache覆盖63620候选实体，动态存储，无256上限。
whole-cell union是每个cell全部tet位置的充分支撑条件，不是中心点抽样；
所有中心/点原生对照及独立basis再次通过1725880项，max差3.84593e-16。
TEST点另用实际cellPointWeight得到其精确位置stencil。

## 17. Full DPM-support result

full认证=own scalar合法+全部cell-wide非零U贡献gas合法+无未知future boundary。
本轮U认证计数等于full；表中full失败可为确定invalid或future未认证，不能混淆。
无法证明完整production carrier实现，证明的是指定静态reference拓扑支撑。

## 18. Exclusion-band cell thickness

排除带只含gas合法且已知stencil触及GAS ABSENT的cell。
以法向分组排除行数、从core-overlap出发的face图层数和中心距离/dx、/dy分别统计。
Sharp侧面1行（L2角部按分组最多2行），tip1行；完整纯气行最多离开core-overlap
1个face层。cut mixed本身计为0层，因此图层数不能冒充排除行数。
corner另列，避免把斜向距离冒充横向带厚。详见analysis JSON。

## 19. Exclusion-band physical thickness

|Sharp L/D|min/median/P95/max (mm)|侧向外侧包络(mm)|tip外侧包络(mm)|侧向/tip最大排除行数|
|---|---|---|---|---|
|1|0.0181416529/0.0234390942/0.0234390943/0.0234390943|0.0431416529|0.001828251|1/1|
|2|0.0181416529/0.0181416529/0.0411640437/0.0411640437|0.0431416529|0.0063104855|2/1|
|5|0.0181416529/0.0181416529/0.025/0.030888826|0.0431416529|0.05|1/1|
|10|0.0181416529/0.0181416529/0.125/0.126309618|0.0431416529|0.25|1/1|

上表min/median/P95/max为全部确定排除单元中心到最近矩形边界的无符号距离。
cut-cell中心可能在core内部；另给bounding-box在gas侧最外延伸，二者不能互换。
距离图保留每cell的mm、local width和归一化值；TRACE内部/外部统计分开。

## 20. Lateral-core result

Sharp普通侧面中心距离约0.018141653mm，gas侧bbox最大延伸0.043141653mm。
L2角部会增加局部混合区域的统计距离，仍为局部限制，非全域不合法。
外部合法component可接近侧面，未发现非局部限制。

## 21. Core-tip result

Sharp tip外侧bbox包络随网格：L1=.001828251mm，L2=.0063104855mm，
L5=.05mm，L10=.25mm。L1/L2的tip cut cell包含大部分液体但少量gas，
不能用该薄包络代替中心距离。L10 tip上方dy=.25mm，不是side的50μm。
没有宣称tip本身必须放parcel；下游合法纯气component真实存在。

## 22. Near-wall result

near-wall定义为y0=0的wall-adjacent cells，非事后指定物理厚度阈值。
基准各场32cell的whole-cell stencil涉及理想future nozzle边界；shift为31。
其中部分已因自身pure-liquid或已知cell贡献不合法，部分仅future未认证。
gas仅future未知：sharp2，TRACE1/2/3为4/6/8。不能将未知编成gas或liquid。
已知非nozzle边界使用owner gas状态；本场这些owner为gas-valid。
bottom/top/inlet/outlet贡献保留；empty候选42000但native非零贡献为0。
没有生成或改BC，未来nozzle原生插值/边界状态需activation重新核对。

## 23. Connected gas-valid region

|Sharp L/D|connected cells|最近pure-gas侧面中心距离(mm)|最近pure-gas tip中心距离(mm)|
|---|---|---|---|
|1|20608|0.0362733355|0.0314107513|
|2|20488|0.0644967224|0.0618927106|
|5|20068|0.0771629417|0.075|
|10|19168|0.0806416529|0.0844279349|

19场均有且仅有1个full认证连通分量，接触远场；远场边界不合法cells=0。
connectivity按actual internal faces；仅用于连通性，不作为interpolation近似。
表为pure-gas单元中心到有限侧面/尖端segment最近距离，不是parcel可连续移动证明。

## 24. Invalidity cause breakdown

已知gas侧排除均因native U footprint含pure-liquid cell，scalar本身无失败。
确定无气相boundary引用导致的gas侧失败为0；future nozzle贡献分类UNKNOWN，
没有删除该贡献，而使full不认证。refs为出现次数，不是unique contributor数。
property/EOS构造失败0；pure-liquid own scalar拒绝是正常phase分类。

## 25. TEST_DPM_INLET result

native含cell1514、位置stencil6实体。ALL_GAS合法；所有core/TRACE/shift场自身
为pure-liquid，scalar/U/full拒绝，属预期。该点是TEST_DPM_INLET，生产预算0。
未bounce/delete/relocate或把它认作production DPM喷孔。

## 26. Geometry-alignment sensitivity

只在L10_SHARP作x±25μm（half actual local wall dx）敏感性，不改变冻结center。
full从19168变19229；已知排除从150变149，farfield component仍唯一。
侧向外侧bbox包络从.043141653变.018141653mm；tip仍.25mm。
边缘对齐影响cut相分类与局部厚度，未改变结构性连通结论。

## 27. Future mesh-resolution implication

保持精确ideal slot边缘，在后续授权阶段一致分割面/单元；不选择28/30面替代。
近壁dx=50μm、第一排dy≈7.6188μm；L10 tip处dy=250μm导致更厚tip外侧排除行。
如需更近tip的DPM候选，应做独立mesh convergence/目标长度设计；无新经验阈值。
不修改mesh。Mapping-A只保留面积/mdot/参考速度及相应积分动量能量尺度，
不保留圆形截面、0.3mm平面内径或圆柱曲率/周长，不是3D物理验证。

## 28. Strict-support feasibility verdict

**FEASIBLE FOR TESTED SYNTHETIC GAS-SIDE SCOPE**。依据冻结结构准则：
native支持局部、已知排除局部化、与farfield连通的合法gas区域可接近side/tip。
未设置事后“Ncells以下PASS”。future nozzle-dependent region不在认证范围。
未来VOF→DPM候选必须落在合法carrier拓扑，或另定义初始化合同；本轮未转换。

## 29. Whether a redesign is required

本轮测试范围**不要求另立mixed-topology carrier redesign作为前置阻塞**。
不证明所有动态VOF/AMR/LES/parcel轨迹或其他EOS状态可用。
若未来目标要求在目前纯液体或确定排除区创建parcel，需另立设计，不mask/重归一化。

## 30. Whether transaction work may resume

T2几何可行性前置门槛通过，下一轮可恢复M8A.3B passive transaction工作。
本轮按STOP要求未继续cloud/Q、breakup/collision retry、MPI或输出提交。
这不是M8A总体COMPLETE，也不授权active integration。

## 31. Frozen regressions

M8A source/energy9288，M8A.3A A/B/C6375（各1000 lifecycle及10future steps），
全部0失败；32个energy/source冻结goldens字节一致。native对照1725880、0失败。
未修改frozen代码/语义，未将3A accepted-step scope升级为full transaction。

## 32. Active solver impact

NONE。仅新增tests/fiveEqDPMTopologySupport、offline分析工具、CSV/JSON与报告。
active source/Make、actual mesh/case及既有冻结证据不变；状态文件只追加。
最终wmake PASS；初版两个格式warning修复后重新编译并重跑。无CFD。

## 33. M8A overall status

PARTIAL。完整atomic commit、forced events、accepted output、MPI仍未闭合。

## 34. M6B.0 permission

NO；exact inlet patch及field/BC integration未实现，本轮不执行。

## 35. M6B.1 permission

NO。

## 36. Updated milestone matrix

|Milestone|Status|
|---|---|
|M8A.3A|COMPLETE / FROZEN serial scope|
|M8A.3B-T0|historical PARTIAL; design blocker resolved by T1|
|M8A.3B-T1|COMPLETE / DESIGN ONLY|
|M8A.3B-T2|COMPLETE / STRICT-SUPPORT FEASIBLE / synthetic scope|
|M8A.3B / M8A|PARTIAL|
|Native Eulerian nozzle patch / BC|NOT ACTIVE / future integration required|
|M6B.0|NO|
|M6B.1|NO|

STOP。未修改mesh/production BC，未继续transaction/MPI/M6B，未运行CFD。
