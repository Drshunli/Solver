# Flux ownership — active gas KT and future two-material KT (OF7)

## Current runtime

| Flux | Writer | Current role |
|---|---|---|
| `phi` | Main `.C`: `aphiv_pos*rho_pos+aphiv_neg*rho_neg` | Legacy gas KT **mass** flux [kg/s]; continuity, species and turbulence read it |
| `phiUp` | Main `.C`: directed `rhoU` plus gas pressure face force | Legacy gas KT momentum flux |
| `phiEp` | Main `.C`: directed gas total-energy/pressure flux | Legacy gas KT energy flux; moving-mesh pressure-work correction remains |
| `phiV` | Main `.C`: `aphiv_pos+aphiv_neg` | KT-derived **volume** flux [m3/s] for current VOF alpha transport only |
| `alphaPhi` | `alphaEqn.H` MULES; `alphaSubCycle.H` time average | Provisional liquid volume flux [m3/s], including advection, compression and limiter correction |

`phi`, `phiUp` and `phiEp` remain the only active KT flow-flux family until
M5C/M6B performs a unified switch. `alphaPhi` is not automatically a
five-equation material flux. Current `rhoMix` is diagnostic, and there is no
authoritative mixture mass flux or two-material wave speed.

## M5A active reference, not runtime

`m5aFluxDiagnostics.H` remains available for the KT/VOF mass-flux audit but
is not included in the current main loop. Its candidate `rhoPhiVoF` uses
limited alpha volume flux and interpolated phase densities; its candidate
`rhoPhiMix` uses legacy gas-derived KT wave weights. Neither candidate is a
valid drop-in replacement for the unified two-material KT flux. Their
absence at runtime is deliberate and does not mean M5A is frozen.

## Future authoritative two-material family

| Flux | Future conserved quantity |
|---|---|
| `F_mG` | Gas partial mass `mG` |
| `F_mL` | Liquid partial mass `mL` |
| `F_M` | Common mixture momentum `M` |
| `F_E` | Mixture total energy `Et` |

All four must be generated from the **same** left/right two-material states,
common pressure and velocity, calibrated phase EOSs, one `cMix` closure and
the same KT wave speeds. The material/interface transport for `alphaL`,
including sharpening or compression, must be derived alongside these fluxes
so it does not spuriously alter phase masses or energy. The M5B data contract
in `twoPhaseKTState.H` and `M5B_TWO_PHASE_MODEL.md` is an active design
reference; its flux evaluator is not implemented or used yet. M5C/M6B is
the planned unified activation point, with no partial replacement today.
