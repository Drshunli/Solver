# M6A1b-1 decision record

## Current authority — M6A1b-2A.3 (2026-09-30)

Overall **M6A1b-2A COMPLETE as a project domain/policy design gate**. Expected
physical screening is 0.188330–6.201421 MPa / 299.440696–301.200448 K;
approved PRODUCTION is **0.10–8 MPa / 295–305 K**; project HARD is
**0.05–12 MPa / 285–320 K**, absolute pressure and inclusive boundaries.
These design support limits do not predict guaranteed CFD extrema.
The former 0.180–6.250 MPa / 299–302 K proposal is historical and superseded.
See [current assessment](M6A1B2A3_ENVELOPE_HARDENING.md) and
[domain/failure policy](EOS_OUT_OF_DOMAIN_POLICY.md); the machine-readable
authority is `fitting/liquid_eos_domain_contract.json`.
M6A1b-2B is NEXT / NOT STARTED. Production model selection, final reference
training/holdout generation and solver energy-offset alignment remain open.
No active solver or CFD case changes were made.

## Historical audit (superseded status statements below)


Status: **MODEL GATE COMPLETE / OPERATING ENVELOPE INCOMPLETE**. Constant-parameter stiffened gas is **REJECTED as the final C10H22 liquid EOS** by the direct temperature-shape tests in [STIFFENED_GAS_ADEQUACY.md](STIFFENED_GAS_ADEQUACY.md). This is a structural decision, not a parameter fit. The overall transition to M6A1b-2B remains blocked.

## M6A1b-2A retirement decision

**constant-parameter stiffened gas = REJECTED FINAL EOS.** The compiled, uninstantiated `rhosprayLiquidThermo` remains a historical algebra/implementation prototype only. No tuning of `gamma`, `pInf`, `Cv` or `q` is an allowed route to its promotion. The next calibration model is **not** this class. Future generic `rhosprayLiquidEOS` and phase-masked reference-table/reduced backends are designed in [FIVE_EQ_LIQUID_EOS_INTERFACE.md](FIVE_EQ_LIQUID_EOS_INTERFACE.md) and [ALTERNATIVE_LIQUID_EOS_ARCHITECTURE.md](ALTERNATIVE_LIQUID_EOS_ARCHITECTURE.md); none are instantiated.

The reference architecture is selected: a versioned Helmholtz/reference-EOS truth layer and a separately validated production candidate layer. The *production* choice remains blocked: the user has supplied a gas state giving Ma≈5.02, while the earlier Ma>7 goal is unconfirmed, and the VOF liquid inlet p/T/U and fuel-hole count are absent. [OPERATING_ENVELOPE_M6A1B2A.md](OPERATING_ENVELOPE_M6A1B2A.md) records the supplied state and exact missing conditions. Old 0.1–10 MPa / 288–403 K screening ranges must not be promoted to final calibration bounds.

Blocking inputs: approved Eulerian liquid inlet p/T and thermal ceiling; per-state multi-pressure mechanical/caloric data or versioned reference-EOS export spanning the resulting liquid phase; declared gas–liquid–parcel absolute/sensible energy reference. The 0.1–10 MPa pressure screening scenario in [LIQUID_EOS_TARGET_RANGE.md](LIQUID_EOS_TARGET_RANGE.md) is not a verified upper bound for Ma>7. No active solver field or dictionary was modified and no CFD validation was run.

M6A1b-2B may begin only after the bounds are specified. It should generate a provenance-tagged Helmholtz/reference-EOS table, verify single-liquid phase and derivatives, compare with independent experimental rho/c/Cp, then select a compressible production EOS with `e(rho,p)`, `T(rho,p)`, `c(rho,p)` and M6A2 pressure-root derivatives. Energy-reference offsets remain a separate gate.
