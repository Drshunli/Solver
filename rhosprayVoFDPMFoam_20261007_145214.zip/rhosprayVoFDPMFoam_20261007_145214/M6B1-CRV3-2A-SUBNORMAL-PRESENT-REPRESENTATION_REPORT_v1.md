# M6B1-CRV3-2A-SUBNORMAL-PRESENT-REPRESENTATION REPORT v1

原step208恢复成功；新scalar-P2分数下溢与正质量表示不一致阻塞，2A未完成。

## 1. status

CRV3-2A INCOMPLETE / STOP。原 PRESENT_PHASE_SUBNORMAL_PRECISION_UNRESOLVED blanket guard 已闭合；新的 P2_FRACTION_UNDERFLOW_PRESENT_MASS_BLOCKER 与时间步量化锁定尚未闭合。

## 2. exact blocker reproduction

旧 binary 的 step208 精确锚点与旧 guard 复现证据沿用已封存 CRV3-2 v2 archive。本轮专项直接读取旧 td1_blocked_trial.csv：cell311 的全部 Q/P2 位保持不变，0006c53f55fe409f / 00933d154ab58a06 经新 recovery 通过。transport 运算次序修正后不要求新 trajectory 与旧 trajectory bit-identical；这与同一旧 state 恢复要求分开。

## 3. rho consistency

90 位 exact binary-input reference rhoL=727.432960545320632985535743654062670867247286479514355580688873803654886759515000966745357。36 组 scaled ratio 最大相对误差 7.39786e-17；构造目标 rho 与实际可表示 alpha*mass 的量化误差单独报告，未修改输入来消除该误差。

## 4. root cause

原 guard 将所有正亚正常数拒绝，不能代表热力学不一致。扩大表示范围后发现两个实现缺陷：非控制时间上限 binary64 溢出触发 SIGFPE；V*m 再除 V 损失亚正常有效位。均已按原数学公式修正。最终 scalar P2 指数范围仍不足，正 fraction 会先于 mass 下溢。

## 5. source delta

5 个已有源文件与 1 个新 ratio helper，另加 representation contract 文档。P2 presence 方法、scaled recovery、overflow-safe bound、固定网格 FMA Euler 运算。source_delta.json 有精确 before/after SHA。K/model EOS 文件、CRV3 viscosity、TD1 selection policy 未改。

## 6. P2 semantics

P2 仍是唯一 presence authority；+0 pure gas / -0 pure liquid；任意非零 signed minority 为两相 present。TRACE_PRESENT 仅诊断分类，没有阈值删除、floor、clip、normalize 或 mass matching。新帮助函数第一次测试发现 signed-zero 判定写反，已修正并完整重跑；旧 attempt log 保留。

## 7. scaled ratio implementation

normal operands 保留原 mass/fraction 运算；subnormal 用 frexp mantissa division + scalbn exponent difference。只缩放计算，不改 P2 或 Q。有限正 rho 才进入相 EOS，present trace 不走 pure-phase 分支。

## 8. subnormal sweep

9 个 alpha（minNormal 上邻/minNormal/下邻、minNormal/2、blocker、2^-1050/-1060/-1070、denorm_min）×4 rho=36 ratio/domain tests；两种 minority 的 18 个合法 EOS 状态及旧 blocker 共19 strict checks；40 P2 transition checks。rho600/800/1000 在该 frozen liquid EOS 无 admissible pressure interval，正确拒绝，不能用 representation support 绕过 EOS；rho727.4329605 admissible。完整 density_domain.csv 保留。

## 9. FTZ/DAZ audit

has_denorm=1，MXCSR=8098，FTZ/DAZ 均 false；denorm multiply/divide/scalbn 与 blocker load/store 检查通过。最终 fresh population_final 启用 FE_DIVBYZERO/INVALID/OVERFLOW，300 步无浮点陷阱。旧 step213 diagnostic restart 并非对应213的权威快照，只用于定位 FPE；不用于 trajectory qualification。

## 10. K/cPE

冻结 K/response/cPE 公式未改；native 19 个 trace/blocker state finite。90 位 liquid-minority/blocker K 与 response 检查通过原 MC3 budget；gas-minority native strict PASS，独立变组分 EOS reference 尚未完成。液相 denorm response 下溢属于算术舍入，不决定 presence；已测 liquid-minority K 未发生强制置零。

## 11. R1/EOS

R1 residual/derivative、EOS coefficients、domain 和 root tolerances 未改；present subnormal 仍调用 gas/liquid thermo。90 位 blocker 的 eL/betaL/cL/K/response/cPE 与 Rprime cross-check PASS；压力区间与 native R 保存在 thermo.csv。不能把 blanket guard 移除当成整个 EOS domain suite 已通过。

## 12. step208 replay

同一旧 trial state recovery PASS，旧 whole-anchor 新实现 cap native 800/800 PASS，viscous fixed component mismatch=0；固定-volume运算修正后的 fresh full solver 越过208和300。

## 13. step208->300

从同一 fresh fixture，最终 trapped 独立审计到step300，t=3.2989411996290971e-05，240000 strict checks，min root margin=3530739.32835。但 min selected dt=1.03249218887e-13，与 hyperbolic cap 比值 1.45896e+06；no new dt-collapse gate FAIL，故2A不能 COMPLETE。

## 14. subnormal population

最多9个亚正常present相；最后 integrated alpha=3.50221248473657264933e-312、mass=2.54762443051538895614e-309、phase energy=1.25272323751181631952e-306，rho extrema=703..727.433204785141811044。记录了每accepted step的 count、time/duration、min fraction/mass、R/Rprime、P2bits、K与bounds。sumAbsK 是 coefficient 指标，不冒充时间积分 K*divu source；完整 K-source 时间积分未计算。合法 tails 可归类 REPRESENTATION TRACE TAIL，但新零fraction/正mass trial 仍必须拒绝。

## 15. conservation

fresh full replay 停止前487步，global conservation max=1.14403e-15；hard budget 未用5%代替。uniform subnormal zero-net-flux 12状态所有Q/P2 bit exact PASS；FMA避免重复 V scaling 失真。

## 16. P2/species

P2编码/authority未改，所有已接受检查无 phase deletion；full replay N−1 closure max=1.71017e-16，viscous fixed mismatch=0。新cap trial精确拒绝 ABSENT_PHASE_HAS_MASS，未提交非法状态。

## 17. CRV3 heating/work

fresh336套 local heating min=0、entropy min=0；原 momentum tau 与 Et tau*u、work identity unchanged。population每步heating/entropy记录仍非完整shock entropy证明。

## 18. contact regression

fresh stationary/moving/thermal-alpha contact 压力误差 max=0.0871438203%（目标<1%、硬≤5%）PASS。

## 19. acoustic regression

fresh N32/64/128 × mu0/3/1000 共9组 analytical discrete Fourier/native strict PASS。

## 20. fixed-mu regression

fresh weak ratio1.05、mu3、N128/256/512、lab/stationary共6组native/strict/conservation PASS；保留既有网格误差趋势。该 native-reference subset 只作CRV3-1 regression，不当独立高精度VV资格。

## 21. joint dt

TD1 selection policy untouched，nonrepresentable-time exact rollback regression PASS。溢出非控制bounds显式返回既有+infinity语义。新full-cap witness下 fraction舍入0而mass正，selector仍可选择合法微步，不能声称所有dt失败；持续收缩来自表示限制，不能用删相解除。

## 22. restart

new model tag exact，亚正常P2、Q和signed zero write/read位级保存PASS，old/new identity cross-rejection fresh regression PASS。没有P2-v2 schema实现或restart migration。

## 23. CRV3-1 preserved?

YES，当前修改后fresh336 /53760 strict、contact、9 acoustic、6 shock subset与rollback通过。历史sealed executable及EOS库SHA保持不变。

## 24. CRV3-2A COMPLETE?

NO。原subnormal guard blocker closed；step300 reached；但是新表示下溢/temporal-collapse gate未通过，混合gas trace独立组分reference未完成。转入用户授权的 REPRESENTATION-V2 DESIGN ONLY。

## 25. CRV3-2 resumed?

NO。用户规定2A COMPLETE以后自动resume；其前提未满足，新hard表示阻塞触发STOP。本轮未执行VV ladder或CRV3-3。

## 26. hashes

source_before/after/delta.json、artifact_manifest.json、checkpoint_seal.json保存完整identity；新 executable SHA 4e7dd57774ae4a23e9212f5a461f38ea109bdc9773d32cf1af26ea497b24c718。sealed历史v1/v2证据没有改写。

## 27. milestone matrix

CRV3-1 COMPLETE/PRESERVED；CRV3-2A INCOMPLETE；Representation-V2 DESIGN ONLY；CRV3-2 INCOMPLETE；CRV3-3 NOT AUTHORIZED；M6B.1 PARTIAL。

独立step300 full-cap witness：cell300，ideal alpha=3.13177572030842521845393928141511598263426041795850814915202023314505410683375750844132940E-325，ideal mass=2.19977474620485232573400128632706430898092590365216770594382348942763767220785972976478283E-322，ideal rho=702.404942965779467680608365019011406844106463878326996197718631178707224334600760456273765，TL=333.156230224706195482904381429971778607194043300612420435857391978373687224630833656275284 K，EOS admissible=True；P2 bits=0，mass bits=0x000000000000002d。该结论只认证记录的离散候选，不是连续解证明。

