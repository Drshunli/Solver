# Generic state recovery and phase EOS APIs — M5B.1

Design specification only. `recoverFiveEqState` and `fiveEqAcoustics` below
are proposed interfaces, not existing compiled functions. No M6A2 root is implemented.

## Phase state interface

Gas: immutable `gasStateRhoP(rhoG,p,YG)` returns eG,TG,cG or cG^2,
deGdpConstRhoY, validity/domain class and diagnostics on a canonical energy
reference. Current OF7 psiReactionThermo/JANAF/sensibleInternalEnergy remains
the authoritative gas model. For its frozen-composition perfectGas case:

    TG=p/(rhoG*R(YG)); eG=Es(TG,YG)
    betaG=Cv(TG,YG)/(rhoG*R(YG))
    cG^2=(Cp/Cv)*p/rhoG.

Expose the corresponding EOS derivative/validity API for any other gas model;
do not assume perfectGas for every future dictionary. Candidate face/root
evaluation must not mutate the global thermo field or borrow mixture density.
JANAF validity intervals and mixture species normalization must be explicit.

Liquid: immutable `liquidStateRhoP(rhoL,p)` returns eL,TL,cL or cL^2,
deLdpConstRho, validity/domain class and diagnostics. statePT and stateRhoE
support initialization, assessment and pure-liquid inversion. This is a
future generic liquid EOS strategy, not activation of the rejected constant-SG
rhosprayLiquidThermo prototype. h=e+p/rho on the same reference.

Both phase APIs provide `stateValidity()` and NORMAL/BUFFER/INVALID. Gas has
its own declared validity, not the liquid temperature envelope. Liquid obeys
production 0.10–8 MPa / 295–305 K and certified HARD 0.05–12 MPa / 285–320 K.
The future accepted production EOS must certify BUFFER before evaluating it.
Existing EOS_OUT_OF_DOMAIN_POLICY.md remains authoritative.

## Recovery order

1. Validate finite Qc,alpha,YG, alpha boundedness, nonnegative partial masses,
   total rho>0 and phase-presence consistency before intrinsic density division.
2. Derive alphaG=1-alphaL, rho=mG+mL, U=M/rho,
   Eint=Et-|M|^2/(2*rho). Check energy subtraction conditioning.
3. Branch exact/near pure according to explicit alphaMin/massMin policy.
   Do not call absent-phase EOS or divide by absent alpha.
4. In a legitimate two-phase state obtain rhoG=mG/alphaG, rhoL=mL/alphaL.
5. On a connected joint EOS-valid bracket solve

       R(p)=mG*eG(rhoG,p,YG)+mL*eL(rhoL,p)-Eint=0
       R'(p)=mG*betaG+mL*betaL.

6. Recover TG,TL,cG,cL, selected cMix,K_L and final validity. Return no usable
   primitive state if any step fails.

Positive beta values imply R'>0 when masses are positive; uniqueness follows
on a continuous valid bracket, but root **existence** additionally needs the
energy to be bracketed. A safeguarded Newton method with bracket fallback is
the M6A2 design. Consistent numerical beta is permitted only with verified
accuracy and every probe inside the valid branch. No iteration may silently
clamp thermodynamic primitives or jump a phase/domain gap. A pressure bracket
inside liquid p limits alone is insufficient: recovered TL and gas validity
must also hold throughout it.

## Pure branch and residual handling

At exact absent liquid: gas EOS + conserved Et supplies p, gas species and
reference conventions preserved. At exact absent gas: liquid EOS + Et supplies
p; gas psi/thermo is never used. Near-pure detection uses BOTH alpha and mass
tests; a small alpha with material mass above threshold is not pure and must
not invoke unbounded m/alpha. See positivity policy for conservative treatment
of residual masses/energy. rho=rhoPresent holds exactly only when absent mass
is zero; do not erase finite residual mass to manufacture this identity.

## Layering and ownership

State records contain values; EOS objects own parameters/reference tables;
recovery owns no persistent fields and mutates no cloud. Acoustics consumes
validated phase records. A future driver owns mG,mL,M,Et,alphaL, derived rho/U/p,
and calls one recovery per candidate state. Alpha module owns the nonconservative
law, KT module owns all conservative fluxes. No duplicate rho or pressure owner.
EOS parameter/table selection stays in M6A1b-2B; root tolerances and pure-phase
threshold values stay in M6A2. Canonical gas/liquid/DPM energy mapping remains
UNRESOLVED and blocks runtime energy initialization/recovery acceptance.
