# TRACKINGDATA_ARCHITECTURE_BLOCKER

## Proven scope

This is a blocker of the **current stock OF7 basicSprayCloud/basicSprayParcel type family plus existing packet wrapper**, not a proof that support-first spray is mathematically or generally impossible.

1. Native evolve explicitly constructs `parcelType::trackingData` before solve ([SprayCloud.C:222](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/spray/clouds/Templates/SprayCloud/SprayCloud.C:222)).
2. Its Thermo base owns **private const volScalarField Cp_ and kappa_**, not deferred handles ([ThermoParcel.H:159](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcel.H:159)).
3. Their member initializers invoke native full-field property functions before parcel-location preflight ([ThermoParcelTrackingDataI.H:35](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcelTrackingDataI.H:35)).
4. Native heThermo.Cp traverses all cells/boundaries and uses p/T/Y; kappa calls Cp again ([heThermo.C:315](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/thermophysicalModels/basic/heThermo/heThermo.C:315), [heThermo.C:730](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/thermophysicalModels/basic/heThermo/heThermo.C:730)). A valid parcel stencil cannot make absent cells elsewhere valid.
5. Spray aliases the Reacting/Thermo trackingData ([SprayParcel.H:131](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/spray/parcels/Templates/SprayParcel/SprayParcel.H:131)); physics methods and models use that fixed nested type and native interpolation interfaces. The R2A packet is not a substitute for those signatures.
6. Public thermal accessors expose const fields. Mutating genuinely const owned members by const_cast is invalid; assigning sparse properties later is not a supported native API.

API-only actual-header probe compiled with Foundation OF7: 9 signature/alias checks,0 failures; no mesh/cloud/thermo/parcel construction or full tracking execution. It supports type binding, not pure-liquid full-chain numerical acceptance. No failing gas EOS is deliberately executed.

## Alternatives assessed

| Approach | Result |
|---|---|
| gate only setCellValues/interpolation accessor | too late for native constructor/global Cp |
| preflight one currently valid parcel then call stock constructor | unrelated absent cells still visited by full-field Cp |
| require every cell gas-valid before constructor | forbidden global-validity restriction; rejects required legal heterogeneous states |
| fill air/previous gas/epsilon/zero species | forbidden invented carrier state |
| poison global fields and execute whole Cp | evaluates invalid physical storage; NaN propagation is not support validation |
| mutate native const Cp/kappa with const_cast | unsafe and unsupported |
| shadow same native template headers/symbols against compiled native libraries | no acceptance proof; ODR/layout/type-family risk; not performed |
| separate project-local parcel/cloud trackingData type family | technically plausible repair; needs explicit ownership/caller-interface migration, native tet provenance and model/template specialization coverage |

## STOP decision

User request section47 explicitly requires STOP when the native trackingData API cannot avoid eager invalid thermo in a heterogeneous gas-absent mesh. That condition holds for the current native type family and simple-wrapper route. No alternative EOS, fake carrier, model physics edit or active solver change is introduced.

Next work should first define a separate local type family/deferred ownership bridge, preserving native equation bodies/integration/model formulas, and prove constructor+actual tet interpolation+source `.psi()`/composition interfaces one layer at a time. Keep the frozen query core as a reference, do not mutate it to disguise the ABI boundary. Only after this architecture gate is resolved should the requested full-chain tests be attempted. R2 final closure remains unauthorized until R2A-FINAL COMPLETE.
