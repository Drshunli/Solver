# M5C.1 legacy KT discrete audit

Audit date: 2026-09-30. Authority is the current local active source, not an
assumed OpenFOAM.com solver. Active files are untouched; SHA-256 before/after
records are under `fitting/flux/m5c1_v1/`.

## Actual source locations and reconstruction

| Actual file | Audited content |
|---|---|
| `rhosprayVoFDPMFoam.C:143–175` | Independently reconstruct rho, rhoU, rPsi=1/psi, e, c; derive U and p; subtract mesh.phi before wave estimates |
| `rhosprayVoFDPMFoam.C:177–202` | ap/am, normalized weights, Tadmor alternative, dissipation, weighted relative transport |
| `rhosprayVoFDPMFoam.C:214–250` | phi, provisional phiV, phiUp, phiEp and absolute pressure-work correction |
| `directionInterpolate.H:15` | `fvc::interpolate(vf,dir,"reconstruct(fieldName)")`, direction-specific renamed field |
| `readFluxScheme.H:1` | Kurganov default, Tadmor supported, invalid choice rejected |
| `createFields.H` | pos/neg direction fields; legacy gas conserved variables and gas thermo |
| `rhoEqn.H`, `rhoUEqn.H`, `rhoEEqn.H` | Legacy gas equations consume phi/phiUp/phiEp; parcel source placement remains unchanged |
| `rhoYEqn.H:1–44` | Species uses mvConvection(phi), reaction and parcels.SYi; this is NOT the new mG*Yi KT face operator |
| `D:/DATA/Solver/300_2D/system/fvSchemes` | Kurganov; Minmod rho/T, MinmodV U; Euler; div(phi,Yi_h) Gauss vanLeer |

Actual local Foundation 7 files were also read:
`/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/applications/solvers/compressible/rhoCentralFoam/directionInterpolate.H`
and `readFluxScheme.H`. Their operator structure matches; the local readFluxScheme
uses the older FatalErrorIn spelling. There is no `interpolate.H` at that location;
the actual header is `directionInterpolate.H`.

Legacy reconstructs:

```
rho± = interpolate(rho, pos/neg)
M±   = interpolate(rhoU, pos/neg, U.name())
rPsi±= interpolate(1/psi, pos/neg, T.name())
e±   = interpolate(e, pos/neg, T.name())
U±   = M±/rho±
p±   = rho± rPsi±
c±   = interpolate(sqrt(Cp/Cv*rPsi), pos/neg, T.name())
```

**Reconstruction boundary:** independent rPsi/e/c interpolants need not be on one
face EOS manifold. M5C.1 proves operator equivalence on EOS-consistent supplied
faces; it does not prove equivalence of a future cell-to-face reconstruction to
the current Minmod reconstruction. That remains a M5C.2 blocker. No reference
state was adjusted to match a failed test.

## Exact coefficient mapping

Let `S=Sf`, `s=|S|`, `w=meshPhi` (m3/s), `q±=U±·S-w`.

| Legacy symbol | Standalone symbol | SI dimension | Definition |
|---|---|---|---|
| phiv_pos/neg BEFORE multiplication | qPlus/qMinus | m3/s | U±·S-w |
| cSf_pos/neg | cMix± s | m3/s | acoustic speed times face area |
| ap | ap | m3/s | max(qPlus+cPlus*s,qMinus+cMinus*s,0) |
| am | am | m3/s | min(qPlus-cPlus*s,qMinus-cMinus*s,0) |
| a_pos | aPos | 1 | ap/(ap-am) |
| a_neg | aNeg | 1 | 1-aPos |
| aSf | aSf | m3/s | am*aPos, nonpositive |
| phiv_pos/neg AFTER multiplication | aPos*qPlus / aNeg*qMinus | m3/s | legacy symbol is mutated |
| aphiv_pos | Aplus | m3/s | aPos*qPlus-aSf, nonnegative |
| aphiv_neg | Aminus | m3/s | aNeg*qMinus+aSf, nonpositive |
| phiV | phiRelStar | m3/s | Aplus+Aminus |
| no dedicated active equivalent | phiPhysStar | m3/s | phiRelStar+w |
| phi | mGPhi+mLPhi | kg/s | total KT mass flux |
| phiUp | momentumPhi | N | transport of M plus pressure*S |
| phiEp | energyPhi | W | transport plus pressure work |

For Tadmor only: aPos=aNeg=1/2; aSf=-max(|ap|,|am|)/2. The ap/am
definitions are retained. Legacy `amaxSf` first denotes max(|ap|,|am|), then is
overwritten with max(|Aplus|,|Aminus|); the standalone does not reuse that symbol.

## Direct five-equation extension of the actual formulas

```
FmG = Aplus*mGPlus + Aminus*mGMinus
FmL = Aplus*mLPlus + Aminus*mLMinus
pStar = aPos*pPlus + aNeg*pMinus
FM = Aplus*MPlus + Aminus*MMinus + pStar*S
FE = Aplus*(EtPlus+pPlus) + Aminus*(EtMinus+pMinus)
     + aSf*pPlus - aSf*pMinus + w*pStar
```

Energy can equivalently be written:

```
FE = Aplus*EtPlus + Aminus*EtMinus
     + aPos*pPlus*(qPlus+w) + aNeg*pMinus*(qMinus+w)
```

For a uniform state this is `Et*(U·S-w)+p*U·S`. Dropping the final
`w*pStar` instead yields wrong relative pressure work. The independent oracle
`tests/fiveEqFlux/legacyKTOracle.H` preserves the original evaluation order and
does not call new coefficient/flux code.

## Species and DPM distinctions

The standalone species operator is `F_mYi=Aplus*(mG Yi)Plus+Aminus*(mG Yi)Minus`,
in the runtime species order, validated by the bridge. It is an intentional future
contract, not a claim of equality to current mvConvection/vanLeer transport.
Reaction remains a separate gas species source.

Future parcel mapping: mass to mG, momentum to M, energy to Et, species to mG Yi.
The existing source matrices cannot be blindly transferred: their unknown,
linearization, gas carrier density and energy reference must be audited in an
adapter. `DPM source adapter = PRE-ACTIVATION DEPENDENCY`. Before M6B there must
be that adapter or an explicitly disabled DPM-source activation mode. Neither
is implemented here. M3 surface tension stays diagnostic; M7 owns conservative
momentum/total-energy/surface-energy coupling.

## Reproducible limits of the regression

3456 gas face pairs vary p, T, vector U, 3 compositions, 3 face vectors/areas,
mesh speed and both schemes. Compare (1) independent legacy algebra on recovered
primitives with e=Et/rho-|U|2/2; (2) original primitive-generated states, separately
exposing recovery roundoff. Scale errors by characteristic wave transport plus
pressure terms, rather than by possibly vanishing/cancelling fluxes. CSV retains
all individual errors. No cell mesh, cloud evolution or CFD case is constructed.
