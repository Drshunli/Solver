# M6B.1-IDP1-INVARIANT-DOMAIN-REVIEW — v1

日期：2026-10-05。本轮请求存于 `request_IDP1.txt`。依据开发日志及其后 TD1/TD2 权威追加记录开展；旧主日志中的早期 EOS/TD1 状态作为历史快照保留。

1. **IDP1 status**：**COMPLETE / ADMISSIBILITY MECHANISM CLASSIFIED / STOP**。19 项诊断门槛 PASS。只闭合机制分类；没有部署修复，也没有取得 TD1、shock endTime 或生产资格。

2. **Anchor population**：复用原 TD2 全部 25 个状态：230 healthy；235 onset；240、260、330、530、651、1000、1309 early；3000、6000、10000、10852、15000、20000 middle；22260、24000、26000、27659、28000、30000、31000、32000、32219、32252 late。32219 原 minimum-dt、1309 原最高 reject/rescue、32252 原 final 均保留。E1 detail：235/1000/10000/22260/32000；E3 detail：240/330/28000/30000/32252；额外审计 32219。每个状态 100 个 committed cells 原始 Q/P2 位串准确解码、原生恢复 PASS；原 TD2 bounded replay 证明与下一快照证据哈希保留。本轮不生成新动态轨迹。

3. **Affine trial verification**：固定单位面积、周期网格、V=0.01、零 mesh flux、零外部 source。连续表示为 Qj(dt)=Qjⁿ+dt(ΦLj−ΦRj)/V，j=1…9；P2 的液相导数为 DD numerator/V，minority 导数随签名变号。`affine.csv` 为全部 25×100 cells 保存各分量 Q、两面 flux、左右导数、总导数、P2 numerator hi/lo、rho 与 Eint 导数。

   原生 binary64 语义不是任意重排后的 affine 表达式：dt>0 时必须逐步计算 `(V*Qj-dt*(ΦRj-ΦLj))/V`；dt=0 原样返回。P2 使用与活动源码相同顺序的 DD 差、缩放和 `advanced`，最后 Q0 取权威 fraction。所有成功构造的 trial 逐位核对这套操作，mismatch=0；连续 long-double 表示与其差异另列为 roundoff，不能拿连续表达式替代原生判定。共 38768 次全网格候选 / 3876800 次 cell checks（两种空间方案），原生 raw 和原始 q9=q1−(q7+q8) post-closure 均要求 PASS。

4. **Analytic mass bounds**：解析条件是 q≥0；原 PRESENT 还要求 q>0。导数 d<0 时界为 q/(-d)，d≥0 没有该正性上界；严格 PRESENT 不含零质量端点。全网格最小 mass bound 为 0.00117509438029–0.00117509438054 s。cell 53 的 dmG/dt≈1695.893、dmL/dt≈286.038，均为正，原微步长限制不来自质量耗尽。

5. **Analytic species bounds**：逐个原始 mYi 及 N−1 residual mG−mY0−mY1 分别计算线性非负界，原始 closure 容差及 post closure 使用原生恢复另核对。全网格 species 最小界约 1.17509438e-3 s。不存在 normalize(Y) 或独立 species 修补；C 条件不构成首拒绝。

6. **P2 bounds**：用 DD numerator 的连续液/气导数建立 alphaL≥0、alphaG≥0 界；P2 签名 minority 只作存储坐标，不能独立裁剪。全网格最小连续界约 3.05649618e-3 s。D 条件还检查 P2 mode、lo=0、|hi|≤0.5、Q0 与权威 fraction 一致。另保存两面的 DD numerator 与 minority 导数；表示层的真实舍入由逐位 trial gate 决定。

7. **Root-domain bounds**：24/24 micro anchors 的首拒绝均为 H / `NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN` / `LIQUID_LO_EINT_LOW`，累计 15912 个当前方案候选。common interval 存在，控制单元的 pLo≈3.2858482766 MPa、pHi=12 MPa；下端由液相 TL≈265 K 控制，绝非 p interval collapse 或上温度端点失败。FLo>energyTol 表示 Eint 低于当前合法下端能量；FHi 为正、两端 dF/dp 正。`cell_conditions.csv` 保留每候选每 cell 的 A–J、端点、FLo/FHi、dF/dp、phase intervals。

   committed cell 53 已处于 R1 的端点容差带，不能称为明显位于 admissible set 内部：23 个样本 TL=265 K，27659 为 265.00000000000017 K（+3 ULP）；FLo=7.0957467e-6…8.6780638e-6 J/m³，energyTol≈8.6922955e-6，余量仅 1.42317e-8…1.59655e-6 J/m³。严格零残差的连续根不能与容差允许的 endpoint acceptance 混为一谈。

   保持原容差，在下端处 dFLo/dt≈2.95842607e11 J/m³/s；本地线性剩余容差估计 `(energyTol−FLo)/dFLo_dt` 为 4.81057587484e-20–5.39661544946e-18 s。该量解释微步长尺度，不是严格全局上界，也不是合法前缀证明。完整 logarithmic continuation 从 accepted×1/2/4/…直到 freshCap，FAIL 后继续；结果在 candidate/cell ledgers 中。原生已测合法集合非单调，不能把一次 bisection 称为最大步长。宏观小扰动的 FLo slope 与解析导数另列 `measuredMacroRootDerivative`。

8. **Limiting cell statistics**：全部 24 个 micro anchors 的所有当前方案首拒绝都发生于 cell 53；这来自全 population，未用单个样本外推。healthy 230 全部候选合法、最大等于 fresh acoustic cap；该 cell TL=265.9322858 K、线性余量尺度约 5.62676e-6 s，仍大于 cap。

9. **Limiting face statistics**：periodic face f 连接 cell f 与 f+1；cell 53 左面为 face 52、右面为 face 53。全 24 个样本左面 dFLo/dt≈+1.24155546e13，右面≈−1.21197120e13；左面推向失效，右面抵消，净值≈+2.95842607e11，绝对两面贡献/净值≈82.9335。以 anchor235 为例 dEt_left=+2.9241223708e10、dEt_right=−2.8281190011e10；dML_left=−250.271977、dML_right=+536.309642。单看能量或质量通量最大项不足以归因；根边界敏感度才决定限制。

10. **Reconstruction audit**：保存全部 committed、left/right reconstructed Q、P2、恢复 p/TG/TL/energy/root distances 和 theta；恢复的 face primitives 与原生 KT faces 一致。cell 53 的 theta 已非常小（anchor235 为 2.75257594495e-12），两面 TL 均在下界附近；anchor235 两侧余量约 4.14700e-7 与 1.21098e-6，原 cell 为 4.46365e-7。因此一侧更近、一侧更远，不能统一宣称重构 overshoot。全网格第一阶对照也没有 materially larger witness。

11. **KT contribution audit**：保存每个 anchor 每个 face 每个守恒分量。采用明确的代数划分：central=0.5(uL QL+uR QR)；waveWeight=(aPos−0.5)uL QL+(aNeg−0.5)uR QR；dissipation=aSf(QR−QL)；Mx 另加加权 pressure，Et 另加 aPos uL pL+aNeg uR pR。wave ap/am/aPos/aNeg/aSf 与原生完整 flux 均保存。原生 Et 的压力抵消以及 residual species 的括号顺序不可重排；代数重组与 native flux 的 roundoff residual 明列，最大按所存归一尺度约 2.501e-10，未覆盖原生值。

   根边界线性贡献（anchor235、两面合计）：central≈+4.46018649782e11；waveWeight≈−4.109202263e9；dissipation≈−1.45633215300e11；pressure≈−4.336250328e8，合计≈+2.95842607186e11。24 个样本方向相同：此划分中 central 主导向外，dissipation 起抵消作用。代数归因不构成独一的物理因果证明，也不支持“删除 KT dissipation 能解决”的结论。

12. **Small-phase / trace sensitivity**：cell53 alphaL≈2.0165507564e-5、mL≈0.01521381567 kg/m³、rhoL≈754.44744534 kg/m³；这是小相量，在原 presence policy 下仍为 PRESENT，不能误称被阈值判定的 TRACE_PRESENT。液相 energy contribution≈−1137.0261 J/m³，远小于 Eint≈4.3461477e6；dmL/dt≈+286.037665。由 drhoL/dt=(dmL−rhoL*dalphaL)/alphaL 得约 67914.205 kg/m³/s。TL265 等温 drho/dp≈6.51145e-7，对应 pLo 变化≈1.04299706e11 Pa/s；较小液相能量占比并不能使其 intrinsic ratio 对公共压力域无关。

13. **Binary64 sensitivity**：全部 24 micro anchors 均取得当前方案的局部相邻 binary64 PASS/FAIL pair；两方案合计 52 对。局部 refinement 只分辨一个所选 PASS/FAIL 边界，不宣称 global maximum；这些额外单 cell probes 不参加第一阶 all100 比较。完整 mL/P2/alpha/rho/endpoint/FLo 位串见 `critical_binary.csv`，E3 detail 与 min/final 均覆盖。

   在相邻候选中 alpha 位串保持、mL 位串跳变，rho 与 pLo 位串随之改变；native rho 跳变 1.136868377e-13–2.273736754e-13 kg/m³，FLo 跳变 2.393499017e-07–1.697801054e-06 J/m³。离线 80 位 Decimal 只针对同一冻结 flux/volume/P2 numerator 的连续 mL/alpha 计算，连续 rho 差仅 2.043718759e-31–2.615960012e-29；未改 EOS、没有把高精度结果提交给求解器。`exact_ratio_adjacency.csv` 区分连续向外方向与表示口袋：前者决定狭窄容差带，后者改变其中的离散接受平台。

14. **Conservative timescales**：V=.01；全部 |Q|/|dQdt| 与两面 magnitude 在 affine/flux ledgers 中。cell53 tau_mG≈8.2007250e-3 s、tau_mL≈5.3188155e-5、tau_Et≈4.5370698e-3、tau_nonzero_species≈8.2007250e-3；静止 transverse momentum 与零 C10H22 derivative 的 tau 为∞。这些尺度远大于原生 admissible dt；ordinary positivity 不能解释差距。

15. **Acoustic vs root bound**：全 micro population acoustic≈1.205093508e-6 s；mass≈1.17509438e-3、species≈1.17509438e-3、P2≈3.05649618e-3。局部根域容差尺度为约 1e-20…1e-18，最大已测 current legal dt 为 6.064668015e-19–2.192052321e-18。每 anchor ranking 与精确值在 `anchor_mechanisms.json`：root/domain geometry → representation acceptance pockets → acoustic → mass/species → P2。根的局部估计与测试 witness 均不等于数学最大 dt。

16. **First-order shadow results**：OFFLINE ONLY，strategy0 同一 committed state 的 piecewise constant faces；same native KT/R1/EOS、same volume、same candidate 位串，raw/post/P2/PRESENT gates 相同。没有安装一阶求解器、没有新 PDE trajectory。healthy 对照两方案一致达 freshCap；24 micro 全部一阶已测最大合法步长更小。

17. **First-order improvement ratios**：micro ratio range=0.25…0.790663964。≥10 / ≥100 / ≥1e4 / ≥1e8 的样本数均 **0/24**。这是测试候选集内的最大 legal 比值，不是两种方案全球最大合法集合的证明。

18. **Short-window replay**：NOT RUN / NOT REQUIRED。使用冻结状态和 TD2 已取得的 bounded historical reconstruction 证据；没有为本轮重新运行 32252 步或添加 ≤100 步动态试验。所有 scan、shadow、face audits 均不提交状态。

19. **IDP A–G classification per anchor**：24 个 micro formal 分类均为 **IDP-G：C 主导 + F 表示效应**；healthy 是 CONTROL。A/B 不控制 first failure；D 未得到一阶改善证据；E 的单独因果资格未建立。F 作为 binary trace-ratio/endpoint acceptance 效应存在，但不能替代已测连续根域向外方向。

| anchor | TD2 class | IDP class | current largest tested legal (s) | first-order largest tested legal (s) | PC/current | local root slack dt (s) |
|---|---|---|---:|---:|---:|---:|
| 230 | E1 | CONTROL | 1.205093328e-06 | 1.205093328e-06 | 1 | 5.62676283873e-06 |
| 235 | E1 | IDP-G | 1.918045781e-18 | 1.370032701e-18 | 0.714286 | 1.50879351678e-18 |
| 240 | E3 | IDP-G | 1.644039241e-18 | 1.096026161e-18 | 0.666667 | 1.54027385639e-18 |
| 260 | E1 | IDP-G | 1.971017105e-18 | 1.370032701e-18 | 0.695089 | 1.571754196e-18 |
| 330 | E3 | IDP-G | 1.918045781e-18 | 4.795114453e-19 | 0.25 | 4.81057587484e-20 |
| 530 | E1 | IDP-G | 9.590228906e-19 | 4.795114453e-19 | 0.5 | 2.3383976246e-19 |
| 651 | E1 | IDP-G | 1.918045781e-18 | 1.370032701e-18 | 0.714286 | 1.93063006755e-18 |
| 1000 | E1 | IDP-G | 2.192052321e-18 | 8.220196205e-19 | 0.375 | 2.25172953155e-18 |
| 1309 | E1 | IDP-G | 6.064668015e-19 | 4.795114453e-19 | 0.790664 | 9.8474302124e-20 |
| 3000 | E1 | IDP-G | 9.590228906e-19 | 4.795114453e-19 | 0.5 | 1.552865992e-18 |
| 6000 | E1 | IDP-G | 1.971017105e-18 | 1.370032701e-18 | 0.695089 | 6.68268448912e-19 |
| 10000 | E1 | IDP-G | 1.971017105e-18 | 1.370032701e-18 | 0.695089 | 2.72708265832e-18 |
| 10852 | E1 | IDP-G | 1.918045781e-18 | 1.370032701e-18 | 0.714286 | 3.42594619718e-18 |
| 15000 | E1 | IDP-G | 1.918045781e-18 | 1.370032701e-18 | 0.714286 | 3.34576848963e-19 |
| 20000 | E1 | IDP-G | 2.192052321e-18 | 1.370032701e-18 | 0.625 | 2.99781357719e-18 |
| 22260 | E1 | IDP-G | 9.590228906e-19 | 7.580835017e-19 | 0.790475 | 8.35114248066e-19 |
| 24000 | E1 | IDP-G | 1.918045781e-18 | 8.220196205e-19 | 0.428571 | 8.60298519644e-19 |
| 26000 | E1 | IDP-G | 1.918045781e-18 | 5.480130803e-19 | 0.285714 | 1.74027116972e-19 |
| 27659 | E1 | IDP-G | 1.918045781e-18 | 1.370032701e-18 | 0.714286 | 1.61897470298e-18 |
| 28000 | E3 | IDP-G | 2.192052321e-18 | 1.370032701e-18 | 0.625 | 1.89600169111e-18 |
| 30000 | E3 | IDP-G | 1.918045781e-18 | 5.480130803e-19 | 0.285714 | 1.96211040399e-18 |
| 31000 | E1 | IDP-G | 2.192052321e-18 | 1.610927441e-18 | 0.734895 | 4.57497858727e-18 |
| 32000 | E1 | IDP-G | 2.192052321e-18 | 1.370032701e-18 | 0.625 | 5.39661544946e-18 |
| 32219 | E3 | IDP-G | 1.918045781e-18 | 1.370032701e-18 | 0.714286 | 3.95166786374e-18 |
| 32252 | E3 | IDP-G | 1.918045781e-18 | 5.480130803e-19 | 0.285714 | 3.97370410143e-18 |

20. **Population dominant class**：formal G=24/24；其 primary C=24/24、secondary F=24/24。24 个状态的首次全网格拒绝、根边界方向、一阶对照和 adjacent witnesses 均支持该结论。19/24 当前单 cell continuation 中观察到 FAIL 后更大 PASS；没有声称其余 5 个状态的合法集合全局单调。结论范围限定这 24 个冻结状态。

21. **True IDP issue established?**：**NO**，用户规定的证据条件未达到。已证明当前空间 trial 产生 inadmissible states，但所测同状态第一阶 alternative 没有 materially larger admissible dt；它也未被证明是该 EOS/R1 set 的 invariant-domain scheme。不能据此保证 reconstruction/positivity/convex limiter 解决，不能将 scheme issue 当作已闭合实施前提。

22. **Candidate repair family — NOT IMPLEMENTED**：下一轮仅建议针对 C/F dominant mixed mechanism 的最小冻结状态对照实验：先 R6 common-pressure/model-closure applicability review，搭配 R5 representation error accounting，区分下界连续向外方向和离散平台；EOS HARD/coefficients/能量参考仍冻结。若以后能找到具有 materially larger legal witness 的保守替代方向，再评估 R2/R3/R4 或 R1，不在本轮设计/安装 limiter。精度处理可能平滑口袋，但当前证据不支持它单独把根域尺度提升至 1e-6。

23. **Conservation implications**：R1 若仅改 face reconstruction 后仍使用同一共享 face flux，可保持 finite-volume face-pair conservation；R2/R4 必须用单一 face coefficient/修正通量对两邻单元等量反号；R3 必须实现成这样的保守 flux correction，独立 cell blend 不自动保守。R5 若只改表示必须重新证明原积分与 closure；R6 是模型审查，不自动获得离散守恒资格。本轮只审计，共享 face flux 的周期 telescoping 未改；不推荐 per-cell post clipping。KT 分解及根方向不是 production limiter。

24. **P2 implications**：P2 仍唯一 fraction authority；PRESENT phase 不删除、不设 alpha threshold、不独立 alpha clip。未来通量/凸限制必须一致处理 P2 numerator、phase masses 和 energy/root admissibility，而非只约束 alpha 正性。

25. **Species implications**：mG 与 N−1 independent mYi 必须使用一致 face limiting，最后 residual 保持 mG−(mY0+mY1)，raw 与 post gate 都保留。没有 normalize(Y)，不允许后归一化掩盖负 residual。

26. **EOS hash preservation**：active v3 HARD p=.05–12 MPa、T=265–400 K 永久冻结；81 coefficients、C_L=369229.9537234281 不动。SHA：

- `liquidEOS/ndecane_gibbs_v3/coefficients.json`：`610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`
- `liquidEOS/ndecane_gibbs_v3/energy_reference.json`：`ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`
- `liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H`：`421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d`
- `liquidEOS/ndecane_gibbs_v3/metadata.json`：`9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`

27. **Temporal hash preservation**：TD1 修复全部保留；TD2 escape 未部署，本轮未实施。SHA：

- `serialFiveEq/runSerialFiveEq.C`：`3327f1988bcca53a459d01f9cb2db0fd7624d946b6da378477c679fbcec7907a`
- `fiveEqIntegration/fiveEqTemporalContract.H`：`e47e6466de56e82856ebc66281acf40061dd121ae917144a1343cf6f9019ba89`
- `fiveEqIntegration/fiveEqTemporalPolicy.H`：`a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062`

28. **Foundation/project hashes**：110 个活动源码文件 SHA 完全相同；115 个 installed libraries、active executable 与两个 custom libraries before/after SHA 相同；Foundation 6717、native parcel 19 全 OK；4547 个既有 TD1/TD2 证据与旧 checkpoint SHA/CRC 全保留。完整 before/after 表、旧 ZIP seal 和 source snapshot 在本轮目录；`source_delta.json={}`、active patch 为空。只追加当前 milestone 记录，其旧 prefix 原样保留。

   隔离诊断编译的初次未初始化警告已通过显式初始化消除；额外工具初次入口重复定义已修正，失败日志保留。最终两个编译日志 0 warning/error；初始化修正后重跑 25 anchors，200 个产物逐字节相同。两工具均位于独立 offline 目录，未安装 active binary。

29. **IDP1 COMPLETE?**：**YES，diagnosis/classification only**。以下为用户 19 项门槛；每项有对应 CSV/JSON/native evidence，而非替代 TD1 效率或 shock completion。

| gate | outcome |
|---|---|
| 25 anchors reproduced | PASS |
| affine Q(dt) verified | PASS |
| admissibility conditions separated | PASS |
| analytic positivity bounds computed | PASS |
| root-domain bounds diagnosed | PASS |
| limiting cells identified | PASS |
| limiting faces identified | PASS |
| reconstruction states audited | PASS |
| flux contribution audited | PASS |
| trace sensitivity audited | PASS |
| binary64 sensitivity audited | PASS |
| acoustic/root/positivity bounds compared | PASS |
| first-order shadow comparison completed | PASS |
| 24 micro anchors classified | PASS |
| dominant/mixed conclusion justified | PASS |
| no active physics modification | PASS |
| EOS unchanged | PASS |
| TD1 source unchanged | PASS |
| Foundation unchanged | PASS |

30. **Next permitted milestone**：本轮结果为 mixed，下一轮建议独立授权的最小 C/F 冻结状态实验：common-pressure closure review 为主、precision representation review 为对照。本轮只提出路径；IDP2 flux limiting design、model/precision changes 全部 NOT EXECUTED。

31. **TD1 status**：PARTIAL / LOCAL CORRECTNESS PASS / MICROSTEP EFFICIENCY UNRESOLVED。旧 user stop、32252 accepted、time=.00028286341471286345、endTime=.00055 未达保持不变；本轮不能将其标记 COMPLETE。

32. **DYN-CLOSURE status**：NOT AUTHORIZED / NOT EXECUTED；TD1 COMPLETE 前提未达。

33. **M6B.1/M6B status**：仍 PARTIAL。IDP1 COMPLETE 只闭合诊断子阶段，未触发下一阶段、未取得 production CFD/restart 或 active DPM 资格。

34. **Milestone matrix**：

| milestone | current authoritative status |
|---|---|
| PHASE-DEFER | COMPLETE / POLICY FROZEN；历史 CLASS D / 物理相边界证书 unresolved |
| EOS3-NUMERICAL | COMPLETE / OPERATIONAL DOMAIN FROZEN；观测接受轨迹范围，非相证书/production |
| ADM1 | COMPLETE / TRIAL REJECTION SEMANTICS CLOSED / OUTCOME C |
| TD1 | PARTIAL / LOCAL CORRECTNESS PASS |
| TD2 | PARTIAL / DIAGNOSIS CLOSED / MICROSTEP ADMISSIBILITY LIMIT |
| IDP1 | COMPLETE / ADMISSIBILITY MECHANISM CLASSIFIED / STOP |
| IDP2 / model / precision implementation | NOT EXECUTED，下一轮独立授权 |
| DYN-CLOSURE | NOT AUTHORIZED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL |
| M6B.2 / active DPM / T4-S3 / production CFD | NOT EXECUTED / 未认证 |

**STOP。** 不修改 EOS、R1、P2、KT、reconstruction、species、时间搜索/增长、Foundation；不自动执行任何后续里程碑。

证据定位：本轮目录 `fitting/integration/m6b1_idp1_invariant_domain_review_v1/`。每个 `results/<anchor>/` 的 `full_reconstructed_states.csv` 包含两种方案的完整 10 分量 Q/P2 位串及恢复 primitives（含 U、rho、e、c、beta、iterations），并逐分量与 `flux_decomposition.csv` 的面 QL/QR 核对。`cell_conditions.csv` 中 1=该条件满足、0=该条件不满足、−1=前置阻塞/不适用；pure-phase geometry 由原生单相 R1 判定，不能把 −1 当作独立条件 PASS。H 首拒绝时 Newton 尚无合法根 bracket，J 的原生失败不是另一个迭代收敛瓶颈。

独立封存包：`D:/DATA/Solver/checkpoints/M6B1_IDP1_ADMISSIBILITY_MECHANISM_CLASSIFIED_STOP_v1.zip`；SHA、CRC、逐文件核验结果见 `checkpoint_gate.json`。包含原始与重复诊断记录；没有删除 trace、旧 TD1/TD2 证据或失败日志。
