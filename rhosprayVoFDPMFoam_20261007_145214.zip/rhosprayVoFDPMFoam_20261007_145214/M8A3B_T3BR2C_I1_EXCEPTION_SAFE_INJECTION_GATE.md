# M8A.3B-T3B-R2C-I1 — Exception-safe injection newborn ownership gate

## 1. I1 status

COMPLETE. Only passive serial fixed-mesh transient coneInjection ownership certification. R2C remains PARTIAL; this is not production activation or complete eight-model transaction certification.

## 2. Native orphan reproduction

Native generic injection first reproduced using parcel-specific lifetime instrumentation, without global operator new/delete interception. `old_lifetime/ownership_result.json`: ctor=1, dtor before control cleanup=0, surviving orphan after discard=1. Canonical restoration still passed. A separate old-control-only manual deletion occurs after recording failure; it is explicitly not the repair.

## 3. Exact ownership timeline

Completed parcel construction → scoped unique owner → native initialization/model callbacks → native move → either guard destruction, or nonthrowing intrusive append followed immediately by release → sole cloud ownership → eventual cloud destruction. Exceptions propagate unchanged. No retry or renumbering inside injector.

## 4. Adapter architecture

`tests/fiveEqDPMInjectionI1/ExceptionSafeConeInjection.H`: native-derived `Foam::fiveEqDPM::ExceptionSafeConeInjection<CloudType>`. Explicit specialization of the generic injection-list entry for the isolated local lazy cloud dispatches to guarded inject; the inherited native model virtual functions remain authoritative.

## 5. Native-vs-local code scope

Only Foundation generic transient InjectionModel orchestration is reproduced. No ConeInjection.C physical formulas copied. `native_orchestration_scope.json` proves native expression tokens unchanged after removing ownership/instrumentation edits. The frozen R2B stack is copied into the isolated I1 executable; only its outer parcel header receives a nonphysical test lifetime member. Other 18 parcel files retain frozen source contents. The seven other model laws and event logic are unchanged.

## 6. Guard implementation

`std::unique_ptr<parcelType, i1::DeleteNewborn<parcelType>>`; deleter only records guard deletion and executes delete. No source, random draw, output, or physical deletion bookkeeping. Counter instrumentation is passive-test-only.

## 7. Allocation ownership point

The allocation expression is the unique_ptr constructor argument. No operation occurs on a completed raw newborn before its scoped owner exists. Failpoint A is after guard construction; native constructor exceptions follow normal C++ construction-unwind rules.

## 8. setThermo failure

Failpoint B at the native setParcelThermoProperties call entry: exactly one guard deletion, no surviving object, zero failed-trial native sources, canonical rollback. These synthetic call-boundary failpoints do not modify or claim to reproduce a Foundation method-internal physical error.

## 9. setProperties failure

C before native setProperties, D after its normal return. Both exact-one-delete PASS. Native setProperties invoked once when reached; size/RNG/order/formulas unchanged.

## 10. checkProperties failure

E at checkParcelProperties call entry. Exact cleanup, no source generation by guard, canonical rollback PASS. Native method implementation remains unchanged.

## 11. nParticle failure

F at protected setNumberOfParticles call entry. Exact cleanup PASS. Native virtual nParticle law is inherited and retains its inputs and placement. No copied physical nParticle formula.

## 12. support/move exception

G is not a synthetic false return: actual native move reaches lazy preflight and throws GAS_SUPPORT_INVALID:EXACT_GAS_ABSENT. Newborn destroyed by unwind; whole trial rejected. Gas recovery/property calls=0; no accepted output. In the actual crossing/retry test, the newborn begins on valid support and later encounters absent gas.

## 13. move(false)

`false_fixture` changes only passive fixture constantProperties.minParcelMass to 1e-9. Native ReactingParcel minimum-mass logic sets keepParticle=false; no move result is forged. Two independent runs (cache warmup and stable rerun) each construct/destroy one parcel, guardDelete=1, cloudAdopt=0, moveFalse=1. Physical minimum-mass carrier transfer is a native event, distinct from failed-trial guard cleanup.

## 14. move(true)

Legal adoption scenario: ctor=1, guardAdopt=1, cloudAdopt=1, guardDelete=0. The subsequently discarded trial cloud destroys this object once.

## 15. pre-adoption failure

H after actual true move and immediately before append: guardDelete=1, cloudAdopt=0, ctor=dtor=1. Native source state sampled at the H boundary equals source state after guard unwind; the guard adds nothing. Partial trial physical effects are discarded.

## 16. cloud adoption

Actual Foundation Cloud::addParticle calls this->append(pPtr). ILList forwards to DLListBase::append, which only updates count/link pointers: no allocation or callback. With a valid non-null newborn the append/release sequence has no throwing operation between adoption and release. These are serial semantics, not a concurrent atomicity claim. Source copies and paths/hashes: adoption_source.sha256, *.reference.

## 17. ctor count

Final A–H + stress + adoption matrix: 1009. move(false) fixture including warmup: 2. Spatial reject/retry and future paths including codec clones: 243.

## 18. dtor count

Corresponding totals: 1009, 2, 243. Old native failure had 0 destructions before its deliberately separate control cleanup.

## 19. live object count

All guarded suites finish with zero live outer parcel objects. Each of 1000 invalid-birth cycles returns to its exact baseline; counter ledger is primary evidence, not RSS.

## 20. cloud-owned count

Failed births: zero survivors. Legal adoption: one cloud-owned object before discard. Retry/direct future step k (0–10): k+1 live objects and k+1 cloud-owned parcels; constructed=destroyed+live at every accepted step. Guard ownership is checked separately at allocation/adoption/deletion boundaries.

## 21. 1000-cycle stress

Final gate_matrix_release: 12083 checks, zero failures; 1000 actual allocate/move/support-reject/unwind/discard cycles. Every cycle ctor=1, dtor=1, guardDelete=1, live=0, canonical=1, output=0, gas property calls=0. Full lifetime.csv retained.

## 22. allocator result

Native identity allocation retained. Transactions restore committed particleCount_ after rejection. Exact canonical allocator state verified every cycle; no post-hoc parcel identity renumbering.

## 23. RNG result

Rejected full canonical packet restores complete native RNG state/cache. Native accepted path matches 328 state hashes; actual reject/small-retry matches direct path through 10 future steps. Guard code has no random call.

## 24. injection-history result

Native time0/timeStep0, injected mass, parcelsAddedTotal, nInjections, parcel-basis and cone cell/tet history remain in the existing typed codec. Canonical accepted equality and rejection restoration PASS. The inherited postInjectCheck remains at the native location.

## 25. source result

A–G failed trial native source fields are zero. Exception-boundary vs post-guard native sources equal where a hook can snapshot them, including H after real movement. Guard has no dmG/dmYi/dM/dEt operation. Native move(false) source transfer is preserved; discarded effects do not enter committed sources.

## 26. output result

Invalid birth: zero accepted publications. Guard destructor has no output. Staged output/acceptance machinery unchanged. The CSV/JSON files are offline test evidence, not solver output.

## 27. canonical rollback

Canonical state and committed carrier snapshot restored for every injected failure/stress cycle. Object-lifetime closure is separately checked; canonical equality is no longer treated as sufficient by itself.

## 28. retry equality

Existing eight unit-cube passive cells: first two gas, remaining cells pure Eulerian liquid. Geometry/BC files unchanged. dtLarge=0.1 s produces actual newborn invalid-support movement (not a production time-step recommendation). dtSmall=5e-8 s accepts. Large trial cleanup/discard followed by small retry equals direct small accept. `retry_v1`: 61 checks, zero failures.

## 29. future equivalence

Both paths continue 10 more accepted steps at 5e-8 s. Canonical parcel/ID/history/RNG/source/Q/generation, committed carrier snapshot and query results equal at every step. Lifetime closure checked every accepted step and after both clouds close.

## 30. native accepted equality

Fresh guarded all-gas core and Foundation native oracle: each 3728 checks, zero failures, 328 canonical .bin hashes byte-identical. This includes the established 13-scenario core subset and its ten-step comparisons; it does not close remaining R2C mixed/ORourke branch/IO gates. Accepted IDs/nParticle/position/U/d/T/Y, model histories, allocator and full RNG/source state are in these canonical comparisons.

## 31. support-first regression

Actual pure-support rejection makes zero gas recovery/thermophysical calls and zero provider samples. Frozen R2B fresh replay: 252194 checks, zero failures; 21000-cell all-gas property/state comparison bit-exact; whole-field Cp/kappa calls=0.

## 32. local lazy chain impact

Frozen R2B 30-file source/executable manifest unchanged. I1-only copied stack adds lifetime instrumentation, not physical fields. Numeric serialization excludes counters/ownership addresses; no installed parcel/cloud template is modified.

## 33. runtime-selection impact

Explicit coneInjection/local-passive-v1 mapping constructs a native-derived model with the same dictionary and coefficients; typed codec restores its native mutable state. Installed runtime tables unchanged. Unmapped local entry rejects rather than silently using unsafe orchestration. Adapter and local list steady entry throw NOT IN FIRST-ACTIVATION SCOPE. The old unsafe route is deliberately available only as the passive test control.

## 34. Foundation hashes

6717 installed source/Make entries verified unchanged; 19 original parcel sources unchanged; native ORourke .H/.C hashes unchanged. Installation and Foundation runtime tables never written.

## 35. frozen regressions

All fresh: R2B 252194; established guarded/native R2C core 3728 each; source/energy 9288 (8 golden CSVs byte-identical); M8A.3A 6375; T2 native 1725880 and all-gas 21000/21000; T3A 64395; P2/R1 105775; temporal/restart 9663. Additional frozen R2A query 273263. All failures zero. The old seven-model event branches were only replayed as frozen regression; no new physics/event development.

## 36. memory/registry

Exact counters prove newborn closure. First legal native move creates the known volPointInterpolate(R2C:trialCommonU) cached point field (48→49 objects); warmup verifies this exact single addition, without dropping any existing registry object. Stable rerun stays at the warm registry count. Pure invalid-birth stress registry is stable every cycle. RSS/time resources are supplemental and recorded in resources.json/log.resource; parallel runs are not controlled performance benchmarks.

## 37. active solver impact

NONE. 145 protected files (including active solver and production 300_2D inputs/mesh/BC), frozen R2B/R2C sources unchanged. No active cloud.evolve integration, thermo/recovery/Q/P2/source adapter/KT/pressure/surface-tension/VOF↔DPM changes. No CFD solver, blockMesh or checkMesh run. Four standalone OF7 wmake targets compile PASS.

## 38. whether I1 COMPLETE

YES for the requested passive transient coneInjection ownership gate. Old orphan reproduced, guard cleanup, A–H failures, actual false/true outcomes, adoption, source/output semantics, lifetime/stress, rollback, actual support retry, future/native equality and required regressions all closed. No mandatory STOP blocker triggered.

## 39. whether R2C may resume

NEXT ROUND ONLY. Do not execute remaining R2C now. Remaining runtime support/mixed/trace/KH-invalid-child/ORourke-branch/evolved-iNew/capability gates remain open. I1 does not authorize R2-FINAL/T4/M6B/CFD this round.

## 40. updated milestone matrix

| Gate | Status |
| --- | --- |
| R2B | COMPLETE / FROZEN |
| R2C-I1 | COMPLETE / passive ownership gate |
| R2C | PARTIAL / ownership blocker resolved, other gates OPEN |
| R2-FINAL | NOT AUTHORIZED |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NO |
| CFD | NO |

STOP. No further R2C gate executed this round.
