# Five-equation phase-presence contract v2

User-authorized M5C.2A revision. v1 is historical, retained in `fitting/reconstruction/m5c2a_v2/historical_v1.zip` and the original M6A2 reports. This document supersedes ONLY the old magnitude-based presence rejection.

| State | Definition | Recovery |
|---|---|---|
| ABSENT | Exact alpha=0, mass=0, associated conservative species masses=0 | Exact pure-phase routing |
| TRACE_PRESENT | alpha>0, mass>0, finite positive intrinsic density, legal EOS/root | Same equations and EOS as PRESENT |
| PRESENT | Nonzero consistent phase outside roundoff diagnostic marker | Ordinary recovery |
| INCONSISTENT | Exact presence/mass contradiction, unusable ratio, impossible EOS density, species-mass inconsistency | Reject |

64 epsilon marks diagnostics only. Neither alpha nor mass is rounded, normalized or deleted. EOS validity and common-energy-root validity remain mandatory even for tiny phases.

Binary64 normal alpha down to 2.2250738585072014e-308 passes the liquid-trace regression at the tested reference density. This is a tested representability point, not a universal bound on every intermediate operation. Subnormal alpha or mass conservatively triggers PHASE_PRECISION_UNRESOLVED; future conservative extinction remains unresolved. The first positive subnormal is 4.9406564584124654e-324. Computing alphaG=1-alphaL has a separate cancellation limit near alphaL=1; exact alphaG=0 with mG>0 is inconsistent, never silently converted to pure liquid.

Kernel state stores gasPresence/liquidPresence for diagnostics. MaterialCell validates conservative species masses; the kernel YG stores intrinsic fractions and is undefined/unused for exact absent gas. Bridge recovery uses the same v2 kernel, and adds a distinct precision diagnostic without changing pre-existing code numbers.

Historical executable objects have v1 ABI and must use the isolated historical replay build/library; do not run them against the current v2 library. The solver passive link was rebuilt for this reason.

Regression suites live in `tests/*V2`; original test sources and outputs remain unchanged. The old bridge magnitude-rejection reason was explicitly revised in the v2 copy to the actual impossible-density EOS rejection. All other legacy assertions remain. Only passive linking was rebuilt; no active mesh fields or flow/cloud updates were added.

See M5C2A_R0_ADMISSIBILITY_CLOSURE.md and the hashed JSON contract for evidence and limits.
