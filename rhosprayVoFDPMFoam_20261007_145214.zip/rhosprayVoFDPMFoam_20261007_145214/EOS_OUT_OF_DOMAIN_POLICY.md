# Liquid EOS domain and state-failure contract — M6A1b-2A.3

**Design contract only. No runtime EOS, root solve or KT reconstruction is implemented.** The audited reference backend is CoolProp 8.0.0 HEOS n-Decane. Production EOS selection/certification is reserved for M6A1b-2B; any selected implementation must pass this contract before activation.

## Three levels, absolute SI coordinates

| Level | Pressure | Liquid temperature | Meaning |
|---|---|---|---|
| EXPECTED PHYSICAL / SCREENING | approximately 0.188330–6.201421 MPa | approximately 299.440696–301.200448 K | current analytic trajectory scales, not guaranteed CFD extrema |
| PRODUCTION DESIGN | **0.10–8.00 MPa** | **295–305 K** | selected normal operation/calibration domain |
| PROJECT HARD EOS VALIDITY | **0.05–12.00 MPa** | **285–320 K** | tested reference domain; mandatory future model/table certification limit |

Bounds are inclusive. Pressure is absolute. This HARD region is not the entire HEOS formal domain (800 MPa, 243.5–675 K). No claim is made for arbitrary mixtures, cavitation, equilibrium two-phase, phase change, or different operating scenarios. The native energy zero remains separate from the domain definition.

Exact backend phase flags `liquid` and `supercritical_liquid` are retained. The latter is physically interpreted here as dense/compressed liquid with T below critical temperature and p above critical pressure; it is not a conventional supercritical-fluid state above both critical coordinates. Every accepted point must have finite/positive density, sound-speed squared, Cp/Cv and acceptable EOS derivatives; a correct numeric box alone does not validate a state. Native e/h/s may be negative and must not be clipped or rejected for their sign.

## NORMAL / BUFFER / INVALID

- **NORMAL:** valid single-liquid EOS state inside PRODUCTION. Evaluate the accepted EOS normally.
- **BUFFER:** valid state outside PRODUCTION but inside HARD. Evaluate the **same** accepted EOS only after its buffer region has been certified; increment cell/face/root counters, record extrema and first event context, and issue rate-limited warnings with global summaries. BUFFER is deliberate supported coverage, not unvalidated extrapolation.
- **INVALID:** outside HARD, wrong phase, nonfinite or nonpositive required thermodynamics, backend failure or unacceptable derivative quality. Return an explicit state failure; no usable flux/energy update may continue with this state.

A production table covering only the NORMAL rectangle cannot evaluate BUFFER by extrapolation. It must also have a certified buffer extension inside HARD, or declare BUFFER unsupported and fail. A reduced EOS calibrated in NORMAL must pass separate HARD/BUFFER validation. Different EOS models for cell and face states are prohibited. The project hard limits are a support obligation for a future implementation, not evidence that an unselected production model already supports them.

## Failure handling and diagnostics

No silent clamp of p,rho,T,e,h and no silent extrapolation. A failure record identifies state origin (cell/face/root/inlet), MPI rank/local/global identity, timestep/iteration, p,T,rho,native e, material masses/alpha, phase/backend status and the failed condition. Wrong-phase states are not masked and then treated as liquid.

Default future action is a **controlled fatal diagnostic** until a complete transactional timestep rollback exists. Protected timestep retry is allowed only with bounded retries and complete restoration of conservative fields, time, clouds/parcels, injection/source accumulators and random state; DPM evolution must not be applied twice. Reducing the timestep does not guarantee that a persistent physical excursion re-enters the project domain. Persistent failure stops and requires an explicit domain/model review. No automatic hard-limit expansion is allowed.

## M6A2 common-pressure bracket

At fixed intrinsic phase densities and composition, every trial of R(p)=mG*eG(rhoG,p,YG)+mL*eL(rhoL,p)-Eint must lie in a **connected joint admissible interval**, not just between the rectangular liquid p endpoints. Recovered TL(rhoL,p) must be inside HARD and phase-valid; the gas EOS and its temperature/species validity must also hold. At a fixed rho, the admissible pressure interval can be much smaller than 0.05–12 MPa. A marginal rho/e box is not sufficient.

Begin with a valid production-domain bracket where possible. Controlled expansion into certified BUFFER is allowed, but never outside HARD or across an invalid phase/temperature gap. Verify endpoint states, a sign change or valid endpoint root, finite derivatives, and continuity/monotonicity on the intended branch. The audited liquid (de/dp)|rho is positive; future gas and mixture residual conditions still require their own checks. If no valid bracket/root exists, fail explicitly. Do not clamp pressure to an endpoint and continue. This document implements no common-pressure solver.

## Cell and face reconstruction margins

PRODUCTION extends below the expected pressure scale by 88.330 kPa, above by 1.798579 MPa, below the expected temperature scale by 4.440696 K and above by 3.799552 K. These are chosen design allowances for nearby operating states, interpolation and reconstruction; they are not a proved bound on all KT face excursions.

The face-state buffer is HARD minus PRODUCTION: additional coverage reaches 0.05 MPa below and 4 MPa above the production pressure endpoints, and 10 K below/15 K above its temperature endpoints. Cell and face states use the same EOS and classification. A cell in NORMAL can reconstruct a face in BUFFER. If a face is INVALID, a later conservative reconstruction limiter/reduction to an admissible lower-order state may be attempted and diagnosed; if no consistent state is available, fail. Do not clip individual thermodynamic primitives to manufacture an admissible face. A BUFFER cell is diagnosed as well; the face buffer is not exclusive to faces.

## Pure-phase recovery is a separate gate

As alphaL approaches zero, rhoL=mL/alphaL is ill-conditioned; alphaG approaching zero has the analogous issue. Label this **PURE_PHASE_STATE_RECOVERY**, not ordinary EOS domain overflow. Future M6A2 must branch on phase presence before division or calling the absent-phase EOS, use declared alpha/mass tolerances, handle positivity, and preserve mass/energy residuals conservatively. No threshold value or runtime branch is implemented here.

Enlarging HARD, accepting enormous intrinsic density, table extrapolation or silently deleting small material masses must not hide bad alpha recovery. A well-conditioned present phase still obeys NORMAL/BUFFER/INVALID. Density/energy marginal ranges are useful diagnostics, not independently admissible Cartesian intervals.

## Energy translation

For e'=e+Delta and h'=h+Delta, define p'(rho,e')=p(rho,e'-Delta). Constant Delta changes neither physical PT/rho/phase nor Cp,Cv,c, (de/dp)|rho, (dp/drho)|e or (dp/de)|rho. HARD validity is checked on the corresponding physical state, not on the sign of translated e. Reference-library translation QA passes; the numerical gas/liquid/DPM ledger offset remains unresolved. Final solver Et/source accounting must be shifted consistently later.

Machine-readable contract: `fitting/liquid_eos_domain_contract.json`. Thirteen offline corner/wrong-phase/nonfinite/backend-failure classification checks pass in `fitting/M6A1b2A3_domain_policy_checks.json`; they do not implement runtime EOS validation or pressure recovery.
