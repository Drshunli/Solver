# 1. M6A2.2 status

COMPLETE / PASSIVE BUILD INTEGRATION. All19 stage gates pass. No physics activation, fake current-mesh Q, CFD or M5C.1 execution.

# 2. Libraries integrated

libRhosprayLiquidEOS.so (real frozen-EOS factory) and libRhosprayFiveEqThermo.so (actual recovery implementation), Foundation OF7 user libraries. ndecane_gibbs_v1 files and C_L unchanged. Factory defaults to production offset.

# 3. Solver link status

PASS. Solver Make/files compiles real species-map/runtime-bridge sources. No main-loop change or bridge instance. Executable has real bridge constructor/recovery symbols and a factory reference. BUILD INTEGRATION is complete; PHYSICS ACTIVATION is absent.

# 4. CoolProp runtime dependency check

PASS. ldd/readelf inspect the actual solver executable, both new libraries retained/resolved; no CoolProp and no missing library. No solver execution was used for dependency inspection.

# 5. fiveEqRuntimeBridge API

tryRecover(input,state,diagnostic,optionalGuess,context), recoverOrFail, recoverCellState and recoverFaceState. Dimensioned alpha/mass/momentum/energy -> scalar kernel input; kernel velocity -> Foam::vector. No fvMesh/field ownership, equation solve or interpolation.

# 6. Diagnostic/status API

Enum RecoveryStatus/RecoveryCode/PhaseValidity and numeric state/attempt information. Includes all13 requested codes plus INVALID_COMPOSITION and INVALID_DIMENSIONS. Availability flags prevent treating missing brackets/trial pressure as accepted roots. Lazy formatDiagnostic; no successful-path formatted string.

# 7. Species mapper

Runtime names -> canonical evaluator names, not runtime indices. Startup verifies supported unique names, molecular weights, JANAF range and coefficients. Actual reactions names and thermal.dat metadata tested, including permutation. Future caller supplies its loaded composition metadata snapshot.

# 8. Species ownership

Intrinsic gas Yi; future conserved mYi=mG*Yi=alphaG*rhoG*Yi, never rhoMix*Yi. No rhoYEqn change. Explicit local YG; production default air removed. Test air remains only in tests/benchmarks.

# 9. Composition validation policy

Finite Yi>=0, matching mechanism size, absolute sum tolerance1e-12. Accept tiny sum discrepancy unchanged; no explicit normalization/clipping. Invalid alpha-weighted Y rejected. Pure-liquid calls skip Y mapping/evaluation and support empty Y.

# 10. Final conservative-field ownership

Future mG/mL partial-mass equations, M/rhoU momentum equation, Et/rhoE energy equation; alphaL independent material field. DESIGN ONLY. See FIVE_EQ_FIELD_OWNERSHIP_FINAL.md for complete dimensions/single writers.

# 11. Derived-field ownership

alphaG=1-alphaL, rhoMix=mG+mL, U=M/rhoMix; recovery owns p,rhoG/rhoL,TG/TL,eG/eL,cG/cL/cMix,beta. No independent rhoMix equation or duplicate thermo writer. Absent phases explicitly tagged.

# 12. rho/rhoMix/rhoG naming decision

Choose explicit rhoMix in new core, eliminate generic rho there. Compatibility view only when a mixture subsystem requires it, with no separate evolution. Current rho remains legacy gas. DPM always uses rhoG and is excluded from mixture aliases.

# 13. p ownership

Future common local recovered mechanical pressure, spatially varying; no pEqn or independently solved phase pressures. Current legacy pressure updates unchanged.

# 14. TG/TL ownership

T/TG means gas temperature, TL liquid; no authoritative mixture T. Gas thermo becomes one-way recovered gas-property projection; not a writer of mixture energy/common pressure. No projection activated.

# 15. psi/cc/cMix ownership

psi gas-only compressibility, cc gas acoustics. Future model wave/CFL field cMix is distinct and recovered by Allaire. No cMix CFL/KT activation now.

# 16. DPM carrier-density contract

Hard future carrier rhoG/TG/common p. Never rhoMix. Current cloud coupling preserved; gas-only source/energy ledger remains a subsequent design gate.

# 17. Cell-state recovery API

recoverCellState attaches CELL context to exactly the same kernel and phase-presence logic; no mesh field reference or cell iteration.

# 18. Face-state recovery API

recoverFaceState attaches FACE context; same math. Caller supplies conservative reconstructed +/- Q and intrinsic Y. No reconstruction/interpolation/limiting in thermo.

# 19. Optional pressure-guess policy

Absent/nonfinite/outside bracket guesses deterministically fall back, never clamp a guess as physical pressure. Pure branches ignore it. Provided1.02p, negative, huge and NaN guesses tested. Correctness needs no history.

# 20. Reconstruction-invalid policy

Frozen caller ordering: reconstruct high-order conservative Q -> recover -> if invalid, caller may reconstruct lower order -> recover again -> controlled failure. No EOS variable clamp or reconstruction implemented.

# 21. Failure propagation policy

Physical STATE_FAILURE, dimension CONFIGURATION_FAILURE, coding/unknown INTERNAL_FAILURE. tryRecover returns false/reset INVALID output plus diagnostics. recoverOrFail throws formatted exception; no FatalError. Future caller records state/context/rank before controlled fatal; rollback not implemented.

# 22. Runtime counter design

Caller/thread/rank-owned pure/mixed/liquid, invalid, BUFFER, root/Newton attempt and fallback totals, max iterations, no-root counts. nNewtonIterations counts scalar root attempts including reverted fallback iterations. No mutable global singleton; merge is deterministic.

# 23. MPI diagnostic design

Future caller SUM totals/MAX iterations outside per-query path, preserving uint64 counts. No MPI calls or reductions in bridge/kernel. MPI execution not validated in this stage.

# 24. Boundary-condition implications

Future prescribed liquid mass flux/TL with responding pressure requires consistent Q boundary construction before recovery. Gas Yi is gas-phase data; pure-liquid Y need not be evaluated. No five-equation BC implemented.

# 25. Pure-gas regression contract

Future atomic-switch gate: alphaL=mL=0 equivalent legacy rho/rhoE/Y must recover same rhoG,p,TG,cG. Algebraic kernel/bridge checks pass; actual atomic-switch/CFD regression remains future work.

# 26. Current alpha-equation status

Current M2 provisional MULES/cAlpha equation unchanged. Not promoted to final Allaire transport; compatible alpha discretization/cAlpha OFF belongs to later design and activation.

# 27. Bridge unit-test results

32 checks,0 failures. Names/permutation/missing species/metadata, invalid and roundoff Y, vector/scalar/dimension conversion, phase routing, progress diagnostics, optional guesses, repeat/cell-face determinism and caller counters. M6A2.1 2087-check regression rerun:0 failures. Synthetic states only.

# 28. Library compile status

PASS. Both libraries built with Foundation OF7 wmake libso; Werror retained; final dependency scans/compiler logs clean. No system FOAM_SRC edits.

# 29. Solver compile status

PASS. Foundation OF7 wmake links the actual final solver, existing solver warning level retained. Real bridge sources compile, no main loop invocation. Make files changes reported separately in files.diff/options.diff.

# 30. Executable dependency audit

ldd.solver.txt/readelf.solver.txt, kernel dependency and bridge/kernel symbols recorded. Both libraries resolved, no CoolProp. Out-of-line bridge constructor references real production factory even though never instantiated by current main loop.

# 31. Protected-file hash audit

8 active physics/initialization/main-loop files byte-identical before/after; five equation headers unchanged. Make/files and Make/options intentionally changed for build/link only. Frozen production EOS metadata SHA256 d76f2085d1d22b45f8ddfd9a44501bdb0a0b6fc9fbb475d6446420d02412fd7e unchanged.

# 32. Active solver impact

NONE for equations, fluxes, thermo/field ownership, DPM and surface-tension semantics. Build/link dependency changes only. No mG/mL/Et fields, shadow p/TL/cMix, solver recovery call or CFD.

# 33. Remaining blockers

None for passive M6A2.2 completion. Runtime thermo projection, BCs, conservative transport, MPI/CFD and DPM energy ledger still unimplemented and must not be inferred validated from linking.

# 34. Exact M5C.1 start condition

Separate next-stage authorization/scope. Freeze reconstructed Q, face recovery order, cMix waves, phase mass/momentum/energy and ALE fluxes, Allaire alpha/nonconservative discretization, contact equilibrium and positivity/lower-order fallback before any atomic switch. M5C.1 NOT EXECUTED.

# 35. Updated milestone matrix

| Stage | Status |
|---|---|
| M0–M4 | COMPLETE |
| M5A/M5B/M5B.1 | COMPLETE |
| M6A1a/M6A1b-2A/2B | COMPLETE |
| M6A2.1 | COMPLETE / STANDALONE |
| M6A2.2 | COMPLETE / PASSIVE / NOT ACTIVE |
| M5C.1 | NEXT / NOT EXECUTED |
| M5C/M6B activation | NOT STARTED |
| M7 | NOT STARTED |
| M8 | PARTIAL / CURRENT DPM PRESERVED |
| M9–M15 | NOT STARTED |

STOP. No transport activation.
