# T3B-R2 capability matrix

| Model | 已通过的选定串行组件测试 | 完整范围能力标签 |
|---|---|---|
| coneInjection | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| sphereDrag | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| stochasticDispersionRAS | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| blobsSheetAtomization | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| ReitzKHRT | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| ORourke | native event / rollback / retry / 10 future steps PASS；保留原生物理限制 | BLOCKER |
| rebound | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| voidFraction | native event / rollback / retry / 10 future steps PASS | BLOCKER |

冻结 StableCommittedCarrierView::prepare 对全部单元恢复气相；任何气相缺失槽都会抛出 DPM_GAS_ABSENT_NO_CARRIER_VIEW。因此无法从真实混合 Q 启动小步合法接受、大步跨越不合法支持域拒绝、随后小步重试的全过程。本轮未修改该冻结 owner，未用全气相影子 Q、虚构气相、掩码、重归一化或最近气相外推绕过。

本机 ThermoParcelTrackingDataI.H 的 trackingData 构造函数先调用 cloud.thermo().thermo().Cp() 和 kappa()，随后才到 setCellValues 插值入口。因此现有局部 guard 不能证明拒绝发生在所有气相物性求值之前。

No FULL-SERIAL-TRANSACTION-SAFE or FULL-CONSERVATION-SAFE certification.
