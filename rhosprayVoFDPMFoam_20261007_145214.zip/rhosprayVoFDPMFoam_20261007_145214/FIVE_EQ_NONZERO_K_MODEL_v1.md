# FIVE_EQ_NONZERO_K_MODEL_v1

M6B.1-MC3 design candidate, 2026-10-05. **DESIGN ONLY. No active installation.**

Normative scope: a common-pressure, common-velocity, general-EOS five-equation candidate with pressure-equilibrium alpha response. Smooth structure is Kapila-type; the shock path below is a separately declared project numerical regularization, not an assertion of equivalence to a Baer–Nunziato relaxation limit. TG and TL may differ. No mass transfer, heat transfer, phase change, independent phase energy equations, or additional total-energy source.

The frozen EOS is ndecane_gibbs_v3, HARD p=0.05–12 MPa/TL=265–400 K, original 81 coefficients and C_L=369229.9537234281. Gas uses the current JANAF mixture. All qualified evaluations require original phase presence, gas validity and positive thermodynamic derivatives. This document does not extend EOS/phase validity or certify physical liquid phase stability.

## 1. State and equations

In one spatial dimension, independent mechanical state Q=(mG,mL,M,Et,a), a=alphaL, b=alphaG. In 3D M is a vector. The implemented P2 authority is one signed minority coordinate, not two independent fractions; reconstruct a and b using its original DD semantics. rho=mG+mL, U=M/rho, I=Et-|M|²/(2rho), rhoG=mG/b, rhoL=mL/a when the phase is present. Independent gas species are N−1 conservative mYi; the last species is the original residual mG−sum(mYi).

Fixed-mesh candidate:

\[
\partial_t m_k+\nabla\cdot(m_k U)=0,\quad k=G,L,
\]
\[
\partial_t M+\nabla\cdot(M\otimes U+p\mathbf I)=0,
\qquad \partial_t E_t+\nabla\cdot((E_t+p)U)=0,
\]
\[
D a/Dt=K\nabla\cdot U,
\qquad \partial_t a+\nabla\cdot(aU)=(a+K)\nabla\cdot U,
\]
\[
\partial_t(mY_i)+\nabla\cdot(mY_i U)=0.
\]

K=0 recovers the original material alpha equation. The source is added to original alpha transport; **K divU must not replace total Eulerian alphaDot**. Species composition is advected, never normalized to conceal an invalid trial. Exact ABSENT branches reduce to the appropriate single-phase Euler system and do not query absent-phase EOS.

## 2. Independent thermodynamic derivation

Write theta=divU and let K initially be unknown. From Dm_k=−m_k theta and mL=a rhoL, mG=b rhoG:

\[
D\rho_L=-\rho_L(1+K/a)\theta,
\qquad D\rho_G=-\rho_G(1-K/b)\theta.
\]

For a smooth local acoustic change at fixed phase entropy and gas composition, Dp_k=c_k² D rho_k. Put A_k=rho_k c_k² (units Pa). Pressure-rate equality requires

\[
A_L(1+K/a)=A_G(1-K/b),
\quad K_{PE}=ab\frac{A_G-A_L}{bA_L+aA_G}.
\]

K is dimensionless. This derivation uses separate phase EOS and separate phase isentropy; it assumes neither TG=TL nor isothermal phases. For the current stiff liquid AL>AG, K<0; compression theta<0 increases liquid volume fraction. Expansion reverses its sign.

Define H=bAL+aAG>0 and Aeff=AL AG/H. Then

\[
a+K=aA_G/H,\quad b-K=bA_L/H,\quad -a\le K\le b,
\]
\[
D\rho_k=-\rho_k(A_{eff}/A_k)\theta,\quad Dp=-A_{eff}\theta.
\]

Both phase densities compress under theta<0 and expand under theta>0; there is no sign-inconsistent compressive response. K is never clipped. These continuous bounds do not guarantee a finite explicit source step preserves alpha; the discrete P2/source admissibility check below is mandatory.

## 3. General-EOS/R1/energy proof

The actual EOS differential is

\[
de_k=\beta_k(dp-P_k d\rho_k),\quad
P_k=(\partial p/\partial\rho)_e,
\quad P_k=c_k^2-p/(\rho_k^2\beta_k).
\]

Gas composition terms vanish along a material acoustic perturbation because DY=0; their partials remain present in general R1 recovery. The liquid Gibbs potential provides Cp, Cv, beta and c; gas JANAF provides temperature-dependent Cp/Cv. No constant-gamma/stiffened-gas substitution is used in the checks.

For smooth flow, conservative momentum and total energy imply DI=−(I+p)theta. Differentiating I=mG eG+mL eL gives

\[
J Dp=-B_K\theta,\quad
J=m_G\beta_G+m_L\beta_L=b\xi_G+a\xi_L,\quad \xi_k=\rho_k\beta_k,
\]
\[
B_K=b\xi_G A_G+a\xi_L A_L+K(\xi_L A_L-\xi_G A_G).
\]

The thermodynamic identity above cancels the p contributions exactly; no p*K*theta or other Et source is required. Substituting the independently derived K gives B_K=J Aeff. Each phase then satisfies

\[
De_k=p/\rho_k^2\,D\rho_k,\quad Ds_k=0
\]

locally and smoothly. In the liquid, s=−g_T; the constant energy offset does not change entropy derivatives. Gas JANAF entropy is checked by its differential at fixed composition. This is not an entropy inequality or shock-admissibility proof. Shock entropy production/phase entropy partition, nonconservative regularization and convergence remain qualifications for subsequent work.

At a fixed trial Q/P2, pressure recovery remains

\[
R(p)=m_G e_G(m_G/b,p,Y)+m_L e_L(m_L/a,p)-I=0,
\quad R'(p)=m_G\beta_G+m_L\beta_L.
\]

K changes the alpha evolution, hence the trial intrinsic densities; it is not varied during the recovery solve and contributes no extra term to R'. Total Et remains the conservative trial value while phase energies rearrange through common-pressure recovery. Pure-phase recovery, HARD pressure intervals, EOS guards, current tolerance and species semantics are unchanged.

## 4. Sound speed and eigenstructure

Linearizing the actual total-energy/R1 pressure response yields

\[
c_K^2=B_K/(\rho J),\qquad
c_{PE}^2=A_{eff}/\rho=\frac1{\rho(a/A_L+b/A_G)}.
\]

At K=0, c_K equals the actual frozen Allaire implementation with xi weights. After installing nonzero K in a future round, that old sound speed MUST NOT remain in recovery primitives/characteristics/KT/CFL except in a mathematically identical qualified limit. Pure gas/liquid speeds equal their corresponding phase speeds.

Around a uniform 1D state, use W=(mG,mL,u,p,a). The primitive acoustic matrix relative to U is

\[
C=\begin{pmatrix}
0&0&m_G&0&0\\0&0&m_L&0&0\\
0&0&0&1/\rho&0\\0&0&A_{eff}&0&0\\0&0&-K&0&0
\end{pmatrix}.
\]

Its characteristic polynomial is lambda³(lambda²−cPE²); rank(C)=2 and its zero eigenspace has dimension three. Acoustic eigenvectors can be chosen (mG/lambda,mL/lambda,1,rho*lambda,−K/lambda). Thus the five speeds are U−cPE,U,U,U,U+cPE. N−1 species and transverse velocities add advected U modes. The primitive/conservative map is invertible in a qualified mixed state because rho>0,J>0; numerical conservative Jacobians independently test this statement.

With AL,AG,rho>0, cPE²>0 throughout the qualified state set. This is an algebraic implication of the existing EOS qualifications, not a newly proven EOS-wide phase certificate. The finite HARD grid is only a cross-check. Exact pure-phase manifolds use reduced Euler matrices; do not evaluate a singular absent-phase five-state coordinate map.

## 5. Binary64 formulas and limits

For mixed PRESENT/TRACE_PRESENT states, use both decoded P2 fractions, never `b=1-a` in binary64. Let scale=max(AL,AG), L=AL/scale, G=AG/scale, D=bL+aG. Freeze

\[
K=(ab)\frac{(A_G-A_L)/scale}{D}.
\]

Compute the difference before scaling: near AL=AG, subtracting two separately normalized moduli would lose avoidable relative information. For source-response diagnostics use aG/D and bL/D rather than cancelling a+K or b−K. Freeze the robust bulk formula

\[
A_{eff}=\begin{cases}A_L/(a+bA_L/A_G)&A_L\le A_G,\\
A_G/(b+aA_G/A_L)&A_L>A_G,\end{cases}\quad c^2=A_{eff}/\rho.
\]

Positive finite qualified moduli/densities are mandatory. Reject nonfinite/zero results from unrepresentable input ranges; do not clip or manufacture a sound speed. The current EOS range plus 1e-20 trace tests is representable. Arbitrary ratios beyond binary64 dynamic range are not thereby certified.

As a→0 at bounded positive phase states, K/a→(AG−AL)/AL and cPE→cG; as b→0, K/b→(AG−AL)/AG and cPE→cL. K itself tends to zero but K divided by a trace fraction need not; deleting a trace phase would destroy its compressive response. Exact pure branches set K=0, preserve signed P2 zero, and skip absent EOS. Original subnormal/presence failure policy remains; support for TRACE_PRESENT is not permission to erase phase mass.

## 6. First future implementation contract

**Time:** forward Euler, K evaluated from committed-cell thermodynamics at time n. No predictor, updated-state K, implicit source/face loop or midpoint re-evaluation in the first implementation. Predictor/midpoint would require conservative/P2/GCL stage consistency and separate authorization. Consistency takes precedence over higher order.

**Spatial source qualification:** first nonzero-K qualification uses the EXISTING piecewise-constant reconstruction option for all coupled face states, conservative transport and fraction transport. This is an explicit contract choice, not a new reconstruction formula. The original higher-order reconstruction remains unmodified and is NOT qualified for nonzero K until its within-cell path/source quadrature is separately derived and verified. K=0 recovers the original P2 operator for the selected reconstruction option, including its original DD numerator. Do not claim byte equality to a different reconstruction strategy.

**Face acoustic bounds:** compute cPE on the same qualified left/right states used by the conservative/alpha KT fluxes. Fixed-mesh normal speeds are Un±cPE. ALE speeds are Un−Umesh,n±cPE. Existing Kurganov/Tadmor weighting choices remain labeled explicitly; first path checks below use the Kurganov weights. No new model may silently mix old cA and cPE.

**Physical divergence:** for each oriented face, preserve the existing KT definitions

\[
q_L=U_L\cdot S_f-\phi_{mesh},\quad q_R=U_R\cdot S_f-\phi_{mesh},
\]
\[
a^+=\max(q_L+c_L|S_f|,q_R+c_R|S_f|,0),\quad
a^-=\min(q_L-c_L|S_f|,q_R-c_R|S_f|,0),
\]
\[
w_+=a^+/(a^+-a^-),\quad w_-=1-w_+,\quad
\phi_{phys}^*=w_+ U_L\cdot S_f+w_- U_R\cdot S_f,
\quad \theta_i=\sum_f\phi_{phys,f}^*/V_i.
\]

This equals phiRelStar+phiMesh. Use physical theta, not div(relative mesh flux). Face KT weights use cPE; cell K uses committed thermodynamics. There is no source/updated-face circular dependency.

**P2 increment:** with original DD transport numerator N_i^transport and V'=V^n+dt sum(phiMesh),

\[
\Delta a_{DD}=\frac{dt}{V'}\left(N_i^{transport}+K_i^n\sum_f\phi_{phys,f}^{*,n}\right).
\]

Construct the source contribution and its sum with original numerator using original DD operations; call signed-minority `advanced` once; reconstruct Q0 from that authority. The ALE source factor is dt*Vn/V'*K*theta, not bare dt*K*theta when the volume changes. Preserve signed zero/pure phase and exact ABSENT consistency. Conservative Q1..Q9 use only the original conservative trial/fluxes and volume; the dependent species post remains original. The source is never added to mG/mL/Et equations.

All built candidates must pass volume positivity, exact mass/species/P2/presence checks, raw and post native recovery, recorded strict-root status and actual representable time advance before atomic commit. No fraction clipping/projection/phase deletion/EOS expansion or tolerance relaxation. A model source bound alone does not guarantee a useful dt.

## 7. Nonconservative shock/path contract

The continuous alpha equation is nonconservative. Conservative mG,mL,M,Et retain standard Rankine–Hugoniot jumps. Alpha must not be judged by conservative RH `[au]=s[a]`; use

\[
-s[a]+[au]-\int_{\Phi}(a+K)\,du=0.
\]

Freeze a **KT-parameterized three-leg numerical path** for first-order qualification. For a face connecting committed thermodynamic endpoint states, let u*=phiPhysicalStar/|Sf| and use normal physical velocity throughout:

1. At left thermodynamic state, change normal uL to u*.
2. At fixed u*, interpolate a,p,TG,TL,Y between endpoint thermodynamic states. Fractions interpolate through original DD/P2 authority, gas composition through the simplex without normalization. Generate thermodynamic Q coordinates by the original EOS manifold. Tangential velocities can interpolate on this du_n=0 leg.
3. At right thermodynamic state, change u* to uR.

The middle leg has du=0, so exactly

\[
\mathcal I_K=K_L(u^*-u_L)+K_R(u_R-u^*),
\quad
\mathcal I_{a+K}=(a_L+K_L)(u^*-u_L)+(a_R+K_R)(u_R-u^*).
\]

The left-cell contribution is the first leg and the right-cell contribution the last leg. Summing the two faces of a piecewise-constant cell reproduces (a_i+K_i) div(phiPhysicalStar); thus the committed-cell source is an explicit discretization of this declared path rather than an unspecified `fvc::div(U)` append. Conservative equations have zero nonconservative path contribution. The original KT conservative alpha flux plus original K0/DD kinematic source and new K source implement this first-order contract. An alternative thermodynamic straight path with simultaneous velocity change generally gives a DIFFERENT integral and is NOT the frozen first model.

Thermodynamic middle-leg guards: liquid p/TL stay inside HARD; gas composition/temperature remain in a qualified continuous JANAF branch; gas Cp/Cv and both moduli positive. Native JANAF polynomial branch gaps are not bridged by pretending the EOS is continuous. A crossing/invalid path rejects and reports PATH_THERMO_BRANCH_OR_DOMAIN_BLOCKER; no extrapolation or undocumented fallback. For an absent phase at only one endpoint, inherit that phase's path temperature/composition from its present opposite endpoint, only for the path construction. Do not create committed mass or query a both-absent phase. Both-pure-same-phase faces reduce to that phase Euler system. Opposite-pure faces use each phase's present endpoint thermodynamics for its missing coordinate, with the same HARD/branch guards. Exact symbolic paths refer to EOS-consistent continuum states; native endpoint energy residuals remain numerical residuals under original R1 checks, never physical energy sources or state resets.

This is a specified numerical regularization, **not** a demonstrated physical relaxation/viscosity limit, entropy-stable path or mesh-refinement shock solution. KT wave weights depend on interface frame; arbitrary mesh/frame changes can change the selected numerical shock path. Coherent Galilean shifts of fluid AND mesh preserve the relative weights. Future RH/mesh studies must report this path dependence and compare against an independently chosen regularization if physical shock interpretation is required. Smooth MC2 gains do not certify it.

Mandatory M4 path tests: endpoint/reversal/equal-state consistency; path-source sum identity; contact exactness; domain/branch and pure/trace guards; first-order coupled microcases; recorded alpha jump integral plus conservative RH; no standalone alpha conservative-RH pass claim. Before production: shock convergence/path sensitivity, entropy admissibility, ALE/frame qualification and physical model suitability. Higher-order reconstructed alpha/velocity paths and within-cell quadrature require a new contract and tests before enabling them. Failure to satisfy the declared path/source identity is SHOCK_PATH_BLOCKER, not permission to use a cell source without interpretation.

The relevance of a declared regularization is supported by the original reduced-model paper's own shock caveat; formal path consistency alone also does not establish shock convergence: [Kapila et al. (2001), author institution record](https://experts.illinois.edu/en/publications/two-phase-modeling-of-deflagration-to-detonation-transition-in-gr-2/), [Castro, LeFloch, Muñoz-Ruiz & Parés (2008), author-hosted paper](https://philippelefloch.org/wp-content/uploads/2009/09/leflochpares-jcp2008.pdf). These sources motivate the qualification boundary; the project's formulas and first implementation contract are derived here.

## 8. ALE/GCL, contact, compression and expansion

Reynolds transport theorem and dV/dt=sum(phiMesh) give

\[
\frac{d(Vm_k)}{dt}+\sum_f m_{k,f}(U_f-U_{mesh,f})\cdot S_f=0,
\]
\[
\frac{d(VM)}{dt}+\sum_f\{M_f(U_f-U_{mesh,f})\cdot S_f+p_f S_f\}=0,
\]
\[
\frac{d(VE_t)}{dt}+\sum_f\{E_{t,f}(U_f-U_{mesh,f})\cdot S_f+p_f U_f\cdot S_f\}=0,
\]
\[
\frac{d(Va)}{dt}+\sum_f a_f(U_f-U_{mesh,f})\cdot S_f=V(a+K)\theta_{physical}.
\]

Species have the same ALE mass form. For uniform physical state and arbitrary mesh motion, sum physical flux=0, thetaPhysical=0 and the mesh transport cancels q*dV/dt in every conservative equation and alpha. Constant-state/GCL consistency is an algebraic proof, not an ALE implementation test. Spatially varying K requires the declared path interpretation at discontinuities.

At an exact material contact with constant p,U,rhoG,rhoL,Y, physical divU=0. K source vanishes, and the original alpha transport plus conservative phase masses/energy have the same coupled coefficients; recovery keeps p/U/densities to original numerical precision. Both phases and two temperatures need not coincide. MC2 Tmin contact's original native/strict rounding distinction is preserved, not upgraded to a strict guarantee.

Uniform compression/expansion obey Da=K theta, D rho_k=−rho_k Aeff/Ak theta, Dp=−Aeff theta. Gas DTG=(RG TG/CvG)D rhoG/rhoG; liquid DTL=(Dp−pL_rhoT D rhoL)/pL_T_rho. All rates reverse with theta's sign, with no singularity in qualified mixed/trace states. Local DsG=DsL=0 is verified for gas/liquid-dominant and trace states. Endpoint cooling/expansion can leave the frozen HARD set; that is model operating-set applicability, not permission to extend it.

## 9. CFL, temporal and recovery policy

Future fresh acoustic bounds use |Un−Umesh,n|+cPE on the SAME qualified coupled states. Keep existing CFL control values and time policy semantics; do not optimize TD1. Joint cap must include conservative mass/species/volume bounds AND total DD alpha transport+K source bound. With mesh volume rate D and total numerator N, require V'>0,

\[
aV+dt(aD+N)\ge0,\quad bV+dt(bD-N)\ge0,
\]

with exact presence consistency and original policy rather than clipped fractions. Candidate recovery is still authoritative; analytic/source/CFL bounds are not a proof of EOS-domain admissibility. Preserve actual time-addition monotonicity, pure/trace handling, atomic rollback/commit and existing TD1 tests.

Record native acceptance AND strict common-root existence for every trial and committed state, including endpoint distances, FLo/FHi/energyTol and tolerance-only counts. The target trajectory is strict interior; original R1 tolerance remains a numerical allowance, not EOS/model extension. BOUNDARY_ONLY classification is a design diagnostic requirement; it is not installed here, and cannot retroactively erase the 24 old tolerance-only micro baselines. Active binary64 remains; only robust algebra is designed. Precision-only primary repair remains unsupported.

## 10. Freeze and qualification boundary

The numerical budget in `fitting/integration/m6b1_mc3_nonzero_k_model_design_v1/error_budget.json` was written before formula/Jacobian evaluation. Independent checks include reduced pure Euler and mixed/trace five-state conservative Jacobians, step halving, phase EOS/R1 derivatives, local entropy rates, stable algebra, HARD-grid positivity, MC2 anchor formula bits, prescribed path partition and ALE/GCL identities.

MC3 completion freezes this design and documented numerical regularization; it does not run MC4 or grant production qualifications. NEXT ROUND ONLY: M6B.1-MC4-NONZERO-K-SERIAL-IMPLEMENTATION with this first-order/path/P2/cPE contract. MC4 still requires fresh M6B.0, TD1 rerun, shock/RH, DYN-CLOSURE prerequisites, high-Mach, ALE and path/entropy/operating-set qualification before subsequent production work. TD1/M6B.1/M6B remain PARTIAL and DYN-CLOSURE NOT AUTHORIZED in MC3.
