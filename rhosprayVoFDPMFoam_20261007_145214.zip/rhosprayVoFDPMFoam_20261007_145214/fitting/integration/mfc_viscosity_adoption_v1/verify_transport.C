#include "MFCNewtonianTransport.H"
#include "TransportViscosityFit.H"
#include <iostream>
#include <random>
#include <algorithm>
#include <fstream>
#include <sstream>
using namespace mfcTransport;
void check(bool ok){if(!ok)throw std::runtime_error("TRANSPORT_TEST_FAILED");}
bool near(long double a,long double b){return std::abs(a-b)<=1e-14L*std::max(1.L,std::max(std::abs(a),std::abs(b)));}
int main(){
    Coefficients c{2.25L,0};Tensor g{};g[0][0]=2;
    check(near(stress(g,c)[0][0],6));check(near(dissipation(g,c),12));
    g={};g[0][1]=2;check(near(stress(g,c)[0][1],4.5L));check(near(dissipation(g,c),9));
    g[1][0]=-2;check(near(dissipation(g,c),0)); // rigid rotation
    g={};for(unsigned i=0;i<3;++i)g[i][i]=2;
    check(near(dissipation(g,{2.25L,0}),0));
    check(near(dissipation(g,{2.25L,1}),36)); // pure bulk compression
    auto mix=mixture(.75L,.25L,{1,2},{5,6});
    check(near(mix.shear,2)&&near(mix.bulk,3));
    check(near(mixture(1,0,{1,2},{5,6}).shear,1));
    check(near(dimensionalFromInverseRe(4),.25L));
    check(near(dimensionalFromInverseRe(4,8),2));
    bool rejected=false;try{mixture(.8L,.3L,{1,0},{1,0});}catch(const std::invalid_argument&){rejected=true;}check(rejected);
    rejected=false;try{stress(g,{-1,0});}catch(const std::invalid_argument&){rejected=true;}check(rejected);
    std::mt19937 gen(73);std::uniform_real_distribution<double>d(-10,10);
    for(unsigned n=0;n<1000;++n){
        for(auto&row:g)for(auto&x:row)x=d(gen);
        c={std::abs(d(gen)),std::abs(d(gen))};auto tau=stress(g,c);
        long double div=g[0][0]+g[1][1]+g[2][2],norm=0;
        for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j){
            check(near(tau[i][j],tau[j][i]));
            auto dev=(g[i][j]+g[j][i])/2-(i==j?div/3:0);norm+=dev*dev;
        }
        const auto phi=dissipation(g,c);
        check(phi>=-1e-14L);check(near(phi,2*c.shear*norm+c.bulk*div*div));
    }
    std::ifstream input("transport_validation.csv");check(bool(input));
    std::string line;std::getline(input,line);unsigned count=0;double maxError=0;
    while(std::getline(input,line)){
        std::stringstream stream(line);std::string family,a,b,c0;
        std::getline(stream,family,',');std::getline(stream,a,',');std::getline(stream,b,',');std::getline(stream,c0,',');
        const auto T=std::stod(a),P=std::stod(b),truth=std::stod(c0);
        const auto fit=family=="air"?mfcTransportFit::air(T,P):mfcTransportFit::liquid(T,P);
        maxError=std::max(maxError,std::abs(fit/truth-1));++count;
    }
    check(count==4008&&maxError<=.001);
    rejected=false;try{mfcTransportFit::liquid(1000,3e6);}catch(const std::out_of_range&){rejected=true;}check(rejected);
    std::cout<<"PASS constitutive tests; 1000 independent dissipation identities; "<<count<<" transport validation points; max relative error "<<maxError<<"\n";
}
