"""Offline transport-only surrogate. Never substitutes the solver EOS."""
from pathlib import Path
import sys,json,hashlib,csv
import numpy as np
from numpy.polynomial import chebyshev as ch
S=Path(__file__).resolve().parent
sys.path.insert(0,str(S/'property_backend'))
import CoolProp
from CoolProp.CoolProp import PropsSI,PhaseSI,get_global_param_string
configs={'air':('Air',(600.,1200.),(1e5,1e7)),
         'liquid':('n-Decane',(280.,450.),(1e6,1e7))}
def viscos(fluid,T,P):
    return np.array([PropsSI('V','T',float(t),'P',float(p),fluid) for t,p in zip(np.ravel(T),np.ravel(P))]).reshape(np.shape(T))
def mapped(x,b):return 2*(x-b[0])/(b[1]-b[0])-1
output={'scope':'shear viscosity only; retained solver EOS; no PDE qualification claim',
        'CoolPropVersion':CoolProp.__version__,'CoolPropGitRevision':get_global_param_string('gitrevision'),
        'reference':'published CoolProp transport correlations; model-data surrogate, not new experimental calibration',
        'gasAssumption':'dry Air transport independent of retained species EOS; not a reacting-mixture viscosity model',
        'liquidAssumption':'C10H22 interpreted as n-decane',
        'bulkViscosity':{'value':0,'meaning':'explicit Stokes approximation; not inferred from shear data'},
        'acceptanceMaxRelativeSurrogateError':.001,'families':{}}
header=['#pragma once','#include <cmath>','#include <stdexcept>','namespace mfcTransportFit {']
validation=[]
rng=np.random.default_rng(20261007)
for name,(fluid,tb,pb) in configs.items():
    degree=8;nodes=np.cos(np.pi*(np.arange(20)+.5)/20)
    x,y=np.meshgrid(nodes,nodes,indexing='ij');T=tb[0]+(x+1)*(tb[1]-tb[0])/2;P=pb[0]+(y+1)*(pb[1]-pb[0])/2
    truth=viscos(fluid,T,P)
    # CoolProp calls compressed liquid at P>Pc,T<Tc 'supercritical_liquid'.
    if fluid=='n-Decane':assert all(PhaseSI('T',float(t),'P',float(p),fluid) in ('liquid','supercritical_liquid') for t,p in zip(T.ravel(),P.ravel()))
    design=ch.chebvander2d(x.ravel(),y.ravel(),[degree,degree]);coef=np.linalg.lstsq(design,np.log(truth).ravel(),rcond=None)[0].reshape(degree+1,degree+1)
    Tv=np.r_[rng.uniform(*tb,2000),tb[0],tb[0],tb[1],tb[1]];Pv=np.r_[rng.uniform(*pb,2000),pb[0],pb[1],pb[0],pb[1]]
    reference=viscos(fluid,Tv,Pv);fitted=np.exp(ch.chebval2d(mapped(Tv,tb),mapped(Pv,pb),coef))
    error=float(np.max(np.abs(fitted/reference-1)));assert error<=.001,(name,error)
    validation.extend((name,float(t),float(p),float(eta)) for t,p,eta in zip(Tv,Pv,reference))
    output['families'][name]={'fluid':fluid,'temperatureK':tb,'pressurePa':pb,'degree':[degree,degree],
      'logViscosityChebyshevCoefficients':coef.tolist(),'independentValidationPoints':len(Tv),
      'maxRelativeSurrogateError':error,'rangePaS':[float(reference.min()),float(reference.max())],
      'nominal':{'T':800 if name=='air' else 300,'P':3e6,'etaPaS':PropsSI('V','T',800 if name=='air' else 300,'P',3e6,fluid)},'status':'PASS_SURROGATE_ONLY'}
    header+=['inline double '+name+'(double T,double P) {',
      f'if(!std::isfinite(T)||!std::isfinite(P)||T<{tb[0]:.17g}||T>{tb[1]:.17g}||P<{pb[0]:.17g}||P>{pb[1]:.17g})throw std::out_of_range("TRANSPORT_FIT_ENVELOPE");',
      f'const double x=2*(T-{tb[0]:.17g})/{tb[1]-tb[0]:.17g}-1,y=2*(P-{pb[0]:.17g})/{pb[1]-pb[0]:.17g}-1;',
      'double a[9]={1,x},b[9]={1,y};for(int i=2;i<9;++i){a[i]=2*x*a[i-1]-a[i-2];b[i]=2*y*b[i-1]-b[i-2];}',
      'static const double c[9][9]={'+','.join('{'+','.join(format(v,'.17g') for v in row)+'}' for row in coef)+'};',
      'double sum=0;for(int i=0;i<9;++i)for(int j=0;j<9;++j)sum+=c[i][j]*a[i]*b[j];return std::exp(sum);','}']
header+=['}']
(S/'TransportViscosityFit.H').write_text('\n'.join(header)+'\n')
with (S/'transport_validation.csv').open('w',newline='') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['family','T','P','referenceEta']);w.writerows(validation)
output['status']='PASS_TRANSPORT_SURROGATE_ONLY'
output['generatedHeaderSHA256']=hashlib.sha256((S/'TransportViscosityFit.H').read_bytes()).hexdigest()
(S/'transport_fit_gate.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({name:{k:v for k,v in z.items() if k in ('maxRelativeSurrogateError','nominal')} for name,z in output['families'].items()}))
