#include "PeriodicViscousWork.H"
#include <iostream>
#include <random>
using namespace mfcTransport;
void require(bool ok){if(!ok)throw std::runtime_error("VARIABLE_WORK_GATE_FAILED");}
long double kinetic(long double rho,Velocity u){long double k=0;for(auto x:u)k+=rho*x*x/2;return k;}
int main(){
    constexpr unsigned N=16;const long double dx=1.L/N,dt=.002L,pi=std::acos(-1.L);
    std::mt19937 random(471);std::uniform_real_distribution<double>d(.1,2);
    long double worstIdentity=0,worstConservation=0,worstLinear=0;
    for(unsigned test=0;test<100;++test){
        WorkState a;a.rho.resize(N);a.energy.resize(N);a.velocity.resize(N);std::vector<Coefficients> face(N);
        for(unsigned i=0;i<N;++i){a.rho[i]=d(random);face[i]={d(random),d(random)};
            for(auto&u:a.velocity[i])u=d(random)-1;
            a.energy[i]=5+kinetic(a.rho[i],a.velocity[i]);}
        const auto z=periodicWork(a,face,dx,dt);Velocity dm{};long double de=0;
        for(unsigned i=0;i<N;++i){require(a.rho[i]==z.state.rho[i]);require(z.heat[i]>=0);
            const auto heat=z.state.energy[i]-a.energy[i]-kinetic(a.rho[i],z.state.velocity[i])+kinetic(a.rho[i],a.velocity[i]);
            worstIdentity=std::max(worstIdentity,std::abs(heat-z.heat[i]));
            require(std::abs(heat-z.heat[i])<1e-13L);
            de+=dx*(z.state.energy[i]-a.energy[i]);
            for(unsigned j=0;j<3;++j)dm[j]+=dx*a.rho[i]*(z.state.velocity[i][j]-a.velocity[i][j]);
        }
        worstConservation=std::max(worstConservation,std::abs(de));for(auto x:dm){require(std::abs(x)<1e-13L);worstConservation=std::max(worstConservation,std::abs(x));}
        require(std::abs(de)<1e-13L);worstLinear=std::max(worstLinear,z.relativeResidual);
    }
    // Independent Fourier eigenmode: compare normal and transverse diffusion.
    for(unsigned component=0;component<3;++component){
        WorkState a;a.rho.assign(N,2);a.energy.assign(N,10);a.velocity.resize(N);
        std::vector<Coefficients> face(N,{.3L,.2L});
        for(unsigned i=0;i<N;++i)a.velocity[i][component]=std::sin(2*pi*i/N);
        auto z=periodicWork(a,face,dx,dt);auto coefficient=component==0?.6L:.3L;
        auto lambda=4*coefficient/2/(dx*dx)*std::pow(std::sin(pi/N),2);
        auto amplification=(1-dt*lambda/2)/(1+dt*lambda/2);
        for(unsigned i=0;i<N;++i)require(std::abs(z.state.velocity[i][component]-amplification*a.velocity[i][component])<1e-13L);
    }
    std::cout<<"PASS 100 variable-coefficient vector work fixtures; 3 analytic Fourier modes; max cell work identity "<<double(worstIdentity)<<"; max conservation "<<double(worstConservation)<<"; max linear residual "<<double(worstLinear)<<"\n";
}
