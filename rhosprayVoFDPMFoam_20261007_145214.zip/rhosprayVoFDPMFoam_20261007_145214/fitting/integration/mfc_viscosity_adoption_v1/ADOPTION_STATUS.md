# MFC Newtonian transport adoption — independent implementation stage

User authorization 2026-10-07: adopt MFC viscous stress/transport parameters, retain existing EOS. Transport material assumptions: dry air and liquid C10H22, interpreted as n-decane. User authorized selection/fitting of conditions. This supersedes self-designed constant-mu transport as the intended production direction; it does not rewrite the prior frozen CRV3 qualification or authorize CRV3-3.

Pinned MFC master commit: 3dc5b2f2a1b1b9c25672aa09d4fbfabee21a91e8. Upstream viscous source and MIT license are preserved here. Independent C++ tensor law: tau = eta*(gradU+gradU^T) + (zeta-2*eta/3)*divU*I. Mixture eta/zeta are volume-fraction weighted. One-dimensional longitudinal coefficient is 4*eta/3+zeta. No clipping, fraction normalization or phase/species diffusion is introduced.

Transport-only surrogate uses CoolProp 8.0.0 published correlations: Air (Lemmon/Jacobsen 2004) and n-Decane (Huber/Laesecke/Xiang 2004). No new experimental fit or physical uncertainty claim. The library EOS is used offline to evaluate reference transport at T,p; solver pressure/energy/recovery EOS remains untouched. Air viscosity is an explicit dry-air approximation, not validated for fuel-bearing/reacting gas composition. Bulk viscosity is set to zero as the MFC default/Stokes approximation, not fitted from shear data.

Declared fitting windows selected to cover existing qualification temperatures/pressures with margin: air 600–1200 K, 0.1–10 MPa; liquid 280–450 K, 1–10 MPa. The temperature bounds exclude critical liquid behavior. Pressure above critical with temperature below critical is accepted as compressed liquid (CoolProp supercritical_liquid label). No extrapolation or silent clamping is permitted. Wider production envelopes require additional transport qualification.

Files: MFCNewtonianTransport.H (constitutive law), TransportViscosityFit.H (generated positive viscosity evaluators), fit_transport.py, transport_fit_gate.json, verify_transport.C. Validation covers analytical longitudinal compression, simple shear, rigid rotation, isotropic compression, two-phase mixing, invalid inputs, 1000 random stress/dissipation identities and 4008 separate reference evaluation points through compiled C++.

Status: constitutive/transport prototype only. Not connected to the active solver, not a new PDE/physical qualification PASS. Next work: separate variable-coefficient conservative viscous momentum/energy work operator, common-EOS heat/entropy check and native authority preservation, independent shear/longitudinal periodic checks, then a separately identified driver/case. Do not retrofit existing frozen executable or label existing mu3 results as material viscosity results. A true material-viscosity shock can be much thinner; mesh feasibility must be assessed before launching the existing shock-resolution ladder with physical transport.

Current legacy N4096 run and controller are preserved. Before any controller transition, check process/lock identity and retain all completed/unfinished evidence. New-model integration must use a distinct model identity and restart metadata; existing production restart remains NOT CERTIFIED.

Sources:
- https://github.com/MFlowCode/MFC/tree/3dc5b2f2a1b1b9c25672aa09d4fbfabee21a91e8
- https://mflowcode.github.io/documentation/equations.html
- https://coolprop.org/fluid_properties/fluids/Air.html
- https://coolprop.org/fluid_properties/fluids/n-Decane.html


## Variable-coefficient work kernel checkpoint

PeriodicViscousWork.H now evolves all three velocity components with spatially variable positive face shear/bulk coefficients. Coefficients are frozen at the substep anchor; this is a linearized verification operator, not a nonlinear time-accuracy qualification. Midpoint traction and shared energy work flux satisfy nonnegative cell heating and periodic momentum/total-energy conservation. 100 randomized variable-density/coefficient cases and 3 independent Fourier eigenmodes PASS; max cell work error4.33681e-19, conservation8.13152e-20, linear residual1.688e-19. Strict compile warning was corrected with braces; numerical law unchanged. Dense solve is explicitly limited to N<=256 small fixtures, not production. Native retained-EOS recovery, entropy and both-level authority integration are next and have NOT yet run.

material_resolution_screen_v1.json estimates scales using the old constant-mu reference only; nominal mixture longitudinal coefficient approximately3.22505e-4Pa.s, indicative thickness approximately1e-6m and order8million cells per1m for8-cell pressure thickness. This is a feasibility warning/diagnostic, not a new variable-coefficient BVP result or instruction to launch such a grid. Existing oldmu3 controller untouched.
