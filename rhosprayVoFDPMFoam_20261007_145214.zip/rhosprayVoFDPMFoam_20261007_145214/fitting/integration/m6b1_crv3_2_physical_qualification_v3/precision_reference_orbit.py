"""Independent 48-digit scalar Gibbs jets and common-state Newton.
SciPy shooting/alpha integration remains binary64. No Decimal verifier code,
native EOS or solver data is imported. Scalar Chebyshev jets are derived by
recurrence, independently of the verifier's differentiated coefficient arrays.
"""
from decimal import Decimal as Q,localcontext
import json
from independent_mixed_reference import MixedOrbit,LIQUID,META,GAS,ReferenceFailure

def q(x):return x if isinstance(x,Q) else Q.from_float(float(x))
def jets(x,n):
 a=[(Q(1),Q(0),Q(0)),(x,Q(1),Q(0))]
 for k in range(2,n):
  b,c=a[-1],a[-2]
  a.append((2*x*b[0]-c[0],2*b[0]+2*x*b[1]-c[1],4*b[1]+2*x*b[2]-c[2]))
 return a[:n]
class ScalarEOS:
 def __init__(self):
  d=json.loads(LIQUID.read_text());self.c=[[q(z) for z in row] for row in d['coefficients']]
  self.pc,self.ps,self.tc,self.ts=[q(d[k]) for k in ('pCenter','pScale','TCenter','TScale')]
  self.offset=q(json.loads(META.read_text())['C_L']);g=json.loads(GAS.read_text())
  self.g={k:[q(z) for z in x] if isinstance(x,list) else q(x) for k,x in g.items()}
 def liquid(self,p,t):
  if not Q(50000)<=p<=Q(12000000) or not Q(265)<=t<=Q(400):raise ReferenceFailure('JET_LIQUID_DOMAIN')
  a=jets((p-self.pc)/self.ps,len(self.c));b=jets((t-self.tc)/self.ts,len(self.c[0]))
  def at(i,j):return sum(v*a[k][i]*b[l][j] for k,row in enumerate(self.c) for l,v in enumerate(row))/self.ps**i/self.ts**j
  g,v,gt,pp,pt,tt=[at(i,j) for i,j in ((0,0),(1,0),(0,1),(2,0),(1,1),(0,2))]
  cp=-t*tt;cv=cp+t*pt*pt/pp;c2=-v*v/(pp-pt*pt/tt);beta=t*(-pt+tt*pp/pt)
  if min(v,cp,cv,c2,beta)<=0:raise ReferenceFailure('JET_LIQUID_THERMO')
  return dict(rho=1/v,e=g-t*gt+self.offset-p*v,c2=c2,beta=beta,entropy=-gt,v=v,vp=pp,vt=pt,ep=-t*pt-p*pp,et=cp-p*pt)
 def gas(self,r,p):
  t=p/(r*self.g['R'])
  if not self.g['Tlow']<=t<=self.g['Thigh']:raise ReferenceFailure('JET_GAS_DOMAIN')
  a=self.g['low'] if t<self.g['Tcommon'] else self.g['high'];cp=sum(a[i]*t**i for i in range(5));cv=cp-self.g['R']
  if min(cp,cv,r,p)<=0:raise ReferenceFailure('JET_GAS_THERMO')
  return dict(T=t,e=sum(a[i]*t**(i+1)/Q(i+1) for i in range(5))+a[5]-self.g['Hc']-self.g['R']*t,c2=p/r*cp/cv,beta=cv/(r*self.g['R']),entropy=a[0]*t.ln()+sum(a[i]*t**i/Q(i) for i in range(1,5))+a[6]-self.g['R']*p.ln())
class PrecisionOrbit(MixedOrbit):
 def __init__(self,eos):
  super().__init__(eos)
  with localcontext() as ctx:
   ctx.prec=48;self.high=ScalarEOS();p=Q(3000000);a=Q('.25');rg=p/(self.high.g['R']*Q(800));g=self.high.gas(rg,p);l=self.high.liquid(p,Q(300))
   mg=(1-a)*rg;ml=a*l['rho'];rho=mg+ml
   self.hrho,self.hwg,self.hwl=rho,mg/rho,ml/rho;self.he=self.hwg*g['e']+self.hwl*l['e'];self.hseed=(p,Q(300))
   self.rho0=float(rho);self.cs=float((1/(rho*((1-a)/(rg*g['c2'])+a/(l['rho']*l['c2'])))).sqrt())
 def at(self,u,alpha,speed):
  with localcontext() as ctx:
   ctx.prec=48;u,a,s=q(u),q(alpha),q(speed)
   if not Q(0)<a<Q(1) or not Q(0)<=u<s:raise ReferenceFailure('JET_MASS_PHASE')
   j=-self.hrho*s;rho=j/(u-s);mg=rho*self.hwg;ml=rho*self.hwl;rg=mg/(1-a);rl=ml/a;target=self.he+u*u/2-Q(3000000)*u/j
   p,t=self.hseed
   for k in range(16):
    g=self.high.gas(rg,p);l=self.high.liquid(p,t);fv=rl*l['v']-1;fe=self.hwg*g['e']+self.hwl*l['e']-target
    if abs(fv)<Q('1e-32') and abs(fe)<Q('1e-27'):break
    vp,vt=rl*l['vp'],rl*l['vt'];ep,et=self.hwg*g['beta']+self.hwl*l['ep'],self.hwl*l['et'];det=vp*et-vt*ep
    p+=(-fv*et+fe*vt)/det;t+=(-fe*vp+fv*ep)/det
   else:raise ReferenceFailure('JET_COMMON_ROOT_FAILED')
   self.hseed=(p,t);self.max_volume_constraint=max(self.max_volume_constraint,float(abs(fv)));self.max_energy_constraint=max(self.max_energy_constraint,float(abs(fe)/max(abs(target),Q(100000))))
   al,ag=rl*l['c2'],rg*g['c2'];k=a*(1-a)*(ag-al)/((1-a)*al+a*ag);J=mg*g['beta']+ml*l['beta'];tau=j*u+p-Q(3000000);cp2=1/(rho*(a/al+(1-a)/ag))
   self.states+=1
   z=dict(u=u,alpha=a,p=p,TG=g['T'],TL=t,rho=rho,rhoG=rg,rhoL=rl,mG=mg,mL=ml,Et=rho*(target+u*u/2),K=k,cPE=cp2.sqrt(),tau=tau,J=J,betaG=g['beta'],betaL=l['beta'])
   return {**{k:float(v) for k,v in z.items()},'entropyG':g['entropy'],'entropyL':l['entropy']}

 def solve_alpha(self,speed,ratio,rtol):
  from scipy.integrate import solve_ivp
  from types import SimpleNamespace
  end=self.p0*(ratio-1)/(self.rho0*speed)
  def rhs(t,increment):
   a=Q('.25')+q(increment[0]);z=self.at(end*t,a,speed)
   return [end*z['K']/(end*t-speed)]
  ode=solve_ivp(rhs,(0.,1.),[0.],method='DOP853',rtol=rtol,atol=rtol*1e-4,dense_output=True,max_step=.025)
  if not ode.success:raise ReferenceFailure('JET_ALPHA_ODE_FAILED')
  # Integrate the small alpha increment and retain its compensated boundary
  # sum for thermodynamics; rounding alpha itself must not corrupt tiny entropy.
  def sol(t):return [Q('.25')+q(ode.sol(t)[0])]
  post=self.at(end,sol(1.)[0],speed)
  return end,SimpleNamespace(sol=sol),post
