"""64-digit independent mixed reference verification, gated by 2C.

Binary64 orbit is an initial speed guess only. All thermodynamics, derivatives,
algebraic roots, speed secants, alpha/entropy/heating RK4 and thickness Simpson
quadrature below use Decimal. No native solver/EOS implementation is called.
"""
from decimal import Decimal as D, getcontext
from pathlib import Path
import argparse, json
from independent_mixed_reference import (S, GAS, LIQUID, META, IndependentEOS,
                                         MixedOrbit, ReferenceFailure, require_2c)

getcontext().prec = 64
ZERO, ONE, TWO = D(0), D(1), D(2)

def exact(x):
    return D.from_float(float(x))

def derivative(c):
    n = len(c)-1
    if n == 0:
        return [ZERO]
    out = [ZERO]*n
    out[n-1] = TWO*n*c[n]
    if n > 1:
        out[n-2] = TWO*(n-1)*c[n-1]
    for k in range(n-3,-1,-1):
        out[k] = out[k+2]+TWO*(k+1)*c[k+1]
    out[0] /= TWO
    return out

def differentiate(c, axis, scale):
    if axis == 0:
        columns = [derivative(list(x)) for x in zip(*c)]
        return [[v/scale for v in row] for row in zip(*columns)]
    return [[v/scale for v in derivative(row)] for row in c]

def basis(x, n):
    b = [ONE]
    if n > 1:
        b.append(x)
    for _ in range(2,n):
        b.append(TWO*x*b[-1]-b[-2])
    return b

class DecimalEOS:
    def __init__(self):
        data = json.loads(LIQUID.read_text())
        self.pc, self.ps = exact(data['pCenter']), exact(data['pScale'])
        self.tc, self.ts = exact(data['TCenter']), exact(data['TScale'])
        c = [[exact(v) for v in row] for row in data['coefficients']]
        cp, ct = differentiate(c,0,self.ps), differentiate(c,1,self.ts)
        self.polys = [c,cp,ct,differentiate(cp,0,self.ps),differentiate(cp,1,self.ts),differentiate(ct,1,self.ts)]
        self.offset = exact(json.loads(META.read_text())['C_L'])
        g = json.loads(GAS.read_text())
        self.gas = {k:[exact(v) for v in value] if isinstance(value,list) else exact(value)
                    for k,value in g.items()}

    def potential(self,p,t):
        a,b = basis((p-self.pc)/self.ps,9),basis((t-self.tc)/self.ts,9)
        return [sum(sum(v*b[j] for j,v in enumerate(row))*a[i]
                    for i,row in enumerate(c)) for c in self.polys]

    def liquid(self,p,t):
        if not (D(50000)<=p<=D(12000000) and D(265)<=t<=D(400)):
            raise ReferenceFailure('DECIMAL_LIQUID_DOMAIN')
        g,v,gt,pp,pt,tt = self.potential(p,t)
        cp=-t*tt;cv=cp+t*pt*pt/pp;c2=-v*v/(pp-pt*pt/tt)
        beta=t*(-pt+tt*pp/pt)
        if not (v>0 and cp>0 and cv>0 and c2>0 and beta>0):
            raise ReferenceFailure('DECIMAL_LIQUID_THERMO')
        return dict(v=v,rho=ONE/v,e=g-t*gt+self.offset-p*v,c2=c2,beta=beta,
                    entropy=-gt,T=t,vp=pp,vt=pt,ep=-t*pt-p*pp,et=cp-p*pt)

    def gas_state(self,rho,p):
        t=p/(rho*self.gas['R'])
        if not self.gas['Tlow']<=t<=self.gas['Thigh']:
            raise ReferenceFailure('DECIMAL_GAS_DOMAIN')
        a=self.gas['low'] if t<self.gas['Tcommon'] else self.gas['high']
        cp=sum(a[i]*t**i for i in range(5));cv=cp-self.gas['R']
        e=sum(a[i]*t**(i+1)/D(i+1) for i in range(5))+a[5]-self.gas['Hc']-self.gas['R']*t
        entropy=a[0]*t.ln()+sum(a[i]*t**i/D(i) for i in range(1,5))+a[6]-self.gas['R']*p.ln()
        if not (cp>0 and cv>0 and rho>0 and p>0):
            raise ReferenceFailure('DECIMAL_GAS_THERMO')
        return dict(T=t,rho=rho,e=e,c2=p/rho*cp/cv,beta=cv/(rho*self.gas['R']),entropy=entropy)

class DecimalOrbit:
    def __init__(self):
        self.eos=DecimalEOS();self.alpha0=D('.25');self.p0=D(3000000)
        self.g0=self.eos.gas_state(self.p0/(self.eos.gas['R']*D(800)),self.p0)
        self.l0=self.eos.liquid(self.p0,D(300))
        self.mg0=(ONE-self.alpha0)*self.g0['rho'];self.ml0=self.alpha0*self.l0['rho']
        self.rho0=self.mg0+self.ml0;self.wg=self.mg0/self.rho0;self.wl=self.ml0/self.rho0
        self.e0=self.wg*self.g0['e']+self.wl*self.l0['e']
        self.seed=(self.p0,D(300));self.maxVolume=self.maxEnergy=ZERO

    def at(self,u,alpha,speed):
        if not (ZERO<alpha<ONE and ZERO<=u<speed):
            raise ReferenceFailure('DECIMAL_ORBIT_MASS_PHASE')
        j=-self.rho0*speed;rho=j/(u-speed);mg=rho*self.wg;ml=rho*self.wl
        rg=mg/(ONE-alpha);rl=ml/alpha;target=self.e0+u*u/TWO-self.p0*u/j
        p,t=self.seed
        for _ in range(20):
            g,l=self.eos.gas_state(rg,p),self.eos.liquid(p,t)
            fv=rl*l['v']-ONE;fe=self.wg*g['e']+self.wl*l['e']-target
            if abs(fv)<D('1e-40') and abs(fe)<D('1e-35'):
                break
            vp,vt=rl*l['vp'],rl*l['vt']
            ep,et=self.wg*g['beta']+self.wl*l['ep'],self.wl*l['et']
            determinant=vp*et-vt*ep
            dp=(-fv*et+fe*vt)/determinant;dt=(-fe*vp+fv*ep)/determinant
            p+=dp;t+=dt
        else:
            raise ReferenceFailure('DECIMAL_COMMON_ROOT_NOT_CONVERGED')
        self.seed=(p,t);self.maxVolume=max(self.maxVolume,abs(fv))
        self.maxEnergy=max(self.maxEnergy,abs(fe)/max(abs(target),D(100000)))
        al,ag=rl*l['c2'],rg*g['c2'];k=alpha*(ONE-alpha)*(ag-al)/((ONE-alpha)*al+alpha*ag)
        tau=j*u+p-self.p0;J=mg*g['beta']+ml*l['beta']
        cp2=al*ag/(rho*((ONE-alpha)*al+alpha*ag))
        return dict(u=u,alpha=alpha,p=p,TG=g['T'],TL=t,rho=rho,rhoG=rg,rhoL=rl,cPE=cp2.sqrt(),mG=mg,mL=ml,
                    Et=rho*(target+u*u/TWO),K=k,tau=tau,J=J,betaG=g['beta'],betaL=l['beta'],
                    entropyG=g['entropy'],entropyL=l['entropy'])

    def integrate(self,speed,ratio,n,store=False):
        end=self.p0*(ratio-ONE)/(self.rho0*speed);h=ONE/n
        y=[self.alpha0,ZERO,ZERO,ZERO];nodes=[]
        self.seed=(self.p0,D(300))
        def rhs(f,q):
            z=self.at(end*f,q[0],speed);v=end*f-speed
            return [end*z['K']/v,end*z['betaG']*z['tau']/(z['TG']*z['J']*v),
                    end*z['betaL']*z['tau']/(z['TL']*z['J']*v),-end*z['tau']],z
        for i in range(n):
            f=D(i)/n;k1,z=rhs(f,y)
            if store:nodes.append((f,y[0],k1[0],z))
            k2,_=rhs(f+h/TWO,[a+h*b/TWO for a,b in zip(y,k1)])
            k3,_=rhs(f+h/TWO,[a+h*b/TWO for a,b in zip(y,k2)])
            k4,_=rhs(f+h,[a+h*b for a,b in zip(y,k3)])
            y=[a+h*(b+TWO*c+TWO*d+e)/D(6) for a,b,c,d,e in zip(y,k1,k2,k3,k4)]
        final,z=rhs(ONE,y)
        if store:nodes.append((ONE,y[0],final[0],z))
        return end,y,z,nodes

    def solve(self,ratio,guess,n):
        a=guess;b=guess*(ONE+D('1e-6'))
        fa=self.integrate(a,ratio,n)[2]['p']-self.p0*ratio
        for _ in range(12):
            fb=self.integrate(b,ratio,n)[2]['p']-self.p0*ratio
            if abs(fb)<D('1e-29'):
                break
            if fb==fa:raise ReferenceFailure('DECIMAL_SPEED_SECANT_DEGENERATE')
            next_speed=b-fb*(b-a)/(fb-fa);a,fa,b=b,fb,next_speed
        else:raise ReferenceFailure('DECIMAL_SPEED_NOT_CONVERGED')
        end,y,post,nodes=self.integrate(b,ratio,n,store=True)
        pre=nodes[0][3]

        def value(f):
            index=min(int(f*n),n-1);left,right=nodes[index],nodes[index+1]
            t=(f-left[0])*n
            alpha=(TWO*t**3-D(3)*t*t+ONE)*left[1]+(t**3-TWO*t*t+t)*left[2]/n
            alpha+=(-TWO*t**3+D(3)*t*t)*right[1]+(t**3-t*t)*right[2]/n
            return self.at(end*f,alpha,b)

        def crossing(key,fraction):
            target=pre[key]+fraction*(post[key]-pre[key]);lo,hi=ZERO,ONE
            increasing=post[key]>pre[key]
            for _ in range(110):
                m=(lo+hi)/TWO
                if (value(m)[key]<target)==increasing:lo=m
                else:hi=m
            return (lo+hi)/TWO

        def simpson(fun,lo,hi,panels):
            h=(hi-lo)/panels
            return h/D(3)*sum((ONE if i in (0,panels) else D(4) if i%2 else TWO)*fun(lo+D(i)*h) for i in range(panels+1))

        widths={}
        for key in ('p','u','alpha'):
            lo,hi=crossing(key,D('.1')),crossing(key,D('.9'))
            q1=simpson(lambda f:-end/value(f)['tau'],lo,hi,1024)
            q2=simpson(lambda f:-end/value(f)['tau'],lo,hi,2048)
            widths[key]={'value':q2,'lastTwoRelativeDifference':abs(q2-q1)/abs(q2)}
        entropy=[]
        for index,phase in ((1,'G'),(2,'L')):
            direct=post['entropy'+phase]-pre['entropy'+phase]
            entropy.append({'phase':phase,'integral':y[index],'direct':direct,
                            'relativeError':abs(y[index]-direct)/max(abs(direct),D('1e-30'))})
        j=-self.rho0*b
        mom=abs(j*end+post['p']-pre['p'])/self.p0
        e0=pre['Et']*(pre['u']-b)+pre['p']*pre['u'];e1=post['Et']*(post['u']-b)+post['p']*post['u']
        energy=abs(e1-e0)/max(abs(e0),ONE)
        errors=[mom,energy,abs(post['tau'])/self.p0,self.maxVolume,self.maxEnergy,
                *(z['relativeError'] for z in entropy),*(z['lastTwoRelativeDifference'] for z in widths.values())]
        passed=max(errors)<=D('1e-8') and all(z[3]['tau']<0 for z in nodes[1:-1]) and y[3]>0 and all(z['integral']>0 for z in entropy)
        result={'digits':64,'panels':n,'pressureRatio':ratio,'speed':b,'upstream':pre,'downstream':post,
                'entropy':entropy,'heatingIntegral':y[3],'thicknessPerMu':widths,
                'residuals':{'momentumRH':mom,'energyRH':energy,'endpointTauRelative':abs(post['tau'])/self.p0,
                             'commonVolume':self.maxVolume,'commonEnergy':self.maxEnergy},
                'referenceMathGatePassed':passed,'nativeRecoveryCalls':0}
        return result,nodes,value

def serial(x):
    if isinstance(x,D):return str(x)
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,list):return [serial(v) for v in x]
    return x

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--family',choices=['weak','moderate'],required=True);args=ap.parse_args()
    require_2c()
    path=S/'independent_references'/f'{args.family}.json'
    initial=json.loads(path.read_text())
    if initial['status']!='PASS':raise ReferenceFailure('BINARY64_INITIAL_ORBIT_FAILED')
    ratio=D('1.05') if args.family=='weak' else D('1.25')
    guess=exact(initial['runs'][-1]['speed']);runs=[]
    for n in (256,512):
        result,nodes,value=DecimalOrbit().solve(ratio,guess,n);runs.append(result);guess=result['speed']
    changes={'speed':abs(runs[1]['speed']-runs[0]['speed'])/runs[1]['speed']}
    for key in ('alpha','p','u','TG','TL'):
        changes[key]=abs(runs[1]['downstream'][key]-runs[0]['downstream'][key])/abs(runs[1]['downstream'][key])
    for key in ('p','u','alpha'):
        changes['width_'+key]=abs(runs[1]['thicknessPerMu'][key]['value']-runs[0]['thicknessPerMu'][key]['value'])/runs[1]['thicknessPerMu'][key]['value']
    # Compare independently evaluated binary64 states at the same orbit nodes;
    # do not use interpolation error from the exported spatial profile here.
    binary=MixedOrbit(IndependentEOS());end,ode,_=binary.solve_alpha(float(guess),float(ratio),2e-10)
    comparisons={key:ZERO for key in ('alpha','p','u','TG','TL','mG','mL','Et')}
    for f,alpha,_,high in nodes[::8]:
        low=binary.at(end*float(f),float(ode.sol(float(f))[0]),float(guess))
        for key in comparisons:
            comparisons[key]=max(comparisons[key],abs(exact(low[key])-high[key])/max(abs(high[key]),ONE))
    for key in ('p','u','alpha'):
        a=exact(initial['runs'][-1]['thicknessPerMu'][key]);b=runs[-1]['thicknessPerMu'][key]['value']
        comparisons['width_'+key]=abs(a-b)/abs(b)
    passed=all(r['referenceMathGatePassed'] for r in runs) and max(changes.values())<=D('1e-8') and max(comparisons.values())<=D('1e-8')
    output={'status':'PASS' if passed else 'FAIL','family':args.family,'precisionDigits':64,
            'independence':'Decimal Gibbs/JANAF, common p/T Newton, speed secant, RK4 alpha/entropy/heating and Simpson thickness; nativeRecoveryCalls=0',
            'runs':runs,'lastTwoPanelDifferences':changes,'binary64VsDecimalRelativeDifferences':comparisons}
    (S/'independent_references'/f'{args.family}_decimal64.json').write_text(json.dumps(serial(output),indent=2)+'\n')
    print(json.dumps(serial({'status':output['status'],'family':args.family,'lastTwoPanelDifferences':changes,'binary64VsDecimalRelativeDifferences':comparisons}),indent=2))
    if not passed:raise ReferenceFailure('DECIMAL64_REFERENCE_GATE_FAILED')

if __name__=='__main__':
    try:main()
    except ReferenceFailure as error:
        import sys
        print('BLOCKER',error,file=sys.stderr);raise SystemExit(1)
