# Authorized autonomous continuation

This stage is separate from frozen physical v2 and the completed M1 migration evidence. No active PDE/EOS/K/cPE/TD1 source has been changed for this preparation.

`resume_physical.py` is a finite, resumable Windows controller using the bundled Python and the compiled WSL native harness. It holds `controller.lock` and records `autonomous_progress.json`. Do not launch a second controller while that PID exists. It waits for the complete 2C progress gate; this wait does not execute any reference EOS state or physical PDE case. The native harness independently enforces the same gate.

After the gate passes it rechecks frozen identity, verifies integrity, creates a new CRC/SHA checked 2C COMPLETE evidence archive without overwriting historical archives, and resumes physical work. It computes independent binary64 and Decimal64 mixed references, verifies the frozen Decimal90 original pure-gas reference, exports conservative orbit fixtures, runs mandatory fixed-mu grids plus adaptive resolution, runs both frozen mu routes with independent fine-grid checks, and records free positive-p fits and engineering audits. Original full-entry endTime remains 0.00055. Controlled cases use the predeclared window/time in `controlled_window_plan.json`.

`preparation_gate.json` certifies only compilation, execution gating and synthetic algorithm checks. No physical result is claimed by it. The fit test recovers known O0/C/p and explicitly rejects a constant series as an identified exponent. Independent reference thickness and PDE thickness both participate in the resolution gate, so numerical broadening cannot substitute for resolving the physical shock.

The existing 30-minute thread continuation should inspect these files and current process liveness first. While either the original actual entry, strict replay, or this controller is running normally, preserve it and avoid duplicate jobs or repeated unchanged notifications. On a reference/tool/native/measurement failure, preserve all evidence and diagnose its actual class before assigning physical model error. Failed or unfinished case directories are not overwritten or silently restarted.

After collection, inspect `route_fit_audit.json`. If limits or engineering observables are unresolved, continue the explicitly authorized refinement/diagnosis rather than declaring COMPLETE. Finish the separate full-original-case assessment, 36-chapter physical v3 report, final source identity and evidence sealing. Only fully qualified CRV3-2 can be marked COMPLETE. Then disable the existing continuation and stop. CRV3-3 is NOT AUTHORIZED.


## Reference precision repair v2 activated

Historical controller PID 1940 exited on the preserved binary64 weak-reference failure. Refined weak reference PASS uses unchanged 1e-8 math budget; max liquid entropy residual 7.350795673875591e-10. Two monotone profiles compared at shared physical coordinates have p/u/alpha jump-normalized differences 1.5832483768463232e-13 / 1.5441705355318426e-13 / 1.632675391697539e-13. The far-tail raw coordinate difference divided by pressure width is 1.8525149762305051e-7 and integration roundoff warning remains preserved; it is not relabeled accurate to 1e-8. The qualified profile comparison measures actual field observables at shared coordinates. New primary runs enforce this profile gate.

Primary precision is SciPy binary64 shooting/increment integration/quadrature with independent Decimal48 scalar Gibbs jets/common-state Newton, not the failed original binary64 thermodynamics. Independent Decimal64 differentiated-coefficient/RK4 verifier remains separate. Failed original active files were moved into reference_failure_weak_binary64_v1/original_active_files, with prior snapshot and hashes unchanged; v2 result/profile files remain separately available in independent_references_v2. Preparation manifest before refinement is retained, fresh algorithm/source-identity checks PASS and include precision_reference_orbit.py. No PDE/EOS production source, budgets, 2C evidence or controlled measurement plan changed.

One resumed controller PID 30596 (log.controller_precision_repair_v2) is executing the full gated independent Decimal64 weak verification, followed by moderate references and mandatory fixed-mu/two-route grids. Its current PID/status is authoritative in autonomous_progress.json/controller.lock; do not duplicate historical PID 1940 or finished reference PID 19256. No physical qualification PASS is claimed from the repaired primary reference alone. CRV3-2 remains INCOMPLETE, production restart NOT CERTIFIED, CRV3-3 NOT AUTHORIZED.


## 2026-10-07 — mathematical references PASS; controlled PDE running

Weak and moderate primary references and independent Decimal64 256/512-panel checks PASS with the frozen 1e-8 mathematical budgets; original Decimal90 pure-gas reference reused with frozen identity. reference_suite_gate.json is mathematical reference qualification only, not PDE/engineering qualification.

Controller 30596 exited because its sandboxed WSL child received E_ACCESSDENIED before numerical execution. The entire launch case, controller failure/log and identity records are retained with SHA manifest in wsl_launch_failure_v1. No PDE process or accepted step existed.

The separately authorized launch reached native input loading, then stopped at BAD_INDEPENDENT_PROFILE_COLUMNS because Windows CSV export produced a CRLF header and the native loader compared Et\r to Et. No accepted state/step was executed. The case, exported inputs, controller source/manifest and failure records are preserved in profile_csv_launch_failure_v2. Only Python CSV export line terminators were changed to LF; CSV-decoded numeric rows and fields are identical. Native executable/source, EOS/PDE/TD1, mu, grids, endTime, engineering and numerical budgets are unchanged. Fresh preparation identity/algorithm checks PASS. No frozen executable was recompiled.

One authorized controller PID 30924 (log.controller_lf_export_v4) is live. WSL native PID 891 is running weak_N256_mu3 and observed step25 at time8.3681071367399892e-5 toward controlled endTime0.0011660346017486967. Subsequent runs remain governed by frozen reference/native/spatial/two-route gates. Check current progress/lock rather than historical PID1940/30596. CRV3-2 physical qualification remains INCOMPLETE; production restart NOT CERTIFIED; CRV3-3 NOT AUTHORIZED. Historical failure evidence and 2C completion archive remain preserved.


## 2026-10-07 — reference entropy diagnostic sign correction

For a right-moving wave, j=-rho_upstream*speed<0 and entropy increases from upstream to downstream. Nonnegative integrated production is -j*(s_downstream-s_upstream), equal to +speed*sum(m_phase_upstream*delta_s_phase). The controller previously used -rho*speed*sum(weight*delta_s), incorrectly recording a negative reference production and dividing relative error by that negative quantity. Mathematical reference entropy increments and native positive production are unchanged.

The raw reference suite/controller/source manifest are preserved in entropy_reference_sign_erratum_v1. Only controller reference-rate sign is corrected, and nonpositive reference work/entropy rates are rejected before calculating engineering error. All PDE/EOS/TD1/executable/grid/mu/endTime/hard budgets are unchanged. Production restart NOT CERTIFIED. No physical engineering PASS is claimed.

Existing weak N256 and N512 runs reached controlled endTime and passed native hard gates, but both are independently underresolved and heating/entropy rates differ by about29.74%; they do not pass spatial qualification. N1024 native run remains live. The controller's next source identity check will stop it at the normal completed-case boundary; a finite observer will preserve that expected identity-stop record, verify the completed result, refresh only tool identity checks, and resume one authorized controller. No current native run is stopped or repeated. Completed case evidence will be reused by identity rather than overwritten. If the live case itself fails, the observer must not resume it.


## 2026-10-07 07:06 +0800 — diagnostic handoff complete; adaptive fixed-mu grid running

N1024 completed normally at exact controlled endTime with1394 accepted steps and native hard gates PASS. Expected source-identity stop at the case boundary is preserved in entropy_reference_sign_erratum_v1/boundary_*; the finite observer refreshed tool identity and resumed one controller PID36048. Observer exited; no numerical process was stopped and completed case results were reused by identity. Corrected weak reference entropy rate is positive7.338659964058221. All currently frozen preparation file hashes agree.

All three mandatory weak mu3 grids N256/512/1024 are now complete. N256/512 fail the independent reference/PDE resolution minimum; N1024 meets it. However last-two-grid heating/entropy-rate changes are28.9554%/28.9560%, above the frozen2% convergence threshold. N1024 measured heating/entropy rates differ from reference by70.3730%/70.3733%; it is FAIL_MEASUREMENTS_REQUIRES_CLASSIFICATION, not a model-error conclusion before spatial convergence. Detailed scoped audit is weak_fixed_mu3_mandatory_grid_audit_v1.json. No spatial/physical PASS is claimed.

Existing controller/native PID2580 now run adaptive N2048, same mu3, reference and controlled endTime. CRV3-2 remains INCOMPLETE; 2C COMPLETE archive unchanged; production restart NOT CERTIFIED; CRV3-3 NOT AUTHORIZED.
