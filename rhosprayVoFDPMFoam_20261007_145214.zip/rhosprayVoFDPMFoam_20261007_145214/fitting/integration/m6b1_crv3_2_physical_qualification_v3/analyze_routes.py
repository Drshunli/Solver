"""Free positive-p fits and audits; never turn missing evidence into COMPLETE."""
from pathlib import Path
import json,sys,math,hashlib
S=Path(__file__).resolve().parent;R=S.parents[2]
sys.path.insert(0,str(R/'fitting/reference_backend'))
import numpy as np
from scipy.optimize import minimize_scalar

def fit(mu,observations):
    x=np.asarray(mu,dtype=float);y=np.asarray(observations,dtype=float)
    assert len(x)>=3 and len(set(x))==len(x) and np.all(x>0) and np.all(np.isfinite(y))
    scale=max(float(np.max(np.abs(y))),1e-30)
    base=float(y[-1]);normalized=(y-base)/scale
    variation=float(np.ptp(y))/scale
    if variation<=64*np.finfo(float).eps:
        return {'status':'EXPONENT_NOT_IDENTIFIABLE_CONSTANT_WITHIN_BINARY64_RESOLUTION',
                'O0IntervalObserved':[float(min(y)),float(max(y))],'p':None,
                'scope':'not a successful free-p fit; requires a separate convergence/uncertainty argument'}
    z=x/np.max(x)
    def solve(logp):
        p=math.exp(logp);v=z**p
        matrix=np.column_stack([np.ones(len(x)),v])
        coef,_,rank,_=np.linalg.lstsq(matrix,normalized,rcond=None)
        if rank<2:return math.inf,None,None
        residual=normalized-matrix@coef
        return float(residual@residual),coef,residual
    lo,hi=math.log(1e-6),math.log(512)
    candidates=[]
    grid=np.linspace(lo,hi,193)
    for a,b,c in zip(grid[:-2],grid[1:-1],grid[2:]):
        if solve(b)[0]<=min(solve(a)[0],solve(c)[0]):
            opt=minimize_scalar(lambda t:solve(t)[0],bounds=(a,c),method='bounded',options={'xatol':1e-12})
            candidates.append((opt.fun,opt.x))
    if not candidates:return {'status':'NO_INTERIOR_POSITIVE_P_MINIMUM','p':None,'variationRelative':variation}
    _,logp=min(candidates);rss,coef,residual=solve(logp)
    o0=base+scale*float(coef[0]);p=math.exp(logp)
    curvature=solve(logp-.01)[0]+solve(logp+.01)[0]-2*rss
    identifiable=curvature>256*np.finfo(float).eps*variation**2
    passed=(logp>lo+.05 and logp<hi-.05 and max(abs(residual))<=.02 and identifiable)
    return {'status':'PASS_FIT_ONLY' if passed else 'FIT_NOT_QUALIFIED','O0':o0,'p':p,
            'C':scale*float(coef[1])/float(np.max(x))**p,
            'fitResidualRelativeMax':float(max(abs(residual))),
            'lastLevelRelativeToO0':abs(y[-1]-o0)/max(abs(o0),1e-30),
            'points':len(x),'variationRelative':variation,
            'localProfileCurvature':curvature,'exponentIdentifiabilityGate':identifiable,
            'algorithm':'variable projection of O0 and C with independently optimized free p>0; interior minimum required'}

def main():
    p=S/'physical_measurements.json';data=json.loads(p.read_text())
    out={'status':'INCOMPLETE / FITS AND ENGINEERING AUDIT','families':{},
         'measurementSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'physicalQualificationComplete':False,
         'CRV3_3':'NOT AUTHORIZED','target':.02,'hardLimit':.05}
    all_pass=True
    for family,z in data.items():
        routes={}
        all_pass=all_pass and z['fixedMu']['analysis']['engineeringMeasurementGate']=='PASS'
        for route,rows in z['routes'].items():
            if len(rows)<3:
                routes[route]={'status':'INSUFFICIENT_ELIGIBLE_MU_LEVELS'};all_pass=False;continue
            assert all(r['spatialProof']['status']=='PASS' for r in rows)
            keys=set.intersection(*(set(r['analysis']['observables']) for r in rows))
            fits={}
            for key in sorted(keys):
                tail=rows[-3:];f=fit([r['mu'] for r in tail],[r['analysis']['observables'][key] for r in tail])
                if len(rows)>3:f['lastFourPointAudit']=fit([r['mu'] for r in rows[-4:]],[r['analysis']['observables'][key] for r in rows[-4:]])
                f['eligibility']='all included points independently spatially qualified and reference/PDE shock widths resolved'
                fits[key]=f
            last=rows[-1];last2=rows[-2]
            changes={}
            for key in keys:
                a=last2['analysis']['observables'][key];b=last['analysis']['observables'][key]
                changes[key]=abs(a-b)/abs(b) if b else None
            routes[route]={'status':'AUDIT_RECORDED','fits':fits,'lastTwoMuChanges':changes,
                           'lastLevelEngineering':last['analysis'],'lastTwoLevelsSpatialProofs':[last2['spatialProof'],last['spatialProof']]}
            all_pass=all_pass and last['analysis']['engineeringMeasurementGate']=='PASS'
        agreement={}
        if all('fits' in routes.get(k,{}) for k in ('A','B')):
            for key in sorted(set(routes['A']['fits'])&set(routes['B']['fits'])):
                a,b=routes['A']['fits'][key],routes['B']['fits'][key]
                if a['status']=='PASS_FIT_ONLY' and b['status']=='PASS_FIT_ONLY':
                    e=abs(a['O0']-b['O0'])/max(abs(a['O0']),abs(b['O0']),1e-30)
                    qualified=e<=.05 and max(a['lastLevelRelativeToO0'],b['lastLevelRelativeToO0'])<=.05
                    four_errors=[]
                    for fit_result in (a,b):
                        four=fit_result.get('lastFourPointAudit')
                        if four:
                            if four['status']!='PASS_FIT_ONLY':qualified=False
                            else:
                                difference=abs(four['O0']-fit_result['O0'])/max(abs(fit_result['O0']),1e-30)
                                four_errors.append(difference);qualified=qualified and difference<=.05
                    agreement[key]={'status':'PASS' if qualified else 'FAIL','relativeO0Difference':e,
                                    'lastThreeVsFourO0Differences':four_errors,
                                    'lastLevelRelativeToO0':[a['lastLevelRelativeToO0'],b['lastLevelRelativeToO0']]}
                else:agreement[key]={'status':'UNRESOLVED_FREE_P_LIMIT','relativeO0Difference':None}
                all_pass=all_pass and agreement[key]['status']=='PASS'
        else:all_pass=False
        out['families'][family]={'fixedMu':z['fixedMu']['analysis'],'routes':routes,'twoRouteO0Agreement':agreement}
    out['status']='PASS_SCOPED_FIT_AND_ENGINEERING_MEASUREMENTS_REQUIRES_FINAL_FULL_AUDIT' if all_pass else 'INCOMPLETE / CONVERGENCE_OR_ENGINEERING_EVIDENCE_REQUIRES_CLASSIFICATION'
    (S/'route_fit_audit.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(out['status'])
if __name__=='__main__':main()
