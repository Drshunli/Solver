"""Finite, resumable physical qualification runner. No CRV3-3 authorization.

Wait for the full 2C gate, generate independent references, then perform the
frozen spatial/mu routes. This runner collects evidence; it cannot declare
CRV3-2 COMPLETE without the separate full report and audit.
"""
from pathlib import Path
import csv, hashlib, json, math, os, subprocess, sys, time, traceback
S=Path(__file__).resolve().parent
R=S.parents[2]
C=S.parent/'m6b1_crv3_2c_representation_v2_implementation_v1'
OLD=S.parent/'m6b1_crv3_2_physical_qualification_v2'
GATE=C/'qualification_progress.json'
FIELDS=['xiPerMu','u','alpha','p','TG','TL','mG','mL','Et']

class QualificationFailure(RuntimeError):pass

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,z):
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(z,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def progress(status,**kw):
    write(S/'autonomous_progress.json',dict(status=status,controllerPID=os.getpid(),
          updatedAt=time.strftime('%Y-%m-%dT%H:%M:%S%z'),physicalQualificationComplete=False,
          CRV3_3='NOT AUTHORIZED',**kw))
def verify_prepared_identity():
    frozen=read(S/'preparation_gate.json')
    for name,expected in frozen['files'].items():
        if sha(S/name)!=expected:raise QualificationFailure('PREPARED_INPUT_OR_EXECUTABLE_CHANGED: '+name)
def wsl(p):
    p=str(p.resolve()).replace('\\','/');return '/mnt/'+p[0].lower()+p[2:]
def run_python(script,family):
    log=S/f'log.{script.stem}.{family}'
    with log.open('wb') as f:
        z=subprocess.run([sys.executable,'-X','utf8',str(script),'--family',family],stdout=f,stderr=subprocess.STDOUT)
    if z.returncode:raise QualificationFailure(f'REFERENCE_IMPLEMENTATION_OR_MATH_GATE_FAILED: {log.name}; inspect before classifying physical model')

def prepare_references():
    refs={}
    for family in ('weak','moderate'):
        progress('INDEPENDENT_REFERENCE_RUNNING',family=family)
        a=S/'independent_references'/f'{family}.json'
        b=S/'independent_references'/f'{family}_decimal64.json'
        if not a.exists():run_python(S/'independent_mixed_reference.py',family)
        if read(a)['status']!='PASS':raise QualificationFailure('INDEPENDENT_BINARY64_REFERENCE_FAILED')
        if not b.exists():run_python(S/'decimal_mixed_reference.py',family)
        if read(b)['status']!='PASS':raise QualificationFailure('INDEPENDENT_DECIMAL64_REFERENCE_FAILED')
        lo=read(a)['runs'][-1];hi=read(b)['runs'][-1]
        refs[family]={**lo,'highPrecisionReferenceSHA256':sha(b),
                      'speed':float(hi['speed']),
                      'entropyFluxProduction':float(hi['upstream']['rho'])*float(hi['speed'])*sum(
                          float(hi['upstream']['m'+z['phase']])/float(hi['upstream']['rho'])*float(z['direct']) for z in hi['entropy']),
                      'heatingIntegral':float(hi['heatingIntegral'])}
        with (S/'independent_references'/f'{family}_profile_1.csv').open() as f:
            rows=list(csv.DictReader(f))
        export(family,rows,refs[family])
    p=OLD/'original_reference.json';q=OLD/'original_reference_profile.csv'
    z=read(p)
    if not z['referenceMathGatePassed'] or not z['allSampledStatesStrictGasEOS']:
        raise QualificationFailure('FROZEN_ORIGINAL_REFERENCE_INVALID')
    with q.open() as f:rows=list(csv.DictReader(f))
    for row in rows:row['TG']=row['T'];row['TL']=0
    for level in ('upstream','downstream'):
        z[level]={k:float(v) for k,v in z[level].items()};z[level]['TG']=z[level]['T'];z[level]['TL']=0
    z['speed']=float(z['speed']);z['entropyFluxProduction']=float(z['Sigma'])
    z['heatingIntegral']=float(z['quadrature'][-1]['heatingIntegral'])
    z['thicknessPerMu']={'p':float(z['quadrature'][-1]['pressureThicknessPerMu']),
                         'u':float(z['quadrature'][-1]['velocityThicknessPerMu']),'alpha':None}
    z['reusedFrozenReferenceSHA256']=sha(p);z['reusedFrozenProfileSHA256']=sha(q)
    refs['original']=z;export('original',rows,z)
    write(S/'reference_suite_gate.json',{'status':'PASS','families':refs,
          'mixedPrecisionDigits':64,'originalPrecisionDigits':90,'nativeRecoveryCalls':0,
          'scope':'independent mathematical references only; no PDE qualification claim'})
    return refs

def export(family,rows,z):
    d=S/'reference_exports';d.mkdir(exist_ok=True)
    with (d/f'{family}_profile.csv').open('w',newline='') as f:
        out=csv.DictWriter(f,fieldnames=FIELDS,lineterminator="\n");out.writeheader()
        out.writerows({k:float(row[k]) for k in FIELDS} for row in sorted(rows,key=lambda r:float(r['xiPerMu'])))
    with (d/f'{family}_endpoints.csv').open('w',newline='') as f:
        out=csv.DictWriter(f,fieldnames=FIELDS,lineterminator="\n");out.writeheader()
        for name,x in (('downstream',-1),('upstream',1)):
            out.writerow({k:x if k=='xiPerMu' else z[name][k] for k in FIELDS})

def case(family,mu,N,ref):
    verify_prepared_identity()
    if not read(GATE).get('complete'):raise QualificationFailure('2C_GATE_REVOKED')
    d=S/'cases'/f'{family}_N{N}_mu{mu:g}';d.mkdir(parents=True,exist_ok=True)
    executable=S/'PDE/referencePDE';profile=S/'reference_exports'/f'{family}_profile.csv'
    ends=S/'reference_exports'/f'{family}_endpoints.csv';thermal=C/'wrapper_full/constant/thermal.dat'
    manifest={'family':family,'mu':mu,'N':N,'endTime':.2/ref['speed'],
              'speed':ref['speed'],'physicalWindowPlanSHA256':sha(S/'controlled_window_plan.json'),
              'executableSHA256':sha(executable),'profileSHA256':sha(profile),
              'endpointsSHA256':sha(ends),'thermalSHA256':sha(thermal),'gate2CSHA256':sha(GATE)}
    m=d/'input_manifest.json';result=d/'result.json'
    if result.exists():
        # Progress report hash can change without changing its qualified state.
        old=read(m)
        for key in manifest:
            if key!='gate2CSHA256' and old[key]!=manifest[key]:raise QualificationFailure('CASE_IDENTITY_MISMATCH: '+d.name)
        z=read(result)
        if z['status']!='PASS_HARD_GATES_MEASUREMENTS_ONLY':raise QualificationFailure('CASE_HARD_GATE_FAILED')
        return z
    if (d/'steps.csv').exists():raise QualificationFailure('UNFINISHED_CASE_EVIDENCE_PRESERVED: '+d.name+'; inspect running native PID before resume')
    write(m,manifest);progress('CONTROLLED_PDE_RUNNING',case=d.name,mu=mu,N=N,endTime=manifest['endTime'])
    args=[str(ref['speed']),str(mu),str(N),repr(manifest['endTime'])]
    script='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\n'
    script+='"'+wsl(executable)+'" "'+wsl(thermal)+'" "'+wsl(profile)+'" "'+wsl(ends)+'" '+' '.join(args)+' "'+wsl(d)+'" "'+wsl(GATE)+'"\n'
    (d/'run.sh').write_bytes(script.encode())
    with (d/'log.native').open('wb') as f:
        done=subprocess.run(['wsl','-d','Ubuntu-22.04','--','bash',wsl(d/'run.sh')],stdout=f,stderr=subprocess.STDOUT)
    write(d/'exit.json',{'exitCode':done.returncode})
    if done.returncode or not result.exists():raise QualificationFailure('NEW_NATIVE_OR_MEASUREMENT_BLOCKER: '+d.name+'; inspect log, do not classify as model error automatically')
    z=read(result)
    if float(z['time']).hex()!=float(manifest['endTime']).hex():raise QualificationFailure('CONTROLLED_ENDTIME_BITS_MISMATCH')
    return z

def resolved(z,ref,mu):
    counts=[z[k+'ShockCells'] for k in ('pressure','velocity','alpha') if z[k+'ShockCells'] is not None]
    true_counts=[ref['thicknessPerMu'][k]*mu*z['N'] for k in ('p','u','alpha') if ref['thicknessPerMu'][k] is not None]
    return min(counts+true_counts)>=8

def differences(a,b,ref):
    values={'speed':abs(a['measuredShockSpeed']-b['measuredShockSpeed'])/abs(b['measuredShockSpeed'])}
    for side in ('upstream','downstream'):
        for k in ('p','u','alpha','mG','mL'):
            i=b['plateauOrder'].index(k);x,y=a[side+'Plateau'][i],b[side+'Plateau'][i]
            scale=max(abs(ref[side][k]),abs(ref['downstream'][k]-ref['upstream'][k]))
            if scale:values[side+'_'+k]=abs(x-y)/scale
            elif x or y:raise QualificationFailure('DEGENERATE_PLATEAU_NONZERO_NEEDS_SCOPED_ABSOLUTE_AUDIT')
    # Thermodynamic rates must also have an independently converged spatial estimate.
    for k in ('primaryHeatingRate','primaryEntropyRate'):
        values[k]=abs(a[k]-b[k])/abs(b[k])
    return values

def spatial_pair(family,mu,start,ref):
    N=start;a=case(family,mu,N,ref)
    while True:
        N*=2;b=case(family,mu,N,ref);diff=differences(a,b,ref)
        qualifying=resolved(a,ref,mu) and resolved(b,ref,mu) and max(diff.values())<=.02
        proof={'status':'PASS' if qualifying else 'MORE_SPATIAL_REFINEMENT_REQUIRED',
               'family':family,'mu':mu,'lastTwoGrids':[a['N'],b['N']],
               'lastTwoRelativeDifferences':diff,'minimumShockCellHardGate':8,
               'referenceAndPDEShockResolution':'PASS' if resolved(a,ref,mu) and resolved(b,ref,mu) else 'FAIL',
               'engineeringTarget':.01,'engineeringHardLimit':.02}
        write(S/'cases'/f'{family}_spatial_mu{mu:g}_start{start}.json',proof)
        if qualifying:return a,b,proof
        a=b

def metrics(z,ref):
    values={'speed':z['measuredShockSpeed'],'position':z['shockPosition'],
            'pressureProfileL1':z['alignedPressureL1JumpRelative'],
            'velocityProfileL1':z['alignedVelocityL1JumpRelative'],
            'heatingRate':z['primaryHeatingRate'],'entropyRate':z['primaryEntropyRate']}
    absolute={}
    if ref['entropyFluxProduction']<=0 or ref['heatingIntegral']<=0:raise QualificationFailure('REFERENCE_WORK_OR_ENTROPY_RATE_NOT_POSITIVE')
    errors={'speed':abs(values['speed']-ref['speed'])/ref['speed'],
            'position':abs(z['shockPosition']-z['referenceShockPosition'])/.2,
            'pressureProfileL1':values['pressureProfileL1'],'velocityProfileL1':values['velocityProfileL1'],
            'heatingRate':abs(values['heatingRate']-ref['heatingIntegral'])/ref['heatingIntegral'],
            'entropyRate':abs(values['entropyRate']-ref['entropyFluxProduction'])/ref['entropyFluxProduction']}
    if z['alignedAlphaL1JumpRelative'] is not None:errors['alphaProfileL1']=z['alignedAlphaL1JumpRelative']
    for k in ('p','u','alpha','mG','mL'):
        i=z['plateauOrder'].index(k);pre=z['upstreamPlateau'][i];post=z['downstreamPlateau'][i]
        rp=ref['upstream'][k];rq=ref['downstream'][k];values[k+'_jump']=post-pre
        if rq!=rp:errors[k+'_jump']=abs(post-pre-(rq-rp))/abs(rq-rp)
        for side,value,true in (('upstream',pre,rp),('downstream',post,rq)):
            values[side+'_'+k]=value
            if true:errors[side+'_'+k]=abs(value-true)/abs(true)
            else:absolute[side+'_'+k]={'absoluteError':abs(value-true),'relativeError':None,'status':'UNDEFINED_RELATIVE_REQUIRES_SCOPED_AUDIT'}
    return {'observables':values,'referenceRelativeErrors':errors,'zeroReferenceAbsoluteDiagnostics':absolute,
            'engineeringMeasurementGate':'PASS' if max(errors.values())<=.05 else 'FAIL_MEASUREMENTS_REQUIRES_CLASSIFICATION',
            'target':.02,'hardLimit':.05,'zeroReference':'absolute and undefined relative; requires scoped review'}

def main():
    lock=S/'controller.lock'
    try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:raise QualificationFailure('CONTROLLER_LOCK_EXISTS_DO_NOT_DUPLICATE')
    os.write(fd,str(os.getpid()).encode());os.close(fd)
    try:
        verify_prepared_identity()
        progress('WAITING_FOR_2C_COMPLETE_NO_PHYSICAL_EXECUTION')
        while not read(GATE).get('complete'):
            for name in ('real_entry_M1_gate.json','real_entry_gate.json'):
                p=C/name
                if p.exists() and read(p).get('status')=='FAIL':raise QualificationFailure('2C_GATE_FAILED: '+name)
            time.sleep(20)
        verify_prepared_identity()
        subprocess.run([sys.executable,'-X','utf8',str(S/'seal_2c_before_resume.py')],check=True)
        write(S/'physical_resume_gate.json',{'status':'AUTHORIZED_AND_2C_COMPLETE','qualificationProgressSHA256':sha(GATE),
              'report2CSHA256':sha(R/'M6B1-CRV3-2C-REPRESENTATION-V2-IMPLEMENTATION_REPORT_v2.md'),
              'startedAt':time.strftime('%Y-%m-%dT%H:%M:%S%z'),'CRV3_3':'NOT AUTHORIZED'})
        refs=prepare_references();all_results={}
        for family,ref in refs.items():
            # Preserve all three mandatory fixed-mu grids before adaptive refinement.
            for N in (256,512,1024):case(family,3,N,ref)
            a,b,proof=spatial_pair(family,3,512,ref)
            all_results[family]={'fixedMu':{'coarse':a,'fine':b,'spatialProof':proof,'analysis':metrics(b,ref)},'routes':{}}
            for route,start in (('A',256),('B',512)):
                points=[]
                for level,mu in enumerate((3,1.5,.75,.375)):
                    coarse,fine,proof=spatial_pair(family,mu,start*2**level,ref)
                    points.append({'mu':mu,'coarse':coarse,'fine':fine,'spatialProof':proof,'analysis':metrics(fine,ref)})
                    all_results[family]['routes'][route]=points
                    write(S/'physical_measurements.json',all_results)
        subprocess.run([sys.executable,'-X','utf8',str(S/'analyze_routes.py')],check=True)
        progress('MEASUREMENT_LADDERS_AND_FREE_P_FITS_FINISHED_FULL_AUDIT_REQUIRED',families=list(refs))
        write(S/'measurement_collection_gate.json',{'status':'PASS_HARD_NATIVE_AND_SPATIAL_COLLECTION_ONLY',
              'physicalQualificationComplete':False,'measurementsSHA256':sha(S/'physical_measurements.json'),
              'fitAuditSHA256':sha(S/'route_fit_audit.json'),
              'remaining':'review free-p identifiability and last-level/two-route gates; full original endTime case assessment, 36-chapter report and sealed evidence'})
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':
    try:main()
    except Exception as error:
        progress('ATTENTION_REQUIRED_EVIDENCE_PRESERVED',blocker=str(error),
                 classification='Inspect evidence; numerical/reference-tool/measurement failure is not automatically a physical model defect')
        (S/'controller_traceback.txt').write_text(traceback.format_exc())
        raise
