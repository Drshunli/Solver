"""Independent CRV3 travelling-wave oracle; no native recovery or solver data.

Reads frozen coefficient data only. Qualification execution is gated by 2C.
The state constraints, simultaneous p/T root, alpha ODE, shock-speed shooting,
entropy integrals and thickness quadrature are implemented here independently.
"""
from pathlib import Path
import argparse, hashlib, json, sys, csv, math

S = Path(__file__).resolve().parent
R = S.parents[2]
sys.path.insert(0, str(R / 'fitting/reference_backend'))
import numpy as np
from numpy.polynomial import chebyshev as ch
from scipy.optimize import root, brentq
from scipy.integrate import solve_ivp, quad

GAS = R / 'fitting/integration/m6b1_mc3_nonzero_k_model_design_v1/results/gas_mixture.json'
LIQUID = R / 'liquidEOS/ndecane_gibbs_v3/coefficients.json'
META = R / 'liquidEOS/ndecane_gibbs_v3/metadata.json'
PHYSICS = R / 'NONZERO_K_PE_CRV3_MODEL_v1.md'

class ReferenceFailure(RuntimeError):
    pass

class IndependentEOS:
    def __init__(self):
        self.gas = json.loads(GAS.read_text())
        d = json.loads(LIQUID.read_text())
        self.offset = json.loads(META.read_text())['C_L']
        self.pc, self.ps = d['pCenter'], d['pScale']
        self.tc, self.ts = d['TCenter'], d['TScale']
        c = np.array(d['coefficients'], dtype=float)
        # Derive derivatives from the scalar Gibbs polynomial rather than
        # importing the native precomputed derivative arrays or native code.
        self.coefficients = [c, ch.chebder(c, axis=0)/self.ps,
                             ch.chebder(c, axis=1)/self.ts,
                             ch.chebder(c, m=2, axis=0)/self.ps**2,
                             ch.chebder(ch.chebder(c, axis=0), axis=1)/(self.ps*self.ts),
                             ch.chebder(c, m=2, axis=1)/self.ts**2]

    def liquid(self, p, t, domain=True):
        if domain and not (50000 <= p <= 12000000 and 265 <= t <= 400):
            raise ReferenceFailure(f'INDEPENDENT_LIQUID_DOMAIN p={p} T={t}')
        x, y = (p-self.pc)/self.ps, (t-self.tc)/self.ts
        g, gp, gt, gpp, gpt, gtt = [ch.chebval2d(x, y, c) for c in self.coefficients]
        cp = -t*gtt
        cv = cp+t*gpt*gpt/gpp
        c2 = -gp*gp/(gpp-gpt*gpt/gtt)
        beta = t*(-gpt+gtt*gpp/gpt)
        if domain and not (gp > 0 and cp > 0 and cv > 0 and c2 > 0 and beta > 0):
            raise ReferenceFailure('INDEPENDENT_LIQUID_THERMO')
        return dict(rho=1/gp, e=math.fsum((g,-t*gt,self.offset,-p*gp)), T=t,
                    c2=c2, beta=beta, entropy=-gt, v=gp, vp=gpp, vt=gpt, ep=-t*gpt-p*gpp, et=cp-p*gpt)

    def gas_state(self, rho, p, domain=True):
        t = p/(rho*self.gas['R'])
        if domain and not (self.gas['Tlow'] <= t <= self.gas['Thigh']):
            raise ReferenceFailure(f'INDEPENDENT_GAS_DOMAIN T={t}')
        a = self.gas['low'] if t < self.gas['Tcommon'] else self.gas['high']
        cp = sum(a[i]*t**i for i in range(5))
        cv = cp-self.gas['R']
        e = math.fsum([a[i]*t**(i+1)/(i+1) for i in range(5)]+[a[5],-self.gas['Hc'],-self.gas['R']*t])
        entropy = a[0]*np.log(t)+sum(a[i]*t**i/i for i in range(1,5))+a[6]-self.gas['R']*np.log(p)
        if domain and not (cv > 0 and cp > 0 and rho > 0 and p > 0):
            raise ReferenceFailure('INDEPENDENT_GAS_THERMO')
        return dict(rho=rho, e=e, T=t, c2=p/rho*cp/cv,
                    beta=cv/(rho*self.gas['R']), entropy=entropy)

class MixedOrbit:
    def __init__(self, eos, alpha=.25, p=3e6, tg=800., tl=300.):
        self.eos = eos
        self.alpha0, self.p0 = alpha, p
        g = eos.gas_state(p/(eos.gas['R']*tg), p)
        l = eos.liquid(p, tl)
        self.mg0, self.ml0 = (1-alpha)*g['rho'], alpha*l['rho']
        self.rho0 = self.mg0+self.ml0
        self.wg, self.wl = self.mg0/self.rho0, self.ml0/self.rho0
        self.e0 = math.fsum((self.wg*g['e'],self.wl*l['e']))
        self.cs = (1/(self.rho0*((1-alpha)/(g['rho']*g['c2'])+alpha/(l['rho']*l['c2']))))**.5
        self.seed = np.array([p/3e6, tl/300.])
        self.states = 0
        self.max_volume_constraint = self.max_energy_constraint = 0.
        self.upstream_entropy = (g['entropy'], l['entropy'])

    def at(self, u, alpha, speed):
        if not (0 < alpha < 1 and 0 <= u < speed):
            raise ReferenceFailure('INDEPENDENT_ORBIT_PHASE_OR_MASS')
        j = -self.rho0*speed
        rho = j/(u-speed)
        mg, ml = rho*self.wg, rho*self.wl
        rg, rl = mg/(1-alpha), ml/alpha
        target_e = math.fsum((self.e0,.5*u*u,-self.p0*u/j))
        scale_e = max(abs(target_e), 1e5)

        def constraints(v):
            p, tl = float(v[0])*3e6, float(v[1])*300.
            # Newton trial points may leave the domain, but accepted roots
            # must pass the strict EOS domain and thermodynamic checks below.
            if p <= 0 or tl <= 0:
                return np.array([1e6+abs(p), 1e6+abs(tl)])
            g = self.eos.gas_state(rg, p, domain=False)
            l = self.eos.liquid(p, tl, domain=False)
            return np.array([(l['v']*rl-1), math.fsum((self.wg*g['e'],self.wl*l['e'],-target_e))/scale_e])

        def jacobian(v):
            p, tl = float(v[0])*3e6, float(v[1])*300.
            g = self.eos.gas_state(rg, p, domain=False)
            l = self.eos.liquid(p, tl, domain=False)
            return np.array([[rl*l['vp']*3e6,rl*l['vt']*300.],
                             [(self.wg*g['beta']+self.wl*l['ep'])*3e6/scale_e,
                              self.wl*l['et']*300./scale_e]])
        answer = root(constraints, self.seed, jac=jacobian, method='hybr', options={'xtol':1e-12})
        # Polish only the independent reference algebraic root, retaining
        # the candidate with the smallest residual; no solver state is involved.
        best = np.max(np.abs(constraints(answer.x)))
        for _ in range(6):
            delta = np.linalg.solve(jacobian(answer.x),constraints(answer.x))
            candidate = answer.x-delta
            error = np.max(np.abs(constraints(candidate)))
            if error >= best: break
            answer.x, best = candidate, error
        residual = constraints(answer.x)
        if not np.all(np.isfinite(answer.x)) or np.max(np.abs(residual)) > 2e-10:
            # This is an independent algebraic reference failure, never a
            # justification to modify the PDE state or its engineering budget.
            raise ReferenceFailure(f'INDEPENDENT_COMMON_PRESSURE_ROOT {answer.message} {residual}')
        self.seed = answer.x.copy()
        p, tl = answer.x[0]*3e6, answer.x[1]*300.
        g, l = self.eos.gas_state(rg, p), self.eos.liquid(p, tl)
        al, ag = rl*l['c2'], rg*g['c2']
        denominator = (1-alpha)*al+alpha*ag
        k = alpha*(1-alpha)*(ag-al)/denominator
        cp2 = 1/(rho*(alpha/al+(1-alpha)/ag))
        J = mg*g['beta']+ml*l['beta']
        tau = j*u+p-self.p0
        self.states += 1
        self.max_volume_constraint = max(self.max_volume_constraint, abs(residual[0]))
        self.max_energy_constraint = max(self.max_energy_constraint, abs(residual[1]))
        return dict(u=u, alpha=alpha, p=p, TG=g['T'], TL=tl, rho=rho,
                    rhoG=rg, rhoL=rl, mG=mg, mL=ml, Et=rho*(target_e+.5*u*u),
                    K=k, cPE=cp2**.5, tau=tau, J=J,
                    betaG=g['beta'], betaL=l['beta'],
                    entropyG=g['entropy'], entropyL=l['entropy'])

    def solve_alpha(self, speed, ratio, rtol):
        end = self.p0*(ratio-1)/(self.rho0*speed)
        self.seed = np.array([self.p0/3e6, 1.])

        def rhs(t, a):
            value = self.at(end*t, float(a[0]), speed)
            return [end*value['K']/(end*t-speed)]

        solution = solve_ivp(rhs, (0., 1.), [self.alpha0], method='DOP853',
                             rtol=rtol, atol=rtol*1e-2, dense_output=True,
                             max_step=.025)
        if not solution.success:
            raise ReferenceFailure('INDEPENDENT_ALPHA_ODE '+solution.message)
        post = self.at(end, float(solution.y[0,-1]), speed)
        return end, solution, post

    def solve(self, ratio, rtol=2e-10):
        samples = []
        previous = None
        bracket = None
        for factor in np.linspace(1.0001, 1.6, 20):
            speed = self.cs*factor
            try:
                _, _, post = self.solve_alpha(speed, ratio, rtol)
                error = (post['p']-self.p0*ratio)/self.p0
                samples.append((float(speed), float(error)))
                if previous is not None and previous[1]*error < 0:
                    bracket = (previous[0], speed)
                    break
                previous = (speed, error)
            except ReferenceFailure as error:
                samples.append((float(speed), str(error)))
                previous = None
        if bracket is None:
            raise ReferenceFailure('INDEPENDENT_SPEED_BRACKET '+repr(samples))

        def shoot(speed):
            return self.solve_alpha(speed, ratio, rtol)[2]['p']-self.p0*ratio

        speed = brentq(shoot, *bracket, xtol=1e-12, rtol=1e-15)
        end, ode, post = self.solve_alpha(speed, ratio, rtol)

        def value(t):
            return self.at(end*t, ode.sol(t)[0], speed)

        pre = value(0.)
        nodes = [value(float(t)) for t in np.linspace(0,1,257)]
        interior = nodes[1:-1]
        if not all(z['tau'] < 0 for z in interior):
            raise ReferenceFailure('INDEPENDENT_COMPRESSIVE_TAU_SIGN')
        if not (speed > pre['cPE'] and speed < post['u']+post['cPE']):
            raise ReferenceFailure('INDEPENDENT_LAX_BRANCH')
        j = -self.rho0*speed

        def crossing(key, f):
            target = pre[key]+f*(post[key]-pre[key])
            return brentq(lambda t:value(t)[key]-target, 0, 1, xtol=5e-13)

        widths = {}
        for key in ('p','u','alpha'):
            if post[key] == pre[key]:
                widths[key] = None
            else:
                lo, hi = sorted((crossing(key,.1), crossing(key,.9)))
                widths[key] = quad(lambda t:-end/value(t)['tau'], lo, hi,
                                   epsabs=1e-13, epsrel=2e-9, limit=100)[0]
        heating = quad(lambda t:-end*value(t)['tau'], 0, 1,
                       epsabs=1e-7, epsrel=2e-9, limit=100)[0]
        entropy = []
        for phase in ('G','L'):
            integral = quad(lambda t:end*value(t)['beta'+phase]*value(t)['tau'] /
                            (value(t)['T'+phase]*value(t)['J']*(end*t-speed)),
                            0,1,epsabs=1e-11,epsrel=2e-9,limit=100)[0]
            direct = float(post['entropy'+phase]-pre['entropy'+phase])
            entropy.append(dict(phase=phase, integral=integral, direct=direct,
                                relativeError=abs(integral-direct)/max(abs(direct),1e-12)))
        energy0 = pre['Et']*(pre['u']-speed)+pre['p']*pre['u']
        energy1 = post['Et']*(post['u']-speed)+post['p']*post['u']
        momentum_error = abs(j*end+post['p']-pre['p'])/self.p0
        energy_error = abs(energy1-energy0)/max(abs(energy0),1.)
        alpha_ode_integral = quad(lambda t:end*value(t)['K']/(end*t-speed),0,1,
                                  epsabs=1e-12,epsrel=2e-9,limit=100)[0]
        alpha_error = abs(post['alpha']-pre['alpha']-alpha_ode_integral)/abs(post['alpha']-pre['alpha'])
        math_errors = [momentum_error, energy_error, alpha_error,
                       abs(post['p']-self.p0*ratio)/self.p0,
                       self.max_volume_constraint, self.max_energy_constraint,
                       *(z['relativeError'] for z in entropy)]
        # Grid-independent coordinate on the orbit: xi/mu = integral du/tau.
        fractions = np.r_[np.geomspace(1e-7,.01,60), np.linspace(.01,.99,981),
                          1-np.geomspace(.01,1e-7,60)]
        fractions = np.unique(fractions)
        profile = []
        last, xi = None, 0.
        for t in fractions:
            if last is not None:
                xi += quad(lambda z:end/value(z)['tau'],last,float(t),
                           epsabs=1e-13,epsrel=2e-9,limit=100)[0]
            profile.append(dict(xiPerMu=xi, **value(float(t))))
            last = float(t)
        middle = crossing('p',.5)
        center = np.interp(middle, fractions, [z['xiPerMu'] for z in profile])
        for z in profile:
            z['xiPerMu'] -= center
        pre={k:float(v) for k,v in pre.items()};post={k:float(v) for k,v in post.items()}
        result = dict(scope='independent mixed CRV3 mathematical travelling-wave BVP only',
                      precision='binary64 SciPy DOP853/quadrature with independent 48-digit scalar Gibbs jet thermodynamics and common-state roots; separate Decimal64 orbit certification required',
                      pressureRatio=ratio, speed=speed, upstream=pre, downstream=post,
                      referenceMathTolerance=1e-8, referenceMathGatePassed=bool(max(math_errors)<=1e-8),
                      residuals=dict(momentumRH=momentum_error, energyRH=energy_error,
                                     alphaODE=alpha_error, commonVolume=self.max_volume_constraint,
                                     commonEnergy=self.max_energy_constraint),
                      entropy=entropy, heatingIntegral=heating,
                      thicknessPerMu=widths, sampledStates=len(nodes), nativeRecoveryCalls=0,
                      TGRange=[min(z['TG'] for z in nodes),max(z['TG'] for z in nodes)],
                      TLRange=[min(z['TL'] for z in nodes),max(z['TL'] for z in nodes)],
                      minimumInteriorMinusTau=min(-z['tau'] for z in interior),
                      inputSHA256={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()
                                   for p in (GAS,LIQUID,META,PHYSICS)})
        return result, profile

def require_2c():
    path = R / 'fitting/integration/m6b1_crv3_2c_representation_v2_implementation_v1/qualification_progress.json'
    if not json.loads(path.read_text()).get('complete'):
        raise ReferenceFailure('2C_NOT_COMPLETE_PHYSICAL_EXECUTION_NOT_STARTED')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--family',choices=['weak','moderate'],required=True)
    ap.add_argument('--output',default='independent_references')
    args = ap.parse_args()
    require_2c()
    ratio = 1.05 if args.family == 'weak' else 1.25
    results = []
    profiles = []
    for tolerance in (2e-9,2e-10):
        from precision_reference_orbit import PrecisionOrbit
        result, profile = PrecisionOrbit(IndependentEOS()).solve(ratio,tolerance)
        results.append(result)
        profiles.append(profile)
    change = {'speed':abs(results[1]['speed']-results[0]['speed'])/results[1]['speed']}
    for field in ('p','alpha','u','TG','TL'):
        change[field] = abs(results[1]['downstream'][field]-results[0]['downstream'][field])/max(abs(results[1]['downstream'][field]),1e-30)
    for field in ('p','u','alpha'):
        change['width_'+field] = abs(results[1]['thicknessPerMu'][field]-results[0]['thicknessPerMu'][field])/results[1]['thicknessPerMu'][field]
    coordinates=[np.array([float(z['xiPerMu']) for z in profile])[::-1] for profile in profiles]
    if not all(np.all(np.diff(x)>0) for x in coordinates):
        raise ReferenceFailure('REFERENCE_PROFILE_COORDINATE_NOT_MONOTONE')
    sample=np.unique(np.r_[coordinates[0],coordinates[1]])
    sample=sample[(sample>=max(x[0] for x in coordinates)) & (sample<=min(x[-1] for x in coordinates))]
    profile_errors={}
    for key in ('p','u','alpha'):
        fields=[np.array([float(z[key]) for z in profile])[::-1] for profile in profiles]
        jump=abs(results[-1]['downstream'][key]-results[-1]['upstream'][key])
        profile_errors[key]=float(np.max(np.abs(np.interp(sample,coordinates[0],fields[0])-np.interp(sample,coordinates[1],fields[1])))/jump)
    passed = all(r['referenceMathGatePassed'] for r in results) and max(change.values())<=1e-8 and max(profile_errors.values())<=1e-8
    result = {'family':args.family,'status':'PASS' if bool(passed) else 'FAIL',
              'independentReferenceConvergenceTolerance':1e-8,
              'lastTwoToleranceRunsRelativeDifferences':change,'profileAtCommonCoordinateJumpNormalizedDifferences':profile_errors,'profileGateTolerance':1e-8,'runs':results}
    output = S / args.output
    output.mkdir(exist_ok=True)
    (output / (args.family+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    for index, profile in enumerate(profiles):
        with (output / f'{args.family}_profile_{index}.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(profile[0]));writer.writeheader();writer.writerows(profile)
    print(json.dumps({'family':args.family,'status':result['status'],'speed':results[-1]['speed'],'thicknessPerMu':results[-1]['thicknessPerMu']},indent=2))
    if not passed:
        raise ReferenceFailure('INDEPENDENT_REFERENCE_MATH_GATE_FAILED')

if __name__ == '__main__':
    try:
        main()
    except ReferenceFailure as error:
        print('BLOCKER',error,file=sys.stderr)
        raise SystemExit(1)
