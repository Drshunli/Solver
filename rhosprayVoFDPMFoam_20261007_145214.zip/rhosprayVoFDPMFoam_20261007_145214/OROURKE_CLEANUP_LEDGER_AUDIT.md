# ORourke minimum-mass cleanup ledger preflight

Date: 2026-10-02. Result: **EVENT_LEDGER_BLOCKER** under the frozen adapter contract; T3B PARTIAL.

## Reproduction scope and admissibility

The unchanged production-model graph is created from the frozen A/B/C dictionaries and evolved for 5/7/9 native steps (106/148/190 parcels). A positive-weight C10H22 parcel at 300 K and diameter 0.3 mm is placed in the last gas-present test cell. Its represented mass is half the actual native minParcelMass=1e-15 kg; density and caloric state use native liquid properties. All Q states are EOS-legal gas-present states; no Et/species corruption, alpha change, negative mass, invented native source or altered coefficient is used.

This is a **collision-kernel entry preflight**, not a proof that this parcel survives the preceding motion/ReactingParcel::calc in an ordinary full cloud timestep. In fact, ReactingParcel::calc checks the same weighted threshold and has a separate conservative absorption path. No pair collision/coalescence was established here. The historical pairs are examined by the native loop and its RNG advances; that does not certify a collision mutation. This limitation is explicit in every result JSON.

The preflight isolates a real native branch that also runs after coalescence. Source shows coalescence can leave a positive remnant m2=(1-prob)*m2Org, followed by min-mass cleanup; full-step reachability within the intended envelope remains to be demonstrated. The test does **not** assert that production already loses this amount in a CFD run.

## Actual source distinction

`fitting/dpm/m8a3b_t3b_v1/native_sources/lagrangian/spray/submodels/StochasticCollision/ORourkeCollision/ORourkeCollision.C`, lines 108–118: the post-collision sweep deletes any parcel whose represented mass is below minParcelMass. It does not update rhoTrans, UTrans or hsTrans, retain a deletion transfer, or define an external mass sink.

`native_sources/lagrangian/intermediate/parcels/Templates/ReactingParcel/ReactingParcel.C`, lines 492–513: when its calc path removes a parcel, the coupled branch adds carrier species mass, sensible enthalpy and momentum before returning. Therefore the frozen disappearance regression cannot be used as proof for ORourke cleanup.

## Measured kernel event

| Quantity | Observation |
|---|---|
| Native threshold | 1e-15 kg |
| Before represented mass | 5e-16 kg |
| After represented mass | 0 |
| Native mass/species transfer | 0 |
| Native UTrans/hsTrans | 0 / 0 |
| Carrier+parcel mass residual | -5e-16 kg |
| Frozen adapter result | PARCEL_SPECIES_LEDGER_MISMATCH |
| Accepted commits | 0 |
| Committed ledger contribution | 0 |

The species mismatch exceeds the unchanged endpoint tolerance by many orders of magnitude. Its small absolute mass is not justification for silently dropping it or relaxing tolerances. Conversion stops at its first species check; dmG/dmYi/dM/dEt and recovered QTrial are **unavailable**, not fabricated zero increments. Exact endpoint momentum/kinetic/raw-liquid-H and source coefficients are retained in EVENT_LEDGER_v1.txt. No energy residual has been used to invent heat/work.

Native cloud role trial is deep-copied through the unchanged T3A beginTrial contract. After the real cleanup, the frozen adapter refuses conversion and the unchanged discard method restores the tested aggregate cloud sentinel, Q bits, carrier values/generation, allocator and registry. The sentinel includes complete native parcel serialization plus a finite RNG future probe; it is **not** the requested complete transactionState-v1 codec.

## Why no repair is applied

Passing the missing parcel mass to gas by editing the native buffers would create a new deletion-coupling rule. Treating it as outflow would invent a physical sink, since no boundary crossing occurred. Excluding the deleted parcel from endpoint totals would hide the discrepancy. Keeping it or merging its remainder would change the native cleanup/model behavior. None is authorized by this turn's frozen-source and model constraints.

Following user section 48, further event development stops. Mandatory frozen regressions and documentation are completed. This gate cannot mark ORourke or the eight-model matrix FULL-SERIAL-TRANSACTION-SAFE.

## Exact next engineering gate

Perform **ORourke cleanup reachability and conservation-policy review** first: instrument ordinary coalescence→cleanup, capture the positive remnant before native deletion, distinguish it from the already-conservative ReactingParcel::calc path, and assess its occurrence in the certified envelope. If reachable, present an explicit conservative cleanup-coupling design for review while preserving the existing frozen source adapter; do not implement it, discard the remainder, change minParcelMass, disable coalescence, or modify production code in this turn. If certified unreachable, prove the relevant entry invariant rather than assuming it from the pre-move calc check. Then resume codec/event/retry/output gates. No alternative EOS, T4 or M6B work is implied.
