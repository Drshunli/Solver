# M6B.1-EOS2-LB2C-PHASESOURCE

2026-10-05.5% phase-boundary evidence amendment acknowledged; no accuracy relaxation elsewhere.

## 1. LB2C status

PARTIAL / STOP / CLASS D. Evidence acquisition only.5% amendment applied solely to phase-boundary evidence; no model work.

## 2. Evidence route

A fresh original1975publisher/archival search; B frozenGao2025originalfigure recalibrated; C freshCoolPropprimarymetadata and existingEESprovenance. No qualifying targetMPa relation.

## 3. Exact source obtained

FreshOpenAlex1975metadata andCoolPropn-DecanefluidJSON; existingGao2025originalsupplementSHAverified. No original1975PDF/table/figure acquired. Publisher403; noaccess-control bypass.

## 4. Source provenance

Full citation/locators and retrievalSHA in NDECANE_MELTING_SOURCE_LB2C_v1.md/fresh_acquisition_log.json. Primary[1975DOI](https://doi.org/10.1002/bbpc.19750791206); original[2025supplement](https://aip.figshare.com/articles/figure/Supplementary_Material/29252828). Citations alone not quantitative evidence.

## 5. N-decane data locator

Gao2025supplement SectionIII/FigS8,word/media/image8.tiff. Heatingblue/coolingorange. Würflinger originaln-decanelocator unknown. Relevant low-pressure solid-solid transitionsunknown.

## 6. Table/equation/figure/package

OriginalGaofigureavailable; no usabletargettable/equation. VisiblebluepixelCSV/axiscalibration are imageaudit, not experimentalrawpoints ortargetinterpolation. CoolPropdownloadedANCILLARIES lacks melting_line. NoEES/REFPROPnumericqueries.

## 7. Pressure validity

Target3.285416855452983/3.286242793380548/12MPa relationnot supported. Figaxis0–8GPa is not experimentalvalidity; usablebluecurve nearoriginclipped. Whole.05–12MPasupportUNKNOWN.

## 8. Temperature validity

Inspectedplotloweredge maps~250.31K; sourceEEStripleto293context supplies noquantitativecurve. AcceptedtargetsourceTvalidityUNKNOWN; noambientmeltingextrapolation.

## 9. Uncertainty

dTtotal=sum defensiblesource/correlation/digitization/interpolationcomponents. Missingcomponent remainsUNKNOWN; not0 orautomatic5%. NeeddTtotal/abs(Tmelt_est)<=.05; preserveactualsourceerrors>5% rather thantruncate. NoRSS withoutindependence. OnlyTmelt evidence policy changed.

## 10. Low-pressure resolution

9p/4Ttickcalibrations saved; pscale8.403361MPa/px,Tscale.613497K/px. Targetoffsets.390965/.391063/1.428px; firstdetectedvisiblebluecolumnx168 maps~25.21MPa, plotbottom~250.31K. Curveclipped/targetnotlocallyobservable; source/modelerrorunknown. FIGURE_RESOLUTION_INSUFFICIENT / SOURCE_ERROR_UNRESOLVED.2pxlocalizationallowance is a screeningassumption, not measuredrepeatability norfullerrorcertificate; no targetTmelt extrapolation.

## 11. Tmelt(p1)

UNRESOLVED / null; no defensibletotalerror orupperboundary.

## 12. Tmelt(p2)

UNRESOLVED / null; independentlyrecordedquery.

## 13. Tmelt(12MPa)

UNRESOLVED / null.5% does not supplymissingtemperature.

## 14. Diagnosed minimum margin

TL_i−Tmelt(p_i) andminconservativemarginTL_i−[Tmelt+dTtotal] UNRESOLVED.130originalid/p/Trows preservedaspending; noEOS/R1rerun.

## 15. Diagnosed verdict

NOT CLOSED / PHYSICAL_PHASE_BOUNDARY_UNRESOLVED. Cannot proveall130strictTL_i>Tmelt+dTtotal. No knownbound supportsPHASE_BOUNDARY_OVERLAP/solid-sideclassification either.

## 16. 12MPa margin

275−Tmelt(12MPa) UNRESOLVED; 275>Tmelt+dTtotal notestablished.

## 17. Full-box verdict

NOT CERTIFIED. Requires.05–12MPadomaincoverage andpositive275−max_p(Tmelt+dTtotal); neitherclosed. Diagnosed/pathandfullboxcertificatesseparate.

## 18. Reused numerical evidence

FreshSHAverification:23LB1numericalevidenceentries +5LB2-Aentries +3originalsourceentriesPASS. lower9801/old3721/upper3721;130shadowR1/old184/accepted6200 remainPASSbyreuse. NoEOSgrid/R1/solverexecution, no81coeff/C_Lchange.

## 19. Final class A–D

CLASS D / UNRESOLVED. NojustificationforA/B/C.5%permission is anaccuracyrequirement, notphase-margin forgiveness.

## 20. LB2B COMPLETE?

NO / PARTIAL; missingtargetquantitativerelation anddefensibleuncertainty.

## 21. LB2 COMPLETE?

NO / PARTIAL; PartA frozenCOMPLETE, PartBunresolved.

## 22. v3 DESIGN QUALIFIED?

NO;SHADOW/NUMERICALPASS/DESIGNPARTIAL. Nohigher/lowerTminoroperationdomainredesign.

## 23. EOS3 permitted?

NO / NOTAUTHORIZED. Intendedphysicaldomainanddiagnosed130conservativequalificationmissing. Noinstall/factoryswitch.

## 24. Source changes

Added isolatedsourceacquisitionlogs/rawmetadata, phase5%policy, calibratedfigureaudittool/CSV/JSON, pendingqueryrecords, this29-sectionreport andmilestoneappend. ActiveEOS/P2/R1/temporal/solvercase untouched. The figureassessment script ran successfully; noCFD/EOS/R1/regressiontest.

## 25. Foundation/project hashes

FreshFoundation6717/nativeparcel19checksumPASS; activebinary/twoEOSlibs/all55linkedlibsUNCHANGED. Fullprotectedprojecthashes/parentCRC/per-fileSHA finalseal inproject_protection.json. Onlyexistingmilestonejournalappendallowed.

## 26. EOS2 status

PARTIAL / STOP; ndecane_gibbs_v2ACTIVE/PRESERVED. LB2Cdoesnotclosepriorlower-boundblocker.

## 27. TD1 status

REQUIRED / NOTAUTHORIZED / NOTEXECUTED; nodt/CFL/temporalchanges.

## 28. M6B.1 status

PARTIAL / STOP. Noshock/solver/EOSgrid/R1regression/CFD/DPM/production. To closegate requiresoriginaln-decanequantitativecontent ortraceableMPamodeloutputs with5%-compliantdefensibleerror andscope.

## 29. Milestone matrix

| Milestone | Status |
|---|---|
| M6B.0 / SR1 / EOS1 | COMPLETE / FROZEN (SR1 diagnosis only) |
| activev2 | ACTIVE / PRESERVED |
| LB2PartA | COMPLETE / FROZEN |
| LB2B / LB2C / LB2 | PARTIAL / STOP |
| Phasecertificates | UNRESOLVED / CLASS D |
| v3candidate | SHADOW / NUMERICAL PASS / DESIGN PARTIAL |
| EOS3 | NOTAUTHORIZED |
| TD1 | REQUIRED / NOTAUTHORIZED |
| EOS2 / M6B.1 / M6B | PARTIAL / STOP |
| M6B.2 / productionCFD | NOTAUTHORIZED |
| T4 / M8A | PARTIAL / S1S2FROZEN / S3DEFERRED |

STOP.
