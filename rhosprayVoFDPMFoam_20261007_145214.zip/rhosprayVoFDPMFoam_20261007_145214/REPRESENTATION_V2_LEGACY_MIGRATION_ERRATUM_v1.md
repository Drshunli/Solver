# CRV3-2B-M1 — Legacy migration contract erratum v1

Authorized by the user's 2026-10-06 development request. This document supersedes only the legacy migration subsection of the frozen Representation-V2 architecture v1. CRV3-2B remains COMPLETE / DESIGN FROZEN; CRV3-2A remains historically INCOMPLETE.

Original design SHA256: `b89c06acbf72a46690e31710aea5c97c4dcc2ead6eb59f404944a8f2de502c51`.

## Evidence and impossibility

The frozen counterexample has mG and mY0 bits `40500b286d91bae3`, mY1 bits `3cf00b286d91bae3` (= mG × 2^-54), and legacy dependent bits `0000000000000000`. Rounded binary64 addition produces mG, so the legacy solver accepts dependent +0. Exact dyadic arithmetic instead gives dependent −mG × 2^-54. The actual frozen legacy executable accepted this state; evidence is preserved in `fitting/integration/m6b1_crv3_2c_representation_v2_implementation_v1/frozen_legacy_probe/result.json` and `LEGACY_MIGRATION_BLOCKER_v1.md` in that same directory.

Preserving every independent amount and mG while requiring a nonnegative exact dependent is impossible for this state. No arithmetic implementation can satisfy both demands. This is LEGACY SEMANTIC MIGRATION INCOMPATIBILITY, not a Representation-V2, species runtime, conservation, EOS/R1, or CRV3 physics failure.

## Lossless archival compatibility

All readable old-contract-legal v1/v2 artifacts remain losslessly archivable. Preserve original bytes, every original field bit, schema/model identity, original checksum, and all recorded time/step metadata. Missing metadata stays unknown. Preserve the raw source plus a SHA256 manifest; an optional container is explicitly `LEGACY_ARCHIVE_ONLY`, never an active restart-v3. Runtime rejects archive activation. Archival compatibility makes no assertion that a historical state is an exact V3 state.

## Exact active migration

Parse legacy bytes exactly; reconstruct exact dyadics; retain P2 orientation and signed-zero semantics; check phase invariants; check species invariants; check conservative values and native recovery/model/EOS identity; emit active restart-v3 only after every check passes. For each temporal level and cell, every species amount is nonnegative, independent sum is no greater than mG, and the dependent authority is the exact residual. A negative exact residual deterministically rejects with `LEGACY_SPECIES_EXACT_CLOSURE_INCOMPATIBLE`. Source bytes remain unchanged.

Audit mG, each independent amount, exact independent sum, exact dependent, the stored legacy dependent, the old rounded residual, and their differences. Classify `EXACT_COMPATIBLE`, `LEGACY_ROUNDING_ONLY_COMPATIBLE`, or `INVALID_LEGACY_DATA`; the last class applies only to data invalid under the old contract. Historical model identity cannot silently upgrade to CRV3.

The frozen counterexample archives successfully and rejects active migration with the specified identifier. No projection, clipping, normalization, trace removal, redistribution, mG change, Et change, or substitution of rounded arithmetic is authorized. Migration has an exact identity contract and no 5% allowance. Incompatible states can continue only under their corresponding legacy executable/schema; reinitialization requires separate future authorization.

## Reverse migration

Downgrade is explicit and exact-only: all authorities must be exactly binary64 representable, legacy dependent closure must represent the identical physical state, and P2 identity including pure-phase signed zero must survive. Otherwise reject; never round a trace away.

## Qualification and scope

Fresh M1–M10 cover ordinary closure, exact-zero dependent, positive subnormal dependent, subnormal independent, the frozen counterexample, exact sum just below/above mG, pure gas +0, pure liquid −0, and a scaled trace-gas V3 state. M10 tests native V3/reverse behavior rather than inventing a binary64 source. Validate both temporal levels and unchanged source archive hashes.

Model/schema metadata references both the original design SHA and this document's SHA256. Frozen architecture v1, PDE, K, cPE, CRV3 stress/work, P2 authority, species PDE, EOS, TD1, and error budgets remain unchanged. The former restart blocker closes only after fresh migration gates pass. 2C additionally requires the already-running original-controlDict actual entry to reach its configured endTime and pass all existing correctness gates. Performance cost is recorded separately and cannot justify demotion or phase thresholds.

After 2C COMPLETE, resume CRV3-2 physical qualification with independent mixed weak/moderate BVP references, resolved fixed-mu and mu ladders, two dx-mu routes, O0 fits, traveling waves, entropy/work, and the frozen engineering gates. Stop when CRV3-2 completes; CRV3-3 is not authorized.
