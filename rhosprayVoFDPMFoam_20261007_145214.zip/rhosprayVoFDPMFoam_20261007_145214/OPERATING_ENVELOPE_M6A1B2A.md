# M6A1b-2A operating-envelope lock audit

## Current authority — M6A1b-2A.3 (2026-09-30)

Overall **M6A1b-2A COMPLETE as a project domain/policy design gate**. Expected
physical screening is 0.188330–6.201421 MPa / 299.440696–301.200448 K;
approved PRODUCTION is **0.10–8 MPa / 295–305 K**; project HARD is
**0.05–12 MPa / 285–320 K**, absolute pressure and inclusive boundaries.
These design support limits do not predict guaranteed CFD extrema.
The former 0.180–6.250 MPa / 299–302 K proposal is historical and superseded.
See [current assessment](M6A1B2A3_ENVELOPE_HARDENING.md) and
[domain/failure policy](EOS_OUT_OF_DOMAIN_POLICY.md); the machine-readable
authority is `fitting/liquid_eos_domain_contract.json`.
M6A1b-2B is NEXT / NOT STARTED. Production model selection, final reference
training/holdout generation and solver energy-offset alignment remain open.
No active solver or CFD case changes were made.

## Historical audit (superseded status statements below)


## Current injector input consistency gate — 2026-09-30

**M6A1b-2A.1 = PARTIAL / INJECTOR INPUT INCONSISTENT.** This section supersedes the historical ledger below where inputs differ. The final gas scenario is now LOCKED to the supplied air condition, approximately Mach 5.02; U=2013.039 m/s, p=188330.307 Pa, T=400 K and supplied rho=1.6338 kg/m3 are retained. C10H22 liquid inlet temperature is CONFIRMED at 300 K. Hole diameter is 0.3 mm; the user provides Nh=1, pending joint flow consistency. `internalNozzleIncluded=false` is CONFIRMED: the future boundary is the liquid exit plane.

The proposed per-hole mass flow is 1.09609 kg/s, while the previous total was 2.62583 kg/s. For Nh=1 these must be identical, but they differ: **MASS FLOW DEFINITION CONFLICT**. Both inputs are retained with conflict statuses; neither is selected or corrected.

At nominal rho=730 kg/m3 and A=pi*(0.0003)^2/4=7.06858347e-8 m2, the proposed 1.09609 kg/s implies a screening velocity of approximately 2.124e4 m/s. This is **PHYSICALLY INCONSISTENT FOR LIQUID JET INLET**. It is not an EOS density result or a formal inlet velocity. `UL_in` remains null/BLOCKED/UNRESOLVED. Review categories are mass-flow unit, total versus per-hole meaning, hole diameter definition, number of holes, and equivalent 2D injection definition; no automatic corrections are made.

`pL_exit` remains null/USER_REQUIRED. Neither gas freestream pressure nor supply pressure defines this exit static pressure without an explicit boundary physics definition. Pressure envelope and reference EOS grid remain BLOCKED. The inlet temperature is locked, but a complete liquid temperature envelope is not approved. Required user closure is limited to final total flow, actual unit of 1.09609, and liquid exit static pressure. No active solver or case is modified and no CFD is run.

**Result: GAS OPERATING CONDITION PARTIALLY LOCKED; LIQUID OPERATING ENVELOPE BLOCKED.** User-supplied future gas/fuel quantities on 2026-09-29 are recorded below. They are not values read from `300`/`300_2D`, and they do not establish an approved liquid p/T calibration interval.

## User-supplied target-condition ledger (2026-09-29)

| Quantity | Value | Status and interpretation |
|---|---:|---|
| Gas `U_inf` | 2013.039 m/s | Supplied freestream magnitude; direction not specified. |
| Gas `p_inf` | 188330.307 Pa absolute | Supplied freestream static pressure; distinct from retired SG parameter `pInf`. |
| Gas `T_inf` | 400 K | Supplied static temperature. |
| Gas `rho_inf` | 1.6338 kg/m3 | Supplied density. |
| Gas identity | air | Detailed species fractions, humidity and chosen gas thermodynamics still unspecified. |
| Gas `M_inf` | approximately 5.02 | Derived/check value, **not final Mach confirmation**; differs from the earlier Ma>7 design target. |
| Gas `q_inf` | approximately 3.31 MPa | Dynamic pressure `0.5*rho_inf*U_inf² = 3.310345 MPa`; not a liquid static pressure. |
| Fuel identity | C10H22 | User-supplied material. |
| Jet diameter | 0.3 mm | User-confirmed diameter per jet/hole; final number of holes unknown. |
| Fuel nominal `rho,Cp,mu` | 730 kg/m3; 2090 J/(kg K); 0.0024 Pa s | Nominal engineering inputs, **not** sourced multi-state EOS calibration observations. |
| Total fuel mass flow | 2.62583 kg/s | Sum over all holes; per-hole flow unknown. |
| Fuel phase metadata | latent heat 277000 J/kg; evaporation temperature 341 K; boiling point 447 K | User-supplied nominal/phase metadata; none defines `TL,in` or a p/T EOS data series. |

## M6A1b-2A.1 injector topology and source audit

`300/system/blockMeshDict` and `300_2D/system/blockMeshDict` place the injection position on/just above a continuous `bottomWall`. Their only gas-flow patches are `inlet`/`outlet`; no 0.3 mm internal liquid passage or liquid-inlet patch is meshed. The 3D DPM `coneInjection` uses a 300 µm disc at `(0.015,0,0.015)` m, `Cd=0.9`, `T0=300 K`, and `massTotal=0.00248 kg` over `duration=1 s`. The 2D reduction uses a point at `(0.015,5e-6,0.015)` m with equivalent 300 µm × 50 µm area, `dOuter=138.1976598 µm`, `Cd=0.9`, `T0=300 K`, and `massTotal=0.0005262723452 kg` over 1 s. Those are **historical Lagrangian case inputs**, not the newly supplied 2.62583 kg/s all-hole target and not a resolved VOF inlet. The old DPM `Cd`, parcel `T0` and injection mass have no authority for a new injector.

Accessible current cases, mesh setup, field boundary conditions, solver notes, previous reports, and available geometry/script/journal filename inventory provide no fuel-hole count, per-hole split, future injector topology, liquid inlet/supply static pressure, liquid inlet temperature or velocity, nozzle length, or approved back pressure. The old case gas inlet `(517.6 m/s, 102243 Pa, 166.67 K)` and its hot gas set-field region are separate historical conditions. `bottomWall` as a legacy boundary does **not** establish how the future VOF injector will be modeled. The two possible future branches and exact required inputs are specified in [the offline input contract](fitting/OPERATING_CONDITION_INPUT_CONTRACT.md).

The new [operating_conditions.json](fitting/operating_conditions.json) records confirmed, screening and unknown fields explicitly. [buildOperatingEnvelope.py](fitting/buildOperatingEnvelope.py) validates and computes only offline analytic screening. Using full supplied precision with `gamma=1.4, R=287`, it returns `M=5.021312`, `q=3.310345 MPa`, `p2=5.508506 MPa`, and post-shock `p02=6.201421 MPa`; the older approximate `5.506/6.198 MPa` figures below were rounded screening estimates. The new values are still **not liquid pressure bounds**. The ideal-air reconstructed density is `1.640508 kg/m3`, or `+0.41057%` relative to supplied `1.6338 kg/m3`; supplied density remains authoritative input pending final gas thermo definition.

For identical equal-flow 0.3 mm holes, `A_h=7.06858347e-8 m²`, `mdot_h=2.62583/Nh kg/s`, and nominal `U_h≈50887.53/Nh m/s` at the supplied **nominal** 730 kg/m³ density. This audit table deliberately does not select a design:

| Candidate `Nh` | `mdot_h` (kg/s) | Nominal `U_h` (m/s) |
|---:|---:|---:|
| 24 | 0.109410 | 2120.31 |
| 48 | 0.054705 | 1060.16 |
| 64 | 0.041029 | 795.12 |
| 96 | 0.027352 | 530.08 |
| 128 | 0.020514 | 397.56 |
| 192 | 0.013676 | 265.04 |
| 256 | 0.010257 | 198.78 |
| 384 | 0.006838 | 132.52 |
| 512 | 0.005129 | 99.39 |

The formal pressure template `p_min/max_expected`, `p_min/max_bound`, `p_min/max_safe` and the temperature template `TL_min/ref/max` remain null/BLOCKED. The base Ma≈5.02 scenario has only an analytic screening state; the future Ma>7 scenario requires exact `M,p,T` and remains BLOCKED. Future reference-grid axes and node counts are likewise deferred, as documented in [REFERENCE_EOS_DATASET_DESIGN.md](REFERENCE_EOS_DATASET_DESIGN.md).

For a screening *calorically perfect air* choice `gamma=1.4`, `R=287 J/(kg K)`, `M=U/sqrt(gamma R T)=5.0213`. From the supplied `p,rho`, the implied `R=p/(rho T)=288.178 J/(kg K)` and `M=U/sqrt(gamma p/rho)=5.0110`. The ideal-air density from `p/(287*T)` is 1.64051 kg/m3, 0.41% above the supplied 1.6338 kg/m3. This small mismatch may reflect rounding or gas-model/composition differences; freeze the final gas EOS/composition before declaring an exact Mach. The earlier `Ma>7` aim and the new `Ma≈5.02` input are **not reconciled**.

If all `N_h` holes are circular, identical, carry equal flow and use the *nominal* 730 kg/m3 density, `A_h=pi*(0.0003 m)²/4=7.06858e-8 m²`, `mdot_h=2.62583/N_h kg/s`, and `U_L,in=mdot_h/(rho A_h)≈5.09e4/N_h m/s`. This is a conditional mass-balance identity, not an inlet-speed prediction. `N_h`, unequal hole flows, discharge coefficient, pressure loss and actual compressible liquid density are unknown.

## Project evidence reviewed

`300/0/{U,p,T}`, `300/constant/sprayCloudProperties`, `300_2D/0/{U,p,T,N2,O2}`, `300_2D/system/setFieldsDict`, `300_2D/constant/{sprayCloudProperties,thermophysicalProperties}`, the active solver's M5B/energy/EOS notes, and the historical stage3 design notes were searched. Historical case copies and checkpoint cases repeat this legacy setup; they are regression artifacts, not a new Ma>7 production specification. The 3D `300` case has gas `(U,p,T)=(517.6 m/s,102243 Pa,166.67 K)` at inlet, a DPM cone injector `dOuter=300e-6 m`, `T0=300 K`, `flowRateAndDischarge`, and no specified liquid supply pressure. The 2D spray replaces the 3D circular injection area with an equivalent 300 µm wide × 50 µm deep slit, encoded as `dOuter=138.1976598e-6 m`; its cloud file mentions **nominal 48 m/s** in a comment, not a prescribed future resolved-liquid inlet boundary. The 2D gas `O2=0.228`, `N2=0.772` are mass fractions in this old case; they do not establish future composition. `setFieldsDict` has a separate 4.053 MPa/2000 K gas hot region. No future `alphaL` liquid-inlet p/T dictionary was found.

## Minimum decisions required to lock the final case

| Required future quantity | Status | Why needed |
|---|---|---|
| `M_inf` | approximately 5.02 from supplied gas state; **final value unconfirmed** | Earlier Ma>7 objective conflicts with this state. |
| `p_inf` absolute | 188330.307 Pa supplied | Gas freestream static pressure; not liquid pressure. |
| `T_inf` | 400 K supplied | Gas freestream static temperature. |
| Gas composition, including reactive species policy | air supplied; exact species fractions/model unknown | Needed to finalize gas `R`, `gamma(T,Y)` and source/energy conventions. |
| `p_L,in` static **or** supply pressure plus injector pressure-loss model | unknown | Liquid inlet and possible acceleration/loading. |
| `T_L,in` | unknown | Liquid reference and thermal bounds. |
| `U_L,in` or per-hole flow | unknown; total mdot=2.62583 kg/s supplied | Hole count and distribution are needed before speed can be inferred. |
| Number of fuel holes | unknown | Connects total mdot to per-hole jet state. |
| Final nozzle/jet geometry | diameter 0.3 mm supplied; hole count/layout unknown | Needed for entrance state and heat-exposure time; 2D equivalent slit is a legacy case reduction. |

If a *supply-to-exit* pressure drop and a discharge coefficient are supplied, a low-compressibility, single-phase, negligible-elevation estimate is `U_exit≈Cd sqrt(2(p_supply-p_exit)/rho_L)`. It also requires an accepted liquid density at supply/exit, defined downstream pressure, injector loss definition, and no cavitation/choking. For appreciable compression/heating, use the EOS and an isentropic/adiabatic nozzle energy balance with measured loss law; pressure drop alone does **not** determine U without those assumptions. An imposed mass rate plus area and exit rho could alternatively give `U=mDot/(rho A)`.

## Pressure-envelope construction once inputs exist

Keep **three distinct layers**:

1. **Physically expected range:** `p_L,in`, `p_inf`, estimated oblique/bow-shock interface states, plausible expansion/decompression states, and documented operating duration. Use gas mixture thermodynamics rather than the legacy 1.4/287 illustrative pair.
2. **Analytical loading bound:** for an ideal-gas screening surrogate, normal shock `p2/p1=1+2gamma/(gamma+1)(M_n1²-1)` and `M_n1=M_inf sin(beta)` for an oblique shock; compute post-shock total pressure from the corresponding `M2`. A normal shock is a conservative local gas compression model for given upstream M, **not** a theorem bounding transient liquid-interface spikes or focusing. Injector supply pressure may exceed it.
3. **Numerical safety envelope:** add declared low/high margins around physically expected/analytical states for EOS lookup, pressure-root bracketing and positivity; record the margin policy separately. Future interface peaks seen in CFD would trigger envelope review, but no CFD is run in this stage.

Pressure lower bound must consider injector exit/ambient and breakup-region rarefaction; phase validity at decompressed states is mandatory. Do not call the 0.1–10 MPa M6A1b-1 data-screening window a final calibration envelope.

**Conditional Ma=5.02 analytic scale:** with supplied `p1=188330.307 Pa` and illustrative constant `gamma=1.4`, a normal shock gives `p2≈5.506 MPa`; downstream isentropic stagnation gives `p02≈6.198 MPa`. These are gas-side calculations, not measured liquid interface pressure, not a maximum over all flow focusing, and not the final Ma>7 design bound. Oblique shocks depend on shock angle; injection supply pressure and decompression remain unknown. Therefore `p_L,min/ref/max` stay **unlocked**.

## Independent liquid-temperature envelope

Start at measured/planned `T_L,in`; estimate adiabatic mechanical compression along liquid loading paths using a complete liquid EOS, e.g. `de = -p d(1/rho)` for reversible isentropic compression, with a separate allowance for dissipative heating. If Eulerian interface heat transfer remains off, liquid `T_L` evolves primarily through its own compression/expansion and numerical/physical dissipation, **not** by assignment of gas post-shock temperature. If heat transfer is enabled, bound exposure using flux/area, liquid mass and intended simulation time; state whether evaporation/phase change is in scope. Do not use hot-gas 2000 K as `T_L,max`. At present `T_L,min/ref/max` cannot be locked.

## Corrected single-hole inputs — 2026-09-30 (current authority)

The user corrected per-hole flow to 1.09609e-4 kg/s and supplied exit static pressure 3 MPa (recorded as absolute). Nh=1, diameter=0.3 mm, internalNozzleIncluded=false, C10H22 TL,in=300 K and the supplied approximately Mach 5.02 gas state are confirmed. Total flow is therefore DERIVED as 1.09609e-4 kg/s; previous 2.62583 kg/s and mistaken 1.09609 kg/s are superseded, not alternative active inputs.

A=7.06858347e-8 m2 and nominal rho=730 kg/m3 imply U_nominal=2.124178 m/s. This is an offline mass/area sanity check, not an EOS density calculation or prescribed inlet velocity. Formal UL remains null. The injector input consistency gate passes; the earlier input-conflict sections are historical. Full liquid p/T envelope endpoints, thermal ceiling, phase validity and margins remain unapproved. Reference grid generation, EOS fitting and solver activation remain deferred. No active solver or CFD case is changed or run.

## M6A1b-2A.2 current authority — 30 September 2026

The current reference inlet, user-selected boundary control and provisional envelope are documented in M6A1B2A2_OPERATING_ENVELOPE.md. CoolProp 8.0.0 HEOS rho(3 MPa,300 K)=727.432960546 kg/m3 gives DERIVED reference U=2.1316743005 m/s; the mass-flow/300 K boundary lets pressure and velocity respond. User confirmed adiabatic mechanical scope. Candidate safe region 0.180–6.250 MPa × 299–302 K passes liquid-vapor phase checks, including reversible entropy paths and a limiting dissipative decompression path. Pressure and thermal engineering extrema remain provisional, so the overall stage is PARTIAL and M6A1b-2B does not start. The earlier null-input/conflict notes are historical where superseded. No active solver or case is changed.
