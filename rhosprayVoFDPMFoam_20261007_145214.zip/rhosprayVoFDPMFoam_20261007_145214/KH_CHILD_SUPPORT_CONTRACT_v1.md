# KH child support contract v1

Date: 2026-10-04. Gate: M8A.3B-T3B-R2C-K1. Acceptance: COMPLETE via PATH 2.

## Authority and scope

The current user request explicitly permits the revision in sections 14, 21 and 23. This document replaces only the impossible requirement that a newborn KH child at the parent's identical valid pose must immediately encounter spatial-invalid support. It preserves identity validation, independent preflight, support-first ordering, ownership, rollback, and subsequent movement checks.

Scope is the passive serial selected `r2::BoundCloud` graph, Foundation OF7, GCC11.4, C++11, DPInt32, x86-64, fixed mesh, scalar-cell/U-cellPoint and All=255 profile. It does not activate the production solver, certify MPI or production restart, or change the C2 native-compatible semantic-noncanonical binary contract. `transactionState-v1` remains canonical transaction authority.

## Source evidence and reachability

Actual installed sources were read; excerpts and SHA-256 are in `fitting/dpm/m8a3b_t3br2c_k1_v1/native_source_audit.txt` and `native_KH_birth_excerpt.txt`.

- Installed `src/lagrangian/spray/parcels/Templates/SprayParcel/SprayParcel.C:286`: copy construct child from parent; :287 allocate a new origId; :311 add child to cloud.
- Frozen local `tests/fiveEqDPMParcelC2/parcel/LazySprayParcel.C:290–322`: copy construct under `unique_ptr`, new origId, invalidate session, independent child preflight, native force/history/dispersion operations, then release to cloud.
- Frozen `LazyCarrierSession.H`: `NativePose::same` requires address, origId/origProc, position, cell, face, tet and barycentric coordinates; `preflightPose` clears validity before calling provider, and no parent-identity cache hit can authorize a child.
- Installed `src/lagrangian/basic/Cloud/Cloud.C:210`: ordinary cloud iteration calls `p.move` on each owned parcel, with no KH-child-only dispatch.
- Frozen local `LazyKinematicParcel.C:328–355`: trackToFace → invalidateAfterMove → setCellValues/preflight → dispersion/source correction/calc. Adopted children have the same parcel type and movement/query implementation. No distinct KH-child movement path is present.

Let S be the spatial pose, G the carrier generation, M the fixed support map, and R the identical All requirements. Spatial admissibility is F(S,G,M,R); it does not depend on parcel address, ID, diameter or KH history. A copy-constructed child has S_child=S_parent before its first query. Therefore F_parent=true implies F_child=true. Identity authority is separate: the parent's valid token must fail for the child even when their spatial predicates are equal.

This is a proof of immediate birth-space unreachability under the stated frozen contract. It is **not** a claim that an adopted child can never move into invalid support.

## Gate A — independent birth revalidation

1. New child address and origId are distinct from parent.
2. Shared tracking session is invalidated before independent child preflight.
3. Stale parent provider authority rejects the child before property sampling. The test-only negative assertion is labeled `IDENTITY_REVALIDATION_TEST`; it does not set an invalid-support flag or alter spatial data.
4. Independent child preflight at the same spatial pose succeeds with unchanged generation and All=255.
5. Native child creation and adoption proceed unmodified.

Fresh final run: 92 birth checks, 92 stale-parent identity rejections, 5,694 later child queries. Every birth has equal position/cell/face/tet/barycentric coordinates and distinct identity. Negative identity checks make zero property calls. Full records: `KH_valid_final/KH_identity_audit.jsonl`.

## Gate B — post-adoption contract

Any later child query follows the same generic movement/support contract:

native movement → actual current-tet contributor discovery → preflight → either valid properties/models or controlled trial rejection.

After rejection there are no additional rho/T/Y/Cp/mu/kappa calls, no accepted source or output publication, and the entire trial is discarded. Rejection is not physical parcel deletion.

The fixed mixed/pure fixture attempt creates valid children at dt=1e-5, then executes native cloud motion at dt=0.1 without moving the child manually or changing its velocity, topology, requirements, support flags or KH formulas. Population after birth is 217. The first spatial-invalid query is **parent origId=107**, owner cell 1, alphaG=0.5, mG=6.5019509848922681, with gas-absent stencil entities 18–21. Thus child-first invalidity was not constructed: **POST_BIRTH_INVALID FIXTURE_UNREACHABLE for this tested fixture/path**, not universal unreachability. PATH 1 is not claimed.

PATH 2 coverage:

- Fresh generic kinetic motion into invalid U-cellPoint stencil, valid owner cell: PASS, 87 checks, 10 future accepted comparisons.
- Fresh pure-liquid owner geometric tracking/query: PASS, 87 checks, 10 future comparisons. This is native `particle::track` followed by actual preflight; it is not a full kinetic trajectory past the earlier strict-stencil rejection.
- Fresh R2B support-first replay: 252,194 checks, no local whole-field Cp/kappa materialization.
- Fresh I1 matrix/native-false/retry: 12,083 / 18 / 61 checks, zero failures and zero final live parcels.
- Fresh KH valid and reachability-attempt transactions: 108 / 112 checks, zero failures, 11 direct/retry canonical state pairs each (initial accepted state plus 10 subsequent accepts), 77 accepted output files per path exactly equal.

All post-rejection property counter deltas are zero. Full trial discard restores parent/child population, IDs, allocator, RNG/cached normal, KH history, carrier state/generation, sources, output and pending tickets, checked through the frozen canonical codec and lifetime counters.

## Ownership boundary

Before adoption: child-local `unique_ptr` owns the newborn, including exceptions during its first query.

After adoption: cloud owns the child as an ordinary parcel. Trial destruction releases it with the parent and all trial-owned parcels. At each audited boundary ctor=dtor+cloud-owned-live; both fresh KH runs finish with 11,562 constructors, 11,562 destructors and live=0.

## Acceptance and retained limits

OLD retired: newborn first query must be spatial-invalid at the identical valid birth pose.

NEW accepted: newborn independently revalidates identity and support at birth; every subsequent query obeys the generic runtime support contract.

K1 COMPLETE via PATH 2. The former `KH_SPATIAL_INVALID_SUPPORT_UNCLOSED` acceptance item is closed by **REACHABILITY-CONTRACT REVISION**, not by a fabricated spatial-invalid child result. Prior R1 evidence remains unchanged and historically PARTIAL. R2C can be COMPLETE within the audited passive serial scope after reevaluation of its other frozen gates.

R2-FINAL is next-round-only and not executed here. T3B/T3 and M8A remain PARTIAL; T4/M6B/CFD remain NO. ORourke retains its native physical conservation limitation. Production restart remains NOT CERTIFIED.
