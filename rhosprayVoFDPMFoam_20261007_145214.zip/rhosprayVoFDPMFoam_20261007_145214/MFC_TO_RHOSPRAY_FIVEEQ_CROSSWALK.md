# MFC to rhosprayVoFDPMFoam crosswalk — M5B.1

Pinned source and exceptions: MFC_FIVE_EQ_SOURCE_AUDIT.md. Governing contract:
FIVE_EQ_GOVERNING_CONTRACT.md. These are future design interfaces, not runtime.

| MFC concept | Project contract | Decision / KT-specific work |
|---|---|---|
| alpha_rho | mG,mL in kg per total m3 | adopt partial-density meaning |
| N adv alpha slots in ordinary path | one alphaL, alphaG=1-alphaL | do not port layout |
| sum partial densities | rho=mG+mL | one derived owner after atomic activation |
| shared momentum | M=rho*U | adopt |
| shared total energy | Et=sum(m_k e_k)+rho U^2/2 | adopt, retain distinct TG/TL |
| analytic coefficient pressure | generic phase energy residual R(p) | reject analytic SG mixture formula |
| EOS dispatch/phase helpers | immutable gas/liquid stateRhoP records | adopt layering; validity/reference contract required |
| ordinary model_eqns=2 | ALLAIRE_BASELINE K=0 | first activation only, not final physical optimum |
| alt_soundspeed | later Kapila model + Wood/K | retain paired extension, not copy source discretization |
| mixture acoustic evaluation | fiveEqAcoustics with betaG,betaL | derive arbitrary-EOS Allaire eigenvalue |
| Riemann NC interface exports | KT shared state/velocity/time-level contract | derive anew, no HLL/HLLC/HLLD traces |
| mpp_lim | alpha/mass/density/presence checks | no post-hoc conservative clipping |
| phase denominator floors | presence branch before m/alpha | no enormous hidden rho or fabricated absent phase |
| mixture_err | explicit c^2 validity/failure | no synthetic acoustic floor |
| WENO/MUSCL reconstruction | current KT directional reconstruction | preserve project route; contact gate needed |
| THINC/MTHINC | future separately designed coupled sharpening | no direct port; first activation none |
| MULES counterpart | boundedness/limiter/subcycle infrastructure | compression separately OFF; synchronize time levels |
| CFL acoustics | recovered model cMix, pure cG/cL | no gas-only c in liquid cells |
| capillarity | M7 mixture momentum and consistent energy work | no current coupling |
| particles/bubbles | later independent gas-carried DPM population | alphaG+alphaL=1 excludes parcels |

## Adopt conceptually

Partial phase masses; shared M/Et; one-pressure/one-velocity closure; material
alpha law; EOS abstraction; phase-presence switching; positivity detection;
model-consistent acoustics and nonconservative source concepts.

## Do not port

WENO or MFC MUSCL implementation, HLL/HLLC/HLLD, analytic SG mixture pressure,
transformed EOS parameter sets, THINC code, Riemann-coupled K discretization,
Fortran/GPU memory layout, conservative clipping, denominator/acoustic floors,
mixture temperature assumption or any state-dependent acoustic branch without
a derivation for this selected PDE. No upstream source is copied into the solver.

## Stage implications

M6A1b-2B remains NEXT / NOT STARTED: compare production liquid EOSs over the
approved domains with beta, acoustic identity and invertibility checks, not
rho/Cp fits alone. M6A2 follows accepted EOS + energy alignment and implements
the recovery/presence/root interfaces. M5C/M6B follows those gates and resolves
KT alpha/contact consistency; ALLAIRE_BASELINE and artificial compression OFF.
Kapila/sharpening require subsequent independent milestones. M7 and later DPM
source/transfer work remain deferred.
