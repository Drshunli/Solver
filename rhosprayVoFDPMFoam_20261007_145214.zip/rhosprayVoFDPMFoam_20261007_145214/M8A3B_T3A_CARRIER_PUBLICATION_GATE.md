# M8A.3B-T3A stable carrier publication gate

Evidence: `fitting/dpm/m8a3b_t3a_v1/carrier_verified`. Local Foundation7 wmake PASS; independent native/offline tests only. Earlier carrier/carrier_final attempts are retained.

## 1. T3A status

**COMPLETE / PASSIVE SERIAL TESTED CONTRACT.** Carrier refresh blocker closed for the represented gas-present native view, fixed topology and explicit test boundaries. This does not activate the solver or close T3.

## 2. Original stale-carrier counterexample

Original legal tiny dt changes My while reconstructed clouds borrow old U. The native case is reproduced without clipping or forcing any source to zero. Current stable view produces new Uy from accepted M. Exact A evidence:

```csv
cell,dMx,dMy,dMz,dEt,UyOld,UyStaged
0,1.5509636485369269e-24,2.1175823681357508e-22,0,-1.7450285954455693e-18,0,1.6284207409868973e-23
1,0,0,0,0,0,0
```

The transverse increment matches the original counterexample. dEt is recomputed from the actual refreshed native thermo/parcel state; it is not forced to a historical bit pattern.

## 3. Carrier authority hierarchy

Only P2,mG,mL,M,Et,mYi are authoritative. Carrier rhoG,p,TG,YG,U and derived thermo/transport are staged by frozen common-pressure recovery; no old field participates as an authority.

## 4. Carrier reference graph

See [CARRIER_REFERENCE_GRAPH.md](CARRIER_REFERENCE_GRAPH.md): direct volField references, thermo, runtime composition, trackingData copies, point caches, registry turbulence, wall oldTime and all eight selected models. Local Foundation7 source copies are retained for reproducibility.

## 5. Stable carrier ownership

Native mesh/thermo/SLGThermo and rho/U outlive both clouds. The Eulerian view layer manages contents and owns diagnostic Cp/kappa only. Role A/B retain stable external references; no role-owned private gas field becomes active later.

## 6. Actual field publication mechanism

Actual OF7 mutable element buffers are cached once during construction using primitiveFieldRef/boundaryFieldRef. Prepare validates registered identities, dimensions, patch sizes, storage addresses and buffer counts. Publish performs bounded scalar/vector writes plus native timeIndex/eventNo updates, with no assignment/transfer API assumption.

## 7. Interpolation refresh semantics

Actual cellPoint owns const psip_ and uses registry point-cache freshness via event numbers. Publish reserves/sets a new event; next trackingData construction rebuilds native point values. Generation guards reject old trackingData. Cached-native off-centre results agree exactly with a separately constructed native cache=false reference.

## 8. Thermo/transport refresh semantics

TG,YG,p,rhoG derive from Q. Native JANAF/perfectGas/Sutherland mixing produces Cp,mu,kappa,he,psi,alphah. Publish native thermo:mu/psi/alpha and p/T/he/Y together. Native Cp() recomputes the current mixture; native kappa()=Cp()*alpha_. No thermo.correct or mass-fraction normalization is used during publication.

## 9. Carrier generation mechanism

Committed generation advances exactly once per publication and does not advance on discard. Each role records the expected generation; cloud access and guarded native scalar/vector interpolation reject mismatches or in-progress publication. Diagnostic generation is not a conserved physics variable.

## 10. prepareCommit architecture

validateTrial checks generation and unchanged carrier snapshot. prepare recovers every candidate cell and invokes frozen support classification on the same Q; explicit owner-Q boundary buffers are staged locally. prepareCommit validates native field schema/registry/storage, allocates complete publication buffers and reserves a native event. Exact Q/P2 bits are sealed; mutation through a held alias is rejected before the first committed write.

## 11. publishCommitNoFail architecture

All throwing precondition/seal checks occur before the publication region. The region excludes observers, copies prepared field buffers, updates metadata, swaps one RoleState pointer containing cloud+Q+logical time/allocator, assigns generation and opens access only after coherence. No EOS, model evolution, registry lookup, allocation, output or callback occurs after the first committed write inside this region. Old role retirement occurs after the coherent state is visible. This is serial logical atomicity, not concurrent/MPI atomicity.

## 12. Discard behavior

Trial/staged objects are destroyed; committed carrier values and generation remain exact. Q and active cloud are never mutated by trial publication preparation. Native trial clock is overlaid/restored for evolve. No persistent native output is admitted; full source-event/output transaction semantics remain T3.

## 13. CV-1 transverse momentum result

PASS in A/B/C. Native dt=1e-30 produces nonzero My; precommit carrier is unchanged, published Uy equals M_y/(mG+mL), and actual promoted trackingData reads it. The immediately following native tiny step is compared with a direct reconstructed accepted reference: parcels, sources and allocator agree; next-step carrier queries match.

## 14. CV-2 mass result

PASS. Actual native single-parcel mass/evaporation probe changes mG consistently with dmYi. Recovery publishes intrinsic rhoG and common U; cloud scalar/vector queries see accepted values. This is a mass-source probe, not a fabricated source that changes only one conserved scalar.

## 15. CV-3 thermal result

PASS. Actual native heat probe changes Et and recovered TG. Native T,Cp,mu,kappa query results match independently evaluated accepted gas state (transport relative tolerance 2e-12; direct p/T/rho/U/Y comparisons exact).

## 16. CV-4 species result

PASS. Actual native C10H22 mass transfer changes gas composition. Runtime N−1 independent fractions are mYi/mG; residual last is 1−sum(first N−1), without clipping/normalization. Native mixture/Cp/transport observe the new Y.

## 17. CV-5 combined result

PASS. Actual combined native event changes mG,Mx,My,Et,mYi, then frozen source adapter/recovery and carrier publication/query checks all pass. No frozen source/energy equation was edited.

## 18. Mixed-cell result

PASS at alphaL=0.1,0.5,0.9 with actual native combined sources. P2 and mL remain unchanged for ordinary DPM exchange; U uses total bulk mass and gas properties use intrinsic gas recovery.

## 19. Trace-gas result

PASS at alphaG=1e-20. A small positive native parcel multiplicity generates a legal source; frozen P2 authority retains TRACE_PRESENT and native rhoG/thermo/next-query refresh passes. No decoded 1−alphaL subtraction replaces trace storage.

## 20. Pure-liquid result

PASS controlled refusal: gas absent cannot manufacture rhoG/TG/YG. Preparing a gas-absent carrier view fails before any committed write. Limitation: this harness bank requires gas-present represented cells; general publication over a production domain containing liquid cores needs an explicit supported/absent-field policy and support-controlled query access before activation.

## 21. A→B promotion

PASS. Inactive cloud is reconstructed with native owner-bound models and frozen typed history import. Its references bind the same stable external view. Accepted Q, cloud role and carrier generation publish coherently.

## 22. B→A promotion

PASS. The reverse promotion uses the same primitive and checks. No private role carrier copy or role-name field replacement is used.

## 23. Repeated role-swap result

Each seed completes 129 accepted promotions, including 100 consecutive A/B swaps driven by newly evaluated native momentum probes at the current committed carrier state. Every promotion increments generation and validates actual native queries.

| Seed | Evolved steps / parcels | Checks | Failures | Promotions | Prepare/discard | Future steps | Final generation |
|---|---|---|---|---|---|---|---|
| A | 5 / 106 | 21465 | 0 | 129 | 1000 | 10 | 130 |
| B | 7 / 148 | 21465 | 0 | 129 | 1000 | 10 | 130 |
| C | 9 / 190 | 21465 | 0 | 129 | 1000 | 10 | 130 |

## 24. Promoted-cloud carrier query

PASS for rho,p,T,Cp,mu,kappa,U and native runtime Y. Direct cloud references remain stable. Cell-centre U equals accepted M/total mass exactly; off-centre point interpolation agrees with a native cache=false reference. Known boundary values also match staged owner Q.

## 25. Next-step interpolation result

PASS. No old trackingData is reused across a publication. Generation assertions reject it even where a scalar interpolation could otherwise borrow a newly updated field; Cp/kappa and point data are reconstructed at next native trackingData creation.

## 26. Post-commit future equivalence

PASS: 10 native future steps for each A/B/C accepted state. Repeated role-reconstruction path agrees with a direct reconstructed reference on complete native parcel serialization/traversal, native source buffers, 128-output mixed RNG probe, injector mutable-state key, allocator and carrier queries. Carrier Q is prescribed/held for this comparison; native evolving sources/injection admission are not promoted into a new event-ledger Q. This is future carrier/model equivalence, not the full source/Q/output retry proof reserved for T3.

## 27. Support/Q generation consistency

Staging invokes unchanged fiveEqDPMCarrierSupport from the same candidate Q and frozen recovery. Gas support authority remains P2+mG+thermo legality, never cached rho existence. Owner-Q boundary construction has the same support state. The existing exact native-footprint support scan is rerun unchanged; general runtime stencil hooks and future nozzle contributors remain T3/future-patch work.

## 28. Registry result

PASS. Each A/B/C performs 1000 prepare/discard cycles with unchanged registered object count and stable rho/U identity. Every prepare checks all managed scalar registrations and U registration/storage/schema. Local staged buffers are unregistered; next native point-cache replacement is outside the no-failure publication region.

## 29. Output observer result

PASS in the serial harness: cloud access and interpolation reject in-progress publication; no callback or output observer is invoked in its straight-line publication region. Fixture file trees are hash-equal to their authored 0/constant/system contents; zero native persistent output files were created. Diagnostic CSV/logs are test evidence. Durable accepted-output promotion remains unimplemented.

## 30. Frozen regression result

PASS: source/energy9288, A/B/C cloud independence6375, native support1725880, all-gas21000/21000, critical P2/recovery/R1 checks105775, subULP1000 steps/scheme, temporal/restart9663. All eight golden_energy.csv files are byte-identical to T3 evidence. No historical result was overwritten.

## 31. Project-local overrides

New test-only interpolation dictionary-factory wrappers delegate unchanged to native OF7 factories and reject stale generations. StableCommittedCarrierView and CarrierTransaction exist only in the new harness directory. Reused frozen modelAdapters/outputIsolation are unchanged. No $FOAM_SRC edits or new active libraries.

## 32. Active solver impact

**NONE.** Active solver/source/Make, actual 300_2D mesh/BC/dictionaries, frozen source/energy/P2/R1/EOS/recovery and prior evidence pass SHA-256 protection. Only newly created T3A preparation tooling and the milestone documentation are allowed to differ from the pre-change list. No CFD run.

## 33. Remaining blockers

Full T3 native event ledger, closed RNG/model codec, injection admission, KH child/collision/merge/delete retry, strict-support runtime hooks, failure/retry equivalence, conservation ledger and persistent accepted output remain. Production gas-absent view policy, future nozzle BC, fixed-value/dynamic wall semantics and MPI remain outside this tested contract.

## 34. Whether T3A COMPLETE

YES for the explicit passive serial fixed-topology carrier-publication contract. The original stale-U blocker is resolved by stable fields and generation-aware next-step interpolation. This is not a production or arbitrary-mesh/BC certification.

## 35. Whether T3 may resume

YES in a subsequent separately requested turn, using this tested stable carrier view design. This turn does not resume any T3 event matrix.

## 36. Whether T4 may start

**NO.** Resumed T3 must first be COMPLETE.

## 37. M8A status

**PARTIAL.** T3A does not close the overall DPM transaction gate.

## 38. M6B.0 permission

**NO.** No unified two-phase KT runtime activation.

## 39. M6B.1 permission

**NO.** No active two-material flow solve.

## 40. Updated milestone matrix

| Milestone | State |
|---|---|
| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE |
| M8A source/energy | PASS / FROZEN |
| M8A.3A | COMPLETE |
| M8A.3B-T1 | COMPLETE / DESIGN ONLY |
| M8A.3B-T2 | COMPLETE / STRICT-SUPPORT FEASIBLE |
| M8A.3B-T3A | COMPLETE / PASSIVE SERIAL TESTED CONTRACT |
| M8A.3B-T3 | PARTIAL / carrier-refresh blocker closed; full transaction pending |
| T4 | NO |
| M8A overall | PARTIAL |
| M6B.0 | BLOCKED / NO |
| M6B.1 | NO |

STOP. No resumed T3, T4, M6B, CFD or production activation in this turn.
