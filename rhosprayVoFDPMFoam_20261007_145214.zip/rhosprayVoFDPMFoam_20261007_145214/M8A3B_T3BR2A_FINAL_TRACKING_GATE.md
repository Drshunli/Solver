# M8A.3B-T3B-R2A-FINAL — full native trackingData closure gate

2026-10-03。**架构审计停止报告；完整链未执行。**

# 1. R2A-FINAL status

**PARTIAL / TRACKINGDATA_ARCHITECTURE_BLOCKER / STOP.** 按用户附件第47节停止集成。完成实际源码调用图和依赖审计；没有完整跟踪链的新验收通过声明。

# 2. Full tracking caller graph

见 FULL_TRACKING_QUERY_GRAPH.md；从实际 cloud.evolve 开始，覆盖构造、注入、move、表面、source correction、wall及下一查询。

# 3. ThermoParcel trackingData audit

私有 const 全场 Cp_/kappa_；构造时立即求值。[ThermoParcel.H:159](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcel.H:159)；[ThermoParcelTrackingDataI.H:35](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcelTrackingDataI.H:35)。类型探针9/0仅检查接口，不执行构造。

# 4. SprayParcel trackingData audit

SprayParcel的trackingData直接typedef父层；没有额外可延迟构造层。[SprayParcel.H:131](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/spray/parcels/Templates/SprayParcel/SprayParcel.H:131)。

# 5. Earliest support gate

需要在构造原生TD之前及后续每次carrier-dependent入口验证实际支撑；当前setCellValues入口过晚。stock TD没有parcel-aware deferred handle接口，故未激活新完整入口。

# 6. Property dependency DAG

PROPERTY_DEPENDENCY_DAG_v1.md已建立；是静态依赖契约，当前native ctor仍存在绕过support root的全场Cp/kappa路径。

# 7. Surface-property classification

区分parcel-local液体属性与carrier-dependent输入；Ts/Tav/气体表面rho/mu/kappa/Pr需先support；液体rhoL/CpL/muL/sigma/pv本身不改为gas属性。

# 8. Source-correction classification

Kinematic动量修正、Thermo热修正、Reacting质量/组分Cp修正及Bird surface composition接口已核对；.psi()[cell]和直接carrier Y访问不能由interpolation accessor单点检查覆盖。

# 9. Exact pure-liquid full-chain result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 10. Pure-liquid property-call counters

本轮完整纯液体路径计数=未测，而非0/PASS。API探针没有构造thermo/parcel；不能据其零对象构造推出纯液体full-chain通过。冻结query-core的零调用证书范围不升级。

# 11. Mixed-cell result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 12. Trace-gas result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 13. U-stencil-invalid result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 14. Scalar-only requirement result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 15. All-gas result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 16. 21000-cell full-chain result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 17. 1725880 interpolation result

历史冻结1725880项/0failures保留，本轮STOP后未重跑；不是full-chain新结果。

# 18. Rebound mixed-domain result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 19. Rebound invalid-domain result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 20. Post-rebound first-query timing

native move先setCellValues/dispersion/correction/calc，再postMove/hitFace/native wall；下一段必须用当前tet重新preflight。新bridge与RB1/RB2探针未实现。

# 21. Movement cache invalidation

旧query-core有position/cell/face/generation guard；native实际coordinates/currentTetIndices路径还需完整key与比对。本轮不宣称旧token覆盖全部tet变化。

# 22. Injection birth query timing

实际born路径见[InjectionModel.C:477](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/submodels/Kinematic/InjectionModel/InjectionModel/InjectionModel.C:477)。setParcelThermoProperties/checkParcelProperties/初次move需要桥接；尚未新的bookkeeping半提交验收。

# 23. KH child query timing

原生KH child立即使用父ttd进行force/dispersion：[SprayParcel.C:295](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/spray/parcels/Templates/SprayParcel/SprayParcel.C:295)。必须建立child独立token，不能把parent支持结果当作新认证；尚未实现。

# 24. ORourke survivor query timing

碰撞后carrier packet只有全部依赖不变才可复用；surface-derived量还依赖parcel T/Y/U/d修订。native ORourke及其limitations不改；新survivor首查询未测。

# 25. Source-correction ordering result

静态ordering已确认；native correction在setCellValues之后，但构造TD更早。未通过“invalid情况下sourceCalls/writes=0”的完整链运行验证。

# 26. Surface-property ordering result

依赖分类完成；carrier-dependent与纯parcel-local liquid调用分别记录；未运行完整链计数。

# 27. Runtime crossing result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 28. Exact gas-absent crossing

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 29. Reject/discard/retry result

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 30. Canonical equality

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 31. Future >=10-step equality

NOT RUN / BLOCKED：尚无安全的完整原生 trackingData bridge；不把旧 query/force kernel 结果替代本轮 full-chain 验收。

# 32. GasSupportMap result

冻结GasSupportMap仍支持P2/mG异构phase authority；未要求全场gas-valid；本轮未改核心。native TD对此地图没有消费接口，是桥接缺口。

# 33. Generation result

冻结generation安全性保留；新完整TD的generation/pose/tet/stencil/requirements及child identity绑定未实现。

# 34. Cache result

不增加stale/fake carrier缓存。原生TD与query packet的ownership差异明确；所需movement/rebound/property-local revision失效规则仅审计。

# 35. TransactionState impact

NONE。旧transactionState-v1与codec未改，没有序列化ABSENT fake gas。

# 36. Output impact

NONE。没有运行新的native evolution或持久化parcel event输出；reject/output exactly-once完整链测试未测，不引用旧R2结果冒充新结果。

# 37. Eight-model property-chain result

八模型stage/property/mutation已静态分类，见DAG文档；全部full-chain integration结果BLOCKED/NOT RUN。

# 38. Performance

完整链preflight/lazy build/materialization成本未测。不把旧query-core microbenchmark当作完整链性能，也不作CFD性能推断。

# 39. Registry/memory

未构造完整cloud，不新增registry/RSS全链测量。API-onlyprobe9项通过，不是memory certification。

# 40. Source/energy regression

历史冻结9288 PASS；8energy goldens冻结；本轮未重跑、adapter/能量约定未改。

# 41. M8A.3A regression

历史冻结6375 PASS；本轮未重跑。

# 42. T2 regression

历史query-core273263/0、all-gas21000逐位一致和T2原生1725880/0保留；本轮都未重跑或升级到full-chain。

# 43. T3A regression

历史冻结64395 PASS；本轮未重跑。

# 44. P2/R1 regression

历史冻结105775 PASS；本轮未重跑。

# 45. Temporal/restart regression

历史冻结9663 PASS；本轮未重跑。

# 46. R2 event regression

历史冻结21432 PASS；本轮未重跑，不恢复R2事件/closure开发。

# 47. Active solver impact

NONE。145份受保护源码/实际case文件与47份冻结R2A target文件哈希一致；active Make、生产mesh/BC、native ORourke不改。本轮仅新API审计目标、源码快照、文档、状态追加；API-only OF7 wmake PASS、9/0。未运行CFD。

# 48. Whether R2A COMPLETE

NO。R2A及R2A-FINAL均保持PARTIAL，触发附件47的TRACKINGDATA_ARCHITECTURE_BLOCKER。

# 49. Whether R2 final closure may start NEXT ROUND ONLY

NO。下一轮应先解决专用local trackingData/type-family ownership架构；只有R2A-FINAL COMPLETE之后，另一次工作才恢复R2 final closure。

# 50. Updated milestone matrix

见下表；本轮STOP。

| Milestone | Status |
|---|---|
| M8A source/energy | PASS / FROZEN |
| M8A.3A / T1 / T2 / T3A / O2D | 保持既有冻结状态 |
| R2 | PARTIAL |
| R2A query core | PASS / FROZEN（历史273263/0） |
| R2A / R2A-FINAL | PARTIAL / TRACKINGDATA_ARCHITECTURE_BLOCKER |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NO |

## Evidence and limits

Actual local Foundation OF7 sources are copied/hash-recorded in fitting/dpm/m8a3b_t3br2a_final_v1/native_sources. `api_probe.json`=9/0; fullTrackingExecuted=false. Existing R2A target/archive fingerprints preserved. Probe build is NOT a full native tracking integration build. No fake carrier or passive poison state is constructed. No new runtime full-chain numerical counters, performance, output, canonical equality or CFD results are claimed.
