# M8A.3B-T3B-R2C-R1 — Remaining serial transaction closure

## 1. R2C-R1 status

PARTIAL / PARCEL_CODEC_BLOCKER / STOP. The binary parcel stream extent includes test-only object size and crosses the actual parcel payload boundary. No remaining gate is promoted to COMPLETE. R2B and I1 remain frozen at their previously certified scopes.

## 2. I1 frozen regression

I1 sources, guard, Cone physics, registration and binaries unchanged (240 frozen I1/R2B entries verified). Reused frozen binaries for fresh I1 injection retry and 1000-invalid-birth matrix. No ownership redevelopment or global allocation interceptor.

## 3. Runtime support retry

Fresh selected existing-parcel movement subset: 62 checks, 0 failures; dtLarge=0.1 s actual native motion reaches GAS_SUPPORT_INVALID:EXACT_GAS_ABSENT, discards, then retries dtSmall=5e-8 s. Canonical state, committed carrier and query equality through 10 further accepted steps PASS. One existing parcel survives the failed trial until discard; no newborn is injected by this movement-only action. 51 constructors=51 destructors, live=0. Complete runtime error/invalid-query property-counter certification is still OPEN.

## 4. Pure-liquid movement crossing

Fixture: existing eight unit cells, first two gas, remaining six pure liquid; initial parcel in cell 0 at its native centre, before either path. Native motion crosses strict contributor support boundary; neither a newborn rejection nor an artificial reflection/freeze/deletion is used. Failed trial still owns its one parcel. The owner-cell alphaG/mG and per-property counters at the first invalid query were not recorded in this first subset, so exact entry into a pure-liquid owner cell and all requested post-invalid counters are NOT certified; this gate remains PARTIAL. A strict stencil may reject before the owner cell itself becomes pure.

## 5. Trace full transaction

NOT RUN in R1 before STOP. Earlier trace query spot proof remains frozen; it is not a full move/source/QTrial/reject/retry proof.

## 6. Mixed 0.1 result

NOT RUN in R1 before STOP. No full-graph promotion.

## 7. Mixed 0.5 result

NOT RUN in R1 before STOP. No full-graph promotion.

## 8. Mixed 0.9 result

NOT RUN in R1 before STOP. No full-graph promotion.

## 9. Rebound mixed result

Full R1 transaction NOT RUN. Frozen R2B spot proof and I1 established core are retained, not expanded.

## 10. Rebound invalid result

NOT RUN in R1 before STOP; old-token reuse and invalid next-query transaction closure remain OPEN.

## 11. KH invalid-child

NOT RUN in R1 before STOP. Native KH child physics and frozen existing child guard untouched. Its first-query support/reject/future/lifetime matrix remains OPEN.

## 12. Injection ownership regression

Fresh frozen I1 actual newborn valid-start→invalid-support→guard cleanup→discard→small retry replay PASS: 61 checks,0 failures;10 future steps;243 constructors=243 destructors,live=0. All-gas native accepted 328-state equality remains the frozen I1 reference (not newly rerun this round).

## 13. ORourke no-collision

Full R1 required branch replay NOT RUN. Native physics unchanged; historical subset evidence remains frozen.

## 14. ORourke grazing

Full R1 required branch replay NOT RUN. No collision correction or RNG changes.

## 15. ORourke coalescence

Full R1 required branch replay NOT RUN. No KE thermalization.

## 16. ORourke cleanup

Full R1 required positive-residual cleanup replay NOT RUN. Native cleanup unchanged.

## 17. ORourke count reduction

Full R1 branch and future matrix OPEN; no certification from scenario names alone.

## 18. ORourke lifetime

Branch-specific exact lifetime/ownership checks NOT RUN. No newly discovered ORourke unowned path is claimed.

## 19. Minimum-mass deletion

Not newly replayed in R1 before STOP. Frozen I1 actual native move(false) evidence remains valid: two one-ctor/one-dtor runs, native carrier transfer distinct from failed-trial guard destruction. No semantic change.

## 20. Evolved iNew/read-write

PARCEL_CODEC_BLOCKER. Preliminary stream safety probe is decisive even before the evolved-population matrix:

- Frozen I1 outer LazySprayParcel adds `i1::LifetimeToken lifetime_{this}` before physical fields.
- The inherited raw length remains `sizeof(LazySprayParcel<ParcelType>) - sizeof(ParcelType)`.
- Actual length=128 bytes; contiguous `d0` through `user` physical span=120 bytes.
- Writer starts at `&d0_` but writes 128 bytes: it consumes eight bytes beyond the complete parcel object.
- Reader similarly writes eight bytes past the parcel boundary.
- Two identical physical objects with different reserved trailing sentinels produce different binary output.
- Readback copies that sentinel into reserved trailing storage.
- Native ASCII physical state is identical; native binary parcel length=355 bytes, instrumented local length=363 bytes.
- Physical fields in this controlled local roundtrip are still equal. This is an extent/non-authoritative-data corruption blocker, NOT a claim that a particular physical scalar was lost in this probe.

The probe allocates 32 extra reserved bytes around its placement-constructed parcel and controls its destructor. No ordinary heap boundary is overwritten; no global allocator interception. Three instrumented constructors=three destructors,live=0. Process exit3 intentionally records the blocker. Source:`tests/fiveEqDPMParcelCodecR2CR1/testParcelCodec.C`; result:`codec_probe_v1/codec_result.json`.

## 21. Combined mixed event

NOT RUN after STOP. No coupled mixed-event capability claim.

## 22. Canonical equality

Selected existing-parcel direct/retry plus10 future steps PASS; fresh I1 replay PASS. The current transactionState-v1 uses ASCII parcel stream plus typed scalar-bit restoration and excludes lifetime counters. Passing that canonical packet does not certify the separate binary parcel IO path.

## 23. Ownership equality

Selected movement path checks all live instrumented parcels against accepted-cloud plus seed-cloud populations at each accepted step, cumulative ctor=dtor+live, and exact baseline after large rejection. Final51/51/live0. I1 replay243/243/live0;stress1009/1009/live0;fenced IO probe3/3/live0. No new unowned model object was found in the executed subset. Unexecuted graph branches remain OPEN.

## 24. Direct/retry equality

PASS for selected existing-parcel crossing subset and fresh I1 injection replay. No post-hoc identity renumbering. Other requested mixed/trace/KH/rebound/ORourke cases are not inferred from these results.

## 25. Future equivalence

Both executed transactional subsets continue 10 additional accepted steps, with canonical/carrier/query equality and exact lifetime closure. No evolved binary restart equivalence claim.

## 26. Output semantics

Existing-parcel large support reject and fresh I1 reject publish zero accepted output; small accepted steps use existing staging/publish machinery. All branch-specific full R1 exactly-once/error-output matrix remains OPEN.

## 27. Sequential lifecycle

New >=100 injection/movement/nonzero-source mixed acceptance sequence NOT RUN before STOP. I1 earlier all-gas core remains frozen.

## 28. Alternating lifecycle

Full new support/injection/child/output alternating sequence NOT RUN. Executed small direct/retry subsets do not replace this requirement.

## 29. Discard stress

Fresh I1 1000 actual invalid births PASS,12083 checks/0failures,1009ctor=1009dtor/live0. New grouped existing-movement/invalid-child/mixed-support1000-discard matrix NOT RUN.

## 30. Registry

Fresh I1 stress restores registry baseline every cycle. New R1 full lifecycle registry matrix NOT RUN. RSS is only supplemental; exact parcel counts are retained as primary evidence.

## 31. RNG

Canonical existing-movement and I1 retry equality includes complete native RNG state/cached normal. New full branch matrix OPEN. Probe adds no physical-model random call.

## 32. Allocator

Canonical allocator restored and direct/retry equal in executed subsets. Failed existing parcel is discarded with the trial, not renumbered. New full graph allocator matrix OPEN.

## 33. Carrier generation

Canonical generation and carrier snapshot equal in executed paths. New long mixed lifecycle publication tests remain OPEN.

## 34. Lazy cache lifecycle

Support rejection is preserved as an exception; the frozen lazy support-first architecture is unchanged. Rebound/child-specific full R1 cache/token matrix NOT RUN. Runtime error categories are not merged; observed exception remains GAS_SUPPORT_INVALID:EXACT_GAS_ABSENT. No new exhaustive error-classification proof.

## 35. Eight-model capability matrix

| Model | Current closure |
| --- | --- |
| coneInjection | I1 ownership COMPLETE/FROZEN; R2C full graph OPEN |
| sphereDrag | selected native movement/source subset PASS; full mixed graph OPEN |
| stochasticDispersionRAS | selected native movement invokes enabled model; full matrix OPEN |
| blobsSheetAtomization | existing frozen core evidence; full R1 OPEN |
| ReitzKHRT | invalid-child/full R1 OPEN |
| ORourke | required full R1 branches/lifetime OPEN; NATIVE-PHYSICS-LIMITATION retained |
| rebound | mixed/invalid full R1 OPEN |
| voidFraction | selected native movement function path; full R1 lifecycle OPEN |

No model is newly labeled FULL-SERIAL-TRANSACTION-SAFE. ORourke is never labeled FULL-CONSERVATION-SAFE.

## 36. Source/energy regression

9288/0 and8goldens remain FROZEN from I1, not freshly replayed after mandatory STOP. Source/energy adapter unchanged.

## 37. M8A.3A regression

6375/0 remains FROZEN, not freshly replayed this round.

## 38. T2 regression

1725880/0 and all-gas21000/21000 remain FROZEN. No new full T2 replay after STOP.

## 39. T3A regression

64395/0 remains FROZEN, not freshly replayed this round.

## 40. P2/R1 regression

105775/0 remains FROZEN; recovery/P2/R1 unchanged.

## 41. Temporal/restart regression

9663/0 remains FROZEN, not newly replayed; binary evolved-population certification remains blocked.

## 42. R2B regression

252194/0 remains FROZEN. R2B 30-file source/executable manifest freshly verified unchanged, no new numerical replay after STOP.

## 43. I1 stress regression

FRESH:12083/0,1000 real invalid-birth cycles,1009ctor=1009dtor/live0. FRESH injection support retry61/0,243ctor=243dtor/live0. No change to I1 ownership implementation or its original scope/verdict.

## 44. Foundation hashes

FRESH:6717 installed source/Make entries and19 native parcel sources verified unchanged; ORourke unchanged through baseline verification. Original Foundation IO/string-stream source copies and paths/hashes recorded in codec_provenance.sha256. The defect is the local diagnostic-member interaction with an inherited native size assumption, not an installed-source modification or claim of an unmodified native parcel bug.

## 45. Active solver impact

NONE. 145 protected files freshly verified unchanged;240 frozen I1/R2B files unchanged. Only two standalone passive test targets and new evidence/report/scripts. Both new OF7 wmake targets PASS. No pressure/KT/thermo/EOS/species/source/production cloud integration.

## 46. Production mesh/BC impact

NONE. Existing eight-cell passive fixture read as-is; no mesh generator/checkMesh/CFD solver run. Production300_2D files protected; no production nozzle patch created or activated.

## 47. Whether R2C COMPLETE

NO. R2C-R1 and R2C remain PARTIAL / PARCEL_CODEC_BLOCKER. The stream probe proves non-authoritative trailing data enters the binary format and readback crosses the object boundary; this prevents safe full read/write capability closure, despite intact physical fields in the fenced roundtrip.

## 48. Whether R2-FINAL may start NEXT ROUND ONLY

NO, prerequisite R2C COMPLETE is unmet. Proposed next bounded scope: project-local explicit physical-field binary IO/codec gate, preserving frozen I1 ownership and native physical formulas. Options are a local field-wise serializer/read wrapper with symmetric explicit payload extent, or a separately authorized instrumentation-layout correction; do not edit Foundation or silently restrict the requested IO certification. No repair is attempted in this STOP round.

## 49. T3B/T3/T4 permissions

T3B/T3 remain PARTIAL. T4 NO;M6B.0/1 NO;R2-FINAL NOT AUTHORIZED;CFD NO. Stop applies to further gate development/testing, while evidence/hash/document/checkpoint closure is completed.

## 50. Updated milestone matrix

| Milestone | Status |
| --- | --- |
| R2B | COMPLETE / FROZEN |
| R2C-I1 | COMPLETE / FROZEN / passive transient ownership scope |
| R2C-R1 | PARTIAL / PARCEL_CODEC_BLOCKER / STOP |
| R2C | PARTIAL |
| R2-FINAL | NOT AUTHORIZED |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NO |
| CFD | NO |

Operational note: first crossing runner was invoked before the initial build finished (exit127, no test executed); its logs are retained in crossing_v1. Build completed PASS; crossing_v2 is the actual successful tested result. This scheduling error is not counted as a physical-model failure or a passing test.
