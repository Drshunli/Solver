# M6B.1-EOS3-LR1-LOWER-RANGE-CLOSURE REPORT v1

2026-10-05。本轮只处理求解器内部、数值 EOS、恢复与保护核验。所有回归为本轮 fresh 执行；物理相界认证仍按 PHASE-DEFER 冻结。

## 1. LR1 status

**PARTIAL / EOS_RANGE_CHASING_DETECTED / STOP**。原 anchor174 下界族已关闭，但最终有界重放触发新的 265 K 下界。active v3 保留 265–400 K 数值资格；整体 EOS3 不 COMPLETE，数值域未冻结。

## 2. Exact anchor174 state

anchor174 / cell49 / attempt0，time=0.00020968603136877972 s（bits 3f2b7be54b582781），dt=1.2050921343033288e-06 s（bits 3eb437d4d06feded）。全部 Q/P2/time/dt 位一致。单状态 CSV 的 cell=0 是该状态在文件中的局部编号，实际网格 cell49 来自 event 与原 candidate 文件。

|字段|原始值|binary64 bits|
|---|---|---|
|P2hi|3.4655813536316512e-09|3e2dc4e4dc922040|
|P2lo|0|0000000000000000|
|Q0|3.4655813536316512e-09|3e2dc4e4dc922040|
|Q1|13.902703647386053|402bce2f2c27018b|
|Q2|2.588104550168383e-06|3ec5b5e985fddfac|
|Q3|522.60863525030516|408054de7c287a07|
|Q4|0|0000000000000000|
|Q5|0|0000000000000000|
|Q6|4353586.8273242293|41509b8cb4f2e153|
|Q7|0|0000000000000000|
|Q8|3.1698164316040187|40095bc8b7a0805f|
|Q9|10.732887215782032|4025773cfe3ee172|

证据：`exact_anchor174_gate.json`、`frozen_capture/`。

## 3. Energy ledger

域修改前独立 PASS。Et=4353586.8273242293，kinetic=9822.5403389798576，Eint=4343764.2869852493 J/m³；原通量更新独立重算 Q1/Q2/Q3/Q6 全部位一致。气相独立组分能量求和与原混合求值差仅 9.3132e−10 / −1.1176e−8 J/m³，species 质量差 −1.77636e−15；未归一化或修补能量。液相 C_L 贡献 0.95560572329006566 J/m³。原合法下端 p=3352159.0373128895 Pa、TL=275 K、F=+195059.59186974261 J/m³；上端 p=12 MPa、F=+28771554.884417579。非零 F 为原域无根，独立 ledger 无不一致。证据：`energy_ledger_gate.json`、`species_ledger.json`。

## 4. Shadow root result

仅建立 270 K 与 265 K shadow；均使用同一 Gibbs v3、气相、R1、P2。每阶段 4036/4036 PASS。exact anchor174 根：p=3283933.4470740478 Pa，TL=274.93878612905684 K，TG=819.10108146161588 K，cL=1347.6096603904261 m/s，cA=564.84264951732962 m/s；F=2.7939677238464355e-09 J/m³，归一化残差 6.4321347551424434e-16，5 iterations。260/255/250 未继续探测。

## 5. Required p / TL

冻结族合法共同压力根所需 p=[2999326.505841318, 3299975.634522133] Pa，TL=[274.93878612905684, 334.5641320960562] K；采用实际混合根，不采用气相单独恢复值。

## 6. Probe-family accounting

4036 events / 3660 unique payloads，missing=0、duplicate event IDs=0、bit mismatches=0。同一 payload 在不同事件中保留。原 275 K 域 valid controls 4004、lower rejected events 32。从冻结 anchor174 的 100 个 cell，以原重构/KT 通量与 connectedDt 求值路径生成实际候选；3336 为原算法实际 probe，另包含请求、既有 retry、connected 与四个邻域步长的全网格候选。connectedDt=existingRetryDt=7.3978782992392903e−7 s，位一致。邻域为 ±1 ULP 与 ±1e−6 relative。anchor/P2 未改变；未调用 TemporalDriver.advance，未推进 PDE/time authority。观测只插入隔离副本捕获实际 trial，不修改判定。

|candidate kind|事件数|
|---|---:|
|first_rejected_dt|100|
|frozen_connectedDt_probe|3336|
|existing_retry_dt|100|
|connected_admissible_dt|100|
|connected_minus_ulp|100|
|connected_plus_ulp|100|
|connected_minus_relative|100|
|connected_plus_relative|100|

证据：`LOWER_FAMILY_INDEX.csv`、`family_states_exact.csv`、`family_capture_gate.json`、`offline_family/`。

## 7. TL envelope

[274.93878612905684, 334.5641320960562] K。全网格含温暖控制，不将它们误标为 lower blocker。

## 8. p envelope

[2999326.5058413181, 3299975.634522133] Pa，全部在原 HARD pressure [50000,12000000] 内。

## 9. Classification A–D

原 anchor174 与族内 32 个原 lower rejection：**CLASS A / artificial 275 K numerical limit**；4004 个 valid controls 保留。该分类只涵盖冻结族。历史固液相证据 CLASS D 不变。新 anchor234 仅证明当前 HARD 内无根；按 STOP 规则未求域外混合根、未补做 A–D 分类，须模型适用性审查。

## 10. Selected final Tmin

265 K。270 K 虽有根，但最低 required TL−270=4.938786129056837 K，不满足 5 K 设计裕量；265 是允许 5 K 序列中的最高合格点，且 >=250 K。选择在 fresh lower property qualification PASS 后才安装。

## 11. Numerical margin

9.9387861290568367 K（min required TL−265）。这是冻结族的数值设计裕量；不代表 melting margin，不能保证后续 PDE 状态均在域内。

## 12. Active-v3 source delta

同一 `ndecane_gibbs_v3`，仅三文件：`liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H`、`fiveEqThermo/fiveEqLiquidThermoEvaluator.C` 将合法下端/反演区间 275→265 K；`metadata.json` 更新范围、资格与 STOP 状态。NORMAL 与 p HARD 不变；未新建 v4，未改变 Tmax400。旧源码/metadata、可执行程序与双库保存在 `source_before/`、`runtime_before/`。准确补丁 `active_lower_extension.patch`。

## 13. Coefficient / C_L identity

v1/v2/v3 coefficients.json SHA256 全部 `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`。81 coefficients 未变；C_L=369229.9537234281 J/kg 未变；energy_reference SHA256 `ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`。源码 audit 证明两个数值实现文件只有 275→265，Gibbs 导数公式没有变化。

## 14. Lower property regression

Fresh native shadow + active 265–275 K，各 9801 grid points，原 BUFFER 预算全部 PASS；CoolProp HEOS 8.0.0 单液体 continuation reference。预算 rho0.5%、c1%、Cp/Cv/beta/dpDe/dpDrho2%、e/h200 J/kg，未松动。

|property|最大误差|单位|
|---|---:|---|
|rho|2.0341139503465996e-09|relative|
|e|0.003180024097673595|J/kg absolute|
|h|0.0031812316155992448|J/kg absolute|
|Cp|3.7556950990328238e-07|relative|
|Cv|1.3678183551567187e-06|relative|
|beta|4.6642991919176599e-06|relative|
|c|2.0543724832981251e-06|relative|
|dpDe|4.6643209476904583e-06|relative|
|dpDrho|4.1133593187753709e-06|relative|

证据：`lower_shadow_qualification_gate.json`、`active_lower_extension_grid.csv`、`active_property_gate.json`。

## 15. Full EOS regression

Fresh final active 61045 points：275–285:9801，285–320:3721，320–330:3721，330–400:34001，265–275:9801。九项物性与原预算全部 PASS；保留 330–400 fresh 回归，未重新开展上界研究。native PT old-math identity mismatch0，反演 failure0，max ΔT=1.8189894035458565e−12 K / Δp=5.2358955144882202e−6 Pa；域外264.999/400.001严格拒绝。直接合法端点6 PASS、one-ULP域外8 expected reject、unexpected0（`strict_boundaries_gate.json`）；没有 clamp/tolerance 放宽。

## 16. Upper133 regression

原 upper133 fresh active 133/133 PASS，stillNoRoot0 / otherFailure0，max normalized residual8.674266973488897e−16，5 iterations。`active_upper133_gate.json`。

## 17. Lower130

130/130 PASS，p/TG/TL/cL/cA 与冻结基准最大差均0；max residual8.570596875729471e−16。另 700 neighbors PASS，max residual2.0258035338020126e−13。

## 18. Old184

184/184 PASS，五项恢复输出最大差0；max residual8.611343140285418e−16。

## 19. Accepted6200

700 neighbors + 5500 prior=6200 fresh PASS；prior5500 五项最大差0，max residual9.824406182180786e−13。`historical_regression_gate.json`。

## 20. Anchor174-family active result

4036/4036 PASS，stillNoRoot0 / otherFailure0，max normalized residual 6.7583179540461597e-13，iterations4–5；shadow/active 全字段一致。exact anchor174 混合根与第4项一致。`LOWER_FAMILY_INDEX.csv`逐事件 active 结果已填齐。

## 21. M6B.0

十个原算例 gas/liquid/mixed01/mixed05/mixed09/traceLiquid/traceGas/contact/speciesContact/smooth fresh 正常退出；314 项原 physical/authority checks 全 PASS。无 clipping、species normalization 或 trace deletion；P2 uniform exact。fresh wclean/wmake 编译/链接 PASS、错误0、unexpected warning0；只保留原三处 diagnostic misleading-indentation warnings。

## 22. Shock replay

原 shock 输入17文件 SHA identity PASS。active 与隔离 read-only diagnostic 在0–234共235完整 history rows全部字段逐文本一致。diagnostic 在第一个显式新 EOS blocker 外部 SIGTERM停止；active 在该 blocker 的第一次原 retry 接受后外部 SIGTERM停止（step235 / t=.00028286341377157468 / dt=8.7185434459499146e−7）。两个 exitCode−15 均是有界观测停止，不是正常 endTime 完成。不改变 solver 时间控制；不声明运行到了 endTime。`shock_analysis.json`。

## 23. First new blocker

anchor234 / cell53 / attempt0，t=.00028199155942697967 s，request dt=1.2050921343033288e−6 s。`NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN`，R1entered1，iterations0。exact Q/P2 bits及Q1/Q2/Q3/Q6原通量构造复核 PASS。active native query：rhoL754.48747382386659 kg/m³、alphaL2.0280533455853129e−5、mL.015301408454907038 kg/m³；Eint4346669.334479114 J/m³。共同区间 lo3347338.6153031113 Pa（TL265 K，F+174887.45675415266，dF2.8652070338479274）至hi12MPa（TL272.3437601697683 K，F+28763019.002321549，dF3.522212641545527）。当前单调 R1合法域无根。气相单独 p3285753.0765799726 Pa仅诊断，不是混合恢复；没有求新域外根。`first_replay_blocker.query.json`。

## 24. EOS range-chasing verdict

**EOS_RANGE_CHASING_DETECTED / STOP**。本轮最后一次数值域修订后仍出现新的下界，用户指定停止规则已触发；不论更低温度是否可求根，都不再扩 Tmin/Tmax、不启动 v4。下一步应审查 common-pressure closure 与模型适用性。

## 25. Timestep behavior

原 joint bound/connectedDt/retry/Time policy unchanged。到有界停止未观察到 time nonprogress，minimum accepted dt=8.7185434459499146e-07 s；原 anchor174 请求现可恢复，新 anchor234 原 retry 接受。新 EOS blocker 是独立存在的，不能将本次结果标为“纯 temporal collapse”。没有执行 TD1。

## 26. Conservation

accepted 原检查全部 PASS；有界重放 max scaled conservation=1.098754595397559e-15，max species closure=1.7101421570792262e-16。未修改残差/守恒容差，未对状态进行能量修补或组分归一化。

## 27. Low/high-T diagnostics

原只读低温TL<285 K、高温TL>330 K监测保留；阈值只用于记录，不用于相删除或EOS接受。integrated mL=sum(volume*mL)，完整 alphaL/mL ranges 见 `shock_analysis.json`。accepted TL范围 [265.0, 342.09115825275677] K。

|diagnostic|summary rows|cell rows|max cells|max integrated mL|TL range K|
|---|---:|---:|---:|---:|---|
|low|236|1921|23|0.010276857388259565|[265.0, 284.99649938488824]|
|high|236|301|5|3.0409972992836214e-19|[330.0059672727802, 342.09115825275677]|


## 28. Executable/library hashes

fresh active build，安装后/测试后 hashes完全一致。115库中仅授权两个库变化，其余113不变；before/after列表与旧运行副本保留。diagnostic、offline family、shadow270/265、回归/query各执行文件另有 SHA256 列表。

|installed artifact|SHA256|
|---|---|
|rhosprayVoFDPMFoam|`049e21b7c0533b5bb2566dcfce74b68530510a02a3a91bb95958639987b1481c`|
|libRhosprayLiquidEOS.so|`1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888`|
|libRhosprayFiveEqThermo.so|`f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896`|


## 29. Foundation/project hashes

109项目源文件：仅3处授权变化；P2/R1/KT/species/temporal/dynamicObservation/DPM 源保持 SHA一致。Foundation6717与native parcel19 before/after全PASS。上一轮UB1证据1180全部不变；UB1 checkpoint SHA256 `eaa617c3306be4a5efb80934643f51bf490b3c313c9bd88d586ded2d2b4614cc`。历史日志/报告hash保留；里程碑只追加本轮记录。`project_protection.json`列完整hash。

|authorized source|before SHA256|after SHA256|
|---|---|---|
|liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H|`686df0e43b92ce2404b72885b40ae47766ec67b132d50ad4cb51371957c74ce1`|`421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d`|
|liquidEOS/ndecane_gibbs_v3/metadata.json|`3902927fcd0919c9146d5344e8fa5add02703e2693ac793788db572a95a49576`|`9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`|
|fiveEqThermo/fiveEqLiquidThermoEvaluator.C|`2fb42991e66a2c95c7e21152ac47042f2c4c13de01e3fe1d743e234b6dae42b4`|`570297b2919a4d161fcc00d8d10360b9c4f9be8fcca24a183ddf04ebc900538f`|


## 30. EOS3 COMPLETE?

**FALSE**。26项 gate中25项通过，`noFurtherEOSRangeBlocker=false`；EOS3-NUMERICAL未获得 COMPLETE / NUMERICAL DOMAIN FROZEN。安装域物性资格与冻结候选族闭合不能替代后续整条 PDE 轨迹适用性。PHASE-DEFER / single-liquid continuation / NOT PHASE CERTIFIED继续成立，历史CLASS D保持。

## 31. TD1 status

REQUIRED / NOT EXECUTED。本轮没有触碰 temporal driver，没有自动打开TD1。EOS新边界存在，不能将任务直接移交为纯时间推进修复。

## 32. Next permitted milestone

下一轮需独立授权的 MODEL APPLICABILITY / COMMON-PRESSURE CLOSURE REVIEW。保留新事件全精度状态、ledger与观测材料，先审查模型适用性与边界反复触达的原因；本轮不继续温区扩展、remaining wave ladder 或 phase research。

## 33. M6B.1 / M6B status

M6B.1 PARTIAL / M6B PARTIAL / STOP。M6B.2、high-Mach、active DPM/MPI、T4-S3、production CFD未执行；production restart NOT CERTIFIED。

## 34. Milestone matrix

|milestone|status|
|---|---|
|原UB1 upper133闭合|CLASS A / CLOSED，fresh retained PASS|
|LR1 anchor174 lower族|CLASS A / CLOSED，4036 PASS|
|LR1最终重放|PARTIAL / EOS_RANGE_CHASING_DETECTED / STOP|
|active v3 265–400 K|PROPERTY QUALIFIED / NUMERICAL DOMAIN NOT FROZEN|
|EOS3-NUMERICAL|PARTIAL / COMPLETE FALSE|
|PHASE-DEFER|FROZEN，历史CLASS D，NOT PHASE CERTIFIED|
|TD1|REQUIRED / NOT EXECUTED|
|下一轮模型适用性审查|需要独立授权，本轮未启动|
|M6B.0|fresh十例 / 314 checks PASS|
|M6B.1 / M6B|PARTIAL / STOP|
|M6B.2 / high-Mach / production CFD|NOT OPENED|
|active DPM/MPI / T4-S3|NOT EXECUTED / DEFERRED|
|production restart|NOT CERTIFIED|

## STOP

本轮开发与核验停止。没有启动TD1/v4、Tmin<250 K、进一步Tmax扩展、remaining wave ladder、high-Mach、M6B.2、DPM、T4-S3或production CFD。封存内容与包SHA在本轮 evidence 目录 `checkpoint_contents.json` / `checkpoint_seal.json`；包内包含报告、开发日志、状态、最小源码补丁、旧/新runtime及全部本轮观测证据。
