# M6B.1-EOS2-LB2B-PHASEBOUNDARY

Date2026-10-05. Original supplementary source acquired, target pressure support insufficient.

## 1. LB2B status

**PARTIAL / STOP / CLASS D.** PHYSICAL_PHASE_BOUNDARY_UNRESOLVED; new source screening identifies PHASE_SOURCE_RANGE_BLOCKER. Search failure/insufficient supported data is an allowed outcome.

## 2. Evidence route

A original1975 publisher attempted; B published independent primary2025 experiment and its original supplement acquired; C EES/REFPROP documentation inspected, no numeric implementation output. None closes the target-MPa melting relation.

## 3. Primary/secondary source

Würflinger1975 DOI[10.1002/bbpc.19750791206](https://doi.org/10.1002/bbpc.19750791206), quantitative original unavailable. New independent primary: Gao et al., J.Chem.Phys.163,014505(2025), DOI[10.1063/5.0268190](https://doi.org/10.1063/5.0268190). Original supplementary material acquired from[public publisher figshare](https://aip.figshare.com/articles/figure/Supplementary_Material/29252828). Full citations/provenance in NDECANE_MELTING_SOURCE_v1.md.

## 4. Source locator

Gao2025 supplementary SectionIII/Fig.S8, explicitly n-decane; original DOCX word/media/image8.tiff. Blue heating melting, orange cooling freezing. RawDOCX SHA2560e5202b84e359bea80d5d691226d85a019dd607a106c2ae963beedfa6dedd3f3, publisher MD5verified. Image SHA/provenance saved. Würflinger exact data locator remains unknown.

## 5. Quantitative data acquired?

Original n-decane-specific high-pressure figure: YES. Usable quantitative relation/data at3.285–12MPa: NO. No accepted source providing requested values/uncertainty. Acquisition of a figure is distinct from acquisition of a target-range certificate.

## 6. Equation/table/digitization

No source coefficients or numerical table in acquired supplement. Figure inspected; no supported digitization at target pressures. Axis0–8GPa across about952pixels gives about8.40MPa/pixel; p1 occupies0.391pixel and12MPa1.428pixels near origin. Resolution screening only, not quantitative Tmelt extraction. No eyeball values, fabricated digitized CSV, guessed equation, smoothing or extrapolation.

## 7. Validity range

Acquired Fig.S8 axis0–8GPa, labeled temperature300–600K; experimental paths/markers at GPa pressures, no local target-MPa measured bracket. Axis limits and drawn fitted line are not experimental validity limits. Target-pressure validity not established. EES gives triple-point–293K context, no pressure range. No accepted target-range interpolation.

## 8. Uncertainty

Source experimental uncertainty for required pressure interval UNKNOWN. Interpolation uncertainty UNKNOWN. Digitization not performed; no finite melting-temperature error bound can be certified from the near-origin figure. Heating/cooling branch separated; low-pressure solid-solid transitions UNRESOLVED.

## 9. Tmelt(p1)

p1=3.285416855452983MPa: UNRESOLVED / null. Rounded requested3.285416855MPa has the same unresolved status.

## 10. Tmelt(p2)

p2=3.286242793380548MPa: UNRESOLVED / null. No temperature uncertainty band generated.

## 11. Min diagnosed margin

UNRESOLVED. All130 id/p*/TL* rows preserved from hash-verified independent reference; Tmelt, uncertainty and margin columns empty with explicit pending verdict. No min TL*−Tmelt or combined uncertainty can be evaluated.

## 12. Diagnosed130 verdict

NOT CERTIFIED / PHYSICAL_PHASE_BOUNDARY_UNRESOLVED. TL*=284.87337272298197–285.00000000011846K; p*=3.285416855452983–3.286242793380548MPa. Fluid-root evidence remains PASS; cannot infer solid/liquid stability. No CLASSB/C claim.

## 13. Tmelt(12MPa)

UNRESOLVED / null. New GPa figure cannot justify target-pressure interpolation or low-pressure extrapolation.

## 14. 12MPa margin

275K−Tmelt(12MPa)=UNRESOLVED. Cannot label this corner stable liquid from numerical EOS positivity or primitive admissibility.

## 15. Max melting T in box

UNRESOLVED over0.05–12MPa. No source-supported melting relation or monotonicity for required interval. No dense fake curve evaluation.

## 16. Full-box verdict

NOT CERTIFIED independently of diagnosed-envelope verdict. HARD275–330K/.05–12MPa remains a numerically qualified fluid-EOS candidate domain, not a certified stable-liquid rectangle. No redesign/higherTmin/nonrectangular-domain activation; such design would require new authorization/evidence.

## 17. Representation Part A status

COMPLETE / FROZEN / REPRESENTATION CONTRACT CLOSED. Fresh hash verification of contract, roundtrip, original280 and representation12 evidence; no new controls rerun. Runtime nextafter/clamps/tolerance changes remain absent.

## 18. Reused v3 numerical status

PASS / FRESH HASH-VERIFIED REUSE.23 LB1 numerical/candidate entries plus5 LB2-A entries checked against frozen checkpoint manifests.17243grid (9801lower+3721old+3721upper),130/130shadowR1 preserved. Same81coefficients/C_L369229.9537234281. No numerical grid/R1 rerun, refit or domain change.

## 19. old184 status

184/184PASS, hash-verified existing evidence only. No fresh recovery regression claim.

## 20. accepted6200 status

5500prior+700neighbors PASS, hash-verified reuse only. No fresh recovery regression claim.

## 21. Final A–D classification

**CLASS D / UNRESOLVED.** Insufficient quantitative evidence in supported target-pressure range. CLASSA not established; no evidence establishes diagnosed solid-side CLASSB or mixed CLASSC.

## 22. v3 DESIGN QUALIFIED?

NO. Remains SHADOW / NUMERICAL PASS / DESIGN PARTIAL. Positive fluid properties, vapor criteria and HEOSphase3 do not replace melting boundary.

## 23. EOS3 permitted?

NO / NOT AUTHORIZED. LB2B is not COMPLETE and CLASSA not established. EOS3 install/factory switch not performed.

## 24. Source changes

Only new isolated retrieval/provenance files, original2025supplement/media, read-only hash scripts/logs, phase-pending CSV/JSON, this29-section report and milestone append. NoEOS/R1/P2/temporal/source-equation change. Nofigure digitization/calibration tool installed. No solver compilation/run required; no CFD/shock/DPM execution.

## 25. Foundation/project hashes

Fresh Foundation6717/nativeparcel19 checksumPASS. Activev2 executable/twoEOSlibraries and all55loadedlibraries unchanged. Installed executable SHA99053c2f1837e3e524b2385a2004d8649d7fc0430a762dfd5cd5bddb01bf9a3d. Project pre-existing protected hashes checked by final seal; only milestone append allowed. Counts/deltas/parentCRC/per-fileSHA in project_protection.json. Fresh evidence reuse28 entriesPASS.

## 26. EOS2 status

M6B.1-EOS2 PARTIAL / STOP. LB2 overallPARTIAL; PartA frozenPASS, PartB unresolved. ndecane_gibbs_v2 ACTIVE / PRESERVED.

## 27. TD1 status

REQUIRED / NOT AUTHORIZED / NOT EXECUTED. No temporal-driver/dt/time-progress changes.

## 28. M6B.1 status

PARTIAL / STOP. No shock replay, remaining dynamics, high-Mach, M6B.2, activeDPM, productionCFD/restart orv3installation. Required next evidence: original1975quantitative data, or traceable low-pressure relation/package outputs with domain, branch and uncertainty; no next implementation authorized.

## 29. Milestone matrix

| Milestone | Status |
|---|---|
| M6B.0 | COMPLETE / FROZEN |
| SR1 | COMPLETE / DIAGNOSIS ONLY |
| EOS1 | COMPLETE / DESIGN QUALIFIED |
| active ndecane_gibbs_v2 | ACTIVE / PRESERVED |
| EOS2 / LB1 / LB2 | PARTIAL / STOP |
| LB2 PartA | COMPLETE / FROZEN |
| LB2B / PartB | PARTIAL / PHYSICAL_PHASE_BOUNDARY_UNRESOLVED |
| Final class | CLASS D |
| v3candidate | SHADOW / NUMERICAL PASS / DESIGN PARTIAL |
| EOS3 | NOT AUTHORIZED |
| TD1 | REQUIRED / NOT AUTHORIZED |
| M6B.1 / M6B | PARTIAL / STOP |
| T4 / M8A | PARTIAL; S1/S2FROZEN; S3DEFERRED |
| M6B.2 / production CFD | NOT AUTHORIZED |

**STOP.**
