# 1. M6A1b-2B.3A.1 status

COMPLETE. All mandatory semantics and own-model gates pass. User-authorized conditional continuation to 3B was executed and completed; M6A2 was not executed. Numerical budgets, coefficient files and PT rectangles are unchanged.

# 2. Why R_REF != R_MODEL

A shared PT rectangle does not imply identical constitutive images. Let F_i(p,T)=(rho_i(p,T),p) and G_i(p,T)=(rho_i(p,T),e_i(p,T)). Approximation errors can move a reference edge state outside the candidate image even when matched-PT errors are tiny. Own-model coverage is mandatory; exact reference-edge inclusion is diagnostic. Interior cross-inverse remains mandatory.

# 3. Formal reference HARD p-T domain

H_REF = [50000,12000000] Pa x [285,320] K, evaluated using CoolProp 8 HEOS n-Decane native DEF. NORMAL=[100000,8000000] Pa x [295,305] K. These are approved design rectangles, not CFD extrema or experimental measurements.

# 4. Formal candidate HARD p-T domain

H_MODEL has exactly the same coordinate rectangle as H_REF. The frozen global degree-8x8 Chebyshev Gibbs potential defines different constitutive values. No fitted coefficient, degree, anchor or physical domain was changed this turn.

# 5. Reference rho-p image

R_REF=F_REF(H_REF). For each p, rho_REF(p,320)<=rho<=rho_REF(p,285). Its caloric image is G_REF(H_REF); boundary caloric states must not be confused with candidate-generated conservative states.

# 6. Candidate rho-p image

R_MODEL=F_MODEL(H_MODEL). Runtime accepts only its own cold/hot density bounds and strict p bounds; temperature and energy inversions use safeguarded Newton/bracketing. There is no CoolProp runtime fallback, clipping or physical extrapolation. Future initialization must use model rho(p,T), model energy and the frozen energy offset; recovered mL/alphaL must be checked against R_MODEL.

# 7. Boundary density mismatch

All-edge matched-PT density mismatch and signed inverse shifts are retained in hard_edges_results.json. The C++ full suite maximum density relative error is 2.70739e-12. Tiny nonzero discrepancies can change strict inclusion at an exact edge. Four prior HARD-corner fitting constraints are disclosed and are not independent holdout validation.

# 8. Linearized DeltaT prediction

Define deltaRho=rho_REF-rho_MODEL and alpha_MODEL=(1/v)(dv/dT)|p. Then DeltaT=T_inverse-T_REF approximately -(deltaRho/rho_MODEL)/alpha_MODEL. The sign convention is explicit. Diagnostic residuals are about 3.2e-13 K or less. Local polynomial continuation is private offline diagnostic algebra only; it is not an accepted runtime state.

# 9. Original failure reclassification

Original frozen 2B model, 99 states: TYPE-1 thermodynamics=0; TYPE-2 self-invertibility=0; TYPE-3 numerical inversion=0; TYPE-4 constitutive-image mismatch=99; TYPE-5 frozen property threshold=0. Full coupled rho/e image, rather than only an old side tag, determines this classification. Historical files are preserved.

# 10. Failure versus boundary distance

Distance d=min(normalized distances to four HARD faces). Exact d=0; near-edge diagnostic 0<d<=1e-6; interior d>1e-6. The current BUFFER sample has no near-edge points; no conclusion of dense near-edge sampling is claimed.

| Bin | Tested | Strict cross failures |
|---|---:|---:|
| exact | 140 | 90 |
| (0,1e-9] | 0 | 0 |
| (1e-9,1e-6] | 0 | 0 |
| (1e-6,1e-3] | 2 | 0 |
| (1e-3,1e-2] | 9 | 0 |
| (1e-2,1] | 1094 | 0 |

CSV/JSON and failure_vs_boundary_distance.svg retain the complete distribution. Domain coordinates and runtime rejection rules are unaffected by these diagnostic bins.

# 11. Genuine thermodynamic failures

Selected Chebyshev: zero. Positivity, global monotonicity/stability certificate and thermodynamic identities pass. Existing coefficient-identical certificates from 3A are reused with hash verification; no new CFD or physical experiment is implied.

# 12. Model-self roundtrip failures

Selected candidate: zero throughout tested NORMAL, BUFFER, HARD edges/corners and paths. Native C++ 4369 golden queries give zero evaluation, temperature, pressure and energy-offset failures.

# 13. Numerical inversion failures

Selected Chebyshev: zero. C4 is not exempted: prior BUFFER mixed failures include 33 TYPE-3 numerical failures; HARD edges include 618 TYPE-3. Hence domain semantics do not automatically accept every candidate.

# 14. Domain-image mismatch count

Selected Chebyshev prior BUFFER90 and edges1239 are TYPE-4; current explicit corner set has 1 strict reference cross-image rejection. C4 BUFFER71 and edges814 are TYPE-4; its remaining failures are TYPE-3. Counts from separate suites overlap and must not be summed as unique physical states.

# 15. NORMAL direct accuracy

PASS: 924 independent matched-PT holdout points. Relative errors below are fractions, not percentages; all frozen per-property budgets pass. Reference-EOS agreement does not establish equal real-fluid experimental accuracy.

| Property | MARE | RMS | MAX |
|---|---:|---:|---:|
| rho | 3.17826e-13 | 3.90345e-13 | 1.26388e-12 |
| e | 1.31651e-12 | 1.54437e-12 | 2.78355e-12 |
| h | 2.68501e-12 | 3.16732e-12 | 5.02043e-12 |
| c | 1.84673e-10 | 2.12128e-10 | 5.25431e-10 |
| Cp | 2.31341e-11 | 2.69614e-11 | 4.40838e-11 |
| Cv | 7.27438e-11 | 8.82253e-11 | 2.07907e-10 |
| deDp_constRho | 3.69529e-10 | 4.27328e-10 | 1.04026e-09 |
| dpDrho_constE | 3.69329e-10 | 4.24227e-10 | 1.05087e-09 |
| dpDe_constRho | 3.69529e-10 | 4.27328e-10 | 1.04026e-09 |

# 16. NORMAL cross-EOS inverse

PASS, no strict inverse failures. DeltaT: signed mean -6.33508e-11 K, RMS3.78549e-10, maxabs1.23151e-9, P95abs7.96919e-10, P99abs1.02829e-9. DeltaP: signed mean0.000323132 Pa, RMS0.000644474, maxabs0.00148950, P95abs0.00102513, P99abs0.00128883. Full statistics in normal_results.json.

# 17. BUFFER interior results

PASS: 1105 strictly interior samples; direct accuracy, model-self inversion and strict reference cross-inverse all pass. DeltaT signed mean2.05700e-10 K, RMS6.68158e-10, maxabs2.68409e-9, P95abs1.54333e-9, P99abs2.35037e-9. DeltaP signed mean-0.000141368 Pa, RMS0.000846040, maxabs0.00319337, P95abs0.00177413, P99abs0.00278482.

| Property | MARE | RMS | MAX |
|---|---:|---:|---:|
| rho | 4.77642e-13 | 6.80993e-13 | 2.70672e-12 |
| e | 8.87582e-13 | 1.12054e-12 | 2.75624e-12 |
| h | 1.97973e-12 | 2.71539e-12 | 5.75806e-12 |
| c | 3.08489e-10 | 4.10616e-10 | 1.71096e-09 |
| Cp | 3.22533e-11 | 3.72082e-11 | 8.56573e-11 |
| Cv | 1.20994e-10 | 1.619e-10 | 7.03574e-10 |
| deDp_constRho | 6.19659e-10 | 8.27364e-10 | 3.51868e-09 |
| dpDrho_constE | 6.16973e-10 | 8.21238e-10 | 3.42159e-09 |
| dpDe_constRho | 6.19659e-10 | 8.27364e-10 | 3.51868e-09 |

# 18. HARD-edge direct p-T accuracy

PASS under unchanged BUFFER budgets. Diagnostic reference cross-inverse maxabs DeltaT2.24497e-9 K and DeltaP0.00221082 Pa. These are estimated inverse shifts, not CFD results.

| Property | MARE | RMS | MAX |
|---|---:|---:|---:|
| rho | 3.11292e-13 | 4.9409e-13 | 2.35523e-12 |
| e | 6.2457e-13 | 8.97503e-13 | 2.39253e-12 |
| h | 1.1606e-12 | 1.94667e-12 | 4.6807e-12 |
| c | 1.83012e-10 | 2.81634e-10 | 1.09753e-09 |
| Cp | 2.7503e-11 | 3.60074e-11 | 1.23105e-10 |
| Cv | 7.95762e-11 | 1.14875e-10 | 6.75636e-10 |
| deDp_constRho | 3.73014e-10 | 5.74027e-10 | 2.72849e-09 |
| dpDrho_constE | 3.65982e-10 | 5.63176e-10 | 2.19109e-09 |
| dpDe_constRho | 3.73014e-10 | 5.74027e-10 | 2.72849e-09 |

# 19. Candidate HARD rho-p self-roundtrip

PASS. Native maximum |T_recovered-T_generated|=1.64845915e-12 K. Tests use own-model density at each generated PT state; own cold/hot density curves define the legal inverse domain.

# 20. Candidate HARD rho-e self-roundtrip

PASS. Native maximum |p_recovered-p_generated|=2.28744466e-6 Pa. Energy convention tested both native and production shifted; maximum pressure difference under offset=3.89292836e-7 Pa. This is pure-liquid recovery, not M6A2 common-pressure recovery.

# 21. Candidate exact-edge tests

PASS for direct values and own rho-p/rho-e roundtrips at the four exact HARD faces. Reference-edge cross-image counters remain diagnostic and are not overwritten as zero. Full per-state evidence: hard_edges_results.json and standalone/golden_states.csv.

# 22. Candidate exact-corner tests

PASS at all four exact HARD corners, including own-model inversions. Reference-corner cross-inverse maxabs DeltaT1.70530e-13 K and DeltaP1.82539e-7 Pa. Corner fit constraints are not counted as independent experimental evidence.

# 23. Just-outside rejection

PASS: Python policy suite36/36 and native C++16/16 invalid queries rejected. Outside p/T/rho/e states produce structured errors; no runtime polynomial continuation, clamp, reference-backend rescue or fuzzy HARD enlargement.

# 24. Thermodynamic consistency

All properties derive from one potential g: v=g_p; rho=1/v; s=-g_T; h=g-Tg_T; e=h-pv; Cp=-Tg_TT; Cv=Cp+T*g_pT^2/g_pp; c^2=-v^2/(g_pp-g_pT^2/g_TT). beta=(de/dp)|rho=T*(g_TT*g_pp/g_pT-g_pT); dp/de|rho=1/beta; dp/drho|e=c^2-p/(rho^2*beta). Production e/h add one constant C_L; derivatives and sound speed are unchanged. Frozen identity budget1e-5 passes; matched-PT Allaire95436 queries maximum relative error1.71096e-9.

# 25. Derivative quality

PASS. Native beta finite-difference maximum relative error3.34399e-9; derivative accuracy and coefficient-bound positivity certificate pass unchanged budgets. Global smooth degree8x8 polynomial avoids patch seams. No cross-cell cache or derivative blending.

# 26. Revised acceptance matrix

This is the user-authorized acceptance semantics correction, not a numerical budget relaxation. acceptance_matrix.json records the 3A1 pre-3B decision; production_acceptance.json records the later completed promotion.

| Test | Role | Result |
|---|---|---|
| normal_direct | MANDATORY_PRODUCTION_GATE | PASS |
| normal_model_self | MANDATORY_PRODUCTION_GATE | PASS |
| normal_cross_inverse | MANDATORY_PRODUCTION_GATE | PASS |
| buffer_interior_direct | MANDATORY_PRODUCTION_GATE | PASS |
| buffer_interior_model_self | MANDATORY_PRODUCTION_GATE | PASS |
| buffer_interior_cross_inverse | MANDATORY_PRODUCTION_GATE | PASS |
| buffer_all_direct | MANDATORY_PRODUCTION_GATE | PASS |
| buffer_all_model_self | MANDATORY_PRODUCTION_GATE | PASS |
| buffer_all_cross_inverse | REFERENCE_DIAGNOSTIC | DIAGNOSTIC |
| hard_edges_direct | MANDATORY_PRODUCTION_GATE | PASS |
| hard_edges_model_self | MANDATORY_PRODUCTION_GATE | PASS |
| hard_edges_cross_inverse | REFERENCE_DIAGNOSTIC | DIAGNOSTIC |
| hard_corners_direct | MANDATORY_PRODUCTION_GATE | PASS |
| hard_corners_model_self | MANDATORY_PRODUCTION_GATE | PASS |
| hard_corners_cross_inverse | REFERENCE_DIAGNOSTIC | DIAGNOSTIC |
| physics_paths_direct | MANDATORY_PRODUCTION_GATE | PASS |
| physics_paths_model_self | MANDATORY_PRODUCTION_GATE | PASS |
| physics_paths_cross_inverse | MANDATORY_PRODUCTION_GATE | PASS |
| just_outside_rejection | MANDATORY_PRODUCTION_GATE | PASS |
| global_monotonicity_and_stability | MANDATORY_PRODUCTION_GATE | PASS |
| derivative_quality | MANDATORY_PRODUCTION_GATE | PASS |

# 27. TABLE-B acceptance status

ACCEPTED PRODUCTION EOS / STANDALONE / NOT ACTIVE: ndecane_gibbs_v1. Coefficients, model-specific energy reference, API contract and content hashes are frozen in liquidEOS/ndecane_gibbs_v1. Selection is based on full thermodynamic/derivative accuracy, smoothness and API/cost gates, not the old mixed counter alone.

# 28. Whether TABLE-A fallback is still needed

Not required for the approved domain under the completed mandatory gates. TABLE-A historical evidence is preserved; no repair or automatic runtime fallback was implemented.

# 29. Active solver impact

NONE. Ten protected active solver/Make/cloud files remain SHA-256 identical to the original audit baseline. No EOS instance, cL/cMix/mG/mL, common-pressure recovery, two-phase KT flux, capillary coupling or conversion was activated. No CFD ran.

# 30. M6A1b-2B.3A final status

COMPLETE / USER-AUTHORIZED ACCEPTANCE SEMANTICS CORRECTED. Prior PARTIAL reports remain historical evidence; current acceptance separates reference-image diagnostics from mandatory model accuracy and self-consistency.

# 31. Whether 3B may start

YES; user-authorized continuation was executed and is COMPLETE. Full standalone C++ API compiled clean with -O3 -std=c++11 -Wall -Wextra -Werror -pedantic;4369 golden queries passed. Public API supplies PT, rho-p, rho-e recovery, e,T,c,Cp,Cv and caloric pressure derivatives, structured rejection and query diagnostics. All runtime properties derive from the frozen potential; no external property library at runtime.

Production C_L=369229.9537234281 J/kg = -h_native_model(3MPa,298.15K). Gas JANAF Es unchanged, gas offset0; DPM OF7 Hs unchanged. Future transfer/heat/phase-change ledger must reconcile state-dependent caloric differences; it remains unimplemented. OpenFOAM runtime adapter and common-pressure solve also remain unimplemented.

| Query | Mean us | Median | P95 | P99 | Max |
|---|---:|---:|---:|---:|---:|
| evaluatePT | 0.113508 | 0.099 | 0.215 | 0.276 | 43.196 |
| evaluateRhoP | 0.467455 | 0.511 | 0.569 | 1.223 | 20.083 |
| pFromRhoE | 3.28863 | 3.199 | 5.877 | 8.867 | 103.823 |
| fullRecoverRhoE | 3.05366 | 2.912 | 5.614 | 8.257 | 91.343 |

13107 warm calls per method; scalar-loop rho-p batch mean0.408818 us/state. Frozen mean budgets50us warm and10us batch pass. Max outliers exceed50us and are retained: no real-time upper-bound guarantee is claimed. Full rho/e recovery pressure iterations mean2.00664/P954/P994/max5; rho-p temperature iterations mean3.04440/P955/P995/max6. Numeric coefficient storage3888B, EOS object16B, state160B; no heap or cross-cell cache. No cold-cache, MPI or CFD overhead measurement is claimed.

Frozen metadata SHA256 d76f2085d1d22b45f8ddfd9a44501bdb0a0b6fc9fbb475d6446420d02412fd7e.

# 32. Updated milestone matrix

| Milestone | Current status |
|---|---|
| M0-M4 | COMPLETE |
| M5A/M5B | COMPLETE / ACTIVE REFERENCE AND DESIGN |
| M6A1a | COMPLETE |
| M6A1b-2A.3 | COMPLETE / APPROVED DOMAIN |
| M6A1b-2B.1 | COMPLETE / FROZEN DATA |
| M6A1b-2B.3A / 3A.1 | COMPLETE |
| M6A1b-2B.3B / overall2B | COMPLETE / ACCEPTED STANDALONE |
| M6A2 | NEXT / NOT EXECUTED |
| M5C/M6B and M7 | NOT STARTED |
| M8 | PARTIAL / EXISTING DPM PRESERVED |
| M9-M15 | NOT STARTED |

STOP. No M6A2 work is authorized by this stage completion.
