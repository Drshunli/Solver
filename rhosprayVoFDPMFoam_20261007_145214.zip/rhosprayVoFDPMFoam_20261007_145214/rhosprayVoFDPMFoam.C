/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2015 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    rhoReactingCentralFoam

Description
    Density-based compressible flow solver based on central-upwind schemes of
    Kurganov and Tadmor with reactions

    Ported to OF7 by CL, based on original code from CFD Online thread :
    https://www.cfd-online.com/Forums/openfoam-community-contributions/82851-new-solver-supersonic-combustion.html#post286897

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "serialFiveEq/runSerialFiveEq.H"
#include "dynamicFvMesh.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "CombustionModel.H"
#include "multivariateScheme.H"
#include "fixedRhoFvPatchScalarField.H"
#include "coupledFvsPatchFields.H"
#include "directionInterpolate.H"
#include "localEulerDdtScheme.H"
#include "fvcSmooth.H"
#include "fvOptions.H"
#include "gaussConvectionScheme.H"
#include "CMULES.H"
#include "interfaceProperties.H"
#include "rhosprayVoFMixture.H"
#include "subCycle.H"
#include "slicedSurfaceFields.H"
#include "basicSprayCloud.H"//1
#include "radiationModel.H" //2
#include "SLGThermo.H" //3
#include "CorrectPhi.H"//
#include "fvOptions.H"//

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    argList::addBoolOption("serialFiveEq", "M6B.0 serial Eulerian verification bootstrap");
    #include "postProcess.H"

    #include "setRootCase.H"

    #include "createTime.H"
    #include "createDynamicFvMesh.H"
    if (args.optionFound("serialFiveEq"))
    {
        return runSerialFiveEq(runTime, mesh);
    }
    // Frozen legacy reference path; never entered by serialFiveEq. 
    #include "createControls.H"
    //#include "createClouds.H"
    #include "createFields.H"
    #include "createFieldRefs.H"
    #include "alphaControls.H"
    #include "createInterfaceProperties.H"
    rhosprayVoFMixture vofMixture
    (
        mesh, alphaL, alphaG, rhoG, thermo, slgThermo
    );
    #include "createFvOptions.H"

    //#include "compressibleCourantNo.H"//
    //#include "setInitialDeltaT.H"//
   // #include "initContinuityErrs.H"//
    //#include "createRhoUfIfPresent.H"//
    //#include "createDyMControls.H"//

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    #include "readFluxScheme.H"

    dimensionedScalar v_zero("v_zero", dimVolume/dimTime, 0.0);

    // Courant numbers used to adjust the time-step
    scalar CoNum = 0.0;
    scalar meanCoNum = 0.0;
    scalar acousticCoNum = 0.0;
    scalar startTimeIndex = runTime.timeIndex();

    Info<< "\nStarting time loop\n" << endl;

    while (runTime.run())
    {
        #include "readControls.H"


		// Indicators for refinement. Note: before runTime++
        // only for postprocessing reasons. Grabbed from 
        // PDRFoamAutoRefine.C.
        tmp<volScalarField> tmagGradP = mag(fvc::grad(p));
        volScalarField normalisedGradP
        (
            "normalisedGradP",
            tmagGradP()/max(tmagGradP())
        );
        normalisedGradP.writeOpt() = IOobject::AUTO_WRITE;
        tmagGradP.clear();

	volScalarField cc
        (
            "cc",
            sqrt((thermo.Cp()/thermo.Cv())/thermo.psi())
        );
        cc.writeOpt() = IOobject::AUTO_WRITE;

        // Store the particle positions
        parcels.storeGlobalPositions();

        // Do any mesh changes
        if (runTime.timeIndex() - startTimeIndex > 0)
	{
            mesh.update();
        }

        if (!LTS)
        {
            #include "setDeltaT.H"
            runTime++;
        }

        // --- Directed interpolation of primitive fields onto faces

        surfaceScalarField rho_pos(interpolate(rho, pos));
        surfaceScalarField rho_neg(interpolate(rho, neg));

        surfaceVectorField rhoU_pos(interpolate(rhoU, pos, U.name()));
        surfaceVectorField rhoU_neg(interpolate(rhoU, neg, U.name()));

        volScalarField rPsi("rPsi", 1.0/psi);
        surfaceScalarField rPsi_pos(interpolate(rPsi, pos, T.name()));
        surfaceScalarField rPsi_neg(interpolate(rPsi, neg, T.name()));

        surfaceScalarField e_pos(interpolate(e, pos, T.name()));
        surfaceScalarField e_neg(interpolate(e, neg, T.name()));

        surfaceVectorField U_pos("U_pos", rhoU_pos/rho_pos);
        surfaceVectorField U_neg("U_neg", rhoU_neg/rho_neg);

        surfaceScalarField p_pos("p_pos", rho_pos*rPsi_pos);
        surfaceScalarField p_neg("p_neg", rho_neg*rPsi_neg);

        surfaceScalarField phiv_pos("phiv_pos", U_pos & mesh.Sf());
        surfaceScalarField phiv_neg("phiv_neg", U_neg & mesh.Sf());

        // Make fluxes relative to mesh-motion
        if (mesh.moving())
        {
            phiv_pos -= mesh.phi();
            phiv_neg -= mesh.phi();
        }

        volScalarField c("c", sqrt(thermo.Cp()/thermo.Cv()*rPsi));
        
        surfaceScalarField cSf_pos("cSf_pos",interpolate(c, pos, T.name())*mesh.magSf());
        surfaceScalarField cSf_neg("cSf_neg",interpolate(c, neg, T.name())*mesh.magSf());

        surfaceScalarField ap("ap",max(max(phiv_pos + cSf_pos, phiv_neg + cSf_neg), v_zero));
        surfaceScalarField am("am",min(min(phiv_pos - cSf_pos, phiv_neg - cSf_neg), v_zero));

        surfaceScalarField a_pos("a_pos", ap/(ap - am));

        surfaceScalarField amaxSf("amaxSf", max(mag(am), mag(ap)));

        surfaceScalarField aSf("aSf", am*a_pos);

        if (fluxScheme == "Tadmor")
        {
            aSf = -0.5*amaxSf;
            a_pos = 0.5;
        }

        surfaceScalarField a_neg("a_neg", 1.0 - a_pos);

        phiv_pos *= a_pos;
        phiv_neg *= a_neg;

        surfaceScalarField aphiv_pos("aphiv_pos", phiv_pos - aSf);
        surfaceScalarField aphiv_neg("aphiv_neg", phiv_neg + aSf);

        // Reuse amaxSf for the maximum positive and negative fluxes
        // estimated by the central scheme
        amaxSf = max(mag(aphiv_pos), mag(aphiv_neg));

        #include "CourantNo.H"

        if (LTS)
        {
            #include "setRDeltaT.H"
            runTime++;
        }

        Info<< "Time = " << runTime.timeName() << nl << endl;

        phi = aphiv_pos*rho_pos + aphiv_neg*rho_neg;

        // M2 one-way VOF: KT gas mass flux remains owned by phi.
        phiV = aphiv_pos + aphiv_neg;
        #include "alphaCourantNo.H"
        #include "alphaSubCycle.H"
        #include "interfaceGeometry.H"
        vofMixture.correct();
        // M5A flux diagnostics remain an active design reference, not part
        // of the current legacy gas-KT run path.

        surfaceVectorField phiUp
        (
            (aphiv_pos*rhoU_pos + aphiv_neg*rhoU_neg)
          + (a_pos*p_pos + a_neg*p_neg)*mesh.Sf()
        );

        surfaceScalarField phiEp
        (
            "phiEp",
            aphiv_pos*(rho_pos*(e_pos + 0.5*magSqr(U_pos)) + p_pos)
          + aphiv_neg*(rho_neg*(e_neg + 0.5*magSqr(U_neg)) + p_neg)
          + aSf*p_pos - aSf*p_neg
        );

        /*surfaceScalarField phiEp
        (
            "phiEp",
            aphiv_pos*(rho_pos*(e_pos) + p_pos)
          + aphiv_neg*(rho_neg*(e_neg) + p_neg)
          + aSf*p_pos - aSf*p_neg
        );*/

        // Make flux for pressure-work absolute
        if (mesh.moving())
        {
            phiEp += mesh.phi()*(a_pos*p_pos + a_neg*p_neg);
        }

        volScalarField muEff("muEff", turbulence->muEff());
        volTensorField tauMC("tauMC", muEff*dev2(Foam::T(fvc::grad(U))));
	parcels.evolve();
        // --- Solve density
        #include "rhoEqn.H"

        // --- Solve momentum
        #include "rhoUEqn.H"
        
        //CL --- Solve species
        #include "rhoYEqn.H"

        // --- Solve energy
        #include "rhoEEqn.H"
        // Refresh diagnostic properties after the legacy gas rho/T update.
        vofMixture.correct();

       /* forAll(maxp, celli)    
          {
	    if(maxp[celli] < p[celli])
               maxp[celli] = p[celli];
           }*/
        turbulence->correct();

        runTime.write();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
    }

    Info<< "End\n" << endl;

    return 0;
}

// ************************************************************************* //
