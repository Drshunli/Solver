# M5B two-phase state and ownership contract

This table is a **future mathematical state**, not a claim that the active
`rhosprayVoFDPMFoam` solves it. Current solver ownership is listed in
`FIELD_OWNERSHIP.md`. The chosen first implementation target is an isobaric,
common-velocity, two-material five-equation model (five scalar equations in
1-D, seven in 3-D); alpha is a non-conservative state variable.

| Quantity | Option A: homogeneous single-fluid VOF | Selected Option B: isobaric five-equation | Current target at M5B |
|---|---|---|---|
| `alphaL` | Advected marker/volume fraction | Non-conservative material volume fraction, `D_t alphaL=0` without phase change; numerical sharpening requires compatibility treatment | MULES-solved, but not yet coupled to phase masses |
| `mL=alphaL*rhoL` | Derived from alpha and EOS | Conserved liquid mass | Absent |
| `mG=alphaG*rhoG` | Derived from alpha and EOS | Conserved gas mass, with future DPM/reaction species sources | Absent; legacy `rho` remains gas mass-like state |
| `rhoL` | Phase EOS result at common `p,T` | Derived `mL/alphaL` where present; liquid EOS defines energy and sound speed | M4 diagnostic liquid-property field |
| `rhoG` | Phase EOS result at common `p,T` | Derived `mG/alphaG` where present; gas composition is additional state | Read-only alias of legacy `rho` in M4 |
| `rho` | Solved total mass | Derived `mL+mG`; no separate total-mass equation needed | Legacy gas `rhoEqn.H` owner |
| `rhoU` / `M` | Solved mixture momentum | Conserved mixture momentum `rho*U` | Legacy gas `rhoUEqn.H` owner |
| `rhoE` / `Et` | Solved mixture total energy | Conserved mixture total energy | Legacy gas `rhoEEqn.H` owner |
| `U` | Common primitive velocity | Derived `M/(mL+mG)` | Legacy `U` from `rhoU/rho` |
| `p` | Common thermo primitive | Isobaric closure: derive from total internal energy and both phase EOSs | Legacy gas thermo pressure |
| `T` | Assumed common in Option A | No mandatory common temperature; `TG,TL` derive separately from phase EOS at common `p` and phase densities | Legacy gas `T`; M4 uses it for liquid diagnostics only |
| `eG` | Gas energy at common `p,T` | Derived `eG(rhoG,p,Y)` from gas EOS | Legacy gas sensible internal energy |
| `eL` | Liquid energy at common `p,T` | Derived `eL(rhoL,p)` from a consistent liquid caloric EOS | Absent |
| `cG` | Gas acoustic property | Gas EOS characteristic speed | Existing gas `c` reconstruction and `cc` output |
| `cL` | Liquid acoustic property | Liquid EOS characteristic speed; mandatory pure-liquid limit | **Missing** from M4 liquid database |
| `cMix` | Must derive from homogeneous equilibrium EOS | Isobaric five-equation acoustic speed from phase EOS derivatives | **Missing**; no candidate is activated |
| Gas species `Y_i` | Gas composition if reacting | Additional gas-component states/transport coupled to `mG`; DPM species exchange remains gas-only | Existing `rhoYEqn.H` gas composition |

Future conservative vector in 3-D:
`Qc=(mG,mL,Mx,My,Mz,Et)`. The full state is `(Qc,alphaL)`.
`rho=mG+mL`, `U=M/rho`, `rho*eMix=Et-|M|^2/(2*rho)`,
`rhoG=mG/(1-alphaL)`, `rhoL=mL/alphaL` in present phases. Pure-phase
limits avoid division by zero by omitting absent-phase state recovery.
The pressure solves
`rho*eMix=mG*eG(rhoG,p,Y)+mL*eL(rhoL,p)`.

At M5B `twoPhaseKTState.H` merely records these conceptual state members.
It does not create fields, evaluate an EOS or calculate a flux.
