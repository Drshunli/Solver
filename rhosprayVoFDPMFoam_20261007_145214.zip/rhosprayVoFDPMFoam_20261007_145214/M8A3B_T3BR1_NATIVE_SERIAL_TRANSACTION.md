# M8A.3B-T3B-R1：原生 OF7 串行事务报告

日期：2026-10-02。工作范围：离线独立测试与文档；没有运行 CFD。
证据目录：`fitting/dpm/m8a3b_t3br1_v1/`。

## 1. T3B-R1 status

**PARTIAL / SERIAL_TRANSACTION_CLOSURE_INCOMPLETE**。
新增独立测试共 **55,638 assertions PASS，0 failures**。
这是碰撞内核和单模型事件的证据，不能升级为完整 T3B 认证。

## 2. Native ORourke decision record

**O2D COMPLETE / NATIVE_OF7_OROURKE_FIRST_ACTIVATION**。
项目所有者的明确决定已记录在 `owner_decision.txt`。原生物理不变，尚未激活生产求解器。

## 3. Native source hash/comparison

本机 Foundation OF7 原文件与取证副本逐字节一致：

| 文件 | SHA-256 |
|---|---|
| ORourkeCollision.C | b7902f356397ed75bef005e89a6a23aa4b758d3483ef3938f559e5ae5378a6dd |
| ORourkeCollision.H | 4ea15160524f8616cdb8c0b12c43ad71a57899b838147ba51d333d463e73ca15 |

实际编译依赖来自 `src/lagrangian/spray/lnInclude/ORourkeCollision.H/.C`。
解析后的目标路径、live hash、编译依赖分别保存在
`native_collision_include_resolution.txt`、`native_collision_live.sha256`、
`collision_compile_dependencies.txt`。
Wrapper 只记录、委托原生 collide/collideSorted，不更改结果、不增加随机抽样。
新编译图不包含 O2 conservative headers；未使用的 O2 搜索路径已移除。

## 4. First-activation ORourke contract

仅 ORourke：原生结果与事务结果必须一致；拒绝恢复原 committed state；不得由残差反造源项。
物理守恒诊断与事务安全认证分开。drag、热、蒸发、注入、species、source adapter、Q recovery
仍执行原严格要求。可能抛异常的验证在 carrier publication/cloud swap 之前完成。

## 5. Archived O1/O2/O2A/O2B status

| 阶段 | 当前解释 |
|---|---|
| O1 | COMPLETE；历史原生守恒 blocker 证据保留 |
| O2 | COMPLETE；研究/设计审计，NOT SELECTED |
| O2A | PARTIAL；历史 thermalization blocker 保留 |
| O2B | PARTIAL；历史 collision-energy blocker 保留 |

旧报告、源代码、数据均未篡改。O2D 更新首次激活决策，不取消历史物理证据。

## 6. transactionState-v1

**完整 codec 未完成**。当前是显式标记的
`transactionState-v1-R1-INCOMPLETE_OUTPUT_RESTART`。

Restricted key 包含 Q/P2 原始 bit（含 signed zero）、native parcel stream/order/IDs、allocator、
完整 RNG/cache、injector/wall history、source buffers、solution iter/trackTime、generation、
time/dt/index、pending theta string。已有深拷贝回滚和完整 RNG encoder/decoder。
但没有整个 graph 的 decoder、持久 pending queue、restart roundtrip、完整未来演化证明。

Random/VoidFraction 的私有成员采用版本绑定的 typed member bridge，只用于导出/恢复实际状态，
不作对象布局强制转换、不替换 RNG、不修改 OF7。该桥必须随实际源码 hash 绑定。
当前 key 相等不能称为完整 transactionState-v1 codec 认证。

## 7. ConeInjection retry

真实 ongoing admission、原生对照、实际副作用后 rollback 均 PASS。
**严格 accepted retry 未闭合**：`NO_ADAPTER_FOR_EXTERNAL_EVENT`。
原生 inject 在 cloud admission 前已经 move 新 parcel；必须记录出生入口质量/动量/能量及逐段源项，
不能把新注入 parcel 质量误当作 gas transfer。

## 8. Stochastic retry

单事件 direct/reference、reject/retry/accept PASS。
接受后另做 **10 次真正消耗 RNG 的原生 renewal**，Uturb/tTurb/RNG 完全一致。
两路径使用相同 synthetic tTurb 历史触发 renewal，没有改原生抽样。
完整 timestep/codec/output 门槛仍开放。

## 9. SphereDrag strict ledger

真实 native calc、非零 UTrans、非零 converted dM/dEt、Q 更新、rollback/retry/accept PASS。
冻结 source adapter 未改。质量、动量、内能+动能账单独检查，不使用 ORourke 例外。

## 10. BlobsSheet transaction

真实 `liquidCore: 1→0` PASS。Synthetic fixture 设置相同的 0.1 m travel history，
触发原生 pWalk>lBU；系数/方程不变。
原生对照、strict adapter、回滚和接受重试 PASS。
之前无 travel history 的失败记录保留，generic cloud mutation 未冒充液核破碎证明。

## 11. ReitzKHRT child transaction

真实 child creation（count>1）、native population/IDs/RNG 对照、strict adapter、rollback/accepted retry PASS。
**后续 child 的 ≥10 次完整 evolution 与逐事件 Q 记账仍未认证**。

## 12. Rebound transaction

真实 trackToFace 到底壁，native rebound 将 Uy 从负变正；patch state、原生结果和 rollback PASS。
**完整 accepted wall transaction 未闭合**：需要显式壁面冲量/能量账及其输出，不能反造 gas source。

## 13. ThermoParcel deletion result

真实 below-minimum represented-mass parcel 经 native calc 删除。
实际 native mass/species/momentum/enthalpy source → unchanged strict adapter → Q publication/retry PASS。
这是独立事件，**不属于 ORourke cleanup 豁免**。

Raw liquid H 与 gas sensible energy 的独立能量账为：

    Eparcel = Hparcel - pHeld*Vparcel + KEparcel
    Renergy = EparcelAfter + dEt + Σ(Hc_i*dmYi_i) - EparcelBefore

其中 chemicalReferenceJ 是冻结适配器的形成焓参考转换，不能漏计；修正后的检查 PASS。

## 14. Support-failure retry

**R1 runtime gate 未闭合**。冻结 T2 native interpolation/support regressions PASS，
但当前事务未在每个真实 native interpolation/deposit segment 前接入 strict-support guard。
未认证 dtLarge 跨非法 stencil 后 reject，再以 dtSmall 合法 accept。
静态回归通过不能替代这项运行期事务证明。

## 15. Trace-gas result

alphaG=1e-20 的真实零碰撞源项 kernel trial/discard/prepare/publish PASS，P2/Q 保持一致。
范围仅为 zero-source kernel。完整 moving trajectory 和非零 trace-source retry 尚未认证。

## 16. Pure-liquid result

exact gas absent candidate 在 carrier prepare 被受控拒绝；discard 恢复 Q/cloud/generation，未造气相。
PASS 范围是 prepare-stage rejection；尚未覆盖完整 runtime tracking hook。

## 17. Persistent output architecture

新增 test-only OutputSink：临时写入、rename、重复 payload 一致性检查、失败后由 caller 保留 ticket 重试。
原生 trial write 仍由冻结 TrialScope specialization 抑制。
**未完成 cloud/Q/restart/output 的持久一致提交**，sequence/pending queue 尚非完整 codec owner。

## 18. Accepted exactly-once output

Probe PASS：每个 fixture 144 kernel tickets +6 model-event tickets，重复 flush 不重复发布。
Kernel 大多为空 payload（未 tracking）；voidFraction 的 model ticket 是真实非空 theta。
另有 10 次 stochastic renewal 和1次 trace auxiliary commit，没有完整统一持久 ticket 契约。
所以不能把本探针结果写成全事务 durable exactly-once PASS。

## 19. Rejected output

Rejected model trials 的 sink publication 为零；kernel reject 不 flush；native trial 永久写出被抑制。
生产文件未改变。尚缺跨 restart、flush interruption、crash 的完整矩阵。

## 20. VoidFraction result

调用原生 preEvolve/postMove/postEvolve，trial 独立拥有 theta，copy/stage/output probe PASS。
单格完整驻留探针检查：

    theta_i = Σ(nParticle * parcelVolume * dtTrack)/(V_i * deltaT)

本探针 dtTrack=deltaT=1e-5；没有另写 occupancy algorithm。
多格轨迹、部分驻留和完整持久 restart 语义仍需认证。

## 21. ORourke no-collision reference

零相对速度原生控制案例：native update 无 pair collision。
reference/trial cloud/RNG/source 字节一致，rollback/small retry PASS。

## 22. ORourke grazing reference

真实 grazing、native damped velocity、mass/species/T/RNG 行为原样保留。
两个 parcel 均 320 K→320 K；原生对照、rollback/small retry PASS。
486.41247553 K 是历史 O2 保守重解释结果，**不是 OF7 原生碰撞加热**。

## 23. ORourke coalescence reference

真实 coalescence class、native mass/multiplicity/U/T/Y 更新保留，原生对照与 rollback/small retry PASS。
已有 native momentum offset 如实保留，不加速度修正。

## 24. ORourke cleanup reference

真实 coalescence 后正残余质量被 native cleanup 删除，count 2→1，reference/trial 一致，carrier dm=0。
历史 O1 A/B/C 的 branch/entry/production replay 独立重跑。
**新两粒子 fixture 不是历史 106/148/190 seed cloud 的完整 accepted transaction replay**。

## 25. ORourke accepted equivalence

Small native reference 与 retry candidate 的 restricted cloud key 在接受前一致；future kernel 也一致。
Large 真实事件单独对照后 deliberate discard。完整 codec 及所有历史 whole-cloud accepted replay 未认证。

## 26. ORourke reject rollback

no-event/grazing/coalescence/cleanup 大步 trial 后 restricted committed key、Q/P2、RNG、source buffers、
IDs/allocator、generation/carrier snapshot 恢复 PASS；无事后 renumber。

## 27. ORourke retry equivalence

Artificial kernel dtLarge=1e-4 被拒绝；dtSmall=1e-5 与独立 native reference 一致。
这些是触发原生分支的测试时长，**不是 CFD 时间步建议**。
完整 transactionState-v1 direct/retry graph equality 未认证。

## 28. ORourke future equivalence

每个 fixture 40 次 future collision-kernel comparisons（每类10次）PASS。
**不满足 ≥10 次已提交完整 collision-capable evolve steps**：kernel query 没有 tracking/injection/drag/event-Q。
冻结 rebinding 的未来模型对照仍保留，不能替代完整事务认证。

## 29. Native mass residual diagnostics

新 cleanup fixture：Rmass≈-2.6260292083e-16 kg，carrier mass=0。
标签 `NATIVE_POSITIVE_MASS_TRUNCATION / KNOWN_NATIVE_MODEL_LIMITATION`。
历史 O1 A/B/C 同样复现；不标 FIXED/CONSERVED。

## 30. Native species diagnostics

Parcel 是 pure C10H22，cleanup 的 C10 mass residual 与 Rmass 相同；其他 parcel species 为零。
Native carrier species source 为零，不由残差反造 dmYi。
每事件 CSV 与 raw native snapshots 保留。

## 31. Native momentum diagnostics

新 coalescence fixture：RmomentumX≈-1.3122549600e-12 kg m/s。
完整参与者向量在 NATIVE_EVENT_PARTICIPANTS.csv；标签
`KNOWN_NATIVE_OROURKE_MOMENTUM_SEMANTIC`。

## 32. Native collision KE dissipation

新 grazing fixture Ediss_native≈2.5497841453e-7 J；实际 native T=320 K。
标签 `NATIVE_UNTRACKED_COLLISION_DISSIPATION`；未热化、未补偿气相。
它与旧 O2 conditioned experiment 是不同测试，不作生产频率估计。
内部能诊断使用实际 native composition H-pV，不假造绝对能量参数。

## 33. No compensating carrier source

ORourke sourceDump before/after 完全一致：mass/momentum/heat/species transfer 均零。
不制造 collision dEt/dmG/dmYi，不创建 reservoir。严格 source adapter 文件未改。

## 34. Duplicate-ID status

新 standalone cloud constructor 放在 TrialScope 内，防止 native restart particleCount reset
破坏 harness allocator；强制验证 unique(origProc,origId)。无事后 renumber。
旧 O1 duplicate-ID 证据未改；未声称所有历史 seeded whole-cloud identity bug 已全局修复。

## 35. Canonical direct/retry comparison

Restricted cloud/RNG/source/key 比较 PASS；**完整 transactionState-v1 serialized equality 未认证**。
当前没有全图 decoder/持久 output state；role name 等非物理身份的 restart schema 仍需明确定义。

## 36. Sequential commit result

每 fixture ≥100 sequential kernel commits；包含 branch/future 后共144 kernel commits。
每轮检查 registry。范围不是所有模型完整耦合 timestep lifecycle。

## 37. Alternating lifecycle result

每 fixture 100 commit/discard alternations +1000 extra discard，合计1104 kernel discard。
Committed state/registry PASS；model-event retry 单列，未作 MPI 声明。

## 38. Registry result

Kernel sequential/alternating/discard registry count 稳定。
冻结 T3A/rebinding 对象身份和 publication 回归 PASS。
Count 稳定不能证明完整 object graph codec。

## 39. RNG result

实际 OF7 Random 的 x_、normalStored、normalValue 三成员 typed codec：
40 varied histories，包含 cache 和 false-flag stale cache；每组200 normals/uniforms 精确未来对照 PASS。
无新算法、额外随机数或有限序列冒充完整 RNG。另有10真实 stochastic renewal 对照。

## 40. Carrier-generation result

沿用冻结 prepareCommit/publishCommitNoFail，稳定 carrier owner。
Discard 保持 snapshot/generation；accepted candidate 接收 nextGeneration 后 coherent swap。
完整 restart/output generation graph 仍开放。

## 41. Frozen regression result

| 回归 | 本轮 |
|---|---:|
| M8A source/energy | 9288 PASS |
| Energy golden | 8 files byte-identical |
| T3A | 64395 PASS |
| M8A.3A | 6375 PASS |
| Native interpolation | 1725880 PASS |
| All gas | 21000/21000 |
| P2/recovery/R1 | 105775 PASS |
| Temporal/restart | 9663 PASS |
| Historical O1 | 349 PASS |

独立检查实际 result/CSV/golden 文件，不只依赖 shell runner 的退出码。

## 42. First-activation limitation document

新增 FIRST_ACTIVATION_OROURKE_LIMITATIONS.md，包含8项限制、486 K历史纠正、
ORourke-only 例外和论文/结果措辞限制；旧文档 untouched。

## 43. Eight-model capability matrix

详见 M8A3B_T3BR1_CAPABILITY_MATRIX.md。八模型均有独立原生/reference/rollback 证据。
六个模型单事件 strict/zero-source accepted retry通过；cone/rebound 外部交换尚未闭合。
ORourke 当前 **PARTIAL / NATIVE-PHYSICS-LIMITATION**。
**没有模型被标为 FULL-SERIAL-TRANSACTION-SAFE 或 FULL-CONSERVATION-SAFE**。

## 44. Performance/memory

| Fixture | Assertions | Failures | Kernel commits | Discards | Seconds | Peak RSS KiB |
|---|---:|---:|---:|---:|---:|---:|
| A | 18546 | 0 | 144 | 1104 | 64.975 | 102192 |
| B | 18546 | 0 | 144 | 1104 | 61.161 | 102596 |
| C | 18546 | 0 | 144 | 1104 | 58.774 | 102504 |

这是 process peak RSS，不是完整长期 no-leak bound。
冻结 rebinding 有1000cycles/warm-final RSS记录；R1 完整 graph/output queue 内存认证仍开放。

## 45. Active solver impact

**NONE**。Active solver、严格 adapter、生产300_2D mesh/BC/dictionaries 未变。
独立审计：12355 existing protected files +2 active Make files；96 production case files 未变。
新增代码仅 standalone test target，无 solver include/runtime registration/production activation。
本机 OF7 源码未改。Foundation OF7 standalone **wmake PASS**。

## 46. Whether T3B-R1 COMPLETE

**NO**。以下仍缺：完整 codec/decoder、strict inlet/wall accepted transaction、
future KHRT child/full ORourke evolve、runtime support crossing/retry、完整 trace tracking/source、
persistent restart-safe output、完整 lifecycle memory certification。
限定范围的 PASS 不能填充这些缺失门槛。

## 47. Whether T3 COMPLETE

**NO / PARTIAL**。T3A COMPLETE 保留；T3B-R1 未完成。
O2D 消除了首次碰撞物理策略决策障碍，没有消除事务架构要求。

## 48. Whether T4 may start

**NO**。本轮未执行 T4。必须先真正完成 T3，不能以 O2D 或 kernel PASS 提前进入。

## 49. M8A/M6B permissions

M8A PARTIAL（直到 T4 COMPLETE）；M6B.0 NO；M6B.1 NO。
没有运行 CFD、two-phase KT activation、pressure recovery 或 VOF→DPM。

## 50. Updated milestone matrix

| Milestone | Latest state |
|---|---|
| M0–M4 | COMPLETE，unchanged |
| M5A/M5B | COMPLETE，冻结主线参考保留 |
| M6A及已冻结 EOS/recovery 阶段 | 历史状态不变 |
| M8A.3A | COMPLETE |
| T2 | 冻结完成范围保留；runtime transaction integration 待闭合 |
| T3A | COMPLETE |
| O1 | COMPLETE / historical native conservation blocker |
| O2 | COMPLETE / research NOT SELECTED |
| O2A | PARTIAL / historical thermalization blocker |
| O2B | PARTIAL / historical collision-energy blocker |
| O2D | COMPLETE / NATIVE_OF7_OROURKE_FIRST_ACTIVATION |
| T3B-R1 | PARTIAL / SERIAL_TRANSACTION_CLOSURE_INCOMPLETE |
| T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0/M6B.1 | NO |

## 新增文件与失败记录

- tests/fiveEqDPMNativeTransaction：nativeState.H、stagedOutput.H、主测试C与Make。
- tools/m8a3b_t3br1_prepare.py、_generate.py、_audit.py。
- 本报告、限制文档、capability matrix、append-only milestone更新。
- fitting/dpm/m8a3b_t3br1_v1：owner decision/native sources/hash/frozen regressions/
  raw states/participants/strict ledgers/3final runs/build-resource logs。

失败记录保留：future fixture dt mismatch；注入缺少 native preEvolve/cache hooks；
初版 atomization 未走过液核长度；独立删除能量检查遗漏 gas formation reference；编译修复日志。
最终三组测试0 failure，不删除失败证据。

## 下一轮仍只能继续 T3B-R1

1. 完整、版本化 graph codec/export/import：Q/P2 bit、native parcel几何/IDs、allocator、
   full RNG/cache、histories、sources、generation/time、owned pending queue；corrupt/unknown state
   在发布前拒绝；roundtrip/restart/future 证明。
2. 原生出生前/逐轨迹段/壁面交换 observation，把 inlet/wall exchange 与 gas transfer 分开；
   不更改 native physics/RNG/order，不改冻结 source adapter。
3. 在真实 interpolation/deposit 前接 frozen strict-support；dtLarge非法→discard→dtSmall合法，
   trace/nonzero source/pure-liquid 门槛一并闭合。
4. 原生完整 cloud evolve +逐事件 source accounting +Q recovery/publication；
   ORourke residual 只作诊断，不补偿；≥10 future collision/child timestep。
5. Pending output 纳入 codec/sequence，failure/restart下 accepted exactly-once/rejected zero；
   保留 native voidFraction residence-time 积分。
6. 重跑八模型 direct/reject/retry/future、≥100commits/1000discards、memory/registry/IDs/RNG/
   generation/output 与所有冻结回归。全部通过才可完成 T3B/T3。

**STOP。本轮不重新开启 O2修复，不进入 T4/M6B，不运行 CFD。**
