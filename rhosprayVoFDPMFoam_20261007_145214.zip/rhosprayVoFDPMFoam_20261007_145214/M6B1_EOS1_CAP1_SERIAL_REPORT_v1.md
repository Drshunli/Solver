# M6B.1-EOS1-CAP1-SERIAL — 完整捕获及 EOS1 设计资格报告

2026-10-05。仅冻结原shock诊断重放及离线评估。

## 1. CAP1 status

**COMPLETE / DESIGN QUALIFIED**。26 项门槛全通过，仅针对冻结 shockInterface_100 诊断包络。未安装 v2，未执行 EOS2 或 TD1。

## 2. Replay parity

17 个 constant/system 输入逐文件 SHA 一致；未生成网格或初始状态。29 份 SR1 历史、原快照、面通量、拒绝和探测记录逐字节一致。dt_history 覆盖驱动器 accepted1–138，初始 step0 独立保存。step106 dt=9.1990382482555322e-7；step107 dt=1.9939191782118543e-18；step138 time=0.00012745457792667973，dt=5.5711770891448054e-22，首个不前进。

沿用冻结 SR1 既有诊断停止：driver 本地接受138后、adapter 发布138前抛出既有停止异常，exit1 预期；不是正常完成的 CFD 运行，也没有新增时间保护。全部新增捕获为只读 I/O。见 [replay_parity.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/replay_parity.json)。

## 3. Captured main count

**6/6**，anchor105/106/107/108/132/137，cell24、attempt0。完整 Q0–Q9、P2hi/lo 的十进制和 binary64 位模式保存。共同区间及 fLo/fHi 在捕获后由冻结 native evaluator 导出；lo/hi/fHi 与原回调逐位相等。见 [MAIN_REJECTION_DETAILS.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/MAIN_REJECTION_DETAILS.csv)。

## 4. Captured probe count

**178/178**，按 anchor105/106/107/108/132/137 分别23/45/22/28/18/42。保存每个原生 trial 候选的完整 Q/P2，probe dt、anchor、cell、MIXED/TRACE_PRESENT、原始失败原因。所有178均为同一 R1:77 域内无根错误。

## 5. Missing count

**0**。之前98个缺失状态已全部补齐。捕获 anchor0–138，每个100单元。独立重建索引保存每格原体积 binary64=3f847ae147ae147b（0.01），时间、lastDt、状态 SHA 和冻结输入 SHA。见 [ANCHOR_RECONSTRUCTION_INDEX.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/ANCHOR_RECONSTRUCTION_INDEX.json)。

## 6. Duplicate count

**0**。事件身份由 main/probe+各自递增序号区分，物理状态或 dt 相同不合并事件；184 个事件一一对原日志。COMPLETE184/MISSING0/DUPLICATE0。原已重建86个候选的12字段与新捕获逐位一致。见 [EOS1_184_CAPTURE_INDEX.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/EOS1_184_CAPTURE_INDEX.csv)。

## 7. Accepted106 state

完整100单元 Q/P2、time=0.00012745457792667531、lastDt=9.1990382482555322e-07 已保存。p=2.99972327472 – 3.2999721208 MPa；TL=286.437564391 – 320 K；rhoL=712.4185906 – 737.993897406 kg/m³；alphaL=4.79790879723e-32 – 0.999999998498；mL=3.45248475574e-29 – 727.432959452 kg/m³。热点22–26所有单元的 primitive 及全域极值见 [ACCEPTED_106_107_108_HOTSPOTS.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/ACCEPTED_106_107_108_HOTSPOTS.csv) 和 qualification_summary.json。

## 8. Accepted107 state

完整100单元 Q/P2、time=0.00012745457792667732、lastDt=1.9939191782118543e-18 已保存。p=2.99972327472 – 3.2999721208 MPa；TL=286.437564391 – 320 K；rhoL=712.4185906 – 737.993897406 kg/m³；alphaL=4.79790879724e-32 – 0.999999998498；mL=3.45248475574e-29 – 727.432959452 kg/m³。热点22–26所有单元的 primitive 及全域极值见 [ACCEPTED_106_107_108_HOTSPOTS.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/ACCEPTED_106_107_108_HOTSPOTS.csv) 和 qualification_summary.json。

## 9. Accepted108 state

完整100单元 Q/P2、time=0.00012745457792667764、lastDt=3.1922844720811036e-19 已保存。p=2.99972327472 – 3.2999721208 MPa；TL=286.437564391 – 320 K；rhoL=712.4185906 – 737.993897406 kg/m³；alphaL=4.79790879724e-32 – 0.999999998498；mL=3.45248475574e-29 – 727.432959452 kg/m³。热点22–26所有单元的 primitive 及全域极值见 [ACCEPTED_106_107_108_HOTSPOTS.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/ACCEPTED_106_107_108_HOTSPOTS.csv) 和 qualification_summary.json。

## 10. Full required p envelope

| 集合 | min – max |
|---|---|
| main | 3.27262892363 – 3.27374428604 MPa |
| probe | 3.27370870177 – 3.27374428604 MPa |
| combined | 3.27262892363 – 3.27374428604 MPa |

来自184个独立 HEOS/native-JANAF 共同压力参考根；不是边界条件估计。

## 11. Full required TL envelope

| 集合 | min – max |
|---|---|
| main | 320.000000001 – 320.107037604 K |
| probe | 320.000000001 – 320.003933515 K |
| combined | 320.000000001 – 320.107037604 K |

来自184个独立 HEOS/native-JANAF 共同压力参考根；不是边界条件估计。

## 12. Full rhoL envelope

| 集合 | min – max |
|---|---|
| main | 712.336026711 – 712.4185906 kg/m³ |
| probe | 712.41556198 – 712.4185906 kg/m³ |
| combined | 712.336026711 – 712.4185906 kg/m³ |

来自184个独立 HEOS/native-JANAF 共同压力参考根；不是边界条件估计。

## 13. alpha/mL trace envelope

| 集合 | alphaL | mL (kg/m³) |
|---|---|---|
| main | 8.60507897628e-22 – 1.015784491e-21 | 6.13041823628e-19 – 7.23579888317e-19 |
| probe | 8.60507897627e-22 – 8.6536029117e-22 | 6.13041823628e-19 – 6.16496138149e-19 |
| combined | 8.60507897627e-22 – 1.015784491e-21 | 6.13041823628e-19 – 7.23579888317e-19 |

没有删相、归一化、alpha floor；accepted 邻域保留到 alphaL≈4.798e-32 的状态。

## 14. Pressure-domain decision

**NOT REQUIRED for diagnosed envelope**。HARD p 仍0.05–12 MPa；184参考根最高3.273744286 MPa，均在原域内。此结论不认证未来全生产流场。

## 15. Temperature-domain decision

HARD TL 推荐285–330 K；NORMAL295–305 K保持。184最高320.107037604 K高于v1320K硬上限；accepted最大320.00000000000335K。330/350/400已预先作为离散候选评估，不使用贴边320.1K域。

## 16. Selected candidate Tmax

**330 K**。选择通过既有预算的最小离散候选，要求诊断包络之上至少5K储备。此储备是本轮设计选择规则，不是放宽物性误差门槛，也不是生产状态覆盖保证。

## 17. Explicit thermal margin

330 − 320.10703760399326 = **9.892962396007 K**。以 rejected 与 accepted 液态最大值共同决定，符合≥5K储备；现有 evidence 不需要350/400K。

## 18. Candidate construction

相同 degree8×8、81系数的一份 Gibbs 势及原导数实现；无 refit、无拼接表、无 runtime 无界外推。新范围是显式 bounded shadow 证书。系数 SHA256：`610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`；候选 C++ header 与上一轮330候选逐字节一致，仅本轮副本 metadata 从 provisional 更新为 design qualified。

## 19. C_L status

**369229.95372342807 J/kg**，binary64不变。e_solver=e_native+C_L；h_solver=h_native+C_L。本轮未更换能量基准或以 offset 掩盖根问题。

## 20. Old-domain regression

3721点（61×61）旧 HARD285–320K/p.05–12MPa重新运行，原结果 SHA 再确认相等。direct PT mismatch=0；新增非法=0；e/h/beta/c差=0；inverse T最大误差1.535e-12K，inverse p最大3.614e-6Pa。见 [old_domain_regression_reconfirmed.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/old_domain_regression_reconfirmed.json)。

## 21. Final extension accuracy

最终330K：2501点61×41，p.05–12MPa、T320–330K，全部正物性及稳定液态，沿用冻结 BUFFER误差预算 PASS。误差是相对 HEOS 的代理近似误差，不是实测不确定度。绝对误差使用对应 SI 单位；e/h relative 使用 native DEF 能量，offset不改变 absolute error。

| 性质 | max abs | RMS abs | max rel | RMS rel |
|---|---:|---:|---:|---:|
| rho | 1.40947918e-07 | 2.49275466e-08 | 1.98268925e-10 | 3.51429861e-11 |
| e | 0.00020557252 | 5.46059981e-05 | 6.71603893e-10 | 1.78677806e-10 |
| h | 0.000204015349 | 5.47080504e-05 | 7.05319829e-10 | 1.84468176e-10 |
| c | 0.000161374679 | 2.26338039e-05 | 1.35294075e-07 | 1.95637818e-08 |
| Cp | 7.7345268e-05 | 2.3522577e-05 | 3.3597658e-08 | 1.02117889e-08 |
| Cv | 0.000184886482 | 3.06788491e-05 | 9.70194094e-08 | 1.61533263e-08 |
| beta | 7.55747014e-10 | 1.04836538e-10 | 3.36144509e-07 | 4.58582133e-08 |
| dpDe | 0.000149511796 | 2.00804213e-05 | 3.36144396e-07 | 4.58582087e-08 |
| dpDrho | 0.381430559 | 0.0521925527 | 2.70098825e-07 | 3.91042537e-08 |

[FINAL_EXTENSION_ACCURACY.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/FINAL_EXTENSION_ACCURACY.json)

## 22. 184 independent reference roots

**184/184 LIQUID_REFERENCE_ROOT**。每个状态使用独立65个 frozen native JANAF样本（9训练/56留出），单一TG<1000K支段 degree5 eG(p)。最大留出误差6.402842700481415e-10J/kg。60位十进制计算完整 mG eG+mL eL−Eint 残差，160次二分；非零 mL eL 始终保留。CoolProp8.0.0 HEOS n-Decane仅离线，参考EOS生成数据，不是实验测量。高精度求根不提高 binary64数据或参考EOS的物理准确度。

[independent_reference_184.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/independent_reference_184.csv)；来源：[CoolProp n-Decane / Lemmon & Span 2006](https://coolprop.org/fluid_properties/fluids/n-Decane.html)，DOI10.1021/je050186n。

## 23. 184 frozen shadow R1 results

RECOVERED_WITH_EXTENSION=184；STILL_NO_ROOT=0；OTHER_DOMAIN_FAILURE=0；UNTESTED=0。归一化残差最大1.0766039734535505e-15，小于冻结2e-12；压力同时遵守原absolute1e-4Pa+relative2e-11门槛，均由原R1接受。shadow与独立参考最大差p=2.3283064e-09Pa、TL=5.7553962e-10K。见 [EOS_REQUIRED_DOMAIN.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/EOS_REQUIRED_DOMAIN.csv)。

## 24. Accepted-state neutrality

原5200+新增300=**5500**，v1合法状态全部保持合法；新失败0。maxΔp=3.0114315450191498e-06Pa；maxrelativeΔp=9.1993079820440471e-13；maxΔTG=7.5283423939254135e-10K；maxΔTL=3.922195901395753e-12K。见 [ACCEPTED_EOS_ENVELOPE_v2.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/ACCEPTED_EOS_ENVELOPE_v2.csv)。

## 25. Pure controls

PURE GAS(+0)16、PURE LIQUID(−0)16，全部PASS。P2有符号零按原语义保留；纯气相无液体时 cL=0 是未存在相的记录，不声称不存在相声速>0。

## 26. Mixed controls

alphaL .1/.5/.9，共48点，全部PASS；p.1/3/8/12MPa×TL300/320/325/330K，原共同速度、TG800K、组分和能量构造保持。

## 27. Trace controls

traceL +1e-20、traceG −1e-20，共32点全部PASS；无phase deletion/alpha floor/额外归一化。112控制矩阵全部离线。见 [recovery_results.csv.controls.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/recovery_results.csv.controls.csv)。

## 28. Sound-speed validity

| 集合 | cL (m/s) | cA (m/s) |
|---|---|---|
| rejected184 | 1170.00303534 – 1170.40802373 | 564.598379933 – 564.621513297 |
| accepted邻域300 | 1170.40802373 – 1300.28577725 | 558.656275147 – 1244.71810582 |
| controls112 | 1110.62575767 – 1299.63765845（液相存在时） | 558.656825165 – 1299.63765845 |

全部存在相 cL>0、cA>0且finite。

## 29. Physical liquid validity

184根全为CoolProp phase3（supercritical_liquid标签）；TL≈320K远低于Tc617.698845K，p≈3.273MPa高于pc2.101337MPa，代表该标签下的压缩液体。未强制气液支路，未用饱和/闪蒸补丁，所有根 p>对应pSat；没有 vapor root。参考后端Tmin243.5K/Tmax675K/pmax800MPa，模型意图仅 single-liquid。参考能力不等于当前五方程包含相变。

## 30. Final root-cause classification

**CLASS A / ARTIFICIAL_TABLE_DOMAIN_LIMIT**。全部184：v1上端TL=320K且fHi<0；独立液态共同根存在；同势候选显式温度域覆盖；冻结R1全部恢复。与SR1的CLASS F混合时间问题不矛盾：本轮关闭EOS域原因，未修正时间策略。

## 31. Whether EOS1 COMPLETE

**YES — COMPLETE / DESIGN QUALIFIED**，全部26门槛通过。仅shadow设计资格；不等于v2 ACTIVE或shock正常跑完。

## 32. EOS2 recommendation — next round only

允许推荐下一轮独立 M6B.1-EOS2-NDECANE：安装/冻结v2、factory/version变更、全EOS/R1回归、M6B0重跑、原时间策略shock重跑，分离EOS修复与时间政策问题。**本轮EOS2未授权执行，未执行。** TD1亦未执行。

## 33. Source changes

仅新增CAP1stage。diagnostic相对冻结SR1：SR1Observation.H只读完整位导出；fiveEqTemporalContract.H anchor/main/accepted导出；fiveEqPrecisionOperator.C记录已有probe候选；Make/files隔离目标。保留原SR1诊断停止、所有数字表达式和分支结果。offline：复制原shadow工具、Make隔离路径，qualifyEOS1.C新增每状态native气体样本/原域bracket输出；reference_all184.py一般化上一轮独立根工具；close_assessment.py/audit_project.py/assess_extension.py。冻结R1/KT/P2/gas/temporal源码原字节不变。

编译初次wrapper C++ auto类型声明错误已修正；旧log保留。离线Eint输出按原R1操作顺序对齐；主拒绝lo/hi/fHi逐位一致。项目审计初次Windows路径分隔格式断言已纠正。均未改变物理模型。两隔离目标最终wmake PASS。完整diff见capture_only.patch/offline_wrapper.patch。

## 34. Foundation hashes

本机Foundation OF7源码**6717/6717**、native parcel**19/19** SHA校验PASS。8个JANAF/气体/循环边界源文件重新读取；没有修改FOAM_SRC。capture加载的55个库逐文件SHA与冻结SR1相等；安装活动binary SHA：`ebb2a5e1f59a3431bea8795098b9a6c190b30b7cdd4dedc57cca9b78cdc05f87`，仍v1。

## 35. Project hashes

此前冻结**34443**文件在history追加前全部原SHA相等；production132文件不变。只授权追加MILESTONE_STATUS历史，不覆盖既有EOS1/SR1报告与证据。新源码、184索引、139anchor重建信息及parent archive SHA随checkpoint封存。见 [project_verification.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos1_cap1_serial_v1/project_verification.json)。

## 36. M6B.1 status

**PARTIAL / STOP**。CAP1只补捕获并做离线设计资格；无v2 active shock、无TD1、无剩余dynamics/boost/production/DPM。M6B.2未执行，前置整体动力学门槛未完成。

## 37. Updated milestone matrix

| 项目 | 状态 |
|---|---|
| M6B.0 | COMPLETE / FROZEN |
| M6B.1-SR1 | COMPLETE / FROZEN / DIAGNOSIS ONLY |
| M6B.1-EOS1-CAP1-SERIAL | COMPLETE |
| M6B.1-EOS1 | COMPLETE / DESIGN QUALIFIED |
| ndecane_gibbs_v2_candidate | SHADOW ONLY / DESIGN QUALIFIED / NOT ACTIVE |
| active EOS | ndecane_gibbs_v1 |
| EOS2 | NEXT ROUND ONLY / NOT EXECUTED |
| TD1 | NOT AUTHORIZED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL / STOP |
| M6B.2 | NOT EXECUTED |
| T4-S1/S2 | COMPLETE / FROZEN |
| T4-S3 | DEFERRED / NOT EXECUTED |
| T4 / M8A | PARTIAL |
| active DPM | NO |
| production CFD/restart | NO / NOT CERTIFIED |

**STOP。**
