# M8A.3B-T4-S2-TIMEOUT-D1-NATIVE

**COMPLETE / DIAGNOSIS ONLY — CLASS C: NATIVE_MODEL_COMPUTE_EXPLOSION.**

Date: 2026-10-04. Localization only. No blocker repair, remaining R1, stress gate, full regression, S3, active integration, production restart or CFD.

## 1. D1 status

Complete within the diagnostic scope. `D1_gate.json` contains28 passing audit checks. Root localized to the existing injection orchestration executing a native cone-injection batch of4,244,131 requested parcels at step5. This does not complete R1 or S2. Earlier MPI_COMMUNICATION_BLOCKER label is a historical timeout label; this round refines the cause without altering the earlier report.

## 2. Exact timeout reproduction

Original frozen `tests/fiveEqDPMR1FinalNative/testR1FinalNative` reused without rebuild.69input files byte equal, same decomposition/mesh/dictionaries, same seed and native RNG initialization, same `-core -steps32 -dt.2 -parallel`, same55s GNU timeout. Initial replay and bounded-sampling replay both complete only steps0–4, stop during step5 and return124. Executable SHA is recorded in `executable_sha.json`; rank PIDs/timestamps/proc maps/loaded executable and library SHA are recorded in each `replay_monitor.json`. Wall elapsed including launch/termination housekeeping is56–58s; the observation window remains55s, not an extended solver allowance.

First debugger export accidentally traversed broad owner/mesh objects, causing large snapshots and long pauses. It is retained as an instrumentation attempt, not a performance baseline. Narrowed samples retain only selected counters, parcel fields and loop variables, although two samples still exported a large referenced object; their measured pauses are explicitly preserved. No per-query diagnostic instrumentation was added to the physics executable. The original previous-round uninstrumented55s failure remains frozen corroborating evidence.

## 3. Rank0 stack samples

Bounded replay PID758: temporal samples20s/35s/48s. All are in step5 under the unchanged project `ExceptionSafeConeInjection::inject` loop, delegating model-specific methods to native ConeInjection. Frames include lazy parcel tracking/model/support or the existing trace write/flush. At48s verbose top stack is `write → std::ostream::flush → MPIFailureLatch::phase`; quiet48s is in `LazyKinematicParcel.C:356`. All retain the enclosing injection loop and advancing `parcelI`. Full thread backtrace, native source/functions/shared libraries saved per sample; no inferior calls or variable writes.

## 4. Rank1 stack samples

Bounded replay PID759, quiet PID746. Repeated stack: `PMPI_Recv → UIPstream::read → Pstream::scatter<int> → reduce<int,maxOp<int>> → InjectionModel::findCellAtPosition (InjectionModel.C:120) → ConeInjection::setPositionAndCell (ConeInjection.C:334) → existing ExceptionSafeConeInjection.H:84`. It waits for owner-rank determination for the next injected parcel. Its enclosing loop index advances between temporal samples, rather than remaining at one unmatched collective.

## 5. CPU behavior

CPU tick rate100Hz. Verbose rank0 user/system ticks at20/35/48s:1028/110,1285/154,1936/249. Quiet:1977/11,3439/14,3798/16. Rank1 also uses substantial CPU in native OpenMPI `opal_progress`, so high CPU is not by itself proof of model computation. Attach pauses are separately recorded (roughly1.4–1.8s normally, with large-export outliers8–20s). Quiet compilation overlapped part of the verbose replay, so raw elapsed throughput is not a clean causal logging benchmark. Counter and loop progression, rather than CPU alone, determine the classification.

## 6. Step5 rank timeline

`RANK_PHASE_TIMELINE.rank0.csv` and `.rank1.csv` combine the known stable-prefix ordering and timestamped OS stack observations. Stable-prefix event timestamps are unknown and left blank; they are not fabricated. Source/destination native processor transfer occurs at step0. At step5 rank0 enters injection/new-parcel tracking/support/model evaluation, while rank1 waits in the matching next owner-rank reduction. Neither returns from this injection phase before55s. No post-evolve ownership reduction is claimed for step5.

## 7. Query/support counter progression

| Replay/rank0 |20s|35s|48s|
|---|---:|---:|---:|
| Verbose preflight |279850|350649|520349|
| Quiet preflight |568433|977240|1069497|

Materialize and rho/p/T/Y/Cp/mu/kappa/U component evaluation counters are captured from existing S1 objects in the gate JSON. Counters represent property evaluations in materialized packets, not an invented count of every virtual sampler access. Rank1 preflight167/materialize162 remains constant during injection because its old parent has not yet entered the ordinary step5 cloud-motion phase. The source-side logged prefix contains one preflight; destination prefix CSV is buffered and empty at forced termination, so its0line count is not a0query claim. Rank1's actual prefix counters are directly sampled as167/162. No new query-time collective or support protocol.

## 8. Native model counter progression

| Verbose rank0 |20s|35s|48s|
|---|---:|---:|---:|
| stochastic calls |279849|350649|520349|
| stochastic random updates |62804|78683|116662|
| blobsSheet calls |15254|19111|28361|
| ReitzKHRT calls |264595|331538|491988|
| sphereDrag calls |529190|663076|983976|
| rebound calls |15252|19109|28357|
| native voidFraction postMove segments |279849|350649|520349|

Quiet48s stochastic1069497/random239708/drag2022412; full counter records saved. The postMove `moves` counter counts tracking segments, not separate Cloud::move invocations. Enclosing injected-parcel loop indices directly show successive per-parcel move completions; no model call order was altered. Processor-transfer quartet count remains the bounded initial one, distinct from owner-selection collectives per injection.

## 9. Parcel count/state

Immediately before step5: one global cloud-owned parcel, rank0=0/rank1=1, identity(0,0). In step5 native injection adds new parcels on rank0. Quiet snapshots directly read cloud-owned rank0 count53260 at35s and58288 at48s; rank1 retains the old one. Thus cloud-owned global totals at those observations are53261 and58289, with an additional currently-injecting parcel potentially not yet added. These are not global transaction/ownership certificates; OS samples are independently timed and rank1's population is static in this phase.

The requested injection count4,244,131 is a numerical Lagrangian parcel count, not hole count or fuel mass flow. Entire evolving population d-distributions were not dumped; configured injection-size range is200–300μm, sampled state/history is recorded, and no guessed global distribution is reported.

## 10. d/nParticle evolution

Before step5 the old rank1 parent has min=maxd7.3239929447904915e-8m, nParticle2545401221464.0679; one parcel under the descriptive threshold d<1e-7m. This threshold only labels diagnostics and changes nothing. The sampled busy rank0 object is a different, newly injected parcel: first attempt identity(0,24956), d=.00025232070164172405m, nParticle=.004065602502260731. Later identities and fractional tracking state differ as injection progresses. The old tiny parent is still on rank1 awaiting injection completion, so its repeated tracking cannot explain the observed rank0 workload. No deletion, merging, diameter clamp or parameter changes.

## 11. Processor-transfer state

Initial native0→1transfer remains recorded by the unchanged C2 boundary observer, preserving the already accepted bounded evidence. During the sampled injection phase neither stack is stuck in parcel stream/iNew/Cloud processor exchange; rank1 waits inside native injector cell-owner lookup. No custom transport or serializer added.

## 12. MPI collective state

There is a real rank1 communication wait, specifically the native max-rank owner-selection reduction at InjectionModel.C:120. This is **not evidence of a deadlocked communication sequence**. Verbose loop indices: rank0 15252→19109→28360; rank1 15253→19110→28360. Quiet: rank0 30980→53260→58288; rank1 30981→53261→58289. The one-parcel lead is explained by rank0 finishing tracking for the current injected parcel while rank1 proceeds to the next owner lookup. Both indices continue to advance; no permanently unmatched collective was found.

## 13. Tracking progress

Tracked parcel identities change, enclosing injection indices advance and move/postMove counters grow. The loop could not advance to tens of thousands of later injected parcels if the previously sampled parcel's move were permanently stuck. Local dt/stepFraction/geometry snapshots are preserved, but values from different parcel identities are not subtracted as if they belonged to one parcel. CLASS B persistent same-parcel tracking nonprogress is excluded as the observed timeout cause, not as a universal claim about all possible future parcel states.

## 14. Model progress and exact trigger

The current trial inherits the roleA injector settings with SOI1s, duration1s and parcelsPerSecond21220659. Steps0–4 reach carrier times .2/.4/.6/.8/1.0s, hence zero injected parcels before the batch. Step5 time is1.2000000000000002s. Actual stack variable `newParcels=4244131` on both ranks. Native `InjectionModel::prepareForNextTimeStep` (lines55–60) computes times relative to SOI and calls native `ConeInjection::parcelsToInject`; its line277 uses:

`floor(parcelsPerSecond*time1 - parcelsAddedTotal)`.

For this first positive-width injection interval, time1≈.2 and previous total0 give the observed4,244,131 batch. Native setPositionAndCell/setProperties and ordinary per-parcel tracking/models execute through the frozen exception-safe orchestration, not a new injector. This sudden millions-parcel workload explains why step5 differs from the one-parcel completed prefix. It is not localized to an infinite ReitzKHRT call or a guessed tiny-drop cost.

## 15. Observer/logging overhead control

Independent `fiveEqDPMTimeoutD1QuietNative` target changes only two test-output sinks: query CSV insertion guarded by a diagnostic environment flag; latch.trace=null when another logging flag is set. S1 preflight/materialization, redundant read-only stencil build, latch decisions, native models, C2 semantics, field/parcel checks and call order remain intact.69input SHA unchanged and all8stable-prefix trajectory/continuation/stability/boundary file comparisons are byte equal.

Quiet query/phase files are0bytes on both ranks. Both verbose and quiet runs still return124 with step5 incomplete under the same55s watchdog. At48s quiet loop has reached58288 versus28360 verbose, but raw ratio is confounded by pause placement and concurrent compile load; do not attribute a precise2.06× speedup solely to logging. Reduced system ticks and verbose write/flush stacks implicate instrumentation cost. **CLASS D's bounded-observer-completes criterion is not met.** The common root in both runs remains the4.24million-parcel native injection workload; logging is an additional cost, not a separately established sole root or permission to repair physics.

## 16. Serial comparator

NOT REQUIRED / NOT RUN. The advancing injected-parcel loops, native count formula, active model/support counters and matched owner lookup already sufficiently localize this cause. A semantically equivalent serial ownership/injection test was not fabricated, and no hand-written parcel evolution was introduced.

## 17. Root-cause class A–F

**CLASS C — NATIVE_MODEL_COMPUTE_EXPLOSION**, specifically native cone-injection activation at step5 and its enormous per-step batch, processed through existing frozen orchestration. Communication synchronization and diagnostic logging add cost but do not create a demonstrated permanent MPI wait or same-pose native tracking loop. This classification is bounded to the diagnosed55s behavior.

## 18. True MPI deadlock proven?

**NO.** Real expected MPI wait is present; permanent mismatched-sequence deadlock is excluded in the observed interval by advancing matching injection ordinals. No new communication fix is justified by this diagnosis.

## 19. Compute slowdown proven?

**YES**, workload/call-count explosion is directly observed: a requested batch4,244,131 versus the prior one-parcel population, with more than one million stochastic calls in the quiet observation. Completion time for the full batch was not measured or extrapolated into a PASS.

## 20. Tracking stall proven?

**NO.** Successive parcel moves complete and identities/loop indices advance; no persistent same-object, same-pose, same-stepFraction state explains the timeout.

## 21. Instrumentation implicated?

**YES as additional cost**, from trace write/flush stacks and reduced-output control. It is not proven to be the sole root. Diagnostic export outliers themselves pause the inferior and are explicitly measured, so neither precise wall-clock attribution nor universal performance claims are made.

## 22. Any source changed

Frozen source bytes unchanged. Only new independent diagnostic-target `QueryObserver.H` and its test main have logging-level changes; exact diffs saved. All coefficients, native functions, shared ZS1/ID1/S1/N1/C2/transaction code and parcel-call order unchanged. New OS monitor/GDB export/offline analysis are test tools, no MPI messages/watchdog protocol/scheduler. Existing GNU timeout remains the sole termination mechanism. No variable writes, inferior function calls, signal recovery or instruction-pointer changes by GDB.

## 23. Foundation hashes

Fresh6717Foundation/19nativeparcel checks PASS. Loaded library/executable hashes captured in monitor metadata for each rank. Actual source paths and source lines are present in stack files. Native InjectionModel, ConeInjection, Cloud::move, particle tracking, Pstream, Random and all model sources remain unchanged.

## 24. Project hashes

23879protected entries unchanged before append, zero unexpected deltas. Earlier reports/checkpoints/targets/production files remain immutable; only append-only milestone history is authorized at closing. No prior certificate revoked or upgraded.

## 25. Active solver impact

**NONE.** No active thermo/EOS/pressure/KT/VOF/DPM coupling activation or equation changes.

## 26. Production mesh/BC impact

**NONE.** All new meshes/dictionaries are copied diagnostic fixtures. No production operating condition, geometry, boundary, injection schedule or coefficient change.

## 27. D1 COMPLETE?

**YES / DIAGNOSIS ONLY.** Exact timeout, PIDs, ≥3valid temporal stack/counter samples perrank, native source/function, CPU, population/physical state, phase divergence, MPI-wait meaning, tracking progress, native workload trigger and reduced-output control are recorded. Snapshot export overhead and incomplete global distribution sampling are explicit limits; they do not change the directly measured batch size and advancing native work. No blocker repair performed.

## 28. T4-S2 status

**PARTIAL**, R1FINAL stillPARTIAL. Earlier bounded coneInjection, single-cross VoidFraction, forward C2 and stable steps0–4 evidence preserved. D1 does not replace any remaining R1 final gate.

## 29. Next permitted action

NEXT ROUND ONLY: separately review R1 test duration, inherited native injection schedule and numerical parcel budget, then propose a minimal native-first test/stress strategy. No automatic SOI/rate/dt/model edit, communication repair, timeout extension as PASS or S3 permission follows from this report.

## 30. T4/M8A/M6B/CFD matrix

| Milestone | State |
|---|---|
| TIMEOUT-D1-NATIVE | COMPLETE / DIAGNOSIS ONLY / CLASS C |
| KH-ZS1 / ID1 / S1 / C1-N1 / T3 | Prior COMPLETE/FROZEN scopes preserved |
| R1FINAL / T4-S2 | PARTIAL / PARTIAL |
| T4 / M8A | PARTIAL / PARTIAL |
| S3 | NOT AUTHORIZED / NOT EXECUTED |
| M6B / CFD | NO / NO |
| Production restart | NOT CERTIFIED |

STOP. No remaining R1, full regression, >=1000crossing stress, S3 or CFD executed.
