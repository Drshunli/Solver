# M6B.1-EOS2-LB1-NDECANE

离线诊断与shadow设计资格报告 — 2026-10-05

## 1. LB1 status

**PARTIAL / STOP / DESIGN CLASSIFICATION UNRESOLVED**。完成独立参考诊断及允许的shadow离线测试；不满足全部COMPLETE勾选项。

## 2. First lower-bound state

anchor114 / cell45 / attempt0。完整Q/P2及binary64文本/位核对PASS。alphaL=2.152515651152602e-15，mL=1.5911360398631835e-12kg/m³，rhoL=739.19836030515364kg/m³，Eint=4348018.6178385196J/m³。v2pLo=3419191.1230748333Pa，pHi=12000000Pa，fLo=+381082.59926334675，fHi=+28763051.280841887；本轮原生查询逐文本重现。

## 3. Independent first root

```json
{
  "id": 0,
  "status": "LIQUID_REFERENCE_ROOT",
  "pStar": 3286242.793380548,
  "TLStar": 284.87337272298197,
  "TGStar": 819.2966997068982,
  "rhoL": 739.1983603051536,
  "alphaL": 2.152515651152602e-15,
  "mL": 1.5911360398631835e-12,
  "eL_solver": -32928.743131712894,
  "betaL": 0.0016416509184368376,
  "cL": 1306.700596671487,
  "cA": 564.9055117296452,
  "Cp": 2142.0746798651467,
  "Cv": 1723.7411167358293,
  "pSat": 68.66405864441103,
  "phase": 3,
  "below285_K": 0.12662727701803078,
  "liquidWeightedEnergy": -5.239410994426566e-08,
  "residualArithmetic": "-1.6963493524515137620917406E-28",
  "gasFitMaxError": 2.9103830456733704e-10,
  "gasCpFitMaxError": 6.821210263296962e-13,
  "estimatedGasFitPressureError": 1.4195916320344593e-09
}
```
气相独立native Foundation7 JANAF查询按每状态65个点重现单分支五次eG(p)，9拟合/56留出点，误差见reference_gate.json；不是液体多项式拟合。液体用离线HEOS自然PT分支与密度温度求根。完整mG*eG+mL*eL-Eint以60位Decimal累加，110次压力二分。未删除trace或强制phase。算术残差不表示物理EOS具有60位精度。

## 4. Required first TL

TL*=284.87337272298197K；低于285K 0.12662727701803K。

## 5. 130-state accounting

MAIN=4 / PROBE=126 / COMPLETE=130 / MISSING=0 / DUPLICATE=0。EOS2_LB_130_INDEX.csv逐事件关联原始文件、SHA、anchor/cell/attempt/dt、参考根及shadow结果；未推进PDE。

## 6. Main envelope

```json
{
  "pStar": [
    3285416.8554529846,
    3286242.793380548
  ],
  "TLStar": [
    284.87337272298197,
    285.00000000011846
  ],
  "rhoL": [
    739.1009933382393,
    739.1983603051536
  ],
  "alphaL": [
    1.924976067026895e-15,
    2.152515651152602e-15
  ],
  "mL": [
    1.4227517232919152e-12,
    1.5911360398631835e-12
  ],
  "cL": [
    1306.1815577535049,
    1306.700596671487
  ],
  "cA": [
    564.8880860477688,
    564.9055117296452
  ]
}
```

## 7. Probe envelope

```json
{
  "pStar": [
    3285416.855452983,
    3285431.6379014826
  ],
  "TLStar": [
    284.9974695297284,
    285.00000000011846
  ],
  "rhoL": [
    739.1009933382393,
    739.1029377977934
  ],
  "alphaL": [
    1.9249760670263666e-15,
    1.9290483789333133e-15
  ],
  "mL": [
    1.4227517232915248e-12,
    1.425765324023683e-12
  ],
  "cL": [
    1306.1815577535049,
    1306.1919179077047
  ],
  "cA": [
    564.8880860477688,
    564.8883980209747
  ]
}
```

## 8. Combined p envelope

[3285416.855452983, 3286242.793380548]Pa。

## 9. Combined TL envelope

[284.87337272298197, 285.00000000011846]K。
{"referenceRootCount": 130, "below285Strict": 37, "atOrAbove285RoundoffScale": 93, "largestAbove285_K": 1.184616849059239e-10, "note": "Some root temperatures are within ~1e-10K of285; do not describe all130 as appreciably below285. Model/reference boundary inversion roundoff matters."}

## 10. Combined rhoL envelope

[739.1009933382393, 739.1983603051536]kg/m³。

## 11. Alpha/mL envelope

alphaL=[1.9249760670263666e-15, 2.152515651152602e-15]；mL=[1.4227517232915248e-12, 1.5911360398631835e-12]kg/m³。mL*eL保留，首状态其贡献=-5.239410994426566e-08J/m³。

## 12. Accepted113–119 envelope

| step | cells | TL/K | p/Pa | rhoL/kg m-3 | trace count |
| --- | --- | --- | --- | --- | --- |
| 113 | 100 | [285.20489129398294, 321.57022550996425] | [2999723.419319453, 3299939.472890146] | [711.2054577083112, 738.9434629179159] | 31 |
| 114 | 100 | [285.037575615247, 321.75383416392816] | [2999723.9067097465, 3299932.819886698] | [711.0626536392543, 739.0721249098577] | 31 |
| 115 | 100 | [284.99999999999693, 321.7946841250933] | [2999724.0312652416, 3299931.316466303] | [711.0309024549401, 739.1009933382392] | 31 |
| 116 | 100 | [284.99999999999693, 321.79468412509357] | [2999724.0312652416, 3299931.316466303] | [711.0309024549399, 739.1009933382392] | 31 |
| 117 | 100 | [284.99999999999693, 321.79468412509374] | [2999724.0312652416, 3299931.316466303] | [711.0309024549398, 739.1009933382392] | 31 |
| 118 | 100 | [284.99999999999693, 321.79468412509385] | [2999724.0312652416, 3299931.316466303] | [711.0309024549397, 739.1009933382392] | 31 |
| 119 | 100 | [284.999999999997, 321.79468412509374] | [2999724.0312652416, 3299931.316466303] | [711.0309024549398, 739.100993338239] | 31 |

各100cell的完整Q/P2及位字符串已复制，完整alpha/mL及trace范围在accepted_neighbors_gate.json。119是冻结driver接受的状态；当时时间未增加，不把它描述为成功production时间推进。

## 13. Pressure extension?

**NOT REQUIRED for this diagnosed envelope**。全部130根在0.05–12MPa内；未扩压力域。

## 14. Lower-T extension?

数值fluid-EOS诊断支持扩下界；130根全部存在，部分在285K以下，部分距285K仅舍入尺度。保留物理资格未闭合事项，不自动推广active模型。

## 15. Physical liquid validity

130自然PT查询均为HEOS phase3：p>pc而T<Tc的compressed-liquid标签；不是气态或液汽flash。TL>Ttriple=243.5K，远低于Tc，p>psat；Cp/Cv/beta/c²均正。**不能将HEOS流体分支标签当作固液相平衡证明**：本机n-Decane无melting_line，Würflinger1975原始压力熔化数据未获得。高压固液证书UNRESOLVED。
来源：[CoolProp官方](https://coolprop.org/fluid_properties/fluids/n-Decane.html)、[NIST reference EOS](https://www.nist.gov/publications/short-fundamental-equations-state-20-industrial-fluids)、[EES熔化曲线来源说明](https://fchartsoftware.com/ees/eeshelp/hs572.htm)。EES能量参考不同，未用其焓数据。完整记录physical_liquid_validity.json。

## 16. Root-cause class A–D

**CLASS D / UNRESOLVED**。参考fluid根与shadow结果强烈支持人工下界截断；没有发现无液体fluid根、越压力域、负声速或必须删除trace的状态。由于物理固液资格与一个角点控制尚未闭合，不能满足CLASS A中“qualified v3”的完整声明。没有证据判CLASS B或C。

## 17. Whether v3 justified

建立隔离shadow候选有数值依据；其完整design qualification仍PARTIAL。未修改factory或active-v2。

## 18. Selected Tmin

shadow建议Tmin=275K，Tmax=330K、p=0.05–12MPa、NORMAL295–305K不变。280K候选精度PASS但余量不足；275K候选精度PASS。未继续270K或更低。

## 19. Lower thermal margin

minRequiredTL−275=9.87337272298197K >=5K；280K只有4.87337272298197K。余量是针对冻结130状态的离线设计余量，不是未来shock轨迹保证。

## 20. Candidate construction

位置：fitting/integration/m6b1_eos2_lb1_ndecane_v1/offline_native/liquidEOS/ndecane_gibbs_v3_candidate/。同一degree8x8、81个potential系数、六组其导数系数数组、导数/逆算代码；只改Tmin及class/array符号名。candidate_construction_gate.json归一化逐文本相同PASS；candidate_changes.patch可审查。

## 21. C_L

C_L=369229.9537234281J/kg，binary64相同；coefficients SHA=610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac。未改变native DEF到solver的h/e偏移。

## 22. Lower-domain accuracy

| property | max absolute | RMS absolute | max relative | RMS relative |
| --- | --- | --- | --- | --- |
| rho | 6.094194304751e-08 | 1.0821812109567671e-08 | 8.112086960618228e-11 | 1.444716478250401e-11 |
| e | 0.00014731776900589466 | 4.670978656050223e-05 | 3.4662954784601526e-10 | 1.1069631998304489e-10 |
| h | 0.00014931318582966924 | 4.7659703451897765e-05 | 3.6087855404309025e-10 | 1.1514474043982986e-10 |
| Cp | 5.867358731848071e-05 | 2.0523029383104172e-05 | 2.7868678170402448e-08 | 9.723078735751273e-09 |
| Cv | 0.00013354945508581295 | 2.340020491504704e-05 | 7.925863616331373e-08 | 1.3827032354503204e-08 |
| beta | 3.7740020527102236e-10 | 4.349723987786059e-11 | 2.4613377076965597e-07 | 2.8700218829936073e-08 |
| c | 0.00013776805985799 | 1.624347011381327e-05 | 1.00416061497357e-07 | 1.1974542499430057e-08 |
| dpDe | 0.000160524152306607 | 1.8950629052421735e-05 | 2.4613383137970853e-07 | 2.870022110957865e-08 |
| dpDrho | 0.3825073945336044 | 0.04393422789229243 | 2.008306260594348e-07 | 2.3948492206624683e-08 |

原生275–285K/全p域121×81=9801点，全部既有BUFFER预算PASS；Python独立导数也分别检查280/275共19602点。误差对reference EOS，不是假称实验不确定度。

## 23. Old-domain neutrality

285–320K原生3721点9物性精度PASS；与active-v2直接PT输出相同，directPTMismatch=0。

## 24. Upper-extension neutrality

320–330K原生3721点9物性精度PASS，与v2直接PT输出相同。旧域+上端合计7442点bit相同。三个域合计17243点逆算invalid=0；maxInverseT=1.8189894035458565e-12K，maxInverseP=4.192814230918884e-06Pa；274.999K拒绝PASS。

## 25. 130 shadow R1 result

130/130PASS / stillNoRoot0 / otherFailure0，全部5次迭代；最大归一化残差=8.570596875729471e-16。参考对比完整在recovery_regression_gate.json；maxΔp=1.862645149230957e-09Pa，maxΔTL=1.21985976875294e-10K。冻结R1数学与代码未改。

## 26. Old184 regression

184/184PASS，p/TG/TL/cL/cA与EOS2冻结输出数值差0。

## 27. Accepted-state neutrality

| population | count | maxΔp/Pa | maxΔTG/K | maxΔTL/K | maxΔcL | maxΔcA |
| --- | --- | --- | --- | --- | --- | --- |
| prior5500 | 5500 | 1.862645149230957e-09 | 4.547473508864641e-13 | 1.7053025658242404e-13 | 9.094947017729282e-13 | 1.1368683772161603e-13 |
| newNeighbors700 | 700 | 3.039836883544922e-06 | 7.580638339277357e-10 | 3.069544618483633e-12 | 5.6843418860808015e-12 | 2.43971953750588e-10 |

全部6200状态合法，无新invalid；差为逆算舍入尺度，未要求改变R1使逆算bit匹配。

## 28. Controls

旧112项fresh子集112/112PASS。包含+0纯气、-0纯液、mixed.1/.5/.9、traceL/traceG；新增275/280/requiredT/285K和全压力边界后总280项，**279PASS/1FAIL**。失败alphaL=.9、p12MPa、TL275K，NO_LIQUID_PRESSURE_INTERVAL。rhoBoundary=752.5301191082287，mL=677.2771071974059，mL/alphaL=752.5301191082289，超出1ULP；冻结严格边界正确拒绝这个生成Q状态。未夹密度、未松容差、未隐藏失败或修改R1。controls_gate.json保留原行。

## 29. Sound-speed range

```json
{
  "rejected130": {
    "cL": [
      1306.1815578320766,
      1306.7005967541158
    ],
    "cA": [
      564.8880860477688,
      564.9055117296454
    ]
  },
  "neighbors700": {
    "cL": [
      1163.6065381031908,
      1306.1815578320811
    ],
    "cA": [
      558.6590250564435,
      1244.7181046984201
    ]
  },
  "old184": {
    "cL": [
      1170.003035344481,
      1170.4080237276469
    ],
    "cA": [
      564.598379933349,
      564.6215132965555
    ]
  },
  "prior5500": {
    "cL": [
      1170.408023727648,
      1300.2857772466896
    ],
    "cA": [
      347.9538728760081,
      1244.718123651766
    ]
  }
}
```
所有本轮成功恢复的存在液相cL正有限，混合cA正有限；纯气absent液体cL=0不作为存在液相断言。低温Hessian-derivedc²、Cp/Cv/beta均正。失败控制不虚构声速。

## 30. Source changes

仅新增本轮stage的离线工具、输入副本、shadow候选、结果/报告，以及milestone追加。active-source改动NONE；本轮未build active EOS/solver。复制的R1.C/.H、P2Fraction/P2IO、Allaire和nativegasheader与active哈希相同；少量未编译的历史driver副本单独列在offline_source_comparison.json，不能作为运行代码。

## 31. Foundation hashes

本轮重新核验6717Foundation与19parcel文件，全部OK；重新实际读取8gas/patchsource及hash在foundation_read_manifest.json/source_read.txt。active-v2二进制及55loadedlibrary全部SHA相同；runtime_protection.jsonPASS。

## 32. Project hashes

以EOS2_PARTIAL_STOP检查点及36629项frozen_after为父链，另加入其snapshot本身。只允许MILESTONE_STATUS.md追加；最终完整保护核验与新封存结果在project_protection.json/checkpoint_seal.json。parent SHA=d1fed4d91eab1ddfece01c86556c28cbb3022497295c9ec653ff68cd52f67037。

## 33. LB1 COMPLETE?

**NO**。controls全PASS未满足；高压固液有效性证书未闭合。其余本轮数据账户、独立root、温压envelope、物性预算、old184、accepted6200、声速、源代码与runtime保护已完成。

## 34. Whether EOS3 may start

**NO**。先独立闭合角点生成Q的表示合同和可引用的熔化曲线/固液边界依据。不得将本轮shadow数值通过自动升级为active EOS3。下一任务需明确范围；不在本轮修R1或安装v3。

## 35. EOS2 status

M6B.1-EOS2 = PARTIAL / STOP；active ndecane_gibbs_v2继续保留，历史v1保留。

## 36. TD1 status

REQUIRED / NOT AUTHORIZED / NOT EXECUTED。未改tiny-dt继承、growth路径、representable-timeguard。

## 37. M6B.1 status

PARTIAL / STOP。未继续shockPDE、remaining wave ladder、RH/highMach、M6B.2、activeDPM/T4-S3、productionCFD。

## 38. Milestone matrix

| item | status |
| --- | --- |
| M0–M4 | COMPLETE / FROZEN |
| M5A/M5B/M6A1a | COMPLETE / FROZEN |
| M6B.0 | COMPLETE / FROZEN; EOS2 rerunPASS |
| M6B.1-SR1 | COMPLETE / DIAGNOSIS ONLY |
| M6B.1-EOS1 | COMPLETE / DESIGN QUALIFIED |
| ndecane_gibbs_v1 | HISTORICAL / PRESERVED |
| ndecane_gibbs_v2 | ACTIVE / PRESERVED |
| M6B.1-EOS2 | PARTIAL / STOP / lower-domainblocker |
| M6B.1-EOS2-LB1 | PARTIAL / STOP / CLASS D |
| ndecane_gibbs_v3_candidate | SHADOW / numericalPASS / full designPARTIAL |
| TD1 | REQUIRED / NOT EXECUTED |
| M6B.1 | PARTIAL / STOP |
| M6B.2 | NOT AUTHORIZED |
| activeDPM/productionCFD | NO |

**STOP。**
