# R2B type graph audit — 2026-10-03

Written before copying parcel implementation. Source: installed Foundation OF7,
`/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src`, read by
`fitting/dpm/m8a3b_t3br2b_v1/read_types.sh`, and the frozen R2A-FINAL source snapshots.

## Concrete versus generic tracking-data binding

| Layer | Binding | Consequence |
|---|---|---|
| particle/Cloud | Cloud.move dispatches `p.move(cloud,td,trackTime)` generically | Retain installed geometry and Cloud containers |
| KinematicParcel | setCellValues, calcDispersion, calcVelocity, calc and move declare its own nested trackingData; move casts to final parcelType::trackingData | An independent TD cannot be passed through the installed concrete base. Its constructor also eagerly creates rho/U/mu interpolators. Local Kinematic declaration/definitions needed; no native-TD subclass patch |
| ThermoParcel | Own nested TD owns private const Cp/kappa fields; heat-transfer/surface/source methods use that concrete TD | Replace TD storage/constructor and carrier sampling access; retain parcel physical fields and model arithmetic |
| ReactingParcel | Own TD inherits ParcelType TD and adds pressure; source correction accesses CpInterp().psi()[cell]; conditional surface correction accesses carrier Y | Local type identity and carrier-access adaptation needed, not a new reacting model |
| SprayParcel | TD is `typename ParcelType::trackingData`; KH creates SprayParcel children and reuses parent TD | Local identity needed for copies/children; independent child gate required before immediate forces/dispersion |
| Kinematic/Thermo/Reacting/SprayCloud | parcelType TD obtained generically from CloudType; nested cloud aliases drive model templates | First try installed cloud templates composed over local parcel, without copying cloud physics |
| Eight models | CloudType template parameters; no exact basicSprayParcel binding established in source audit | Compile explicit instantiations/selection tables before evolution; inspection is not a compile PASS |

## Proposed graph

```
Foam::fiveEqDPM::LazySprayParcel<
  LazyReactingParcel<LazyThermoParcel<LazyKinematicParcel<Foam::particle>>>>
Foam::SprayCloud<Foam::ReactingCloud<Foam::ThermoCloud<
  Foam::KinematicCloud<Foam::Cloud<localParcel>>>>>
```

The local Kinematic layer is necessary because of concrete signatures, rather than
because geometry needs replacement. Retain particle::trackToFace/currentTetIndices,
the Kinematic move algorithm, parcel field layout, clone(mesh), stream/iNew and IO.

## Minimum file family to test

Kinematic/Thermo/Reacting each require `.H`, `I.H`, `TrackingDataI.H`, `.C`, `IO.C`;
Spray requires `.H`, `I.H`, `.C`, `IO.C`: 19 parcel files. Declarations alone are
insufficient: member definitions, constructors and IO are class-name-qualified.
These are a type-identity fork, not permission to change the eight model physics.
No cloud or model implementation copies are planned initially. Retain GPL notices.

## Semantic change budget

1. Unique namespace, class names, include guards and qualified definitions.
2. Lazy TD: no full Cp/kappa fields or constructors; no eager gas interpolators.
3. Support/generation/native-pose preflight before carrier sampling.
4. Replace field-only sampling access with certified local sampling, preserving formulas.
5. Independent child preflight and movement/rebound invalidation.

Compile topology first. A renamed stock TD is only a type probe and **not** a lazy
bridge. Runtime acceptance must separately prove no eager scans and native equivalence.
Native cloud construction still references carrier thermo; legal all-gas topology
does not certify absent-gas cloud construction. No absent-cell fake carrier field
may be used to bridge this ownership issue.

## Unresolved runtime design gates

Sparse sampling must match native barycentric/tet interpolation, including required
contributors. Cp/kappa source correction requires certified cell sampling; Bird
surface correction requires valid per-species carrier access. Constructor-only
deferral does not satisfy these gates. None is being declared impossible by this audit.
