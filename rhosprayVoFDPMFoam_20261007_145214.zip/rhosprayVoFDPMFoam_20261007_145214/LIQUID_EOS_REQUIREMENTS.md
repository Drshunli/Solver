# LIQUID_EOS_REQUIREMENTS — M5B source audit

## Current Foundation OF7 C10H22 liquid data

`SLGThermo` supplies `liquidMixtureProperties`, and the current one-liquid
database resolves to `C10H22`. In the local Foundation OF7 source,
`C10H22::rho(p,T)` calls `NSRDSfunc5::f(p,T)`, whose implementation ignores
its pressure argument. `liquidProperties::psi(p,T)` returns zero and
`CpMCv(p,T)` also returns zero with an incompressible-liquid assumption.
The database supplies density, Cp, enthalpy, viscosity, conductivity, sigma
and latent heat correlations for spray parcels. It does **not** supply a
finite liquid acoustic speed, bulk modulus, or a pressure-dependent density
law suitable for the selected compressible KT flux.

Source locations under the local `OpenFOAM-7/src`:

- `thermophysicalModels/thermophysicalProperties/liquidProperties/C10H22/C10H22I.H`
- `thermophysicalModels/thermophysicalProperties/liquidProperties/liquidProperties/liquidPropertiesI.H`
- `thermophysicalModels/thermophysicalProperties/thermophysicalFunctions/NSRDSfunctions/NSRDSfunc5/NSRDSfunc5.H`
- `thermophysicalModels/thermophysicalProperties/liquidProperties/liquidMixtureProperties/liquidMixtureProperties.H`

## Required future liquid EOS contract

For `mL/alphaL` and pressure-equilibrium energy recovery, an EOS must define
`eL(rhoL,p)` (or a mutually invertible `rhoL(p,T), eL(p,T)` pair), admissible
state ranges, and the isentropic characteristic speed
`cL²=(partial p/partial rhoL)_s > 0`. The isobaric model also needs
`xiL=(partial (rhoL*eL)/partial p)_{rhoL}` to compute its mixture acoustic
speed. Pressure, density and energy inversions must remain positive and
well-defined near pure-phase limits and across shocks.

A calibrated weakly compressible / Tait-type density-pressure relation is a
candidate, but it needs a thermodynamically consistent caloric energy and
measured/reference bulk modulus. The experimental branch contains a
`barotropicLiquidThermo` candidate; it has **not** been audited or promoted
into this target. No coefficient or liquid sound speed is invented in M5B.
The M4 spray-property database can remain the source of transport and
droplet properties, but its rho correlation cannot by itself serve as the
conservative liquid EOS. A reconciliation strategy between the future VOF
EOS and DPM parcel rho/Cp must be documented and validated before transfer.

Constant-density liquid would imply an effectively infinite bulk modulus in
this acoustic model. It can be useful for a low-Mach limit, but is not an
adequate unqualified final choice for supersonic gas shock–liquid-interface
interaction. This is an implementation blocker, not a fitted parameter.
