# M5B.1 — pinned MFC five-equation source audit

## Scope and reproducibility

Repository https://github.com/MFlowCode/MFC, branch `master`, exact commit
**0f7f62fa0abb9394012cb99ba3aa93136f93e074**, commit date 2026-09-28.
Inspected on 2026-09-30. Local checkout: `D:/DATA/Solver/reference/MFC`.
Downloaded through WSL Git after the bundled Windows Git lacked its HTTPS helper.
No MFC build, case, source port or production EOS fitting was performed.
Reference repository AGENTS.md was read through WSL. Source hashes and commit-blob
comparisons are recorded in `fitting/M5B1_source_audit_manifest.json`.
Windows reports two checkout symlink differences (AGENTS.md and a platform build
script); audited regular source files are checked against commit blobs separately.

## Audited source index

Every link is commit-pinned. Local file paths have the same relative suffix.

| File / location | Evidence |
|---|---|
| [m_global_parameters_common.fpp:137](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/common/m_global_parameters_common.fpp#L137) | model_eqns=2 partial densities, momentum, energy and adv indices |
| [m_eos.fpp:327](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/common/m_eos.fpp#L327) | phase coefficient dispatch and denominator floors |
| [m_eos.fpp:497](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/common/m_eos.fpp#L497) | phase energy/bulk modulus and analytic pressure |
| [m_eos.fpp:567](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/common/m_eos.fpp#L567) | coefficient mixing; acoustic branches around 659–777 |
| [m_variables_conversion.fpp:72](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/common/m_variables_conversion.fpp#L72) | conservative pressure recovery; chemistry separate |
| [m_variables_conversion.fpp:186](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/common/m_variables_conversion.fpp#L186) | mpp_lim clips partial densities and alpha, then renormalizes alpha |
| [m_variables_conversion.fpp:792](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/common/m_variables_conversion.fpp#L792) | partial densities retained; velocity to momentum; energy conversion |
| [m_rhs.fpp:1083](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_rhs.fpp#L1083) | phase bulk moduli, alpha and Kterm |
| [m_rhs.fpp:1439](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_rhs.fpp#L1439) | alpha-interface / velocity-interface nonconservative RHS branches |
| [m_global_parameters.fpp:947](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_global_parameters.fpp#L947) | adv_src_mode and additional nc_iface_vel export |
| [m_riemann_solver_hll.fpp:562](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_riemann_solver_hll.fpp#L562) | HLL interface traces |
| [m_riemann_solver_hllc.fpp:1371](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_riemann_solver_hllc.fpp#L1371) | alpha flux and shared velocity handoff |
| [m_riemann_solvers.fpp](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_riemann_solvers.fpp), [m_riemann_state.fpp](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_riemann_state.fpp) | export channels / finalization |
| [m_thinc.fpp:293](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_thinc.fpp#L293) | reconstructed alpha and both partial densities updated together |
| [m_weno.fpp:1486](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_weno.fpp#L1486), [m_muscl.fpp:226](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/src/simulation/m_muscl.fpp#L226) | THINC called after reconstruction |
| [case_validator.py:1815](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/toolchain/mfc/case_validator.py#L1815) | actual alt_soundspeed configuration constraints |
| [equations.md:236](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/docs/documentation/equations.md#L236), [case.md:605](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/docs/documentation/case.md#L605) | model documentation and input meanings |
| [Riemann source notes](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/misc/dev_notes/Riemann_and_RHS_source_terms_explanations.md), [NC derivations](https://github.com/MFlowCode/MFC/blob/0f7f62fa0abb9394012cb99ba3aa93136f93e074/misc/dev_notes/HLL_HLLC_non_conservative_terms_derivations.md) | face quantity meanings and nonconservative products |

## State and conversion findings

For the standard WENO/MUSCL model_eqns=2 path MFC stores N partial densities,
shared momentum components, total energy density and N alpha slots. The IGR
branch instead stores N-1 alpha slots. This project stores **one independent
alphaL** for two materials and derives alphaG. Do not copy MFC's complete layout.
Primitive continuity slots still hold partial densities, not intrinsic densities;
momentum slots become velocity and the energy slot becomes pressure. Array names
alone therefore do not identify units or physical meanings.

The nonchemistry coefficient EOS path has I=GammaMix*p+PiMix+qvMix,
GammaMix=sum(alpha_k*Gamma_k), PiMix=sum(alpha_k*Pi_k),
qvMix=sum(m_k*q_k). Here Gamma_k=1/(physical gamma_k-1) for SG;
Pi_k=physical gamma_k*pInf_k/(physical gamma_k-1). `f_pressure` inverts this
affine relation. Density-dependent coefficients also exist in this snapshot.
The chemistry branch instead recovers gas temperature/pressure through chemistry
helpers. None is a replacement for arbitrary JANAF gas + real-liquid recovery.
No transformed SG parameter set is adopted by this project.

## Allaire and Kapila source implementation

Without alt_soundspeed the Kterm construction/correction is skipped. Standard
velocity-interface paths implement alpha-flux divergence plus cell alpha times
the divergence of the shared Riemann velocity. HLL Method 1 instead uses an
alpha-interface trace for u_cell*grad(alpha), together with its numerical flux
regularization. Both follow the nonconservative material equation; neither is
incompressible VOF conservation of alpha.

For nonelastic two-fluid flow set B_i=rho_i*c_i^2. MFC calculates

    K1 = alpha1*alpha2*(B2-B1)/(alpha1*B2+alpha2*B1).

This is equivalent to (B2-B1)/(B1/alpha1+B2/alpha2) away from endpoints.
The RHS adds +K1*div(u_iface) to fluid 1 and -K1*div(u_iface) to fluid 2.
Use the nonsingular product form and explicit pure-phase branches, not the
endpoint division form. For finite positive B_i, K->0 at either pure limit,
and K=0 when B1=B2. Hypoelastic branches add shear contributions; those are
out of this project's gas/liquid scope.

Mapping **fluid1=L, fluid2=G** gives the project's positive-alphaL-source K_L.
Swapping labels changes its sign. Wood bulk modulus B_W satisfies
1/B_W=alphaL/B_L+alphaG/B_G; K_L=alphaL*(B_W/B_L-1).
The K term and Wood acoustics are a matched relaxation closure.

Actual validator: model_eqns=2, exactly two fluids, avg_state=2, no Eulerian
bubbles, solver in HLL/HLLC/HLLD; HLLD additionally requires hypoelasticity,
with stated cylindrical HLL restrictions. Thus describing this commit as
"HLL/HLLC only" would be inaccurate. All these solver implementations remain
excluded from direct port. HLL Method 1 exports alpha traces and a separate
velocity channel for K; HLLC/HLL Method 2 export shared velocity. Hypo HLLD
handles NC terms inside its solver. A KT scheme must derive its own matched
alpha/source discretization; copying only the cell K source is prohibited.

## Acoustics findings and limits of borrowing

`s_compute_speed_of_sound` uses harmonic bulk-modulus mixing for alt_soundspeed.
The ordinary constant-coefficient five-equation branch uses the effective
mixture-coefficient bulk modulus divided by rho. For SG this matches the
Allaire isobaric acoustic relation. The state-dependent-EOS/non-alt branch in
this snapshot uses sum(alpha_i*B_i)/rho. That arithmetic branch is **not a
general derivation of this project's arbitrary-EOS Allaire eigenvalue**.
Project acoustics must use the independently derived caloric-derivative formula
in FIVE_EQ_ACOUSTICS.md. Averaged Riemann-state enthalpy branches likewise are
solver-specific and do not define project cell/face thermodynamics.

## Safeguards: source differs from idealized option descriptions

Actual mpp_lim conversion kernels clamp negative partial densities to zero,
clip alpha to [0,1] and normalize its sum with a denominator floor. Phase
coefficient evaluation floors both alpha and partial density before division.
With mixture_err enabled, a negative computed c-squared candidate is replaced
by a small positive speed rather than producing a root failure. These are
actual behaviors, not proofs of conservation or general EOS admissibility.
Borrow the detection goals only. The project forbids silent thermodynamic
clipping, acoustic replacement and unaccounted conservative correction.

## THINC/MTHINC

int_comp=1/2 applies tanh-profile reconstruction after WENO/MUSCL. Source
adjusts reconstructed alpha1, alpha2=1-alpha1 and both partial densities using
cell intrinsic densities. Pressure and velocity remain primitive reconstruction
inputs for subsequent flux/energy construction. This is not an additional
OpenFOAM cAlpha PDE flux. The validator rejects six-equation THINC because
per-phase energies would be left inconsistent. No implementation is copied.

## Audit conclusion

State organization, EOS separation and safeguard concepts are useful references.
Acoustic closure, alpha nonconservative products and contact preservation must
be derived for the selected PDE and project KT states. M5B.1 closes a **design
contract**, not a discrete contact-preservation proof or runtime validation.
