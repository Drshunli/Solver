# M5C.2B：Foundation OF7 旧重构审计

审计本机 `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7`；没有使用 OpenFOAM.com API。

## 实际调用链

| 位置 | 调用 | 实际作用 |
|---|---|---|
| rhosprayVoFDPMFoam.C:143–154 | interpolate(rho,pos/neg); interpolate(rhoU,pos/neg,U.name()); interpolate(rPsi/e,pos/neg,T.name()) | rho 独立 Minmod；rhoU 独立 MinmodV；rPsi、e 独立 Minmod |
| rhosprayVoFDPMFoam.C:156–159 | U_face=rhoU_face/rho_face; p_face=rho_face*rPsi_face | 不对独立重构后的状态重新作 EOS 恢复 |
| rhosprayVoFDPMFoam.C:174–175 | interpolate(c,pos/neg,T.name()) | c=sqrt((Cp/Cv)/psi) 在 cell 计算，再独立 Minmod |
| directionInterpolate.H | fvc::interpolate(vf,dir,"reconstruct(name)") | pos/neg 是方向；U/T 是 scheme lookup alias |
| rhoYEqn.H:8 | mesh.divScheme("div(phi,Yi_h)") | 真正的 species convection lookup |
| createFields.H:177–179 | field table = all Y + thermo.he() | 多变量 vanLeer 的共享最小 limiter 包括能量字段 |

`300_2D/system/fvSchemes:55–58` 是 Minmod/MinmodV/Minmod/Minmod。
`:38` 的 `div(phi,Yi_h) Gauss vanLeer` 才被当前物种方程使用。
`:35–37` 单物种 `vanLeer01` 和 `reconstruct(Yi)` 在这条实际物种调用链没有被调用。
旧 solver 没有独立的 KT species face-flux branch。比较器使用旧 KT mass flux × 实际 multivariate vanLeer Yi。

## OF7 模板及边界

读取 finiteVolume/interpolation/surfaceInterpolation 下的 Minmod/Minmod.H/.C、
LimitedScheme/NVDTVD.H、NVDVTVDV.H、LimitedScheme.H/.C、LimitFuncs.C、
limitedSurfaceInterpolationScheme、vanLeer/vanLeer.H/.C、
multivariateSchemes/vanLeer/multivariateVanLeer.C、multivariateScheme/multivariateScheme.C、
multivariateSurfaceInterpolationScheme.H/.C、surfaceInterpolationScheme.C。

标量 Minmod 使用 MinmodLimiter<NVDTVD>；magSqr<scalar> specialization 返回标量本身。
向量 MinmodV 使用 MinmodLimiter<NVDVTVDV> 和 null 映射。
标量 r=2(d·grad_up)/(phi_N−phi_P)−1；向量使用 Δv·(d·grad_up)/|Δv|²。
模板包括 OF7 1000 倍 guard；limiter=max(0,min(1,r))；权重=limiter*wCD+(1−limiter)*pos0(dir)。
vanLeer=(r+|r|)/(1+|r|)，multivariate 对所有 Yi 和 he 取最小 limiter。

内部面使用 C_N−C_P、mesh weights、Gauss-linear gradient；耦合边界使用 patch neighbour
values/gradients 和 patch.delta；非耦合边界插值直接使用 volume patch field 的边界值。
本轮真实 fvMesh 测试覆盖内部面和非耦合 zeroGradient；耦合/MPI/nonorthogonal 边界只有源码审计，
没有宣称完成运行验证，归属未来边界准备阶段。

## 真实 API 验证

独立 `tests/fiveEqOF7Interpolation` 直接构造八单元几何 fixture 和 fvMesh；不调用 blockMesh/checkMesh，
不推进 time loop，不运行 CFD。调用真实 Foam::interpolate/fvc::interpolate 和
multivariateSurfaceInterpolationScheme::New。

428 checks，0 failures；标量/向量适配器最大差异分别 4.44e−16 / 6.66e−16。
包含真实 rho/rhoU/rPsi/e/c cell→face→legacyKT 和实际 MaterialCell 面重构→recoverFaceState→新 KT。
气相使用当前 thermal.dat 的 OF7 JANAF，air 和 2% gaseous C10H22。
真实 API 输出 `fitting/reconstruction/m5c2b_v1/actual_fvc_gas_chain.csv`。
完整组合扩展到不同 p/T/U、组成、方向、ALE 及 Kurganov/Tadmor 共 5832 候选比较行。
这些扩展采用已被真实 API 验证的均匀正交一维 limiter 适配器；不冒充任意三维网格验证。

## 阶数与限制

平滑非极值附近，Gauss-linear gradient + Minmod 在一致的均匀网格上给出二阶面状态。
非线性变量变换与独立插值不对易：R1/R2 与 legacy 的非均匀面状态/通量差异允许存在。
Minmod 在极值、间断和 admissibility 限幅处可退化；本轮 Euler 更新只是一阶时间。
`final_faces/formal_order.csv` 在 N=20/40/80/160/320 给出实际 EOS 恢复的面误差；
R1 的 Et 与 R2 的 U 近似二阶。特定样本 R2 p 接近三阶只是局部超收敛，不能推广。

多步 N=20/60/200 是 unit-volume periodic stencil（V=1，Sf=1，长度 N），
用于更新合法性/守恒；不是同物理长度的 CFD 网格收敛测试。
