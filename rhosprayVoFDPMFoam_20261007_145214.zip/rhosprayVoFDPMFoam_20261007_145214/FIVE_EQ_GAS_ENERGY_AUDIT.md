# M6A2.1 gas energy audit — actual Foundation OF7

## Actual case and active solver

Audited 300_2D/constant/thermophysicalProperties: hePsiThermo, reactingMixture,
sutherland, janaf, sensibleInternalEnergy, perfectGas, specie; foamChemistryReader
loads thermal.dat and reactions. Actual reactions species order is C10H22,O2,N2;
API YG uses that order. Air is [0,0.228,0.772]. These are frozen-composition
thermodynamic queries, not equilibrium/reaction predictions.

createFields.H binds e=thermo.he() and initializes rhoE=rho*(e+0.5*|U|^2).
rhoEEqn.H restores e=rhoE/rho-0.5*|U|^2, calls thermo.correct(), and updates
p=rho/psi. The active solver calculates cc=sqrt((Cp/Cv)/psi).

## Exact local source references

Foundation source root /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7:

* src/thermophysicalModels/specie/thermo/sensibleInternalEnergy/sensibleInternalEnergy.H:
  HE dispatches Es, Cpv dispatches Cv, THE dispatches TEs.
* src/thermophysicalModels/specie/thermo/thermo/HtoEthermo.H:
  Cv=Cp-CpMCv; Es=Hs-p/rho; Ea=Ha-p/rho.
* src/thermophysicalModels/specie/thermo/janaf/janafThermoI.H:
  Hs=Ha-Hc; Hc evaluates the low JANAF enthalpy polynomial at Tstd;
  low coefficients apply T<Tcommon, high coefficients at T>=Tcommon.
* janafThermo.C converts dimensionless coefficients to mass basis using specie R.
* src/thermophysicalModels/specie/equationOfState/perfectGas/perfectGasI.H:
  rho=p/(R*T), psi=1/(R*T), CpMCv=R.
* src/thermophysicalModels/reactionThermo/mixtures/multiComponentMixture/multiComponentMixture.C:
  cellMixture=sum(Y_i*speciesData_i); standalone uses identical value operations
  on a local object, avoiding the global mutable mixture_ and fields.

## Convention and derivatives

Rmix=sum(Y_i*R_i), Cp=sum(Y_i*Cp_i), Cv=Cp-Rmix;
eG=Es=Ha-Hc-Rmix*T. No arbitrary gas offset is introduced. Hs is zero at
Tstd for this convention; Es there is -Rmix*Tstd, not zero. Formation/reference
enthalpy is removed in sensible energy; reaction Qdot remains owned by existing
solver code and is untouched.

T=p/(rho*Rmix); betaG=Cv/(rho*Rmix) at fixed rho,Y;
cG^2=gamma/psi=(Cp/Cv)*p/rho, matching the active cc formula.
Fixed-composition dp/drho|e=p/rho. Cv is temperature dependent.

The actual species dictionaries give 100<=T<=6000 K and Tcommon=1000 K.
The evaluator rejects outside states before querying thermo; it never calls the
OF7 temperature limiter. Pure-gas inversion explicitly splits the two JANAF
branches and rejects energy gaps. Existing coefficient discontinuities are not
smoothed or refitted. Mixed states at 999/1000/1001 K are tested.

## Numerical cross-check scope

220 matching PT/composition queries compare local OF7 mixture HE/Cp/R/c with
independent OF7 per-species Es/Cp/R mass sums. Four compositions include air,
1% fuel vapor, pure nitrogen and pure oxygen; eleven temperatures cover validity
edges and JANAF branch; five pressures span 0.05 to12 MPa. No mesh or
psiReactionThermo field is constructed. This verifies the same OF7 mathematical
mixture and energy type, not a separately run CFD case.
