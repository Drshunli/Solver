# KH child support reachability v1

M8A.3B-T3B-R2C-K1 contract closure, 2026-10-04.

## Scope and authority

This round's explicit user request authorizes replacing the immediate birth-space invalidity requirement when the birth and generic-path proofs pass. Previous K1 documents/evidence are preserved. Current certificate applies only to the frozen passive serial selected `r2::BoundCloud` graph, Foundation OF7 GCC11.4 C++11 DPInt32 x86-64, fixed mesh, All=255, scalar-cell/U-cellPoint interpolation. No active solver capability is activated.

## Actual source chain

Installed Foundation source was reread and fingerprinted in `fitting/dpm/m8a3b_t3br2c_k1_closure_v1/native_source_audit.txt`:

1. Native `SprayParcel.C:286–311`: copy construct from parent, allocate origId, compute child properties/history/dispersion, add to cloud. No child coordinate/cell/tet relocation.
2. Frozen local `tests/fiveEqDPMParcelC2/parcel/LazySprayParcel.C:290–322`: unique_ptr copy construction, distinct ID, invalidate session, independent child preflight before native carrier-dependent force/dispersion calls, adoption, invalidate/revalidate parent.
3. Frozen provider: all physical contributor checks depend on the actual current tet, barycentric coordinates and fixed support map; profile must equal All. The child diameter, ID and KH history do not select alternative physical support contributors.
4. Frozen `LazyKinematicParcel.C:41–69`: preflight before rho/U/mu interpolation. `:328–355`: native trackToFace, invalidate, setCellValues, dispersion, correction, calc. `:390`: invalidate after rebound.
5. Installed `Cloud.C:203–210`: generic iteration calls `p.move(cloud,td,trackTime)` for every cloud-owned parcel; no KH-child dispatcher.

Search artifacts: `local_KH_query_search.txt`, `provider_predicate_search.txt`, `session_search.txt`, `generic_path_search.txt`, `native_generic_cloud_move.txt`, `native_KH_model_search.txt`. ReitzKHRT's breakup calculation changes native breakup state and returns addParcel; it neither installs a carrier-support predicate nor selects a child-only interpolation stencil. There is no extra child requirement expansion in this graph.

## Spatial reachability proof

Define spatial admissibility F(S,G,R,M), where S includes position, cell, face, tet and barycentric coordinates; G is carrier generation, R the required property mask and M the fixed GasSupportMap/stencil rules.

At the child's first query:

S_child=S_parent, G_child=G_parent, R_child=R_parent=255, and M is unchanged.

Actual source does not contain a physical child-specific support rule. Therefore:

F(S_child,G_child,R_child,M)=F(S_parent,G_parent,R_parent,M).

A spatially valid parent implies a spatially valid newborn at that identical pose. Making it spatial-invalid would require changing an assumption, which this round prohibits.

**This proof concerns spatial admissibility only. It does not imply that a parent identity token can authorize the child.**

## Separate authority and independent validation

The actual authority key consists of object address, origProc/origId, pose/tet/coordinates, generation and requirements. `NativePose::same` includes identity and IDs as well as spatial fields. Session invalidation occurs before child preflight. The child's identity mismatch also prevents a parent cache hit.

The provider's old parent authority rejects the child in the isolated `IDENTITY_REVALIDATION_TEST` without evaluating properties. Then the real child's independent preflight succeeds. This round recorded 92 such birth transitions and 5,694 subsequent child queries. Parent and child keys are exported to `support_authority_keys.json`, derived from actual records, not fabricated opaque token values or persisted certificates.

The provider's historical `TEST_ONLY_KH_CHILD_SUPPORT_REJECT` hook is explicitly a test-only exception after physical support checks. It is not a hidden physical support predicate. This round replays it separately with parent107/child108 to certify child cleanup and whole-trial retry. It is never counted as real spatial invalidity.

## Ownership and post-adoption proof

Before adoption the newborn is uniquely held by childOwner. If independent query/model work throws, local destruction releases it. At adoption `cloud.addParticle(childOwner.release())` transfers ownership; no surviving local second owner remains.

After adoption the child has the same parcel class and generic movement method as any existing parcel. The shared session's authority still includes that individual identity. Position/cell/tet movement, rebound, and carrier-generation changes invalidate authority, followed by preflight before materialization/model update. No separate untested KH carrier-query path was found.

Fresh generic strict-stencil crossing and pure-liquid owner query PASS, with zero rho/T/Y/Cp/mu/kappa increments after failure. Pure owner evidence is native geometric `particle::track` followed by actual query; it is not a full kinetic trajectory through the earlier invalid strict stencil. Fresh R2B support-first and I1 ownership/retry subsets PASS.

## Optional real post-birth crossing

Not rerun this round. No child/support/Q/geometry/requirements changes and no large-dt manufacture were performed. Previous K1's frozen mixed/pure fixture attempt rejected the parent first, so it did not certify child-first spatial failure. That result remains historical fixture evidence, not a proof of universal post-adoption unreachability and not a production time-step recommendation.

The optional real child crossing is **NOT CERTIFIED**. K1 completion relies on the explicitly authorized generic-path proof, not on treating the optional test as a spatial PASS.

## Revised acceptance contract

Retired: the child first query must encounter real spatial-invalid support at its parent's identical valid birth pose.

Required:

- Independent child identity/support validation at birth.
- Parent authority cannot authorize the child.
- The identical valid birth pose remains physically valid.
- Every later adopted-child query follows the generic runtime support/reject contract.
- Generation validation, support-first ordering, no fake gas/masked stencil, no thermo after invalid support, unique ownership, whole-trial reject/rollback, allocator/RNG/source/output restoration remain mandatory.

K1 COMPLETE. R2C COMPLETE only after the explicit 30-row completion audit in `R2C_COMPLETION_CHECKLIST.json`; all rows PASS, no OPEN. Capability label `FULL-SERIAL-TRANSACTION-SAFE` is limited to this audited passive serial graph. ORourke additionally retains `NATIVE-PHYSICS-LIMITATION`, never FULL-CONSERVATION-SAFE. C2 semantic-noncanonical contract unchanged; production restart remains NOT CERTIFIED.

R2-FINAL MAY START NEXT ROUND ONLY. This round stops here: no R2-FINAL/T4/M6B/CFD.
