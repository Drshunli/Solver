# M6B.1-SR1-SERIAL — first rejection / dt collapse diagnosis

## 1. SR1 status

**COMPLETE / DIAGNOSIS ONLY. CLASS F — MIXED_CAUSE。** 首次拒绝、两级热力学步长坍缩、继承与首次时间不前进已复现。未修复；M6B.1 仍 PARTIAL / STOP。封存日期2026-10-05。

## 2. Reproduction

shockInterface_100 的 constant/system（含 polyMesh、fiveEqInitialState）17个文件 SHA逐项一致，无 blockMesh/初态再生成，无 dt/endTime/mesh/EOS修改。隔离的 actual rhosprayVoFDPMFoam -serialFiveEq 复现138步的 time/dt与原记录逐文本一致；step0–137全部 published history列逐文本一致。诊断在 step138首次 tNew==tOld 时停止（exit1，SR1_DIAGNOSTIC_STOP_FIRST_TIME_NONPROGRESS），不是模型失败正常退出，也不是timeout。

初次观察代码 t=0 的 dt/ULP 比值溢出退出136，保留 observer_startup_attempt；只读比值安全处理后 first_reproduction与最终版本重复 time/dt链一致。没有降低CFL或改变计算。

## 3. First rejection step/time

anchor accepted step105，t=0.00012653467410184976 s；试图生成 step106，retry index0，dt=1.2050921343033288e−6 s；cell24（x=.245 m）。明确区别 anchor105 与待接受106。

## 4. First rejection reason

`NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN`。失败属于冻结 common-pressure EOS domain/energy feasibility gate；不是 generic candidate rejected。6次 main trial拒绝、178次 connectedDt探测拒绝均为同一显式理由（rejections.csv、connected_probe_rejections.csv）。探测拒绝不混算成主重试次数。

## 5. Source line/function

原始 fiveEqPrecision/fiveEqPrecisionRecovery.C:77，fiveEqPrecisionRecovery::recover：先计算共同压力区间两端残差，再要求左负右正（或端点达到etol）；未通过即 throw。调用路径 PrecisionOperator::recover（fiveEqPrecisionOperator.C:10）→ R1 → temporal driver catch（fiveEqTemporalContract.H:22）。原始逐行源码/SHA保存在 original_source_origins.json；仪器化副本行号与原始不同。

## 6. Committed pre-state

A snapshot 与 first_committed_Q.csv 保存100cell精确Q/P2；cell24 mG+mL=13.875969061392656 kg/m³，rhoL=712.56436033391867，Eint=4328691.1442294298 J/m³，recovery PASS，p=3275261.4520430616 Pa，TG=818.51203634796775 K，TL=319.81048481444691 K。共同区间[400148.23320822552,3437486.2749781469] Pa，两端 f=[-7465516.2245068364,465419.11099100113]，存在能量根。

## 7. Candidate failed state

first_candidate.csv 保存失败cell24：P2/alphaL=9.0196079636474302e−22，mG=13.869723487241057，mL=6.4254079426687836e−19 kg/m³；rhoL=mL/alphaL=712.38217542998609 kg/m³；Mx=502.43311081912702，Et=4334379.6557239667，Eint=4325279.2929416951 J/m³。common bracket [399968.12647470122,3232891.4142302852] Pa，fLo=-7460692.4881426226、fHi=-114938.15962614212 J/m³，均负。

端点不是candidate成功recovery温度：hi端 TG=808.28726096872424 K、TL=319.9999999999996 K（液体HARD上限320 K）；hi导数=2.8416993261766188>0。能量不足以在现有区间内达到目标Et。气体单独诊断压力=3273273.8951882566 Pa>hi，仅为比较，未删除trace/修复candidate。失败量是能量残差的符号/域，不是质量负值。

## 8. R1 involvement

实际进入 R1，recoveryMode MIXED，iterations=0：在Newton/bisection loop之前的端点检验失败。初始bracket、两端 residual与derivative由实时 progress 和独立 frozen query重现；不是100次不收敛。tiny liquid仍TRACE_PRESENT，不能强制标ABSENT；无 root tolerance 修改。

## 9. First retry sequence

step105/attempt0：1.2050921343033288e−6拒绝→connectedDt=9.1990382482555322e−7→attempt1接受step106。下一 anchor106/attempt0：9.1990382482555322e−7拒绝→connectedDt=1.9939191782118543e−18→attempt1接受step107。后续详表第16节；每一episode仅1主拒绝、下一候选通过。

## 10. Retry reduction rule

保持原算法：next=bound；逐cell next=min(next,connectedDt(anchor,V,bound,L,R))；若next>=dt才 next=.5*dt。实际6个episodes均 connectedDt<dt，未用half fallback。connectedDt先合法检查x=0，再32点前缀扫描及52步二分合法性边界；probe reason已逐次记录。每次重新用const anchor构建trial，无持久candidate更新作为retry anchor的证据。

## 11. Accepted dt

首重试接受dt=9.1990382482555322e−7；随后几乎立即降至1.9939191782118543e−18。dt_history.csv 与原dynamic_history的138步dt一致。最后诊断driver构造的 accepted candidate dt=5.5711770891448054e−22；此时原driver已经更新local candidate，但观察器终止，未让该步再进入active adapter commit/publish。原M6B.1确实commit了此步并继续无进展。

## 12. Next-step initial dt

runSerialFiveEq.C:121–127：request=min(Time::deltaTValue,endTime−currentTime)；成功后 Time::setDeltaT(step.dt)。time_seed.csv实际读取表明 accepted106的dt成为anchor106下一 request，直到最终step138亦然。connected bound减少的接受dt永久继承，没有独立较大 proposal。

## 13. Fresh joint bound

重试链期间 fresh joint bound约1.2050921353e−6 s，cell82/acoustic。A/B/C只读重构、face recovery、wave、jointBound全部重算，100cell完整；无trial/advance。fresh jointBound为线性通量/质量/P2/CFL上限，不等于common EOS能量域边界，不能据大joint bound断言connectedDt错误。

## 14. connectedDt

首episode≈9.199e−7，第二episode≈1.994e−18，随后3.192e−19、7.967e−20、1.727e−20、5.571e−22。connected_bounds.csv分cell记录，拒绝探测有明确EOS无根理由。极小connectedDt不是CFL cap，而是当前trace state已逼近HARD TL=320 K能量域边界与离散trial/二分合法判断的结果；没有独立证明connected算法计算bug。

## 15. Acoustic/local bounds

first_faces.csv记录100面waves与phase/momentum/energyflux、joint/acoustic；first_reconstructed_Q.csv保存200个side的Q/P2，first_face_primitives.csv离线重现side pressure/velocity/rho/T/c（face i对应side2i和side2(i+1)+1周期映射）。A/B/C.bounds.csv给出P2 alpha、两相质量、物种、acoustic与joint各项。未额外加入安全系数或阈值。

## 16. dt history

| Accepted step | incoming/first dt | accepted dt | retries | fresh joint |
|---|---:|---:|---:|---:|
| 105 | 1.2050921343033288e-06 | 1.2050921343033288e-06 | 0 | 1.2050921351301712e-06 |
| 106 | 1.2050921343033288e-06 | 9.1990382482555322e-07 | 1 | 1.2050921352255571e-06 |
| 107 | 9.1990382482555322e-07 | 1.9939191782118543e-18 | 1 | 1.2050921353055126e-06 |
| 108 | 1.9939191782118543e-18 | 3.1922844720811036e-19 | 1 | 1.2050921353055126e-06 |
| 109 | 3.1922844720811036e-19 | 7.966783237478011e-20 | 1 | 1.2050921353055126e-06 |
| 110 | 7.966783237478011e-20 | 7.966783237478011e-20 | 0 | 1.2050921353055126e-06 |
| 132 | 7.966783237478011e-20 | 7.966783237478011e-20 | 0 | 1.2050921353055126e-06 |
| 133 | 7.966783237478011e-20 | 1.7270648976349179e-20 | 1 | 1.2050921353055126e-06 |
| 137 | 1.7270648976349179e-20 | 1.7270648976349179e-20 | 0 | 1.2050921353055126e-06 |
| 138 | 1.7270648976349179e-20 | 5.5711770891448054e-22 | 1 | 1.2050921353055126e-06 |

完整138行dt_history.csv记录old/new时间、first/accepted/minretry dt、retries、fresh/connected/acoustic bounds、limitingcell、ULP及timeProgress；无retry时connectedDt=nan（未调用，不伪造为joint）。原Time读取另有time_seed.csv。

## 17. First severe shrink

相对初始dt首次10倍下降、首次dt<1e−12和<1e−16，均在 accepted step107：dt=1.9939191782118543e−18 s。主要坍缩是106→107约4.61e11倍，不是数千个half-retry累积；之后长期继承并夹杂热力学合法性拒绝。

## 18. First dt < time ULP

accepted133：dt=1.7270648976349179e−20，ULP=2.7105054312137611e−20，比值.6371744833。仍可因round-to-nearest增加一个ULP；dt<ULP本身不必等于无进展。

## 19. Time non-progress point

首次 accepted candidate138：old/new t=0.00012745457792667973 s，dt=5.5711770891448054e−22，dt/ULP=.02055401559，tOld+dt==tOld。该诊断前原生策略没有对representable time increment作检查；立即只读snapshot C后STOP，不继续3000次拒绝。

## 20. State positivity

首次前后mG、mL非负，rhoMix>0，Et/Eint有限；committed primitive p/T合法。failed candidate尚未recover成功，不能把端点p/T写成它的正式primitive。正质量/有限能量不意味着共同EOS能量根存在；此处总体热力学admissibility不成立，排除“物理可接受但R1算法失败”的CLASS B。

## 21. Species/P2 validity

candidate物种质量residual=-1.7763568394002505e-15 kg/m³，相对约1.28e−16，在冻结阈值内；P2+9.0196e−22合法，trace质量保留，不normalize、不clip、不删除trace。真实拒绝不是species/P2。accepted step0–137与旧诊断各列完全一致，C138另有完整100cell。

## 22. Shock/interface separation

A状态采用cell-centre线性等值点读数：右行shock p=3.15 MPa（x∈[.4,.6]）x=0.47415712459343445 m；material alphaL=.5（x∈[.6,.7]）x=0.64934812172462197 m；间距=0.17519099713118752 m，约17.5个Δx。是网格诊断估计，不是精确shock定位。首次失败cell24 x=.245远离右行shock/interface相遇处；明确 BEFORE interaction。周期域还存在返回材料边界及另一Riemann波，不能宣称单孤立shock无限域。

## 23. Classification A–G

**CLASS F / MIXED_CAUSE**：A成分：首次trial的trace-liquid intrinsic rho与共同能量要求在冻结EOS HARD区间内无根；C成分：thermodynamic retry接受的极小dt成为后续起始dt且无增长途径；最后是未检查representable-time的浮点停滞后果。

不优先纯CLASS C：本案有独立、很大的首次域残差，以及第二次真实connected-bound坍缩。非CLASS B的合法root求解失败；非已证明CLASS D；非“dt仍合理”的纯CLASS E；也不把现象称为已验证的shock/interface物理不稳定。

## 24. Whether core mathematics implicated

冻结共同pressure energy feasibility数学与HARD domain确实参与拒绝。证据证明给定candidate无合法区间内根，不证明R1公式有bug；trace运输/单总能量与EOS HARD热力学闭合的兼容性需另轮审查。不得以删trace、扩大EOS域或改energy tolerance在本轮修复。

## 25. Whether temporal-driver policy implicated

是：请求上一步accepted dt且bound=min(requested,localBounds)，无growth；connectedDt异常微小可直接commit；s.time+=dt没有timeProgress guard。policy影响明确，但单独把dt_next设为freshJoint会重新生成EOS-invalid trial，不是充分修复。retry anchor始终const committed，未发现retry-state mutation。

## 26. Any source changes

现有active/frozen源文件、Make、二进制均未改。独立 diagnostic_solver副本仅增加 observer读数：temporalContract、PrecisionOperator探测异常输出、recoveryObservation progress、runSerialFiveEq Time seed与隔离EXE路径。SR1Observation.H新建，observer_only.patch详列。原KT/R1/P2/reconstruction/thermo/formulas逐源SHA/副本比对。新增tests/fiveEqSR1Query仅离线读取，不进入runtime。编译PASS；observer初始overflow/接口参数编译尝试保留，不隐瞒为模型故障。

## 27. Foundation hashes

fresh本机 Foundation6717 PASS、nativeparcel19 PASS，完整逐文件日志；55链接库SHA保留。未混用.com，也未修改FOAM_SRC。

## 28. Project hashes

33892个封存基线文件全部SHA一致（授权status append之前）；17case输入一致；现安装active binary SHA仍 ebb2a5e1f59a3431bea8795098b9a6c190b30b7cdd4dedc57cca9b78cdc05f87。独立诊断exe SHA见executable.sha256；原M6B.0/M6B.1 checkpoint未改；isolated source manifests与observer patch保留。

## 29. SR1 COMPLETE?

是，**COMPLETE / DIAGNOSIS ONLY**：复现、第一拒绝reason与origin、失败Q/P2、前state/facewave/bounds、R1端点、完整首retry、actualTime继承、collapse阈值、ULP与首次停滞、A/B/C replay、物理/EOS可容许性与interaction时序、CLASS F、冻结/无repair全部闭合。这不提高M6B.1或production认证级别。

## 30. Next permitted action

本轮STOP。下一轮应单独授权repair/design gate，先处理common EOS admissibility/trace候选失配的原因，再设计可终止的temporal policy。建议审查位置：PrecisionOperator::trial/connectedDt；fiveEqTemporalDriver::advance的bound/retry/commit；runSerialFiveEq.C:121/127 dt继承。数学理由：linear joint上限不能替代EOS energy可容许性；time更新必须可表示且可进展；dt增长应在合法候选与守恒事务下定义。不得径直用freshJoint重置dt，更不能在本轮扩大domain/改P2/tolerance。未实现修复，M6B.2仍无前置证书。

## 31. M6B.1 status

仍 **PARTIAL / STOP**。原blocker已诊断细分为EOS candidate feasibility + temporal inheritance/nonprogress；不得将SR1完成当作M6B.1 COMPLETE。其余网格、RH、高速、Galilean gates均未执行/未认证。

## 32. Milestone matrix

| Milestone | Status |
|---|---|
| M6B.0 | COMPLETE / FROZEN |
| M6B.1-SR1 | COMPLETE / DIAGNOSIS ONLY |
| M6B.1 / M6B overall | PARTIAL / STOP |
| T4-S1 / T4-S2 | COMPLETE / FROZEN |
| T4-S3 | DEFERRED / NOT CERTIFIED / NOT EXECUTED |
| T4 / M8A | PARTIAL |
| M6B.2 / active DPM / production CFD / restart | NOT EXECUTED / NOT CERTIFIED |

**STOP — NO REPAIR APPLIED.**
