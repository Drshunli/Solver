#include "runSerialFiveEq.H"
#include "fiveEqCRV3Temporal.H"
#include "fiveEqInitialStateBuilder.H"
#include "recoveryObservation.H"
#include "dynamicObservation.H"
#include "fiveEqScaledP2IO.H"
#include "fiveEqScaledExport.H"
#include "fiveEqAuthorityLedger.H"
#include "cyclicFvPatch.H"
#include <algorithm>
#include <numeric>
#include <fstream>
#include <iomanip>
using namespace Foam;
using namespace fiveEq;
namespace {
void require(bool ok,const char* why){if(!ok)throw RecoveryError(why);}
std::array<long double,9> integrals(const TemporalState& s){
 std::array<long double,9> z{};for(unsigned i=0;i<s.committed.size();++i)for(unsigned j=1;j<10;++j)z[j-1]+=static_cast<long double>(s.volume[i])*s.committed[i].q[j];return z;
}
}
int runSerialFiveEq(Time& runTime,fvMesh& mesh){
 try{
 require(!Pstream::parRun(),"M6B0_SERIAL_ONLY");
 require(!mesh.moving()&&!mesh.topoChanging(),"M6B0_FIXED_MESH_ONLY");
 require(runTime.value()==0,"M6B0_FRESH_START_ONLY_NO_ALPHA_RESTART");
 IOdictionary cfg(IOobject("fiveEqBootstrap",runTime.constant(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE));
 require(readBool(cfg.lookup("verificationOnly")),"M6B0_VERIFICATION_ONLY");
 require(!readBool(cfg.lookup("DPM"))&&!readBool(cfg.lookup("surfaceTension")),"M6B0_EULERIAN_ONLY");
 const word mechanicalModel=cfg.lookupOrDefault<word>("mechanicalModel","HISTORICAL_K0");
 require(mechanicalModel=="HISTORICAL_K0"||mechanicalModel=="NONZERO_K_PE_v1"||mechanicalModel=="NONZERO_K_PE_CRV3_v1","UNKNOWN_MECHANICAL_MODEL");
 const auto model=mechanicalModel=="NONZERO_K_PE_CRV3_v1"?MechanicalModel::NONZERO_K_PE_CRV3_v1:mechanicalModel=="NONZERO_K_PE_v1"?MechanicalModel::NONZERO_K_PE_v1:MechanicalModel::HISTORICAL_K0;
 const word representationModel=cfg.lookupOrDefault<word>("representationModel","P2_V1");require(representationModel=="P2_V1"||representationModel=="P2_SCALED_V2","UNKNOWN_REPRESENTATION_MODEL");const bool scaledRepresentation=representationModel=="P2_SCALED_V2";if(scaledRepresentation)require(model==MechanicalModel::NONZERO_K_PE_CRV3_v1,"SCALED_V2_CRV3_STRATEGY0_ONLY");
 if(model==MechanicalModel::HISTORICAL_K0)require(readLabel(cfg.lookup("K"))==0,"M6B0_K_ZERO_ONLY");
 else require(!cfg.found("K"),"MC4_MODEL_FORMULA_NOT_CONFIGURABLE");
 Info<<"mechanicalModel="<<modelTag(model)<<" production restart NOT CERTIFIED"<<nl;
 const double crv3Mu=model==MechanicalModel::NONZERO_K_PE_CRV3_v1?readScalar(cfg.lookup("CRV3mu")):0;
 require(crv3Mu>=0&&std::isfinite(crv3Mu),"CRV3_INVALID_VISCOSITY");
 const label N=mesh.nCells();require(N>=4,"M6B0_TOO_FEW_CELLS");
 // Frozen operator has unit x-normal faces and a periodic one-dimensional stencil.
 // Certify geometry before using that reduction: unit area, contiguous equal slabs,
 // precisely two cyclic axial faces, transverse empty faces; no inferred topology.
 std::vector<label> ids(N);std::iota(ids.begin(),ids.end(),0);
 std::sort(ids.begin(),ids.end(),[&](label i,label j){return mesh.C()[i].x()<mesh.C()[j].x();});
 std::vector<label> order(N);for(label i=0;i<N;++i)order[ids[i]]=i;
 const double dx=mesh.C()[ids[1]].x()-mesh.C()[ids[0]].x();require(dx>0,"M6B0_BAD_DX");
 for(label i=0;i<N;++i){require(std::abs(mesh.V()[ids[i]]/dx-1)<1e-12,"M6B0_UNIT_AREA_REQUIRED");
  if(i)require(std::abs((mesh.C()[ids[i]].x()-mesh.C()[ids[i-1]].x())/dx-1)<1e-12,"M6B0_UNIFORM_RING_REQUIRED");}
 require(mesh.nInternalFaces()==N-1,"M6B0_NOT_A_1D_CHAIN");
 for(label f=0;f<mesh.nInternalFaces();++f){auto sf=mesh.Sf()[f];require(std::abs(std::abs(sf.x())-1)<1e-12&&mag(vector(0,sf.y(),sf.z()))<1e-12,"M6B0_BAD_AXIAL_FACE");
  label o=order[mesh.owner()[f]],n=order[mesh.neighbour()[f]];require(std::abs(o-n)==1,"M6B0_BAD_CHAIN_CONNECTIVITY");}
 label cyclicFaces=0;wordList patchTypes(mesh.boundary().size());
 forAll(mesh.boundary(),pi){const auto& patch=mesh.boundary()[pi];patchTypes[pi]=patch.type();
  require(patch.type()=="cyclic"||patch.type()=="empty","M6B0_BOUNDARY_NOT_CERTIFIED");
  if(patch.type()=="cyclic"){
   require(patch.size()==1,"M6B0_CYCLIC_PAIR_REQUIRED");const auto& cp=refCast<const cyclicFvPatch>(patch);
   require(cp.neighbFvPatch().size()==1,"M6B0_CYCLIC_NEIGHBOUR_REQUIRED");
   auto sf=patch.Sf()[0];require(std::abs(std::abs(sf.x())-1)<1e-12&&mag(vector(0,sf.y(),sf.z()))<1e-12,"M6B0_CYCLIC_AXIAL_REQUIRED");
   label cell=order[patch.faceCells()[0]],other=order[cp.neighbFvPatch().faceCells()[0]];
   require((cell==0&&other==N-1)||(cell==N-1&&other==0),"M6B0_RING_END_PAIR_REQUIRED");++cyclicFaces;
  }else forAll(patch,fi)require(std::abs(patch.Sf()[fi].x())<1e-12,"M6B0_EMPTY_TRANSVERSE_ONLY");
 }
 require(cyclicFaces==2,"M6B0_EXACTLY_TWO_AXIAL_CYCLIC_FACES");
 const fileName gasFile=runTime.path()/runTime.constant()/"thermal.dat";
 std::ifstream gasIdentityFile(gasFile.c_str(),std::ios::binary);std::string gasIdentityBytes((std::istreambuf_iterator<char>(gasIdentityFile)),{});const auto gasSHA=authoritySHA256(gasIdentityBytes);
 fiveEqGasThermoEvaluator gas(gasFile.c_str());fiveEqLiquidThermoEvaluator liquid;
 fiveEqPrecisionRecovery recovery(gas,liquid,{},model);const std::array<unsigned,3> index={{0,1,2}};
 PrecisionOperator op(recovery,index);PrecisionReconstruction rec(gas,liquid,op,index);
 fiveEqBoundaryStateBuilder builder(rec,op);fiveEqInitialStateBuilder initializer(builder);
 const word profile(cfg.lookup("profile"));const double p0=readScalar(cfg.lookup("p"));
 const double tg=readScalar(cfg.lookup("TG")),tl=readScalar(cfg.lookup("TL"));const vector u(cfg.lookup("U"));
 require(u.y()==0&&u.z()==0,"M6B0_AXIAL_VELOCITY_ONLY");
 const scalarField yin(cfg.lookup("YG"));require(yin.size()==3,"M6B0_CANONICAL_SPECIES_REQUIRED");
 const std::vector<double> Y={yin[0],yin[1],yin[2]};
 TemporalState state;state.volume.assign(N,dx);state.oldVolume=state.volume;
 if(profile=="exactInitial"){
  state=fiveEqP2IO::read((runTime.path()/runTime.constant()/"fiveEqInitialState").c_str(),"C10H22:O2:N2",op,"ndecane_gibbs_v1","HISTORICAL_K0"); // Explicit historical FRESH fixture only: step/time/lastDt must be zero.
  require(state.time==0&&state.step==0&&state.lastDt==0&&state.committed.size()==static_cast<unsigned>(N),"DYNAMIC_FRESH_INITIAL_METADATA");
  Info<<"EOS2 explicit freshInitialEOS=ndecane_gibbs_v1 activeEOS="<<liquidEOS::productionLiquidEOSVersion()<<" step=0/time=0/lastDt=0; production restart NOT CERTIFIED"<<nl;
  for(label i=0;i<N;++i){require(std::abs(state.volume[i]/mesh.V()[ids[i]]-1)<1e-12&&exactCellEqual(state.committed[i],state.old[i]),"DYNAMIC_INITIAL_GEOMETRY_OR_OLD_LEVEL");}
 }else for(label i=0;i<N;++i){BoundaryPrimitive b;b.p=p0;b.TG=tg;b.TL=tl;b.U=u;b.canonicalY=Y;
  if(profile=="uniform")b.fraction=p2Coordinate(parseHexDouble(Foam::string(cfg.lookup("P2Bits"))));
  else if(profile=="contact")b.fraction=PrecisionFraction::liquid(i<N/2?0.:1.,FractionMode::P2);
  else if(profile=="speciesContact"){b.fraction=PrecisionFraction::liquid(.1,FractionMode::P2);if(i>=N/2)b.canonicalY={.1,.2,.7};}
  else if(profile=="smooth")b.fraction=PrecisionFraction::liquid(.5+.02*std::sin(2*constant::mathematical::pi*i/N),FractionMode::P2);
  else throw RecoveryError("M6B0_UNKNOWN_INITIAL_PROFILE");
  state.committed.push_back(initializer.build(b));
 }
 if(scaledRepresentation){for(auto& c:state.committed)c.migrateV2();for(auto& c:state.old)c.migrateV2();}
 state.old=state.committed;const auto initial=state.committed;const auto sums0=integrals(state);
 std::vector<fiveEqRecoveredState> initialPrimitive;for(const auto& c:initial)initialPrimitive.push_back(op.recover(c));
 // Registered fields are accepted-state publications, never independent PDE owners.
 PtrList<volScalarField> scalars(15);wordList names({"P2","mG","mL","Et","mY_C10H22","mY_O2","mY_N2","alphaL","alphaG","rhoG","rhoL","rhoMix","p","TG","TL"});
 forAll(names,j){const dimensionSet dims=(j==3||j==12)?dimPressure:(j>=13)?dimTemperature:((j>=1&&j<=6)||(j>=9&&j<=11))?dimDensity:dimless;
  scalars.set(j,new volScalarField(IOobject(names[j],runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),mesh,dimensionedScalar(names[j],dims,0),patchTypes));}
 volVectorField M(IOobject("M",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),mesh,dimensionedVector("M",dimDensity*dimVelocity,vector::zero),patchTypes);
 volVectorField U(IOobject("U",runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),mesh,dimensionedVector("U",dimVelocity,vector::zero),patchTypes);
 PtrList<volScalarField> Ys(3);const wordList yn({"YG_C10H22","YG_O2","YG_N2"});
 forAll(yn,j)Ys.set(j,new volScalarField(IOobject(yn[j],runTime.timeName(),mesh,IOobject::NO_READ,IOobject::AUTO_WRITE),mesh,dimensionedScalar(yn[j],dimless,0),patchTypes));
 std::uint64_t acceptedCalls=0,acceptedFailures=0,acceptedIterations=0;double maxP=0,maxClosure=0,maxUniform=0,maxTrace=0,maxAlphaError=0,maxConservation=0;unsigned signChanges=0,rejected=0;
 double maxUniformPrimitive=0,maxAlphaChange=0;
 const fileName evidence=runTime.path()/"fiveEqEvidence";mkDir(evidence);
 if(scaledRepresentation){std::ofstream metadata((evidence/"representation_views.json").c_str());metadata<<"{\"physicsModel\":\"NONZERO_K_PE_CRV3_v1\",\"representationModel\":\"P2_SCALED_V2\",\"originalDesignSHA256\":\"b89c06acbf72a46690e31710aea5c97c4dcc2ead6eb59f404944a8f2de502c51\",\"legacyMigrationErratumSHA256\":\"700a03ca4b707838e8846c77a3835c98b6ce08a6d32d56d6b45904a9f1ed5704\",\"P2_alphaL_alphaG_mass_species_fields\":\"lossy views only\",\"phasePresence\":\"Side authority\",\"scientificAuthority\":\"fiveEqRestart-v3\"}\n";}
 TemporalPolicyJournal temporalLedger(evidence.c_str());fiveEqTemporalDriver driver(op,rec,&temporalLedger);
 std::unique_ptr<fiveEqCRV3TemporalDriver> crv3Driver;
 if(model==MechanicalModel::NONZERO_K_PE_CRV3_v1)crv3Driver.reset(new fiveEqCRV3TemporalDriver(op,rec,dx,crv3Mu,cfg.lookupOrDefault<Switch>("CRV3fullJournal",false)?&temporalLedger:nullptr));
 std::ofstream crv3Ledger((evidence/"crv3_joint_dt.csv").c_str());crv3Ledger<<std::setprecision(17)<<"step,time,dt,hyperbolic,alphaSource,viscous,joint,rejected,linearResidual,heatingMin,heatingIntegral,entropyProductionTrapezoidIntegral,capAdjustments,firstRejection\n";
 std::ofstream ledger((evidence/"accepted_steps.csv").c_str());ledger<<std::setprecision(17)<<"step,time,dt,rejected,maxPressureRelative,conservationRelative,speciesClosure\n";
 std::unique_ptr<m6b1::DynamicObservation> dynamic;
 if(cfg.found("dynamicDiagnostics")&&readBool(cfg.lookup("dynamicDiagnostics"))){dynamic.reset(new m6b1::DynamicObservation(evidence.c_str(),dx,N,readBool(cfg.lookup("constantP2")),readLabel(cfg.lookup("snapshotEvery"))));}
 auto publish=[&](){std::vector<fiveEqRecoveredState> recovered;for(const auto& c:state.committed){++acceptedCalls;try{recovered.push_back(op.recover(c));acceptedIterations+=recovered.back().iterations;}catch(...){++acceptedFailures;throw;}}
  // Publish only after the complete accepted state was recovered successfully.
  for(label i=0;i<N;++i){label id=ids[i];const auto& c=state.committed[i];const auto& s=recovered[i];const auto& q=c.q;
   double vals[15]={c.fraction.minorityCoordinateView(),q[1],q[2],q[6],q[7],q[8],q[9],s.alphaL,s.alphaG,s.rhoG,s.rhoL,s.rhoMix,s.p,s.TG,s.TL};
   for(unsigned j=0;j<15;++j){scalars[j].primitiveFieldRef()[id]=vals[j];}
   M.primitiveFieldRef()[id]=vector(q[3],q[4],q[5]);U.primitiveFieldRef()[id]=vector(s.U[0],s.U[1],s.U[2]);
   for(unsigned j=0;j<3;++j)Ys[j].primitiveFieldRef()[id]=c.fraction.gasPresent()?(c.representationV2?scaledV2::rationalDoubleView(c.mass(7+j),c.mass(1)).value:q[7+j]/q[1]):0;
   maxP=std::max(maxP,std::abs(s.p/p0-1));
   maxAlphaChange=std::max(maxAlphaChange,std::abs(c.fraction.liquidValue()-initial[i].fraction.liquidValue()));maxClosure=std::max(maxClosure,std::abs((q[7]+q[8]+q[9])-q[1])/std::max(q[1],1.));
   if(profile=="uniform"){const auto& b=initialPrimitive[i];
    for(unsigned j=0;j<3;++j){maxUniformPrimitive=std::max(maxUniformPrimitive,std::abs(s.U[j]-b.U[j])/std::max(1.,std::abs(b.U[j])));if(q[1]>0)maxUniformPrimitive=std::max(maxUniformPrimitive,std::abs(q[7+j]/q[1]-initial[i].q[7+j]/initial[i].q[1]));}
    for(auto v:{std::make_pair(s.p,b.p),std::make_pair(s.TG,b.TG),std::make_pair(s.TL,b.TL),std::make_pair(s.rhoG,b.rhoG),std::make_pair(s.rhoL,b.rhoL)})maxUniformPrimitive=std::max(maxUniformPrimitive,std::abs(v.first-v.second)/std::max(1.,std::abs(v.second)));
    for(unsigned j=1;j<10;++j)maxUniform=std::max(maxUniform,std::abs(q[j]-initial[i].q[j])/std::max(std::abs(initial[i].q[j]),1.));
    if(c.representationV2)require(c.fraction.scaledAuthority().side==initial[i].fraction.scaledAuthority().side&&c.fraction.scaledAuthority().q.wire()==initial[i].fraction.scaledAuthority().q.wire(),"P2_UNIFORM_PAYLOAD_DRIFT");else require(exactBits(c.fraction.payload().hi)==exactBits(initial[i].fraction.payload().hi),"P2_UNIFORM_PAYLOAD_DRIFT");
    if(initial[i].q[1]>0&&initial[i].q[2]>0){double f0=std::abs(initial[i].fraction.minorityCoordinateView());if(f0>0&&f0<1e-12)maxTrace=std::max(maxTrace,std::abs(std::abs(c.fraction.minorityCoordinateView())/f0-1));}}
   if(profile=="smooth"){double exact=.5+.02*std::sin(2*constant::mathematical::pi*(i-u.x()*state.time/dx)/N);maxAlphaError=std::max(maxAlphaError,std::abs(s.alphaL-exact));}
  }
  forAll(scalars,j){scalars[j].correctBoundaryConditions();}
  M.correctBoundaryConditions();U.correctBoundaryConditions();
  forAll(Ys,j){Ys[j].correctBoundaryConditions();}
  if(dynamic)dynamic->record(state,recovered);
 };
 forAll(names,j){require(mesh.foundObject<volScalarField>(names[j])&&&mesh.lookupObject<volScalarField>(names[j])==&scalars[j],"M6B0_REGISTRY_OWNER_MISMATCH");}
 require(mesh.foundObject<volVectorField>("M")&&mesh.foundObject<volVectorField>("U"),"M6B0_VECTOR_REGISTRY_MISSING");
 forAll(yn,j){require(mesh.foundObject<volScalarField>(yn[j]),"M6B0_SPECIES_REGISTRY_MISSING");}
 publish();Info<<"M6B0 authority=fiveEq "<<representationModel<<" serial=1 fixedMesh=1 DPM=0 surfaceTension=0 unitAreaPeriodic1D=1 fieldsRegistered=20"<<nl;
 // Verification requires the configured endTime, including a final clipped
 // physical step. OpenFOAM run() uses a half-deltaT stopping window and can
 // skip a short case entirely when its startup deltaT exceeds twice endTime.
 while(scaledRepresentation?state.time<runTime.endTime().value():runTime.run()){
  require(!mesh.moving()&&!mesh.topoChanging(),"M6B0_MESH_CHANGED");
  const auto anchor=state.committed;TemporalState candidate=state;
  const double remaining=runTime.endTime().value()-runTime.value();
  // Preserve startup deltaT. Subsequent proposal/growth is project-local TD1 policy.
  double request=state.lastDt>0?remaining:std::min(runTime.deltaTValue(),remaining);
  if(request<=0)break;
  TemporalStepResult step;
  if(model==MechanicalModel::NONZERO_K_PE_CRV3_v1){auto z=crv3Driver->advance(candidate,request);step.dt=z.dt;step.rejected=z.rejected;crv3Ledger<<candidate.step<<','<<candidate.time<<','<<z.dt<<','<<z.bounds.hyperbolic<<','<<z.bounds.alphaSource<<','<<z.bounds.viscous<<','<<z.bounds.joint<<','<<z.rejected<<','<<z.linearResidual<<','<<z.heatingMin<<','<<z.heatingIntegral<<','<<z.entropyProductionIntegral<<','<<z.capAdjustments<<','<<z.firstRejection<<'\n';}
  else step=driver.advance(candidate,request); // Frozen PDE, full raw/post-species recovery, TD1 transactional time guard.
   if(scaledRepresentation)guardAuthorityConservation(authorityLedger(anchor,state.volume),candidate.committed,candidate.volume);
   const double clockOld=runTime.value(),clockCandidate=clockOld+step.dt;
  require(std::isfinite(clockCandidate)&&clockCandidate>clockOld,"TD1_TIME_MONOTONICITY_BLOCKER");
  state=std::move(candidate);rejected+=step.rejected;runTime.setDeltaT(step.dt);++runTime;
  require(runTime.value()>clockOld,"TD1_TIME_MONOTONICITY_BLOCKER");
  require(std::abs(state.time-runTime.value())<=1e-12*std::max(1.,state.time),"M6B0_TIME_CLOCK_MISMATCH");
  for(label i=0;i<N;++i)signChanges+=std::signbit(state.committed[i].fraction.minorityCoordinateView())!=std::signbit(anchor[i].fraction.minorityCoordinateView());
  publish();auto sums=integrals(state);double error=0;
  for(unsigned j=0;j<9;++j)error=std::max(error,static_cast<double>(std::abs(sums[j]-sums0[j])/std::max(std::abs(sums0[j]),static_cast<long double>(1.))));
  maxConservation=std::max(maxConservation,error);ledger<<state.step<<','<<state.time<<','<<step.dt<<','<<step.rejected<<','<<maxP<<','<<error<<','<<maxClosure<<'\n';
  Info<<"Time = "<<runTime.timeName()<<" acceptedStep="<<state.step<<" pressureError="<<maxP<<" conservation="<<error<<nl;
  if(runTime.writeTime()){runTime.write();if(scaledRepresentation){fiveEqScaledP2IO::write((runTime.path()/runTime.timeName()/"fiveEqRestart").c_str(),state,"C10H22:O2:N2",gasSHA);writeScaledAuthorityExport((runTime.path()/runTime.timeName()/"fiveEqAuthority.csv").c_str(),state);}else fiveEqP2IO::write((runTime.path()/runTime.timeName()/"fiveEqRestart").c_str(),state,"C10H22:O2:N2",model);}
 }
 // Final exact conservative/P2 contract. Production restart remains uncertified.
 if(scaledRepresentation)fiveEqScaledP2IO::write((evidence/"final_fiveEqRestart").c_str(),state,"C10H22:O2:N2",gasSHA);else fiveEqP2IO::write((evidence/"final_fiveEqRestart").c_str(),state,"C10H22:O2:N2",model);
 if(scaledRepresentation)writeScaledAuthorityExport((evidence/"final_authority.csv").c_str(),state);
 const auto obs=m6b0::observations();auto sums=integrals(state);
 std::ofstream diagnostic((evidence/"primitive_diagnostics.json").c_str());diagnostic<<std::setprecision(17)<<"{\"maxUniformPrimitiveDrift\":"<<maxUniformPrimitive<<",\"maxAlphaChange\":"<<maxAlphaChange<<",\"registryChecked\":true}\n";
 std::ofstream result((evidence/"result.json").c_str());result<<std::setprecision(17);
 result<<"{\"profile\":\""<<profile<<"\",\"steps\":"<<state.step<<",\"np\":1,\"registeredFields\":20,\"maxPressureRelative\":"<<maxP<<",\"maxUniformRelative\":"<<maxUniform<<",\"maxTraceRelative\":"<<maxTrace<<",\"maxAlphaAdvectionAbsolute\":"<<maxAlphaError<<",\"maxSpeciesClosureRelative\":"<<maxClosure<<",\"maxConservationRelative\":"<<maxConservation<<",\"branchChanges\":"<<signChanges<<",\"rejectedTrials\":"<<rejected<<",\"acceptedRecoveryCalls\":"<<acceptedCalls<<",\"acceptedRecoveryFailures\":"<<acceptedFailures<<",\"acceptedRecoveryIterations\":"<<acceptedIterations<<",\"allRecoveryCalls\":"<<obs.calls<<",\"allRecoveryFailuresIncludingProbes\":"<<obs.failures<<",\"allRecoveryIterations\":"<<obs.iterations<<",\"pureGasCalls\":"<<obs.gas<<",\"pureLiquidCalls\":"<<obs.liquid<<",\"mixedCalls\":"<<obs.mixed<<",\"gasQueries\":"<<obs.gasQueries<<",\"liquidQueries\":"<<obs.liquidQueries<<",\"conservationByComponent\":[";
 for(unsigned j=0;j<9;++j){if(j)result<<',';result<<static_cast<double>(std::abs(sums[j]-sums0[j])/std::max(std::abs(sums0[j]),static_cast<long double>(1.)));}result<<"]}\n";
 Info<<"M6B0 normal exit; serial verification micro-case only"<<nl;return 0;
 }catch(const std::exception& e){FatalErrorInFunction<<"M6B0 STOP: "<<e.what()<<exit(FatalError);return 1;}
}
