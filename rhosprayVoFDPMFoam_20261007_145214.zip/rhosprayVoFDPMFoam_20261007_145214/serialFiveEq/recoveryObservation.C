#include "recoveryObservation.H"
#include "fiveEqPrecisionRecovery.H"
namespace m6b0 {RecoveryObservation& observations(){static RecoveryObservation s;return s;}}
using namespace fiveEq;
extern "C" fiveEqRecoveredState realRecovery(const fiveEqPrecisionRecovery*,const fiveEqConservativeState&,const PrecisionFraction&,const RecoveryOptions&,fiveEqRecoveredState*) asm("__real__ZNK6fiveEq23fiveEqPrecisionRecovery7recoverERKNS_23fiveEqConservativeStateERKNS_17PrecisionFractionERKNS_15RecoveryOptionsEPNS_20fiveEqRecoveredStateE");
extern "C" fiveEqRecoveredState observedRecovery(const fiveEqPrecisionRecovery*,const fiveEqConservativeState&,const PrecisionFraction&,const RecoveryOptions&,fiveEqRecoveredState*) asm("__wrap__ZNK6fiveEq23fiveEqPrecisionRecovery7recoverERKNS_23fiveEqConservativeStateERKNS_17PrecisionFractionERKNS_15RecoveryOptionsEPNS_20fiveEqRecoveredStateE");
extern "C" fiveEqRecoveredState observedRecovery(const fiveEqPrecisionRecovery* self,const fiveEqConservativeState& q,const PrecisionFraction& f,const RecoveryOptions& o,fiveEqRecoveredState* progress){
 auto& c=m6b0::observations();++c.calls;fiveEqRecoveredState local;
 auto record=[&](const fiveEqRecoveredState& s){c.maxIterations=std::max(c.maxIterations,s.iterations);c.iterations+=s.iterations;c.gasQueries+=s.calls.gas;c.liquidQueries+=s.calls.liquid;
  c.gas+=s.recoveryMode==RecoveryMode::PURE_GAS;c.liquid+=s.recoveryMode==RecoveryMode::PURE_LIQUID;c.mixed+=s.recoveryMode==RecoveryMode::MIXED;};
 try{auto s=realRecovery(self,q,f,o,progress?progress:&local);record(s);return s;}
 catch(...){++c.failures;record(progress?*progress:local);throw;}
}
extern "C" fiveEqRecoveredState realAuthorityRecovery(const fiveEqPrecisionRecovery*,const fiveEqConservativeState&,const PrecisionFraction&,const RecoveryOptions&,fiveEqRecoveredState*,const RecoveryAuthority*) asm("__real__ZNK6fiveEq23fiveEqPrecisionRecovery20recoverWithAuthorityERKNS_23fiveEqConservativeStateERKNS_17PrecisionFractionERKNS_15RecoveryOptionsEPNS_20fiveEqRecoveredStateEPKNS_17RecoveryAuthorityE");
extern "C" fiveEqRecoveredState observedAuthorityRecovery(const fiveEqPrecisionRecovery*,const fiveEqConservativeState&,const PrecisionFraction&,const RecoveryOptions&,fiveEqRecoveredState*,const RecoveryAuthority*) asm("__wrap__ZNK6fiveEq23fiveEqPrecisionRecovery20recoverWithAuthorityERKNS_23fiveEqConservativeStateERKNS_17PrecisionFractionERKNS_15RecoveryOptionsEPNS_20fiveEqRecoveredStateEPKNS_17RecoveryAuthorityE");
extern "C" fiveEqRecoveredState observedAuthorityRecovery(const fiveEqPrecisionRecovery* self,const fiveEqConservativeState& q,const PrecisionFraction& f,const RecoveryOptions& o,fiveEqRecoveredState* progress,const RecoveryAuthority* authority){
 auto& c=m6b0::observations();++c.calls;fiveEqRecoveredState local;
 auto record=[&](const fiveEqRecoveredState& s){c.maxIterations=std::max(c.maxIterations,s.iterations);c.iterations+=s.iterations;c.gasQueries+=s.calls.gas;c.liquidQueries+=s.calls.liquid;c.gas+=s.recoveryMode==RecoveryMode::PURE_GAS;c.liquid+=s.recoveryMode==RecoveryMode::PURE_LIQUID;c.mixed+=s.recoveryMode==RecoveryMode::MIXED;};
 try{auto s=realAuthorityRecovery(self,q,f,o,progress?progress:&local,authority);record(s);return s;}catch(...){++c.failures;record(progress?*progress:local);throw;}
}
