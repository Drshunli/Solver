# Five-equation migration dependency audit (Foundation OF7)

This audit describes the active legacy gas-KT solver and the dependencies to
resolve before a unified isobaric, common-velocity two-material KT switch.
It is not an active five-equation implementation.

## Gas species and reaction

`rhoYEqn.H` constructs multivariate convection with the current gas KT mass
flux `phi`, solves `fvm::ddt(rho,Yi)+div(phi,Yi)` for each active non-inert gas
species, subtracts `parcels.SYi(i,Yi)` and `reaction->R(Yi)`, optionally
diffuses with `turbulence->muEff()`, then closes the inert specie by
`Yi=1-sum(other Yi)`. `createFields.H` obtains `Y` from gas
`thermo.composition()`, adds species and gas `he` to interpolation, and
constructs reaction from gas thermo/turbulence. Future species mass is
`mG*Yi`, and its advective flux must derive from the same two-material KT
face state as `F_mG`; `rhoMix*Yi` is invalid. No species equation changes now.

## Turbulence

`createFields.H` calls OF7 `compressible::turbulenceModel::New(rho,U,phi,thermo)`:
`rho` and `phi` currently have legacy gas KT meanings, while thermo is gas
thermo. `rhoUEqn.H` uses `muEff()`, `rhoEEqn.H` uses `muEff/alphaEff`,
`rhoYEqn.H` uses `muEff`, and the main loop calls `turbulence->correct()`
after thermo. The five-equation switch must choose a consistent density and
mass-flux adapter and define liquid/interface turbulence effects; it must not
silently feed a different flux meaning into this constructor.

## DPM carrier and sources

OF7 `SprayCloud` accepts a const carrier density reference. `createClouds.H`
passes `rhoG`; today this aliases the exact legacy gas `rho` object. Future
intrinsic gas density must come from `mG/alphaG` with a pure-liquid/vanishing
gas-volume policy. DPM mass, species and heat exchange belong to the gas
material balance; parcel drag couples through gas-contact locations into
common momentum. Current `parcels.evolve()`, `Srho`, `SU`, `Sh` and `SYi`
placement is unchanged and requires an M8 source audit.

## Moving mesh and fluxes

The current main loop stores parcel positions before `mesh.update()`. KT
face volume speeds subtract `mesh.phi()` when moving; `phiV` is their sum;
`phiEp` adds a moving-mesh pressure-work term. Future two-material left/right
states, `F_mG/F_mL/F_M/F_E`, material transport and mesh-motion corrections
must use one consistent relative/absolute-flux convention and satisfy the
geometric conservation law. The current `CorrectPhi.H` top-level include
does not mean a pressure-correction algorithm is active.

## Present alpha interface

M2 `alphaEqn.H` uses MULES with `phiV`, compression and subcycle averaging.
Its `alphaPhi` is provisional interface transport. It is not automatically
conservative with future phase-mass KT fluxes or total-energy flux. The
five-equation material-field and sharpening contract must be derived before
M5C/M6B activation.
