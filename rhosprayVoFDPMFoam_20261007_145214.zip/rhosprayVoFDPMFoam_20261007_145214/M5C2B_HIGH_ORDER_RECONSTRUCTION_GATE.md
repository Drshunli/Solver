# M5C.2B 高阶重构竞争与更新合法性评估

日期：2026-09-30/2026-10-01；Foundation OF7 本机源码；纯独立算子单元测试，无 CFD。

# 1. M5C.2B status

**PARTIAL / STANDALONE / NOT ACTIVE。** R1 和 R2-HYBRID 已编译、评估；当前不满足全部 29 项关闭条件。M5C.2C REQUIRED，但本轮未实现。

# 2. Legacy reconstruction audit

实际旧链独立重构 rho/rhoU/rPsi/e/c，随后 U=rhoU/rho、p=rho*rPsi；面状态不重新作 EOS 闭合。源码及实际 API 核对见 LEGACY_RECONSTRUCTION_AUDIT.md。

# 3. Actual current schemes

rho→Minmod；rhoU→reconstruct(U)/MinmodV；rPsi、e、c→reconstruct(T)/Minmod。物种实际采用 div(phi,Yi_h)/Gauss multivariate vanLeer，共享 limiter 包括所有 Yi 和 he；字典内单物种 vanLeer01 不是实际调用。

# 4. R1 mathematical definition

令 Q=(alphaL,mG,mL,Mx,My,Mz,Et,mY0,mY1,mY2)。
面状态 Q_if=Q_i+theta_i*deltaQ_if，0<=theta_i<=1；deltaQ 来自 OF7 directional Minmod/MinmodV。
M 使用 MinmodV；其余权威变量使用 scalar Minmod。rhoMix=mG+mL，p/T 只从实际恢复获得。无独立 thermo 面 owner。


# 5. Shared-theta implementation

r1SharedCell 对传入该 cell 的全部关联面、全部 MaterialCell 分量使用同一个 theta。本轮一维 cell 的左右两面都传入。初版“各面独立续接再取最小端点”在 mixedShock 失败，已保留历史结果并改为同一 theta 同时检查所有面。不会把面限幅结果写回 cell average。

# 6. Theta analytic bounds

对 x(theta)=x0+theta*dx，若 dx<0，则 theta<=x0/(-dx)。同时约束 alphaL、1-alphaL、mG、mL 和各 mYi；取所有面/变量的共同最小上界。没有经验 theta 系数或额外 shrink factor。

# 7. Theta thermo continuation

从 theta=0 的真实合法 Q_i 开始，以共同解析上限的 32 等分点顺序检查所有面；遇到第一个采样失败，仅在该段以 52 次二分取得合法端点；最后再次恢复所有最终面。不搜索后续合法岛。有限采样不能证明点间任意非单调路径，此限制明确保留。

# 8. Species closure strategy

三物种 MaterialCell 按 runtime name 顺序存储；N−1 分量独立重构，最后分量的增量 dmY_last=dmG−sum(dmY_independent)，面值 mY_last=mG−sum(mY_independent)。theta=0 原样返回，未归一化。重排 N2/C10H22/O2 测试通过。但冻结 KT 核心分别求各物种通量，14/5832 个 flux-sum 检查超过预设 1e−12 容差，最大 3.7517e−12；该问题尚未关闭。

# 9. Alpha face boundedness

最终 100 步评估的 19040 个面状态检查通过 0<=alphaL<=1；512 个认证角点面检查通过。没有 clipping。

# 10. Partial-mass face positivity

19040 个应力面及 512 个边界面均合法；解析 theta 约束、phase presence 与实际 EOS 检查共同工作。没有负质量修复。

# 11. Phase-presence v2 behavior

v2 文件/库保持冻结；64epsilon 未成为截断阈值。非零 phase 不因 theta 限幅被消灭；exact pure branch 的 absent phase 不调用其 EOS。alphaL==1 且 mG>0 仍严格拒绝，不吞掉新生 trace。

# 12. EOS face admissibility

所有被使用的最终高阶面通过真实 recoverFaceState。气体来自 thermal.dat 的 OF7 JANAF；液体使用冻结 ndecane_gibbs_v1。没有 p/T clipping、EOS extrapolation 或替换解析假模型。

# 13. R1 stationary-contact result

初始面 p/U 保持通过。N=20 完成 1000 步；N=60/200 接受 10 步后无合法连续更新。压力小误差不等价于全阶段接触测试通过。

# 14. R1 moving-contact result

U=47 m/s，N=20 完成 1000 步；N=60/200 接受 10 步后 NO_USABLE_ANCHOR。已接受更新的 p/U 检查通过；诊断尾部 rhoG/TG 仍有约 1.17%/1.15% 偏移。

# 15. R1 trace-contact result

液体/气体 trace=1e−12、1e−14、1e−16，N=20/60/200 均完成 100 步；N=20 的 1e−16 两类 trace 完成 1000 步，p/U 与守恒通过。不能据此称为准确保持 intrinsic thermo：traceGas16 的 11 步诊断 rhoG/TG 最大相对漂移约 29.51%/22.78%。

# 16. R1 shock-state result

gasShock 在全部 N 完成 100 步。mixedShock 接受 12 步后高阶与同状态 R0 同一 cell 均向 HARD 边界外演化，受控 EOS 停止，不把它记为 limiter 成功。mixedShock 初版面 theta 问题已由共同续接修复。

# 17. R2 formulation

R2-HYBRID 重构 alphaL、p、MinmodV(U)、存在相的 TG/TL、两个独立 canonical Yi。然后用实际 phase EOS 构造 mG=(1−alphaL)rhoG、mL=alphaL*rhoL、M=(mG+mL)U、Et=mG*eG+mL*eL+0.5*(mG+mL)|U|²，并 recoverFaceState roundtrip。

# 18. R2 absent-phase handling

只在该相实际存在时重构其 T/Y 和查询对应 EOS。四点 stencil 的相存在模式不一致、或构造将抹除 owner 的相时，明确 R1_FALLBACK；非法 primitive 构造亦回退到已经合法的 R1 面。未插值 fictitious absent temperature。

# 19. R2 contact result

stationary/moving/ALE 初始面 p/U 均通过；N=20 stationary/moving 完成 1000 步，ALE 前独立长测亦完成 1000 步，但本次正式 final100 的 ALE=100 步。N=60/200 的三类尖锐接触均在 10 步后停止。R2 不因重构 p 就获得 contact-preserving 声明。

# 20. R2 pure-phase result

纯气/纯液 branch、shock、JANAF near-range、HARD corner 面验证通过。pureLiquidCompression 全部 N 完成 100 步；gasJANAFNear 完成 10 步。实际边界/MPI 验证仍未执行。

# 21. Pure-gas legacy reconstruction comparison

5832 候选比较行中 1944 项 uniform 完整链 equality 检查通过。非均匀最大差异：R1 rho=0、U≈7.76e−17、p≈0.4198%；R2 rho≈0.3236%、p≈0.3236%，U 的归一化最大差异约 0.1621。R1 更接近旧 rho/rhoU 面表达。真实 fvc 完整链另有 428 项检查、0 失败。

# 22. Pure-gas flux comparison

最大 wave 差异 R1≈8.162e−4、R2≈5.320e−4；mass/momentum/energy/species 全部差异写入 legacy_comparison.csv；真实 fvc 输出同时记录绝对差异。接近零的旧 mass/energy flux 会放大用 max(1,abs(oldFlux)) 归一化的比例，例如 R1 energy 最大约 330、R2 mass 最大约 1，不能当成普遍的百分比精度。非均匀差异未强行置零。

# 23. Selected reconstruction strategy

**R1：CONDITIONAL DEVELOPMENT REFERENCE ONLY**；R2-HYBRID 保留为竞争原型。没有正式接受、没有运行时提升。selected_strategy.json 记录该区分；严格“最终策略已选并接受”门槛仍 PARTIAL。

# 24. Selection rationale

采用测试前 test_contract.json 的优先级：合法性、纯相稳健性、接触压力、旧链接近程度、守恒一致性、简单性、成本、精度。两者共有长步接触/补量精度阻塞；R2 未证明能排除它们。R1 权威变量共享增量、rho/rhoU 与旧链更近，适合作为下一次修正的参考。平滑加密中 R1 Et 与 R2 U 近二阶；特定 R2 p 超收敛不推广为全局阶数。

# 25. High-order dtAlpha

每个候选用自己的 F_alpha 和 phiRelStar。
D=meshPhi_R−meshPhi_L；N_alpha=−(F_alpha_R−F_alpha_L)+alpha_i*(phiRelStar_R−phiRelStar_L)。
要求 alpha_i*V+dt*(alpha_i*D+N_alpha)>=0，及 (1−alpha_i)*V+dt*((1−alpha_i)*D−N_alpha)>=0。
从实际这两个线性不等式得到 dtAlpha；没有挪用 R0 的 alpha 时间步。

# 26. High-order dtMass/species

每种部分质量/物种的界限来自 q_j*V−dt*(F_j,R−F_j,L)>=0；若净流出>0，dt<=V*q_j/netOut，否则为无穷。体积同时要求 V+dt*D>0。

# 27. High-order dtThermo

在各自 joint linear/acoustic candidate 上，调用冻结 connectedThermodynamicStep：真实 explicitTrial→checkMaterialCell→recoverCellState，32 续接点/52 二分；R0 也在同一个当前 cell state 上独立重算。存在性提前失败不是 EOS failure；诊断默认 INTERNAL_PROGRAM_ERROR 字段在该情形不代表 EOS 内部异常，PRESENCE(issue=5) 才是失败理由。

# 28. High-order joint timestep

CFL=0.15；线性界限 safety=0.95，与冻结基线一致。dtCandidate=min(dtAcoustic,0.95*dtAlpha,0.95*dtMG,0.95*dtML,0.95*dtSpecies,0.95*dtVolume)，dtFinalHigh 再与各 cell dtThermo 取最小。高阶独有 outward 时可整算子退到原样 R0，重新检查 R0；不实施 FCT。

# 29. Post-update thermo validity

全域 proposals 逐 cell 真实恢复全部通过才 commit；任何失败/停止保持 q 和 V 不变。没有被提交的不合法状态。已接受状态合法性与未来存在正时间步是不同门槛，后者在 12 条接触路径失败。

# 30. Multiple-step results

final100：17 类 ×3 个 N ×2 候选=102 组；78 完成请求步数、12 EOS stops、12 NO_USABLE_ANCHOR，共7446 accepted steps。通常请求100步；JANAF10步、HARD1步。final1000：N=20 stationary/moving/traceLiquid16/traceGas16 ×R1/R2，共8组各1000步。N=60/200 未完成所有种类1000步，因此不宣称完整长步门槛通过。

# 31. HARD-domain outward handling

6 组 exact TL=320 K outward 从0步受控停止；6 组 mixedShock 到合法边界后高阶/R0同一 cell 均 outward，分别 R1第12步、R2第10步后停止。HARD 是认证域而非 PDE invariant domain；没有通过放宽表、clipping 或限幅强行留在域内。

# 32. High-order-only overshoot cases

构造8个 TL=285 K 局部 stencil：6个为高阶 outward 而同状态 R0 inward；实际 R0 dtThermo≈1.149e−4，rollback 和 R0 explicitTrial 恢复6/6通过。与 both-outward EOS stop 分类分开。它们是局部 operator 检查，未冒充全域所有 cell 同时可推进的多步证明。

# 33. Conservation ledger

102组 accepted-only periodic ledger 全通过；部分质量、M、Et、物种最大归一化漂移 7.106e−14，低于预设5e−12。rejected proposal 未进入账本。

# 34. Alpha discrete balance

检查 sum(V_new*alpha_new)−sum(V_initial*alpha_initial)−sum(accepted alpha source integral)，最大绝对残差1.137e−13。alpha 有非保守源，未错误要求 sum(alpha) 在任意 ALE/压缩场中严格不变。

# 35. Limiter statistics

final100 cell-step统计：R1 thetaFull=329194、thetaLimited=106、thetaZero=0；R2内嵌R1 full=328625、limited=115、zero=0。R2 direct face=655692，R1 fallback face=1788。整算子退R0次数 R1=9、R2=6；theta=0的严格身份另外7种相状态直接测试通过。

# 36. dt cost statistics

accepted steps 的统计（失败路径的 dt=0 单独报告，不从统计事实中抹除）：

| 比值 | min | median | P5 | P95 | P99 |
|---|---:|---:|---:|---:|---:|
| R1 dtFinal/dtAcoustic |0.080679|1|1|1|1|
| R2 dtFinal/dtAcoustic |0.547767|1|1|1|1|
| R1 dtHigh/dtR0 |0.333959|1|0.99999491|1.00016578|1.00063579|
| R2 dtHigh/dtR0 |0.563808|1|0.99999230|1.00019494|1.00100370|

高阶/R0续接合计 query 数：R1 21645672，R2 21608766；对应整体 profile 墙钟约264.4 /283.8秒。
并发环境下墙钟不是专用性能基准。没有事后设置 practical dt 阈值；12组接触的连续 dt 真为0，不能记成微小正步成功。

# 37. Complement-cancellation diagnostics

final_tail 的11步诊断：traceGas16 中 R1 rhoG/TG 最大漂移29.51%/22.78%，R2 34.52%/25.66%；alphaG 绝对兼容残差仅约3.28e−17/3.83e−17。这展示除以1−alphaL的条件数放大。traceLiquid16 的 intrinsic 误差约机器精度。尖锐接触纯液 plateau 的 alphaL=1 与新生 mG≈3.35e−16 在第一续接采样相互矛盾，即使更大 dt 可能合法，也没有跳过该非法区间。

# 38. Whether coupled limiter is needed

**需要进一步的耦合 operator/flux 修正研究。** 单独高阶面合法、dt线性界限和有限 thermo 续接没有关闭整个更新门槛。R0 anchor 自身在新生成的浮点 phase-emergence 状态也会无连续正步，必须先处理/证明该前提；不能默认 FCT 的低阶合法性。

# 39. Whether M5C.2C is required

**REQUIRED / NOT IMPLEMENTED。** 下一轮应先审计 pure-plateau/新生 trace 的离散表示及 alpha/mG 一致性、N−1 species flux closure、R0 anchor 有效区间，再决定共享保守通量修正。禁止以删除 trace、修改 q、能量 rescale 或 EOS 域扩张代替。这里只记录需求，未实现 M5C.2C。

# 40. Whether M5C.2 is COMPLETE

**NO / PARTIAL。** 29项清单中的 species closure、完整 trace contact、正式策略接受仍 PARTIAL；虽已得出需耦合修正的方向，但不借“decision gate”掩盖这些未关闭条件。

# 41. Active solver impact

**NONE。** 56个事前保护文件 SHA-256 全一致；活动方程、主 C、Make、alpha、KT 重构、时间步和 DPM 源位置未改。EOS metadata/coefficients/energy reference/header 和两个冻结库哈希核对一致。新增模块仅由独立测试 Make 编译，不进入 solver runtime。未运行 CFD。

# 42. M5C.3 start permission

**NO。** M5C.2 尚未关闭，不能进入时间积分/边界/初始化/restart阶段。

# 43. M6B permission

**NO。** 未激活两材料 KT，也未进入 M8A。

# 44. Updated milestone matrix

|阶段|状态|
|---|---|
|M0–M4|COMPLETE，保持原有范围|
|M5A/M5B/M5B.1|COMPLETE / ACTIVE REFERENCE或DESIGN|
|M6A1a、M6A1b生产EOS|保持已冻结状态；无参数修改|
|M6A2.1/.2|COMPLETE / STANDALONE或PASSIVE；本轮2096/38回归通过|
|M5C.1|COMPLETE / STANDALONE；34902回归通过|
|M5C.2A|COMPLETE / TESTED DOMAIN；362962回归通过，不推广为任意高阶状态证明|
|M5C.2B|PARTIAL；R1/R2原型、审计和评估已执行|
|M5C.2C|REQUIRED / NOT STARTED|
|M5C.2|PARTIAL|
|M5C.3 / M8A / M6B|BLOCKED / NOT STARTED|
|M7、M9–M15|NOT STARTED|
|M8|原DPM保留；后续源耦合未激活|

STOP：本轮结束，不执行后续阶段。

## 29项门槛逐项状态

|门槛|状态|
|---|---|
|1. real legacy cell-face reconstruction audited|PASS / TESTED SCOPE|
|2. R1 implemented|PASS / TESTED SCOPE|
|3. theta=0 == R0 proven|PASS / TESTED SCOPE|
|4. shared theta acts on all authoritative variables|PASS / TESTED SCOPE|
|5. species closure solved|PARTIAL|
|6. theta connected-valid search implemented|PASS / TESTED SCOPE|
|7. face alpha bound|PASS / TESTED SCOPE|
|8. partial mass positivity|PASS / TESTED SCOPE|
|9. phase-presence v2 preserved|PASS / TESTED SCOPE|
|10. EOS-valid face recovery|PASS / TESTED SCOPE|
|11. stationary contact reconstruction|PASS / TESTED SCOPE|
|12. moving contact reconstruction|PASS / TESTED SCOPE|
|13. trace contact|PARTIAL|
|14. shock-like face reconstruction|PASS / TESTED SCOPE|
|15. R2 prototype evaluated|PASS / TESTED SCOPE|
|16. pure-gas end-to-end legacy comparison|PASS / TESTED SCOPE|
|17. reconstruction strategy selected|PARTIAL|
|18. high-order bounds recomputed|PASS / TESTED SCOPE|
|19. high-order dtThermo implemented/tested|PASS / TESTED SCOPE|
|20. post-update recovery checked|PASS / TESTED SCOPE|
|21. multiple-step harness executed|PASS / TESTED SCOPE|
|22. conservation ledger|PASS / TESTED SCOPE|
|23. alpha balance|PASS / TESTED SCOPE|
|24. HARD outward semantics preserved|PASS / TESTED SCOPE|
|25. overshoot separated from domain exhaustion|PASS / TESTED SCOPE|
|26. timestep cost quantified|PASS / TESTED SCOPE|
|27. coupled flux limiter explicitly required|PASS / TESTED SCOPE|
|28. active solver unchanged|PASS / TESTED SCOPE|
|29. no CFD run|PASS / TESTED SCOPE|

## 文件与复现

新增 `fiveEqReconstruction/fiveEqOF7Directional.H/.C`、`fiveEqThetaAdmissibility.H/.C`、
`fiveEqR1SharedTheta.H/.C`、`fiveEqR2ThermoReconstruction.H/.C`。
新增 `tests/fiveEqHighOrder` 和 `tests/fiveEqOF7Interpolation`，含各自 Make/files/options。
新增本报告、LEGACY_RECONSTRUCTION_AUDIT.md、tools/reportM5C2B.py、
`fitting/reconstruction/m5c2b_v1` 的原始 CSV/JSON/log、保护清单、策略及29项清单；更新 MILESTONE_STATUS.md。
活动 Make/files/options 无改动。独立测试增加 finiteVolume/meshTools/specie include 和有限体积链接；保留 -Werror。

独立模块最终严格编译 PASS；实际 fvMesh/完整气相链检查428/0失败。
高阶 harness 有意返回失败 exit code：final100为71099检查/26失败；其中14物种通量闭合、12无连续步。
final1000 sample为23139检查/14失败，均来自每轮重复执行的同一气相通量矩阵。
final_tail为41691检查/22失败，其中同一矩阵14、尖锐接触无步8；不是22个EOS查询错误。
四组冻结回归2096、38、34902、362962，均0失败。

在 WSL OF7 环境下对两个独立 tests 目录分别 wmake；所有运行必须进入新的结果 cwd，
避免覆盖冻结历史。高阶程序参数为 thermal.dat、reactions、mode；
`screen`=10步全类别，`audit100`=100步，`longsample`=N20四类各1000步，
`faceonly`=纯面/重构矩阵，`taildiag`=接触/trace11步及补量诊断。
实际 OF7 插值程序参数为 fixture绝对路径、thermal.dat、reactions。
不运行活动求解器、blockMesh或checkMesh。

最终物理模块（共同theta续接）在final100/final1000/final_faces/final_tail间没有变化；
后续 test harness 编辑只增加诊断/误差输出及局部回退断言。
root历史长测在joint修复后停止，未覆盖日志；screen初版abort保留。
历史或不同版本的测试不能混加成一份零失败报告。
