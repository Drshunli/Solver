# Future fiveEq ownership v3 — M5C.3 temporal/IO freeze, NOT ACTIVE

Historical v2 and active legacy ownership remain unchanged. This v3 adds temporal/IO authority to the already selected R1-P2 design. Production activation is prohibited until the subsequent gates grant it.

| Data | In-memory owner | Cold generation | Stage update | Restart authority |
|---|---|---|---|---|
| P2 signed minority coordinate |complete Q tuple, ONE alpha DOF|physical minority specification|P2-aware nonconservative operator|exact coordinate bits in accepted bundle|
| mG/mL |same tuple|phase EOS and P2|one shared KT phase mass flux; later typed source adapter|bundle,not primitive rho files|
| M |same tuple|rhoMix U|shared KT momentum flux; later paired stresses/body/parcel forces|bundle|
| Et |same tuple|phase sensible internal energy +kinetic|shared KT energy flux; later ledger-coupled work/heat|bundle|
| mYi |same tuple,runtime species order|mG Yi and residual species|shared conservative species flux; paired chemistry/DPM source|bundle +species signature|
| V/time/step/lastDt |accepted temporal/mesh owner|mesh/startup time|commit only after all-cell/source acceptance|bundle +mesh/address identity|
| oldTime Q/P2/V |temporal owner|full copy of initial accepted tuple|full copy of last accepted tuple; immutable during retry|exact old-level bundle|
| trial |transaction-local buffers|copy coherent Qn|all components proposed together|NEVER serialized|
| alphaL/alphaG |decoded views|P2 decode|refresh per generation|NONE|
| rhoMix/U/Yi |derived views|masses/M/species|refresh from same tuple|NONE|
| p/TG/TL/rhoG/rhoL/cMix |P2-aware production recovery cache|whole-Q recovery|whole-stage recovery|NONE; optional diagnostic comparison only|
| reconstructed face Q/P2 |R1 stage owner|committed cell states/BC|one generation; recover before flux|NONE|
| shared face fluxes |KT stage owner|recovered face pair and geometry|one value per face, reused by adjacent cells|NONE|
| DPM transfer ledgers |future M8A transaction owner|accepted parcel events|paired gas/common momentum/Et/species update|M8A must define synchronized accepted IO|

Coherent generation rule: no EOS call mixes new phase masses/Et with old fraction, old composition or old pressure authority. Diagnostic p must never overwrite the new Q tuple. Standard field visualization and exact restart bundle represent the same accepted state, not two independently mutable authorities. See docs/FIVE_EQ_TEMPORAL_CONTRACT.md, FIVE_EQ_INITIALIZATION_CONTRACT.md and FIVE_EQ_RESTART_CONTRACT.md for startup/IO flags and metadata requirements.
