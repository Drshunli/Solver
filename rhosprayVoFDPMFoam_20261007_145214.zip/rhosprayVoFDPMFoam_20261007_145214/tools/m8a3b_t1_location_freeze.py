from pathlib import Path
import json,csv,math
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t1_v1'
p=e/'mapping_contract.json';contract=json.loads(p.read_text())
if (e/'mapping_before_location_input.json').exists():raise SystemExit('Refusing to apply twice')
(e/'mapping_before_location_input.json').write_bytes(p.read_bytes())
design={'providedLabel':'DESIGN_INPUT_PROPOSAL','source':'PROJECT_DESIGN_INPUT','xNozzle_mm':15.0,'wall':'bottom_wall','wall_y_mm':0.,'fluid_entry_direction':[0,1,0],'injection_direction':'+y','inferredFromTestDPM':False,'adoption':'explicit user response adopted as geometry design source for T1'}
(e/'user_design_input.json').write_text(json.dumps(design,indent=2))
x=.015;w=contract['mappingA']['idealWidth_m'];lo=x-w/2;hi=x+w/2
rows=list(csv.DictReader((e/'bottom_wall_faces.csv').open()))
for r in rows:
    for key in list(r):r[key]=int(r[key]) if key=='face' else float(r[key])
inside=[r for r in rows if r['xMin_m']>=lo and r['xMax_m']<=hi]
cover=[r for r in rows if r['xMax_m']>lo and r['xMin_m']<hi]
touch=[r for r in cover if r not in inside]
A=contract['physicalReference']['A_m2'];rho=contract['physicalReference']['rhoReference_kg_m3'];mdot=contract['physicalReference']['mdot_kg_s'];uref=contract['physicalReference']['UReference_m_s'];depth=contract['mappingA']['numericalDepth_m']
def describe(name,faces):
    area=sum(r['area_m2'] for r in faces);center=sum(.5*(r['xMin_m']+r['xMax_m'])*r['area_m2'] for r in faces)/area
    return {'name':name,'role':'AUDIT CANDIDATE ONLY / NOT SELECTED PRODUCTION PATCH','faceIDs':[r['face'] for r in faces],'count':len(faces),'xInterval_m':[min(r['xMin_m'] for r in faces),max(r['xMax_m'] for r in faces)],'center_m':[center,0.,.015],'area_m2':area,'relativeAreaError':area/A-1,'centerError_m':center-x,'widthError_m':area/depth-w,'referenceURequired_m_s':mdot/(rho*area),'relativeReferenceVelocityChange':mdot/(rho*area)/uref-1}
candidates=[describe('contained whole faces',inside),describe('covering whole faces',cover)]
clippedArea=sum(max(0.,min(r['xMax_m'],hi)-max(r['xMin_m'],lo))*depth for r in cover)
assert len(inside)==28 and len(cover)==30 and len(touch)==2
assert abs(clippedArea-A)<1e-20
assert all(abs(r['centerError_m'])<1e-14 for r in candidates)
geometry={'status':'FROZEN IDEAL FUTURE GEOMETRY / NOT IMPLEMENTED','source':'PROJECT_DESIGN_INPUT','center_m':[x,0.,.015],'width_m':w,'xInterval_m':[lo,hi],'zInterval_m':[.014975,.015025],'outwardNormal':[0,-1,0],'fluidEntryDirection':[0,1,0],'idealArea_m2':A,
 'exactWholeFaceRepresentable':False,'idealEdgesLieInsideFaces':[r['face'] for r in touch],'auditCandidates':candidates,'clippedGeometricIntersectionArea_m2':clippedArea,
 'implementationRequirement':'future separately authorized mesh-face splitting at ideal x edges to preserve exact Mapping-A; no quantized fallback selected; mathematical clipped intersections are not current patch faces',
 'wholeFaceApproximationApproved':False,'acceptanceTolerance':None,'noActiveMeshEdit':True}
contract['status']='COMPLETE / DESIGN ONLY'
contract['location']={'xNozzle_m':x,'wall':'bottomWall','yNozzle_m':0.,'fluidEntryDirection':[0,1,0],'source':'PROJECT_DESIGN_INPUT / explicit user response','status':'FROZEN DESIGN','originalInputLabel':'DESIGN_INPUT_PROPOSAL'}
contract['futurePatchGeometry']=geometry
contract['wallCensus']['candidateNozzleFaces']=candidates
contract['wallCensus']['representedPatchArea_m2']='28-face and 30-face audit candidates: see futurePatchGeometry; neither production-selected'
contract['runtimeStressTopology']['status']='GEOMETRY RULE NOW DEFINABLE / NOT CREATED THIS STAGE'
contract['runtimeStressTopology']['center_m']=[x,0.,.015];contract['runtimeStressTopology']['fluidEntryDirection']=[0,1,0]
contract['supportScanMayResume']=True
contract['supportScanScope']='next separately requested support-only scan using frozen ideal Eulerian footprint; no scan performed in T1'
contract['transactionMayResume']=False
contract['transactionBlocker']='full new topology support gate and remaining M8A.3B gates still unproved; T1 does not authorize transaction continuation'
contract['checks']+=4
p.write_text(json.dumps(contract,indent=2));(e/'patch_representability.json').write_text(json.dumps(geometry,indent=2))
print(json.dumps({'status':contract['status'],'idealInterval':geometry['xInterval_m'],'splitFaces':geometry['idealEdgesLieInsideFaces'],'candidates':candidates,'clippedArea':clippedArea},indent=2))
