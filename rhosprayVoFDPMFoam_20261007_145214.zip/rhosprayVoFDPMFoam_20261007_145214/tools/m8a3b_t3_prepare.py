from pathlib import Path
import hashlib,json,shutil
b=Path(__file__).resolve().parents[1]
e=b/'fitting/dpm/m8a3b_t3_v1'
if (e/'protected_before.json').exists():
 raise RuntimeError('Frozen T3 evidence exists; use a new version directory, never overwrite it')
e.mkdir(exist_ok=True)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
protected={str(p.relative_to(b)):digest(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_t3_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()}
(e/'protected_before.json').write_text(json.dumps(protected,indent=2),encoding='utf8')
(e/'case_before.json').write_text(json.dumps({str(p.relative_to(b.parent/'300_2D')):digest(p) for p in (b.parent/'300_2D').rglob('*') if p.is_file()},indent=2),encoding='utf8')
t=b/'tests/fiveEqDPMSerialTransaction';(t/'Make').mkdir(parents=True,exist_ok=True)
(t/'Make/options').write_bytes((b/'tests/fiveEqDPMRebinding/Make/options').read_bytes().replace(b'EXE_INC =',b'EXE_INC = \\\n    -I../fiveEqDPMRebinding'))
(t/'Make/files').write_bytes((b/'tests/fiveEqDPMNative/Make/files').read_bytes().replace(b'testFiveEqDPMNative',b'testFiveEqDPMSerialTransaction'))
for state in 'ABC':
 for folder in ('0','constant','system'):
  shutil.copytree(b/'tests/fiveEqDPMRebinding'/('fixture'+state)/folder,e/'fixtures'/state/folder)
 # Cloud logical roles need independent native dictionary names, never rename registry objects.
 for role in ('roleA','roleB','referenceA','referenceB'):
  shutil.copyfile(e/'fixtures'/state/'constant/sprayCloudProperties',e/'fixtures'/state/'constant'/(role+'Properties'))
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqDPMSerialTransaction"\nwmake > "$base/fitting/dpm/m8a3b_t3_v1/log.wmake" 2>&1\n').encode())
(e/'read_sources.sh').write_bytes((head+'src=$FOAM_SRC\nfind "$src" -name ReitzKHRT.C -o -name ORourkeCollision.C -o -name BlobsSheetAtomization.C -o -name Random.H -o -name RandomI.H | while read -r file; do cat "$file"; done > "$base/fitting/dpm/m8a3b_t3_v1/native_event_sources.txt"\n').encode())
for name in ('run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh'):
 (e/name).write_bytes((b/'fitting/dpm/m8a3a_v1'/name).read_bytes().replace(b'm8a3a_v1',b'm8a3b_t3_v1'))
(e/'run_rebinding.sh').write_bytes((b/'fitting/dpm/m8a3b_t2_v1/run_rebinding.sh').read_bytes().replace(b'm8a3b_t2_v1',b'm8a3b_t3_v1'))
for state in 'ABC':
 for folder in ('0','constant','system'):
  shutil.copytree(e/'fixtures'/state/folder,e/'rebinding_fixtures'/state/folder)
print(e)
