"""Offline final native R1 gate. Read evidence; never repair state or weight."""
from pathlib import Path
import csv, json, hashlib, math, difflib
root=Path(__file__).resolve().parents[2]
b=root/'rhosprayVoFDPMFoam'
s=b/'fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1'
checks={}
def check(k,v): checks[k]=bool(v)
def j(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p): return list(csv.reader(p.open()))
def allrows(c,n): return [r for p in c.glob('processor*/'+n) for r in rows(p)]
def final(c):
 ds=[j(p) for p in c.glob('processor*/native_crossing_result.json')]
 return len(ds)==2 and all(d['globalFailures']==0 and d['live']==d['liveBaseline'] and d['constructed']-d['destroyed']==d['liveBaseline'] for d in ds)
def discard(c):
 rs=allrows(c,'N1_discard.csv')
 return len(rs)>=2 and all(r[1]=='1' and r[2:5]==['0','0','0'] for r in rs)
c=s/'pilot_corrected'
check('pilot_normal_exit',int((s/'exit.pilot').read_text())==0)
check('pilot_full_boundary_oracle',j(s/'boundary.pilot_corrected.json')['status']=='PASS')
rng=[json.loads(line) for p in c.glob('processor*/R1_rng_next.jsonl') for line in p.read_text().splitlines()]
check('weighted_same_parcel_next_result',len(rng)==50 and all(r['equal']==1 and r['cachedNormalCompared'] and r['pre']==r['actualPre'] and r['referencePost']==r['actualPost'] for r in rng))
check('fresh_next_random_draw',any(r['randomUpdate']==1 for r in rng) and all(any(x!=0 for x in r['UTurb']) for r in rng))
check('full_RNG_x_flag_cached_value',all(len(r['pre'].split())==len(r['actualPost'].split())==3 for r in rng))
models=allrows(c,'R1_fresh_models.csv');continuation=allrows(c,'R1_continuation.csv')
check('fresh_stochastic_nonzero',any(int(r[3])>0 for r in models))
check('fresh_stochastic_RNG_changed',any(r[1]!=r[2] for r in models))
check('fresh_dispersion_calls_consumption',all(sum(int(r[k]) for r in continuation)>0 for k in [5,6]))
check('fresh_native_ORourke_updates',any(int(r[4])>0 for r in models))
check('fresh_native_KH_calls',sum(int(r[8]) for r in continuation)>0)
drag=allrows(c,'R1_fresh_drag.csv')
check('fresh_native_drag_source',len(drag)>0 and all(all(math.isfinite(float(r[k])) and float(r[k])>0 for k in [2,3,4,5]) for r in drag))
dragError=max(float(r[6])/float(r[5]) for r in drag)
check('drag_weighted_once_actual_segment',dragError<=1e-12)
pw=b/'fitting/dpm/m8a3b_t4_s2_pw1_native_v1/candidate_final'
check('candidate_physical_dictionaries_unchanged',all((c/'constant'/n).read_bytes()==(pw/'constant'/n).read_bytes() for n in ['roleAProperties','roleBProperties']))
check('candidate_rate_50',all('parcelsPerSecond 50;' in (c/'constant'/n).read_text() for n in ['roleAProperties','roleBProperties']))
check('native_pre_probe_trajectory_unchanged',all((c/f'processor{rank}/R1_trajectory.csv').read_bytes()==(pw/f'processor{rank}/R1_trajectory.csv').read_bytes() for rank in [0,1]))
birth=allrows(c,'PW1_births.csv');steps=allrows(c,'PW1_steps.csv')
check('bounded_native_injection',len(birth)==50 and all(r[3]==r[4] and int(r[3])<=10 for r in steps))
check('native_weight_positive_unique',len({tuple(r[2:4]) for r in birth})==50 and all(float(r[4])>0 and math.isfinite(float(r[4])) for r in birth))
check('physical_mass_preserved',abs(math.fsum(float(r[7]) for r in birth)/.0005262723452-1)<=1e-12)
runs=[]
for case in sorted((s/'independent_runs').glob('run_*')):
 name=case.name;gate=j(s/f'gate.{name}.json');boundary=j(s/f'boundary.{name}.json')
 wall=float((s/f'wall.{name}').read_text())
 check(name+'_normal_no_timeout',int((s/f'exit.{name}').read_text())==0 and wall<55)
 check(name+'_native_crossing_ownership',gate['status']==boundary['status']=='PASS' and gate['crossings']==boundary['events']==50)
 check(name+'_final_lifetime_registry_rollback',final(case) and discard(case))
 check(name+'_native_theta_all_segments',all(r[1]=='1' for r in allrows(case,'PW1_void.csv')))
 runs.append({'name':name,'crossings':gate['crossings'],'births':gate['births'],'wallSeconds':wall,'direction':boundary['directions']})
check('independent_bounded_1000',len(runs)==20 and sum(r['crossings'] for r in runs)>=1000)
void=allrows(c,'PW1_void.csv');voidMoves=sum(int(r[2]) for r in void)
check('repeated_VoidFraction_native_segments',voidMoves>10 and all(r[1]=='1' for r in void) and j(s/'boundary.pilot_corrected.json')['events']>=10)
check('pilot_final_lifetime_registry_rollback',final(c) and discard(c))
rb=s/'rollback_bounded'
check('nonempty_weighted_rollback_normal_exit',int((s/'exit.rollback_bounded').read_text())==0)
check('nonempty_weighted_accepted_bit_exact',all((rb/f'processor{rank}/PW1_accepted_before.txt').read_bytes()==(rb/f'processor{rank}/PW1_accepted_after_discard.txt').read_bytes() for rank in [0,1]) and sum((rb/f'processor{rank}/PW1_accepted_before.txt').stat().st_size for rank in [0,1])>0)
check('nonempty_full_codec_allocator_RNG_pending_registry_lifetime',final(rb) and discard(rb))
check('rollback_physical_dictionaries_preserved',all((rb/'constant'/n).read_bytes()==(pw/'constant'/n).read_bytes() for n in ['roleAProperties','roleBProperties']))
reg={}
for name,file in [('k1','event_result.json'),('c2','basic_result.json'),('i1','gate_result.json'),('r2b','test_results.json')]:
 d=j(s/'regressions'/name/file);reg[name]=d
 check('fresh_'+name,int((s/f'exit.{name}').read_text())==0 and d['failures']==0)
kh=j(s/'regressions/k1/identity_result.json')
check('fresh_KH_child_path',kh['births']>=2 and kh['births']==kh['identityNegativeChecks'] and kh['laterChildQueries']>0)
reg['KH_identity']=kh
for name,folder in [('s1','reg_fixture_s1'),('s1_topology','reg_fixture_topology'),('n1_valid','n1_valid'),('n1_forward','n1_forward'),('n1_reverse','n1_reverse')]:
 check('fresh_'+name,int((s/f'exit.{name}').read_text())==0)
 if name.startswith('n1'):check('fresh_'+name+'_ownership_lifetime',final(s/folder) and discard(s/folder))
 if name in ['s1','s1_topology']:
  filename='support_result.json' if name=='s1' else 'topology_result.json'
  ds=[j(p) for p in (s/folder).glob('processor*/'+filename)]
  check('fresh_'+name+'_assertions',len(ds)==2 and all(d['globalFailures']==0 for d in ds))
  reg[name]=ds
for name,count in [('installed_source_verification.txt',6717),('native_parcel_verification.txt',19)]:
 lines=(s/name).read_text().splitlines();check(name,len(lines)==count and all(x.endswith(': OK') for x in lines))
before=j(s/'frozen_before.json')
changed=[k for k,h in before.items() if not (root/k).is_file() or sha(root/k)!=h]
check('frozen_active_production_unchanged',not changed)
old=b/'tests/fiveEqDPMPW1Native';new=b/'tests/fiveEqDPMR1QualifiedNative';delta=[]
for p in old.rglob('*'):
 if p.is_file() and not any(x in p.parts for x in ['linux64GccDPInt32Opt','lnInclude']) and p.suffix not in ['.o','.dep'] and p.name!='testPW1Native':
  rel=p.relative_to(old);q=new/rel
  if not q.exists() or sha(p)!=sha(q):delta.append(rel.as_posix())
check('isolated_main_Make_only',set(delta)=={'testNewbornIdentity.C','Make/files'})
(s/'native_observer.diff').write_text(''.join(difflib.unified_diff((old/'testNewbornIdentity.C').read_text().splitlines(True),(new/'testNewbornIdentity.C').read_text().splitlines(True),fromfile='frozen_PW1',tofile='isolated_R1_observer')))
result={'status':'R1 FINAL COMPLETE' if all(checks.values()) else 'R1 PARTIAL','checks':checks,'failed':[k for k,v in checks.items() if not v],'runs':runs,'stressCrossings':sum(r['crossings'] for r in runs),'pilotCrossings':j(s/'boundary.pilot_corrected.json')['events'],'RNGNextRecords':len(rng),'dragSegments':len(drag),'dragMaximumRelativeResidual':dragError,'pilotVoidSegments':voidMoves,'regressions':reg,'protectedEntries':len(before),'unexpectedChanges':changed,'sourceDelta':delta,'RNGScope':'same-parcel native no-migration next-update control on destination owner; not independent whole serial cloud trajectory or rank RNG synchronization','activeImpact':'NONE','productionImpact':'NONE','S2':'PARTIAL','T4':'PARTIAL','globalTransactionCertified':False,'CFD':False}
(s/'R1_FINAL_gate.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','runs']},indent=2))
raise SystemExit(bool(result['failed']))
