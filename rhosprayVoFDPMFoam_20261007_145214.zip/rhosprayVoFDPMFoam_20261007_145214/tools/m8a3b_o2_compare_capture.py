from pathlib import Path
import difflib,json
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2_v1'
a=(e/'O1_A_collision_entry.txt').read_bytes();c=(e/'results/A/captured_native_entry.txt').read_bytes()
print('byte lengths',len(a),len(c),'normalized text equal',a.decode().replace('\r\n','\n')==c.decode().replace('\r\n','\n'))
for i,(x,y) in enumerate(zip(a,c)):
 if x!=y:print('first byte',i,repr(a[max(0,i-50):i+80]),repr(c[max(0,i-50):i+80]));break
d=''.join(difflib.unified_diff(a.decode().splitlines(True),c.decode().splitlines(True)))
(e/'capture_difference_attempt2.diff').write_text(d);print(d[:1500])
