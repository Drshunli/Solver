"""Offline, fail-closed bounded native run validator. No state correction."""
from pathlib import Path
import csv,json,sys,math,collections
c=Path(sys.argv[1]);errors=[];groups=collections.defaultdict(lambda:collections.defaultdict(list))
def rows(p):return list(csv.reader(p.open()))
for p in c.glob('processor*/native_crossing_result.json'):
 d=json.loads(p.read_text())
 if d['globalFailures'] or d['live']!=d['liveBaseline']:errors.append('native_result_or_final_lifetime')
for p in c.glob('processor*/R1_boundary.csv'):
 for r in rows(p):groups[tuple(r[3:5])][(r[1],r[2])].append(r)
crossings=0
for identity,g in groups.items():
 for source in ['0','1']:
  dest=str(1-int(source));quartets=[g[(stage,rank)] for stage,rank in [('SEND_BEFORE_PREPARE',source),('SEND_AFTER_PREPARE',source),('RECEIVE_BEFORE_CORRECT',dest),('RECEIVE_AFTER_CORRECT',dest)]]
  if len({len(x) for x in quartets})!=1:errors.append('MPI_OWNERSHIP_BOUNDARY_COUNT');continue
  for a,b,d,e in zip(*quartets):
   crossings+=1
   if b[15:-1]!=d[15:-1] or b[-1]!=d[-1] or a[19:-1]!=e[19:-1]:errors.append('NPARTICLE_OR_NATIVE_STATE_CORRUPTION')
   if a[12]!=b[12] or d[12]!=e[12]:errors.append('PREPARE_CORRECT_RNG_CHANGE')
   if a[3:5]!=e[3:5]:errors.append('IDENTITY_CORRUPTION')
birth=[]
for p in c.glob('processor*/PW1_births.csv'):birth+=rows(p)
if len({tuple(r[2:4]) for r in birth})!=len(birth):errors.append('DUPLICATE_IDENTITY')
if any(not math.isfinite(float(r[4])) or float(r[4])<=0 for r in birth):errors.append('NPARTICLE_CORRUPTION')
for p in c.glob('processor*/PW1_steps.csv'):
 for r in rows(p):
  if int(r[3])>1000 or r[3]!=r[4]:errors.append('INJECTION_POPULATION_BLOCKER')
for p in c.glob('processor*/PW1_void.csv'):
 if any(r[1]!='1' for r in rows(p)):errors.append('THETA_WEIGHTING_BLOCKER')
for p in c.glob('processor*/N1_discard.csv'):
 if any(r[1]!='1' or r[2:5]!=['0','0','0'] for r in rows(p)):errors.append('DISCARD_LIFETIME_REGISTRY_BLOCKER')
if len(list(c.glob('processor*/native_crossing_result.json')))!=2:errors.append('INCOMPLETE_RUN')
if crossings<10:errors.append('INSUFFICIENT_CROSSINGS')
print(json.dumps({'status':'PASS' if not errors else 'FAIL','crossings':crossings,'births':len(birth),'errors':errors},indent=2))
raise SystemExit(bool(errors))
