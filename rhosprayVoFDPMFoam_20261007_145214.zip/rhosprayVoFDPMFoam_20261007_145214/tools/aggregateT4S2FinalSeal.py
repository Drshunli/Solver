"""Read-only aggregation of sealed S2 evidence. Never launch physics or edit runtime."""
from pathlib import Path
import hashlib,json,csv,zipfile,subprocess,sys,struct
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/dpm/m8a3b_t4_s2_final_seal_v1'
r=b/'fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1'
w=b/'fitting/dpm/m8a3b_t4_s2_pw1_native_v1'
z=b/'fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1'
i=b/'fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_text())
def rows(p):return list(csv.reader(p.open()))
def rr(c,n):return [x for p in c.glob('processor*/'+n) for x in rows(p)]
checks={}
def check(k,v):checks[k]=bool(v)
before=j(s/'frozen_before.json')
changed=[k for k,h in before.items() if not (root/k).is_file() or sha(root/k)!=h]
check('all_30535_frozen_entries_unchanged',not changed)
# The R1 list omits common P2/recovery/KT source files. Resolve their historical
# hashes through a pinned T3 dependency manifest and immutable nested archives.
anchor=b/'fitting/dpm/m8a3b_t3b_r2_final_replay_v2/dependency_manifest.json'
check('common_source_chain_anchor_frozen',before.get(anchor.relative_to(root).as_posix())==sha(anchor))
chain=[];chainDir=s/'common_source_chain';chainDir.mkdir(exist_ok=True)
expected=j(anchor)['M8A3B_T3BR2C_C2_NATIVE_SEMANTIC_BINARY_COMPLETE_v1.zip']['sha256']
for name,nextName in [('M8A3B_T3BR2C_C2_NATIVE_SEMANTIC_BINARY_COMPLETE_v1.zip','M8A3B_T3BR2B_lazy_tracking_COMPLETE_v1.zip'),('M8A3B_T3BR2B_lazy_tracking_COMPLETE_v1.zip','M8A3B_T3BR2_serial_gate_PARTIAL_v1.zip')]:
 archive=root/'checkpoints'/name;actual=sha(archive);check(name+'_source_chain_archive',actual==expected)
 with zipfile.ZipFile(archive) as f:
  entry=next(n for n in f.namelist() if n.endswith('checkpoint_manifest.json'));data=f.read(entry);m=json.loads(data)
  copied=chainDir/(name+'.manifest.json');copied.write_bytes(data)
  nextDep=next(d for d in m['dependencies'] if Path(d.get('path',d.get('file'))).name==nextName)
  chain.append({'archive':str(archive),'archiveSHA256':actual,'expectedSHA256':expected,'member':entry,'memberSHA256':hashlib.sha256(data).hexdigest(),'nextDependency':nextDep})
  expected=nextDep['sha256']
oldArchive=root/'checkpoints/M8A3B_T3BR2_serial_gate_PARTIAL_v1.zip'
check('common_source_baseline_archive',sha(oldArchive)==expected)
with zipfile.ZipFile(oldArchive) as f:
 entry='rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2_v1/protected_before.json';data=f.read(entry)
 common={('rhosprayVoFDPMFoam/'+k.replace('\\','/')):h for k,h in json.loads(data).items()}
 (chainDir/'common_protected_before.json').write_bytes(data)
 chain.append({'archive':str(oldArchive),'archiveSHA256':sha(oldArchive),'expectedSHA256':expected,'member':entry,'memberSHA256':hashlib.sha256(data).hexdigest()})
(s/'common_source_chain.json').write_text(json.dumps({'anchor':str(anchor),'anchorSHA256':sha(anchor),'chain':chain},indent=2))
active={}
for name in ['rhosprayVoFDPMFoam.C','rhoEqn.H','rhoUEqn.H','rhoEEqn.H','rhoYEqn.H','alphaEqn.H']:
 key='rhosprayVoFDPMFoam/'+name;active[key]={'historical':common.get(key),'current':sha(root/key)}
check('active_equations_historical_bytes_unchanged',all(v['historical']==v['current'] for v in active.values()))
(s/'active_source_audit.json').write_text(json.dumps(active,indent=2))
parents={}
for name,folder in [('R1_FINAL',r),('PW1',w),('ZS1',z),('ID1',i)]:
 meta=j(folder/'checkpoint_seal.json');archive=Path(meta.get('archive',meta.get('path')))
 expected=meta.get('sha256',meta.get('SHA256'))
 check(name+'_archive_sha',sha(archive)==expected)
 with zipfile.ZipFile(archive) as f:
  check(name+'_archive_crc',f.testzip() is None)
  check(name+'_archive_unique',len(f.namelist())==len(set(f.namelist())))
  # R1/PW1/ZS1 use a manifest embedded in the immutable parent ZIP.
  manifests=[n for n in f.namelist() if n.endswith('/checkpoint_manifest.json')]
  if manifests:
   m=json.loads(f.read(manifests[0]));check(name+'_archive_manifest',all(hashlib.sha256(f.read(k)).hexdigest()==h for k,h in m.items()))
  else:
   # ID1's older seal stores per-file hashes under a different artifact name.
   sealkey=(folder/'checkpoint_seal.json').relative_to(root).as_posix()
   check(name+'_archive_frozen_sha',before.get(sealkey)==sha(folder/'checkpoint_seal.json') and sha(archive)==expected)
 parents[name]={'archive':str(archive),'sha256':expected,'entries':meta['entries'],'CRC':'PASS' if checks[name+'_archive_crc'] else 'FAIL'}
foundation=j(s/'foundation_native_source_manifest.json')
for name,count in [('installed_source_verification.txt',6717),('native_parcel_verification.txt',19)]:
 lines=(s/name).read_text().splitlines();check(name,len(lines)==count and all(x.endswith(': OK') for x in lines))
gate=j(r/'R1_FINAL_gate.json');pw=j(w/'PW1_gate.json');zs=j(z/'ZS1_gate.json');id1=j(i/'identity_acceptance_audit.json')
check('R1_sealed_complete',gate['status']=='R1 FINAL COMPLETE' and not gate['failed'] and all(gate['checks'].values()))
check('PW1_sealed_complete',pw['status']=='COMPLETE / OF7-NATIVE WEIGHTED PARCEL QUALIFIED' and not pw['failed'])
check('ZS1_sealed_complete',zs['status']=='COMPLETE' and not zs['failed'])
check('ID1_acceptance_authority',id1['fullPairUniqueness'] and id1['nativeAllocatorStep'] and id1['directRetryFullAcceptedStateEquality'] and id1['normalRejectedAllocatorRestore'] and id1['sourceBornChildNativeTransfer'])
# Pin actual project compilation dependencies, not a filename-only summary.
(s/'source_manifests').mkdir(exist_ok=True)
targets={'R1_NATIVE':('fiveEqDPMR1QualifiedNative','testR1QualifiedNative',r),'R1_ROLLBACK':('fiveEqDPMR1QualifiedRollback','testR1QualifiedRollback',r),'K1':('fiveEqDPMR1QualifiedK1','testKHSupportK1',r),'C2':('fiveEqDPMR1QualifiedC2','testParcelCodec',r),'I1':('fiveEqDPMR1QualifiedI1','testI1Gate',r),'R2B':('fiveEqDPMR1QualifiedR2B','testLazyCarrier',r),'N1':('fiveEqDPMR1QualifiedN1','testFailureDisposition',r),'S1':('fiveEqDPMR1QualifiedS1Support','testSupport',r),'TOPOLOGY':('fiveEqDPMR1QualifiedS1Topology','testTopology',r),'PW1':('fiveEqDPMPW1Native','testPW1Native',w),'ZS1':('fiveEqDPMZS1Native','testZS1Native',z),'ID1':('fiveEqDPMID1FixtureNative','testID1FixtureNative',i)}
provenance={}
for label,(target,exe,authority) in targets.items():
 t=b/'tests'/target;p=t/exe
 # Historical targets may name their executable differently; use sealed Make/files.
 if not p.is_file():
  executable=(t/'Make/files').read_text().split('EXE = $(PWD)/')[-1].strip();p=t/executable
 files={t/'Make/files',t/'Make/options'}
 for dep in (t/'Make').rglob('*.dep'):
  for line in dep.read_text().splitlines()[1:]:
   v=line.strip().removesuffix('\\').strip()
   if not v or '$' in v or v.startswith('/'):continue
   q=(t/v).resolve()
   if q.is_file() and q.is_relative_to(root):files.add(q)
 for line in (t/'Make/files').read_text().splitlines():
  if line.strip().endswith('.C'):
   q=(t/line.strip()).resolve()
   if q.is_file():files.add(q)
 manifest={q.relative_to(root).as_posix():sha(q) for q in sorted(files)}
 check(label+'_current_source_and_exe_frozen',p.is_file() and before.get(p.relative_to(root).as_posix())==sha(p) and all(before.get(k,common.get(k))==h for k,h in manifest.items()))
 # The ZS1 compatible reverse must consume the same critical shared source.
 historical=j(authority/'frozen_after.json');delta={k:{'authority':historical.get(k,common.get(k)),'current':h} for k,h in manifest.items() if historical.get(k,common.get(k))!=h}
 if label=='ID1':
  allowed={'rhosprayVoFDPMFoam/tests/fiveEqDPMParcelC2/parcel/LazySprayParcel.C'}
  check('ID1_only_frozen_ZS1_compatibility_delta',set(delta)<=allowed)
 else:check(label+'_source_matches_authority',not delta)
 file=s/'source_manifests'/f'{label}.json';file.write_text(json.dumps(manifest,indent=2))
 provenance[label]={'executable':str(p),'executableSHA256':sha(p),'projectSourceManifest':str(file),'projectSourceManifestSHA256':sha(file),'projectFiles':len(manifest),'authoritySourceDifferences':delta,'commonSourceAuthority':str(s/'common_source_chain.json'),'foundationManifest':str(s/'foundation_native_source_manifest.json'),'foundationManifestSHA256':sha(s/'foundation_native_source_manifest.json')}
critical='rhosprayVoFDPMFoam/tests/fiveEqDPMParcelC2/parcel/LazySprayParcel.C'
shared=sha(root/critical)
check('reverse_final_shared_source_identical',shared==j(z/'source_delta.json')['after_sha256']==j(z/'frozen_after.json')[critical]==j(r/'frozen_after.json')[critical])
# Re-evaluate native boundary semantics without touching inherited evidence.
boundary={}
cases=[('valid_reverse_ZS1',z/'mpi_zero'),('R1_pilot',r/'pilot_corrected')]+[(p.name,p) for p in sorted((r/'independent_runs').glob('run_*'))]
for label,case in cases:
 result=subprocess.run([sys.executable,str(b/'tools/auditS2R1Boundary.py'),str(case)],capture_output=True,text=True)
 d=json.loads(result.stdout);boundary[label]=d
 check(label+'_boundary_reaudit',result.returncode==0 and d['status']=='PASS')
check('valid_reverse_not_invalid_rejection',boundary['valid_reverse_ZS1']['directions'].get('1->0')==1 and int((z/'exit.mpi_zero.txt').read_text())==0 and all(j(p)['globalFailures']==0 for p in (z/'mpi_zero').glob('processor*/native_crossing_result.json')))
stress=[]
for p in sorted((r/'independent_runs').glob('run_*')):
 d=j(r/f'gate.{p.name}.json');wall=float((r/f'wall.{p.name}').read_text())
 check(p.name+'_stress_complete',int((r/f'exit.{p.name}').read_text())==0 and wall<55 and d['status']=='PASS' and d['crossings']==50 and boundary[p.name]['directions']=={'0->1':50})
 births=rr(p,'PW1_births.csv');owners=[x for x in rr(p,'native_crossing.csv') if x[0]=='after']
 check(p.name+'_no_loss_one_owner',len(owners)==50 and len({tuple(x[2:4]) for x in owners})==50 and {tuple(x[2:4]) for x in owners}=={tuple(x[2:4]) for x in births})
 stress.append({'run':p.name,'crossings':d['crossings'],'wallSeconds':wall})
check('twenty_independent_1000_forward',len(stress)==20 and sum(x['crossings'] for x in stress)==1000)
c=r/'pilot_corrected';fresh=rr(c,'R1_fresh_models.csv');continuation=rr(c,'R1_continuation.csv')
last=[rows(p)[-1] for p in c.glob('processor*/R1_continuation.csv')]
models={n:sum(int(x[k]) for x in last) for n,k in [('drag',4),('stochastic',5),('rngConsumingUpdates',6),('blobsSheet',7),('KH',8)]}
models['rebound']=sum(int(rows(p)[-1][5]) for p in c.glob('processor*/R1_fresh_models.csv'))
check('blobsSheet_and_native_rebound_evidence',models['blobsSheet']>0 and models['rebound']>0)
adapter=(b/'tests/fiveEqDPMParcelC2/modelAdapters.H').read_text()
check('model_delegates_native',all(x in adapter for x in ['Foam::Rebound<Kin>::correct','Foam::BlobsSheetAtomization<Cloud>::update','Foam::SphereDragForce<Kin>::calcCoupled','Foam::StochasticDispersionRAS<Kin>::update']))
check('weighted_migrated_core_transition',all(x[42]=='0' for x in rr(c,'R1_boundary.csv') if x[1]=='RECEIVE_AFTER_CORRECT') and models['blobsSheet']==50)
check('no_manual_seed_in_injection_authority','-nativeInjectionProbe' in (r/'pilot.sh').read_text())
for name,destination in [('n1_forward',1),('n1_reverse',0)]:
 p=r/name
 latch=j(p/f'processor{destination}/C1_latch.json');line=rows(p/f'processor{destination}/C1_cycles.csv')[1]
 phases=[x[1] for x in rows(p/f'processor{destination}/C1_phases.csv')]
 check(name+'_support_before_thermo',latch['reason']=='GAS_SUPPORT_INVALID:EXACT_GAS_ABSENT' and latch['failed']==1 and latch['trialRejected']==1 and all(x=='0' for x in line[5:12]))
 expected=['NATIVE_MOVE_RETURNED','FAILURE_REDUCTION_ENTER','FAILURE_REDUCTION_EXIT','FIXTURE_DISCARD','FINALIZE']
 check(name+'_communication_safe_reject',all(x in phases for x in expected) and [phases.index(x) for x in expected]==sorted(phases.index(x) for x in expected))
 check(name+'_normal_discard',int((r/f'exit.{name}').read_text())==0 and all(j(q)['globalFailures']==0 for q in p.glob('processor*/native_crossing_result.json')) and all(x[1]=='1' and x[2:5]==['0','0','0'] for x in rr(p,'N1_discard.csv')))
check('identity_native_allocator',(b/'dpmFiveEq/KHNewbornIdentityV1.H').read_text().count('child.getNewParticleID()')==1)
check('no_new_runtime_delta',not changed)
# Architecture statements reference inspected implementations and fixed source hashes.
native=(s/'foundation_native_source_read.txt').read_text()
check('native_transport_inspected',all(x in native for x in ['ParticleType::iNew','PstreamBuffers','UOPstream','UIPstream','prepareForParallelTransfer','correctAfterParallelTransfer']))
check('rank_local_transaction_not_global',gate['globalTransactionCertified'] is False and id1['globalMPITransactionCertified'] is False)
(s/'authority_provenance.json').write_text(json.dumps(provenance,indent=2))
(s/'inherited_archives_audit.json').write_text(json.dumps(parents,indent=2))
(s/'boundary_reaudit.json').write_text(json.dumps(boundary,indent=2))
(s/'compatibility_audit.json').write_text(json.dumps({'criticalSharedSource':critical,'criticalSharedSHA256':shared,'ZS1_matches_R1':checks['reverse_final_shared_source_identical'],'ID1_ZS1_birth_parity':j(z/'trajectory_birth_parity.json')['birth'],'currentSourcesPinnedByFrozenR1':True},indent=2))
commonUsed={k:h for v in provenance.values() for k,h in j(Path(v['projectSourceManifest'])).items() if k not in before}
check('all_common_sources_match_archived_baseline',all(common.get(k)==h for k,h in commonUsed.items()))
(s/'common_source_current_hashes.json').write_text(json.dumps(commonUsed,indent=2))
failed=[k for k,v in checks.items() if not v]
out={'status':'COMPLETE / FROZEN' if not failed else 'PARTIAL','checks':checks,'failed':failed,'protectedEntries':len(before),'unexpectedChanges':changed,'sourceProvenance':provenance,'parentArchives':parents,'stress':stress,'stressCrossings':sum(x['crossings'] for x in stress),'validReverse':boundary['valid_reverse_ZS1'],'models':models,'newPhysicsRuns':0,'newCompilations':0,'activeImpact':'NONE','productionImpact':'NONE','customMPITransport':False,'customMPISerializer':False,'existingLocalTransactionCodec':'transactionState-v1 retained; not used for MPI parcel transport','globalTransactionCertified':False,'T4':'PARTIAL','M8A':'PARTIAL','S3':'NOT AUTHORIZED / NOT EXECUTED','M6B':False,'CFD':False,'productionRestart':'NOT CERTIFIED'}
(s/'S2_FINAL_gate.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k] for k in ['status','failed','protectedEntries','stressCrossings','validReverse','models','newPhysicsRuns','newCompilations']},indent=2))
raise SystemExit(bool(failed))
