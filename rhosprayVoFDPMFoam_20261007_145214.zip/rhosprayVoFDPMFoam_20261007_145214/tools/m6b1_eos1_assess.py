from pathlib import Path
import sys,json,csv,hashlib,math
import numpy as np
from numpy.polynomial import chebyshev as ch
b=Path(__file__).resolve().parents[1];sys.path.insert(0,str(b/'fitting/reference_backend'))
import CoolProp,CoolProp.CoolProp as CP
from scipy.optimize import brentq
s=b/'fitting/integration/m6b1_eos1_ndecane_v1';src=b/'liquidEOS/ndecane_gibbs_v1'
meta=json.loads((src/'coefficients.json').read_text());coef=np.array(meta['coefficients']);pc,ps,tc,ts=[meta[x] for x in ['pCenter','pScale','TCenter','TScale']];offset=369229.9537234281
d={(i,j):ch.chebder(ch.chebder(coef,m=i,axis=0),m=j,axis=1)/ps**i/ts**j for i,j in [(0,0),(1,0),(0,1),(2,0),(1,1),(0,2)]}
def poly(p,T):
 g,v,gt,gpp,gpt,gtt=[ch.chebval2d((p-pc)/ps,(T-tc)/ts,d[x]) for x in d]
 cp=-T*gtt;cv=cp+T*gpt*gpt/gpp;c2=-v*v/(gpp-gpt*gpt/gtt);beta=T*(-gpt+gtt*gpp/gpt)
 if min(v,cp,cv,c2,beta)<=0:raise ValueError('candidate thermodynamic sign pathology')
 h=g-T*gt;return dict(rho=1/v,e=h-p*v,h=h,c=math.sqrt(c2),Cp=cp,Cv=cv,beta=beta,dpDe=1/beta,dpDrho=c2-p*v*v/beta)
ref=CP.AbstractState('HEOS','n-Decane')
def reference(p,T):
 ref.update(CP.PT_INPUTS,p,T)
 if ref.phase() not in (CP.iphase_liquid,CP.iphase_supercritical_liquid):raise ValueError('reference not liquid')
 return dict(rho=ref.rhomass(),e=ref.umass(),h=ref.hmass(),c=ref.speed_sound(),Cp=ref.cpmass(),Cv=ref.cvmass(),beta=ref.first_partial_deriv(CP.iUmass,CP.iP,CP.iDmass),dpDe=ref.first_partial_deriv(CP.iP,CP.iUmass,CP.iDmass),dpDrho=ref.first_partial_deriv(CP.iP,CP.iDmass,CP.iUmass))
threshold=json.loads((b/'fitting/m6a1b2b_config.json').read_text())['gatesDefinedBeforeCompetition'];keys=list(poly(3e6,300));candidateStats={}
for Tmax in [330,350,400]:
 errors={k:[] for k in keys};relations=[]
 for p in np.linspace(5e4,12e6,61):
  for T in np.linspace(320,Tmax,41):
   z=poly(p,T);r=reference(p,T)
   for k in keys:errors[k].append((z[k]-r[k],(z[k]-r[k])/max(abs(r[k]),1e-30)))
 stats={k:{'maxAbsolute':float(np.max(np.abs(np.array(v)[:,0]))),'RMSAbsolute':float(np.sqrt(np.mean(np.array(v)[:,0]**2))),'maxRelative':float(np.max(np.abs(np.array(v)[:,1]))),'RMSRelative':float(np.sqrt(np.mean(np.array(v)[:,1]**2)))} for k,v in errors.items()}
 th=threshold['BUFFER'];mapping={'rho':'rho','c':'c','Cp':'Cp','Cv':'Cv','beta':'deDp_constRho','dpDe':'dpDe_constRho','dpDrho':'dpDrho_constE'}
 passed=all(stats[k]['maxRelative']<=th[v] for k,v in mapping.items()) and stats['e']['maxAbsolute']<=th['eAbsolute_J_kg'] and stats['h']['maxAbsolute']<=th['hAbsolute_J_kg']
 candidateStats[str(Tmax)]={'grid':[61,41],'points':2501,'p':[50000,12000000],'T':[320,Tmax],'stats':stats,'historicalBUFFERbudgetsPASS':bool(passed),'coefficientAction':'NO REFIT: qualify explicit continuation of frozen one-potential polynomial','experimentalClaim':False}
(s/'extension_accuracy.json').write_text(json.dumps(candidateStats,indent=2))
# Reference first; no table enlargement was used for this query.
sr=b/'fitting/integration/m6b1_sr1_serial_v1';first=json.loads((sr/'first_candidate.query.json').read_text());pg=first['gasOnlyDiagnosticPressure_NOT_candidateRecovery'];rho=first['rhoL']
TL=brentq(lambda T:reference(pg,T)['rho']-rho,315,330,xtol=1e-11);z=reference(pg,TL)
required={'pStar_Pa':pg,'TLStar_K':TL,'rhoL':rho,'eNative':z['e'],'eSolver':z['e']+offset,'hSolver':z['h']+offset,'betaL':z['beta'],'cL':z['c'],'backend':'CoolProp '+CoolProp.__version__+' HEOS n-Decane native DEF / reference-EOS-generated, NOT experimental','rootMethod':'frozen native gas-only root pressure evaluated with independent reference liquid; positive trace liquid contribution retained and below double pressure resolution; native full common R1 shadow check follows','liquidWeightedEnergy_J_m3':6.4254079426687836e-19*(z['e']+offset),'liquidPressureCorrectionUpperBound_Pa':abs(6.4254079426687836e-19*(z['e']+offset))/2.3,'phase':CP.PhaseSI('P',pg,'T',TL,'HEOS::n-Decane'),'pSat_Pa':CP.PropsSI('P','T',TL,'Q',0,'HEOS::n-Decane'),'Tcrit':CP.PropsSI('Tcrit','n-Decane'),'pcrit':CP.PropsSI('pcrit','n-Decane'),'backendTmin':CP.PropsSI('Tmin','n-Decane'),'backendTmax':CP.PropsSI('Tmax','n-Decane'),'backendPmax':CP.PropsSI('pmax','n-Decane')}
(s/'first_reference_root.json').write_text(json.dumps(required,indent=2))
# Candidate at 330 is provisional: complete required envelope remains unavailable.
assert candidateStats['330']['historicalBUFFERbudgetsPASS']
out=s/'ndecane_gibbs_v2_candidate';out.mkdir(exist_ok=True)
h=(src/'GibbsPotentialLiquidEOS.H').read_text();body=h[h.index('class GibbsPotentialLiquidEOS'):];body=body[:body.rfind('\n}')];body=body.replace('GibbsPotentialLiquidEOS','GibbsPotentialLiquidEOSV2Candidate').replace('coefficients[','candidateCoefficients[').replace('320','330')
array=h[h.index('static const double coefficients'):h.index('class GibbsPotentialLiquidEOS')].replace('coefficients[','candidateCoefficients[')
header='#pragma once\n#include "GibbsPotentialLiquidEOS.H"\nnamespace liquidEOS {\n'+array+body+'\n}\n'
(out/'GibbsPotentialLiquidEOSV2Candidate.H').write_text(header)
(out/'coefficients.json').write_bytes((src/'coefficients.json').read_bytes())
(out/'metadata.json').write_text(json.dumps({'version':'ndecane_gibbs_v2_candidate','status':'PROVISIONAL SHADOW / NOT ACTIVE / QUALIFICATION PARTIAL','hardP':[50000,12000000],'hardT':[285,330],'normalP':[100000,8000000],'normalT':[295,305],'energyOffset':offset,'coefficientSHA256':hashlib.sha256((src/'coefficients.json').read_bytes()).hexdigest(),'oldPTPotential':'IDENTICAL COEFFICIENTS AND ARITHMETIC; native regression follows','candidateMargin':'10 K qualification option passes reference grid; 9.95 K above first required TL. Not final range until full184 envelope known','notRuntimeExtrapolation':'new explicit bounded shadow domain; no queries outside this candidate HARD'},indent=2))
print('Required first p/T',pg,TL,'330/350/400 accuracy pass',[(k,v['historicalBUFFERbudgetsPASS']) for k,v in candidateStats.items()])
