from pathlib import Path
import csv,json,sys,math,hashlib,struct,collections
b=Path(__file__).resolve().parents[1];s=b/'fitting/integration/m6b1_eos1_ndecane_v1';sys.path.insert(0,str(b/'fitting/reference_backend'))
import CoolProp.CoolProp as CP
from scipy.optimize import brentq
records=json.loads((s/'rejected_capture_inventory.json').read_text());manifest=json.loads((s/'states_manifest.json').read_text());result={int(z['id']):z for z in csv.DictReader((s/'recovery_results.csv').open())};qs={int(z['id']):z for z in csv.DictReader((s/'recorded_candidates.csv').open())};recovered={x['recordId']:result[x['id']] for x in manifest if 'recordId' in x};ref=CP.AbstractState('HEOS','n-Decane');domain=[]
for rec in records:
 row=dict(recordId=rec['recordId'],kind=rec['kind'],anchorStep=rec['anchorStep'],cell=rec['cell'],dt=rec['dt']);rid=rec['recordId']
 if rid not in qs:row.update(status='MISSING_ANCHOR_Q',alphaL='',mL='',rhoL='',Eint='',requiredP='',requiredTL='',referenceTL='',referencePhase='',betaRef='',cLRef='')
 else:
  q=qs[rid];z=recovered[rid];mg,ml=float(q['mG']),float(q['mL']);rho=mg+ml;M=[float(q[x]) for x in ['Mx','My','Mz']];E=float(q['Et'])-.5*sum(x*x for x in M)/rho;rl=ml/float(q['alphaL']);p=float(z['p'])
  def rho_at(T):ref.update(CP.PT_INPUTS,p,T);return ref.rhomass()
  T=brentq(lambda T:rho_at(T)-rl,285,330,xtol=1e-11);ref.update(CP.PT_INPUTS,p,T);phase=ref.phase();assert phase in [CP.iphase_liquid,CP.iphase_supercritical_liquid]
  row.update(status=z['status'],alphaL=q['alphaL'],mL=q['mL'],rhoL=rl,Eint=E,requiredP=z['p'],requiredTL=z['TL'],referenceTL=T,referencePhase=int(phase),betaRef=ref.first_partial_deriv(CP.iUmass,CP.iP,CP.iDmass),cLRef=ref.speed_sound())
 domain.append(row)
with (s/'EOS_REQUIRED_DOMAIN.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=domain[0].keys());w.writeheader();w.writerows(domain)
known=[x for x in domain if x['status']=='RECOVERED_WITH_EXTENSION'];missing=[x for x in domain if x['status']=='MISSING_ANCHOR_Q'];assert len(known)==86 and len(missing)==98
accepted=[(x,result[x['id']]) for x in manifest if x['family']!='exact_first_rejected' and x['family']!='recorded_rejected'];assert len(accepted)==5200
assert all(z['oldStatus']=='PASS' and z['status']=='RECOVERED_WITH_EXTENSION' for x,z in accepted)
control=list(csv.DictReader((s/'recovery_results.csv.controls.csv').open()));assert len(control)==112 and all(x['status']=='PASS' for x in control)
summary={'status':'PARTIAL / MISSING_CAPTURED_STATES','versioning':'B / v2 extension justified for studied states; promotion NOT QUALIFIED','rootClass':'CLASS A for exact first and 86 reconstructed records; unobserved98 UNRESOLVED','requiredKnown':{'records':86,'main':sum(x['kind']=='main' for x in known),'probe':sum(x['kind']=='probe' for x in known),'p':[min(float(x['requiredP']) for x in known),max(float(x['requiredP']) for x in known)],'TL':[min(float(x['requiredTL']) for x in known),max(float(x['requiredTL']) for x in known)],'rhoL':[min(x['rhoL'] for x in known),max(x['rhoL'] for x in known)],'referenceTL':[min(x['referenceTL'] for x in known),max(x['referenceTL'] for x in known)]},'missing':{'records':98,'main':sum(x['kind']=='main' for x in missing),'probe':sum(x['kind']=='probe' for x in missing),'anchorSteps':sorted(set(x['anchorStep'] for x in missing)),'acceptedNeighbors106107':'NOT CAPTURED; no PDE replay used'},'acceptedNeutrality':{'states':5200,'newInvalid':0,'maxPressureAbsolute':max(abs(float(z['p'])-float(z['oldP'])) for x,z in accepted),'maxPressureRelative':max(abs(float(z['p'])/float(z['oldP'])-1) for x,z in accepted),'maxTGAbsolute':max(abs(float(z['TG'])-float(z['oldTG'])) for x,z in accepted),'maxTLAbsolute':max(abs(float(z['TL'])-float(z['oldTL'])) for x,z in accepted),'TG':[min(float(z['TG']) for x,z in accepted if float(z['rhoG'])>0),max(float(z['TG']) for x,z in accepted if float(z['rhoG'])>0)],'TL':[min(float(z['TL']) for x,z in accepted if float(z['rhoL'])>0),max(float(z['TL']) for x,z in accepted if float(z['rhoL'])>0)],'p':[min(float(z['p']) for x,z in accepted),max(float(z['p']) for x,z in accepted)]},'controls':{'count':112,'failures':0,'kinds':['pure gas','pure liquid','mixed alphaL .1/.5/.9','traceL +1e-20','traceG -1e-20'],'P2Coordinates':[0,-0.0,.1,.5,-.1,1e-20,-1e-20]},'noActiveChange':True,'noPDEAdvance':True,'energyOffset':369229.9537234281}
(s/'qualification_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary['requiredKnown'],indent=2));print('Missing98; EOS1 PARTIAL')
