from pathlib import Path
b=Path(__file__).resolve().parents[1];e=b/'fitting/integration/m5c3_v1'
old=(b/'fitting/reconstruction/m5c2d_v1/run_regressions.sh').read_text()
(e/'run_frozen_regressions.sh').write_bytes(old.replace('fitting/reconstruction/m5c2d_v1/regressions','fitting/integration/m5c3_v1/regressions').encode())
commands=[]
def command(name,target,mode=''):
    base='/mnt/d/DATA/Solver/rhosprayVoFDPMFoam'
    exe=f'{base}/tests/{target}/test'+target[0].upper()+target[1:]
    args='/mnt/d/DATA/Solver/300_2D/constant/thermal.dat /mnt/d/DATA/Solver/300_2D/constant/reactions'
    commands.append(f'mkdir -p {base}/fitting/integration/m5c3_v1/D_regressions/{name}\ncd {base}/fitting/integration/m5c3_v1/D_regressions/{name}\n{exe} {args} {mode} > log.run 2>&1\necho "$?" > exit_status.txt\n')
for name,mode in [('grid_final','grid'),('legacy','legacy'),('long','long'),('ordering','ordering'),('volume','volume'),('cost','cost')]:command(name,'fiveEqHighOrderPrecisionFinal',mode)
command('O0','fiveEqHighOrderPrecisionO0','margin')
command('diagnostics','fiveEqHighOrderPrecisionDiagnostics')
command('subulp','fiveEqHighOrderSubULP')
command('boundary','fiveEqPrecisionBoundary')
header='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\n'
(e/'run_D_regressions.sh').write_bytes((header+''.join(commands)).encode())
commands=[];command('stress_final','fiveEqHighOrderPrecisionFinal','stress')
(e/'run_D_stress.sh').write_bytes((header+''.join(commands)).encode())
print('new-output regression runners prepared')
