from pathlib import Path
from decimal import Decimal as D
import json,hashlib,csv,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o1_v1';old=b/'fitting/dpm/m8a3b_t3b_v1'
def load(p):return json.loads(p.read_text(encoding='utf8'))
def precise(p):return json.loads(p.read_text(),parse_float=D)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def encode(x):return json.dumps(x,indent=2,default=str)
results={mode:{s:load(e/'results'/mode/s/'test_results.json') for s in 'ABC'} for mode in ('production','branch','entry')}
for mode,group in results.items():
 for s,r in group.items():
  assert r['failures']==0 and r['ordinaryEvolveEntry']==(mode!='entry')
  assert (e/'results'/mode/s/'test_failures.txt').stat().st_size==0
  assert r['committedSentinelUnchanged']
assert all(r['coalescences']>0 and r['positiveDeletions']>0 for r in results['branch'].values())
assert all(r['removedMass']==5.0000000000000004e-16 for r in results['entry'].values())
before=load(e/'protected_before.json');changes={n for n,h in before.items() if not(b/n).exists() or sha(b/n)!=h}
assert changes<= {'MILESTONE_STATUS.md'},changes
for n,h in load(b/'fitting/dpm/m8a3b_t1_v1/active_before.json').items():assert sha(b/n)==h,n
case=b.parent/'300_2D';now={str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()};assert now==load(e/'case_before.json')
dictionaryHashes={}
for mode in ('fixtures','branch_fixtures'):
 for s in 'ABC':
  for role in ('roleA','roleB'):
   p=e/mode/s/'constant'/f'{role}Properties';assert sha(p)==sha(case/'constant/sprayCloudProperties')
   dictionaryHashes[f'{mode}/{s}/{role}']=sha(p)
groups={'sourceEnergy':list((e/'energy_regressions').glob('*/test_results.json')),'rebinding':list((e/'rebinding').glob('*/test_results.json')),'critical':list((e/'D_regressions').glob('*/test_results.json')),'T3A':list((e/'carrier_verified').glob('*/test_results.json'))}
expected={'sourceEnergy':9288,'rebinding':6375,'critical':105775,'T3A':64395}
for name,paths in groups.items():
 assert all(load(p)['failures']==0 for p in paths)
 assert sum(load(p).get('checks',0) for p in paths)==expected[name]
assert load(e/'D_regressions/subulp/test_results.json')['steps_per_scheme']==1000
assert load(e/'temporal/test_results.json')=={'checks':9663,'failures':0}
assert load(e/'support_regression/native_comparison.json')['checks']==1725880
assert load(e/'support_regression/native_comparison.json')['failures']==0
assert load(e/'support_regression/test_results.json')['failures']==0
rows=list(csv.DictReader((e/'support_regression/ALL_GAS.csv').open()));assert len(rows)==21000 and all(int(r['full'])==1 for r in rows)
goldens={}
for p in (e/'energy_regressions').glob('*/golden_energy.csv'):
 assert p.read_bytes()==(old/'energy_regressions'/p.parent.name/p.name).read_bytes();goldens[p.parent.name]=sha(p)
assert len(goldens)==8
# All residuals use decimal parsing of long-double population diagnostics.
# Positive truncation must also be reproduced in the independent pair ledger,
# avoiding any cancellation against unrelated historical cloud mass.
events={};numericChecks=0
for s in 'ABC':
 root=e/'results/branch'/s
 stream=[json.loads(line,parse_float=D) for line in (root/'events.jsonl').read_text().splitlines()]
 deletion=next(x for x in stream if x['type']=='delete')
 event=deletion['event'];pair=[x for x in stream if x['type']=='pair' and x['event']==event][-1]
 pop=next(x for x in stream if x['type']=='population' and x['event']==event)
 A,C,B,S0,S1=(pop[x] for x in ('before','preCleanup','after','sourceBefore','sourceAfter'))
 rem=deletion['state']['mass'];pb={p['id']:p for p in pair['before']};pa={p['id']:p for p in pair['after']};deleted=deletion['state']['id'];survivor=next(i for i in pa if i!=deleted)
 assert set(pb)==set(pa) and pa[deleted]==deletion['state'];numericChecks+=2
 assert pb[deleted]['mass']>=D('1e-15') and pb[survivor]['mass']>=D('1e-15');numericChecks+=1
 pairBefore=sum(p['mass'] for p in pb.values());pairPreCleanup=sum(p['mass'] for p in pa.values());pairAfter=pa[survivor]['mass']
 tolerance=D('1e-30')+D(128)*D(2)**-52*(abs(pairBefore)+abs(pairAfter))
 assert abs(pairPreCleanup-pairBefore)<=tolerance;numericChecks+=1
 assert abs((pairAfter-pairBefore)+rem)<=tolerance;numericChecks+=1
 deltaMass=S1['m']-S0['m'];Rm=B['m']-A['m']+deltaMass
 assert deltaMass==0 and Rm<0 and abs(Rm)>tolerance;numericChecks+=1
 # Whole-population subtraction has its own frozen arithmetic scale; it
 # must agree with the affected pair, not excuse its positive remnant.
 popTolerance=D('1e-30')+D(128)*D(2)**-52*(abs(A['m'])+abs(B['m']))
 assert abs(Rm+rem)<=popTolerance;numericChecks+=1
 RY=[B['Y'][i]-A['Y'][i]+S1['Y'][i]-S0['Y'][i] for i in range(len(A['Y']))]
 RP=[B['P'][i]-A['P'][i]+S1['P'][i]-S0['P'][i] for i in range(3)]
 assert RY[0]==Rm and RY[1:]==[0,0];numericChecks+=1
 assert S1['P']==S0['P'] and S1['H']==S0['H'];numericChecks+=1
 assert pa[survivor]['mass']-pb[survivor]['mass'] < pb[deleted]['mass'];numericChecks+=1
 # Verify the actual native coalescence momentum expression, including its
 # use of updated m1 and residual m2; do not substitute a desired formula.
 a,b0=pb[survivor]['mass'],pb[deleted]['mass'];a1,r=pa[survivor]['mass'],pa[deleted]['mass'];f=(b0-r)/b0
 predicted=[(a1*pb[survivor]['U'][i]+f*r*pb[deleted]['U'][i])/a1 for i in range(3)]
 assert all(abs(predicted[i]-pa[survivor]['U'][i]) <= D(128)*D(2)**-52*(1+abs(predicted[i])) for i in range(3));numericChecks+=1
 initialV=D('1.00105e-12')/D('725.21967199798883')/D('8e-15');assert initialV<1;numericChecks+=1
 events[s]={'event':event,'pair':pair,'deletion':deletion,'population':pop,'survivorId':survivor,'pairMassBefore':pairBefore,'pairMassPreCleanup':pairPreCleanup,'pairMassAfter':pairAfter,'Rm':Rm,'RY':RY,'RP':RP,'deltaH':B['H']-A['H'],'deltaE':B['E']-A['E'],'deltaKE':B['KE']-A['KE'],'coalescenceDeltaKE':C['KE']-A['KE'],'cleanupDeltaKE':B['KE']-C['KE'],'deltaInternalPlusKE':B['E']+B['KE']-A['E']-A['KE'],'nativeDeltaCarrierMass':deltaMass,'nativeDeltaCarrierMomentum':[S1['P'][i]-S0['P'][i] for i in range(3)],'seedVolumeFraction':initialV}
(e/'population_ledgers.json').write_text(encode(events))
summary={'milestone':'M8A.3B-O1','status':'COMPLETE / NATIVE CONSERVATION BLOCKER','classification':'B / NATIVE_OROURKE_POSITIVE_MASS_TRUNCATION','reachability':'REACHABLE_NORMAL_PATH','scope':'ordinary cloud.evolve with byte-identical production dictionaries and legal branch-test initial states; modified test mesh and timestep, not production frequency validation','nativeHarnessChecks':sum(r['checks'] for g in results.values() for r in g.values()),'offlineLedgerChecks':numericChecks,'testFailures':0,'regressions':{**expected,'nativeInterpolation':1725880,'temporalRestart':9663},'energyGoldenByteIdentical':goldens,'productionDictionaryHashes':dictionaryHashes,'results':results,'activeSolverImpact':'NONE','actualCaseUnchanged':True,'frozenAdapterUnchanged':True,'noCFD':True,'T3B':'PARTIAL / BLOCKED','T3':'PARTIAL','T4':'NO','M8A':'PARTIAL','M6B.0':'NO','M6B.1':'NO'}
(e/'gate_summary.json').write_text(encode(summary))
# Preserve the previous isolated evidence verbatim; classification is now
# CLEANUP_ENTRY_BEHAVIOR, while the ordinary event has independent evidence.
if not(e/'original_cleanup_entry_evidence').exists():
 import shutil
 shutil.copytree(old/'ledger',e/'original_cleanup_entry_evidence')
lineage=[]
for s in 'ABC':
 rows=[json.loads(x) for x in (e/'results/entry'/s/'events.jsonl').read_text().splitlines()]
 deleted=next(x for x in rows if x['type']=='delete');assert not any(x['type']=='pair' for x in rows)
 lineage.append({'state':s,'label':'CLEANUP_ENTRY_BEHAVIOR','deleted':deleted,'predecessor':'explicit test insertion after native history; no preceding collision mutation','survivor':'NONE','otherModifiedParticipants':[],'fullNativeStates':f'results/entry/{s}/native_parcel_states.txt'})
(e/'original_case_lineage.json').write_text(encode(lineage))
def table_states(states):
 return '| ID | nParticle | droplet mass kg | represented mass kg | d m | T K | U m/s | Y |\n|---|---:|---:|---:|---:|---:|---|---|\n'+'\n'.join('| '+str(p['id'])+' | '+str(p['nParticle'])+' | '+str(p['dropletMass'])+' | '+str(p['mass'])+' | '+str(p['d'])+' | '+str(p['T'])+' | '+str(p['U'])+' | '+str(p['Y'])+' |' for p in states)
ev=events['A'];pop=ev['population'];pair=ev['pair'];dele=ev['deletion'];A,B,C=(pop[k] for k in ('before','after','preCleanup'))
massTable='| Seed | before kg | pre-cleanup kg | after kg | deleted kg | Rm kg |\n|---|---:|---:|---:|---:|---:|\n'+'\n'.join(f"| {s} | {v['population']['before']['m']} | {v['population']['preCleanup']['m']} | {v['population']['after']['m']} | {v['deletion']['state']['mass']} | {v['Rm']} |" for s,v in events.items())
countTable='| Mode / seed | updates | pair attempts | collisions | coalescence | cleanup deletions | positive deletions |\n|---|---:|---:|---:|---:|---:|---:|\n'+'\n'.join(f"| {mode}/{s} | {r['updates']} | {r['pairAttempts']} | {r['collisions']} | {r['coalescences']} | {r['deletions']} | {r['positiveDeletions']} |" for mode,g in results.items() for s,r in g.items())
matrix='| Milestone | Status | Scope |\n|---|---|---|\n| M8A source/energy | PASS / FROZEN | unchanged |\n| M8A.3A | COMPLETE | evolved-cloud independence |\n| T1 | COMPLETE / DESIGN ONLY | unchanged |\n| T2 | COMPLETE / STRICT-SUPPORT FEASIBLE | unchanged |\n| T3A | COMPLETE | passive carrier publication |\n| O1 | COMPLETE / NATIVE CONSERVATION BLOCKER | classification B; ordinary event proof |\n| T3B | PARTIAL / BLOCKED | native cleanup truncation, coalescence momentum/energy discrepancies |\n| T3 | PARTIAL | full codec/event/retry/output closure pending |\n| T4 | NO | not authorized |\n| M8A | PARTIAL | production coupling not activated |\n| M6B.0 / M6B.1 | NO / NO | not authorized |'
sections=[
('O1 status','**COMPLETE / NATIVE CONSERVATION BLOCKER.** Final classification B. Conservation does not pass; the classification gate is complete. No conservation repair is implemented.'),
('Native ORourke caller graph','Actual local Foundation7 source was recopied this turn. `SprayCloud::evolve()` (SprayCloud.C:218–225) → `KinematicCloud::solve()` (KinematicCloud.C:92–135) → `preEvolve()` → `evolveCloud()` (180–224): reset sources when coupled, surfaceFilm inject, injectors.inject, **cloud.motion**, then **stochasticCollision().update(td, solution_.trackTime())** at line212 → `StochasticCollisionModel::update()` active guard (C:79–89) → virtual `ORourkeCollision<KinematicCloudType>::collide()` → collideParcels → collideSorted → update positive participant rho/Cp/sigma/mu/d → cleanup sweep. After evolveCloud, scaleSources when coupled, info, postEvolve. Tests enter cloud.evolve, not update, for ordinary proof.'),
('Cleanup entry function','`ORourkeCollision<CloudType>::collide(trackingData&, scalar dt)`, actual ORourkeCollision.C:108–119. The sweep is inline inside collide, not a distinct cleanup API. Predicate: `p.nParticle()*p.mass() < owner.constProps().minParcelMass()`; effect: owner.deleteParticle(p). No native rhoTrans, UTrans, hsTrans update or residual reservoir.'),
('Cleanup callers','Direct caller is the end of ORourke::collide, reached by active StochasticCollisionModel::update from transient KinematicCloud::evolveCloud after motion. Every active transient collision update reaches the sweep even with no pairs. The ordinary pre-motion ReactingParcel threshold path is separate; it cannot protect remnants newly produced by post-motion coalescence.'),
('Delete-condition taxonomy','| Category | Actual OF7 branch |\n|---|---|\n| Coalescence bookkeeping | No separate unconditional coalescence delete; only the common represented-mass threshold. Positive remainder is not already transferred. |\n| Zero/negative multiplicity | No dedicated predicate. With positive droplet mass, zero/negative nParticle falls under common mass threshold. |\n| Minimum mass | Sole ORourke delete predicate; strict <, equality retained. Default dictionary-backed threshold1e-15kg in KinematicParcelI.H:68. |\n| Invalid parcel | No independent ORourke invalid-state delete or validation. NaN comparison does not satisfy <; do not claim such cleanup. |\n| Other ORourke branch | None found. Grazing mutates U but returns massChanged=false. |\n| ReactingParcel minimum mass | Separate calc path C:492–515, keepParticle=false, coupled mapped species/hs/momentum absorption. This is DPM_CARRIER_TRANSFER, not ORourke semantics. |'),
('Current production reachability','**REACHABLE_NORMAL_PATH** for this active transient ORourke/coalescence configuration. All 12 roleA/B dictionaries in original/branch fixtures are byte-identical to 300_2D/constant/sprayCloudProperties (SHA256 '+sha(case/'constant/sprayCloudProperties')+'). Native defaults retain minParcelMass1e-15kg. Analytical proof: for initial b>=threshold, coalescence leaves r=(1-f)b, 0<=f<1; any f>1-threshold/b leaves a positive sub-threshold remnant. Coalescence yes and nonzero relative speed allow this event on the ordinary path. Three complete ordinary tests realize it. Unaltered-mesh observations alone do not certify impossibility. Geometry/timestep/seed distribution are BRANCH-REACHABILITY TEST ONLY: final cell20µm cube, precursor core/drop history KHindex1, d1µm/50nm, masses1e-12/1.05e-15kg, TL300K, dt1e-8s. Seeded volume fraction≈0.173. No injected production size/frequency or CFD application conclusion is inferred.'),
('Represented parcel-mass definition','KinematicParcelI.H:343–360: mass()=rho*volume(), volume()=pi*d^3/6, both refer to a single droplet. Physical computational-parcel mass is **nParticle()*mass()**. Multiplicity may be fractional. Every population and pair mass uses both factors; native serialization is also preserved.'),
('Represented species-mass definition','M_i=sum_parcels[nParticle*mass()*Y_local], mapped using actual composition.localToCarrierId(0,localId). Diagnostics allocate the species vector from runtime rhoTrans.size(); no normalization or guessed species source. Current carrier ordering C10H22/O2/N2; liquidY=[1], so all parcel mass maps to fuel and zero to the other species.'),
('Original 5e-16 case','Relabelled **CLEANUP_ENTRY_BEHAVIOR**. Previous A/B/C evidence copied verbatim to original_cleanup_entry_evidence; original files remain unchanged. New replay preserves all native parcel fields in results/entry/{A,B,C}/native_parcel_states.txt before/preCleanup/after. A deleted ID0:106: nParticle4.8768347711933546e-8, dropletMass1.0252551572044561e-8kg, represented5.0000000000000004e-16kg, rho725.21967199798883kg/m³, TL300K,d0.3mm,U(47,0,0),Y=[1]. No earlier coalescence participant or receiving survivor exists in this test. It is not an ordinary timestep proof.'),
('Event lineage','Final A: seed IDs0:106/0:107 are explicitly inserted above minParcelMass after five normal history steps (106 parcels). 24 ordinary evolve steps execute native injection/motion before event24/pair139368. The last modifying collision is that pair; ID0:107 falls to '+str(dele['state']['mass'])+'kg, ID0:106 survives. Its mass gain is b-r, not b. Cleanup then deletes the residual r. B/C lineage uses the same origProc/origId and per-update pair IDs in JSONL; final cleanup occurs at update26/48. Source matrices are sampled at collision begin/end, excluding preceding drag/injection contributions.'),
('Participants before event',table_states(pair['before'])),
('Participants after event','After coalescence, before cleanup:\n\n'+table_states(pair['after'])+'\n\nAfter cleanup only the survivor ID'+ev['survivorId']+' remains. Whole-cloud native snapshots include every other parcel; no hidden participant gain is omitted.'),
('Deleted parcel state',table_states([dele['state']])+'\n\nDelete reason: representedMassLessThanMinParcelMass; positivity is recorded, never waived by small mass.'),
('Survivor state','Before/after matched by stable native ID:\n\n'+table_states([next(p for p in pair['before'] if p['id']==ev['survivorId']),next(p for p in pair['after'] if p['id']==ev['survivorId'])])+'\n\nSurvivor gain='+str(ev['pairMassAfter']-next(p['mass'] for p in pair['before'] if p['id']==ev['survivorId']))+'kg; donor initial mass is larger. The residual is still physically represented before deletion.'),
('Population mass before',massTable+'\n\nTotals are over **all parcels at collision entry after motion**, not all-timestep before injection. A affected pair before='+str(ev['pairMassBefore'])+'kg.'),
('Population mass after','A full population after='+str(B['m'])+'kg; affected survivor='+str(ev['pairMassAfter'])+'kg. All post-collision pair updates and cleanup complete before measurement. Full-cloud and pair-ledger residuals agree within unchanged endpoint arithmetic scaling.'),
('Native carrier mass transfer','**ΔMcarrier=0** and every ΔrhoTrans_i=0 across each collision update. Previously accumulated drag momentum in native matrices may be nonzero at entry; subtracting before from after gives collision-only native ΔUTrans=0 and ΔhsTrans=0. No receiving parcel/reservoir stores the discarded positive residual.'),
('Mass residual','Rm=(MDPM_after−MDPM_before)+ΔMcarrier−Mexternal, Mexternal=0 for collision. A='+str(ev['Rm'])+'kg; B='+str(events['B']['Rm'])+'kg; C='+str(events['C']['Rm'])+'kg. Negative in all three. The positive lost masses are **not** arithmetic exemptions. Pair-local residual=-r independently excludes masking by historical cloud mass.'),
('Species before/after','A fuel mass '+str(A['Y'])+' → '+str(B['Y'])+'kg. Runtime-mapped species endpoints retained for every event and whole cloud; O2/N2 parcel masses remain zero.'),
('Species residual','RY_i=ΔMDPM_i+ΔMcarrier_i. A='+str(ev['RY'])+'kg; B='+str(events['B']['RY'])+'kg; C='+str(events['C']['RY'])+'kg. Fuel residual equals Rm; no source patch or normalization.'),
('Momentum before/after','A PDPM_before='+str(A['P'])+'; preCleanup='+str(C['P'])+'; after='+str(B['P'])+'kg·m/s. Complete collision scope excludes the motion forces that preceded it; ΔPcarrier=0 across collision.'),
('Momentum-model semantics','Actual sorted coalescence stores U1/U2 references, sets a_new=a_old+dm, r=b_old−dm, dm=f*b_old; then U1_new=(a_new*U1_old+f*r*U2_old)/a_new, leaves donorU unchanged and reduces donor multiplicity. This differs from conservative U1_new=(a_old*U1_old+dm*U2_old)/a_new. Before cleanup ΔP=dm*(U1_old−f*U2_old); deleting r subtracts r*U2_old. The source comment claims conservation, but the implemented expression and measured result do not close momentum. Grazing gf mixes subset velocities and generally dissipates relative KE; it does not create carrier sources. No coefficient/formula is modified.'),
('Momentum residual','RP=PDPM_after−PDPM_before+ΔPcarrier−Iexternal. Iexternal=0 inside collision; any earlier wall/drag impulse precedes the event snapshot. A='+str(ev['RP'])+'kg·m/s; B='+str(events['B']['RP'])+'; C='+str(events['C']['RP'])+'. The native velocity formula is independently evaluated against each observed surviving U, with only frozen floating arithmetic tolerance.'),
('Energy before/after','A raw-liquid caloric H: '+str(A['H'])+'→'+str(B['H'])+'J; raw internal E=H−pV: '+str(A['E'])+'→'+str(B['E'])+'J; translational KE: '+str(A['KE'])+'→'+str(B['KE'])+'J. Diagnostics use native composition.H at each parcel p/T/Y; this is not carrier JANAF sensible energy or an activation of the frozen evaporation ledger. Full numeric tables for A/B/C are population_ledgers.json.'),
('Collision energy semantics','Coalescence sets T1=(Tave*(a+b)−r*T2)/(a+dm), mixes Y by mass, updates native liquid rho/Cp/sigma/mu and d. It does not explicitly add KE loss/gain to thermal energy, track surface energy, or update hsTrans. At equal300K, thermal/caloric sum before cleanup is unchanged up to arithmetic; the residual carries its H/E/KE away when deleted. Grazing collision relative-velocity damping is MODELLED_DISSIPATION of resolved translational KE; no native carrierheat destination exists. No grazing branch was needed for the decisive final coalescence cases.'),
('Energy classification','For the actual decisive coalescence/cleanup events: **UNACCOUNTED_ENERGY**, not an evaporation exchange. A coalescence ΔKE='+str(ev['coalescenceDeltaKE'])+'J (positive); cleanup ΔKE='+str(ev['cleanupDeltaKE'])+'J. B/C coalescence KE can decrease, still no native caloric/surface reservoir closes it. Raw H/E zero includes a negative reference; deleting negative caloric energy can increase the recorded total. Therefore no sign alone is interpreted as carrier heat. Collision thermal and kinetic records remain separate; no gas Et or Eulerian C_L correction.'),
('Ordinary coalescence result','PASS as observed native reachability; not a conservation PASS. Final A/B each one, C two coalescences. All affected pair states logged before mutation and after native property reconstruction. Mass redistribution **before** cleanup closes; this validates the event scope and shows the survivor already accounts for b-r only.'),
('Ordinary cleanup result','Final A/B/C each have one positive-mass native deletion **after** ordinary evolve→motion→coalescence. Both initial participants exceed minParcelMass at the decisive pair entry. No direct cleanup/update call is used for the proof. Removing the instrumentation hooks recovers the actual native collide body; native pair probabilities and RNG kernels are called unchanged. Independently evolving the same initial cloud through uninstrumented ORourke gives exact aggregate serialized state/native source and finite RNG-future probe equality. This is not a complete RNG transaction codec.'),
('Production-config event counts',countTable+'\n\nProduction rows use unchanged original8-cell fixture geometry and no inserted parcels. Branch rows use the same byte-identical production dictionaries, with labelled test-only geometry/time/initial population. Entry rows are isolated behavior only. All observed counts are finite test counts, never production event-frequency estimates. Initial overly small-cell and aborted expensive serialization attempts are retained but superseded by final20µm-cell evidence.'),
('Whether positive-mass cleanup is normally reachable','**Yes, the ordinary caller path allows and realizes it with the current collision configuration.** On the unaltered large-cell fixture, 60 normal updates and the reported pair attempts yielded zero collisions/deletions; that is non-observation, not static unreachability. No probability, active flag, coalescence coefficient or threshold was altered. No CFD production occurrence claim is made.'),
('Final classification A/B/C/D','**B — NATIVE_OROURKE_POSITIVE_MASS_TRUNCATION.** Internal coalescence transfers b-r and conserves represented mass until cleanup. Cleanup discards r>0, with no receiving parcel/nativecarrier/reservoir. Thus A is not the complete-event classification; C is contradicted by source and ordinary-path tests; D is resolved by complete population records. STOP: no conservative-cleanup design or implementation this turn.'),
('Whether current ledger checker was false-positive','A disappearance-only DPM→gas check cannot prove production loss and would incorrectly classify an otherwise conservative internal merge. The previous isolated assertion is therefore re-scoped to CLEANUP_ENTRY_BEHAVIOR, not retroactively treated as a complete ordinary event. This new **population ledger independently confirms a real native truncation**, so the O1 blocker is not removed by correcting scope. Frozen carrier-transfer adapter remains correct for actual carrier exchange; it is not invoked to force internal collision into gas.'),
('Ledger checker changes','Added a separate offline/passive four-level population audit: individual parcel observations; all affected pair/mutation/deletion endpoints; complete cloud safeguard; DPM+carrier increments. Existing EventLedgerV1 and frozen adapter are unchanged. ClassA-specific production/checker API migration is not performed because final classification is B. Added numeric checks confirm pre-cleanup transfer, leftover deletion, lineage, dynamic species map and native momentum algebra.'),
('Source-adapter changes','**NONE.** No dmG/dmYi/dM/dEt, pressure work, JANAF energy mapping, P2/recovery or existing deletion adapter is modified. No source is fabricated from disappearance; no mL source, C_L repair or mass clipping.'),
('Frozen source/energy regression','PASS: 9288 source/energy,6375 rebinding,1725880 native interpolation (max error3.84593e-16; all-gas21000/21000),64395 T3A,105775 critical P2/recovery/R1,9663 temporal/restart. All eight energy golden CSVs are byte-identical to frozen prior evidence. Sub-ULP1000steps/scheme preserved. New native harness'+str(summary['nativeHarnessChecks'])+'checks plus offline population'+str(numericChecks)+'checks, zero assertion failures. Assertions confirm the diagnosed conservation blocker, not a physical conservation PASS.'),
('Transaction rollback spot-check','ClassA optional merge rollback is not applicable. No further T3B transaction matrix is executed. Each diagnostic role is independently reconstructed from committed state and destroyed after observing events; before/after committed cloud/carrier/generation sentinels remain exact, allocator/time restored. Frozen T3A begin/discard regressions replay unchanged. No accepted event commit or complete transaction-state codec is claimed.'),
('Active solver impact','**NONE.** SHA256 audit verifies active files against T1 frozen active manifest, every pre-existing file against O1 pre-change snapshot except the permitted appended milestone document, and actual300_2D all96files unchanged. No $FOAM_SRC edits. New independent test wmake PASS; no solver/CFD/blockMesh/checkMesh execution.'),
('Remaining blocker','Positive represented-mass truncation in native ORourke cleanup; additional actual coalescence momentum and unaccounted-energy discrepancies recorded. A later independently authorized conservation-policy design must review native semantics before any repair. This turn does not choose preserve/merge/reservoir or automatic gas absorption. Full codec, accepted-event retry, persistent output and production coupling gates also remain pending.'),
('Whether O1 COMPLETE','**YES: classification gate COMPLETE / NATIVE CONSERVATION BLOCKER.** Caller audit, actual config, represented mass/species, originalcase lineage, all participants/survivor, wholepopulation mass/species, collision momentum/energy semantics, native source deltas, ordinary-path reachability, classificationB, no exemptions/fake sources, frozen/active byte audit and noCFD are documented. Completion does not mean conservation passed.'),
('Whether T3B may resume NEXT ROUND ONLY','**NO automatic resume.** ClassificationB keeps T3B blocked. Next independent stage must be authorized as native conservation-policy review/design. No coneInjection/KH/rebound/output/combined-event T3B matrix is resumed this turn.'),
('T3 status','PARTIAL / BLOCKED; T3A remains COMPLETE, full serial coupled event gate is not complete.'),
('T4 permission','NO.'),
('M8A status','PARTIAL; frozen source/energy PASS remains intact, production coupling activation not granted.'),
('M6B.0 permission','NO.'),
('M6B.1 permission','NO.'),
('Updated milestone matrix',matrix+'\n\n**STOP. No T3B continuation, no T4, no M6B, no CFD.**')]
assert len(sections)==46
report=b/'M8A3B_O1_OROURKE_POPULATION_GATE.md'
report.write_text('# M8A.3B-O1 ORourke complete-event audit\n\nDate2026-10-02. Final evidence: fitting/dpm/m8a3b_o1_v1.\n\n'+ '\n\n'.join(f'## {i}. {title}\n\n{body}' for i,(title,body) in enumerate(sections,1))+'\n',encoding='utf8')
status=b/'MILESTONE_STATUS.md';text=status.read_text(encoding='utf8');marker='## 2026-10-02 M8A.3B-O1'
if marker not in text:status.write_text(text+'\n\n'+marker+'\n\nCOMPLETE / NATIVE CONSERVATION BLOCKER. FinalclassificationB / NATIVE_OROURKE_POSITIVE_MASS_TRUNCATION.\nOrdinary cloud.evolve→coalescence→cleanup reproduced with byte-identical production dictionaries and explicitly test-only geometry/initialstates.\nCompletepair and wholepopulation ledgers prove positive residual not received by survivor/carrier/reservoir.\nPrior5e-16 isolatedtest is CLEANUP_ENTRY_BEHAVIOR, notproductionlossproof.\nAdditional nativecoalescence momentum/energy discrepancies audited; nofix.\nFrozen regressions9288/6375/1725880/64395/105775/9663PASS, energygoldensbyteidentical.\nActive solver andactual300_2Dunchanged. NoCFD.\nT3B PARTIAL/BLOCKED, T3PARTIAL, T4NO, M8APARTIAL, M6B.0/1NO.\nSee M8A3B_O1_OROURKE_POPULATION_GATE.md andfitting/dpm/m8a3b_o1_v1. STOP.\n',encoding='utf8')
archive=b/'checkpoints/M8A3B_O1_population_v1_COMPLETE_BLOCKER.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for root in (e,b/'tests/fiveEqORourkePopulation'):
  for p in root.rglob('*'):
   if '/Make/linux' in p.as_posix() or '/lnInclude/' in p.as_posix():continue
   if p.is_file() and not p.is_symlink() and p.suffix not in ('.o','.dep'):z.write(p,str(p.relative_to(b)))
 for name in ('M8A3B_O1_OROURKE_POPULATION_GATE.md','MILESTONE_STATUS.md','tools/m8a3b_o1_prepare.py','tools/m8a3b_o1_generate_probe.py','tools/m8a3b_o1_generate_main.py','tools/m8a3b_o1_refine_fixture.py','tools/m8a3b_o1_finalize.py'):z.write(b/name,name)
(e/'checkpoint.json').write_text(encode({'path':str(archive),'sha256':sha(archive)}))
print(encode({'status':summary['status'],'classification':summary['classification'],'nativeChecks':summary['nativeHarnessChecks'],'offlineChecks':numericChecks,'activeSolverImpact':'NONE','report':str(report),'checkpoint':str(archive)}))
