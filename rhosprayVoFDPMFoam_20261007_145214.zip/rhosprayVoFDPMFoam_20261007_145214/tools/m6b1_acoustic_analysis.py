from pathlib import Path
import numpy as np,json,sys
b=Path(__file__).resolve().parents[1];s=b/'fitting/integration/m6b1_serial_dynamics_v1'
results=[]
for case in sorted((s/'cases').iterdir()):
 refPath=case/'constant/fiveEqInitialState.reference.json';dataPath=case/'fiveEqEvidence/dynamic_history.csv'
 if not refPath.exists() or not (case/'exit_status.txt').exists():continue
 ref=json.loads(refPath.read_text())
 if ref['kind']!='acoustic':continue
 data=np.genfromtxt(dataPath,delimiter=',',names=True);t=data['time'];assert len(t)>10
 z=data['pRe']+1j*data['pIm'];phase=np.unwrap(np.angle(z));slope=np.polyfit(t,phase,1)[0];speed=-slope/(2*np.pi/ref['L'])
 model=ref['expectedSpeed'];actualPhase=phase[-1]-phase[0]
 result={'case':case.name,'N':ref['N'],'expectedSpeed':model,'measuredSpeed':float(speed),'relativeSpeedError':float(abs(speed-model)/max(abs(model),1.)),'amplitudeRatio':float(abs(z[-1])/abs(z[0])),'phaseChange':float(actualPhase),'actualEndTime':float(t[-1]),'steps':int(data['step'][-1]),'directionCorrect':bool(speed*model>0),'R1':json.loads((case/'fiveEqEvidence/dynamic_summary.json').read_text())}
 results.append(result)
groups={}
for r in results:groups.setdefault(r['case'].rsplit('_',1)[0],[]).append(r)
checks={}
for name,group in groups.items():
 group.sort(key=lambda r:r['N']);checks[name+'_full_ladder']=[r['N'] for r in group]==[100,200,400]
 checks[name+'_direction']=all(r['directionCorrect'] for r in group)
 checks[name+'_speed_converges']=len(group)==3 and group[2]['relativeSpeedError']<group[1]['relativeSpeedError']<group[0]['relativeSpeedError']
 checks[name+'_R1']=all(r['R1']['R1failures']==0 and r['R1']['violations']==0 for r in group)
 # No post-hoc sound-speed/limiter tolerances. Owner requests convergence to
 # frozen characteristic speed. All three physical/N/CFL settings are fixed.
summary={'measure':'least-squares slope of unwrapped pressure fundamental Fourier phase at every accepted step; speed=-slope/k','checks':checks,'failed':[k for k,v in checks.items() if not v],'results':results}
(s/'acoustic_analysis.json').write_text(json.dumps(summary,indent=2))
for r in results:print(r['case'],'expected',r['expectedSpeed'],'measured',r['measuredSpeed'],'relativeError',r['relativeSpeedError'],'ampRatio',r['amplitudeRatio'])
print('failed',summary['failed'])
