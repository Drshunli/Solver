from pathlib import Path
import os,json,hashlib,shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_v1'
if e.exists():raise SystemExit('Refusing to overwrite evidence')
e.mkdir(parents=True);manifest={}
for root,dirs,names in os.walk(b):
 dirs[:]=[x for x in dirs if x not in ('Make','lnInclude','.git','m8a3b_v1')]
 for n in names:
  p=Path(root)/n
  if not p.is_symlink():
   try:manifest[p.relative_to(b).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
   except OSError:pass
(e/'protected_before.json').write_text(json.dumps(manifest,indent=2))
t=b/'tests/fiveEqDPMSupportScan';(t/'Make').mkdir(parents=True)
for n in ('files','options'):(t/'Make'/n).write_bytes((b/'tests/fiveEqDPMRebinding/Make'/n).read_bytes().replace(b'testFiveEqDPMRebinding',b'testFiveEqDPMSupportScan'))
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\n'
(e/'build.sh').write_bytes((head+'cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMSupportScan\nwmake > ../../fitting/dpm/m8a3b_v1/log.wmake 2>&1\n').encode())
(e/'run.sh').write_bytes((head+'cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_v1\n/usr/bin/time -v ../../../tests/fiveEqDPMSupportScan/testFiveEqDPMSupportScan /mnt/d/DATA/Solver/300_2D > log.scan 2> log.resource\n').encode())
