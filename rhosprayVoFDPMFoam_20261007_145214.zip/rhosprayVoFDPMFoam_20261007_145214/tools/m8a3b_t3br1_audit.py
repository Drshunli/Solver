from pathlib import Path
import json,hashlib,csv,re
from decimal import Decimal
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3br1_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out={'checks':0,'failures':[]}
def ck(ok,name):
 out['checks']+=1
 if not ok:out['failures'].append(name)
def load(p):return json.loads(p.read_text())
def group(folder,expected):
 vals=[load(p) for p in (e/folder).rglob('test_results.json')]
 ck(bool(vals) and all(x['failures']==0 for x in vals),folder+' zero failures')
 count=sum(x.get('checks',0) for x in vals);ck(count==expected,folder+' assertion count');return count
out['frozen']={f:group(f,n) for f,n in [('energy_regressions',9288),('rebinding',6375),('carrier_verified',64395),('D_regressions',105775),('temporal',9663),('O1_regression',349)]}
j=load(e/'support_regression/native_comparison.json');ck(j['checks']==1725880 and j['failures']==0,'T2 native interpolation');out['frozen']['T2_native']=j['checks']
r=list(csv.DictReader((e/'support_regression/scenarios.csv').open()));out['supportScenarioColumns']=list(r[0]);out['allGasScenario']=[v for v in r if 'all' in str(v).lower()]
rows=list(csv.DictReader((e/'support_regression/ALL_GAS.csv').open()));ck(len(rows)==21000 and all(r['full']=='1' for r in rows),'21000 actual all-gas support rows');out['allGasPass']=len(rows)
for p in (e/'O1_regression').rglob('test_results.json'):
 old=b/'fitting/dpm/m8a3b_o2b_v1/O1_regression'/p.relative_to(e/'O1_regression')
 ck(p.read_bytes()==old.read_bytes(),'historical O1 replay byte identical '+str(p.relative_to(e/'O1_regression')))
fixtureCount=0
for folder in ('fixtures','branch_fixtures','rebinding_fixtures'):
 old=b/'fitting/dpm/m8a3b_o2b_v1'/folder
 for p in old.rglob('*'):
  if p.is_symlink() or not p.is_file():continue
  fixtureCount+=1;ck((e/folder/p.relative_to(old)).read_bytes()==p.read_bytes(),'native fixture unchanged '+folder+'/'+str(p.relative_to(old)))
out['fixtureFileChecks']=fixtureCount
# Original authoritative energy golden baseline, preserved byte for byte.
goldens={}
for p in (e/'energy_regressions').rglob('golden_energy.csv'):
 old=b/'fitting/dpm/m8a3b_o2b_v1/energy_regressions'/p.relative_to(e/'energy_regressions')
 ck(p.read_bytes()==old.read_bytes(),'energy golden '+p.parent.name);goldens[p.parent.name]=sha(p)
ck(len(goldens)==8,'eight energy goldens');out['goldenHashes']=goldens
native={};physical=[]
for state in 'ABC':
 d=e/'native'/state;j=load(d/'test_results.json');ck(j['failures']==0,state+' native gates');ck(not j['T3BComplete'] and not j['fullTransactionCodec'] and not j['fullOutputTransactionCertified'],state+' scope truth flags');ck(j['acceptedKernelCommits']>=100 and j['kernelDiscards']>=1000,state+' lifecycle');ck(j['futureKernelComparisons']==40,state+' future queries');ck(j['nativeGrazingTemperature']==320,state+' native grazing temperature');
 for mode in ('none','grazing','coalescence','cleanup'):
  ck((d/f'native_reference_{mode}.txt').read_bytes()==(d/f'transaction_result_{mode}.txt').read_bytes(),state+mode+' exact reference cloud/RNG/source bytes')
 rows=list(csv.DictReader((d/'model_events.csv').open()));ck(len(rows)==8,state+' model rows');ck(all(r['nativeReferenceExact']=='1' and r['rollbackExact']=='1' for r in rows),state+' model native/rollback');ck(sum(r['accepted']=='1' for r in rows)==6,state+' six model commits only');
 ck(len(list((d/'published').glob('accepted_*.txt')))==j['acceptedKernelCommits'],state+' accepted persistent ticket count');ck(len(list((d/'model_published').glob('accepted_*.txt')))==6,state+' model persistent ticket count');ck(not list((d/'published').glob('*.pending')),state+' no leftover temp tickets');ck(int((d/'future_stochastic_count.txt').read_text())==10,state+' ten future stochastic renewals');
 for r in csv.DictReader((d/'PHYSICAL_CONSERVATION_AUDIT.csv').open()):
  a={k:Decimal(v) for k,v in r.items() if k not in ('event','status')};res={'state':state,'event':r['event'],'Rmass':str(a['Mafter']-a['Mbefore']),'RspeciesC10':str(a['C10massAfter']-a['C10massBefore']),'RmomentumX':str(a['PxAfter']-a['PxBefore']),'RenergyRawLiquidHminusPV':str(a['KEafter']+a['EintAfter']-a['KEbefore']-a['EintBefore']),'EdissNative':str(a['KEbefore']-a['KEafter']),'carrierMass':str(a['carrierMass']),'carrierMomentum':str(a['carrierMomentum']),'carrierHeat':str(a['carrierHeat']),'classification':'KNOWN_NATIVE_MODEL_LIMITATION'}
  ck(a['carrierMass']==0 and a['carrierMomentum']==0 and a['carrierHeat']==0,state+r['event']+' no collision compensation');physical.append(res)
 native[state]=j
out['native']=native;out['physicalDiagnostics']=physical
# Existing project files are immutable apart from append-only milestone status.
protected=load(e/'protected_before.json');changed=[];missing=[]
for path,h in protected.items():
 p=b/path
 if not p.exists():missing.append(path);continue
 current=sha(p)
 if current!=h:
  if path=='MILESTONE_STATUS.md':
   # audit-specific baseline body saved separately before append
   old=e/'milestone_before.bin';ck(old.exists() and p.read_bytes().startswith(old.read_bytes()),'milestone append-only')
  else:changed.append(path)
ck(not changed and not missing,'protected existing files unchanged');out['protected']={'count':len(protected),'changed':changed,'missing':missing}
cases=load(e/'case_before.json');caseChanged=[path for path,h in cases.items() if not (b.parent/'300_2D'/path).exists() or sha(b.parent/'300_2D'/path)!=h];ck(not caseChanged,'actual 300_2D all files unchanged');out['productionCase']={'count':len(cases),'changed':caseChanged}
activeMake={'Make/files':'1707e8915e28ce8da88bc4c191c7c7eefbade2003162d00993814f288bf9bdd9','Make/options':'51d40116cf7f636c6226381282e783b8f1ad73ff8fc90a0104004b3a3f715b74'}
for path,h in activeMake.items():ck(sha(b/path)==h,'active '+path+' unchanged')
out['activeMakeHashes']=activeMake
sources={}
for p in (e/'native_sources').rglob('ORourkeCollision.*'):sources[p.name]=sha(p)
ck(sources=={'ORourkeCollision.C':'b7902f356397ed75bef005e89a6a23aa4b758d3483ef3938f559e5ae5378a6dd','ORourkeCollision.H':'4ea15160524f8616cdb8c0b12c43ad71a57899b838147ba51d333d463e73ca15'},'native ORourke pinned hash');out['nativeSourceHashes']=sources
cpp=b/'tests/fiveEqDPMNativeTransaction/testFiveEqDPMNativeTransaction.C';dep=cpp.parent/'Make/linux64GccDPInt32Opt/testFiveEqDPMNativeTransaction.C.dep';txt=dep.read_text();ck('src/lagrangian/spray/lnInclude/ORourkeCollision.C' in txt,'actual compiled native collision include');ck(not any(x in txt for x in ('populationAudit.H','collisionEnergy.H','energyDecision.H')),'O2 conservative implementation excluded from compile graph');out['collisionDependencies']=[s for s in txt.splitlines() if 'ORourkeCollision' in s]
(e/'collision_compile_dependencies.txt').write_text('\n'.join(out['collisionDependencies'])+'\n')
(e/'independent_audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:out[k] for k in ('checks','failures','frozen','protected','productionCase')},indent=2));raise SystemExit(bool(out['failures']))
