from pathlib import Path
import hashlib,json,shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3a_v1'
if e.exists():raise RuntimeError('Use a new version; never overwrite prior evidence')
e.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
protected={str(p.relative_to(b)):sha(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_t3a_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()}
(e/'protected_before.json').write_text(json.dumps(protected,indent=2),encoding='utf8')
case=b.parent/'300_2D';(e/'case_before.json').write_text(json.dumps({str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()},indent=2),encoding='utf8')
t=b/'tests/fiveEqDPMCarrierPublication';(t/'Make').mkdir(parents=True)
(t/'Make/options').write_bytes((b/'tests/fiveEqDPMSerialTransaction/Make/options').read_bytes().replace(b'-I../fiveEqDPMRebinding',b'-I../fiveEqDPMRebinding -I../fiveEqDPMSerialTransaction -I../fiveEqDPMSupportScan'))
(t/'Make/files').write_bytes((b/'tests/fiveEqDPMSerialTransaction/Make/files').read_bytes().replace(b'testFiveEqDPMSerialTransaction',b'testFiveEqDPMCarrierPublication'))
for s in 'ABC':
 for f in ('0','constant','system'):shutil.copytree(b/'fitting/dpm/m8a3b_t3_v1/fixtures'/s/f,e/'fixtures'/s/f)
 for mode in ('heat','mass','momentum','combined'):
  shutil.copyfile(b/'tests/fiveEqDPMNative/fixtures'/mode/'constant/sprayCloudProperties',e/'fixtures'/s/'constant'/('cvSource'+mode+'Properties'))
 for f in ('0','constant','system'):shutil.copytree(b/'tests/fiveEqDPMRebinding'/('fixture'+s)/f,e/'rebinding_fixtures'/s/f)
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqDPMCarrierPublication"\nwmake > "$base/fitting/dpm/m8a3b_t3a_v1/log.wmake" 2>&1\n').encode())
for n in ('run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','run_rebinding.sh','run_support.sh'):
 (e/n).write_bytes((b/'fitting/dpm/m8a3b_t3_v1'/n).read_bytes().replace(b'm8a3b_t3_v1',b'm8a3b_t3a_v1'))
(e/'read_sources.sh').write_bytes((head+'''src=$FOAM_SRC
out="$base/fitting/dpm/m8a3b_t3a_v1/native_sources"
mkdir -p "$out"
for name in KinematicCloud.H KinematicCloud.C ThermoCloud.H ThermoCloud.C ReactingCloud.H ReactingCloud.C KinematicParcel.H KinematicParcel.C KinematicParcelTrackingDataI.H ThermoParcel.H ThermoParcel.C ThermoParcelTrackingDataI.H ReactingParcel.H ReactingParcelTrackingDataI.H interpolation.H interpolationCell.H interpolationCellPoint.H interpolationCellPointI.H volPointInterpolation.H volPointInterpolation.C GeometricField.H GeometricField.C GeometricFieldI.H Field.H Field.C basicThermo.H basicThermo.C psiThermo.H psiThermo.C heThermo.H heThermo.C hePsiThermo.C hePsiThermo.H multiComponentMixture.H multiComponentMixture.C DimensionedFieldI.H DimensionedField.H; do
 find "$src" -name "$name" -not -path '*/lnInclude/*' | while read -r file; do
  relative="${file#$src/}"; mkdir -p "$out/$(dirname "$relative")"; cp "$file" "$out/$relative"
 done
done
''').encode())
print(e)
