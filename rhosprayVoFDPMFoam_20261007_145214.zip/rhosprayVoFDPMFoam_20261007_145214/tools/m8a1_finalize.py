from pathlib import Path
import json,hashlib,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a1_v1';result=json.loads((e/'test_results.json').read_text());assert result['failures']==0;assert (e/'exit.production.txt').read_text().strip()=='0'
reg={}
for mode in ('zero','heat','momentum','mass','evaporation','combined','disappearance','permuted'):
 d=e/'energy_regressions'/mode;old=b/'fitting/dpm/m8a_v1'/mode
 equal={n:(d/n).read_bytes()==(old/n).read_bytes() for n in ('ledger.csv','golden_energy.csv','test_results.json','test_failures.txt')}
 assert all(equal.values()),(mode,equal);reg[mode]={'result':json.loads((d/'test_results.json').read_text()),'identicalFrozenFiles':equal}
names=['actual production cloud config audited','actual interpolation path audited','authoritative gas-support classifier implemented','P2 trace gas correctly supported','exact gas-absent cells rejected','injection support check implemented in production','tracking support check implemented in production','interpolation-stencil support check implemented in production','source-deposition support check implemented in production','no fake gas thermo introduced','production applicability contract frozen','complete mutable cloud state enumerated','source accumulators included in COMPLETE transaction','injection rollback PASS','parcel deletion rollback PASS','enabled patch-model rollback PASS','enabled stochastic-model full RNG rollback PASS','enabled breakup/collision event rollback PASS','output side effects commit-safe','real cloud begin/commit/discard implemented','oversized-dt retry PASS','direct-small versus reject-retry equivalence PASS','gas-support failure WHOLE cloud/Q rollback PASS','trace-gas source trial PASS','real production-path enforcement/transaction harness PASS','M8A energy regressions unchanged','pure-gas legacy regression unchanged','no alpha source','active solver physics unchanged','no CFD run']
partial={6,7,8,9,13,14,17,18,19,20,21,22,23,25}
gates=[{'number':i+1,'gate':n,'status':'PARTIAL' if i+1 in partial else 'PASS'} for i,n in enumerate(names)]
summary={'status':'PARTIAL','M8A':'PARTIAL','nativeHarness':result,'harnessScope':'44 diagnostic/guarded-caller/native-event/defect assertions, NOT complete production transaction','energyRegressions':reg,'gates':gates,'activeSolverImpact':'NONE','CFD':False,'MPI':'PRE-M6B BLOCKER','M6B0':'BLOCKED / NOT STARTED','M6B1':'NO / NOT STARTED'}
(e/'summary.json').write_bytes(json.dumps(summary,indent=2).encode())
matrix='| Gate | Status |\n|---|---|\n'+''.join(f"| {g['number']}. {g['gate']} | {g['status']} |\n" for g in gates)
sections=[
('M8A.1 status','**PARTIAL.** Classifier/strict operator probes and native production-model events implemented/tested; production enforcement hooks and complete real transaction NOT closed.'),
('Production cloud configuration','Actual 300_2D sprayCloudProperties copied byte-for-byte to a manufactured native harness. Source and runtime selection audited; fixture geometry/fields/write-time are unit inputs, not a CFD case run.'),
('Enabled DPM models','coneInjection/RosinRammler; sphereDrag; heat none; phaseChange none; singlePhaseMixture; blobsSheetAtomization; ReitzKHRT; ORourke/coalescence; stochasticDispersionRAS; standardWallInteraction/rebound; voidFraction. RanzMarshall/evaporation coefficient dictionaries are inactive. See PRODUCTION_DPM_RUNTIME_AUDIT.md.'),
('Actual carrier interpolation path','rho/mu/T/Cp/kappa/p=cell; U=cellPoint; species direct cell reads. Future rhoG/TG/YG must be intrinsic gas; native cellValueSourceCorrection uses rho*V and remains unresolved for mixed gas partial mass.'),
('Interpolation stencil definition','Native vector basis expansion records exact tensor coefficients, physical patch contributors, constraints and mandatory scalar cell read; native particle barycentric/tet overload used after crossing. actual_stencil.csv contains measured injection weights. Serial <=256-entity diagnostic only; no production/MPI builder.'),
('Gas-support classifier','fiveEqDPMCarrierSupport uses immutable committed signed P2 + mG consistency + frozen recovery. Controlled PRESENT/TRACE/ABSENT/INCONSISTENT/THERMO results; no FatalError or alpha decode heuristic.'),
('Injection support policy','Validate actual native injector location/tet/stencil BEFORE allocation. Native setPositionAndCell + pre-allocation guard probe passes. Hook not installed in native InjectionModel::inject: production gate PARTIAL.'),
('Tracking support policy','Native trackToAndHitFace crosses an internal face; same classifier rejects next absent cell before carrier query and permits trace gas. This guarded-caller probe does not install a guard in legacy move().'),
('Source-deposition policy','sourceTrial calls the same classifier before unchanged adapter/recovery. Absent source rejects even if zero; production calc/accumulation interception unimplemented.'),
('Trace-gas behavior','alphaG1e-20 recognized even with decoded alphaL1; zero source bit identity and excessive source recovery rejection pass. Rejected source preserves committed support snapshot.'),
('Exact gas-absent behavior','Containing-cell, boundary-contributor, injection/track/source caller tests reject before native carrier query. No artificial gas creation. Complete production cloud crossing/discard remains unproven.'),
('DPM applicability scope','Strict pre-existing gas support only. No renormalization, nearest-gas copy, dummy thermo, parcel deletion/bounce workaround or alpha source. Contract_v1 frozen.'),
('Mutable cloud-state inventory','Parcel fields/IDs/tets, allocator, injector/distribution/time/counters, RNG, models/owner refs, force/dispersion caches, occupancy, sources/coefficients, solution/outputProperties, private theta, pending IO, caller Q/time/mesh and MPI enumerated in audit.'),
('Native cloud restore limitations','Confirmed clone owner aliases original, cloudReset resets global ID allocator0, private theta is lost, native sources omitted, full solution/output dictionaries not reset, files not undone. Empty-cloud tests can hide allocator defects.'),
('Selected transaction architecture','Preferred isolated trial cloud with correctly rebound owners and commit-deferred IO. Raw native clone is rejected; raw snapshot+source restore insufficient. No complete production implementation claimed.'),
('Parcel-state rollback','Real minParcelMass deletion restores full native serialized parcel; repeat deletion passes. Actual enabled rebound restores/replays full serialized parcel. These local tests do not close global transaction.'),
('Source-accumulator rollback','Frozen NativeDPMSourceSnapshot used alongside native snapshots; energy/source API implementation unchanged. Full atomic source+cloud+Q commit remains incomplete.'),
('Injector-state rollback','Actual evolve injects21 parcels and5.26272e-10kg; count/mass retry match. First origId1 versus retry0 exposes incomplete allocator restoration, so injection rollback remains PARTIAL.'),
('RNG rollback','Actual production random models run; post-event scalar RNG and cumulative impulse repeat. Full parcel/random-decision branch coverage, including forced breakup/coalescence, not proven; do not infer global deterministic rollback.'),
('Patch-interaction rollback','Actual standardWallInteraction rebound invoked; native serialized parcel restoration and identical rebound replay PASS. Escape/stick modes not selected.'),
('Breakup/collision rollback status','Both are ENABLED and run in native evolve; forced child creation/merge/deletion rollback NOT validated. They cannot be labeled outside production scope or PASS.'),
('Output-side-effect handling','Native unit writeTime forced to exercise output: theta/outputProperties files remain after native restore, while theta memory field disappears. No commit-safe output implementation; hard blocker. No production write schedule changed.'),
('begin/commit/discard API','Lifecycle capability gate rejects known unsupported production path BEFORE mutation, checks validated commit and single terminal call. It is a readiness interface, not the requested complete real-cloud transaction.'),
('Oversized-step retry','NOT PROVEN: complete production transaction must exist before this golden test. No artificial mock success reported.'),
('Small-step equivalence test','NOT PROVEN. Real nonzero allocator counterexample already disproves exact native reject/retry cloud equivalence.'),
('Support-failure rollback','Immutable support and rejected coherent source tests PASS; whole native-cloud/Q/output rollback on gas-absent trajectory NOT PROVEN.'),
('Real production-path harness',f"Actual basicSprayCloud, identical DPM dictionary/runtime models, real interpolation, injection, tracking, deletion, rebound, source accumulation and clone/restore used. {result['checks']} assertions/{result['failures']} failures; includes assertions proving defects. productionTransactionComplete=false. No Eulerian equations or CFD run."),
('Energy-ledger regression','Eight M8A regressions rerun:9288 checks/0 failures. ledger.csv, golden_energy.csv, results and failure files byte-identical to frozen originals. Energy formulas/headers never edited.'),
('Pure-gas legacy regression','Existing equivalent pure-gas accepted-source regression byte-identical. New support layer is passive; no active source-placement modification.'),
('MPI/decomposition readiness','Serial diagnostic only. Processor-transfer support/owner/message buffers and collective accept/discard absent: PRE-M6B MPI BLOCKER.'),
('No-alpha-source confirmation','Signed P2/Allaire K0 unchanged; no alpha equation/source or gas-volume creation.'),
('Active solver impact','**NONE.** Protected old source/case/energy/result hashes audited; only MILESTONE_STATUS.md authorized update. No active timestep/cloud/equation/source edit; no CFD.'),
('Remaining blockers','Scalable actual production stencil builder and injection/move/source hooks; owner-safe trial cloud or full snapshot including allocator/solution/properties/occupancy/private theta; commit-deferred IO; enabled breakup/collision branch rollback; oversized/small-step and full support-failure golden tests; MPI ownership.'),
('Whether M8A.1 is COMPLETE','**NO.**\n\n'+matrix),
('Whether M8A is COMPLETE','**NO.** Accepted original ledger gates remain intact, but M8A.1 is PARTIAL.'),
('M6B.0 start permission','**NO / BLOCKED.** Not executed.'),
('M6B.1 permission','**NO.** No active equation switch.'),
('Updated milestone matrix','| Stage | Status |\n|---|---|\n| M5C.1-M5C.3 | COMPLETE / NOT ACTIVE |\n| Accepted M8A source/energy gates | unchanged / regression PASS |\n| M8A.1 | PARTIAL / native defects and guard probes documented |\n| M8A overall | PARTIAL |\n| M6B.0/M6B.1 | BLOCKED / NOT STARTED |\n| CFD | NOT EXECUTED |\n\nSTOP. No M6B.0/M6B.1 performed.')]
report='# M8A.1 production gas support and transactional rollback gate\n\n'+''.join(f'# {i}. {title}\n\n{text}\n\n' for i,(title,text) in enumerate(sections,1));(b/'M8A1_PRODUCTION_SUPPORT_TRANSACTION_GATE.md').write_bytes(report.encode())
p=b/'MILESTONE_STATUS.md';text=p.read_text(encoding='utf-8');marker='## M8A.1 current production support/transaction gate (2026-10-01)'
if marker not in text:text+='\n\n'+marker+'\n\nM8A.1 PARTIAL: P2+mass support classifier, exact serial native interpolation probes and native production-model harness pass their diagnostic checks. Actual injection/move/source enforcement hooks and complete transaction remain unsupported. Native clone owner alias, private theta/output loss, zero-reset global ID allocator and missing solution/property restore are concrete blockers. Deletion/rebound local rollback tests pass; forced breakup/collision and whole-step golden tests not proven. Original M8A energy/source results remain byte-identical. M8A remains PARTIAL; M6B.0/M6B.1 blocked and unexecuted. Active solver/case/energy code unchanged; no CFD. See M8A1_PRODUCTION_SUPPORT_TRANSACTION_GATE.md.\n'
p.write_bytes(text.encode())
before=json.loads((e/'protected_before.json').read_text());changed=[];missing=[]
for name,h in before.items():
 path=b.parent/'300_2D'/name[5:] if name.startswith('CASE/') else b/name
 if not path.exists():missing.append(name)
 elif hashlib.sha256(path.read_bytes()).hexdigest()!=h:changed.append(name)
audit={'protected':len(before),'changed':changed,'missing':missing,'allowed':['MILESTONE_STATUS.md']};assert not missing and set(changed)<=set(audit['allowed']),audit
(e/'protected_after.json').write_bytes(json.dumps(audit,indent=2).encode());summary['protected']=audit
(e/'source_hashes.json').write_bytes(json.dumps({str(p.relative_to(e/'source_audit')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (e/'source_audit').rglob('*') if p.is_file()},indent=2).encode())
summary['productionDictionaryIdentical']=(b.parent/'300_2D/constant/sprayCloudProperties').read_bytes()==(b/'tests/fiveEqDPMProduction/fixture/constant/sprayCloudProperties').read_bytes();assert summary['productionDictionaryIdentical'];summary['preCommitOutputProbeFiles']=[str(p.relative_to(b)) for p in (b/'tests/fiveEqDPMProduction/fixture').rglob('*') if p.is_file() and (p.name=='sprayCloudTheta' or 'OutputProperties' in p.name)]
(e/'summary.json').write_bytes(json.dumps(summary,indent=2).encode())
paths=set(p for p in e.rglob('*') if p.is_file());paths.update(p for p in (b/'tests/fiveEqDPMProduction').rglob('*') if p.is_file() and not any('linux64Gcc' in x for x in p.parts));paths.update((b/'tools').glob('m8a1_*.py'));paths.update(b/'dpmFiveEq'/n for n in ('fiveEqDPMCarrierSupport.H','fiveEqDPMNativeStencilProbe.H','fiveEqDPMTransactionGate.H'));paths.update(b/n for n in ('MILESTONE_STATUS.md','M8A1_PRODUCTION_SUPPORT_TRANSACTION_GATE.md','PRODUCTION_DPM_RUNTIME_AUDIT.md','docs/FIVE_EQ_DPM_COUPLING_CONTRACT_v1.md'))
manifest={str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)};(e/'checkpoint_manifest.json').write_bytes(json.dumps(manifest,indent=2).encode());paths.add(e/'checkpoint_manifest.json')
z=b/'checkpoints/M8A1_production_support_transaction_v1_PARTIAL.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for p in sorted(paths):out.write(p,p.relative_to(b))
sha=hashlib.sha256(z.read_bytes()).hexdigest();(b/'checkpoints/M8A1_production_support_transaction_v1_PARTIAL.sha256').write_text(sha+'  '+z.name+'\n',encoding='ascii');print(json.dumps({'status':'PARTIAL','harness':result,'regressionChecks':sum(r['result']['checks'] for r in reg.values()),'audit':audit,'checkpointSHA256':sha},indent=2))
