from pathlib import Path
import json,hashlib,shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3br1_v1';assert not e.exists()
e.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_text(json.dumps({str(p.relative_to(b)):sha(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_t3br1_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()},indent=2))
old=b/'fitting/dpm/m8a3b_o2b_v1'
for folder in ('fixtures','branch_fixtures','rebinding_fixtures'):shutil.copytree(old/folder,e/folder)
shutil.copyfile(old/'case_before.json',e/'case_before.json')
for name in ('run_all_regressions.sh','run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','run_rebinding.sh','run_support.sh','run_carrier_verified.sh','run_o1.sh','read_sources.sh'):
 (e/name).write_bytes((old/name).read_bytes().replace(b'm8a3b_o2b_v1',b'm8a3b_t3br1_v1'))
t=b/'tests/fiveEqDPMNativeTransaction';(t/'Make').mkdir(parents=True)
(t/'Make/files').write_bytes((b/'tests/fiveEqDPMEventLedger/Make/files').read_bytes().replace(b'testFiveEqDPMEventLedger',b'testFiveEqDPMNativeTransaction'))
(t/'Make/options').write_bytes((b/'tests/fiveEqDPMEventLedger/Make/options').read_bytes().replace(b'-I../fiveEqDPMCarrierPublication',b'-I../fiveEqORourkePopulation -I../fiveEqDPMSerialTransaction -I../fiveEqDPMCarrierPublication'))
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqDPMNativeTransaction"\nwmake > "$base/fitting/dpm/m8a3b_t3br1_v1/log.wmake" 2>&1\n').encode())
(e/'run.sh').write_bytes((head+'''for s in A B C; do
 mkdir "$base/fitting/dpm/m8a3b_t3br1_v1/native/$s" -p
 cd "$base/fitting/dpm/m8a3b_t3br1_v1/native/$s"
 /usr/bin/time -v "$base/tests/fiveEqDPMNativeTransaction/testFiveEqDPMNativeTransaction" "$base/fitting/dpm/m8a3b_t3br1_v1/branch_fixtures/$s" "$s" /mnt/d/DATA/Solver/300_2D/constant/thermal.dat > log.run 2>log.resource
done
''').encode())
(e/'owner_decision.txt').write_text('USER_AUTHORIZED_O2D_COMPLETE_NATIVE_OF7_OROURKE_FIRST_ACTIVATION\nSource: C:/Users/17624/.codex/attachments/11cfce58-f4b4-4ee3-ba44-edfd64be8546/已粘贴的文本.txt\nNative collision semantics including cleanup unchanged. Physical conservation audit diagnostic for ORourke only. No invented sources.\n',encoding='utf-8')
print(e)
