"""Read-only FPE2 evidence audit; evaluates only the failed native quotient.
No KH model formulas, solver dictionaries, or runtime states are changed.
"""
import csv, decimal, hashlib, json, pathlib, subprocess, sys
stage = pathlib.Path(sys.argv[1])
root = stage.resolve().parents[2]
def read(path):
    return json.loads(path.read_text(encoding="utf-8"))
def calls(name, rank):
    return [json.loads(line) for line in (stage/name/("calls.rank"+rank+".jsonl")).read_text().splitlines()]
def entry(name, rank):
    return next(x for x in calls(name, rank) if "nativeArgs" in x)
def scale(name, rank):
    return next(x["nativeScales"] for x in calls(name, rank) if x.get("stage")=="NATIVE_LARGER_DROP_BEFORE_ASSIGNMENT")
original=entry("exact_debug_final", "1")
failure=read(stage/"exact_debug_final/failure.rank1.json")
assert failure["frames"][0]["line"]==254
assert original["td"]["session_"]["valid_"]==1
assert original["materializedCarrier"]["ticket_"]["valid"]==1
assert original["td"]["session_"]["generation_"]==1
controls=[]
for name, rank in [("serial_control","serial"),("rank1_direct_control","1")]:
    e=entry(name,rank); f=read(stage/name/("failure.rank"+rank+".json"))
    equality={k:e["nativeArgs"][k]==v for k,v in original["nativeArgs"].items() if k!="this"}
    assert all(equality.values()) and e["model"]==original["model"]
    assert f["frames"][0]["line"]==254
    assert f["nativeFailureVars"]["averageParcelMass"]==failure["nativeFailureVars"]["averageParcelMass"]
    controls.append({"name":name,"rank":rank,"arg_equality":equality,"model_equality":True,"native_failure_line":254,"FPE":True})
D=decimal.Decimal
mass=D(failure["nativeFailureVars"]["mass"]["value"])
massDrop=D(failure["nativeFailureVars"]["massDrop"]["value"])
try:
    result=str(mass/massDrop)
except decimal.DivisionByZero:
    result="DivisionByZero"
assert mass>0 and massDrop==0 and result=="DivisionByZero"
forward=entry("forward_debug_scales","0")
comparison={k:{"reverse":v,"forward":forward["nativeArgs"][k],"equal":v==forward["nativeArgs"][k]} for k,v in original["nativeArgs"].items() if k!="this"}
input_checks=[]
for name,data in read(stage/"exact_input_hashes.json").items():
    changed=[p for p,h in data["files"].items() if hashlib.sha256((stage/name/p).read_bytes()).hexdigest()!=h]
    assert not changed
    input_checks.append({"fixture":name,"files":len(data["files"]),"changed":changed})
# No boundary event exists for the failing parcel: native KH failed before x=4.
boundary_rows=[r for p in (stage/"exact_debug_final").glob("processor*/R1_boundary.csv") for r in csv.reader(p.open())]
assert not boundary_rows
oracle=subprocess.run([sys.executable,str(root/"tools/auditS2R1Boundary.py"),str(stage/"forward_debug_scales")],capture_output=True,text=True)
assert oracle.returncode==0
forward_boundary=json.loads(oracle.stdout)
pre=original["parcelIdentity"]
finite=[]
def walk(v,path):
    if isinstance(v,dict):
        if "value" in v and "finite" in v:
            finite.append({"operand":path,**v})
        else:
            for k,x in v.items():walk(x,path+"."+k)
    elif isinstance(v,list):
        for i,x in enumerate(v):walk(x,path+"["+str(i)+"]")
walk(original["nativeArgs"],"nativeArgs");walk(original["model"],"model");walk(original["averageParcelMass"],"averageParcelMass")
assert all(x["finite"] for x in finite)
summary={"status":"COMPLETE / DIAGNOSIS ONLY","classification":"CLASS E / NATIVE_REITZKHRT_REACHABLE_LIMITATION","native_line":254,"native_expression":"nParticle = mass/massDrop","failed_operands":{"mass":str(mass),"massDrop":str(massDrop)},"Decimal_single_expression_result":result,"native_entry_scalar_components":finite,"all_entry_components_finite":True,"parcel":pre,"support_valid":True,"generation":1,"original_RNG":original["rng"],"controls":controls,"forward_comparison":comparison,"reverse_larger_drop_scales":scale("exact_debug_final","1"),"forward_larger_drop_scales":scale("forward_debug_scales","0"),"exact_input_checks":input_checks,"failing_parcel_boundary_events":len(boundary_rows),"failing_migration_audit":"NOT APPLICABLE: FPE before first transfer; no sender/receiver state exists","forward_boundary_audit":forward_boundary,"root_cause":"zero Urmag with KHindex<0.5 enters native larger-drop branch; captured lengthScale=0, diameterLargerDrop=0, d=0, massDrop=0 then positive mass/zero","historical_FPE1_distinct":True,"S2":"PARTIAL","no_automatic_resume":True}
(stage/"diagnosis_result.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
md="| Operand | Captured value | Finite | Sign | Zero |\n|---|---|---|---|---|\n"
for x in finite:
    md+="| "+x["operand"]+" | "+x["value"]+" | "+str(x["finite"])+" | "+x["sign"]+" | "+str(x["zero"])+" |\n"
md+="\nT/U/rho/thermo context and all parcel/history fields are captured in exact_debug_final/failure.rank1.json and calls.rank1.jsonl. Native ReitzKHRT does not directly read parcel T, Cp, Y or RNG; these are caller context. muc, y, yDot are signature arguments not read by this native update. No physical formula is replaced here.\n"
context=[]
for key in ["d_","nParticle_","rho_","T_","Cp_","mu_","sigma_","U_","UTurb_","tTurb_","tc_","ms_","KHindex_","y_","yDot_","d0_","mass0_","tMom_","liquidCore_","Y_values"]:
    value=failure["failureCall"]["this"].get(key)
    context.append({"field":key,"value":value,"note":"failure state (d/KHindex already changed by native branch)"})
(stage/"PARCEL_CONTEXT.json").write_text(json.dumps(context,indent=2),encoding="utf-8")
(stage/"NATIVE_OPERANDS.md").write_text(md,encoding="utf-8")
print(json.dumps({"status":summary["status"],"class":summary["classification"],"input_checks":input_checks,"controls":[x["name"] for x in controls],"entry_finite_components":len(finite),"failure_line":254,"single_expression":result,"forward_boundary":forward_boundary},indent=2))
