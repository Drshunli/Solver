from pathlib import Path
from decimal import Decimal as D
import csv,json,math,collections,hashlib
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2b_v1'
def rows(p):return list(csv.DictReader(p.open()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((e/'O2A_reaudit_summary.json').read_text())
assert frozen['numericalAudit']=='PASS'
events=[];scan=[];prototype_checks=0
for directory in ('prototypes','prototypes_boiling','prototypes_high'):
 r=json.loads((e/directory/'test_results.json').read_text());assert r['failures']==0
 prototype_checks+=r['checks'];events+=rows(e/directory/'candidate_events.csv');scan+=rows(e/directory/'candidate_sweep.csv')
assert len(events)==20 and len(scan)==3600
inputs={r['name']:r for r in rows(e/'event_inputs.csv')}
independent_checks=0
def close(x,y,scale=None):
 global independent_checks
 u,v=(abs(x),abs(y)) if scale is None else scale
 assert abs(x-y)<=D('1e-30')+128*D(2)**-52*(abs(u)+abs(v)),(x,y)
 independent_checks+=1
for r in events:
 src=inputs[r['event']];a,z=D(src['m1']),D(src['m2']);M=D(r['M']);close(a+z,M)
 close(D(src['EintBefore']),D(r['EintBefore']));close(D(r['Ediss']),D(src['Kbefore'])-D(src['Kafter']))
 close(D(r['Ediss']),D(r['Qheat'])+D(r['reservoir'])+D(r['carrierHypothetical'])) if r['policy']!='E' else close(D(r['Kafter']),D(src['Kbefore']))
 # Property inversion is independently checked by native O2A; here test the exported extended ledger, not a debug counter.
 assert abs(D(r['Eresidual']))<=D('1e-30')+128*D(2)**-52*(abs(D(r['EintBefore'])+D(r['Kbefore']))*2)
 independent_checks+=1
 for k in ('Px','Py','Pz'):
  # Stable sum-absolute scale; actual before magnitudes are in the native affected-event replay.
  if r['event']=='O2A_486':scale=(D(src['m1'])*D('1006.5195')*2,D(src['m1'])*D('366.11194518235226')*2)
  else:scale=(abs(D(src[k+'Before'])),abs(D(r[k])))
  close(D(src[k+'Before']),D(r[k]),scale)
 assert r['physicalApproved']=='0' and r['finiteAPI']=='1'
old=rows(e/'thermal/thermal_sweep.csv');limits={r['p']:r for r in rows(e/'prototypes/native_limits.csv')}
bad=[r for r in old if r['Tnew']=='NaN' or r['boilingExceeded']=='1'];assert len(bad)==96
stats={}
for p in limits:
 group=[r for r in old if r['p']==p];valid=[r for r in group if r['Tnew']!='NaN'];hot=[r for r in valid if r['boilingExceeded']=='1']
 stats[p]={'conditionedStates':len(group),'controlledUnbracketed':len(group)-len(valid),'boilingCriterion':len(hot),
  'boilingExcessVsNativeTMaxK':None if not hot else [min(float(r['Tnew'])-float(limits[p]['TnativeInvert']) for r in hot),max(float(r['Tnew'])-float(limits[p]['TnativeInvert']) for r in hot)],
  'maxDissipationPerMassAllCandidates':max(float(r['diss'])/(1e-12+1e-12/float(r['ratio'])) for r in group)}
with (e/'inadmissible_conditioned_merges.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(old[0]));w.writeheader();w.writerows(bad)
counts={k:collections.Counter(r[k] for r in bad) for k in ('p','relU','ratio','T1','T2')}
reservoir_scan={p:{'states':sum(r['p']==p for r in scan),'AphaseFailures':sum(r['p']==p and r['Aphase']=='0' for r in scan),'BphaseFailures':sum(r['p']==p and r['Bphase']=='0' for r in scan)} for p in limits}
maxA=max(float(r['RAperMass']) for r in scan);maxB=max(float(r['RBperMass']) for r in scan)
nu=2688.9784156997048*.25*math.pi*(2e-6)**2*2013.039*1e-8/(20e-6)**3
dt_analysis=[{'dt':dt,'nu':nu*dt/1e-8,'probabilityAnyEvent':-math.expm1(-nu*dt/1e-8),'conditionalOutcomeChangesWithDt':False} for dt in (1e-8,1e-9,1e-10,1e-11)]
(e/'dt_conditional_analysis.json').write_text(json.dumps({'classification':'analytic conditioned-outcome/source audit; not CFD and not exact random-threshold replay','actualFirstRandomDrawRecorded':False,'cellVolume':'20 micrometre cube harness','rows':dt_analysis},indent=2))
protected=json.loads((e/'protected_before.json').read_text());changed=[p for p,h in protected.items() if sha(b/p)!=h]
if 'MILESTONE_STATUS.md' in changed:
 before=e/'MILESTONE_STATUS.beforeO2B.md';assert sha(before)==protected['MILESTONE_STATUS.md'];assert (b/'MILESTONE_STATUS.md').read_bytes().startswith(before.read_bytes());changed.remove('MILESTONE_STATUS.md')
assert not changed,changed
old_make=json.loads((b/'fitting/dpm/m8a_v1/protected_before.json').read_text())
make_proof={rel:{'current':sha(b/rel),'frozenM8A':old_make[rel]} for rel in ('Make\\files','Make\\options')}
assert all(v['current']==v['frozenM8A'] for v in make_proof.values())
(e/'active_make_comparison.json').write_text(json.dumps(make_proof,indent=2))
contract=json.loads((e/'state_contract_examples.json').read_text());assert contract['failures']==0 and not contract['productionCodecImplemented']
out={'status':'PARTIAL / COLLISION_ENERGY_MODEL_BLOCKER','selectedPolicy':None,'firstActivationAllowed':False,
 'prototypeChecks':prototype_checks,'prototypeFailures':0,'independentCandidateLedgerChecks':independent_checks,'stateContractDesignChecks':contract['checks'],'additionalActiveMakeFilesVerified':2,
 'actualEvents':events,'conditionedMergeStates':3600,'inadmissibleConditionedMerges':96,
 'inadmissibleFractionUnweighted':96/3600,'isProductionEventFrequency':False,'pressureGroups':stats,'badInputBins':counts,
 'reservoirPrototypeScan':reservoir_scan,'maxAReservoirSpecificJperkg':maxA,'maxBReservoirSpecificJperkg':maxB,
 'AEndpointIssue':'16 roots infinitesimally exceed strict native TrMax ceiling at12MPa; arithmetic closure does not waive admissibility',
 'regressions':frozen['regressions'],'goldensByteIdentical':8,'protectedFilesAudited':len(protected),
 'caseFilesUnchanged':frozen['caseFilesUnchanged'],'activeSolverImpact':'NONE','sourceAdapterImpact':'NONE',
 'noCFD':True,'T3BResumed':False,'O2CImplemented':False,'reservoirStateContractCertified':False,
 'blockers':['A/B physical identity and energy-release/work contract unresolved; state contracts are proposals, not deployed authority',
 'C already fails on native grazing; new elastic/no-event law unsupported',
 'D all dissipation to carrier unsupported by native source or cited model',
 'E first-activation exclusion lacks explicit project-owner approval']}
(e/'audit_summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ('actualEvents','regressions')},indent=2))
