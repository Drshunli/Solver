from pathlib import Path
import shutil
b=Path(__file__).resolve().parents[1]
e=b/'fitting/dpm/m8a3b_v1'
case=e/'scan_fixture'
if case.exists(): raise SystemExit('Refusing to overwrite scan fixture')
case.mkdir()
for name in ('0','constant','system'):
    shutil.copytree(b.parent/'300_2D'/name,case/name)
for name in ('log.scan','log.resource'):
    p=e/name
    if p.exists(): p.rename(e/(name+'.attempt1'))
p=e/'run.sh'
p.write_bytes(p.read_bytes().replace(b'/mnt/d/DATA/Solver/300_2D',b'/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_v1/scan_fixture'))
