#include "../fiveEqPrecision/fiveEqFractionPrecision.H"
#include <chrono>
#include <fstream>
#include <iomanip>
#include <random>
#include <vector>
int main(){
 std::mt19937_64 rng(20261003);std::vector<double> x(10000);for(auto& v:x)v=1e-20+(rng()%100000)*1e-12;volatile double sink=0;std::ofstream out("p2_cost_samples.csv");out<<std::setprecision(17)<<"batch,conversionNs,updateNs,payloadBytes\n";
 for(unsigned b=0;b<250;++b){auto t=std::chrono::steady_clock::now();for(unsigned i=0;i<x.size();++i){auto f=fiveEq::PrecisionFraction::minority(x[i],i%2,fiveEq::FractionMode::P2);sink+=f.gasValue();}double conversion=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count()*1e9/x.size();std::vector<fiveEq::PrecisionFraction> f;for(unsigned i=0;i<x.size();++i)f.push_back(fiveEq::PrecisionFraction::minority(x[i],i%2,fiveEq::FractionMode::P2));t=std::chrono::steady_clock::now();for(unsigned i=0;i<f.size();++i){auto g=f[i].advanced({-x[i]*.001,0});sink+=g.gasValue();}double update=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count()*1e9/x.size();out<<b<<','<<conversion<<','<<update<<",8\n";}
 std::ofstream checksum("benchmark_checksum.txt");checksum<<sink<<'\n';
}
