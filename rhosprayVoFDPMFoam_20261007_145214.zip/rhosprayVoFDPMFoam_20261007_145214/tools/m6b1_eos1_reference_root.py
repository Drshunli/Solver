from pathlib import Path
from decimal import Decimal,localcontext
import sys,csv,json,math
import numpy as np
from numpy.polynomial import chebyshev as ch
b=Path(__file__).resolve().parents[1];s=b/'fitting/integration/m6b1_eos1_ndecane_v1';sys.path.insert(0,str(b/'fitting/reference_backend'))
import CoolProp.CoolProp as CP
from scipy.optimize import brentq
rows=list(csv.DictReader((s/'recovery_results.csv.nativeGas.csv').open()));press=np.array([float(x['p']) for x in rows]);energy=np.array([float(x['eG']) for x in rows]);train=np.arange(0,65,8);coef=ch.chebfit((press[train]-3.25e6)/.25e6,energy[train],5);error=float(np.max(np.abs(ch.chebval((press-3.25e6)/.25e6,coef)-energy)))
ref=CP.AbstractState('HEOS','n-Decane');rhoL=712.38217542998609
D=lambda x:Decimal.from_float(float(x))
with localcontext() as ctx:
 ctx.prec=60
 mg=D(13.869723487241057);ml=D(6.4254079426687836e-19);target=D(4325279.2929416951);offset=D(369229.9537234281);coeff=[D(x) for x in coef]
 def nativeGasPolynomial(p):
  x=(p-Decimal(3250000))/Decimal(250000);t0=Decimal(1);t1=x;value=coeff[0]*t0+coeff[1]*t1
  for c in coeff[2:]:t0,t1=t1,2*x*t1-t0;value+=c*t1
  return value
 def liquid(p):
  pf=float(p)
  def f(T):ref.update(CP.PT_INPUTS,pf,T);return ref.rhomass()-rhoL
  T=brentq(f,315,330,xtol=1e-11);ref.update(CP.PT_INPUTS,pf,T)
  return T,D(ref.umass())+offset
 def residual(p):return mg*nativeGasPolynomial(p)+ml*liquid(p)[1]-target
 lo,hi=Decimal(3000000),Decimal(3500000);assert residual(lo)<0 and residual(hi)>0
 for i in range(160):
  mid=(lo+hi)/2
  if residual(mid)<0:lo=mid
  else:hi=mid
 p=(lo+hi)/2;T,eL=liquid(p);ref.update(CP.PT_INPUTS,float(p),T)
 out={'method':'60-decimal accumulation/bisection of FULL common residual; degree5 native JANAF eG(p) on single low-T branch; independent HEOS n-Decane eL(rho,p); phase retained','gasNativeSamples':65,'gasTrainingSamples':9,'gasHoldoutSamples':56,'maxGasEnergyApproximationError_J_kg':error,'estimatedGasFitPressureUncertainty_Pa':error*float(mg)/2.3,'pStar_Pa':float(p),'pStarArithmeticOnly_decimal':str(p),'residual_J_m3_arithmeticOnly':str(residual(p)),'TLStar_K':T,'rhoL':rhoL,'eL_solver':float(eL),'betaL':ref.first_partial_deriv(CP.iUmass,CP.iP,CP.iDmass),'cL':ref.speed_sound(),'phase':int(ref.phase()),'liquidWeightedEnergy_J_m3':float(ml*eL),'warning':'decimal precision does not increase native-gas sample/CoolProp binary64 accuracy or reference-EOS experimental accuracy'}
 (s/'independent_common_reference_root.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
