from pathlib import Path
import shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_v1'
for name in ('run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh'):
 (e/name).write_bytes((b/'fitting/dpm/m8a3a_v1'/name).read_bytes().replace(b'm8a3a_v1',b'm8a3b_v1'))
for state in 'ABC':
 for name in ('0','constant','system'):
  shutil.copytree(b/'tests/fiveEqDPMRebinding'/('fixture'+state)/name,e/'rebinding_fixtures'/state/name)
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\n'
(e/'run_rebinding.sh').write_bytes((head+'base=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\nfor state in A B C; do\n mkdir -p "$base/fitting/dpm/m8a3b_v1/rebinding/$state"\n cd "$base/fitting/dpm/m8a3b_v1/rebinding/$state"\n /usr/bin/time -v "$base/tests/fiveEqDPMRebinding/testFiveEqDPMRebinding" "$base/fitting/dpm/m8a3b_v1/rebinding_fixtures/$state" "$state" > log.run 2> log.resource\ndone\n').encode())
