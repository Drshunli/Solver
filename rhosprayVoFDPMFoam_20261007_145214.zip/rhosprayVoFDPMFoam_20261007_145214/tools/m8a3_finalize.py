from pathlib import Path
import json,hashlib,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3_v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=json.loads((e/'test_results.json').read_text());assert audit['checks']==54 and audit['failures']==0 and not audit['transactionSafe']
energy=[]
for mode in ('zero','heat','momentum','mass','evaporation','combined','disappearance','permuted'):
 new=e/'energy_regressions'/mode;old=b/'fitting/dpm/m8a_v1'/mode;r=json.loads((new/'test_results.json').read_text());assert r['failures']==0
 same={n:sha(new/n)==sha(old/n) for n in ('golden_energy.csv','ledger.csv','test_results.json','test_failures.txt')};assert all(same.values());energy.append({**r,'byteIdentical':same})
assert sum(r['checks'] for r in energy)==9288
d=[]
for mode in ('grid_final','legacy','long','ordering','volume','cost','O0','diagnostics','subulp','boundary'):
 p=e/'D_regressions'/mode;q=b/'fitting/dpm/m8a_v1/D_regressions'/mode
 assert (p/'exit_status.txt').read_text().strip()=='0'
 r=json.loads((p/'test_results.json').read_text());assert r['failures']==0
 same={n:sha(p/n)==sha(q/n) for n in ('test_results.json','test_failures.txt') if (q/n).exists()};assert all(same.values());d.append({'directory':mode,**r,'byteIdenticalResults':same})
temporal=e/'temporal';old=b/'fitting/dpm/m8a_v1/temporal';r=json.loads((temporal/'test_results.json').read_text());assert r['failures']==0 and r['checks']==9663
temporalSame={n:sha(temporal/n)==sha(old/n) for n in ('test_results.json','test_failures.txt')};assert all(temporalSame.values())
reg={'sourceEnergy':{'checks':9288,'failures':0,'modes':energy},'P2RecoveryR1':{'reportedChecks':sum(item.get('checks',0) for item in d),'subULPStepsPerScheme':1000,'failures':0,'modes':d},'temporalRestart':{**r,'byteIdenticalResults':temporalSame}}
(e/'regression_summary.json').write_text(json.dumps(reg,indent=2))
before=json.loads((e/'protected_before.json').read_text());changed=[]
for n,value in before.items():
 p=b/n
 if not p.exists() or sha(p)!=value:changed.append(n)
(e/'changed_files_audit.json').write_text(json.dumps(changed,indent=2))
allowed={'MILESTONE_STATUS.md','tests/fiveEqDPMEvolvedAudit/testFiveEqDPMEvolvedAudit.C'}
assert set(changed)<=allowed
(e/'protected_comparison.json').write_text(json.dumps({'changedSincePreparation':changed,'auditHarnessCreatedThisRound':True,'auditHarnessChanges':'const interface and indentation compilation repair only','historicalEvidenceUnchanged':True,'frozenCodeUnchanged':True,'activeSolverImpact':'NONE'},indent=2))
summary={'M8A3':'PARTIAL','M8A':'PARTIAL','blocker':'MODEL_TRANSACTION_BLOCKER','stopRule':'User section 51','evolvedAudit':audit,'regressions':reg,'modelClassification':'All eight NOT TRANSACTION-SAFE for current evolved-copy path','activeImpact':'NONE','noCFD':True,'M6B0':'BLOCKED','M6B1':'NO'}
(e/'summary.json').write_text(json.dumps(summary,indent=2))
report=b/'M8A3_MODEL_TRANSACTION_BLOCKER.md';s=report.read_text();s=s.replace('These results are verified separately from transaction closure.','Verified: source/energy 9288, P2/recovery/R1 '+str(reg['P2RecoveryR1']['reportedChecks'])+' reported checks plus subULP 1000 steps per scheme, temporal/restart 9663 checks; all zero failures. Frozen source golden/ledger bytes and regression result bytes match baseline. These results are separate from transaction closure.');report.write_bytes(s.encode())
files=[b/'MILESTONE_STATUS.md',report,b/'docs/M8A3_TRANSACTION_STATE_INVENTORY.md',b/'tools/m8a3_prepare.py',b/'tools/m8a3_finalize.py']
for folder in (b/'tests/fiveEqDPMEvolvedAudit',e):
 for p in folder.rglob('*'):
  if any(n in p.parts for n in ('lnInclude','Make','linux64GccDPInt32Opt')):continue
  if p.is_file():files.append(p)
files.extend((b/'tests/fiveEqDPMEvolvedAudit/Make'/n) for n in ('files','options'))
dest=b/'checkpoints/M8A3_evolved_model_transaction_BLOCKER_v1_PARTIAL.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):z.write(p,str(p.relative_to(b)))
(e/'checkpoint.sha256').write_text(sha(dest)+'  '+dest.name+'\n')
print(json.dumps({'auditChecks':54,'sourceEnergy':9288,'P2RecoveryR1ReportedChecks':reg['P2RecoveryR1']['reportedChecks'],'subULPStepsPerScheme':1000,'temporalRestart':9663,'failures':0,'status':'PARTIAL / MODEL_TRANSACTION_BLOCKER','checkpoint':str(dest)}))
