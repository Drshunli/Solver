from pathlib import Path
import json,hashlib,gzip,re
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a2_v1'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
total=0;results=[]
for mode in ('zero','heat','momentum','mass','evaporation','combined','disappearance','permuted'):
 new=e/'energy_regressions'/mode;old=b/'fitting/dpm/m8a_v1'/mode
 r=json.loads((new/'test_results.json').read_text());total+=r['checks'];same={n:digest(new/n)==digest(old/n) for n in ('golden_energy.csv','ledger.csv','test_results.json','test_failures.txt')}
 results.append({'mode':mode,**r,'byteIdentical':same})
assert total==9288 and all(r['failures']==0 and all(r['byteIdentical'].values()) for r in results)
(e/'frozen_regression_comparison.json').write_text(json.dumps({'checks':total,'failures':0,'modes':results},indent=2))
snapshot=json.loads((e/'protected_before.json').read_text());changes=[]
for name,sha in snapshot.items():
 p=b/name
 if not p.exists() or digest(p)!=sha:changes.append(name.replace('\\','/'))
active=('rhosprayVoFDPMFoam.C','createClouds.H','rhoEqn.H','rhoUEqn.H','rhoEEqn.H','rhoYEqn.H','alphaEqn.H','createFields.H')
assert all(n not in changes for n in active)
frozen=['dpmFiveEq/fiveEqDPMSourceAdapter.H','dpmFiveEq/fiveEqNativeDPMExtraction.H','dpmFiveEq/fiveEqNativeDPMSourceSnapshot.H']
assert all(n not in changes for n in frozen)
(e/'protected_comparison.json').write_text(json.dumps({'changedSincePreparation':changes,'activeImpact':'NONE','sourceCoreChanged':False,'activeHashes':{n:snapshot.get(n) for n in active}},indent=2))
f=b/'tests/fiveEqDPMTransaction/fixture_noWrite';outputs=[str(p.relative_to(f)) for p in f.rglob('*') if p.is_file() and p.relative_to(f).parts[0] not in ('0','constant','system')]
assert not outputs
(e/'noWrite_artifacts.json').write_text(json.dumps({'fixture':str(f),'permanentTrialArtifacts':outputs,'writeTimeForced':True,'acceptedOutputProtocolTested':False},indent=2))
mesh=b.parent/'300_2D/constant/polyMesh';owner=gzip.open(mesh/'owner.gz','rt').read();counts={k:int(v) for k,v in re.findall(r'(nPoints|nCells|nFaces|nInternalFaces):\s*(\d+)',owner)}
counts['nBoundaryFaces']=counts['nFaces']-counts['nInternalFaces'];counts['basisEntities']=counts['nCells']+counts['nBoundaryFaces'];counts['probeLimit']=256;counts['strictFeasibilityScan']='NOT_EXECUTED';counts['reason']='Native exact basis probe is bounded; scalable exact stencil extraction has not been implemented.'
(e/'actual_mesh_preflight.json').write_text(json.dumps(counts,indent=2))
print(json.dumps({'frozenChecks':total,'activeImpact':'NONE','trialArtifacts':len(outputs),'actualMesh':counts},indent=2))
