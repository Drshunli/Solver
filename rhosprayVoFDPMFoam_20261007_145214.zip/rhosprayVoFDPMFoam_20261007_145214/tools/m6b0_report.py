from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parents[1];s=b/'fitting/integration/m6b0_serial_active_v1'
g=json.loads((s/'M6B0_gate.json').read_text());assert g['status']=='COMPLETE';r=g['results'];d=g['primitiveDiagnostics']
def write(p,t):p.write_text(t,encoding='utf8',newline='\n')
exe=g['executableSHA256'];sourceSHA=hashlib.sha256((s/'compiled_project_source_manifest.json').read_bytes()).hexdigest()
rows='\n'.join(f"| {k} | {v['steps']} | {v['maxPressureRelative']:.6e} | {v['maxConservationRelative']:.6e} | {v['acceptedRecoveryFailures']} |" for k,v in r.items())
cons=[max(v['conservationByComponent'][j] for v in r.values()) for j in range(9)]
owned='''| Field / state | Owner | Created / updated | Meaning |
|---|---|---|---|
| P2 | TemporalState.committed[i].fraction | exact P2Bits fresh input; frozen advanced() | signed binary64 minority; +0 pure gas / -0 pure liquid |
| mG / mL | q[1/2] | frozen shared KT candidate and whole commit | phase partial densities |
| M | q[3:6] | same transaction | mixture momentum density |
| Et | q[6] | same transaction | mG eG+mL eL+0.5 rhoMix U² |
| mY_C10H22 / mY_O2 | q[7/8] | shared species flux | N-1 independent species |
| mY_N2 | q[9] | algebraic residual, then revalidate | mG-mY_C10H22-mY_O2; no normalization |
| q[0] / alphaL | P2 decoded mirror | frozen P2 trial / accepted publication | not a second alpha authority |
| alphaG | P2.gasValue() | accepted publication | not 1-rounded alphaL; preserves trace gas |
| rhoG / rhoL | frozen R1 | whole accepted-state recovery | absent phase output=0, no fake phase |
| rhoMix / U / p / TG / TL / YG_* | accepted Q/recovery | publish only after all recoveries succeed | derived, no independent PDE |
| 20 volScalar/VectorFields | runSerialFiveEq | register once, lookup owner checks | OpenFOAM output mirrors of accepted Q |
| old rho / rhoU / rhoE / phi | isolated legacy branch | not created by serialFiveEq | frozen historical reference |
'''
audit='''# M6B0_ACTIVE_AUTHORITY_AUDIT_v1

## Scope and exclusive dispatch

实际 rhosprayVoFDPMFoam executable，实际 fvMesh 和 Time，入口 `-serialFiveEq`。只认证固定、等距、单位截面积一维周期 chain。主入口在 createTime/createDynamicFvMesh 后直接 return runSerialFiveEq；return 位于旧 createControls/createFields/cloud/interface 创建之前。未选择该选项时 legacy reference 分支仍存在，但本轮没有运行，绝不在同一 active step 与 fiveEq 同时执行。

Active不调用旧 rhoEqn/rhoUEqn/rhoEEqn/rhoYEqn/alphaEqn、fvm/fvc second conservation、PIMPLE/PISO/pEqn，也不创建旧 global thermo/cloud/turbulence/interface。DPM/ST 字典 guard 必须 false，K 必须0，verificationOnly 必须 true。所有测试不包含 sprayCloudProperties/global thermophysicalProperties/interfaceProperties 而能正常运行，佐证没有这些对象依赖。

## Sole Q/P2 authority and transaction

TemporalState.committed 的 P2、q[1:10] 是唯一 accepted authority。20个 registered volFields 是 accepted mirror，不被第二套 PDE 更新。driver 在候选 copy 上执行原封冻结 reconstruction→face R1→Allaire→shared KT waves/flux→joint dt→trial→recovery→accept。N2=mG-mY_C10H22-mY_O2 residual 后整批复核，随后 active commit、Time 更新、整批 primitive publication。无部分 field publication，无 normalize/clip。

冻结 explicitTrial 内普通 q[0] 的中间 alpha 运算结果会被 PrecisionOperator::trial 的 P2 authoritative 更新覆盖；它不是另一个可提交的 alpha PDE。P2 从 DD fraction difference 经 advanced() 更新，不从 rounded alpha 重建。fresh 初始化用精确位串，保留 -0。

## Geometry/ALE

对实际 mesh 验证 N−1 内部 x 向单位面积面、相邻拓扑、等距 cells、V=dx、两个 cyclic 端面相互配对、横向 empty，然后才用冻结 periodic driver 的 Sf=(1,0,0)。因此真实物理 volume 与冻结 driver volume 一致，没有隐藏缩放。横向空方向在1D reduction中消去。其他几何拒绝，非通用2D/3D认证。

冻结 face(meshPhi)/KT ALE API 未改；本轮 fixed mesh默认 Umesh=0。质量/动量仍是相对对流，energy保留 absolute p-work，alpha保留physical divU。移动网格/GCL没有运行或认证。

## Read-only R1 counting and pure/trace state

GNU linker --wrap 观察原 fiveEqPrecisionRecovery::recover，调用 __real_，不改 options/Q/P2/root/EOS。原有可选 progress Snapshot 只用于失败计数；返回结果/异常原样传回。所有跨 translation-unit R1 调用含 initial/limiter probes/face/candidate/accepted 被计数；publication另外计数。本轮所有失败含 probes=0。没有故意执行新的 failed candidate replay，拒绝算法沿用冻结M5C.3。

生成器仅查询真实存在相；纯气liquidQueries=0，纯液gasQueries=0，两种1e-20trace正质量/signedP2均保留。没有fake相。restart输出用原fiveEqRestart-v1/P2-v1；本轮active adapter拒绝startTime!=0，不读alpha-only restart；production restart未认证。

## Ownership

'''+owned+'''
## Source impact

30,618个前序冻结条目已核对。仅授权主入口、Make/files/options、5项root target生成编译文件及本轮milestone追加允许变化，逐项before/after SHA记录在frozen_delta_audit.json；不是对冻结library源码的例外。恢复/EOS/P2/KT/reconstruction/integration/DPM C/H源文件全部unchanged。compiled_project_source_manifest.json记录72个当前编译project依赖并保留源文件副本；Foundation6717/nativeparcel19哈希重新通过。300/300_2D/原rhosprayFoam共132文件unchanged。

同一binary仍链接legacy DPM/ST依赖，不声称未链接；前置return与active源码和无cloud配置成功运行，证明本轮不执行、不发布其源项。不运行production、MPI、restart、喷口或T4-S3。
'''
write(b/'M6B0_ACTIVE_AUTHORITY_AUDIT_v1.md',audit)
sections=[]
def sec(i,title,body):sections.append(f'# {i}. {title}\n\n{body}\n')
sec(1,'M6B.0 status','**COMPLETE / SERIAL ACTIVE FIVE-EQUATION BOOTSTRAP**；316项PASS。仅一维周期串行固定单位截面积micro-case认证；不是production CFD validation。')
sec(2,'Active authority','实际solver -serialFiveEq分支中的accepted Q/P2为唯一authority。rhoMix=mG+mL，U=M/rhoMix，Et=mG eG+mL eL+½rhoMix|U|²。')
sec(3,'Old-core isolation','前置return在旧createFields/cloud/interface前；old rho/rhoU/rhoE方程不执行，原方程字节unchanged。详见authority audit。')
sec(4,'Active fields',owned)
sec(5,'P2 authority','精确signed binary64 P2Bits初始化，冻结advanced()更新。+0/-0和±1e−20精确保留；alphaL/alphaG派生，无第二authority。')
sec(6,'Pressure recovery','冻结R1：Eint=Et−½M·U；R=mG eG(rhoG,p,YG)+mL eL(rhoL,p)−Eint，R′=mG betaG+mL betaL。Pure-phase原分支unchanged；无pEqn/PIMPLE/替代root/new EOS fallback。')
sec(7,'Gas thermo','冻结fiveEqGasThermoEvaluator复用Foundation7 specie/perfectGas/JANAF/sensibleInternalEnergy、C10H22/O2/N2 local mass-weighted mixture，沿用reactingMixture已审计的热力学组合及数据。active没有新建旧global reactingMixture field object；不激活反应/旧thermo.correct，不换gas package。')
sec(8,'Liquid EOS','ndecane_gibbs_v1 TABLE-B standalone Chebyshev，C_L=369229.9537234281 J/kg，e/h_solver=e/h_native+C_L。factory/evaluator冻结unchanged，无CoolProp runtime。')
sec(9,'Gas-only uniform',f"10步PASS，conservative/primitive漂移0，p相对误差{r['gas']['maxPressureRelative']:.6e}，liquidQueries=0，mL=0，P2=+0。")
sec(10,'Liquid-only uniform',f"10步PASS，conservative/primitive漂移0，p相对误差{r['liquid']['maxPressureRelative']:.6e}，gasQueries=0，mG=0，P2=-0，无fake gas。")
sec(11,'Mixed states',f"alphaL=.1/.5/.9各10步PASS；p=3MPa，U=(47,0,0)，TG=800K，TL=300K。状态和P2保存，最大p相对误差{r['mixed09']['maxPressureRelative']:.6e}。")
sec(12,'Trace state','液相1e−20与gas-minority P2=-1e−20各10步PASS，P2位串和trace不变，phase mass均正。负P2时alphaL输出舍入成1不删除气相，alphaG直接由P2.gasValue()派生。')
sec(13,'Contact',f"M5C.3/M5C.2结构common-p/U pure gas/liquid接触，实际solver10步，最大p相对误差{r['contact']['maxPressureRelative']:.6e}<预先给定1e−8，无调参。")
sec(14,'Species contact',f"alphaL=.1，两侧YG=(0,.228,.772)/(.1,.2,.7)，10步PASS。p相对误差{r['speciesContact']['maxPressureRelative']:.6e}，N2 residual无normalize/clip。")
sec(15,'Alpha advection',f"20步：alphaL=.5+.02sin(2πi/20)，U47m/s，dt1e−5s，周期长20m。冻结K=0、无MULES/compression。实际alpha最大变化{d['smooth']['maxAlphaChange']:.6e}；对解析平移全过程最大绝对误差{r['smooth']['maxAlphaAdvectionAbsolute']:.6e}。bounded，1次合法P2 branch切换；不声称网格收敛阶/长期精度认证。")
for i,title,j,n in [(16,'mG conservation',0,1),(17,'mL conservation',1,1),(18,'Momentum conservation',2,3),(19,'Energy conservation',5,1),(20,'Species conservation',6,3)]:
 sec(i,title,'周期闭域，无外部通量/源项；最终各分量最大缩放误差：'+', '.join(f'{v:.6e}' for v in cons[j:j+n])+'。全过程见accepted_steps.csv；分母max(|初始积分|,1 SI)，零初始分量按该尺度报告，trace均匀积分误差0。')
sec(21,'Recovery counters',f"全部R1调用{g['allRecoveryCalls']}，iterations {g['allRecoveryIterations']}，失败0（含limiter probes）；accepted publication calls {g['acceptedRecoveryCalls']}，失败0。state class/query计数逐例记录。--wrap只读，不改算法。")
sec(22,'Timestep logic','复用冻结driver joint acoustic/alpha/mass/species约束、connectedDt与16次retry；先candidate验证再commit，当前全部rejectedTrials=0，dt1e−5s。不声称本轮又做failed candidate回滚试验。')
sec(23,'KT flux authority','复用PrecisionReconstruction strategy1、PrecisionOperator::face和fiveEqTemporalDriver。所有守恒量共享left/right state、KT wave/weights/Sf，不新增第二flux。')
sec(24,'Sound speed','冻结Allaire：xi_k=rho_k beta_k，w_k=m_k/rhoMix；cA²=(wG xiG cG²+wL xiL cL²)/(alphaG xiG+alphaL xiL)。Pure-phase用该相sound speed。')
sec(25,'ALE compatibility','冻结meshPhi/API不改，本轮Umesh=0。质量mk(U−Umesh)·Sf，动量M(U−Umesh)·Sf+pSf，能量Et(U−Umesh)·Sf+pU·Sf；alpha physical divU。移动mesh/GCL未运行未认证。')
sec(26,'Boundaries exercised','仅一维等距单位面积cyclic x、横向empty；非该geometry拒绝。fixedValue/zeroGradient、任意2D/3D、多维inlet/wall/nozzle未认证。')
sec(27,'DPM disabled proof','提前return，不创建cloud/SLGThermo，不调用evolve/SU/Sh/Srho或M8A source adapter。10cases无sprayCloudProperties仍正常运行。legacy DPM库可链接但不执行。')
sec(28,'Surface tension disabled','不创建interfaceProperties，不计算sigma/曲率/表面力，无MULES。DPM=false/ST=false/K=0启动guard。')
sec(29,'Serial-only proof','最终10日志nProcs:1，直接执行actual solver，无mpirun/decomposition；parRun guard拒绝MPI。T4-S2不升级active MPI。')
sec(30,'Compile result','最终wclean+fresh wmake exit0，errors0/warnings0。最终binary重跑10cases全部exit0/normal exit/no timeout。首次relative path IO failure、dimensionSet赋值startup failure日志保留；只修新适配层，未改冻结物理算法。')
sec(31,'Executable SHA',f'`{exe}`。installed及封存runtime binary、运行前后SHA相同；55个linked libraries SHA另存。')
sec(32,'Foundation hashes','重新核对6717源码/Make和19 native parcel项全部PASS；实际gas/patch源码8文件读取并记录SHA；系统OpenFOAM无修改。')
sec(33,'Project hashes',f'30,618 frozen baseline、72 compiled project dependencies。manifest SHA `{sourceSHA}`。逐项差异见frozen_delta_audit.json，附compiled_sources；冻结模块源码unchanged。')
sec(34,'Active source deltas','改main前置dispatch、Make/files/options；新增serialFiveEq/runSerialFiveEq.H/.C、recoveryObservation.H/.C及输入/审计/报告工具；编译现有冻结Precision/Flux/Reconstruction C。不建新库、不改frozen C/H。active_source.patch可复核。')
sec(35,'Production input impact','NONE：300/300_2D/原rhosprayFoam共132文件unchanged。未运行生产jet/crossflow/atomization/MPI/restart。目标active solver源码和binary有本轮授权变化，不标其impact NONE。')
sec(36,'Whether M6B.0 COMPLETE','YES，仅串行1D periodic bootstrap。所有请求的uniform/pure/mixed/trace/contact/species/alpha/守恒/编译/隔离gate通过；非通用多维、moving mesh、restart reader或production认证。')
sec(37,'Next permitted milestone','M6B.1 NEXT ROUND ONLY，可在后续用户授权范围讨论serial Eulerian wave/contact/shock；当前未执行。多维网格适配和边界认证需单独计划；active DPM/T4-S3后置。')
sec(38,'T4 status','T4-S1/S2 COMPLETE/FROZEN；T4-S3 DEFERRED/NOT CERTIFIED/NOT EXECUTED；T4 PARTIAL，global MPI transaction未认证。本轮owner路线切换优先于旧报告M6BNO。')
sec(39,'M8A/M6B status','M8A PARTIAL；M6B.0 COMPLETE；M6B PARTIAL；既有T3/R2/S1/S2/PW1冻结证据不改。')
sec(40,'Updated milestone matrix','''| Milestone | Status |
|---|---|
| M0–M4 / M5A/B / frozen EOS/R1/P2 / M5C.1/.2/.3 | 保持既有状态，不重新升级 |
| T3 / T4-S1 / T4-S2 | COMPLETE / FROZEN |
| T4-S3 | DEFERRED / NOT CERTIFIED / NOT EXECUTED |
| T4 / M8A | PARTIAL |
| M6B.0 | COMPLETE / SERIAL ACTIVE FIVE-EQUATION BOOTSTRAP（周期1D） |
| M6B | PARTIAL |
| M6B.1 | NEXT ROUND ONLY / NOT EXECUTED |
| production restart / MPI / CFD | NOT CERTIFIED |

STOP；未进入M6B.1、active DPM、T4-S3、surface tension、VOF→DPM或production。''')
report='\n'.join(sections)+'\n## Micro-case evidence\n\n| Case | Steps | Max relative p error | Max scaled conservation error | Accepted recovery failures |\n|---|---:|---:|---:|---:|\n'+rows+'\n\nEvidence: fitting/integration/m6b0_serial_active_v1/cases_final; gate M6B0_gate.json（316PASS）。\n'
write(b/'M6B0_SERIAL_ACTIVE_FIVEEQ_REPORT_v1.md',report)
append='''\n\n## M6B.0-SERIAL-ACTIVE-FIVEEQ — COMPLETE (2026-10-04)\n\nOwner deferred T4-S3 and authorized serial active Eulerian bootstrap. Actual solver -serialFiveEq exits before legacy fields/cloud/equations. Frozen P2/R1/KT/M5C.3 reused, sole Q, N-1 residual, K=0 alpha, DPM/ST OFF. Runtime restricts fixed uniform unit-area 1D cyclic mesh; no production/MPI/multidimensional/restart certification. Final clean compile exit0/errors0/warnings0; final10microcases normal exit. Uniform conservative+primitive drift0, recovery failures0, contact pressure2.156053113822054e-13, smooth analytic alpha absolute error9.564114781990263e-5 reported untuned. 316checksPASS; Foundation6717/native19/production132 unchanged; frozen modules unchanged, authorized main/Make/generated build delta listed. M6B.0COMPLETE;M6BPARTIAL;T4/M8APARTIAL;S1/S2COMPLETEFROZEN;S3DEFERRED/NOTCERTIFIED/NOTEXECUTED. Production CFD/MPI/restartNOTCERTIFIED. See M6B0_ACTIVE_AUTHORITY_AUDIT_v1.md and M6B0_SERIAL_ACTIVE_FIVEEQ_REPORT_v1.md. STOP;M6B.1NEXTROUNDONLY.\n'''
p=b/'MILESTONE_STATUS.md';t=p.read_text();assert '## M6B.0-SERIAL-ACTIVE-FIVEEQ — COMPLETE' not in t;write(p,t+append)
print('40-item report, authority audit and milestone written')
