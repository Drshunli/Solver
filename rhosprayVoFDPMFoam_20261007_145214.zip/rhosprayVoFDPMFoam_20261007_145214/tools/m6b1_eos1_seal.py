from pathlib import Path
import json,hashlib,zipfile,os,re
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/integration/m6b1_eos1_ndecane_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
g=json.loads((s/'gate_status.json').read_text());assert g['status']=='PARTIAL' and g['knownRecovered']==86 and g['missing']==98
report=b/'M6B1_EOS1_NDECANE_QUALIFICATION_REPORT_v1.md';assert len(re.findall(r'^## \d+\.',report.read_text(),re.M))==34
base=json.loads((s/'protected_before.json').read_text());after={};delta=[]
for rel,h in base.items():
 v=sha(root/rel);after[rel]=v
 if v!=h:delta.append(rel)
assert delta==['rhosprayVoFDPMFoam/MILESTONE_STATUS.md'],delta
for file,n in [('foundation_verification.txt',6717),('foundation_parcel_verification.txt',19)]:assert sum(x.endswith(': OK') for x in (s/file).read_text().splitlines())==n
parent=root/'checkpoints/M6B1_SR1_SERIAL_DIAGNOSIS_COMPLETE_v1.zip';assert sha(parent)=='9b6d36e2186619b74c624cb1364958a8a41d8caa5131b51b7fcfe2893f5e7fb5'
(s/'closing_protection.json').write_text(json.dumps({'checked':len(base),'unexpectedChanges':[],'historyAppendOnly':delta,'parentSHA256':sha(parent),'activeEOS':'ndecane_gibbs_v1 unchanged','activeIntegration':False,'temporalChange':False},indent=2))
source={}
for folder in [s/'shadow_recovery',s/'ndecane_gibbs_v2_candidate',b/'tests/fiveEqEOS1Extract']:
 for wd,dirs,names in os.walk(folder):
  dirs[:]=[x for x in dirs if x not in ['lnInclude','linux64GccDPInt32Opt']]
  for n in names:
   p=Path(wd)/n
   if p.suffix in ['.C','.H','.json'] or n in ['files','options']:source[p.relative_to(root).as_posix()]=sha(p)
(s/'final_source_sha.json').write_text(json.dumps(source,indent=2))
files=[p for p in s.rglob('*') if p.is_file() and p.name not in ['checkpoint_seal.json','frozen_after.json','checkpoint_contents.json']]
files.extend([report,b/'MILESTONE_STATUS.md']);files.extend((b/'tools').glob('m6b1_eos1_*.py'))
for wd,dirs,names in os.walk(b/'tests/fiveEqEOS1Extract'):
 dirs[:]=[x for x in dirs if x!='lnInclude'];files.extend(Path(wd)/n for n in names)
manifest={p.relative_to(root).as_posix():sha(p) for p in sorted(set(files))}
contents=s/'checkpoint_contents.json';contents.write_text(json.dumps({'status':'PARTIAL','candidateEOS':'PROVISIONAL SHADOW / NOT ACTIVE','knownRecords':86,'missingRecords':98,'M6B1':'PARTIAL','EOS2Allowed':False,'noDynamics':True,'parentSHA256':sha(parent),'files':manifest},indent=2));manifest[contents.relative_to(root).as_posix()]=sha(contents)
archive=root/'checkpoints/M6B1_EOS1_NDECANE_PARTIAL_SHADOW_v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel in manifest:z.write(root/rel,rel)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for rel,h in manifest.items():assert hashlib.sha256(z.read(rel)).hexdigest()==h,rel
seal={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(manifest),'CRC':'PASS','perFileSHA256':'PASS','status':'PARTIAL / SHADOW ONLY','missingRecords':98,'EOS2Allowed':False}
(s/'checkpoint_seal.json').write_text(json.dumps(seal,indent=2))
for p in set(files+[contents,s/'checkpoint_seal.json',archive]):after[p.relative_to(root).as_posix()]=sha(p)
(s/'frozen_after.json').write_text(json.dumps(after,indent=2));print(json.dumps(seal,indent=2));print('Frozen entries',len(after))
