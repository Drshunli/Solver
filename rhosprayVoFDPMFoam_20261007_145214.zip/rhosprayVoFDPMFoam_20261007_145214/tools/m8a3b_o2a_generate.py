from pathlib import Path
b=Path(__file__).resolve().parents[1];t=b/'tests/fiveEqORourkeThermal'
prefix=(b/'tests/fiveEqORourkeConservative/testFiveEqORourkeConservative.C').read_text().split(' auto initial=')[0]
prefix=prefix.replace('#include "captureNative.H"','#include "thermalPolicyProbe.H"\n#include <chrono>\nclass NativeSortedProbe:public Foam::ORourkeCollision<m8a3a::Kin>{public: NativeSortedProbe(const Foam::dictionary&d,m8a3a::Kin&c):Foam::ORourkeCollision<m8a3a::Kin>(d,c){} using Foam::ORourkeCollision<m8a3a::Kin>::collideSorted;};')
prefix=prefix.replace(' const std::string state(argv[2]);unsigned history=state=="A"?5:state=="B"?7:9;',' const std::string state(argv[2]);')
prefix=prefix.replace(' const std::string state(argv[2]);',' const std::string state(argv[2]); const double pBoot=state=="BOILING"?188330.307:3e6;')
prefix=prefix.replace('3e6,800,300,Foam::vector(47,0,0)','pBoot,800,300,Foam::vector(47,0,0)')
body=r'''
 auto initial=std::unique_ptr<m8a3a::Cloud>(new m8a3a::Cloud("roleA",rho,U,gravity,slg,false));
 o2::Audit audit("thermal_events");o2::Policy probe(initial->stochasticCollision().dict(),*initial,audit);
 Foam::scalarField Y(1,1);auto&liquids=initial->composition().liquids();auto X=liquids.X(Y);
 auto E=[&](double p,double T){return probe.specificE(p,T,Y);};
 std::ofstream table("native_properties.csv");table<<std::setprecision(17)<<"p,T,rho,h,e,Cp,mu,sigma,pv,de_dT_fd\n";
 double minSlope=Foam::great,maxCpMismatch=0;unsigned slopeSamples=0;
 for(double p:{188330.307,3e6,12e6})for(unsigned i=0;i<=2000;++i){double T=243.51+(617.7-243.51)*i/2001.,delta=1e-4;
  double cp=initial->composition().Cp(0,Y,p,T),h=initial->composition().H(0,Y,p,T);
  double slope=(E(p,T+delta)-E(p,T-delta))/(2*delta);minSlope=std::min(minSlope,slope);++slopeSamples;
  maxCpMismatch=std::max(maxCpMismatch,std::abs(slope-cp));
  table<<p<<','<<T<<','<<liquids.rho(p,T,X)<<','<<h<<','<<E(p,T)<<','<<cp<<','<<liquids.mu(p,T,X)<<','<<liquids.sigma(p,T,X)<<','<<liquids.pv(p,T,X)<<','<<slope<<'\n';
 }
 check(minSlope>0,"nativeMixtureCaloricMonotonicOnPrespecifiedPressureGridIncludingNativeTrMaxHandling");
 std::ofstream cases("thermal_sweep.csv");cases<<std::setprecision(17)<<"p,T1,T2,ratio,relU,np1,np2,EintBefore,KEbefore,KEafter,diss,target,Tnew,roundtripResidual,propertyDomain,boilingExceeded,mu,sigma,rho,Cp\n";
 unsigned acceptedRoots=0,rejectedRoots=0,boilingStates=0,nativeCorrelationCapped=0;double Tmin=Foam::great,Tmax=0,minSpecific=Foam::great,maxSpecific=0,maxRoundtrip=0;
 double velocities[]={0,1e-6,1e-5,1e-4,.001,.01,.1,1,10,50,100,300,1000,2013.039,4026.078};
 for(double p:{188330.307,3e6,12e6})for(double T1:{285.,300.,305.,320.})for(double T2:{285.,300.,305.,320.})for(double ratio:{.01,.1,1.,10.,100.})for(double rel:velocities){
  double a=1e-12,bm=a/ratio,M=a+bm;Foam::vector v1(rel/2,15,0),v2(-rel/2,15,0),com=(a*v1+bm*v2)/M;
  long double internal=(long double)a*E(p,T1)+(long double)bm*E(p,T2);
  long double K0=.5L*a*Foam::magSqr(v1)+.5L*bm*Foam::magSqr(v2),K1=.5L*M*Foam::magSqr(com);
  // Stable exact mechanical dissipation identity; no residual repair variable.
  long double diss=.5L*a*(bm/M)*rel*rel,target=(internal+diss)/M;
  check(diss>=0,"mechanicalMergeNonnegativeDissipation");
  double np1=a/(liquids.rho(p,T1,X)*Foam::constant::mathematical::pi*std::pow(200e-6,3)/6);
  double np2=bm/(liquids.rho(p,T2,X)*Foam::constant::mathematical::pi*std::pow(300e-6,3)/6);
  try{double T=probe.solveT(p,Y,target,(a*T1+bm*T2)/M);++acceptedRoots;
   double rt=E(p,T)-target;maxRoundtrip=std::max(maxRoundtrip,std::abs(rt));Tmin=std::min(Tmin,T);Tmax=std::max(Tmax,T);
   minSpecific=std::min(minSpecific,double(diss/M));maxSpecific=std::max(maxSpecific,double(diss/M));
   bool capped=T>=.999*617.7,boil=liquids.pv(p,T,X)>=.999*p;nativeCorrelationCapped+=capped;boilingStates+=boil;
   check(std::abs(rt)<=o2::budget(E(p,T),target),"independentNativePropertyRoundTrip");
   check(std::abs((long double)M*E(p,T)+K1-internal-K0)<=o2::budget(internal+K0,(long double)M*E(p,T)+K1),"thermalMergeEnergyClosure");
   if(rel==0)check(T>=std::min(T1,T2)-o2::budget(T,std::min(T1,T2))&&T<=std::max(T1,T2)+o2::budget(T,std::max(T1,T2)),"differentTemperatureCaloricMixWithinFrozenArithmeticEndpointBudget");
   cases<<p<<','<<T1<<','<<T2<<','<<ratio<<','<<rel<<','<<np1<<','<<np2<<','<<internal<<','<<K0<<','<<K1<<','<<diss<<','<<target<<','<<T<<','<<rt<<','<<(capped?"NATIVE_CORRELATION_CAP":"UNCAPPED")<<','<<boil<<','<<liquids.mu(p,T,X)<<','<<liquids.sigma(p,T,X)<<','<<liquids.rho(p,T,X)<<','<<liquids.Cp(p,T,X)<<'\n';
  }catch(const std::runtime_error&x){++rejectedRoots;cases<<p<<','<<T1<<','<<T2<<','<<ratio<<','<<rel<<','<<np1<<','<<np2<<','<<internal<<','<<K0<<','<<K1<<','<<diss<<','<<target<<",NaN,NaN,"<<x.what()<<",0,NaN,NaN,NaN,NaN\n";}
 }
 double target=E(3e6,300)+1000;double first=probe.solveT(3e6,Y,target,300);bool deterministic=true;
 auto begin=std::chrono::steady_clock::now();for(unsigned i=0;i<10000;++i){double T=probe.solveT(3e6,Y,target,300);deterministic=deterministic&&T==first;}
 double rootNs=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-begin).count()/10000;
 check(deterministic,"10000RepeatedThermalInversionsBitDeterministic");
 NativeSortedProbe native(initial->stochasticCollision().dict(),*initial);Foam::basicSprayParcel pa(mesh,mesh.C()[0],0),pb(mesh,mesh.C()[0],0);
 initial->setParcelThermoProperties(pa,1e-8);initial->setParcelThermoProperties(pb,1e-8);pa.Y()=pb.Y()=Y;pa.T()=pb.T()=300;pa.rho()=pb.rho()=liquids.rho(3e6,300,X);pa.d()=1e-6;pb.d()=5e-8;pa.nParticle()=1e-12/pa.mass();pb.nParticle()=1.05e-15/pb.mass();pa.U()=Foam::vector(1,0,0);pb.U()=Foam::vector(-1,0,0);pa.sigma()=pb.sigma()=liquids.sigma(3e6,300,X);
 begin=std::chrono::steady_clock::now();for(unsigned i=0;i<10000;++i){auto a=pa,z=pb;double m1=a.nParticle()*a.mass(),m2=z.nParticle()*z.mass();native.collideSorted(1e-8,a,z,m1,m2);}
 double nativeNs=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-begin).count()/10000;
 // Native composition-aware properties using an independent two-liquid dictionary.
 Foam::IStringStream mixStream("C10H22; C7H16;");Foam::dictionary mixDict(mixStream);Foam::liquidMixtureProperties mix(mixDict);
 auto mixE=[&](double T,const Foam::scalarField&yy){auto xx=mix.X(yy);double h=0;forAll(yy,i)h+=yy[i]*mix.properties()[i].h(3e6,T);return h-3e6/mix.rho(3e6,T,xx);};
 Foam::scalarField ya(2,0),yb(2,0);ya[0]=1;yb[1]=1;Foam::scalarField ym((ya+yb)*.5);double mt=.5*(mixE(285,ya)+mixE(320,yb));
 double lo=285,hi=320;for(unsigned i=0;i<100;++i){double mid=(lo+hi)*.5;if(mixE(mid,ym)>mt)hi=mid;else lo=mid;}
 double mixT=(lo+hi)*.5;check(std::abs(mixE(mixT,ym)-mt)<=o2::budget(mixE(mixT,ym),mt),"NativeTwoLiquidCompositionAwareInversion");
 // Pressure-work implication retained as diagnostic; never carrier transfer.
 double rhoOld=liquids.rho(3e6,300,X),rhoNew=liquids.rho(3e6,first,X),pressureWorkPerMass=3e6*(1/rhoNew-1/rhoOld);
 auto committed=std::unique_ptr<t3a::RoleState>(new t3a::RoleState);committed->cloud=std::move(initial);committed->q=q;committed->allocator=Foam::particle::particleCount_;committed->time=time.value();committed->index=time.timeIndex();
 t3a::CarrierTransaction tx(std::move(committed),view,slg,time);const auto committedBefore=m8a3bt3::cloudDump(tx.cloud());
 tx.beginTrial();o2::Audit downstream("downstream");{m8a3a::TrialScope scope;tx.trial().cloud.reset(new o2::Cloud("roleC",*tx.trial().cloud,slg,downstream));}
 auto&c=*tx.trial().cloud;bool nativeBoilingEvent=false;unsigned nativeSearch=0;double nativeEventT=0;
 if(state=="BOILING"){
  for(unsigned attempt=0;attempt<64&&!nativeBoilingEvent;++attempt){c.clear();++nativeSearch;
   for(unsigned j=0;j<2;++j){auto*p=new Foam::basicSprayParcel(mesh,mesh.C()[mesh.nCells()-1],mesh.nCells()-1);c.setParcelThermoProperties(*p,1e-8);p->T()=320;p->Y()=Y;p->rho()=liquids.rho(pBoot,320,X);p->Cp()=liquids.Cp(pBoot,320,X);p->sigma()=liquids.sigma(pBoot,320,X);p->mu()=liquids.mu(pBoot,320,X);p->d()=p->d0()=1e-6;p->mass0()=p->mass();p->position0()=p->position();p->liquidCore()=0;p->KHindex()=1;p->U()=Foam::vector(j?-2013.039/2:2013.039/2,0,0);p->nParticle()=1e-12/p->mass();c.addParticle(p);}
   {m8a3a::TrialScope scope;Foam::basicSprayParcel::trackingData td(c);c.stochasticCollision().update(td,1e-8);}
   for(auto it=c.begin();it!=c.end();++it)if(liquids.pv(pBoot,it().T(),X)>=.999*pBoot){
    auto kept=std::unique_ptr<Foam::basicSprayParcel>(new Foam::basicSprayParcel(it()));nativeEventT=kept->T();nativeBoilingEvent=true;
    std::ofstream f("native_boiling_participant.txt");Foam::OStringStream raw;raw.precision(17);raw<<*kept;f<<raw.str()<<'\n';c.clear();c.addParticle(kept.release());break;
   }
  }
  check(nativeBoilingEvent,"ActualUnmodifiedNativeProbabilityCollisionReachesBoilingStateInO2Policy");
 }
 auto*parcel=state=="BOILING"?nullptr:new Foam::basicSprayParcel(mesh,mesh.C()[mesh.nCells()-1],mesh.nCells()-1);if(parcel)c.setParcelThermoProperties(*parcel,1e-8);
 double downstreamSeedT=state=="BOILING"?probe.solveT(pBoot,Y,E(pBoot,320)+.5*.1/(1.1*1.1)*4026.078*4026.078,320):first;
 if(parcel){parcel->T()=downstreamSeedT;parcel->Y()=Y;parcel->rho()=liquids.rho(pBoot,downstreamSeedT,X);parcel->d()=parcel->d0()=200e-6;parcel->mass0()=parcel->mass();parcel->position0()=parcel->position();parcel->U()=Foam::vector(47,2,0);parcel->liquidCore()=0;parcel->KHindex()=1;parcel->nParticle()=1e-12/parcel->mass();c.addParticle(parcel);}
 double downstreamT=0,downstreamLimit=0;bool downstreamOK=true;try{tx.evolveTrial(1e-8);for(auto it=c.begin();it!=c.end();++it){downstreamT=it().T();downstreamLimit=c.constProps().TMax();downstreamOK=downstreamOK&&std::isfinite(it().T())&&it().T()>0&&std::isfinite(it().d())&&it().d()>0;}}catch(...){downstreamOK=false;}
 check(downstreamOK,"OneOrdinaryNativeDownstreamModelUpdateFinite");tx.discard();check(committedBefore==m8a3bt3::cloudDump(tx.cloud()),"DownstreamPassiveTrialDiscard");
 std::ofstream result("thermal_results.json");result<<std::setprecision(17)<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"slopeSamples\":"<<slopeSamples<<",\"minimumNativeMixtureEnergySlope\":"<<minSlope<<",\"maxDifferenceEnergySlopeVsCp\":"<<maxCpMismatch<<",\"acceptedRoots\":"<<acceptedRoots<<",\"controlledRejections\":"<<rejectedRoots<<",\"boilingStates\":"<<boilingStates<<",\"nativeCorrelationCappedStates\":"<<nativeCorrelationCapped<<",\"Tmin\":"<<Tmin<<",\"Tmax\":"<<Tmax<<",\"minimumDissipationPerMass\":"<<minSpecific<<",\"maximumDissipationPerMass\":"<<maxSpecific<<",\"maxRoundtripSpecificEnergyResidual\":"<<maxRoundtrip<<",\"deterministicRepetitions\":10000,\"rootCostNs\":"<<rootNs<<",\"nativeSortedCostNsIncludingParcelCopies\":"<<nativeNs<<",\"twoLiquidMixT\":"<<mixT<<",\"pressureWorkPerMassExample\":"<<pressureWorkPerMass<<",\"downstreamUpdateFinite\":"<<(downstreamOK?"true":"false")<<",\"activeSolverImpact\":\"NONE\",\"noCFD\":true}\n";
 return failures?1:0;
}
'''
body=body.replace('<<rootNs<<', '<<rootNs<<')
body=body.replace('<<nativeNs<<', '<<nativeNs<<",\\\"downstreamT\\\":"<<downstreamT<<",\\\"downstreamLimit\\\":"<<downstreamLimit<<')
body=body.replace('<<downstreamLimit<<','<<downstreamLimit<<",\\\"nativeBoilingEvent\\\":"<<(nativeBoilingEvent?"true":"false")<<",\\\"nativeEventSearchUpdates\\\":"<<nativeSearch<<",\\\"nativeEventT\\\":"<<nativeEventT<<')
(t/'testFiveEqORourkeThermal.C').write_text((prefix+body).replace('pa.Y()=pb.Y()=Y;','pa.Y()=Y;pb.Y()=Y;'))
print(t)
