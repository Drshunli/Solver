from pathlib import Path
import shutil,struct,json
b=Path(__file__).resolve().parents[1];s=b/'fitting/integration/m6b0_serial_active_v1';root=s/'cases_final';root.mkdir(exist_ok=False)
def header(obj,cls='dictionary'):
 return 'FoamFile\n{version 2.0; format ascii; class '+cls+'; object '+obj+';}\n'
def write(p,t):p.write_text(t,encoding='utf8',newline='\n')
fixtures={'gas':('uniform',0.),'liquid':('uniform',-0.),'mixed01':('uniform',.1),'mixed05':('uniform',.5),'mixed09':('uniform',-.1),'traceLiquid':('uniform',1e-20),'traceGas':('uniform',-1e-20),'contact':('contact',0.),'speciesContact':('speciesContact',0.),'smooth':('smooth',0.)}
mesh=header('blockMeshDict')+'''convertToMeters 1;
vertices ((0 0 0)(20 0 0)(20 1 0)(0 1 0)(0 0 1)(20 0 1)(20 1 1)(0 1 1));
blocks (hex (0 1 2 3 4 5 6 7) (20 1 1) simpleGrading (1 1 1));
edges ();
boundary (
left {type cyclic; neighbourPatch right; transform translational; separationVector (20 0 0); faces ((0 4 7 3));}
right {type cyclic; neighbourPatch left; transform translational; separationVector (-20 0 0); faces ((1 2 6 5));}
transverse {type empty; faces ((0 1 5 4)(3 7 6 2)(0 3 2 1)(4 5 6 7));}
);
mergePatchPairs ();
'''
for name,(profile,coord) in fixtures.items():
 c=root/name;(c/'system').mkdir(parents=True);(c/'constant').mkdir();(c/'0').mkdir()
 steps=20 if name=='smooth' else 10
 write(c/'system/controlDict',header('controlDict')+f'application rhosprayVoFDPMFoam; startFrom startTime; startTime 0; stopAt endTime; endTime {steps*1e-5:.17g}; deltaT 1e-5; writeControl timeStep; writeInterval {steps}; purgeWrite 0; writeFormat binary; writePrecision 17; writeCompression off; timeFormat general; timePrecision 12; runTimeModifiable false;\n')
 write(c/'system/blockMeshDict',mesh)
 write(c/'system/fvSchemes',header('fvSchemes')+'ddtSchemes {default Euler;} gradSchemes {default Gauss linear;} divSchemes {default none;} laplacianSchemes {default Gauss linear corrected;} interpolationSchemes {default linear;} snGradSchemes {default corrected;}\n')
 write(c/'system/fvSolution',header('fvSolution')+'solvers {}\n')
 bits=struct.pack('>d',coord).hex()
 write(c/'constant/fiveEqBootstrap',header('fiveEqBootstrap')+f'verificationOnly true; DPM false; surfaceTension false; K 0; profile {profile}; P2Bits "{bits}"; p 3000000; TG 800; TL 300; U (47 0 0); YG (0 .228 .772);\n')
 shutil.copyfile(b.parent/'300_2D/constant/thermal.dat',c/'constant/thermal.dat')
(s/'fixture_manifest.json').write_text(json.dumps({'fixtures':list(fixtures),'steps':{'smooth':20,'others':10},'source':'M5C.3 common-p/U periodic profiles, no production case','geometry':'20 unit-area slabs, cyclic x, transverse empty'},indent=2))
print('Created',len(fixtures),'verification micro-cases')
