from pathlib import Path
b=Path(__file__).resolve().parents[1]
t=b/'tests/fiveEqTemporalContract'
(t/'Make').mkdir(exist_ok=True)
f=(b/'tests/fiveEqHighOrderPrecisionFinal/Make/files').read_text()
f=f.replace('testFiveEqHighOrderPrecisionFinal','testFiveEqTemporalContract')
(t/'Make/files').write_bytes(f.encode())
(t/'Make/options').write_bytes((b/'tests/fiveEqHighOrderPrecisionFinal/Make/options').read_bytes())
e=b/'fitting/integration/m5c3_v1'
script='''#!/bin/bash
source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqTemporalContract
wmake > /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/log.wmake 2>&1
code=$?
echo "$code" > /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/compile_exit.txt
if [ "$code" != 0 ]; then tail -50 /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/log.wmake; exit "$code"; fi
mkdir -p /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/contract
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/contract
/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqTemporalContract/testFiveEqTemporalContract /mnt/d/DATA/Solver/300_2D/constant/thermal.dat /mnt/d/DATA/Solver/300_2D/constant/reactions > log.run 2>&1
code=$?
echo "$code" > exit_status.txt
cat log.run
exit "$code"
'''
(e/'build_run.sh').write_bytes(script.encode())
print('standalone build/run script prepared')
