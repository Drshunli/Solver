from pathlib import Path
import json,hashlib,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t2_v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
status=b/'MILESTONE_STATUS.md';saved=e/'milestone_before.md'
if saved.exists():raise SystemExit('Refusing to append twice')
old=json.loads((e/'protected_before.json').read_text());changed=[n for n,h in old.items() if not (b/n).exists() or sha(b/n)!=h];assert not changed,changed
case=b.parent/'300_2D';before=json.loads((b/'fitting/dpm/m8a3b_t1_v1/case_before.json').read_text());after={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()};assert before==after
active=json.loads((b/'fitting/dpm/m8a3b_t1_v1/active_before.json').read_text());assert all(sha(b/n)==h for n,h in active.items())
saved.write_bytes(status.read_bytes());entry='''

## M8A.3B-T2 synthetic support feasibility (2026-10-01)

**COMPLETE / STRICT-SUPPORT FEASIBLE**, scoped to serial synthetic Mapping-A
gas-side reference topologies on actual 300_2D. All-gas 21000/21000 valid.
19 complete full-grid scans: four lengths, sharp/TRACE1/2/3, +/-25um L10
alignment sensitivity, baseline. Geometric overlap fractions with P2 authority,
EOS-consistent gas/liquid masses, frozen recovery and native Sutherland
transport property checks; 25 exact unique states cached without sampling.
No 256 cap; 63620 candidate entities and actual native tensor footprints.
Sharp scalar/full counts L1=20664/20608,L2=20552/20488,L5=20160/20068,
L10=19320/19168. Known exclusion 54/62/90/150 cells is localized; every
scenario has one connected certified farfield gas region, no invalid farfield
boundary cells. Trace moves known invalidity inward; outside nontrace known
exclusion becomes zero, interior TRACE cells can still fail U support.
Future-nozzle boundary contributors remain FUTURE_PATCH_DEPENDENT, not fake
carrier values or certified full support. TEST_DPM_INLET is pure liquid and
expected invalid in all core cases, test-only, no production mass ownership.
Native comparison 1725880 checks PASS; frozen energy 9288 and 3A A/B/C6375
PASS (3000 lifecycle), energy/source32 goldens byte equal. Active case/mesh,
solver, frozen source/P2/R1/thermo and historical evidence unchanged.
No CFD, no transaction/MPI continuation, no mesh/BC changes. A later separately
requested M8A.3B passive transaction turn may resume; full transaction and
M8A remain PARTIAL. M6B.0 NO, M6B.1 NO. Exact nozzle patch not active.
See M8A3B_T2_SYNTHETIC_SUPPORT_GATE.md and fitting/dpm/m8a3b_t2_v1.
'''
with status.open('ab') as f:f.write(entry.encode())
proof={'protectedExistingFileChanges':[],'allowedChange':'MILESTONE_STATUS.md append only','milestoneAppendOnly':status.read_bytes().startswith(saved.read_bytes()),'actualCaseAndMeshUnchanged':True,'activeSourceAndMakeUnchanged':True,'noCFD':True}
(e/'protection_verification.json').write_text(json.dumps(proof,indent=2))
out=b/'checkpoints/M8A3B_T2_synthetic_support_v1_COMPLETE.zip'
if out.exists():raise SystemExit('Refusing to overwrite checkpoint')
files=[p for p in e.rglob('*') if p.is_file()]+list(b.glob('tools/m8a3b_t2_*'))+[b/'M8A3B_T2_SYNTHETIC_SUPPORT_GATE.md',status]
files+=[p for p in (b/'tests/fiveEqDPMTopologySupport').rglob('*') if p.is_file() and not any(t.startswith('linux') for t in p.parts)]
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(b).as_posix())
 z.writestr('CHECKPOINT_MANIFEST.json',json.dumps({p.relative_to(b).as_posix():sha(p) for p in files},indent=2))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
(e/'checkpoint.json').write_text(json.dumps({'path':str(out),'sha256':sha(out),'status':'COMPLETE / STRICT-SUPPORT FEASIBLE','bytes':out.stat().st_size},indent=2))
print(json.dumps(proof,indent=2))
