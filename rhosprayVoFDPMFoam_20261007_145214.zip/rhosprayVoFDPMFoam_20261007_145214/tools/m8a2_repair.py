from pathlib import Path
import shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a2_v1';failed=e/'failed_attempt_1';failed.mkdir(exist_ok=True)
for name in ('log.wmake','log.transaction','test_results.json','test_failures.txt','transaction_probes.txt','owner_graph.csv','direct_initial_state.txt','retry_initial_state.txt'):
 if (e/name).exists():shutil.copyfile(e/name,failed/name)
t=b/'tests/fiveEqDPMTransaction';f=t/'fixture_noWrite';f.mkdir(exist_ok=True)
for n in ('0','constant','system'):shutil.copytree(t/'fixture'/n,f/n,dirs_exist_ok=True)
p=e/'build_run.sh';p.write_bytes(p.read_bytes().replace(b'/fixture ',b'/fixture_noWrite '))
script='''#!/bin/bash
source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
base=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam
command -v mpirun
mpirun --version
command -v mpic++
grep -R -n --include='*.C' --include='*.H' 'lookupObject.*Theta' "$FOAM_SRC/lagrangian" "$base" --exclude-dir=fitting --exclude-dir=lnInclude --exclude-dir=Make
'''
(e/'audit_environment.sh').write_bytes(script.encode())
