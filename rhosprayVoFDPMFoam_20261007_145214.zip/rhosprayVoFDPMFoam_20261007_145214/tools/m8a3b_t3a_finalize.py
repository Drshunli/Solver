"""Read-only gate aggregation followed by T3A documentation/checkpoint writes."""
from pathlib import Path
import hashlib,json,csv,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3a_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf8'))
states={s:load(e/'carrier_verified'/s/'test_results.json') for s in 'ABC'}
for s,r in states.items():
 assert r['failures']==0 and r['CV1transverse']
 assert r['acceptedRoleSwaps']>=100 and r['prepareDiscardCycles']>=1000 and r['futureSteps']>=10
 assert (e/'carrier_verified'/s/'test_failures.txt').stat().st_size==0
 assert r['T3FullTransactionSafe'] is False
energy=list((e/'energy_regressions').glob('*/test_results.json'))
rebinding=list((e/'rebinding').glob('*/test_results.json'))
critical=list((e/'D_regressions').glob('*/test_results.json'))
for p in energy+rebinding+critical+[e/'temporal/test_results.json',e/'support_regression/native_comparison.json',e/'support_regression/test_results.json']:
 assert load(p)['failures']==0,p
assert sum(load(p)['checks'] for p in energy)==9288
assert sum(load(p)['checks'] for p in rebinding)==6375
assert sum(load(p).get('checks',0) for p in critical)==105775
assert load(e/'D_regressions/subulp/test_results.json')['steps_per_scheme']==1000
assert load(e/'temporal/test_results.json')['checks']==9663
assert load(e/'support_regression/native_comparison.json')['checks']==1725880
rows=list(csv.DictReader((e/'support_regression/ALL_GAS.csv').open()))
assert len(rows)==21000 and all(int(r['full'])==1 for r in rows)
goldens={}
for p in (e/'energy_regressions').glob('*/golden_energy.csv'):
 old=b/'fitting/dpm/m8a3b_t3_v1/energy_regressions'/p.parent.name/p.name
 assert p.read_bytes()==old.read_bytes()
 goldens[str(p.relative_to(e))]=sha(p)
before=load(e/'protected_before.json');allowed={'tools/m8a3b_t3a_prepare.py','MILESTONE_STATUS.md'}
changes={name:{'before':digest,'after':sha(b/name) if (b/name).exists() else None} for name,digest in before.items() if not (b/name).exists() or sha(b/name)!=digest}
assert {name.replace('\\','/') for name in changes}<=allowed,changes
case=b.parent/'300_2D';actual={str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()}
assert actual==load(e/'case_before.json')
# Native permanent-output isolation: copied carrier fixtures must retain exactly
# their authored 0/constant/system files, including independently enabled probes.
fixture_files={}
for s in 'ABC':
 expected={}
 for folder in ('0','constant','system'):
  root=b/'fitting/dpm/m8a3b_t3_v1/fixtures'/s/folder
  for p in root.rglob('*'):
   if p.is_file():expected[str(Path(folder)/p.relative_to(root))]=sha(p)
 for mode in ('heat','mass','momentum','combined'):
  expected['constant/cvSource'+mode+'Properties']=sha(b/'tests/fiveEqDPMNative/fixtures'/mode/'constant/sprayCloudProperties')
 fixture=e/'fixtures'/s
 observed={str(p.relative_to(fixture)).replace('\\','/'):sha(p) for p in fixture.rglob('*') if p.is_file()}
 expected={k.replace('\\','/'):v for k,v in expected.items()}
 assert observed==expected,(s,set(observed)-set(expected))
 fixture_files[s]=observed
summary={'milestone':'M8A.3B-T3A','status':'COMPLETE / PASSIVE SERIAL TESTED CONTRACT','states':states,
 'totalChecks':sum(r['checks'] for r in states.values()),'failures':0,
 'regressions':{'sourceEnergy':9288,'cloudRebinding':6375,'nativeSupport':1725880,'allGasFull':21000,'criticalPrecisionRecovery':105775,'temporal':9663,'subULPStepsPerScheme':1000},
 'goldensByteIdentical':goldens,'activeSolverImpact':'NONE','actualCaseUnchanged':True,
 'priorProtectedFilesChanged':changes,'nativePermanentOutputsCreated':0,
 'T3':'PARTIAL / FULL TRANSACTION NOT SAFE','T4':'NO','M8A':'PARTIAL','M6B.0':'NO','M6B.1':'NO','noCFD':True}
(e/'gate_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
(e/'fixture_publication_output_audit.json').write_text(json.dumps(fixture_files,indent=2),encoding='utf8')
table='\n'.join(f"| {s} | {r['seedSteps']} / {r['seedParcels']} | {r['checks']} | {r['failures']} | {r['acceptedRoleSwaps']} | {r['prepareDiscardCycles']} | {r['futureSteps']} | {r['carrierGeneration']} |" for s,r in states.items())
counter='\n'.join((e/'carrier_verified/A/CV1_native_source.csv').read_text().splitlines()[:3])
sections=[
('T3A status','**COMPLETE / PASSIVE SERIAL TESTED CONTRACT.** Carrier refresh blocker closed for the represented gas-present native view, fixed topology and explicit test boundaries. This does not activate the solver or close T3.'),
('Original stale-carrier counterexample',f'Original legal tiny dt changes My while reconstructed clouds borrow old U. The native case is reproduced without clipping or forcing any source to zero. Current stable view produces new Uy from accepted M. Exact A evidence:\n\n```csv\n{counter}\n```\n\nThe transverse increment matches the original counterexample. dEt is recomputed from the actual refreshed native thermo/parcel state; it is not forced to a historical bit pattern.'),
('Carrier authority hierarchy','Only P2,mG,mL,M,Et,mYi are authoritative. Carrier rhoG,p,TG,YG,U and derived thermo/transport are staged by frozen common-pressure recovery; no old field participates as an authority.'),
('Carrier reference graph','See [CARRIER_REFERENCE_GRAPH.md](CARRIER_REFERENCE_GRAPH.md): direct volField references, thermo, runtime composition, trackingData copies, point caches, registry turbulence, wall oldTime and all eight selected models. Local Foundation7 source copies are retained for reproducibility.'),
('Stable carrier ownership','Native mesh/thermo/SLGThermo and rho/U outlive both clouds. The Eulerian view layer manages contents and owns diagnostic Cp/kappa only. Role A/B retain stable external references; no role-owned private gas field becomes active later.'),
('Actual field publication mechanism','Actual OF7 mutable element buffers are cached once during construction using primitiveFieldRef/boundaryFieldRef. Prepare validates registered identities, dimensions, patch sizes, storage addresses and buffer counts. Publish performs bounded scalar/vector writes plus native timeIndex/eventNo updates, with no assignment/transfer API assumption.'),
('Interpolation refresh semantics','Actual cellPoint owns const psip_ and uses registry point-cache freshness via event numbers. Publish reserves/sets a new event; next trackingData construction rebuilds native point values. Generation guards reject old trackingData. Cached-native off-centre results agree exactly with a separately constructed native cache=false reference.'),
('Thermo/transport refresh semantics','TG,YG,p,rhoG derive from Q. Native JANAF/perfectGas/Sutherland mixing produces Cp,mu,kappa,he,psi,alphah. Publish native thermo:mu/psi/alpha and p/T/he/Y together. Native Cp() recomputes the current mixture; native kappa()=Cp()*alpha_. No thermo.correct or mass-fraction normalization is used during publication.'),
('Carrier generation mechanism','Committed generation advances exactly once per publication and does not advance on discard. Each role records the expected generation; cloud access and guarded native scalar/vector interpolation reject mismatches or in-progress publication. Diagnostic generation is not a conserved physics variable.'),
('prepareCommit architecture','validateTrial checks generation and unchanged carrier snapshot. prepare recovers every candidate cell and invokes frozen support classification on the same Q; explicit owner-Q boundary buffers are staged locally. prepareCommit validates native field schema/registry/storage, allocates complete publication buffers and reserves a native event. Exact Q/P2 bits are sealed; mutation through a held alias is rejected before the first committed write.'),
('publishCommitNoFail architecture','All throwing precondition/seal checks occur before the publication region. The region excludes observers, copies prepared field buffers, updates metadata, swaps one RoleState pointer containing cloud+Q+logical time/allocator, assigns generation and opens access only after coherence. No EOS, model evolution, registry lookup, allocation, output or callback occurs after the first committed write inside this region. Old role retirement occurs after the coherent state is visible. This is serial logical atomicity, not concurrent/MPI atomicity.'),
('Discard behavior','Trial/staged objects are destroyed; committed carrier values and generation remain exact. Q and active cloud are never mutated by trial publication preparation. Native trial clock is overlaid/restored for evolve. No persistent native output is admitted; full source-event/output transaction semantics remain T3.'),
('CV-1 transverse momentum result','PASS in A/B/C. Native dt=1e-30 produces nonzero My; precommit carrier is unchanged, published Uy equals M_y/(mG+mL), and actual promoted trackingData reads it. The immediately following native tiny step is compared with a direct reconstructed accepted reference: parcels, sources and allocator agree; next-step carrier queries match.'),
('CV-2 mass result','PASS. Actual native single-parcel mass/evaporation probe changes mG consistently with dmYi. Recovery publishes intrinsic rhoG and common U; cloud scalar/vector queries see accepted values. This is a mass-source probe, not a fabricated source that changes only one conserved scalar.'),
('CV-3 thermal result','PASS. Actual native heat probe changes Et and recovered TG. Native T,Cp,mu,kappa query results match independently evaluated accepted gas state (transport relative tolerance 2e-12; direct p/T/rho/U/Y comparisons exact).'),
('CV-4 species result','PASS. Actual native C10H22 mass transfer changes gas composition. Runtime N−1 independent fractions are mYi/mG; residual last is 1−sum(first N−1), without clipping/normalization. Native mixture/Cp/transport observe the new Y.'),
('CV-5 combined result','PASS. Actual combined native event changes mG,Mx,My,Et,mYi, then frozen source adapter/recovery and carrier publication/query checks all pass. No frozen source/energy equation was edited.'),
('Mixed-cell result','PASS at alphaL=0.1,0.5,0.9 with actual native combined sources. P2 and mL remain unchanged for ordinary DPM exchange; U uses total bulk mass and gas properties use intrinsic gas recovery.'),
('Trace-gas result','PASS at alphaG=1e-20. A small positive native parcel multiplicity generates a legal source; frozen P2 authority retains TRACE_PRESENT and native rhoG/thermo/next-query refresh passes. No decoded 1−alphaL subtraction replaces trace storage.'),
('Pure-liquid result','PASS controlled refusal: gas absent cannot manufacture rhoG/TG/YG. Preparing a gas-absent carrier view fails before any committed write. Limitation: this harness bank requires gas-present represented cells; general publication over a production domain containing liquid cores needs an explicit supported/absent-field policy and support-controlled query access before activation.'),
('A→B promotion','PASS. Inactive cloud is reconstructed with native owner-bound models and frozen typed history import. Its references bind the same stable external view. Accepted Q, cloud role and carrier generation publish coherently.'),
('B→A promotion','PASS. The reverse promotion uses the same primitive and checks. No private role carrier copy or role-name field replacement is used.'),
('Repeated role-swap result',f'Each seed completes 129 accepted promotions, including 100 consecutive A/B swaps driven by newly evaluated native momentum probes at the current committed carrier state. Every promotion increments generation and validates actual native queries.\n\n| Seed | Evolved steps / parcels | Checks | Failures | Promotions | Prepare/discard | Future steps | Final generation |\n|---|---|---|---|---|---|---|---|\n{table}'),
('Promoted-cloud carrier query','PASS for rho,p,T,Cp,mu,kappa,U and native runtime Y. Direct cloud references remain stable. Cell-centre U equals accepted M/total mass exactly; off-centre point interpolation agrees with a native cache=false reference. Known boundary values also match staged owner Q.'),
('Next-step interpolation result','PASS. No old trackingData is reused across a publication. Generation assertions reject it even where a scalar interpolation could otherwise borrow a newly updated field; Cp/kappa and point data are reconstructed at next native trackingData creation.'),
('Post-commit future equivalence','PASS: 10 native future steps for each A/B/C accepted state. Repeated role-reconstruction path agrees with a direct reconstructed reference on complete native parcel serialization/traversal, native source buffers, 128-output mixed RNG probe, injector mutable-state key, allocator and carrier queries. Carrier Q is prescribed/held for this comparison; native evolving sources/injection admission are not promoted into a new event-ledger Q. This is future carrier/model equivalence, not the full source/Q/output retry proof reserved for T3.'),
('Support/Q generation consistency','Staging invokes unchanged fiveEqDPMCarrierSupport from the same candidate Q and frozen recovery. Gas support authority remains P2+mG+thermo legality, never cached rho existence. Owner-Q boundary construction has the same support state. The existing exact native-footprint support scan is rerun unchanged; general runtime stencil hooks and future nozzle contributors remain T3/future-patch work.'),
('Registry result','PASS. Each A/B/C performs 1000 prepare/discard cycles with unchanged registered object count and stable rho/U identity. Every prepare checks all managed scalar registrations and U registration/storage/schema. Local staged buffers are unregistered; next native point-cache replacement is outside the no-failure publication region.'),
('Output observer result','PASS in the serial harness: cloud access and interpolation reject in-progress publication; no callback or output observer is invoked in its straight-line publication region. Fixture file trees are hash-equal to their authored 0/constant/system contents; zero native persistent output files were created. Diagnostic CSV/logs are test evidence. Durable accepted-output promotion remains unimplemented.'),
('Frozen regression result','PASS: source/energy9288, A/B/C cloud independence6375, native support1725880, all-gas21000/21000, critical P2/recovery/R1 checks105775, subULP1000 steps/scheme, temporal/restart9663. All eight golden_energy.csv files are byte-identical to T3 evidence. No historical result was overwritten.'),
('Project-local overrides','New test-only interpolation dictionary-factory wrappers delegate unchanged to native OF7 factories and reject stale generations. StableCommittedCarrierView and CarrierTransaction exist only in the new harness directory. Reused frozen modelAdapters/outputIsolation are unchanged. No $FOAM_SRC edits or new active libraries.'),
('Active solver impact','**NONE.** Active solver/source/Make, actual 300_2D mesh/BC/dictionaries, frozen source/energy/P2/R1/EOS/recovery and prior evidence pass SHA-256 protection. Only newly created T3A preparation tooling and the milestone documentation are allowed to differ from the pre-change list. No CFD run.'),
('Remaining blockers','Full T3 native event ledger, closed RNG/model codec, injection admission, KH child/collision/merge/delete retry, strict-support runtime hooks, failure/retry equivalence, conservation ledger and persistent accepted output remain. Production gas-absent view policy, future nozzle BC, fixed-value/dynamic wall semantics and MPI remain outside this tested contract.'),
('Whether T3A COMPLETE','YES for the explicit passive serial fixed-topology carrier-publication contract. The original stale-U blocker is resolved by stable fields and generation-aware next-step interpolation. This is not a production or arbitrary-mesh/BC certification.'),
('Whether T3 may resume','YES in a subsequent separately requested turn, using this tested stable carrier view design. This turn does not resume any T3 event matrix.'),
('Whether T4 may start','**NO.** Resumed T3 must first be COMPLETE.'),
('M8A status','**PARTIAL.** T3A does not close the overall DPM transaction gate.'),
('M6B.0 permission','**NO.** No unified two-phase KT runtime activation.'),
('M6B.1 permission','**NO.** No active two-material flow solve.'),
('Updated milestone matrix','| Milestone | State |\n|---|---|\n| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE |\n| M8A source/energy | PASS / FROZEN |\n| M8A.3A | COMPLETE |\n| M8A.3B-T1 | COMPLETE / DESIGN ONLY |\n| M8A.3B-T2 | COMPLETE / STRICT-SUPPORT FEASIBLE |\n| M8A.3B-T3A | COMPLETE / PASSIVE SERIAL TESTED CONTRACT |\n| M8A.3B-T3 | PARTIAL / carrier-refresh blocker closed; full transaction pending |\n| T4 | NO |\n| M8A overall | PARTIAL |\n| M6B.0 | BLOCKED / NO |\n| M6B.1 | NO |\n\nSTOP. No resumed T3, T4, M6B, CFD or production activation in this turn.')]
report='# M8A.3B-T3A stable carrier publication gate\n\nEvidence: `fitting/dpm/m8a3b_t3a_v1/carrier_verified`. Local Foundation7 wmake PASS; independent native/offline tests only. Earlier carrier/carrier_final attempts are retained.\n\n'
report+='\n\n'.join(f'## {i}. {title}\n\n{body}' for i,(title,body) in enumerate(sections,1))+'\n'
(b/'M8A3B_T3A_CARRIER_PUBLICATION_GATE.md').write_text(report,encoding='utf8')
marker='## M8A.3B-T3A stable carrier publication (2026-10-01)'
status=b/'MILESTONE_STATUS.md';text=status.read_text(encoding='utf8')
if marker not in text:
 text+='\n\n'+marker+'\n\nCOMPLETE / PASSIVE SERIAL TESTED CONTRACT. Stable external carrier fields\npublish accepted Q with cloud/Q role swap; native cellPoint/Cp/kappa tracking\ndata rebuild at next step, generation guards reject stale queries. A/B/C each\n21465 checks, zero failures, 129 accepted swaps, 1000 prepare/discard and\n10 prescribed-carrier native future steps plus immediate CV1 next-step proof.\nCV1 actual tiny transverse source, mass/thermal/species/combined probes, mixed\n0.1/0.5/0.9, trace1e-20 and pure-liquid controlled refusal PASS. Fixed-topology\nowner-Q test boundaries only; production absent-cell/nozzle/wall policy pending.\nFrozen 9288/6375/1725880/105775/9663 and all-gas21000 PASS; energy goldens\nbyte-identical. Active solver/Make, actual case, frozen libraries and historical\nevidence unchanged. No CFD. Original T3 carrier refresh blocker closed; T3\nremains PARTIAL, all full native event/source/Q/output retry gates pending.\nT3 may resume only in a following turn; not resumed here. T4 NO, M8A PARTIAL,\nM6B.0 NO and M6B.1 NO. STOP. See CARRIER_REFERENCE_GRAPH.md and\nM8A3B_T3A_CARRIER_PUBLICATION_GATE.md; evidence m8a3b_t3a_v1.\n'
 status.write_text(text,encoding='utf8')
sources={}
root=b/'tests/fiveEqDPMCarrierPublication'
for p in root.rglob('*'):
 if '/Make/linux' in p.as_posix() or '/lnInclude/' in p.as_posix():continue
 if p.is_file() and (p.suffix in ('.H','.C') or p.parent.name=='Make'):sources[str(p.relative_to(b))]=sha(p)
(e/'tested_source_manifest.json').write_text(json.dumps(sources,indent=2),encoding='utf8')
archive=b/'checkpoints/M8A3B_T3A_carrier_publication_v1_COMPLETE.zip'
assert not archive.exists(),'Never overwrite checkpoints'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for root in (e,b/'tests/fiveEqDPMCarrierPublication'):
  for p in root.rglob('*'):
   if '/Make/linux' in p.as_posix() or '/lnInclude/' in p.as_posix():continue
   if p.is_file() and not p.is_symlink() and p.suffix not in ('.o','.dep'):z.write(p,str(p.relative_to(b)))
 for name in ('M8A3B_T3A_CARRIER_PUBLICATION_GATE.md','CARRIER_REFERENCE_GRAPH.md','MILESTONE_STATUS.md','tools/m8a3b_t3a_prepare.py','tools/m8a3b_t3a_finalize.py'):z.write(b/name,name)
(e/'checkpoint.json').write_text(json.dumps({'path':str(archive),'sha256':sha(archive)},indent=2),encoding='utf8')
print(json.dumps({'status':summary['status'],'checks':summary['totalChecks'],'failures':0,'protectedFiles':len(before),'caseFiles':len(actual),'checkpoint':str(archive)}))
