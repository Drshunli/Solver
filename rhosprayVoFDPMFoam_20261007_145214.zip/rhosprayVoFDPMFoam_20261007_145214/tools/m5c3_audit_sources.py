from pathlib import Path
b=Path(__file__).resolve().parents[1];e=b/'fitting/integration/m5c3_v1'
root='/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7'
paths=[
'src/OpenFOAM/fields/GeometricFields/GeometricField/GeometricField.C',
'src/finiteVolume/finiteVolume/ddtSchemes/EulerDdtScheme/EulerDdtScheme.C',
'src/OpenFOAM/containers/Lists/UList/UListIO.C',
'src/OpenFOAM/db/IOstreams/Sstreams/ISstream.C',
'src/thermophysicalModels/specie/thermo/janaf/janafThermoI.H',
'src/thermophysicalModels/specie/thermo/thermo/HtoEthermo.H',
'src/thermophysicalModels/specie/thermo/sensibleInternalEnergy/sensibleInternalEnergy.H',
'src/combustionModels/laminar/laminar.C',
'src/combustionModels/noCombustion/noCombustion.C',
'src/thermophysicalModels/chemistryModel/chemistryModel/StandardChemistryModel/StandardChemistryModel.C',
'src/lagrangian/intermediate/clouds/Templates/ReactingCloud/ReactingCloudI.H',
'src/lagrangian/intermediate/clouds/Templates/ThermoCloud/ThermoCloudI.H',
'src/lagrangian/intermediate/clouds/Templates/KinematicCloud/KinematicCloudI.H',
'src/lagrangian/intermediate/parcels/Templates/ReactingParcel/ReactingParcel.C',
'src/thermophysicalModels/basic/psiThermo/hePsiThermo.C']
script='#!/bin/bash\nset -e\n'
for i,p in enumerate(paths):
    target=e/'source_audit'/p
    target.parent.mkdir(parents=True,exist_ok=True)
    win='/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/source_audit/'+p
    script+=f'cp {root}/{p} {win}\n'
script+='sha256sum /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayLiquidEOS.so /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayFiveEqThermo.so > /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/library_hashes.txt\n'
(e/'capture_source_audit.sh').write_bytes(script.encode())
