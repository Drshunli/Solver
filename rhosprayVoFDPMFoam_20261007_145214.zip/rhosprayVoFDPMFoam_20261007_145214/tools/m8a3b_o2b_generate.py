from pathlib import Path
b=Path(__file__).resolve().parents[1]
source=(b/'tests/fiveEqORourkeThermal/testFiveEqORourkeThermal.C').read_text()
prefix=source.split(' auto initial=')[0].replace('state=="BOILING"?188330.307:3e6','state=="BOILING"?188330.307:(state=="HIGH"?12e6:3e6)').replace('#include <fstream>','#include <fstream>\n#include <sstream>\n#include <limits>')
body=r'''
 auto initial=std::unique_ptr<m8a3a::Cloud>(new m8a3a::Cloud("roleA",rho,U,gravity,slg,false));
 o2::Audit audit("property_probe");o2::Policy probe(initial->stochasticCollision().dict(),*initial,audit);
 Foam::scalarField Y(1,1);auto& liquids=initial->composition().liquids();auto X=liquids.X(Y);
 auto E=[&](double p,double T){return probe.specificE(p,T,Y);};
 auto ceiling=[&](double p){double lo=243.51,hi=.999*617.7;
  for(unsigned i=0;i<100;++i){double mid=lo+(hi-lo)*.5;if(liquids.pv(p,mid,X)<.999*p)lo=mid;else hi=mid;}
  return std::nextafter(lo,243.51);};
 std::ofstream bounds("native_limits.csv");bounds<<std::setprecision(17)<<"p,Tupper,pv,TnativeInvert\n";
 for(double p:{188330.307,3e6,12e6})bounds<<p<<','<<ceiling(p)<<','<<liquids.pv(p,ceiling(p),X)<<','<<liquids.pvInvert(p,X)<<'\n';
 auto committed=std::unique_ptr<t3a::RoleState>(new t3a::RoleState);committed->cloud=std::move(initial);committed->q=q;committed->allocator=Foam::particle::particleCount_;committed->time=time.value();committed->index=time.timeIndex();
 t3a::CarrierTransaction tx(std::move(committed),view,slg,time);const auto beforeCloud=m8a3bt3::cloudDump(tx.cloud());
 std::ifstream input(argv[4]);std::string line;std::getline(input,line);
 std::ofstream out("candidate_events.csv");out<<std::setprecision(17)<<"event,policy,p,M,EintBefore,Kbefore,Kafter,Ediss,Qheat,reservoir,carrierHypothetical,Tmix,Tpost,Tupper,Eresidual,Mresidual,Yresidual,Px,Py,Pz,downstreamT,downstreamTMax,finiteAPI,phaseAdmissible,IDs,physicalApproved\n";
 while(std::getline(input,line)){std::vector<std::string>v;std::stringstream ss(line);std::string word;while(std::getline(ss,word,','))v.push_back(word);if(v.size()!=21)return 3;
  double p=std::stod(v[1]);if(p!=pBoot)continue;
  double a=std::stod(v[2]),z=std::stod(v[3]),M=a+z,T1=std::stod(v[4]),T2=std::stod(v[5]);
  long double K0=std::stold(v[6]),K1=std::stold(v[7]),Ei=(long double)a*E(p,T1)+(long double)z*E(p,T2),diss=K0-K1;
  bool merge=std::stoi(v[9]);Foam::vector u(std::stod(v[10]),std::stod(v[11]),std::stod(v[12])),w(std::stod(v[13]),std::stod(v[14]),std::stod(v[15]));
  double mix=probe.solveT(p,Y,Ei/M,(a*T1+z*T2)/M),upper=ceiling(p);check(diss>=0,"nonnegativeFixedSampleDissipation");
  for(char policy:std::string("ABCDE")){long double heat=0,R=0,carrier=0,Kpost=K1;double T=mix;
   if(policy=='A'){long double capacity=std::max(0.L,(long double)M*E(p,upper)-Ei);heat=std::min(diss,capacity);R=diss-heat;}
   if(policy=='B')R=diss;
   if(policy=='C')heat=diss; // Existing grazing is already the failing branch; no new elastic law or resampling.
   if(policy=='D')carrier=diss; // Hypothetical algebra only: not a carrier adapter/source.
   if(policy=='E')Kpost=K0; // Scope exclusion retains the whole pre-event state; owner approval absent.
   if(policy!='E')T=probe.solveT(p,Y,(Ei+heat)/M,mix);else T=T1;
   long double Epost=policy=='E'?Ei:(long double)M*E(p,T);long double er=Epost+Kpost+R+carrier-Ei-K0;
   check(std::abs(er)<=o2::budget(Ei+K0,Epost+Kpost+R+carrier),"extendedInventoryArithmeticClosure");
   // A temperature is obtained by solving allocated energy, never clipping a hot root.
   tx.beginTrial();auto&c=*tx.trial().cloud;c.clear();bool finite=true;double afterT=0,nativeMax=0;
   unsigned count=policy=='E'?2:(merge?1:2);
   for(unsigned j=0;j<count;++j){auto* parcel=new Foam::basicSprayParcel(mesh,mesh.C()[mesh.nCells()-1],mesh.nCells()-1);c.setParcelThermoProperties(*parcel,1e-8);
    double tp=policy=='E'?(j?T2:T1):T;parcel->Y()=Y;parcel->T()=tp;parcel->rho()=liquids.rho(p,tp,X);parcel->Cp()=liquids.Cp(p,tp,X);parcel->sigma()=liquids.sigma(p,tp,X);parcel->mu()=liquids.mu(p,tp,X);
    parcel->d()=parcel->d0()=1e-6;parcel->mass0()=parcel->mass();parcel->position0()=parcel->position();parcel->liquidCore()=0;parcel->KHindex()=1;
    parcel->U()=Foam::vector(47,0,0);parcel->nParticle()=(count==1?M:(j?z:a))/parcel->mass();c.addParticle(parcel);
   }
   // Isolated ordinary API compatibility probe, not exact post-event full-state replay. E uses one retained participant to avoid performing the excluded event.
   if(policy=='E'&&c.size()>1){auto it=c.begin();++it;auto*deleteMe=&it();c.deleteParticle(*deleteMe);}
   try{tx.evolveTrial(1e-8);for(auto it=c.begin();it!=c.end();++it){afterT=it().T();nativeMax=c.constProps().TMax();finite=finite&&std::isfinite(afterT)&&std::isfinite(it().rho())&&it().rho()>0&&it().d()>0;}}catch(...){finite=false;}
   check(finite,"isolatedNativeDownstreamAPIFinite");tx.discard();check(beforeCloud==m8a3bt3::cloudDump(tx.cloud()),"probeDiscardKeepsCommittedGraph");
   bool phase=T>=243.51&&T<.999*617.7&&liquids.pv(p,T,X)<.999*p&&afterT<=nativeMax+o2::budget(afterT,nativeMax);
   Foam::vector P=policy=='E'?Foam::vector(std::stod(v[18]),std::stod(v[19]),std::stod(v[20])):(merge?M*u:a*u+z*w);
   out<<v[0]<<','<<policy<<','<<p<<','<<M<<','<<Ei<<','<<K0<<','<<Kpost<<','<<diss<<','<<heat<<','<<R<<','<<carrier<<','<<mix<<','<<T<<','<<upper<<','<<er<<",0,0,"<<P.x()<<','<<P.y()<<','<<P.z()<<','<<afterT<<','<<nativeMax<<','<<finite<<','<<phase<<','<<(policy=='E'?"both_pre":(merge?"native_recipient":"both"))<<",0\n";
  }
 }
 std::ifstream sweep("../O2A_reference_sweep.csv");std::getline(sweep,line);std::ofstream scan("candidate_sweep.csv");scan<<std::setprecision(17)<<"p,T1,T2,ratio,relU,EdissPerMass,Tupper,Tmix,TA,TB,QAperMass,RAperMass,RBperMass,Aphase,Bphase\n";
 while(std::getline(sweep,line)){std::vector<std::string>v;std::stringstream ss(line);std::string word;while(std::getline(ss,word,','))v.push_back(word);double p=std::stod(v[0]);if(p!=pBoot)continue;
  double t1=std::stod(v[1]),t2=std::stod(v[2]),ratio=std::stod(v[3]),rel=std::stod(v[4]);long double a=1e-12,z=a/ratio,M=a+z,Ei=a*E(p,t1)+z*E(p,t2),diss=.5L*a*z/M*rel*rel;
  double upper=ceiling(p),mix=probe.solveT(p,Y,Ei/M,(a*t1+z*t2)/M);long double cap=std::max(0.L,M*E(p,upper)-Ei),heat=std::min(diss,cap);double ta=probe.solveT(p,Y,(Ei+heat)/M,mix);
  bool ap=ta>=243.51&&ta<.999*617.7&&liquids.pv(p,ta,X)<.999*p,bp=mix>=243.51&&mix<.999*617.7&&liquids.pv(p,mix,X)<.999*p;
  check(std::abs(M*E(p,ta)+(diss-heat)-Ei-diss)<=o2::budget(Ei+diss,M*E(p,ta)+diss-heat),"sweepExtendedInventoryClosure");
  scan<<p<<','<<t1<<','<<t2<<','<<ratio<<','<<rel<<','<<diss/M<<','<<upper<<','<<mix<<','<<ta<<','<<mix<<','<<heat/M<<','<<(diss-heat)/M<<','<<diss/M<<','<<ap<<','<<bp<<'\n';
 }
 std::ofstream result("test_results.json");result<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"physicalApproval\":false,\"prototypeOnly\":true,\"fullCandidateStateCodec\":false}\n";
 return failures?1:0;
}
'''
(b/'tests/fiveEqORourkeEnergyDecision/testFiveEqORourkeEnergyDecision.C').write_bytes((prefix+body).encode())
print('Generated standalone candidate assessment; no runtime registration.')
