from pathlib import Path
import json,csv,math,hashlib,statistics,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a_v1'
cases={};rows=[];perf={'conversionNs':[],'trialRecoveryNs':[]}
for mode in ('zero','heat','momentum','mass','evaporation','combined','disappearance','permuted'):
 cases[mode]=json.loads((e/mode/'test_results.json').read_text())
 rows+=list(csv.DictReader((e/mode/'ledger.csv').open()))
 for r in csv.DictReader((e/mode/'performance.csv').open()):
  for k in perf:perf[k].append(float(r[k]))
stats={}
for k,v in perf.items():
 v.sort();stats[k]={'samples':len(v),'mean':statistics.mean(v),'P95':v[math.ceil(.95*len(v))-1],'P99':v[math.ceil(.99*len(v))-1],'max':max(v)}
def maximum(k):return max(abs(float(r[k])) for r in rows)
tot=sum(v['checks'] for v in cases.values());fail=sum(v['failures'] for v in cases.values())
gateNames=['real OF7 parcel source path audited','source dimensions/signs frozen','mass -> mG mapping proven','species -> mYi mapping proven','sum species source = mG source PASS','momentum ledger proven','parcel kinetic-energy accounting closed','heat-transfer energy ledger closed','evaporation energy ledger closed','gas JANAF energy-reference compatibility proven','no C_L misuse','parcel disappearance ledger PASS','pure-gas legacy DPM regression PASS','mixed-cell source recovery PASS','trace-gas source test PASS','exact pure-liquid/gas-absent DPM policy frozen','source applicability mask frozen and viable','source-stage thermo validation PASS','rollback/transaction contract frozen and real-cloud mapping proven','real OF7 source API harness PASS','chemistry source family kept separate','DPM+chemistry energy-reference compatibility test PASS','conservation matrix PASS','no clipping / silent repair','no CoolProp runtime dependency','standalone compile PASS','active solver physics unchanged','no CFD run']
gates=[{'number':i+1,'gate':n,'status':'PARTIAL' if i+1 in (17,19) else 'PASS','scope':'standalone held-pressure single-fuel explicit-source model; chemistry test is reference algebra only'} for i,n in enumerate(gateNames)]
summary={'status':'PARTIAL','nativeCases':cases,'checks':tot,'failures':fail,'maxAbsLedgerDefects':{k:maximum(k) for k in ('massDefect','momentumDefect','energyDefect')},'performance_ns':stats,'gates':gates,'hardBlockers':['actual injector/path/interpolation applicability guard before native carrier lookup, including gas-absent trajectory entry','complete current-production-cloud transactional rollback, metadata/output/occupancy and source-correction ownership'],'activeSolverImpact':'NONE','CFD_run':False,'M6B0_permission':'NO','M6B1_permission':'NO'}
(e/'summary.json').write_bytes(json.dumps(summary,indent=2).encode())
matrix='| Gate | Status |\n|---|---|\n'+''.join(f"| {g['number']}. {g['gate']} | {g['status']} |\n" for g in gates)
nativeTable='| Native fixture | Checks | Failures |\n|---|---:|---:|\n'+''.join(f"| {k} | {v['checks']} | {v['failures']} |\n" for k,v in cases.items())
perfTable='| API | N | Mean ns | P95 ns | P99 ns | Max ns |\n|---|---:|---:|---:|---:|---:|\n'+''.join(f"| {k} | {s['samples']} | {s['mean']:.1f} | {s['P95']:.1f} | {s['P99']:.1f} | {s['max']:.1f} |\n" for k,s in stats.items())
sections=[
('M8A status','**PARTIAL.** Standalone conservative adapter and real OF7 API harness pass. Two production viability gates remain incomplete. This report does not grant M6B activation.'),
('OF7 cloud/source audit','Actual Foundation7 sources copied and inspected. See docs/OF7_DPM_SOURCE_AUDIT.md; basicSprayCloud/basicSprayParcel layers, phase/heat/velocity/deletion and matrix paths audited.'),
('Native mass-source semantics','rhoTrans is cell/time-step integrated mass kg, with nParticle. Srho() divides dt*V; explicit matrix Srho(rho) stores -transfer/dt.'),
('Native species-source semantics','Actual localToCarrierId mapping; each runtime rhoTrans[i] maps to gas mYi. Actual reordered N2/C10H22/O2 fixture passes.'),
('Native momentum-source semantics','UTrans is integrated coupled impulse plus mass-carried momentum. ReactingParcel U0 aliases new U; candidate exposes endpoint correction rather than double-counting mass momentum.'),
('Native energy-source semantics','hsTrans is sensible enthalpy, not Et. Frozen-Cp heat integration, mass gas Hs and deletion branch require explicit reference/caloric/kinetic/pV conversion.'),
('Units/sign conventions','Adapter outputs kg, kg m/s, J and kg per event. Divide by coherent event V only. Real Srho/SYi/SU/Sh dimensions and explicit RHS signs tested.'),
('fiveEq source adapter API','dpmFiveEq/fiveEqDPMSourceAdapter.H: gasCarrier(), convert(), trial(). TrialSource: beginTrial(), accumulateSources() with validation, commit(), discard(). Native extraction and source snapshot use actual APIs.'),
('Mass mapping','mG*=mG+dmG/V; Eulerian mL and signed P2 unchanged. No DPM liquid volume is inserted into alphaL.'),
('Species mapping','mYi*=mYi+dmYi/V in actual runtime order. Frozen Q supports precisely three species; extension is explicit future work.'),
('Species-source closure',f'All source/species and endpoint mass checks pass. Max extensive mass difference {maximum("massDefect"):.8g} kg, within frozen endpoint roundoff budget.'),
('Momentum ledger','dM=Pparcel_before-Pparcel_after+externalImpulse. Combined mass+drag alias defect is exposed as momentumCorrection. Common-velocity M update affects both material velocities through the model constraint; no post-accumulation alpha weighting.'),
('Kinetic-energy ledger','dK=Kparcel_before-Kparcel_after+externalWork. Et and M updated coherently; no extra Ugas dot impulse source added afterward.'),
('Heat-transfer ledger','Actual RanzMarshall tested. Nonlinear raw liquid h and H-pV endpoints are exactified explicitly relative to native frozen-mCp integration. Temperature clipping causes rejection.'),
('Evaporation ledger','Actual liquidEvaporation with enthalpyDifference tested. dEt=HB-HA-chi+KB-KA+p(VA-VB)+Qext+Wext. All unit external terms are zero. The heat-none mass fixture is diagnostic, not production latent-cooling approval.'),
('JANAF energy-reference compatibility','Actual Hs=Ha-Hc and Es=Ha-Hc-p/rho inspected. chi=sum(Hc_i dmYi) is subtracted ONCE. Gas energy remains original sensibleInternalEnergy.'),
('Eulerian-liquid C_L status','Frozen 369229.9537234281 J/kg remains solely Eulerian Gibbs EOS coordinate offset. No C_L is added to DPM->gas source and no frozen EOS file is changed.'),
('DPM caloric-reference status','Use real CompositionModel::H raw liquid h; liquid Hs=h(p,T)-h(p,298.15), Hc=h(p,298.15). Full native-reference comparison is in golden_energy.csv; no invented enthalpy offset.'),
('Pure-gas legacy regression','Real source matrices and equivalent mass/species updates agree. Zero-source bit identity passes. Momentum/energy differences are explicit conservative upgrades (alias, caloric, KE and pV), not claimed equality to legacy full CFD.'),
('Mixed-cell source result','alphaL=.1/.5/.9 source trials recover; mL and P2 untouched. This is local source admissibility, not a CFD coexistence validation.'),
('Trace-gas result','alphaG=1e-20 intrinsic gas carrier and gas-volume-scaled event pass. Signed P2 remains exact. Finite arbitrary source into vanishing gas is not certified; source/Et resolution can require rejection.'),
('Pure-liquid/gas-absent analysis','gasCarrier rejects before tracking even with zero source. Nonzero trial also rejects exact pure liquid. No alphaG=tiny or gas-volume creation source.'),
('DPM applicability contract','Domain A frozen: DPM only in already present/trace gas. Injection and every trajectory/interpolation/source segment must check mask. Production path guard not yet implemented/verified: PRE-M6B HARD BLOCKER.'),
('Parcel disappearance result','Real minParcelMass deletion branch and full single-C10H22 mass/energy ledger pass. Multi-component depletion/deletion is not covered.'),
('Trial-source/recovery result','Full coherent Q recovery after increment; invalid-energy trial rejected, no partial commit; paired mock commit/discard tested. Recovery tolerances unchanged.'),
('Rollback/transaction design','Real cloud clone restores parcel but not transfer arrays. Explicit reset gives identical replay; separate nonzero rhoTrans/UTrans/UCoeff/hsTrans/hsCoeff snapshot restore passes. Production injector/functions/IDs/output/occupancy/time/mesh rollback is NOT proven: PRE-M6B HARD BLOCKER.'),
('Real OF7 source API harness result',nativeTable+f'\n{tot} checks, {fail} failures. Two actual parcels with unequal multiplicities, real source matrices, clone/restore and source snapshots included. Direct native parcel calc, not a CFD run.'),
('DPM/chemistry source separation','Vapor dmYi and Et reference conversion are separate from chemical RR_i/Qdot. M8A does not integrate/rewrite chemistry.'),
('DPM/chemistry energy-reference test','Actual Hc-based hypothetical mass-conserving algebra verifies Qdot=-sum(Hc_i RR_i) cancels chemical-reference change. Current three-species case lacks products/active reactions; synthetic RR direction is NOT a physical reaction test. Reaction-enabled adapter remains a distinct future gate.'),
('Conservation matrix',f'Zero, heat, drag, mass, evaporation, combined, disappearance, real multiple-parcel, pure-gas, trace, mixed, ALE and rejected trial checks pass in supported standalone scope. Max extensive momentum defect {maximum("momentumDefect"):.8g} kg m/s; max energy defect {maximum("energyDefect"):.8g} J. Frozen tolerances in FROZEN_TOLERANCES.json.'),
('ALE/source result','Event-volume normalization tested at V=.7; source increment never depends on meshPhi or a second dt. ALE flux/temporal frozen regressions rerun separately.'),
('Golden energy-reference cases','Native property values at p=3MPa and TL285/300/305/320 K retained. These are actual OF7 property outputs, not experimental measurements or new reference-EOS grids.'),
('Performance',perfTable+'\nNearest-rank percentiles, warmed repeated conversions; separate per-event source conversion and source-trial recovery. Not full cloud/CFD timing.'),
('Added files','dpmFiveEq/*.H; tests/fiveEqDPMNative source/Make/manufactured fixtures; four docs; tools/m8a_*.py; fitting/dpm/m8a_v1 immutable evidence. Only ENERGY_REFERENCE_AUDIT.md and MILESTONE_STATUS.md are authorized existing document updates.'),
('Compile status','Foundation7 wmake PASS for isolated native harness. No system library rebuild or active solver change; frozen library hashes unchanged. Frozen temporal test 9663/0; D regressions recorded under M8A evidence.'),
('Active solver impact','**NONE.** Hash audit of all protected old sources/case/EOS/contracts: only the two authorized document updates may differ. No runtime include/field/equation/source activation.'),
('Remaining blockers','1. Actual production injection/path/interpolation gas applicability guard and coherent cellValueSourceCorrection ownership. 2. Full current production cloud rollback/preview isolation beyond the minimal unit cloud, including mutable metadata and side effects. Varying-pressure/radiation/multi-fuel cases lie outside candidate contract.'),
('Whether M8A is COMPLETE','**NO.** All 28 gates must pass; applicability and complete real-cloud transaction viability remain PARTIAL.\n\n'+matrix),
('M6B.0 start permission','**NO.** Close M8A blockers first. M6B.0 is not executed here.'),
('M6B.1 permission','**NO.** No atomic equation switch.'),
('Updated milestone matrix','| Stage | Status |\n|---|---|\n| M0-M4 | COMPLETE; diagnostics only where previously stated |\n| M5A/M5B | COMPLETE / reference/design |\n| M6A1a / accepted EOS / M6A2 | Existing COMPLETE / passive scopes unchanged |\n| M5C.1/M5C.2/M5C.3 | COMPLETE / standalone / not active |\n| M8A | PARTIAL / standalone source tests PASS; two hard blockers |\n| M6B.0 | NOT STARTED / blocked |\n| M6B.1 | NOT STARTED / NO |\n| VOF-DPM conversion, CFD | NOT EXECUTED |\n\nSTOP. No M6B.0/M6B.1 or CFD performed.')]
report='# M8A conservative DPM source and energy ledger gate\n\n'+''.join(f'# {i}. {title}\n\n{text}\n\n' for i,(title,text) in enumerate(sections,1))
(b/'M8A_DPM_SOURCE_ENERGY_GATE.md').write_bytes(report.encode())
energy=b/'ENERGY_REFERENCE_AUDIT.md';marker='## M8A conservative DPM source gate (2026-10-01)'
if marker not in energy.read_text():energy.write_bytes((energy.read_text()+f'\n\n{marker}\n\nStandalone candidate uses actual raw OF7 parcel h and JANAF Hc. dEt=HB-HA-sum(Hc_i dmYi)+KB-KA+p*(VA-VB) at held p, plus explicitly modeled external heat/work (zero in unit tests). Pressure work is internal, never an invented external residual. Native hsTrans, frozen-Cp, KE omission, U0 alias and deletion approximations are separated by explicit corrections. Eulerian C_L is not used for vapor sources. See docs/DPM_EULERIAN_ENERGY_REFERENCE_LEDGER.md and M8A_DPM_SOURCE_ENERGY_GATE.md. M8A remains PARTIAL due to real production carrier-path guard and complete cloud transaction blockers. No active source/chemistry change.\n').encode())
status=b/'MILESTONE_STATUS.md';s=status.read_text();s=s.replace('| M8A | **ELIGIBLE FOR NEXT USER REQUEST / NOT STARTED** | M5C.3 standalone complete; conservative gas-carried parcel mass/momentum/Et/species and rollback/reference adapter is mandatory before M6B. |','| M8A | **PARTIAL / STANDALONE SOURCE TESTS PASS / NOT ACTIVE** | Actual OF7 API and conservative source ledger pass; production carrier-path applicability and full cloud transaction remain hard blockers. See M8A_DPM_SOURCE_ENERGY_GATE.md. |');s+='\n\n## M8A current gate (2026-10-01; supersedes historical unexecuted wording)\n\nM5C.3 stays COMPLETE/standalone. M8A PARTIAL: real parcel/cloud source APIs, source dimensions, endpoint mass/momentum/internal-total-energy conversion, trace/mixed/gas-absent rejection and minimal cloud/source snapshot tests pass. Production trajectory/interpolation carrier guard and full cloud side-effect rollback are not proven. M6B.0 and M6B.1 remain NOT STARTED / blocked. Active solver and cases unchanged; no CFD.\n';status.write_bytes(s.encode())
currentMarker='## M8A current gate (2026-10-01; supersedes historical unexecuted wording)'
parts=status.read_text(encoding='utf-8').split(currentMarker)
if len(parts)>2:status.write_bytes((parts[0]+currentMarker+parts[1]).encode())
before=json.loads((e/'protected_before.json').read_text());changed=[];missing=[]
for name,h in before.items():
 p=(b.parent if Path(name).parts[0]=='300_2D' else b)/name
 if not p.exists():missing.append(name)
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=h:changed.append(name)
audit={'protected_count':len(before),'changed':changed,'missing':missing,'allowed':['ENERGY_REFERENCE_AUDIT.md','MILESTONE_STATUS.md'],'activeSolverImpact':'NONE' if not missing and set(changed)<=set(['ENERGY_REFERENCE_AUDIT.md','MILESTONE_STATUS.md']) else 'AUDIT_FAILED'}
(e/'protected_after_audit.json').write_bytes(json.dumps(audit,indent=2).encode())
if audit['activeSolverImpact']!='NONE':raise RuntimeError(audit)
catalog={str(p.relative_to(e/'source_audit')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (e/'source_audit').rglob('*') if p.is_file()};(e/'source_provenance_hashes.json').write_bytes(json.dumps(catalog,indent=2).encode())
print(json.dumps({'checks':tot,'failures':fail,'stats':stats,'protected':audit},indent=2))
