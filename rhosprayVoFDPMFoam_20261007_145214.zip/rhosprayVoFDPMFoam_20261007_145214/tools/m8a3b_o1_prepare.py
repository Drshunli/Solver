from pathlib import Path
import json,hashlib,shutil,re
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o1_v1';old=b/'fitting/dpm/m8a3b_t3b_v1'
if e.exists():raise RuntimeError('Do not overwrite evidence')
e.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_text(json.dumps({str(p.relative_to(b)):sha(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_o1_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()},indent=2))
shutil.copyfile(old/'case_before.json',e/'case_before.json')
t=b/'tests/fiveEqORourkePopulation';(t/'Make').mkdir(parents=True,exist_ok=True)
(t/'Make/files').write_bytes((b/'tests/fiveEqDPMEventLedger/Make/files').read_bytes().replace(b'testFiveEqDPMEventLedger',b'testFiveEqORourkePopulation'))
shutil.copyfile(b/'tests/fiveEqDPMEventLedger/Make/options',t/'Make/options')
for s in 'ABC':
 shutil.copytree(old/'fixtures'/s,e/'fixtures'/s)
 shutil.copytree(old/'rebinding_fixtures'/s,e/'rebinding_fixtures'/s)
 shutil.copytree(old/'fixtures'/s,e/'branch_fixtures'/s)
 p=e/'branch_fixtures'/s/'constant/polyMesh/points'
 text=p.read_text();pat=r'\((\d+) ([01]) ([01])\)'
 def point(m):
  x,y,z=map(int,m.groups())
  if x<7:return m[0]
  return f'({7+(x-7)*1e-7:.17g} {0.5+(y-.5)*1e-7:.17g} {0.5+(z-.5)*1e-7:.17g})'
 p.write_text(re.sub(pat,point,text))
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
for name in ('run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','run_rebinding.sh','run_support.sh','run_carrier_verified.sh','read_sources.sh'):
 (e/name).write_bytes((old/name).read_bytes().replace(b'm8a3b_t3b_v1',b'm8a3b_o1_v1'))
(e/'read_sources.sh').write_bytes((e/'read_sources.sh').read_bytes().replace(b'Random.H RandomI.H',b'SprayCloud.C KinematicParcel.H KinematicParcelI.H Random.H RandomI.H'))
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqORourkePopulation"\nwmake > "$base/fitting/dpm/m8a3b_o1_v1/log.wmake" 2>&1\n').encode())
(e/'run_o1.sh').write_bytes((head+'for mode in production branch; do\nfor state in A B C; do\n mkdir -p "$base/fitting/dpm/m8a3b_o1_v1/results/$mode/$state"\n cd "$base/fitting/dpm/m8a3b_o1_v1/results/$mode/$state"\n fixture=fixtures\n if [ "$mode" = branch ]; then fixture=branch_fixtures; fi\n /usr/bin/time -v "$base/tests/fiveEqORourkePopulation/testFiveEqORourkePopulation" "$base/fitting/dpm/m8a3b_o1_v1/$fixture/$state" "$state" /mnt/d/DATA/Solver/300_2D/constant/thermal.dat "$mode" > log.run 2> log.resource\ndone\ndone\n').encode())
(e/'design.json').write_text(json.dumps({'scope':'BRANCH-REACHABILITY TEST ONLY','branchMesh':'last cell is 100 nm cube; no frequency inference','collisionCoefficients':'unchanged production ORourke coalescence yes','seedMassKg':[5e-15,1.05e-15],'seedDiameterM':[1e-6,5e-7],'seedTLK':300,'dtBranch':1e-10},indent=2))
print(e)
