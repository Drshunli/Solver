"""Read-only native PW1 evidence qualification; never adjust particle state."""
from pathlib import Path
import csv,json,math,hashlib,struct,difflib
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/dpm/m8a3b_t4_s2_pw1_native_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(csv.reader(p.open())) if p.exists() else []
def allrows(c,name):return [r for p in c.glob('processor*/'+name) for r in rows(p)]
checks={}
def check(name,value):checks[name]=bool(value)
ladder={};target=5.262723452e-8
for n in [1,10,100,1000]:
 c=s/f'control_final_{n}';birth=allrows(c,'PW1_births.csv');mass=math.fsum(float(r[7]) for r in birth);err=(mass-target)/target
 check(f'N{n}_exit',int((s/f'exit.control_final_{n}').read_text())==0)
 check(f'N{n}_count',len(birth)==n)
 check(f'N{n}_native_mass',abs(err)<=1e-12)
 check(f'N{n}_positive',all(all(math.isfinite(float(r[i])) and float(r[i])>0 for i in [4,5,6,7]) for r in birth))
 check(f'N{n}_identity',len({tuple(r[2:4]) for r in birth})==n)
 check(f'N{n}_finite_native_state',all(json.loads(p.read_text())['globalFailures']==0 for p in c.glob('processor*/native_crossing_result.json')))
 step=rows(c/'processor0/PW1_steps.csv')[0];initialMomentum=mass*float(birth[0][9])
 check(f'N{n}_source_spot',float(step[9])>0 and float(step[10])/initialMomentum<1e-12)
 check(f'N{n}_native_trajectory_theta',all(r[1]=='1' for r in allrows(c,'PW1_void.csv')) and sum(int(r[2]) for r in allrows(c,'PW1_void.csv'))>0)
 ladder[n]={'requested':int(step[3]),'actualAdded':len(birth),'targetMass':target,'representedMass':mass,'relativeMassError':err,'mean_nParticle':math.fsum(float(r[4]) for r in birth)/n,'sourceMomentumMagnitude':float(step[9]),'sourceResidual':float(step[10]),'sourceResidualNormalizedByInitialMomentum':float(step[10])/initialMomentum,'nativeVoidPostMoves':sum(int(r[2]) for r in allrows(c,'PW1_void.csv')),'wallSeconds':float((s/f'wall.control_final_{n}').read_text())}
check('physical_mass_invariant',len({v['targetMass'] for v in ladder.values()})==1)
check('multiplicity_inverse_scaling',all(abs(ladder[n]['mean_nParticle']*n/ladder[1]['mean_nParticle']-1)<1e-12 for n in ladder))
c=s/'candidate_final';birth=allrows(c,'PW1_births.csv');boundary=allrows(c,'R1_boundary.csv');groups={}
for r in boundary:groups.setdefault(tuple(r[3:5]),{})[r[1]]=r
check('candidate_native_crossings_10',len(groups)>=10)
check('candidate_complete_stream_stages',all(len(g)==4 for g in groups.values()))
check('candidate_physical_state_bit_parity',all(g['SEND_AFTER_PREPARE'][21:52]==g['RECEIVE_BEFORE_CORRECT'][21:52] and g['SEND_BEFORE_PREPARE'][21:52]==g['RECEIVE_AFTER_CORRECT'][21:52] for g in groups.values()))
states=allrows(c,'R1_final_stability.csv');step=rows(c/'processor0/PW1_steps.csv')
check('candidate_exit_no_timeout',int((s/'exit.candidate_final').read_text())==0)
check('candidate_native_state',all(json.loads(p.read_text())['globalFailures']==0 for p in c.glob('processor*/native_crossing_result.json')))
check('candidate_requested_equals_added',all(r[3]==r[4] for r in step))
check('candidate_bounded',max(int(r[3]) for r in states)<=1000 and max(int(r[3]) for r in step)<=1000 and all(int(r[3])==50 for r in rows(c/'processor0/R1_final_stability.csv')[9:]))
check('candidate_injected_mass',abs(math.fsum(float(r[7]) for r in birth)/.0005262723452-1)<=1e-12)
original=b/'fitting/dpm/m8a3b_t4_s2_timeout_d1_native_v1/exact_replay'
check('candidate_only_rate_changed',all((c/'constant'/name).read_text().replace('parcelsPerSecond 50;','parcelsPerSecond 21220659;')==(original/'constant'/name).read_text() for name in ['roleAProperties','roleBProperties']))
candidate={'requestedByStep':[int(r[3]) for r in step],'actualByStep':[int(r[4]) for r in step],'globalPopulationByStep':[int(r[3]) for r in rows(c/'processor0/R1_final_stability.csv')],'representedInjectedMass':math.fsum(float(r[7]) for r in birth),'crossings':len(groups),'directions':{'0to1':sum(g['SEND_AFTER_PREPARE'][2]=='0' for g in groups.values()),'1to0':sum(g['SEND_AFTER_PREPARE'][2]=='1' for g in groups.values())},'wallSeconds':float((s/'wall.candidate_final').read_text()),'allPhysicalScalarBitsPreserved':checks['candidate_physical_state_bit_parity']}
rollback=s/'rollback_final'
check('rollback_normal_exit',int((s/'exit.rollback_final').read_text())==0)
check('rollback_nonempty_weighted_exact',all((rollback/f'processor{rank}/PW1_accepted_before.txt').read_bytes()==(rollback/f'processor{rank}/PW1_accepted_after_discard.txt').read_bytes() for rank in [0,1]) and (rollback/'processor0/PW1_accepted_before.txt').stat().st_size>0)
check('rollback_full_codec_and_lifetime',all(r[1]=='1' and r[2:5]==['0','0','0'] for r in allrows(rollback,'N1_discard.csv')))
serial=s/'serial_final';mpi=s/'mpi_final'
check('serial_mpi_normal_exit',all(int((s/f'exit.{name}').read_text())==0 for name in ['serial_final','mpi_final']))
a=rows(serial/'PW1_face_state.csv');q=allrows(mpi,'PW1_face_state.csv')
def faceEqual(x,y):
 return len(x)==len(y) and all(u==v or (j==30 and abs(value(u)-value(v))<=32*2.220446049250313e-16*max(abs(value(u)),abs(value(v)))) for j,(u,v) in enumerate(zip(x,y)))
def value(x):return struct.unpack('<d',int(x).to_bytes(8,'little'))[0]
check('serial_internal_face_MPI_face_native_roundoff',len(a)==len(q)==1 and faceEqual(a[0],q[0]))
bb=allrows(mpi,'R1_boundary.csv');g={r[1]:r for r in bb}
check('same_serial_state_received_after_MPI',len(a)==1 and a[0][:2]==g['RECEIVE_AFTER_CORRECT'][3:5] and faceEqual(a[0],g['RECEIVE_AFTER_CORRECT'][3:5]+g['RECEIVE_AFTER_CORRECT'][21:52]))
sa=rows(serial/'PW1_state_bits.csv')[0];ma=allrows(mpi,'PW1_state_bits.csv')[0]
check('serial_final_multiplicity_d_T_Y_identity',all(sa[j]==ma[j] for j in [1,2,3,4,15,33]))
names=['nParticle','d','dTarget','Ux','Uy','Uz','rho','age','tTurb','UTurbx','UTurby','UTurbz','T','Cp','mass0','d0','position0x','position0y','position0z','sigma','mu','liquidCore','KHindex','y','yDot','tc','ms','injector','tMom','user','Y0']
def value(x):return struct.unpack('<d',int(x).to_bytes(8,'little'))[0]
parity={'faceNativeRoundoffParity':checks['serial_internal_face_MPI_face_native_roundoff'],'faceBitDifferences':[{ 'field':names[i-2],'serial':value(a[0][i]),'MPI':value(q[0][i]),'ULP_distance':abs(int(a[0][i])-int(q[0][i]))} for i in range(2,len(a[0])) if a[0][i]!=q[0][i]],'sameStateReceived':checks['same_serial_state_received_after_MPI'],'finalComparison':{name:{'serial':value(sa[i+3]),'MPI':value(ma[i+3]),'bitEqual':sa[i+3]==ma[i+3]} for i,name in enumerate(names)},'limit':'Final stochastic trajectories are not required to match: native rank-local RNG is neither synchronized nor changed; this spot certifies migration semantics, not R1 RNG-next or spray statistics.'}
check('no_double_weighting', 'np0*dUTrans' in (b/'tests/fiveEqDPMParcelC2/parcel/LazyReactingParcel.C').read_text() and 'nParticle' not in (b/'dpmFiveEq/fiveEqDPMSourceAdapter.H').read_text() and 'this->setNumberOfParticles' in (b/'tests/fiveEqDPMParcelC2/ExceptionSafeConeInjection.H').read_text())
modelRows=allrows(c,'R1_continuation.csv')
check('native_drag_dispersion_atomization_KH_executed', all(sum(int(r[col]) for r in modelRows)>0 for col in [4,5,7,8]))
check('candidate_void_trajectory',all(r[1]=='1' for r in allrows(c,'PW1_void.csv')))
previous=json.loads((s/'frozen_before.json').read_text());changed=[k for k,h in previous.items() if not (root/k).is_file() or sha(root/k)!=h]
check('protected_project_unchanged',changed==[])
foundation=(s/'installed_source_verification.txt').read_text().splitlines();native=(s/'native_parcel_verification.txt').read_text().splitlines()
check('Foundation6717',len(foundation)==6717 and all(x.endswith(': OK') for x in foundation))
check('nativeParcel19',len(native)==19 and all(x.endswith(': OK') for x in native))
old=b/'tests/fiveEqDPMR1FinalNative';new=b/'tests/fiveEqDPMPW1Native'
delta=[]
for p in old.rglob('*'):
 if p.is_file() and 'linux64GccDPInt32Opt' not in p.parts and 'lnInclude' not in p.parts and p.name!='testR1FinalNative' and p.suffix not in ['.o','.dep']:
  relative=p.relative_to(old);other=new/relative
  if not other.exists() or sha(p)!=sha(other):delta.append(str(relative))
check('only_isolated_main_and_Make_changed',set(delta)=={'testNewbornIdentity.C','Make\\files'} or set(delta)=={'testNewbornIdentity.C','Make/files'})
(s/'PW1_target.diff').write_text(''.join(difflib.unified_diff((old/'testNewbornIdentity.C').read_text().splitlines(True),(new/'testNewbornIdentity.C').read_text().splitlines(True),fromfile='frozen_R1_main',tofile='PW1_observers_and_serial_entry')))
result={'status':'COMPLETE / OF7-NATIVE WEIGHTED PARCEL QUALIFIED' if all(checks.values()) else 'PARTIAL','checks':checks,'failed':[k for k,v in checks.items() if not v],'ladder':ladder,'candidate':candidate,'serial_MPI_spot':parity,'protectedEntries':len(previous),'unexpectedChanges':changed,'Foundation':len(foundation),'nativeParcel':len(native),'isolatedSourceDelta':delta,'activeImpact':'NONE','productionImpact':'NONE','S2':'PARTIAL','S3':False,'M6B':False,'CFD':False}
(s/'PW1_gate.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'checks':len(checks),'failed':result['failed'],'candidate':candidate,'ladder':ladder,'parity':{k:v for k,v in parity.items() if k!='finalComparison'}},indent=2))
raise SystemExit(bool(result['failed']))
