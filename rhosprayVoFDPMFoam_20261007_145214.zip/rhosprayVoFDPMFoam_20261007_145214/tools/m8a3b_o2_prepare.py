from pathlib import Path
import hashlib,json,shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2_v1';old=b/'fitting/dpm/m8a3b_o1_v1'
if e.exists():raise RuntimeError('Never overwrite evidence')
e.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_text(json.dumps({str(p.relative_to(b)):sha(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_o2_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()},indent=2))
shutil.copyfile(old/'case_before.json',e/'case_before.json')
t=b/'tests/fiveEqORourkeConservative';(t/'Make').mkdir(parents=True)
(t/'Make/files').write_bytes((b/'tests/fiveEqORourkePopulation/Make/files').read_bytes().replace(b'testFiveEqORourkePopulation',b'testFiveEqORourkeConservative'))
(t/'Make/options').write_bytes((b/'tests/fiveEqORourkePopulation/Make/options').read_bytes().replace(b'-I../fiveEqDPMCarrierPublication',b'-I../fiveEqORourkePopulation -I../fiveEqDPMCarrierPublication'))
for s in 'ABC':
 shutil.copytree(old/'fixtures'/s,e/'fixtures'/s)
 shutil.copytree(old/'rebinding_fixtures'/s,e/'rebinding_fixtures'/s)
 shutil.copytree(old/'branch_fixtures'/s,e/'branch_fixtures'/s)
 for kind in ('fixtures','branch_fixtures'):
  shutil.copyfile(e/kind/s/'constant/roleAProperties',e/kind/s/'constant/roleCProperties')
 # Exact collision-entry replay, not reconstructed approximations of the pair.
 r=json.loads((old/'results/branch'/s/'test_results.json').read_text());event=r['updates']
 lines=(old/'results/branch'/s/'native_parcel_states.txt').read_text().splitlines();marker=f'EVENT {event} before';i=lines.index(marker)+1;j=i
 while j<len(lines) and not lines[j].startswith('EVENT '):j+=1
 (e/f'O1_{s}_collision_entry.txt').write_text('\n'.join(lines[i:j])+'\n')
 (e/f'O1_{s}_replay_provenance.json').write_text(json.dumps({'event':event,'sourceFile':str(old/'results/branch'/s/'native_parcel_states.txt'),'sourceSha256':sha(old/'results/branch'/s/'native_parcel_states.txt'),'parcelCount':len(lines[i:j]),'fixture':str(e/'branch_fixtures'/s)},indent=2))
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
for name in ('run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','run_rebinding.sh','run_support.sh','run_carrier_verified.sh','run_all_regressions.sh','read_sources.sh'):
 (e/name).write_bytes((old/name).read_bytes().replace(b'm8a3b_o1_v1',b'm8a3b_o2_v1'))
read=(e/'read_sources.sh').read_bytes().replace(b'SprayCloud.C KinematicParcel.H',b'CompositionModel.C singlePhaseMixture.C liquidProperties.H liquidPropertiesI.H liquidMixtureProperties.C liquidMixtureProperties.H C10H22.H C10H22.C SprayParcel.H SprayParcelI.H ThermoParcelI.H KinematicCloud.H SprayCloud.C KinematicParcel.H')
(e/'read_sources.sh').write_bytes(read)
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqORourkeConservative"\nwmake > "$base/fitting/dpm/m8a3b_o2_v1/log.wmake" 2>&1\n').encode())
(e/'run_o2.sh').write_bytes((head+'for state in A B C; do\n mkdir -p "$base/fitting/dpm/m8a3b_o2_v1/results/$state"\n cd "$base/fitting/dpm/m8a3b_o2_v1/results/$state"\n /usr/bin/time -v "$base/tests/fiveEqORourkeConservative/testFiveEqORourkeConservative" "$base/fitting/dpm/m8a3b_o2_v1/branch_fixtures/$state" "$state" /mnt/d/DATA/Solver/300_2D/constant/thermal.dat "$base/fitting/dpm/m8a3b_o2_v1/O1_${state}_collision_entry.txt" > log.run 2> log.resource\ndone\n').encode())
print(e)
