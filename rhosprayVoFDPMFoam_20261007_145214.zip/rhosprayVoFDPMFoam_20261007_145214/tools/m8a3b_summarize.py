from pathlib import Path
import json,hashlib,csv
b=Path(__file__).resolve().parents[1]; e=b/'fitting/dpm/m8a3b_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((e/'protected_before.json').read_text())
changed=[name for name,h in before.items() if not (b/name).exists() or sha(b/name)!=h]
allowed=[]
saved=e/'milestone_before.md'
if saved.exists() and 'MILESTONE_STATUS.md' in changed and sha(saved)==before['MILESTONE_STATUS.md'] and (b/'MILESTONE_STATUS.md').read_bytes().startswith(saved.read_bytes()):
    changed.remove('MILESTONE_STATUS.md');allowed.append('MILESTONE_STATUS.md (append only)')
reg={}
for category in ('energy_regressions','D_regressions','temporal','rebinding'):
    rows=[]
    for p in (e/category).rglob('test_results.json'):
        rows.append({'name':p.parent.relative_to(e/category).as_posix(),**json.loads(p.read_text())})
    reg[category]={'results':rows,'reportedChecks':sum(r.get('checks',0) for r in rows),'failures':sum(r.get('failures',0) for r in rows)}
# Frozen energy/source golden bytes must match, excluding timing evidence.
golden=[]
for p in (e/'energy_regressions').rglob('*'):
    if p.name in ('golden_energy.csv','ledger.csv','test_results.json','test_failures.txt'):
        old=b/'fitting/dpm/m8a_v1'/p.relative_to(e/'energy_regressions')
        golden.append({'file':p.relative_to(e).as_posix(),'baselineExists':old.exists(),'equal':old.exists() and sha(p)==sha(old)})
fixtures=[]
for p in (e/'scan_fixture').rglob('*'):
    if p.is_file():
        src=b.parent/'300_2D'/p.relative_to(e/'scan_fixture')
        fixtures.append(src.exists() and sha(src)==sha(p))
scan=json.loads((e/'test_results.json').read_text()); native=json.loads((e/'sparse_verification.json').read_text())
topologies=list(csv.DictReader((e/'support_topologies.csv').open()))
query=list(csv.DictReader((e/'injection_stencil.csv').open()))
inj=[]
for r in topologies:
    edge=float(r['traceInterfaceX']); name=r['map']; invalid=[]
    for q in query:
        # Synthetic-map geometry only. This is NOT intended material topology.
        if name!='legacy_all_gas_presence_only' and float(q['x'])<edge: invalid.append(int(q['entity']))
    inj.append({'map':name,'actualPosition':[.015,5e-6,.015],'entities':len(query),'gasPresenceSupportValid':not invalid,'gasAbsentEntities':invalid,'fullThermoSupportCertified':False})
(e/'injection_map_diagnostics.json').write_text(json.dumps(inj,indent=2))
summary={'status':'PARTIAL / INTENDED_TOPOLOGY_INPUT_REQUIRED','selectedArchitecture':'dual-cloud logical role swap (design frozen; not implemented)',
 'scan':scan,'nativeSparseVerification':native,'topologies':topologies,'injectionDiagnosticMaps':inj,'regressions':reg,
 'frozenEnergyGoldenComparisons':golden,'protectedExistingFileChanges':changed,'allowedExistingFileChanges':allowed,'scanFixtureMatchesActualCase':all(fixtures),
 'activeSolverImpact':'NONE','noCFD':True,'fullTransactionImplemented':False,'MPITransactionTested':False,'M6B0':'BLOCKED','M6B1':'NO'}
(e/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k in ('status','protectedExistingFileChanges','scanFixtureMatchesActualCase')},indent=2))
print('Energy goldens',len(golden),'mismatches',sum(not x['equal'] for x in golden))
for category,r in reg.items():print(category,r['reportedChecks'],r['failures'],len(r['results']))
