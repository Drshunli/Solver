from pathlib import Path
import shutil
b=Path(__file__).resolve().parents[1];t=b/'tests/fiveEqDPMNative';m=t/'Make';m.mkdir(exist_ok=True)
opts=(b/'Make/options').read_text().replace('-I. \\', '-I../../dpmFiveEq -I../../fiveEqPrecision -I../../fiveEqHighOrderPrecision -I../../fiveEqFlux -I../../fiveEqReconstruction \\').replace('-IfiveEq','-I../../fiveEq').replace('-IliquidEOS','-I../../liquidEOS')
(m/'options').write_bytes(opts.encode()); files=(b/'tests/fiveEqTemporalContract/Make/files').read_text().replace('testFiveEqTemporalContract','testFiveEqDPMNative');(m/'files').write_bytes(files.encode())
def header(obj,cls='dictionary'):return f'FoamFile {{version 2.0; format ascii; class {cls}; object {obj};}}\n'
for mode in ('zero','heat','momentum','mass','evaporation','combined','disappearance'):
 f=t/'fixtures'/mode
 for d in ('0','system','constant'): (f/d).mkdir(parents=True,exist_ok=True)
 shutil.copytree(b/'tests/fiveEqOF7Interpolation/fixture/constant/polyMesh',f/'constant/polyMesh',dirs_exist_ok=True)
 for name in ('thermophysicalProperties','thermal.dat','reactions'):shutil.copyfile(b.parent/'300_2D/constant'/name,f/'constant'/name)
 for name,value,dims in [('p',3000000,'1 -1 -2 0 0 0 0'),('T',800,'0 0 0 1 0 0 0'),('C10H22',0,'0 0 0 0 0 0 0'),('O2',.228,'0 0 0 0 0 0 0'),('N2',.772,'0 0 0 0 0 0 0')]:
  (f/'0'/name).write_bytes((header(name,'volScalarField')+f'dimensions [{dims}]; internalField uniform {value}; boundaryField {{outer {{type zeroGradient;}}}}\n').encode())
 (f/'system/controlDict').write_bytes((header('controlDict')+'application unitHarness; startFrom startTime; startTime 0; stopAt endTime; endTime 1; deltaT 1e-5; writeControl timeStep; writeInterval 1;').encode())
 (f/'system/fvSchemes').write_bytes((header('fvSchemes')+'ddtSchemes {default Euler;} gradSchemes {default Gauss linear;} divSchemes {default none;} laplacianSchemes {default Gauss linear corrected;} interpolationSchemes {default linear;} snGradSchemes {default corrected;}').encode())
 (f/'system/fvSolution').write_bytes((header('fvSolution')+'solvers {}').encode())
 heat='RanzMarshall' if mode in ('heat','evaporation','combined') else 'none'; phase='liquidEvaporation' if mode in ('mass','evaporation','combined','disappearance') else 'none';force='sphereDrag;' if mode in ('momentum','combined') else '';minmass='1e-3' if mode=='disappearance' else '1e-30'
 cloud=header('sprayCloudProperties')+f'''
solution {{active true; coupled true; transient yes; cellValueSourceCorrection off; maxCo .3;
 sourceTerms {{schemes {{rho explicit 1; U explicit 1; Yi explicit 1; h explicit 1; e explicit 1;}}}}
 interpolationSchemes {{rho cell; U cell; thermo:mu cell; T cell; Cp cell; kappa cell; p cell;}}
 integrationSchemes {{U Euler; T analytical;}}}}
constantProperties {{T0 300; rho0 730; Cp0 2090; constantVolume false; minParcelMass {minmass};}}
subModels {{particleForces {{{force}}} injectionModels {{}} dispersionModel none; patchInteractionModel none;
 heatTransferModel {heat}; compositionModel singlePhaseMixture; phaseChangeModel {phase}; surfaceFilmModel none;
 atomizationModel none; breakupModel none; stochasticCollisionModel none; radiation off;
 RanzMarshallCoeffs {{BirdCorrection false;}}
 singlePhaseMixtureCoeffs {{phases (liquid {{C10H22 1;}});}}
 liquidEvaporationCoeffs {{enthalpyTransfer enthalpyDifference; activeLiquids (C10H22);}}
}} cloudFunctions {{}}
'''
 (f/'constant/sprayCloudProperties').write_bytes(cloud.encode())
script='#!/bin/bash\nset -e\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\ncd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMNative\nwmake > ../../fitting/dpm/m8a_v1/log.native.wmake 2>&1\n'
(b/'fitting/dpm/m8a_v1/build.sh').write_bytes(script.encode())
