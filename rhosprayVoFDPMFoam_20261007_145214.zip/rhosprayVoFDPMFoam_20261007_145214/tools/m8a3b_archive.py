from pathlib import Path
import zipfile,hashlib,json
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_v1'
out=b/'checkpoints/M8A3B_support_scan_v1_PARTIAL.zip'
if out.exists():raise SystemExit('Refusing to overwrite checkpoint')
files=set(p for p in e.rglob('*') if p.is_file())
files.update(p for p in (b/'tests/fiveEqDPMSupportScan').rglob('*') if p.is_file() and not any(x.startswith('linux') for x in p.parts))
files.update(b.glob('tools/m8a3b_*'))
files.update([b/'M8A3B_FULL_TRANSACTION_GATE.md',b/'docs/M8A3B_ROLE_SWAP_DESIGN.md',b/'MILESTONE_STATUS.md'])
files={p for p in files if p.name!='core' and not p.name.startswith('core.') and not p.is_symlink()}
manifest={p.relative_to(b).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,p.relative_to(b).as_posix())
    z.writestr('M8A3B_CHECKPOINT_MANIFEST.json',json.dumps(manifest,indent=2))
result={'path':str(out),'files':len(files),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'status':'PARTIAL'}
(e/'checkpoint.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
