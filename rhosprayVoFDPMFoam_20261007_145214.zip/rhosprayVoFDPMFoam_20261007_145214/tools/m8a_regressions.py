from pathlib import Path
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a_v1'
old=(b/'fitting/integration/m5c3_v1/run_D_regressions.sh').read_text();(e/'run_frozen_regressions.sh').write_bytes(old.replace('fitting/integration/m5c3_v1/D_regressions','fitting/dpm/m8a_v1/D_regressions').encode())
s='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\n'
for path in ['specie/thermo/thermo/thermoI.H','specie/thermo/janaf/janafThermoI.H','specie/thermo/sensibleInternalEnergy/sensibleInternalEnergy.H','chemistryModel/chemistryModel/StandardChemistryModel/StandardChemistryModel.C']:
 q=e/'source_audit/thermophysicalModels'/path;q.parent.mkdir(parents=True,exist_ok=True)
 s+=f'cp /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src/thermophysicalModels/{path} /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a_v1/source_audit/thermophysicalModels/{path}\n'
s+='mkdir -p /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a_v1/temporal\ncd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a_v1/temporal\n/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqTemporalContract/testFiveEqTemporalContract /mnt/d/DATA/Solver/300_2D/constant/thermal.dat /mnt/d/DATA/Solver/300_2D/constant/reactions > log.run 2>&1\necho "$?" > exit_status.txt\nsha256sum /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayLiquidEOS.so /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayFiveEqThermo.so > ../core_library_hashes.txt\n'
(e/'run_temporal.sh').write_bytes(s.encode())
