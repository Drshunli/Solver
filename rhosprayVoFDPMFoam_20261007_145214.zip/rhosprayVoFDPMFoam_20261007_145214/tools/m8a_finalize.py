from pathlib import Path
import hashlib,json,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a_v1'
s=json.loads((e/'summary.json').read_text(encoding='utf-8'));reg={}
for d in sorted((e/'D_regressions').iterdir()):
 if not d.is_dir():continue
 code=int((d/'exit_status.txt').read_text());r=json.loads((d/'test_results.json').read_text());old=json.loads((b/'fitting/integration/m5c3_v1/D_regressions'/d.name/'test_results.json').read_text())
 reg[d.name]={'exit':code,'result':r,'sameFrozenResult':r==old}
 if code or r.get('failures',0) or r!=old:raise RuntimeError((d.name,r,old))
if len(reg)!=11:raise RuntimeError('missing frozen regression')
temporal=json.loads((e/'temporal/test_results.json').read_text());assert temporal=={'checks':9663,'failures':0}
s['frozenRegressions']=reg;s['temporalRegression']=temporal
libHashes=(e/'core_library_hashes.txt').read_text().splitlines();assert libHashes[0].split()[0]=='79ac28be52ed5aac02745d2ae81a2841508e00ee3eecb725dc8068f3fb503efe';assert libHashes[1].split()[0]=='7754f609bf8ad7bf921c363fa24c21354303f03053e169a8efbe95e0a88ef0dc'
audit=json.loads((e/'protected_after_audit.json').read_text());assert audit['activeSolverImpact']=='NONE';s['protectedFiles']=audit
s['compile']={'initialFullCompile':'PASS; transient clock-skew warning retained in initial log','finalWmakeExit':0,'finalNoRebuildWarnings':False if 'warning:' in (e/'log.native.wmake').read_text() else True,'nativeBinarySHA256':hashlib.sha256((b/'tests/fiveEqDPMNative/testFiveEqDPMNative').read_bytes()).hexdigest()}
(e/'summary.json').write_bytes(json.dumps(s,indent=2).encode())
report=b/'M8A_DPM_SOURCE_ENERGY_GATE.md';text=report.read_text(encoding='utf-8');text=text.replace('Frozen temporal test 9663/0; D regressions recorded under M8A evidence.','Frozen temporal test 9663/0; all 11 D regressions exit0/failure0 and their result JSON exactly matches the frozen M5C.3 result. Initial full-build transient clock-skew warning is retained; final wmake exits0 without warnings, unchanged binary verified by hash.');report.write_bytes(text.encode())
paths=set()
for folder in ('dpmFiveEq','fitting/dpm/m8a_v1'):
 paths.update(p for p in (b/folder).rglob('*') if p.is_file())
for p in (b/'tests/fiveEqDPMNative').rglob('*'):
 if p.is_file() and not any('linux64Gcc' in x for x in p.parts):paths.add(p)
paths.update((b/'tools').glob('m8a_*.py'))
paths.update(b/'docs'/f for f in ('OF7_DPM_SOURCE_AUDIT.md','DPM_EULERIAN_ENERGY_REFERENCE_LEDGER.md','DPM_KINETIC_ENERGY_SOURCE_AUDIT.md','FIVE_EQ_DPM_COUPLING_CONTRACT.md'))
paths.update(b/f for f in ('M8A_DPM_SOURCE_ENERGY_GATE.md','ENERGY_REFERENCE_AUDIT.md','MILESTONE_STATUS.md'))
manifest={str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)};(e/'checkpoint_manifest.json').write_bytes(json.dumps(manifest,indent=2).encode());paths.add(e/'checkpoint_manifest.json')
z=b/'checkpoints/M8A_dpm_source_energy_v1_PARTIAL.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for p in sorted(paths):out.write(p,p.relative_to(b))
digest=hashlib.sha256(z.read_bytes()).hexdigest();(b/'checkpoints/M8A_dpm_source_energy_v1_PARTIAL.sha256').write_text(digest+'  '+z.name+'\n',encoding='ascii')
print(json.dumps({'checkpoint':str(z),'sha256':digest,'files':len(paths),'nativeChecks':s['checks'],'D':len(reg),'allFrozenEqual':True,'status':s['status']},indent=2))
