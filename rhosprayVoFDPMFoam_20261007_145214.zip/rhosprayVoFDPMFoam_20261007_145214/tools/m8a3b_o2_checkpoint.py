"""Archive this design gate only; never overwrite historical evidence."""
from pathlib import Path
import hashlib,json,zipfile,sys
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2_v1'
assert json.loads((e/'independent_audit.json').read_text())['status']=='PASS'
before=e/'MILESTONE_STATUS.beforeO2.md'
if not before.exists():
 before.write_bytes((b/'MILESTONE_STATUS.md').read_bytes())
 with (b/'MILESTONE_STATUS.md').open('a',encoding='utf-8',newline='\n') as f:
  f.write('''

## 2026-10-02 M8A.3B-O2

COMPLETE / DESIGN + OFFLINE-NATIVE HARNESS ONLY.
OF7-ORourke-conservative-v1 selects B: event-local conservative internal merge,
represented COM momentum and explicit isolated-adiabatic parcel caloric thermalization.
No positive mass deletion or carrier/alpha/Eulerian-liquid dumping.
A/B/C 27420 native assertions and 2697 independent ledger checks PASS;
1000 collision updates/seed, rollback/one accepted internal event/next query PASS.
Frozen six regression groups PASS; 8 energy goldens byte-identical.
O1 historical fixtures unchanged: duplicate IDs5/6/11 discovered from legacy
allocator initialization; retained as rejection fixtures. Exact affected native
event replay PASS, full historical cloud identity byte-equality explicitly FALSE.
Thermalization is a new modeled closure, not native behavior/CFD validation.
Active solver and96 actualcase files unchanged. NoCFD.
T3B remainsPARTIAL/BLOCKED; T3PARTIAL; T4NO; M8APARTIAL; M6B.0/1NO.
Next round only: fresh-owner policy adapter, complete canonical retry/output/
combined-event/remaining-model certification. STOP this turn.
See M8A3B_O2_CONSERVATIVE_OROURKE_POLICY_GATE.md and fitting/dpm/m8a3b_o2_v1.
''')
print('Milestone append captured. Run independent audit again before pack.')
if '--pack' in sys.argv:
 audit=json.loads((e/'independent_audit.json').read_text())
 assert audit['authorizedMilestoneAppend'] and audit['protectedImplementationAndEvidenceUnchanged']
 dest=b/'checkpoints/M8A3B_O2_conservative_policy_v1_COMPLETE.zip'
 assert not dest.exists(),'Never overwrite checkpoint'
 paths=[]
 for root in (e,b/'tests/fiveEqORourkeConservative'):
  for p in root.rglob('*'):
   rel=p.relative_to(b)
   if 'lnInclude' in rel.parts:continue
   if 'Make' in rel.parts and p.name not in ('files','options'):continue
   if p.is_symlink() or not p.is_file():continue
   if p.name=='testFiveEqORourkeConservative':continue
   paths.append(p)
 paths.extend(b/'tools'/name for name in ('m8a3b_o2_prepare.py','m8a3b_o2_generate_main.py','m8a3b_o2_compare_capture.py','m8a3b_o2_finalize.py','m8a3b_o2_checkpoint.py'))
 paths.extend((b/'M8A3B_O2_CONSERVATIVE_OROURKE_POLICY_GATE.md',b/'MILESTONE_STATUS.md'))
 manifest={str(p.relative_to(b)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in paths:z.write(p,str(p.relative_to(b)).replace('\\','/'))
  z.writestr('O2_CHECKPOINT_MANIFEST.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  assert all(hashlib.sha256(z.read(rel)).hexdigest()==h for rel,h in manifest.items())
 checkpoint={'status':'COMPLETE / DESIGN + OFFLINE-NATIVE HARNESS ONLY','zip':str(dest),
  'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(paths),'bytes':dest.stat().st_size,
  'manifestAndCRCVerified':True,'T3BResumed':False,'noCFD':True}
 dest.with_suffix('.json').write_text(json.dumps(checkpoint,indent=2))
 print(json.dumps(checkpoint,indent=2))
