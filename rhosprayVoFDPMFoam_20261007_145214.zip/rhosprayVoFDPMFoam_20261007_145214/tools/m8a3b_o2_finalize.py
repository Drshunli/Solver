"""Independent evidence audit; no solver/runtime dictionary changes."""
from pathlib import Path
from decimal import Decimal as D
import json, hashlib, math

b=Path(__file__).resolve().parents[1]
e=b/'fitting/dpm/m8a3b_o2_v1'
def read(p): return json.loads(p.read_text(),parse_float=D)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
eps=D(2)**-52
def budget(a,z):return D('1e-30')+128*eps*(abs(a)+abs(z))
checks=0
maxima=dict(mass=D(0),species=D(0),momentum=D(0),energy=D(0))
def close(kind,a,z,scale=None):
 global checks
 residual=abs(z-a); allowance=budget(a,z) if scale is None else budget(*scale)
 assert residual<=allowance,(kind,residual,allowance)
 maxima[kind]=max(maxima[kind],residual);checks+=1
results={s:read(e/f'results/{s}/test_results.json') for s in 'ABC'}
for s,r in results.items():
 assert r['failures']==0 and r['physicalEntryExact'] and r['rollback'] and r['nextCollisionQuery']
 assert r['acceptedCommits']==1 and r['stressUpdates']==1000
 for p in (e/f'results/{s}').glob('*.jsonl'):
  for line in p.read_text().splitlines():
   if not line.strip():continue
   ev=json.loads(line,parse_float=D)
   if ev['type']!='pair':continue
   a,z=ev['before'],ev['after']
   ma=sum(x['mass'] for x in a);mz=sum(x['mass'] for x in z)
   close('mass',ma,mz)
   for j in range(len(a[0]['Y'])):
    close('species',sum(x['mass']*x['Y'][j] for x in a),sum(x['mass']*x['Y'][j] for x in z))
   for j in range(3):
    pa=[x['mass']*x['U'][j] for x in a];pz=[x['mass']*x['U'][j] for x in z]
    close('momentum',sum(pa),sum(pz),(sum(abs(x) for x in pa),sum(abs(x) for x in pz)))
   close('energy',ev['Ebefore'],ev['Eafter'])
   for x in z:
    assert x['mass']>=0 and x['nParticle']>=0 and x['rho']>0 and D('243.51')<=x['T']<D('617.7')
    assert all(y>=0 for y in x['Y']) and abs(sum(x['Y'])-1)<=128*eps
 for p in (e/f'results/{s}').glob('*_ledger.json'):
  ev=read(p);a,z=ev['before'],ev['after']
  close('mass',a['m'],z['m'])
  for ya,yz in zip(a['Y'],z['Y']):close('species',ya,yz)
  # O1 Total writes internal energy as E and kinetic as KE, separately.
  close('energy',a['E']+a['KE'],z['E']+z['KE'])
  assert ev['sourceBefore']==ev['sourceAfter'],p
reg={}
for folder in ('energy_regressions','rebinding','D_regressions','carrier_verified','support_regression','temporal'):
 fs=list((e/folder).rglob('test_results.json'))
 assert fs,folder
 rows=[read(p) for p in fs]
 assert all(r.get('failures',0)==0 for r in rows),folder
 reg[folder]={'files':len(fs),'checks':sum(r.get('checks',0) for r in rows),'failures':0}
old=b/'fitting/dpm/m8a3b_o1_v1'
goldens=[]
for p in (e/'energy_regressions').rglob('golden_energy.csv'):
 rel=p.relative_to(e);assert p.read_bytes()==(old/rel).read_bytes();goldens.append(str(rel))
assert len(goldens)==8
native_support=read(e/'support_regression/native_comparison.json')
assert native_support['checks']==1725880 and native_support['failures']==0
reg['support_regression']['checks']=native_support['checks']
reg['support_regression']['maxError']=str(native_support['maxError'])
protected=json.loads((e/'protected_before.json').read_text())
changed=[rel for rel,h in protected.items() if not (b/rel).exists() or sha(b/rel)!=h]
if 'MILESTONE_STATUS.md' in changed:
 before=e/'MILESTONE_STATUS.beforeO2.md'
 assert sha(before)==protected['MILESTONE_STATUS.md']
 assert (b/'MILESTONE_STATUS.md').read_bytes().startswith(before.read_bytes())
 changed.remove('MILESTONE_STATUS.md')
assert not changed,changed
case=json.loads((e/'case_before.json').read_text())
case_root=b.parent/'300_2D'
assert all(sha(case_root/rel)==h for rel,h in case.items())
out={'status':'PASS','nativeChecks':sum(r['checks'] for r in results.values()),'nativeFailures':0,
 'independentLedgerChecks':checks,'maxAbsoluteResiduals':{k:str(v) for k,v in maxima.items()},
 'results':results,'regressions':reg,'energyGoldensByteIdentical':len(goldens),
 'protectedImplementationAndEvidenceUnchanged':True,'protectedFilesAudited':len(protected),
 'authorizedMilestoneAppend':(e/'MILESTONE_STATUS.beforeO2.md').exists(),
 'caseFilesUnchanged':len(case),'activeSolverImpact':'NONE',
 'historicalFullCloudIdentityExact':False,'exactAffectedEventReplay':True,'noCFD':True}
(e/'independent_audit.json').write_text(json.dumps(out,indent=2,default=lambda v:float(v)))
print(json.dumps(out,indent=2,default=lambda v:float(v)))
