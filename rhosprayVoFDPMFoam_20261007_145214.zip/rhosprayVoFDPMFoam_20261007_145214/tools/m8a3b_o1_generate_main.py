from pathlib import Path
b=Path(__file__).resolve().parents[1]
s=(b/'tests/fiveEqDPMEventLedger/testFiveEqDPMEventLedger.C').read_text()
s=s[:s.index(' auto initial=')].replace('#include "eventLedger.H"','#include "populationAudit.H"').replace('if(argc!=4)','if(argc!=5)')
s+='''
 const bool branch=std::string(argv[4])=="branch"; const bool entry=std::string(argv[4])=="entry";
 auto initial=std::unique_ptr<m8a3a::Cloud>(new m8a3a::Cloud("roleA",rho,U,gravity,slg,false));
 time.setDeltaT(1e-6);
 {m8a3a::TrialScope passive;for(unsigned i=0;i<history;++i){++time;initial->evolve();}}
 const unsigned seed=initial->size(),cell=mesh.nCells()-1;
 if(branch){
  for(unsigned i=0;i<2;++i){auto*p=new Foam::basicSprayParcel(mesh,mesh.C()[cell],cell);
   initial->setParcelThermoProperties(*p,1e-8);p->T()=300;p->Y()=Foam::scalarField(1,1);
   p->rho()=initial->composition().liquids().rho(3e6,300,p->Y());p->Cp()=initial->composition().liquids().Cp(3e6,300,p->Y());
   p->sigma()=initial->composition().liquids().sigma(3e6,300,p->Y());p->mu()=initial->composition().liquids().mu(3e6,300,p->Y());
   p->d()=p->d0()=i?5e-8:1e-6;p->mass0()=p->mass();p->liquidCore()=0;p->U()=Foam::vector(47,i?10:0,0);
   p->KHindex()=1;p->position0()=p->position();p->nParticle()=(i?1.05e-15:1e-12)/p->mass();initial->addParticle(p);
  }
 }
 if(entry){auto*p=new Foam::basicSprayParcel(mesh,mesh.C()[cell],cell);initial->setParcelThermoProperties(*p,1e-6);p->T()=300;p->Y()=Foam::scalarField(1,1);p->rho()=initial->composition().liquids().rho(3e6,300,p->Y());p->d()=p->d0()=.0003;p->mass0()=p->mass();p->liquidCore()=0;p->U()=U[cell];p->nParticle()=.5*initial->constProps().minParcelMass()/p->mass();initial->addParticle(p);}\n const auto sentinel=m8a3bt3::cloudDump(*initial),carrier=view.snapshot();const auto allocator=Foam::particle::particleCount_;const auto gen=view.token.generation;
 const double tv=time.value(),delta=time.deltaTValue();const auto ti=time.timeIndex();
 const double dt=branch?1e-8:1e-6;unsigned steps=0,checks=0,failures=0;
 std::ofstream bad("test_failures.txt");auto check=[&](bool ok,const char*n){++checks;if(!ok){++failures;bad<<n<<'\\n';}};
 o1::Audit audit;
 {o1::Cloud trial("roleB",*initial,slg,audit);if(entry)trial.resetSourceTerms();
  for(unsigned i=0;i<(entry?1u:branch?64u:20u);++i){time.setDeltaT(dt);time.setTime(tv+(i+1)*dt,ti+i+1);{m8a3a::TrialScope passive;if(entry){Foam::basicSprayParcel::trackingData td(trial);trial.stochasticCollision().update(td,dt);}else trial.evolve();}++steps;
   check(view.snapshot()==carrier&&view.token.generation==gen,"committedCarrierUnchanged");
   check(m8a3bt3::cloudDump(*initial)==sentinel,"committedCloudUnchanged");
   if(branch&&audit.reached)break;
  }
  std::ofstream out("observed_final_cloud.txt");out<<m8a3bt3::cloudDump(trial);
 }
 Foam::particle::particleCount_=allocator;time.setTime(tv,ti);time.setDeltaT(delta);
 // Independently replay the identical ordinary timestep sequence through the
 // unchanged native ORourke, proving diagnostics preserve physics and RNG.
 {m8a3a::ReconstructedCloud native("roleB",*initial,slg);if(entry)native.resetSourceTerms();
  for(unsigned i=0;i<steps;++i){time.setDeltaT(dt);time.setTime(tv+(i+1)*dt,ti+i+1);{m8a3a::TrialScope passive;if(entry){Foam::basicSprayParcel::trackingData td(native);native.stochasticCollision().update(td,dt);}else native.evolve();}}
  std::ifstream in("observed_final_cloud.txt");std::string observed((std::istreambuf_iterator<char>(in)),{});
  check(observed==m8a3bt3::cloudDump(native),"passiveInstrumentationNativeExactStateAndRNGProbe");
 }
 Foam::particle::particleCount_=allocator;time.setTime(tv,ti);time.setDeltaT(delta);
 check(view.snapshot()==carrier&&m8a3bt3::cloudDump(*initial)==sentinel,"committedSentinelAfterNativeReplay");
 if(branch){check(audit.reached&&audit.merges&&audit.positiveDeletes,"ordinaryCoalescenceThenPositiveCleanup");
  check(audit.before.m-audit.after.m>0,"completePopulationMassDecreases");
  check(audit.sourceAfter.m==audit.sourceBefore.m,"collisionAddsNoNativeCarrierMass");
 }
 std::ofstream result("test_results.json");result<<std::setprecision(21)<<"{\\"state\\":\\""<<state<<"\\",\\"mode\\":\\""<<argv[4]<<"\\",\\"checks\\":"<<checks<<",\\"failures\\":"<<failures<<",\\"seedParcels\\":"<<seed<<",\\"steps\\":"<<steps<<",\\"updates\\":"<<audit.updates<<",\\"pairAttempts\\":"<<audit.pairs<<",\\"collisions\\":"<<audit.collisions<<",\\"coalescences\\":"<<audit.merges<<",\\"deletions\\":"<<audit.deletes<<",\\"positiveDeletions\\":"<<audit.positiveDeletes<<",\\"removedMass\\":"<<audit.removed<<",\\"before\\":";audit.before.write(result);result<<",\\"preCleanup\\":";audit.preCleanup.write(result);result<<",\\"after\\":";audit.after.write(result);result<<",\\"sourceBefore\\":";audit.sourceBefore.write(result);result<<",\\"sourceAfter\\":";audit.sourceAfter.write(result);result<<",\\"noCFD\\":true,\\"ordinaryEvolveEntry\\":true,\\"committedSentinelUnchanged\\":true}\\n";
 return failures?1:0;
}
'''
s=s.replace('ordinaryEvolveEntry\\":true,', 'ordinaryEvolveEntry\\":'+ '"<<(entry?"false":"true")<<"'+ ',')
(b/'tests/fiveEqORourkePopulation/testFiveEqORourkePopulation.C').write_text(s)
