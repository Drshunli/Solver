from pathlib import Path
import hashlib,json,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((e/'protected_before.json').read_text(encoding='utf8'))
# Preparation script was created in this turn, before the protected snapshot.
new_this_turn={'tools\\m8a3b_t3_prepare.py','tools/m8a3b_t3_prepare.py'}
changed=[k for k,v in before.items() if not (b/k).is_file() or sha(b/k)!=v]
unexpected=[k for k in changed if k not in new_this_turn]
assert not unexpected,unexpected
case_before=json.loads((e/'case_before.json').read_text(encoding='utf8'))
case=b.parent/'300_2D'
now={str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()}
assert now==case_before,'Active case changed'
gate=json.loads((e/'gate.json').read_text(encoding='utf8'));assert gate['status']=='PARTIAL'
status=b/'MILESTONE_STATUS.md';old=status.read_bytes()
marker=b'## M8A.3B-T3 serial transaction prototype and stop gate'
assert marker not in old,'Append-only milestone record already exists'
append=b'\n\n'+marker+b'\n\nPARTIAL / COMMIT_ARCHITECTURE_BLOCKER_CARRIER_VIEW_REFRESH. Architecture A\n(dual-cloud logical role swap) selected; passive serial prototype only.\nA/B/C evolved seeds 5/7/9 steps, 106/148/190 parcels: each 1000 independent\nbegin/evolve/discard cycles, aggregate committed sentinels/registry restored.\n6027 guard/lifecycle checks, zero failures; zero accepted promotions out of\n100 requested per state. Legal tiny-step endpoint-remapped source changes\nQ momentum; native reconstructed cloud borrows source rho/U/p/T fields.\nControlled precommit rejection, no source clipping or fake zero increment.\nInitial exploratory A native injection 106->318 and KH child107->108 were\ndiscarded; not full direct-small/Q/output retry proof. Initial registry\npromotion failures retained. Full RNG codec, event ledger, candidate-owned\ncarrier views, strict-support runtime hooks and durable output are pending.\nAll eight models remain BLOCKER for FULL-SERIAL-TRANSACTION-SAFE.\nFrozen source/energy9288, independence6375, P2/recovery/R1 105775 plus1000\nsubULP steps/scheme, temporal/restart9663, native interpolation1725880 PASS.\nAll-gas21000/21000 full-valid. 32 energy-reference rows byte-identical.\nActive solver/Make, actual mesh/case/BC and all frozen source/thermo unchanged.\nNo CFD, MPI, alpha source, interpolation masking or production activation.\nT3 not COMPLETE; T4 may not start; M8A.3B and M8A remain PARTIAL.\nM6B.0 NO, M6B.1 NO. STOP as requested.\nSee M8A3B_T3_SERIAL_TRANSACTION_GATE.md and fitting/dpm/m8a3b_t3_v1.\n'
status.write_bytes(old+append);assert status.read_bytes().startswith(old)
protection={'preexistingProtectedFileChanges':unexpected,'newStagePreparationToolChanged':changed,'caseMeshBCUnchanged':True,'activeSolverUnchanged':True,'activeMakeUnchanged':True,'frozenSourceThermoP2R1Unchanged':True,'milestoneAppendOnly':True,'noCFD':True,'systemOF7Writes':False}
(e/'protection_verification.json').write_text(json.dumps(protection,indent=2),encoding='utf8')
archive=b/'checkpoints/M8A3B_T3_serial_transaction_v1_PARTIAL.zip'
assert not archive.exists()
files=list(e.rglob('*'))+list((b/'tests/fiveEqDPMSerialTransaction').rglob('*'))+list((b/'tools').glob('m8a3b_t3_*.py'))+[b/'docs/M8A3B_T3_SERIAL_TRANSACTION_DESIGN.md',b/'M8A3B_T3_SERIAL_TRANSACTION_GATE.md',status]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:
  if '/Make/linux' in p.as_posix() or '/lnInclude/' in p.as_posix() or p.is_symlink() or not p.is_file():continue
  z.write(p,p.relative_to(b).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(e/'checkpoint.json').write_text(json.dumps({'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size},indent=2),encoding='utf8')
print(json.dumps({'status':'PARTIAL','checkpoint':str(archive),'protectedChanges':unexpected}))
