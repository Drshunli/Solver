"""Isolated PW1 observers; no weighting or native physics implementation."""
from pathlib import Path
import shutil,json,re
b=Path(__file__).resolve().parents[1];s=b/'fitting/dpm/m8a3b_t4_s2_pw1_native_v1'
old=b/'tests/fiveEqDPMR1FinalNative';new=b/'tests/fiveEqDPMPW1Native'
assert not new.exists()
shutil.copytree(old,new,ignore=shutil.ignore_patterns('linux64GccDPInt32Opt','lnInclude','*.o','*.dep','testR1FinalNative'))
(new/'Make/files').write_text((new/'Make/files').read_text().replace('testR1FinalNative','testPW1Native'),newline='\n')
main=(new/'testNewbornIdentity.C').read_text()
main=main.replace('int main(int argc,char**argv){', '''namespace pw1 {
std::ofstream births;long double mass=0;Foam::label count=0;Foam::vector momentum=Foam::vector::zero;
void birth(r2::Cloud&c,const Foam::fiveEqDPM::LazyParcel&p,double np){
 double m=np*p.mass();mass+=m;momentum+=m*p.U();++count;
 births<<std::setprecision(17)<<c.time().timeIndex()<<','<<Foam::Pstream::myProcNo()<<','<<p.origProc()<<','<<p.origId()<<','<<np<<','<<p.d()<<','<<p.rho()<<','<<m<<','<<p.T()<<','<<p.U().x()<<','<<p.U().y()<<','<<p.U().z()<<','<<Foam::particle::particleCount_<<','<<r1::rng(c.rndGen())<<'\\n';
}
}
int main(int argc,char**argv){''')
main=main.replace(' const bool injectionProbe=', ' pw1::births.open((runTime.path()/"PW1_births.csv").c_str());r2::birthHook=&pw1::birth;\n const bool injectionProbe=')
main=main.replace('if(global!=(injectionProbe&&std::string(phase)=="before"?0:1))++failures;', 'if(!injectionProbe&&global!=1)++failures;')
main=main.replace('if(steps==1&&post!=', 'if(!injectionProbe&&steps==1&&post!=')
main=main.replace('if(!args.optionFound("allowNativeBirths")&&total!=1)', 'if(!injectionProbe&&!args.optionFound("allowNativeBirths")&&total!=1)')
anchor='    {m8a3a::TrialScope passive;cloud.evolve();}'
main=main.replace(anchor,'''    const auto countBefore=pw1::count;const auto massBefore=pw1::mass;
    auto startWall=std::chrono::steady_clock::now();
'''+anchor+'''
    double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-startWall).count();
    scalar injected=scalar(pw1::mass-massBefore),massNow=0;label added=pw1::count-countBefore;
    vector particleMomentum=vector::zero,source=vector::zero;
    for(auto it=cloud.begin();it!=cloud.end();++it){massNow+=it().nParticle()*it().mass();particleMomentum+=it().nParticle()*it().mass()*it().U();}
    for(const auto&v:cloud.UTrans())source+=v;
    reduce(injected,sumOp<scalar>());reduce(added,sumOp<label>());reduce(massNow,sumOp<scalar>());
    vector initialMomentum=pw1::momentum;reduce(initialMomentum,sumOp<vector>());reduce(particleMomentum,sumOp<vector>());reduce(source,sumOp<vector>());
    std::ofstream w((runTime.path()/"PW1_steps.csv").c_str(),std::ios::app);
    w<<std::setprecision(17)<<step<<','<<Pstream::myProcNo()<<','<<runTime.value()<<','<<added<<','<<injected<<','<<massNow<<','<<wall<<','<<mag(source)<<','<<mag(initialMomentum-particleMomentum-source)<<','<<particle::particleCount_<<','<<r1::rng(cloud.rndGen())<<'\\n';
''')
main=main.replace('#include <iomanip>','#include <iomanip>\n#include <chrono>')
# Observe existing native trajectory check (no second field contribution).
main=main.replace('  C&cloud=*tx.trial().cloud;', '''  C&cloud=*tx.trial().cloud;
  cloud.functions().set(0,new r2::TrajectoryVF(cloud.functions()[0].dict(),cloud,"voidFraction"));''')
main=main.replace('    auto&theta=static_cast<r1::VF&>(vf)', '''    std::ofstream vo((runTime.path()/"PW1_void.csv").c_str(),std::ios::app);
    auto&observedVF=dynamic_cast<r2::TrajectoryVF&>(vf);vo<<step<<','<<observedVF.trajectoryVerified<<','<<observedVF.observedMoves<<'\\n';
    auto&theta=static_cast<r1::VF&>(vf)''')
# Flush test data per native evolve; no semantic changes.
main=main.replace('    double wall=', '    pw1::births.flush();\n    double wall=')
(new/'testNewbornIdentity.C').write_text(main,newline='\n')
src=b/'fitting/dpm/m8a3b_t4_s2_timeout_d1_native_v1/exact_replay'
def case(name,N,control=True):
 dst=s/name;dst.mkdir()
 for folder in ['0','constant','system','processor0/0','processor0/constant','processor1/0','processor1/constant']:
  shutil.copytree(src/folder,dst/folder,dirs_exist_ok=True)
 for role in ['roleA','roleB']:
  p=dst/'constant'/f'{role}Properties';t=p.read_text()
  t=re.sub(r'parcelsPerSecond\s+\S+;',f'parcelsPerSecond {N/0.0001:.17g};',t)
  t=re.sub(r'SOI\s+\S+;', 'SOI 0;',t);t=re.sub(r'duration\s+\S+;', 'duration 0.0001;',t)
  t=re.sub(r'position\s+\([^;]+;', 'position (3.9 0.5 0.5);',t)
  t=re.sub(r'direction\s+\([^;]+;', 'direction (1 0 0);',t)
  if control:
   t=re.sub(r'type RosinRammler;\s*RosinRammlerDistribution\s*\{[^}]+\}', 'type fixedValue; fixedValueDistribution { value 0.00025; }',t)
  p.write_text(t,newline='\n')
 return dst
for n in [1,10,100,1000]:case(f'ladder_{n}',n)
(s/'build.sh').write_text('''source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMPW1Native
wmake > /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_pw1_native_v1/log.wmake 2>&1
''',newline='\n')
(s/'run_ladder.sh').write_text('''source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
s=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_pw1_native_v1
exe=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMPW1Native/testPW1Native
for n in 1 10 100 1000;do
timeout 55s mpirun --oversubscribe -np 2 "$exe" -nativeInjectionProbe -allowNativeBirths -steps 1 -dt .0001 -parallel -case "$s/ladder_$n" > "$s/log.ladder_$n" 2>&1
rc=$?;echo "$rc" > "$s/exit.ladder_$n";test "$rc" = 0 || exit "$rc"
done
''',newline='\n')
print('Prepared PW1 target and four isolated native mass-basis controls')
