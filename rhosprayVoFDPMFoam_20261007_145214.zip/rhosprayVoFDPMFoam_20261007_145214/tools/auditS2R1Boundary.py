"""Read-only offline migration oracle; never used as a transport serializer."""
import csv,json,pathlib,sys,collections
case=pathlib.Path(sys.argv[1])
rows=[]
for p in sorted(case.glob('processor*/R1_boundary.csv')):
 with p.open() as f: rows+=list(csv.reader(f))
groups=collections.defaultdict(lambda:collections.defaultdict(list))
for r in rows: groups[(r[0],r[3],r[4])][(r[1],r[2])].append(r)
errors=[];events=0;direction=collections.Counter()
for identity,stages in groups.items():
 for rank in ('0','1'):
  peer=str(1-int(rank))
  sends=stages[('SEND_BEFORE_PREPARE',rank)]
  packed=stages[('SEND_AFTER_PREPARE',rank)]
  raw=stages[('RECEIVE_BEFORE_CORRECT',peer)]
  received=stages[('RECEIVE_AFTER_CORRECT',peer)]
  if not (len(sends)==len(packed)==len(raw)==len(received)):
   errors.append([identity,rank,'BOUNDARY_COUNT_MISMATCH']);continue
  for i,(a,b,c,d) in enumerate(zip(sends,packed,raw,received)):
   events+=1;direction[rank+'->'+peer]+=1
   # fields: cycle/stage/rank/IDs/position/cell/face/tetFace/tetPt/RNG/active/type/C2 doubles/native particle ASCII
   checks={
    'identity':a[3:5]==d[3:5],
    'native_stream_all_scalars':b[15:-1]==c[15:-1],
    'native_stream_flags':b[13:15]==c[13:15],
    'native_stream_particle_history':b[-1]==c[-1],
    'physical_and_history_equality':a[19:-1]==d[19:-1] and a[13:15]==d[13:15],
    'prepare_rng_no_draw':a[12]==b[12],
    'correct_rng_no_draw':c[12]==d[12],
    'physical_position':max(abs(float(x)-float(y)) for x,y in zip(a[5:8],d[5:8]))<1e-12,
    'destination_native_face':d[9]==d[10],
    'native_quad_tet_reflection':int(a[11])+int(d[11])==3,
   }
   # reflect() swaps barycentric c/d; all raw scalars are equal before correct.
   checks['barycentric_reflection']=a[15:17]==d[15:17] and a[17]==d[18] and a[18]==d[17]
   for name,ok in checks.items():
    if not ok: errors.append([identity,rank,i,name])
out={'events':events,'directions':dict(direction),'errors':errors,'status':'PASS' if events and not errors else 'FAIL',
 'scope':'axis-aligned two-rank quad processor patch; existing C2 helper as oracle only'}
print(json.dumps(out,indent=2))
sys.exit(bool(errors) or not events)
