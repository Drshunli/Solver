from pathlib import Path
b=Path(__file__).resolve().parents[1]
s=(b/'tests/fiveEqORourkePopulation/testFiveEqORourkePopulation.C').read_text()
s=s[:s.index(' const bool branch=')].replace('#include "populationAudit.H"','#include "captureNative.H"')
s+='''
 unsigned checks=0,failures=0;std::ofstream bad("test_failures.txt");auto check=[&](bool ok,const char*n){++checks;if(!ok){++failures;bad<<n<<'\\n';}};
 auto initial=std::unique_ptr<m8a3a::Cloud>(new m8a3a::Cloud("roleA",rho,U,gravity,slg,false));time.setDeltaT(1e-6);
 {m8a3a::TrialScope scope;for(unsigned i=0;i<history;++i){++time;initial->evolve();}}
 const unsigned cell=mesh.nCells()-1;
 for(unsigned i=0;i<2;++i){auto*p=new Foam::basicSprayParcel(mesh,mesh.C()[cell],cell);initial->setParcelThermoProperties(*p,1e-8);
  p->T()=300;p->Y()=Foam::scalarField(1,1);p->rho()=initial->composition().liquids().rho(3e6,300,p->Y());p->Cp()=initial->composition().liquids().Cp(3e6,300,p->Y());p->sigma()=initial->composition().liquids().sigma(3e6,300,p->Y());p->mu()=initial->composition().liquids().mu(3e6,300,p->Y());p->d()=p->d0()=i?5e-8:1e-6;p->mass0()=p->mass();p->liquidCore()=0;p->U()=Foam::vector(47,i?10:0,0);p->KHindex()=1;p->position0()=p->position();p->nParticle()=(i?1.05e-15:1e-12)/p->mass();initial->addParticle(p);
 }
 o2::Entry entry;entry.target=state=="A"?24:state=="B"?26:48;
 {m8a3a::TrialScope scope;auto c=std::unique_ptr<m8a3a::Cloud>(new o2::CaptureCloud("roleB",*initial,slg,entry));initial=std::move(c);}
 const double tv=time.value();const auto ti=time.timeIndex();time.setDeltaT(1e-8);{m8a3a::TrialScope scope;for(unsigned i=0;i<entry.target;++i){time.setTime(tv+(i+1)*1e-8,ti+i+1);initial->evolve();}}
 std::ifstream original(argv[4]);std::string frozen((std::istreambuf_iterator<char>(original)),{});
 std::ofstream("captured_native_entry.txt")<<entry.serialization;bool exactNativeEntry=entry.serialization==frozen;
 // Preserve the historical identity defect rather than relabel owned parcels.
 std::istringstream oldLines(frozen),newLines(entry.serialization);std::string oldLine,newLine;unsigned historicalIdentityChanges=0;bool exactPhysicalEntry=true;std::set<std::pair<int,int>> oldIdentities;unsigned historicalDuplicateIds=0;
 while(std::getline(oldLines,oldLine)&&std::getline(newLines,newLine)){
  if(!oldLine.empty()&&oldLine.back()=='\\r')oldLine.pop_back();Foam::IStringStream x(oldLine),y(newLine);Foam::basicSprayParcel historical(mesh,x,true),current(mesh,y,true);
  if(!oldIdentities.emplace(historical.origProc(),historical.origId()).second)++historicalDuplicateIds;
  if(historical.origProc()!=current.origProc()||historical.origId()!=current.origId())++historicalIdentityChanges;
  // Diagnostic copies only: never remap a parcel in an owned cloud.
  historical.origProc()=current.origProc();historical.origId()=current.origId();Foam::OStringStream hx,cy;hx.precision(17);cy.precision(17);hx<<historical;cy<<current;
  exactPhysicalEntry=exactPhysicalEntry&&hx.str()==cy.str();
 }
 check(exactPhysicalEntry,"O1AllPhysicalFieldsExactAfterDiagnosingIdentityOnlyDifference");
 check(historicalDuplicateIds>0&&historicalIdentityChanges==historicalDuplicateIds,"historicalIdentityDefectExplicitNotSilentlyMigrated");
 check(entry.before.m>entry.after.m,"frozenNativePositiveTruncationStillReproduced");
 std::ofstream native("native_O1_replay.json");native<<"{\\"before\\":";entry.before.write(native);native<<",\\"after\\":";entry.after.write(native);native<<"}\\n";
 initial->clear();for(const auto&p:entry.parcels)initial->addParticle(new Foam::basicSprayParcel(*p));initial->rndGen()=*entry.rng;entry.source->restore(*initial);
 auto accepted=std::unique_ptr<t3a::RoleState>(new t3a::RoleState);accepted->cloud=std::move(initial);accepted->q=q;accepted->allocator=Foam::particle::particleCount_;accepted->time=time.value();accepted->index=time.timeIndex();
 t3a::CarrierTransaction tx(std::move(accepted),view,slg,time);
 const auto before=m8a3bt3::cloudDump(tx.cloud()),carrier=view.snapshot();auto gen=view.token.generation;auto id=Foam::particle::particleCount_;auto registry=mesh.Foam::objectRegistry::size();
 auto install=[&](o2::Audit&a){auto&trial=tx.trial();Foam::word name=tx.cloud().name()=="roleC"?"roleB":"roleC";m8a3a::TrialScope scope;auto c=std::unique_ptr<m8a3a::Cloud>(new o2::Cloud(name,*trial.cloud,slg,a));trial.cloud=std::move(c);};
 auto query=[&](m8a3a::Cloud&c,double dt){Foam::basicSprayParcel::trackingData td(c);m8a3a::TrialScope scope;c.stochasticCollision().update(td,dt);};
 auto ledger=[&](o2::Audit&a,const char*name){
  check(std::abs(a.after.m-a.before.m)<=o2::budget(a.before.m,a.after.m),"populationMassClosure");
  for(unsigned j=0;j<a.before.y.size();++j)check(std::abs(a.after.y[j]-a.before.y[j])<=o2::budget(a.before.y[j],a.after.y[j]),"populationSpeciesClosure");
  for(unsigned j=0;j<3;++j)check(std::abs(a.after.p[j]-a.before.p[j])<=o2::budget(a.pScaleBefore[j],a.pScaleAfter[j]),"populationMomentumClosure");
  check(std::abs((a.after.e+a.after.k)-(a.before.e+a.before.k))<=o2::budget(a.before.e+a.before.k,a.after.e+a.after.k),"populationInternalPlusKineticEnergyClosure");
  check(a.sourceBefore.m==a.sourceAfter.m&&a.sourceBefore.y==a.sourceAfter.y&&a.sourceBefore.p==a.sourceAfter.p&&a.sourceBefore.h==a.sourceAfter.h,"noNativeCarrierExchange");
  std::ofstream f(std::string(name)+"_ledger.json");f<<"{\\"before\\":";a.before.write(f);f<<",\\"after\\":";a.after.write(f);f<<",\\"sourceBefore\\":";a.sourceBefore.write(f);f<<",\\"sourceAfter\\":";a.sourceAfter.write(f);f<<"}\\n";
 };
 o2::Audit rollback("rollback");tx.beginTrial();install(rollback);query(*tx.trial().cloud,1e-8);ledger(rollback,"O1_conservative");
 check(rollback.internalMerges==1&&rollback.zeroDeletes==1,"O1PositiveResidualMergedThenExactZeroBookkeepingDelete");
 const auto rejected=o2::canonical(*tx.trial().cloud);
 check(before==m8a3bt3::cloudDump(tx.cloud())&&carrier==view.snapshot()&&gen==view.token.generation,"committedSentinelBeforeDiscard");
 tx.discard();check(before==m8a3bt3::cloudDump(tx.cloud())&&carrier==view.snapshot(),"rollbackParticipantsCarrierAndRNGLogicalState");
 check(Foam::particle::particleCount_==id&&mesh.Foam::objectRegistry::size()==registry,"rollbackAllocatorRegistry");
 for(unsigned i=0;i<q.size();++i)check(exactCellEqual(q[i],tx.accepted().q[i]),"rollbackQBits");
 o2::Audit commit("accepted");tx.beginTrial();install(commit);query(*tx.trial().cloud,1e-8);ledger(commit,"accepted");
 check(o2::canonical(*tx.trial().cloud)==rejected,"discardThenIdenticalConservativeEventDeterministic");
 tx.prepareCommit();tx.publishCommitNoFail();check(view.token.generation==gen+1,"onePassiveAcceptedEventPublication");
 check(o2::canonical(tx.cloud())==rejected,"acceptedParcelPopulationEqualsPreparedEvent");
 for(unsigned i=0;i<q.size();++i)check(exactCellEqual(q[i],tx.accepted().q[i]),"acceptedInternalCollisionQUnchanged");
 const auto committed=m8a3bt3::cloudDump(tx.cloud()),carrierAccepted=view.snapshot();
 o2::Audit future("future"),reference("future_reference");tx.beginTrial();install(future);
 {o2::Cloud direct("roleA",tx.cloud(),slg,reference);query(*tx.trial().cloud,1e-8);query(direct,1e-8);check(o2::canonical(direct)==o2::canonical(*tx.trial().cloud),"nextCollisionQueryMatchesIndependentAcceptedCopy");}
 ledger(future,"future");tx.discard();check(committed==m8a3bt3::cloudDump(tx.cloud())&&carrierAccepted==view.snapshot(),"futureQueryTrialDoesNotMutateCommitted");
 // New seeds are branch-only diagnostics, inside independent T3A trials.
 auto seed=[&](m8a3a::Cloud&c,double m,double d,const Foam::vector&v){auto*p=new Foam::basicSprayParcel(mesh,mesh.C()[cell],cell);c.setParcelThermoProperties(*p,1e-8);p->T()=300;p->Y()=Foam::scalarField(1,1);p->rho()=c.composition().liquids().rho(3e6,300,p->Y());p->d()=p->d0()=d;p->mass0()=p->mass();p->liquidCore()=0;p->KHindex()=1;p->position0()=p->position();p->U()=v;p->nParticle()=m/p->mass();c.addParticle(p);return p;};
 unsigned stressCount=0,stressMax=0;double stressMinimum=Foam::great;unsigned stressCollisions=0,stressMerges=0,grazing=0;
 const auto particleCounter=Foam::particle::particleCount_;
 for(unsigned scenario=0;scenario<10;++scenario){o2::Audit audit("scenario_"+std::to_string(scenario));tx.beginTrial();install(audit);auto&c=*tx.trial().cloud;c.clear();
  if(scenario==0){seed(c,5e-14,1e-6,Foam::vector(0,0,0));seed(c,8e-14,7e-7,Foam::vector(0,0,0));query(c,1e-6);check(audit.collisions==0,"ordinaryNoCollisionAtZeroRelativeSpeed");}
  if(scenario==1){seed(c,5e-14,1e-6,Foam::vector(300,0,0));seed(c,8e-14,7e-7,Foam::vector(-300,0,0));for(unsigned i=0;i<8&&!audit.grazing;++i)query(c,1e-6);check(audit.grazing>0,"nativeGrazingDecisionReachedWithoutCoefficientChange");grazing=audit.grazing;}
  if(scenario==2){seed(c,0,1e-6,Foam::vector(0,0,0));query(c,1e-8);check(c.size()==0&&audit.zeroDeletes==1,"exactZeroInventoryBookkeepingDelete");}
  if(scenario==3){seed(c,5e-16,1e-6,Foam::vector(0,0,0));query(c,1e-8);check(c.size()==1&&audit.orphanRetained==1,"positiveOrphanPreservedWithoutUnrelatedMerge");}
  if(scenario==4){
   for(unsigned i=0;i<16;++i)seed(c,5e-14,1e-6+i*5e-8,Foam::vector(i%2?30:-30,0,0));stressMax=c.size();
   for(unsigned i=0;i<1000;++i){query(c,1e-6);ledger(audit,("stress_last").c_str());stressMax=std::max(stressMax,unsigned(c.size()));for(auto it=c.begin();it!=c.end();++it)stressMinimum=std::min(stressMinimum,it().nParticle()*it().mass());}
   stressCount=c.size();stressCollisions=audit.collisions;stressMerges=audit.internalMerges;check(stressMax==16&&stressCount<=16,"noParcelCountExplosion");
  }
  if(scenario==5){
   seed(c,5e-14,1e-6,Foam::vector(2,0,0));seed(c,8e-14,1e-6,Foam::vector(-2,0,0));o2::Audit reverseAudit("reordered");o2::Cloud reversed("roleA",c,slg,reverseAudit);
   std::vector<std::unique_ptr<Foam::basicSprayParcel>>copies;for(auto it=reversed.begin();it!=reversed.end();++it)copies.emplace_back(new Foam::basicSprayParcel(it()));reversed.clear();for(auto it=copies.rbegin();it!=copies.rend();++it)reversed.addParticle(new Foam::basicSprayParcel(**it));
   for(unsigned i=0;i<16;++i){query(c,1e-6);query(reversed,1e-6);}check(o2::canonical(c)==o2::canonical(reversed),"identityTieAndPairScheduleIndependentOfContainerOrder");
  }
  if(scenario==6){std::istringstream lines(frozen);std::string line;while(std::getline(lines,line)){if(!line.empty()&&line.back()=='\\r')line.pop_back();Foam::IStringStream is(line);c.addParticle(new Foam::basicSprayParcel(mesh,is,true));}auto rng=m8a3a::randomSequence(c.rndGen());bool refused=false;try{query(c,1e-8);}catch(const std::runtime_error&x){refused=std::string(x.what())=="OROURKE_DUPLICATE_IDENTITY";}check(refused&&rng==m8a3a::randomSequence(c.rndGen())&&audit.updates==0,"historicalDuplicateIdentityRejectedBeforeMutationOrRNG");}
  if(scenario==7){
   std::istringstream lines(frozen);std::string line,exactPair;while(std::getline(lines,line)){if(!line.empty()&&line.back()=='\\r')line.pop_back();Foam::IStringStream is(line);auto p=std::unique_ptr<Foam::basicSprayParcel>(new Foam::basicSprayParcel(mesh,is,true));if(p->cell()==label(cell)){exactPair+=line+'\\n';c.addParticle(p.release());}}
   check(c.size()==2&&m8a3bt3::parcelDump(c)==exactPair,"exactO1AffectedEventAllFieldsIncludingIdentities");
   check(bool(entry.pairRng),"RNGCapturedAtActualOrdinaryNativePairEntry");c.rndGen()=*entry.pairRng;query(c,1e-8);
   check(audit.internalMerges==1&&audit.zeroDeletes==1,"exactFrozenO1ParticipantReplayConservativeMerge");
  }
  if(scenario==8){seed(c,5e-14,1e-6,Foam::vector(1e8,0,0));seed(c,8e-14,7e-7,Foam::vector(-1e8,0,0));bool refused=false;try{query(c,1e-6);}catch(const std::runtime_error&x){refused=std::string(x.what()).find("OROURKE_ENERGY_UNBRACKETED")==0||std::string(x.what())=="OROURKE_CALORIC_NONMONOTONE";}check(refused,"caloricDomainOverflowRejectedWithoutTemperatureClipping");}
  if(scenario==9){bool refused=false;try{c.stochasticCollision().clone();}catch(const std::logic_error&x){refused=std::string(x.what())=="OROURKE_POLICY_CLONE_REQUIRES_FRESH_OWNER_FACTORY";}check(refused,"nativeAliasingOrPolicyLosingCloneRejected");}
  if(scenario!=6&&scenario!=8&&scenario!=9)ledger(audit,("scenario_"+std::to_string(scenario)).c_str());tx.discard();Foam::particle::particleCount_=particleCounter;
  check(committed==m8a3bt3::cloudDump(tx.cloud())&&carrierAccepted==view.snapshot(),"stressScenarioCommittedStateUnchanged");
 }
 std::ofstream result("test_results.json");result<<std::setprecision(17)<<"{\\"state\\":\\""<<state<<"\\",\\"checks\\":"<<checks<<",\\"failures\\":"<<failures<<",\\"nativeEntryByteIdentical\\":true,\\"nativeConservationDefectRetained\\":true,\\"rollback\\":true,\\"acceptedCommits\\":1,\\"acceptedSpotScope\\":\\"passive internal collision event only; not full T3B coupled retry\\",\\"nextCollisionQuery\\":true,\\"O1InternalMerges\\":"<<commit.internalMerges<<",\\"thermalRoots\\":"<<commit.roots<<",\\"grazing\\":"<<grazing<<",\\"stressUpdates\\":1000,\\"stressMaximumParcels\\":"<<stressMax<<",\\"stressFinalParcels\\":"<<stressCount<<",\\"stressMinimumMass\\":"<<stressMinimum<<",\\"stressCollisions\\":"<<stressCollisions<<",\\"stressInternalMerges\\":"<<stressMerges<<",\\"activeSolverImpact\\":\\"NONE\\",\\"noCFD\\":true}\\n";
 return failures?1:0;
}
'''
s=s.replace('("stress_last").c_str()', '"stress_last"')
s=s.replace('nativeEntryByteIdentical\\":true,','nativeEntryByteIdentical\\":"<<(exactNativeEntry?"true":"false")<<",\\"physicalEntryExact\\":"<<(exactPhysicalEntry?"true":"false")<<",\\"historicalDuplicateIds\\":"<<historicalDuplicateIds<<",\\"historicalIdentityChanges\\":"<<historicalIdentityChanges<<",')
(b/'tests/fiveEqORourkeConservative/testFiveEqORourkeConservative.C').write_text(s)
