from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/integration/m6b0_serial_active_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
g=json.loads((s/'M6B0_gate.json').read_text());assert g['status']=='COMPLETE' and not g['failed']
assert len(__import__('re').findall(r'^# \d+\.',(b/'M6B0_SERIAL_ACTIVE_FIVEEQ_REPORT_v1.md').read_text(),__import__('re').M))==40
archive=root/'checkpoints/M6B0_SERIAL_ACTIVE_FIVEEQ_COMPLETE_v1.zip';assert not archive.exists()
files=[p for p in s.rglob('*') if p.is_file() and p.name not in ['checkpoint_seal.json','frozen_after.json']]
files += [b/'M6B0_ACTIVE_AUTHORITY_AUDIT_v1.md',b/'M6B0_SERIAL_ACTIVE_FIVEEQ_REPORT_v1.md',b/'MILESTONE_STATUS.md']
files += list((b/'serialFiveEq').glob('*')) + list((b/'tools').glob('m6b0_*.py'))
manifest={p.relative_to(root).as_posix():sha(p) for p in sorted(set(files)) if p.is_file()}
manifestFile=s/'checkpoint_contents.json';manifestFile.write_text(json.dumps({'files':manifest,'status':'COMPLETE','scope':g['scope'],'executableSHA256':g['executableSHA256'],'priorFrozenAuthority':{'path':'checkpoints/M8A3B_T4_S2_FINAL_SEAL_COMPLETE_FROZEN_v1.zip','sha256':'3342871bd57cd188c0dbda5602c19debb9e983c38a3ff7fa5bc0a8f740981b97'}},indent=2))
manifest[manifestFile.relative_to(root).as_posix()]=sha(manifestFile)
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel in manifest:z.write(root/rel,rel)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for rel,v in manifest.items():assert hashlib.sha256(z.read(rel)).hexdigest()==v,rel
seal={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(manifest),'CRC':'PASS','perFileSHA256':'PASS','status':'COMPLETE','gateChecks':len(g['checks']),'failed':[]}
(s/'checkpoint_seal.json').write_text(json.dumps(seal,indent=2))
after=json.loads((s/'protected_before.json').read_text())
for rel in list(after):after[rel]=sha(root/rel)
for p in list(s.rglob('*'))+list((b/'serialFiveEq').rglob('*'))+list((b/'Make').rglob('*'))+list((b/'tools').glob('m6b0_*.py'))+[b/'M6B0_ACTIVE_AUTHORITY_AUDIT_v1.md',b/'M6B0_SERIAL_ACTIVE_FIVEEQ_REPORT_v1.md',archive]:
 if p.is_file() and p!=s/'frozen_after.json':after[p.relative_to(root).as_posix()]=sha(p)
(s/'frozen_after.json').write_text(json.dumps(after,indent=2))
print(json.dumps(seal,indent=2));print('Frozen entries',len(after))
