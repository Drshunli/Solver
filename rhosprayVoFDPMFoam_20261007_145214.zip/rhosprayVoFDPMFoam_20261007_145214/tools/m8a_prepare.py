from pathlib import Path
import hashlib,json,shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a_v1';e.mkdir(parents=True,exist_ok=True)
files={}
for p in b.rglob('*'):
 if 'lnInclude' in p.parts or 'm8a_v1' in p.parts or 'linux64Gcc' in str(p):continue
 if p.is_file() and (p.suffix in ('.C','.H','.md','.json','.csv','.py','.sh') or p.name in ('files','options')) and not p.name.startswith('m8a_'):files[str(p.relative_to(b))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in (b.parent/'300_2D').rglob('*'):
 if p.is_file():files[str(p.relative_to(b.parent))]=hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_bytes(json.dumps(files,indent=2).encode())
tol={'mass_relative':1e-12,'mass_absolute_kg':1e-30,'momentum_relative':1e-12,'momentum_absolute_kg_m_s':1e-25,'energy_relative':1e-12,'energy_absolute_J':1e-20,'field_rounding_budget':'128*epsilon*sum(abs(before),abs(after),abs(increment))','recovery':'UNCHANGED; energyRelativeTol2e-12, final4*tol; pressure compatibility1e-8','policy':'Frozen before source tests; distinguish native-model defects from conversion roundoff; no post-test relaxation'}
(e/'FROZEN_TOLERANCES.json').write_bytes(json.dumps(tol,indent=2).encode())
root='/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src/'
paths=[]
for layer in ('Kinematic','Thermo','Reacting','Spray'):
 pref='lagrangian/'+('spray' if layer=='Spray' else 'intermediate')
 for kind in ('parcels','clouds'):
  name=layer+('Parcel' if kind=='parcels' else 'Cloud')
  for ext in ('.H','.C','I.H'):paths.append(f'{pref}/{kind}/Templates/{name}/{name}{ext}')
paths += ['lagrangian/intermediate/submodels/Reacting/CompositionModel/CompositionModel/CompositionModel.C','lagrangian/intermediate/submodels/Reacting/PhaseChangeModel/LiquidEvaporation/LiquidEvaporation.C','lagrangian/intermediate/submodels/Reacting/PhaseChangeModel/LiquidEvaporationBoil/LiquidEvaporationBoil.C','lagrangian/intermediate/submodels/Kinematic/ParticleForces/Drag/SphereDrag/SphereDragForce.C','lagrangian/intermediate/submodels/Thermodynamic/HeatTransferModel/RanzMarshall/RanzMarshall.C','thermophysicalModels/thermophysicalProperties/liquidProperties/C10H22/C10H22.C','thermophysicalModels/thermophysicalProperties/liquidProperties/liquidProperties/liquidPropertiesI.H']
s='#!/bin/bash\nset -e\n'
for p in paths:
 q=e/'source_audit'/p;q.parent.mkdir(parents=True,exist_ok=True);s+=f'cp {root}{p} /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a_v1/source_audit/{p}\n'
(e/'capture_sources.sh').write_bytes(s.encode())
print('protected',len(files),'tolerances frozen')
