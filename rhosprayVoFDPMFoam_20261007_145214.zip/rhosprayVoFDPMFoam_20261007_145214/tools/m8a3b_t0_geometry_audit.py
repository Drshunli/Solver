"""Read-only actual-case audit. No mesher, solver, interpolation or EOS run."""
from pathlib import Path
import re,gzip,json,hashlib,math
b=Path(__file__).resolve().parents[1];case=b.parent/'300_2D'
out=b/'fitting/dpm/m8a3b_t0_v1'
if out.exists():raise SystemExit('Refusing to overwrite historical evidence')
out.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()}
(out/'case_before.json').write_text(json.dumps(before,indent=2))
active={p.relative_to(b).as_posix():sha(p) for p in list(b.glob('*.H'))+list(b.glob('*.C'))+list((b/'Make').glob('*')) if p.is_file()}
(out/'active_before.json').write_text(json.dumps(active,indent=2))
def read(p):
    p=Path(p)
    return (gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()).decode('utf8')
def clean(s):return re.sub(r'//[^\n]*|/\*.*?\*/','',s,flags=re.S)
def body(name):
    s=clean(read(case/'constant/polyMesh'/(name+'.gz')))
    assert 'format      ascii;' in s
    s=s[s.index('}')+1:]
    m=re.match(r'\s*(\d+)\s*\((.*)\)\s*$',s,re.S)
    assert m,name
    return int(m[1]),m[2]
np,ps=body('points');points=[tuple(map(float,x.split())) for x in re.findall(r'\(([^()]*)\)',ps)];assert len(points)==np
nf,fs=body('faces');faces=[]
for size,vs in re.findall(r'(\d+)\(([^()]*)\)',fs):
    ids=list(map(int,vs.split()));assert len(ids)==int(size);faces.append(ids)
assert len(faces)==nf
_,o=body('owner');owner=list(map(int,o.split()));ni,n=body('neighbour');neighbour=list(map(int,n.split()));assert len(owner)==nf and len(neighbour)==ni
nc=max(owner)+1;cellPoints=[set() for _ in range(nc)]
for i,f in enumerate(faces):
    cellPoints[owner[i]].update(f)
    if i<ni:cellPoints[neighbour[i]].update(f)
def bounds(ids):return [[min(points[i][a] for i in ids),max(points[i][a] for i in ids)] for a in range(3)]
def minus(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def faceGeometry(ids):
    vertices=[points[i] for i in ids];v0=vertices[0];av=[0.,0.,0.];weighted=[0.,0.,0.];area=0.
    for i in range(1,len(vertices)-1):
        c=cross(minus(vertices[i],v0),minus(vertices[i+1],v0));mag=math.sqrt(sum(x*x for x in c))/2
        for a in range(3):av[a]+=c[a]/2;weighted[a]+=mag*(v0[a]+vertices[i][a]+vertices[i+1][a])/3
        area+=mag
    return area,av,[x/area for x in weighted]
boundary=clean(read(case/'constant/polyMesh/boundary'));patches=[]
for name,t,count,start in re.findall(r'(\w+)\s*\{\s*type\s+(\w+)\s*;(?:[^{}]*?)nFaces\s+(\d+)\s*;\s*startFace\s+(\d+)\s*;',boundary):
    count,start=int(count),int(start);ids=set();area=0.;av=[0.,0.,0.];centroid=[0.,0.,0.];normalClasses=set()
    for f in faces[start:start+count]:
        ids.update(f);a,v,c=faceGeometry(f);area+=a
        for k in range(3):av[k]+=v[k];centroid[k]+=a*c[k]
        normalClasses.add(tuple(round(x/a,12) for x in v))
    patches.append({'name':name,'type':t,'faces':count,'startFace':start,'bounds_m':bounds(ids),'area_m2':area,'areaWeightedCenter_m':[x/area for x in centroid],'faceOutwardNormals':sorted(normalClasses),'summedAreaVector_m2':av})
assert len(patches)==5 and sum(p['faces'] for p in patches)==nf-ni
assert (nc,np,nf,ni)==(21000,42622,84310,41690)
checks=['actual compressed ASCII mesh counts','boundary faces cover mesh boundary','five boundary patches parsed']
position=(.015,5e-6,.015);candidates=[]
for c,ids in enumerate(cellPoints):
    bb=bounds(ids)
    if all(lo-1e-13<=x<=hi+1e-13 for x,(lo,hi) in zip(position,bb)):candidates.append({'cell':c,'bounds_m':bb})
assert {c['cell'] for c in candidates}=={1514,1515};checks.append('point lies on x-face between cells 1514 and 1515')
legacy=read(case/'constant/sprayCloudProperties');cleanLegacy=clean(legacy)
def scalar(key):return float(re.search(r'\b'+key+r'\s+([\d.eE+-]+)\s*;',cleanLegacy)[1])
outer=scalar('dOuter');mass=scalar('massTotal');duration=scalar('duration');oldArea=math.pi*outer**2/4
assert abs(oldArea/(.0003*.00005)-1)<1e-8;checks.append('legacy DPM equivalent-area comment agrees with dOuter')
for p in (case/'0').iterdir():
    if p.is_file():read(p) # inspect all BC/initial-field input as text
initial={p.name:re.search(r'\binternalField\s+([^;]+);',clean(read(p)))[1].strip() for p in (case/'0').iterdir() if p.is_file()}
dicts={name:(case/'system'/name).exists() or (case/'constant'/name).exists() for name in ('blockMeshDict','snappyHexMeshDict','setFieldsDict','topoSetDict','createPatchDict')}
setContents={p.name:read(p) for p in (case/'constant/polyMesh/sets').iterdir() if p.is_file()}
(out/'mesh_set_contents.json').write_text(json.dumps(setContents,indent=2))
assert initial['theta']=='uniform 0' and initial['C10H22']=='uniform 0';checks.append('initial theta and gas fuel species are zero')
assert not any(p.name.startswith(('alphaL','alphaG','rho','mG','mL','P2')) for p in (case/'0').iterdir());checks.append('no Eulerian phase fraction or fiveEq material initial fields')
result={'status':'PARTIAL / 2D_INJECTION_MAPPING_BLOCKER','mesh':{'cells':nc,'points':np,'faces':nf,'internalFaces':ni,'bounds_m':bounds(range(np)),'extrusionDepth_m':.00005,'coordinatePlane':'x-y','patches':patches},
 'relatedDictionariesPresent':dicts,'initialFields':initial,'initialTopologyContract':{'name':'INITIAL_TOPOLOGY_V1','interior':'gas','interiorLiquidColumnLength_m':0,'basis':'legacy perfect-gas carrier, theta=0, no Eulerian liquid initialization','implementedFiveEqP2Field':False,'futureLiquidEntry':'Eulerian liquid inlet ONLY; patch unresolved'},
 'nozzle':{'physicalDiameter_m':.0003,'numberOfHoles':1,'holeExitPatch':None,'center_m':None,'normal':None,'production2DMapping':None,'effectiveProductionArea_m2':None,'reason':'bottomWall is continuous noSlip wall; no distinct Eulerian liquid patch or frozen physical-to-2D mass mapping'},
 'massFlow':{'physicalTarget_kg_s':1.09609e-4,'TL_K':300,'referencePressure_Pa':3e6,'pressureControl':'mechanically responding; reference pressure is not independent Dirichlet','productionIntegratedBoundaryFluxVerified':False,'physicalCircleArea_m2':math.pi*.0003**2/4},
 'legacyDPMMapping':{'status':'LEGACY TEST-ONLY EVIDENCE, NOT PRODUCTION MAPPING','commentSlotWidth_m':.0003,'actualExtrusionDepth_m':.00005,'commentSlotArea_m2':.0003*.00005,'dOuter_m':outer,'dOuterArea_m2':oldArea,'slotToCircleAreaRatio':oldArea/(math.pi*.0003**2/4),'massTotal_kg':mass,'duration_s':duration,'averageNativeMassFlow_kg_s':mass/duration,'ratioToPhysicalTarget':mass/duration/1.09609e-4},
 'testDPMInlet':{'classification':'TEST_DPM_INLET','position_m':position,'nativeContainingCellFromFrozenScan':1514,'frozenScanEvidence':'m8a3b_v1/test_results.json; same case bytes','geometricTouchingCells':candidates,'distanceToBottomWall_m':5e-6,'distancesToEmptyPlanes_m':[25e-6,25e-6],'directionFromActualDPMConfig':[0,1,0],'distanceToHoleCenter_m':None,'relationToEulerianInlet':'UNDEFINED; no Eulerian nozzle patch','productionPhysicalMassBudget':'EXCLUDED'},
 'ownershipContract':{'productionNozzleMassOwner':'Eulerian VOF/fiveEq inlet','independentDPMNozzleDefault':'OFF IN FUTURE PRODUCTION ONLY; existing case unchanged','separateDPMSource':'requires explicit separate physical source','futureDPMPopulation':'later VOF-to-DPM milestone, not implemented','antiDoubleInjection':'same physical mass cannot enter through both Eulerian nozzle and independent DPM injector'},
 'stressTopologies':{'status':'NOT CREATED / MAPPING BLOCKER','requested_L_over_D':[1,2,5,10],'traceBufferCells':[1,2,3],'origin':'requires actual hole-exit patch','footprint':'requires approved 2D mapping','physicalInitialCondition':False},
 'fullSupportScanRerun':False,'transactionWorkResumed':False,'M6B0':'BLOCKED','M6B1':'NO','noCFD':True,'checks':checks,'failures':0}
after={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()}
assert before==after;assert all(sha(b/name)==h for name,h in active.items());result['caseUnchanged']=True;result['activeUnchanged']=True
(out/'audit.json').write_text(json.dumps(result,indent=2));(out/'case_after.json').write_text(json.dumps(after,indent=2))
print(json.dumps({'status':result['status'],'checks':len(checks),'failures':0,'patches':patches,'legacyDPMMapping':result['legacyDPMMapping'],'point':result['testDPMInlet']},indent=2))
