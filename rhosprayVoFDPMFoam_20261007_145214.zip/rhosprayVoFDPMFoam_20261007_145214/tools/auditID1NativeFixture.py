"""Read-only audit of isolated OF7-native ID1 fixture certificates."""
import json,csv,sys,subprocess
from pathlib import Path
s=Path(sys.argv[1]);cases=sorted((s/'accepted_stress').glob('case_*'));assert len(cases)==100
births=0;rankBirths={0:0,1:0};migratedBirths=0;transferSequences=0;stableSteps=0;multigeneration=False
for case in cases:
 assert (case/'exit.txt').read_text().strip()=='0'
 events=[]
 for p in case.glob('birth.rank*.csv'):
  for row in csv.reader(p.open()):
   parentProc,parentId,birthProc,birthId,before,after=map(int,row);assert after==before+1 and birthId==before
   events.append((parentProc,parentId,birthProc,birthId));rankBirths[birthProc]+=1
   if birthProc==1 and parentProc==0:migratedBirths+=1
   if (parentProc,parentId)!=(0,0):multigeneration=True
 births+=len(events)
 groups={}
 for q in case.glob('processor*/R1_trajectory.csv'):
  for row in csv.reader(q.open()):groups.setdefault((row[0],row[1]),[]).append(tuple(map(int,row[3:5])))
 assert len(groups)==10
 for pairs in groups.values():assert len(pairs)==len(set(pairs))
 stableSteps+=len(groups)
 parentReceived=False;childTransferred=False
 for q in case.glob('processor*/R1_boundary.csv'):
  for row in csv.reader(q.open()):
   if row[1]=='RECEIVE_AFTER_CORRECT':
    if row[3:5]==['0','0']:parentReceived=True
    if row[3:5]==['0','1']:childTransferred=True
 assert parentReceived and childTransferred
 transferSequences+=1
 for q in case.glob('processor*/native_crossing_result.json'):assert json.loads(q.read_text())['globalFailures']==0
 for q in case.glob('processor*/ID1_local_acceptance.json'):
  x=json.loads(q.read_text());assert x['localPublication'] and x['publications']==1 and not x['globalMPITransactionCertified']
for rank in ['processor0','processor1']:
 assert (s/'accepted_direct'/rank/'ID1_local_accepted.bin').read_bytes()==(s/'accepted_retry'/rank/'ID1_local_accepted.bin').read_bytes()
 rollback=list(csv.reader((s/'accepted_retry'/rank/'ID1_allocator.csv').open()))
 before=int(next(x[2]for x in rollback if x[0]=='0' and x[1]=='before'));restored=int(next(x[2]for x in rollback if x[0]=='0' and x[1]=='afterDiscard'));assert before==restored
 old=list(csv.reader((s/'accepted_retry'/rank/'N1_discard.csv').open()));assert old[0][1]=='1' and old[0][2]=='0'
r={'cases':100,'locallyAcceptedBirths':births,'rankBirths':rankBirths,'migratedParentBirths':migratedBirths,'migrationBirthSequences':transferSequences,'stableNativeSteps':stableSteps,'fullPairUniqueness':True,'nativeAllocatorStep':True,'directRetryFullAcceptedStateEquality':True,'normalRejectedAllocatorRestore':True,'sourceBornChildNativeTransfer':True,'multiGeneration':'REACHED'if multigeneration else 'NOT REACHED NATURALLY','globalMPITransactionCertified':False,'scope':'100 independent fixed-mesh two-rank successful local publications; not production global transaction closure'}
(s/'identity_acceptance_audit.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
