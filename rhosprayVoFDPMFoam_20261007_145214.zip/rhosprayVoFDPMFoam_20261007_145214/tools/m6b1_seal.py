from pathlib import Path
import json,hashlib,zipfile,re,os
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/integration/m6b1_serial_dynamics_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
g=json.loads((s/'final_gate_status.json').read_text());assert g['status']=='PARTIAL / STOP' and g['normalExitRuns']==15
assert len(re.findall(r'^## \d+\.',(b/'M6B1_SERIAL_EULERIAN_DYNAMICS_REPORT_v1.md').read_text(),re.M))==41
baseline=json.loads((s/'protected_before.json').read_text())
allowed={f'rhosprayVoFDPMFoam/serialFiveEq/{x}' for x in ['runSerialFiveEq.C','recoveryObservation.C','recoveryObservation.H']}
allowed.update(f'rhosprayVoFDPMFoam/Make/linux64GccDPInt32Opt/serialFiveEq/{x}.o' for x in ['runSerialFiveEq','recoveryObservation'])
allowed.add('rhosprayVoFDPMFoam/MILESTONE_STATUS.md')
changed=[];after={}
for rel,v in baseline.items():
 now=sha(root/rel);after[rel]=now
 if now!=v:changed.append(rel);assert rel.replace('\\','/') in allowed,rel
assert len(changed)==6,changed
for file,n in [('foundation_verification.txt',6717),('foundation_parcel_verification.txt',19)]:
 lines=(s/file).read_text().splitlines();oks=[x for x in lines if x.endswith(': OK')]
 assert len(oks)==n and not any('FAILED' in x for x in lines),(file,len(oks))
assert not json.loads((s/'production_verification.json').read_text())['mismatches']
parent=root/'checkpoints/M6B0_SERIAL_ACTIVE_FIVEEQ_COMPLETE_v1.zip';parentSHA=sha(parent)
assert parentSHA=='6a09213343d33386bd91fa980961b7d4637e08a803207530f3d2ec1173118f94'
(s/'final_protected_verification.json').write_text(json.dumps({'checked':len(baseline),'allowedChanges':changed,'unexpectedChanges':[],'frozenNumericalCore':'UNCHANGED','historyAppend':'AUTHORIZED','parentCheckpointSHA256':parentSHA},indent=2))
files=[p for p in s.rglob('*') if p.is_file() and p.name not in ['checkpoint_seal.json','frozen_after.json','checkpoint_contents.json']]
files.extend([b/'M6B1_SERIAL_EULERIAN_DYNAMICS_REPORT_v1.md',b/'MILESTONE_STATUS.md'])
files.extend(p for p in (b/'serialFiveEq').glob('*') if p.is_file())
files.extend((b/'tools').glob('m6b1_*.py'))
for sub in ['tests/fiveEqDynamicInitial','tests/fiveEqDynamicSnapshot']:
 for wd,dirs,names in os.walk(b/sub):
  dirs[:]=[x for x in dirs if x!='lnInclude']
  files.extend(Path(wd)/x for x in names)
manifest={p.relative_to(root).as_posix():sha(p) for p in sorted(set(files)) if p.is_file()}
contents=s/'checkpoint_contents.json';contents.write_text(json.dumps({'status':'PARTIAL / STOP','noFurtherSolverExecution':True,'files':manifest,'parentCheckpointSHA256':parentSHA,'executableSHA256':sha(s/'runtime/rhosprayVoFDPMFoam'),'incompleteArtifacts':['shockInterface_100/accepted_steps.csv incomplete tail','shockInterface_100/snapshot_6760.csv partial 50 rows','shockInterface_100/latest.csv possibly partial; use snapshot_6750.csv','shockInterface_100 missing destructor dynamic_summary.json']},indent=2))
manifest[contents.relative_to(root).as_posix()]=sha(contents)
archive=root/'checkpoints/M6B1_SERIAL_EULERIAN_DYNAMICS_PARTIAL_STOP_v1.zip';assert not archive.exists(),archive
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel in manifest:z.write(root/rel,rel)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for rel,v in manifest.items():assert hashlib.sha256(z.read(rel)).hexdigest()==v,rel
seal={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(manifest),'CRC':'PASS','perFileSHA256':'PASS','status':'PARTIAL / STOP','parentCheckpointSHA256':parentSHA}
(s/'checkpoint_seal.json').write_text(json.dumps(seal,indent=2))
for p in set(files+[contents,s/'checkpoint_seal.json',archive]):
 if p.is_file():after[p.relative_to(root).as_posix()]=sha(p)
(s/'frozen_after.json').write_text(json.dumps(after,indent=2))
print(json.dumps(seal,indent=2));print('Frozen entries',len(after),'Baseline checked',len(baseline))
