from pathlib import Path
import json,hashlib,zipfile,csv
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3a_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
states={};artifacts={};retained={}
for state in ('A','B','C'):
 p=e/state;r=json.loads((p/'test_results.json').read_text())
 assert r['failures']==0 and r['lifecycleCycles']==1000 and r['futureSteps']==10 and r['randomRenewals']>=10
 for key in ('dragCalls','atomizationCalls','breakupCalls','collisionCalls','wallCalls','voidMoves'):assert r[key]>0
 for new,old in (('initial_parcels.txt',state+'_ordered_parcels.txt'),('initial_sources.txt',state+'_native_sources.txt')):
  assert sha(p/new)==sha(b/'fitting/dpm/m8a3_v1'/old),(state,new,'Historical seed changed')
 rows=list(csv.DictReader((p/'future_equivalence.csv').open()))
 assert len(rows)==10 and all(all(row[k]=='1' for k in ('parcelExact','sourceExact','modelExact','rngExact','stochasticDrawExact')) for row in rows)
 fixture=b/'tests/fiveEqDPMRebinding'/('fixture'+state)
 artifacts[state]=[f.relative_to(fixture).as_posix() for f in fixture.rglob('*') if f.is_file() and any('trialCloud' in x for x in f.relative_to(fixture).parts) and f.relative_to(fixture).as_posix()!='constant/trialCloudProperties']
 assert not artifacts[state],artifacts[state]
 retained[state]={'warmToMaximumBytes':(r['maxRSSPages']-r['warmRSSPages'])*4096,'warmToFinalBytes':(r['finalRSSPages']-r['warmRSSPages'])*4096}
 states[state]=r
energy=[]
for mode in ('zero','heat','momentum','mass','evaporation','combined','disappearance','permuted'):
 new=e/'energy_regressions'/mode;old=b/'fitting/dpm/m8a_v1'/mode;r=json.loads((new/'test_results.json').read_text());assert r['failures']==0
 same={n:sha(new/n)==sha(old/n) for n in ('golden_energy.csv','ledger.csv','test_results.json','test_failures.txt')};assert all(same.values());energy.append({**r,'byteIdentical':same})
assert sum(r['checks'] for r in energy)==9288
d=[]
for mode in ('grid_final','legacy','long','ordering','volume','cost','O0','diagnostics','subulp','boundary'):
 p=e/'D_regressions'/mode;q=b/'fitting/dpm/m8a_v1/D_regressions'/mode
 assert (p/'exit_status.txt').read_text().strip()=='0'
 r=json.loads((p/'test_results.json').read_text());assert r['failures']==0
 same={n:sha(p/n)==sha(q/n) for n in ('test_results.json','test_failures.txt') if (q/n).exists()};assert all(same.values());d.append({'directory':mode,**r,'byteIdenticalResults':same})
r=json.loads((e/'temporal/test_results.json').read_text());assert r['failures']==0 and r['checks']==9663
temporalSame={n:sha(e/'temporal'/n)==sha(b/'fitting/dpm/m8a_v1/temporal'/n) for n in ('test_results.json','test_failures.txt')};assert all(temporalSame.values())
reg={'sourceEnergy':{'checks':9288,'failures':0,'modes':energy},'P2RecoveryR1':{'reportedChecks':sum(x.get('checks',0) for x in d),'subULPStepsPerScheme':1000,'failures':0,'modes':d},'temporalRestart':{**r,'byteIdenticalResults':temporalSame}}
(e/'regression_summary.json').write_text(json.dumps(reg,indent=2))
models=('coneInjection','sphereDrag','stochasticDispersionRAS','blobsSheetAtomization','ReitzKHRT','ORourke','rebound','voidFraction')
summary={'M8A3A':'COMPLETE','scope':'selected OF7 serial basicSprayCloud accepted-step evolved reconstruction only','modelCapabilities':{n:'TRIAL-INDEPENDENT' for n in models},'fullTransactionSafe':False,'states':states,'checks':sum(r['checks'] for r in states.values()),'failures':0,'retainedMemory':retained,'trialPermanentOutputArtifacts':artifacts,'regressions':reg,'M8A3':'PARTIAL / MAY RESUME NEXT TURN','M8A':'PARTIAL','M6B0':'NO','activeImpact':'NONE','noCFD':True}
(e/'summary.json').write_text(json.dumps(summary,indent=2))
matrix='''

## M8A.3A project-local evolved independence gate (2026-10-01)

**M8A.3A COMPLETE**, restricted to eight selected Foundation 7 models and
exclusive serial accepted-step-boundary reconstruction. Fresh config/model
construction plus explicit value-state imports remove the native evolved
clone RNG/owner/properties alias counterexample. Native shallow copy remains
ineligible; historical M8A.3 blocker evidence is preserved unchanged.
A/B/C seeds match historical ordered parcels and native sources byte-for-byte.
6375 checks, zero failures: each seed has 1000 construct/minimal-evolve/destroy
cycles and 10 exact accepted future steps including actual normal RNG renewals.
All eight models TRIAL-INDEPENDENT in this gate, not FULL TRANSACTION-SAFE.
Registry/source/output independence and committed sentinels pass.
Frozen source/energy 9288, P2/recovery/R1 105775 reported checks plus subULP
1000 steps per scheme, temporal/restart 9663 pass without changed golden bytes.
M8A.3 may resume next turn; no forced retry, full support scan, cloud/Q commit
or MPI crossing is executed this round. M8A remains PARTIAL; M6B.0 NO.
Active solver/case/frozen code unchanged; no CFD. See
M8A3A_EVOLVED_INDEPENDENCE_GATE.md and M8A3A_MODEL_DEPENDENCY_GRAPH.md.
'''
milestone=b/'MILESTONE_STATUS.md';s=milestone.read_text()
if '## M8A.3A project-local evolved independence gate' not in s:milestone.write_bytes((s+matrix).encode())
before=json.loads((e/'protected_before.json').read_text());changed=[n for n,v in before.items() if not (b/n).exists() or sha(b/n)!=v]
assert set(changed)<={'MILESTONE_STATUS.md'},changed
(e/'protected_comparison.json').write_text(json.dumps({'changedSincePreparation':changed,'historicalEvidenceUnchanged':True,'frozenCodeUnchanged':True,'activeSolverImpact':'NONE'},indent=2))
report=b/'M8A3A_EVOLVED_INDEPENDENCE_GATE.md'
text='''# M8A.3A evolved independence gate — 2026-10-01

## 1. M8A.3A status

COMPLETE for the selected eight-model serial accepted-step reconstruction
contract. This is not FULL TRANSACTION-SAFE and does not authorize M6B.0.

## 2. Original reference-retention bug

Historical native clone retains owner_, properties_ and nested distribution
rndGen_ bindings. A/B/C clone injector advances committed RNG. The original
54-check counterexample and its checkpoint remain unchanged. Native clone is
still ineligible; the new route repeats the injector call using fresh models.

## 3. Transaction reconstruction architecture

Fresh named native cloud -> dictionary value import -> public cloudSolution
copy construction -> root RNG value import -> fresh cone/wall models and explicit
history import -> fresh stateless model graph -> ordered parcel copy -> source
value import. No evolved clone is evolved as trial. No raw ABI tricks are used.

## 4. Immutable-sharing policy

Only fixed mesh/patches, fixed per-call carrier/turbulence inputs, immutable
SLGThermo liquid tables and read-only time environment are shared. Lifetimes
exceed both clouds. Configuration values/Function1 objects are rebuilt.
See the member-by-member dependency graph and whitelist.

## 5. Mutable-sharing policy

Model owner/properties, root RNG, parcels, source accumulators and output data
are trial-local. Default is rejection of unknown model graphs. particleCount_
is an explicitly managed exclusive process-level resource, not cloud-local.

## 6. Root RNG architecture

Whole OF7 Random value copy/assignment preserves private generator and stored
normal state, without reseeding. Future-sequence probes use 128 alternating
normal/uniform/normal groups on copies. Actual stochastic renewal exercises
normal caching across 10 accepted steps for every seed. Committed probes never
advance the committed generator.

## 7. Model dependency graph

M8A3A_MODEL_DEPENDENCY_GRAPH.md covers nested owners, configuration, mesh,
SLGThermo, root RNG, interpolation, ordered parcel lists, occupancy and output.
Native references are sourced from the installed Foundation 7 copy saved in
fitting/dpm/m8a3a_v1/native_sources.

## 8. coneInjection adapter

OF7-coneInjection-txn-v1. A real read-only derived copy bridge exports
massInjected/time0/timeStep0/nInjections/parcelsAddedTotal. Its shallow nested
references never execute physics. A separate config constructor binds trial
owner/properties and fresh RosinRammler to trial RNG, then imports values.
Private injector cell/tet geometry is deterministically rebuilt. TRIAL-INDEPENDENT.

## 9. sphereDrag adapter

OF7-sphereDrag-txn-v1. Stateless model, fresh owner/mesh; the native constructor
uses readCoeffs=false. DragAdapter only counts then calls native calcCoupled.
No outputProperties reference exists in ParticleForce. TRIAL-INDEPENDENT.

## 10. stochasticDispersionRAS adapter

OF7-stochasticDispersionRAS-txn-v1. Fresh owner, independently reacquired native
k/epsilon cache ownership. UTurb/tTurb history resides in copied parcels; all
randomness uses trial root Random. Counter instrumentation does not change
the formula. TRIAL-INDEPENDENT.

## 11. blobsSheetAtomization adapter

OF7-blobsSheetAtomization-txn-v1. B/angle read-only config, parcel history
copied, trial RNG passed by native parcel caller. Ordinary update is counted
and forwarded unchanged. No child rollback golden is claimed. TRIAL-INDEPENDENT.

## 12. ReitzKHRT adapter

OF7-ReitzKHRT-txn-v1. Fresh coefficients and owner; all dynamic breakup history
copied with parcels. Native update ordinary path executes thousands of times.
Full child-event commit/discard is out of scope. TRIAL-INDEPENDENT.

## 13. ORourke adapter

OF7-ORourke-txn-v1. Fresh owner/RNG; liquids resolves external registry
SLGThermo tables, whose lifetime exceeds both clouds. Native collide rebuilds
ordered occupancy from trial container and executes every accepted step.
Collision golden retry remains outside this gate. TRIAL-INDEPENDENT.

## 14. rebound adapter

OF7-rebound-txn-v1. Fresh owner/properties; protected fate counters exported
by a real derived copy reader and explicitly imported. A disposable tracked
parcel hits a real wall; native owner.patchData/rebound path gives exact
reference velocity/active/keep results with unchanged committed state.
TRIAL-INDEPENDENT.

## 15. voidFraction adapter

OF7-voidFraction-txn-v1. Diagnostic-only, trial-local trialCloudTheta field.
Native preEvolve reset, trajectory dt*nParticle*volume integral and
postEvolve/(dtCarrier*V) normalization unchanged; every future step agrees
exactly with reference Theta. Actual virtual write is suppressed in trial
scope. Previous-step output is not authoritative physics history.
TRIAL-INDEPENDENT / output-isolated.

## 16. Nested ownership audit

No trial distribution, interpolation or occupancy object references committed
RNG/parcels/sources. Public cloudSolution value copy covers otherwise private
runtime state. Deleted assignment is handled by typed reconstruction of the
derived cloud's protected member before evolution. Model readers are temporary
export-only objects, never trial graph nodes. No installed class is edited.

## 17. properties_ classification

For seven CloudSubModelBase models, properties_ is mutable restart/statistics
data and is TRIAL_REBOUND_REFERENCE into trial outputProperties. Config dicts
are separate read-only values. SphereDrag has no such reference. The address
test compares dictionary subobjects, not IOdictionary most-derived addresses.

## 18. rndGen_ classification

Distribution Random& and owner RNG access are TRIAL_REBOUND_REFERENCE. Root
generator/cached normal values are MUTABLE_COPIED_STATE. Mesh/SLG tables are
the only relevant immutable shared references; no reseeding occurs.
'''
for i,state in enumerate(('A','B','C'),19):
 r=states[state];text+=f'\n## {i}. {state} evolved-copy result\n\nHistorical seed {r["seedSteps"]} steps, '+str({'A':106,'B':148,'C':190}[state])+f' parcels: original parcel/source bytes unchanged. {r["checks"]} checks, 0 failures, 1000 cycles and 10 future steps.\n'
text+='''
## 22. Committed mutation sentinel

Full ordered parcel serialization, source/coefficients, output dictionary,
injection/wall history, solution iteration/trackTime, ambient pressure,
average parcel mass, RNG future sequence and committed Theta remain unchanged
after trial construction, evolution, injector, stochastic and rebound calls.
Derived caches are rebuilt, not authoritative state. This is an accepted-step
boundary contract; asynchronous carrier/mesh mutation is excluded.

## 23. Ongoing injection equivalence

All A/B/C: 10 future steps, not merely one. IDs, injection schedule/counters,
mass, positions/U/d/T and all serialized parcel state agree exactly. No broad
floating tolerance is used; native evaluation order is unchanged. Precision-17
serialization is deterministic and round-trip identifies finite doubles; this
is not a raw-memory comparison including padding.

## 24. Stochastic multi-step equivalence

Each seed has 10 real stochastic renewals using an evolved parcel's cell/U
inputs and a local expired turbulence-clock stimulus after the accepted step.
The stimulus operates on disposable UTurb/tTurb values, advances reference and
trial RNG equally, and does not overwrite evolved parcel history. Ordinary
tracking also invokes dispersion thousands of times. No seed-only proof.

## 25. Source accumulator isolation

Independent source object addresses and exact transfer/coefficients after
every step. Committed source sentinel does not change during trial operations.
Frozen ledger/adapter formulas are unmodified. Full source/Q commit not done.

## 26. ObjectRegistry isolation

trialCloud namespace is used for source fields/outputProperties/Theta. Model
state import copies dictionary value only. No trial permanent output artifacts
exist except the pre-created constant/trialCloudProperties configuration file.
Registry count returns to baseline every destruction cycle. Committed field
contents remain unchanged; no active production dictionary is changed.

## 27. Repeated lifecycle test

Each exact A/B/C seed: 1000 construct/evolve-minimally/destroy cycles at fixed
accepted time, dt=1e-12, restoring serial allocator afterward. 3000 total.
Committed sentinel and registry count pass every cycle. Memory sampled from
/proc/self/statm after each cycle; warm-up is first 10 cycles. Predeclared
obvious-growth bound is 5 MiB, not a formal leak proof or MPI guarantee.

## 28. Project-local overrides/wrappers

All new C++ is tests/fiveEqDPMRebinding/modelAdapters.H, outputIsolation.H and
testFiveEqDPMRebinding.C. Physics wrappers count and forward native equations.
Local method specializations suppress trial restart allocator loading and
VoidFraction/KinematicCloud file output; native postEvolve cache cleanup,
function normalization and nextIter remain intact. No installed OF7 edits,
no runtime selection replacement, no active solver changes.

## 29. Performance/memory impact

'''
text+='| Seed | 1000 cycles wall seconds | warm-to-maximum RSS bytes | warm-to-final RSS bytes |\n|---|---:|---:|---:|\n'
for state,r in states.items():text+=f'| {state} | {r["lifecycleSeconds"]:.4f} | {retained[state]["warmToMaximumBytes"]} | {retained[state]["warmToFinalBytes"]} |\n'
text+='''
These timings include filesystem/cloud config construction and logging on the
WSL/mounted workspace. They are not CFD production performance or a formal
allocator leak analysis. Resource logs retain maximum RSS and exit codes.

## 30. Frozen regression result

Source/energy 9288 checks; P2/recovery/R1 105775 reported checks plus subULP
1000 steps per scheme; temporal/restart 9663. All zero failures. Golden
energy/ledger bytes and stable regression result bytes equal frozen baseline.
Native wrapper harness compilation PASS. Initial failed compile/address-test
diagnostics are retained separately and are not counted as final gate passes.

## 31. Remaining transaction blockers

Full breakup/collision reject/discard/retry goldens, whole-mesh support scan,
combined cloud/Q atomic commit, accepted output release and real MPI crossing.
These are not implemented or tested in this round. No model is disabled.

## 32. Are all production models TRIAL-INDEPENDENT?

YES for the eight selected models under this frozen serial reconstruction
scope. No claim for other models, different configurations or active runtime.

## 33. Is M8A.3A COMPLETE?

YES: all required evolved independence gates and frozen regressions pass.
The historical shallow native-copy defect remains preserved and is bypassed
by explicit construction/import, not repaired in OF7 installation.

## 34. May M8A.3 resume?

YES, next turn only. This round stops at M8A.3A and does not resume retries.

## 35. M8A overall status

PARTIAL. TRIAL-INDEPENDENT is not FULL TRANSACTION-SAFE.

## 36. M6B.0 permission

NO. No active two-phase solver activation is authorized by this gate.

## 37. Active solver impact

NONE. Active cloud type/evolve/equations/sources/timestep, production
dictionaries, frozen thermo/P2/R1/ledger and historical reports/checkpoints
are unchanged; only MILESTONE_STATUS receives an appended new entry. No CFD.

## 38. Updated milestone matrix

| Milestone | Current status |
|---|---|
| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE |
| M8A source/energy | PASS / FROZEN |
| M8A.1 | PARTIAL |
| M8A.2 | PARTIAL |
| M8A.3 historical native-copy gate | PARTIAL / preserved MODEL_TRANSACTION_BLOCKER evidence |
| M8A.3A reconstruction independence | COMPLETE / selected serial scope |
| M8A.3 full transaction work | PARTIAL / may resume next turn |
| M8A overall | PARTIAL |
| M6B.0 | NO / BLOCKED |

STOP. No additional milestone executed.
'''
report.write_bytes(text.encode())
files=[milestone,report,b/'M8A3A_MODEL_DEPENDENCY_GRAPH.md',b/'tools/m8a3a_prepare.py',b/'tools/m8a3a_refine_harness.py',Path(__file__).resolve()]
for folder in (e,b/'tests/fiveEqDPMRebinding'):
 for p in folder.rglob('*'):
  if any(n in p.parts for n in ('lnInclude','Make','linux64GccDPInt32Opt')):continue
  if p.is_file():files.append(p)
files.extend((b/'tests/fiveEqDPMRebinding/Make'/n) for n in ('files','options'))
dest=b/'checkpoints/M8A3A_evolved_independence_v1_COMPLETE.zip'
if dest.exists():raise SystemExit('Checkpoint already exists; refusing overwrite')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):z.write(p,p.relative_to(b).as_posix())
(e/'checkpoint.sha256').write_text(sha(dest)+'  '+dest.name+'\n')
print(json.dumps({'status':'COMPLETE','checks':summary['checks'],'failures':0,'activeImpact':'NONE','checkpoint':str(dest)}))
