"""Offline audit of the one OF7 ReitzKHRT failing expression, never a runtime model."""
import argparse,json,math,sys
from decimal import Decimal,localcontext
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('failure');ap.add_argument('--output',required=True);a=ap.parse_args()
f=json.loads(Path(a.failure).read_text());v=f['nativeFailureVars'];call=f['failureCall']
get=lambda x:Decimal(x['value'])
with localcontext() as ctx:
 ctx.prec=80
 twoPi=get(f['Foam::constant::mathematical::twoPi']);crt=get(call['model']['cRT_']);krt=get(v['KRT']);small=get(f['Foam::vSmall']);maximum=Decimal.from_float(sys.float_info.max)
 denominator=krt+small;value=twoPi*crt/denominator
 result={'expression':'twoPi*cRT_/(KRT+vSmall)','nativeLine':161,'twoPi':str(twoPi),'CRT':str(crt),'KRT':str(krt),'vSmall':str(small),'denominator':str(denominator),'numerator':str(twoPi*crt),'mathematicalValue':str(value),'doubleMaximum':str(maximum),'overflowsDouble':value>maximum,'denominatorZero':denominator==0,'CRTlimitAtKRTzero':str(maximum*small/twoPi),'requiredMinimumDenominator':str(abs(twoPi*crt)/maximum),'classification':'CLASS D / FIXTURE_DOMAIN_INVALID','scope':'source-implied finite-output floating-point domain; no new physical model law'}
Path(a.output).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
