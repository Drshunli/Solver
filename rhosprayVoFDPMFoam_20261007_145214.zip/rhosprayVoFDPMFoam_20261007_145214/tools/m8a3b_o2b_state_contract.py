"""Executable design examples only; not the OF7 canonical codec or production wrapper."""
from dataclasses import dataclass
from pathlib import Path
import json,copy,hashlib
@dataclass
class Parcel:
    identity:tuple
    mass:float
    reservoir:float
    rank:int=0
def encode(ps,escaped=0.):
    ids=[p.identity for p in ps]
    if len(set(ids))!=len(ids):raise ValueError('DUPLICATE_ID')
    if any(p.mass<0 or p.reservoir<0 for p in ps):raise ValueError('INVALID_INVENTORY')
    return json.dumps({'schema':'DESIGN_ONLY_COLLISION_R_v2','parcels':[p.__dict__ for p in sorted(ps,key=lambda p:p.identity)],'escaped':escaped},sort_keys=True,separators=(',',':')).encode()
def merge(a,b,dm,ediss):
    if not 0<=dm<=b.mass:raise ValueError('INVALID_TRANSFER')
    fraction=dm/b.mass
    return Parcel(a.identity,a.mass+dm,a.reservoir+fraction*b.reservoir+ediss,a.rank),Parcel(b.identity,b.mass-dm,(1-fraction)*b.reservoir,b.rank)
def remove(p,reason):
    if reason=='escape':return p.reservoir
    if p.mass==0 and p.reservoir==0:return 0.
    raise ValueError('UNMODELED_ENERGY_SINK')
checks=0
def check(ok):
    global checks
    checks+=1;assert ok
for mass in (1e-18,1e-15,1e-12):
 for fraction in (0.,.01,.5,1.):
  for er in (0.,1e-15,8.790435474750444e-7):
   a=Parcel((0,106),mass,er);b=Parcel((0,107),mass,er);s=encode([a,b]);trial=copy.deepcopy([a,b]);x,y=merge(*trial,fraction*mass,er)
   check(abs(x.reservoir+y.reservoir-3*er)<=1e-30+128*2**-52*6*abs(er))
   check(encode([a,b])==s) # Discard by isolated authority; no production rollback implementation.
   # Hypothetical restart decode/encode preserves proposed inventory and order.
   payload=json.loads(encode([x,y]));decoded=[Parcel(tuple(r['identity']),r['mass'],r['reservoir'],r['rank']) for r in payload['parcels']]
   check(encode(decoded)==encode([x,y]))
   check(encode([x,y])==encode([y,x]))
   # Hypothetical mass-proportional breakup partition; does not change native breakup model.
   parent=Parcel(x.identity,.75*x.mass,.75*x.reservoir);child=Parcel((1,5),.25*x.mass,.25*x.reservoir)
   check(parent.reservoir+child.reservoir==x.reservoir)
   migrated=copy.deepcopy(x);migrated.rank=1
   check(migrated.identity==x.identity and migrated.reservoir==x.reservoir)
   check(remove(x,'escape')==x.reservoir)
for reason in ('evaporation','below_minParcelMass','zero_mass_with_nonzero_R'):
 try:remove(Parcel((0,1),0.,1.),reason);assert False
 except ValueError:check(True)
try:encode([Parcel((0,1),1.,0.),Parcel((0,1),2.,0.)]);assert False
except ValueError:check(True)
out={'checks':checks,'failures':0,'classification':'EXECUTABLE_DESIGN_EXAMPLES_ONLY',
 'productionCodecImplemented':False,'physicalModelValidated':False,'actualMPIRun':False,
 'unresolved':'Mass-proportional partition, escape-flux interpretation and release physics require model approval and O2C native certification.'}
e=Path(__file__).resolve().parents[1]/'fitting/dpm/m8a3b_o2b_v1'
(e/'state_contract_examples.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
