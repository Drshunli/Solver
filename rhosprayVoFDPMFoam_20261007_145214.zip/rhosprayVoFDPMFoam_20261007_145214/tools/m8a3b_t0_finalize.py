from pathlib import Path
import hashlib,json,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t0_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
data=json.loads((e/'audit.json').read_text())
contract={k:data[k] for k in ('status','nozzle','initialTopologyContract','ownershipContract','massFlow','stressTopologies')}
contract['runtimeImplemented']=False
(e/'TOPOLOGY_AND_DPM_OWNERSHIP_CONTRACT_V1.json').write_text(json.dumps(contract,indent=2))
status=b/'MILESTONE_STATUS.md';before=e/'milestone_before.md'
if before.exists():raise SystemExit('Refusing to append twice')
before.write_bytes(status.read_bytes())
entry='''

## M8A.3B-T0 nozzle/topology/ownership audit (2026-10-01)

**PARTIAL / 2D_INJECTION_MAPPING_BLOCKER.** Actual 300_2D mesh has only
gas inlet/outlet, continuous noSlip bottom/top walls, and empty front/back;
no Eulerian liquid exit patch, center or normal can be identified.
Legacy DPM explicitly uses equivalent area (300um)*(50um)=1.5e-8m2,
but this is not a production Eulerian patch or frozen physical-to-2D mass
budget. Its massTotal/duration=5.262723452e-4kg/s differs from the physical
1.09609e-4kg/s target. No historical scaling factor is promoted.
INITIAL_TOPOLOGY_V1 contract frozen: interior gas, liquid-column L=0;
no prefilled Eulerian liquid is specified; fiveEq/P2 field not generated.
Existing DPM point is TEST_DPM_INLET, excluded from production nozzle mass
budget. Final production Eulerian inlet owns nozzle mass; independent DPM
nozzle defaults OFF in future production only, actual case remains unchanged.
Seven read-only geometry consistency checks pass. Entire actual case and
active source/Make hashes unchanged. No synthetic nozzle cores/support rerun
because mapping is blocked; no transaction continuation, CFD or M6B.
M8A.3B/M8A PARTIAL; M6B.0 BLOCKED, M6B.1 NO. See
M8A3B_T0_NOZZLE_TOPOLOGY_GATE.md and new m8a3b_t0_v1 evidence.
'''
with status.open('ab') as f:f.write(entry.encode())
# Preserve all frozen evidence and source content; milestone may only append.
old=b/'fitting/dpm/m8a3b_v1';manifest=json.loads((old/'protected_before.json').read_text())
changed=[n for n,h in manifest.items() if n!='MILESTONE_STATUS.md' and (not (b/n).exists() or sha(b/n)!=h)]
assert not changed,changed
previous=json.loads((e/'case_before.json').read_text());case=b.parent/'300_2D'
assert previous=={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()}
for n,h in json.loads((e/'active_before.json').read_text()).items():assert sha(b/n)==h,n
fixture=old/'scan_fixture'
matches=all((case/p.relative_to(fixture)).exists() and sha(case/p.relative_to(fixture))==sha(p) for p in fixture.rglob('*') if p.is_file())
assert matches
proof={'protectedUnexpectedChanges':changed,'entireCaseUnchanged':True,'activeUnchanged':True,'frozenScanFixtureMatchesActualCase':matches,'milestoneAppendOnly':status.read_bytes().startswith(before.read_bytes()),'noCFD':True}
(e/'protection_verification.json').write_text(json.dumps(proof,indent=2))
out=b/'checkpoints/M8A3B_T0_geometry_v1_PARTIAL.zip'
if out.exists():raise SystemExit('Refusing to overwrite checkpoint')
files=list(e.rglob('*'))+[b/'M8A3B_T0_NOZZLE_TOPOLOGY_GATE.md',b/'tools/m8a3b_t0_geometry_audit.py',Path(__file__),status]
files=[p for p in files if p.is_file()]
hashes={p.relative_to(b).as_posix():sha(p) for p in files}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(b).as_posix())
    z.writestr('CHECKPOINT_MANIFEST.json',json.dumps(hashes,indent=2))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
(e/'checkpoint.json').write_text(json.dumps({'path':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'status':data['status']},indent=2))
print(json.dumps(proof,indent=2));print(data['status'])
