"""Readonly offline analysis of D1 artifacts; no solver execution or repair."""
from pathlib import Path
import json,hashlib,csv,difflib
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/dpm/m8a3b_t4_s2_timeout_d1_native_v1'
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result={'classification':'CLASS C / NATIVE_MODEL_COMPUTE_EXPLOSION','status':'COMPLETE / DIAGNOSIS ONLY','cause':'Step5 enables a 4244131-parcel native cone-injection batch','runs':{},'gates':{}}
inputs=j(s/'exact_input_sha.json')
for name,folder in [('first_attempt',s),('verbose',s/'bounded_samples'),('quiet',s/'quiet_control')]:
 monitor=j(folder/'replay_monitor.json');data={'pids':monitor['pids'],'exit':int((folder/'exit.exact_replay.txt').read_text()),'elapsed':monitor['elapsed'],'cpu':monitor['cpu'],'attachments':monitor['attachments'],'loaded_library_sha':monitor['loaded_libraries'],'input_changes':[k for k,h in inputs.items() if sha(folder/'exact_replay'/k)!=h]}
 result['gates']['input_'+name]=len(inputs)==69 and not data['input_changes']
 stable=[]
 for rank in range(2):
  f=folder/f'exact_replay/processor{rank}/R1_final_stability.csv';rows=list(csv.reader(f.open()));stable.append([int(r[1]) for r in rows])
 data['stable_steps']=stable;data['step5_incomplete']=stable==[[0,1,2,3,4]]*2 and not list((folder/'exact_replay').glob('processor*/native_crossing_result.json'))
 result['gates']['exact_timeout_'+name]=data['exit']==124 and data['step5_incomplete']
 if name!='first_attempt':
  data['samples']=[]
  for label in ['20s','35s','48s']:
   for rank in range(2):
    snap=j(folder/f'snapshot.{label}.rank{rank}.json');frame=next(f for f in snap['frames'] if 'newParcels' in f);pose=snap.get('pose');parcel=snap['parcel'];record={'label':label,'rank':rank,'pid':snap['pid'],'wall':snap['timestamp'],'step':snap['step'],'newParcels':frame['newParcels'],'parcelI':frame.get('parcelI'),'inject_site':{'function':frame['function'],'file':frame['file'],'line':frame['line']},'tracking_loop':[{k:f[k] for k in f if k!='td'} for f in snap['frames'] if 'LazyKinematicParcel' in f['function'] and '::move' in f['function']],'frames':snap['frames'],'model_counters':snap['models'],'support':snap['support_counters'],'property_evaluations':sum(snap['support_counters'][k] for k in ['rho','p','T','Y','Cp','mu','kappa','U']),'parcel':parcel,'pose':pose,'cloud_owned_count':snap.get('cloud_owned_count')}
    data['samples'].append(record);result['gates'][name+label+str(rank)]=snap['step']==5 and frame['newParcels']==4244131 and all('error' not in v for v in snap['models'].values())
  for rank in range(2):
   records=[x for x in data['samples'] if x['rank']==rank];indexes=[x['parcelI'] for x in records];result['gates'][name+'injection_progress'+str(rank)]=all(a<c for a,c in zip(indexes,indexes[1:]))
 result['runs'][name]=data
# First five stable states are identical; the logging flags change no physical input.
quiet=s/'quiet_control/exact_replay';verbose=s/'bounded_samples/exact_replay';parity={}
for rank in range(2):
 for name in ['R1_trajectory.csv','R1_continuation.csv','R1_final_stability.csv','R1_boundary.csv']:
  parity[str(rank)+'/'+name]=(quiet/f'processor{rank}'/name).read_bytes()==(verbose/f'processor{rank}'/name).read_bytes()
result['prefix_parity']=parity;result['gates']['prefix_parity']=all(parity.values())
# CPU is auxiliary: MPI progress may spin, so rank1's high CPU is not compute proof.
for name in ['verbose','quiet']:
 data=result['runs'][name];data['cpu_interval_percent']=[]
 for rank in range(2):
  points=[x for x in data['cpu'] if x['rank']==rank and x['elapsed']>=19]
  for a,c in zip(points,points[1:]):data['cpu_interval_percent'].append({'rank':rank,'from':a['elapsed'],'to':c['elapsed'],'percent':(c['utime_ticks']+c['stime_ticks']-a['utime_ticks']-a['stime_ticks'])/(c['elapsed']-a['elapsed'])})
# Per-rank timeline: stable-prefix events have ordering only; stack observations have exact wall time.
for rank in range(2):
 with (s/f'RANK_PHASE_TIMELINE.rank{rank}.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['run','rank','step','wall_time','phase','evidence'])
  for step in range(5):
   for phase in ['before evolve','evolve return','post-evolve reduction']:w.writerow(['exact prefix',rank,step,'',phase,'completed stability/continuation record; ordering inferred, no exact event timestamp'])
  w.writerow(['exact prefix',rank,0,'','processor send' if rank==0 else 'processor receive','complete R1_boundary quartet'])
  for run in ['verbose','quiet']:
   for rec in result['runs'][run]['samples']:
    if rec['rank']!=rank:continue
    w.writerow([run,rank,5,rec['wall'],'native injection/model/support work' if rank==0 else 'native owner-rank reduction wait',rec['inject_site']['file']+':'+str(rec['inject_site']['line'])+'; parcelI='+str(rec['parcelI'])])
# Model/support counts at stable step4 come from the existing continuation and query records.
result['prefix_population']={'global_count':1,'per_rank':[0,1],'identity':[0,0],'min_d':7.3239929447904915e-8,'max_d':7.3239929447904915e-8,'nParticle':2545401221464.0679,'diagnostic_small_d_definition':'d < 1e-7m; descriptive only','very_small_count':1}
for rank in range(2):
 rows=list(csv.reader((verbose/f'processor{rank}/R1_continuation.csv').open()));result.setdefault('step4_model_counters',{})[rank]=rows[-1]
 # rank1 cannot sample its old parent at step5 until synchronized injection finishes.
 count=0
 with (verbose/f'processor{rank}/R1_queries.csv').open() as f:
  for row in csv.reader(f):
   if row[2]!='0':break
   count+=1
 result.setdefault('step4_preflight_log_count',{})[rank]=count
result['observer_control']={'quiet_query_bytes':[(quiet/f'processor{r}/R1_queries.csv').stat().st_size for r in range(2)],'quiet_phase_bytes':[(quiet/f'processor{r}/C1_phases.csv').stat().st_size for r in range(2)],'both_timeout':True,'CLASS_D_completion_criterion_met':False,'interpretation':'Logging consumes measurable system work, but reducing it does not close step5; raw throughput is not a clean causal benchmark because attach pauses and concurrent compilation differed.'}
result['gates']['logging_off']=all(n==0 for k in ['quiet_query_bytes','quiet_phase_bytes'] for n in result['observer_control'][k])
result['gates']['three_samples_per_rank']=all(len([x for x in result['runs'][run]['samples'] if x['rank']==rank])==3 for run in ['verbose','quiet'] for rank in range(2))
for file,count in [('installed_source_verification.txt',6717),('native_parcel_verification.txt',19)]:
 lines=(s/file).read_text().splitlines();result['gates'][file]=len(lines)==count and all(x.endswith(': OK') for x in lines)
baseline=j(s/'frozen_before.json');bad=[k for k,h in baseline.items() if not(root/k).is_file() or sha(root/k)!=h];result['protected']={'entries':len(baseline),'unexpected_changes':bad};result['gates']['frozen_project_unchanged']=not bad
# Exact diagnostic logging source delta, no production adapter modification.
new=b/'tests/fiveEqDPMTimeoutD1QuietNative';old=b/'tests/fiveEqDPMR1FinalNative'
for file in ['testNewbornIdentity.C','QueryObserver.H']:
 (s/(file.replace('.','_')+'.diff')).write_text(''.join(difflib.unified_diff((old/file).read_text().splitlines(True),(new/file).read_text().splitlines(True),fromfile='frozen/'+file,tofile='diagnostic/'+file)))
result['failed_gates']=[k for k,v in result['gates'].items() if not v]
assert not result['failed_gates'],result['failed_gates']
(s/'D1_gate.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'classification':result['classification'],'gate_count':len(result['gates']),'failed':result['failed_gates'],'protected':result['protected']},indent=2))
