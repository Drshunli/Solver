from pathlib import Path
import os,json,hashlib,shutil
b=Path(__file__).resolve().parents[1]; e=b/'fitting/dpm/m8a3a_v1'
if e.exists():raise SystemExit('Evidence directory exists; refusing overwrite')
e.mkdir(parents=True); manifest={}
for root,dirs,names in os.walk(b):
 dirs[:]=[n for n in dirs if n not in ('lnInclude','Make','linux64GccDPInt32Opt','.git','m8a3a_v1')]
 for name in names:
  p=Path(root)/name
  if p.is_symlink():continue
  try:manifest[p.relative_to(b).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
  except OSError:continue
(e/'protected_before.json').write_text(json.dumps(manifest,indent=2))
t=b/'tests/fiveEqDPMRebinding';(t/'Make').mkdir(parents=True)
for n in ('files','options'):
 (t/'Make'/n).write_bytes((b/'tests/fiveEqDPMEvolvedAudit/Make'/n).read_bytes().replace(b'testFiveEqDPMEvolvedAudit',b'testFiveEqDPMRebinding'))
for state in ('A','B','C'):
 for n in ('0','constant','system'):
  shutil.copytree(b/'tests/fiveEqDPMEvolvedAudit/fixture'/n,t/('fixture'+state)/n)
 f=t/('fixture'+state)/'constant'
 shutil.copyfile(f/'sprayCloudProperties',f/'trialCloudProperties')
for n in ('run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','capture_contract_sources.sh'):
 (e/n).write_bytes((b/'fitting/dpm/m8a3_v1'/n).read_bytes().replace(b'm8a3_v1',b'm8a3a_v1'))
header='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\n'
(e/'build.sh').write_text(header+'cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMRebinding\nwmake > ../../fitting/dpm/m8a3a_v1/log.wmake 2>&1\n')
(e/'run.sh').write_text(header+'cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3a_v1\nfor state in A B C; do\n mkdir -p "$state"\n cd "$state"\n /usr/bin/time -v /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMRebinding/testFiveEqDPMRebinding /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMRebinding/fixture$state $state > log.run 2> log.resource\n cd ..\ndone\n')
