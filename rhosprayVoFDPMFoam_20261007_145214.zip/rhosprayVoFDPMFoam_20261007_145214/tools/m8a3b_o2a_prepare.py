from pathlib import Path
import json,hashlib,shutil
b=Path(__file__).resolve().parents[1];old=b/'fitting/dpm/m8a3b_o2_v1';e=b/'fitting/dpm/m8a3b_o2a_v1'
assert not e.exists(),'Never overwrite gate evidence'
e.mkdir();t=b/'tests/fiveEqORourkeThermal';(t/'Make').mkdir(parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_text(json.dumps({str(p.relative_to(b)):sha(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_o2a_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()},indent=2))
shutil.copyfile(old/'case_before.json',e/'case_before.json')
for folder in ('fixtures','branch_fixtures','rebinding_fixtures'):shutil.copytree(old/folder,e/folder)
for s in 'ABC':shutil.copyfile(old/f'O1_{s}_collision_entry.txt',e/f'O1_{s}_collision_entry.txt')
for name in ('run_all_regressions.sh','run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','run_rebinding.sh','run_support.sh','run_carrier_verified.sh','run_o2.sh','read_sources.sh'):
 data=(old/name).read_bytes().replace(b'm8a3b_o2_v1',b'm8a3b_o2a_v1')
 if name=='run_o2.sh':data=data.replace(b'/results/',b'/O2_regression/')
 if name=='read_sources.sh':data=data.replace(b'for name in ',b'for name in ThermoParcel.C NoHeatTransfer.C NoPhaseChange.C LiquidEvaporationBoil.C ReitzKHRT.C SphereDragForce.C StochasticDispersionRAS.C NSRDSfunc5I.H NSRDSfunc0I.H C7H16.C C7H16.H ')
 (e/name).write_bytes(data)
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqORourkeThermal"\nwmake > "$base/fitting/dpm/m8a3b_o2a_v1/log.wmake" 2>&1\n').encode())
(e/'run.sh').write_bytes((head+'cd "$base/fitting/dpm/m8a3b_o2a_v1"\nmkdir -p thermal\ncd thermal\n"$base/tests/fiveEqORourkeThermal/testFiveEqORourkeThermal" "$base/fitting/dpm/m8a3b_o2a_v1/branch_fixtures/A" A /mnt/d/DATA/Solver/300_2D/constant/thermal.dat "$base/fitting/dpm/m8a3b_o2a_v1/O1_A_collision_entry.txt" > log.run 2>&1\n').encode())
(t/'Make/options').write_bytes((b/'tests/fiveEqORourkeConservative/Make/options').read_bytes())
(t/'Make/files').write_bytes((b/'tests/fiveEqORourkeConservative/Make/files').read_bytes().replace(b'testFiveEqORourkeConservative',b'testFiveEqORourkeThermal'))
# Test visibility only. Algorithm bytes unchanged; original O2 policy never edited.
policy=(b/'tests/fiveEqORourkeConservative/conservativePolicy.H').read_text()
policy=policy.replace('class Policy:public ORourkeCollision<m8a3a::Kin> {','class Policy:public ORourkeCollision<m8a3a::Kin> {\npublic: // O2A harness visibility only')
(t/'thermalPolicyProbe.H').write_text(policy)
(e/'envelope_before_tests.json').write_text(json.dumps({
 'classification':'AUDIT_INPUT_ENVELOPE_NOT_CFD_DISTRIBUTION',
 'propertyPressurePa':[188330.307,3e6,12e6],
 'initialTemperaturesK':[285,300,305,320],
 'relativeVelocityMps':[0,1e-6,1e-5,1e-4,.001,.01,.1,1,10,50,100,300,1000,2013.039,4026.078],
 'massRatios':[.01,.1,1,10,100],
 'productionDiameterM':[200e-6,300e-6],
 'O1O2StressDiameterM':[50e-9,1e-6,300e-6],
 'inputSources':['300_2D/constant/SprayCloudProperties','locked gas U_inf=2013.039 m/s','O1/O2 native harness states'],
 'velocityBoundMeaning':'2*U_inf conservative branch stress bound; not measured droplet velocity',
 'productionPressureRangeNotFullyCertified':True,
 'thermalMonotonicAudit':'entire original O2 allowable Tt..Tc; no posterior shrink to hide failures',
 'comparisonBudget':'unchanged O2 128epsilon and1e-30 absolute floor'},indent=2))
print(e)
