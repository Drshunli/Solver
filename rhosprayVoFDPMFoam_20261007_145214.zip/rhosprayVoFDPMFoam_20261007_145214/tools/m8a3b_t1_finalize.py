from pathlib import Path
import json,hashlib,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t1_v1';case=b.parent/'300_2D'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=e/'mapping_contract.json';c=json.loads(p.read_text())
c['conditionalBottomWallGeometry']={'status':'SUPERSEDED BY FROZEN futurePatchGeometry','source':'PROJECT_DESIGN_INPUT'}
p.write_text(json.dumps(c,indent=2))
gate={
 'physical circular area documented':True,'old area mismatch quantified':True,'A/B/C comparison complete':True,'mapping A selected':True,
 'x explicitly frozen':True,'wall explicitly frozen':True,'direction explicitly frozen':True,'ideal patch width frozen':True,
 'existing wall representability audited':True,'numerical audit-candidate areas known':True,'mdot velocity arithmetic checked':True,
 'pressure not overconstrained':True,'Eulerian nozzle ownership frozen':True,'test DPM only':True,'anti-double-injection contract frozen':True,
 'initial L=0 retained':True,'runtime stress family definable':True,'active unchanged':True,'no CFD':True}
assert c['status']=='COMPLETE / DESIGN ONLY' and all(gate.values())
(e/'T1_COMPLETE_GATE.json').write_text(json.dumps({'scope':'design only; not runtime patch/BC or support certification','checks':gate},indent=2))
status=b/'MILESTONE_STATUS.md';saved=e/'milestone_before.md'
if saved.exists():raise SystemExit('Refusing to finalize twice')
saved.write_bytes(status.read_bytes())
entry='''

## M8A.3B-T1 2D representation and ownership freeze (2026-10-01)

**COMPLETE / DESIGN ONLY.** User PROJECT_DESIGN_INPUT provides xNozzle=15mm,
bottom wall y=0, fluid entry +y, independently of TEST_DPM_INLET. Original
DESIGN_INPUT_PROPOSAL label retained. First-activation design selects Mapping-A
equivalent-area slot: w=1.413716694115mm, numerical depth=50um, A=Aphysical.
Ideal x interval 14.2931416529423--15.7068583470577mm; exact whole-face
representation is unavailable in current mesh. Faces 41965/41994 contain ideal
edges. 28-face and 30-face audit candidates have area errors -0.9702576% and
+6.1032954%; neither is selected production geometry. Exact ideal geometry
requires future separately authorized conforming mesh subdivision/regeneration.
A/B/C conservation and interpretation comparison complete; no B weighting or
C changed-reference jet is adopted. Reference velocity=2.131674300619m/s.
Mass-flow+TL control/responding pressure, initial gas/L=0, Eulerian mass owner,
TEST_DPM_INLET zero production budget and anti-double-injection contract frozen.
Runtime stress family now geometrically definable, L/Dphysical=1/2/5/10, not
instantiated or scanned. T1 design gate passes; native patch/BC NOT IMPLEMENTED.
Actual case and active source/Make hashes unchanged; historical evidence retained.
No CFD/transaction/M6B. M8A.3B and M8A PARTIAL; M6B.0 BLOCKED, M6B.1 NO.
See M8A3B_T1_INJECTION_REPRESENTATION.md and fitting/dpm/m8a3b_t1_v1.
'''
with status.open('ab') as f:f.write(entry.encode())
before=json.loads((e/'case_before.json').read_text());after={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()};assert before==after
active=json.loads((e/'active_before.json').read_text());assert all(sha(b/n)==h for n,h in active.items())
old=json.loads((b/'fitting/dpm/m8a3b_v1/protected_before.json').read_text());changes=[n for n,h in old.items() if n!='MILESTONE_STATUS.md' and (not (b/n).exists() or sha(b/n)!=h)];assert not changes,changes
proof={'entireCaseUnchanged':True,'activeSourceAndMakeUnchanged':True,'protectedUnexpectedChanges':changes,'milestoneAppendOnly':status.read_bytes().startswith(saved.read_bytes()),'noCFD':True}
(e/'protection_verification.json').write_text(json.dumps(proof,indent=2))
archive=b/'checkpoints/M8A3B_T1_design_v1_COMPLETE.zip'
if archive.exists():raise SystemExit('Refusing to overwrite archive')
files=[p for p in e.rglob('*') if p.is_file()]+list(b.glob('tools/m8a3b_t1_*'))+[b/'M8A3B_T1_INJECTION_REPRESENTATION.md',status]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(b).as_posix())
    z.writestr('CHECKPOINT_MANIFEST.json',json.dumps({p.relative_to(b).as_posix():sha(p) for p in files},indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(e/'checkpoint.json').write_text(json.dumps({'path':str(archive),'sha256':sha(archive),'status':c['status']},indent=2))
print(json.dumps(proof,indent=2));print(c['status'])
