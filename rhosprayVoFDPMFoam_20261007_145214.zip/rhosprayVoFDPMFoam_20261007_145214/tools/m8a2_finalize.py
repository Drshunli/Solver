from pathlib import Path
import json,hashlib,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a2_v1'
native=json.loads((e/'test_results.json').read_text());mpi=json.loads((e/'mpi_allocator_results.json').read_text());frozen=json.loads((e/'frozen_regression_comparison.json').read_text())
assert native['failures']==mpi['failures']==frozen['failures']==0
assert (e/'direct_initial_state.txt').read_bytes()==(e/'retry_initial_state.txt').read_bytes()
gates={
'production support region formally defined':'PASS',
'actual cellPoint stencil audited':'PARTIAL: bounded serial native probe',
'strict-support feasibility scan complete':'NOT COMPLETE',
'injection hook installed in passive production path':'PARTIAL: native harness override only',
'tracking hook installed':'PARTIAL: native harness override only',
'deposition hook installed':'NOT COMPLETE',
'trace gas supported':'PASS in standalone classifier/hook',
'exact gas absent rejected before illegal query':'PASS in tested serial hooks',
'no fake carrier state':'PASS',
'self-owned trial cloud implemented':'PARTIAL: fresh initial-state only',
'all trial model owners correct':'PARTIAL: eight top-level PASS; all dependent refs not exposed',
'particle-ID transaction PASS':'PASS serial component',
'injector-state transaction PASS':'PARTIAL: initial state replay only',
'RNG transaction PASS':'PARTIAL: initial replay and scalar probe only',
'breakup child rollback PASS':'NOT COMPLETE',
'collision mutation rollback PASS':'NOT COMPLETE',
'rebound rollback PASS':'PARTIAL: prior native local proof only',
'source accumulator rollback PASS':'PARTIAL: fresh trial fields isolated; no continued cloud',
'parcel deletion rollback PASS':'PARTIAL: prior local proof only',
'output fully deferred/commit-safe':'PARTIAL: noWrite PASS; accepted release missing',
'voidFraction handling proven':'PARTIAL: classification/formula/noWrite; commit integration missing',
'objectRegistry pollution test PASS':'PARTIAL: 1000 fresh cycles after explicit cache warmup',
'repeated transaction ownership PASS':'PARTIAL: initial factory cycles only; full leak check absent',
'normal accepted-event physics unchanged':'NOT COMPLETE',
'oversized reject+retry PASS':'PARTIAL: manually discarded initial large trial',
'direct-small-step equivalence PASS':'PARTIAL: initial-state exported byte equality only',
'injection-containing retry PASS':'PARTIAL: initial-state only',
'breakup-containing retry PASS':'NOT COMPLETE',
'collision-containing retry PASS':'NOT COMPLETE',
'support-failure retry PASS':'PARTIAL: installed crossing rejection; whole-step golden missing',
'combined production event retry PASS':'NOT COMPLETE',
'frozen M8A source/energy regressions PASS':'PASS: 9288 byte-identical',
'no alpha source introduced':'PASS',
'active solver unchanged':'PASS',
'no CFD run':'PASS',
'2-rank transaction test PASS':'NOT COMPLETE: allocator-only 2002 PASS, actual crossing/source missing'}
summary={'M8A2':'PARTIAL','M8A':'PARTIAL','M6B0':'BLOCKED','M6B1':'NO','nativeComponents':native,'frozen':{'checks':9288,'failures':0,'byteIdentical':True},'mpiAllocatorOnly':mpi,'gates':gates,'activeImpact':'NONE','noCFD':True}
(e/'summary.json').write_text(json.dumps(summary,indent=2))
files=[b/'M8A2_PRODUCTION_TRANSACTION_GATE.md',b/'MILESTONE_STATUS.md']
for folder in ('dpmFiveEq','tests/fiveEqDPMTransaction','docs','tools','fitting/dpm/m8a2_v1'):
 for p in (b/folder).rglob('*'):
  if any(x in p.parts for x in ('lnInclude','linux64GccDPInt32Opt','native_sources')):continue
  if p.is_file():files.append(p)
dest=b/'checkpoints/M8A2_initial_transaction_components_v1_PARTIAL.zip';dest.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):z.write(p,str(p.relative_to(b)))
sha=hashlib.sha256(dest.read_bytes()).hexdigest();(e/'checkpoint.sha256').write_text(sha+'  '+dest.name+'\n')
print(json.dumps({'status':'PARTIAL','checkpoint':str(dest),'sha256':sha}))
