from pathlib import Path
import json,math
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2a_v1';a=json.loads((e/'audit_summary.json').read_text());n=a['normal'];z=a['boilingCounterexample']
heads=['O2A status','Thermalization equation','Parcel energy convention','Caloric property implementation','Temperature inversion','Certified temperature domain','DeltaE_diss sign result','Zero-relative-velocity limit','Equal-parcel result','Unequal-mass sweep','Multiplicity sweep','Temperature sweep','Production-relevant envelope','Stress envelope','O1-A thermal replay','O1-B thermal replay','O1-C thermal replay','Thermal energy round-trip','Mass closure','Species closure','Momentum closure','Total-energy closure','Different-temperature mixing','Composition mixing','Thermalization fraction','Resulting temperature range','Energy-per-mass range','Downstream model compatibility','Breakup-property sensitivity','Surface-energy treatment','Deformation-energy treatment','Reference-shift invariance','Invalid-state behavior','Determinism','Performance','Physical-consistency classification A/B/C','First-activation suitability','Experimental-validation status','Source-adapter impact','Active solver impact','Remaining blockers','Whether O2A COMPLETE','Whether T3B may resume — NEXT ROUND ONLY','T3 status','T4 permission','M8A status','M6B.0 permission','M6B.1 permission','Frozen regression result','Updated milestone matrix']
c={
1:'**PARTIAL / THERMALIZATION_MODEL_BLOCKER；分类 C。** 数学审计通过，但当前 O2 v1 可接受超出下一步 native boiling-related TMax 的状态。没有将数值 PASS 标为物理认证，也没有修改旧 O2 COMPLETE 的历史范围。',
2:r'''以 represented mass M=np*single-droplet mass 为唯一质量定义。

```text
E_A = sum(M_j*e_j + 0.5*M_j*|U_j|^2)
M_B = sum(M_j); Y_B = sum(M_j*Y_j)/M_B
U_B = sum(M_j*U_j)/M_B
Eint_B,preHeat = sum(M_j*e_j)
E_mech,B = Eint_B,preHeat + 0.5*M_B*|U_B|^2
DeltaE_diss = E_A - E_mech,B
Eint_B,new = Eint_B,preHeat + DeltaE_diss
solve e_native(p,Tnew,Y_B) = Eint_B,new/M_B
E_B = E_A
```

两个完整合并参与者时，DeltaE_diss=0.5*(M1*M2/(M1+M2))*|U1-U2|^2。
O2 partial transfer 使用 survivor+remaining donor 的完整 KE 差；同事件 tiny remainder 全并入 recipient 后才 zero bookkeeping delete。
新增 thermal unit sweep 是 conditioned full-merge primitive 测试，**不伪称每个输入均由 native probability 触发合并**；真实 stochastic branch 由 O1/O2 重放覆盖。
没有 residual energy 修补、carrier source 或 Eulerian C_L。
''',
3:'''实际存储 T、Y、rho、d、np、U；不是显式存储一个独立 parcel e field。
本机 CompositionModel.C 的 LIQUID 分支：H=sum(Y_i*h_i(p,T))；Hs=sum(Y_i*(h_i(p,T)-h_i(p,298.15)))；Hc=sum(Y_i*h_i(p,298.15))。
O2 使用 e=H-p/rho_mix；这是从实际液体 h/rho 构造的内部能量 primitive，也可见 SprayParcel atomization 的 iTp/iTb 计算，但不是 native collision 已实现的能量闭合。
气相 JANAF 用于 harness carrier bootstrap，**不进入碰撞 caloric authority**；C_L、ndecane Gibbs/e_solver reference 不进入该 primitive。
ReactingParcel phase-change/heat 源独立；当前两者 none，不由 collision 自动相变。''',
4:'''直接调用当前 OF7 composition/liquidMixtureProperties。C10H22.C：

```text
h(T)=-2699436.15229142+1958.18252099659*T
     -0.695470358786942*T^2+0.00251537407316302*T^3
Cp(T)=1958.18252099659-1.39094071757388*T+0.00754612221948905*T^2
rho(T)=60.94208835 / 0.25745^[1+(1-T/617.7)^0.28912]
```

NSRDSfunc0/5 本机实现与 coefficient 源已保存。liquidMixtureProperties rho/Cp/mu/sigma/pv 等存在 native TrMax=0.999 的输入限幅，必须披露。
H 的原始液体分支按 native h(T) 求值；因此对 e 的导数应为 dh/dT-p*alpha/rho，**不能设 de/dT=Cp 或 Cv=Cp**。
native_properties.csv 包含 6003 个实际 API 状态；没有把这些相关式输出称为实验数据。''',
5:'''O2A thermalPolicyProbe.H 是 O2 conservativePolicy.H 的测试访问副本：只增加 public 可见性，算法不改。实际 solveT 采用 native H/rho、局部 bracket 扩展、32 点单调检查、bisection/adjacent-double residual。
无 DeltaT=DeltaE/(mCp)、无 T clipping、无未盘点 energyFix。
重新调用 actual native e 校验 root，而不只信 solver 自报 residual。
独立多组分 unit 使用实际 native mixture API 与 CompositionModel LIQUID 同一加权 h 公式；不是生产 cloud 配置变更。''',
6:f'''**数值域审计通过，物理认证域未通过。**
O2 输入域下限=max(TMin,active liquid Tt)，上限=min(TMax,mixture Tc)，Tc 开端点；当前 C10H22 Tt=243.51 K，Tc=617.7 K，默认 TMin=200 K、TMax=5000 K。
本轮在 p=0.188330307/3/12 MPa 及 Tt..Tc 网格审计，数值 min de/dT={n['minimumNativeMixtureEnergySlope']:.6g} J/(kg K)。
解析证明补充：Cp 随 T 增加，alpha/rho 随 T 增加；用 0.01 K 分区下界 Cp(Tlo)-pmax*alpha(Thi)/rho(Thi)，得到全区间保守下界 {a['analyticEnergySlopeLowerBound']:.6g} J/(kg K)>0。TrMax 以上 rho 输入固定，e_T=dh/dT>0；故当前已审计单组分数值域内 root 唯一。
此证明包含 native property cap，**不构成近临界液体物理有效性证明**。本次成功 root 全部低于 TrMax*Tc，没有靠该 cap 挽救碰撞结果。
低压还需 boiling-related admissibility；原 O2 没有相应 event rejection，这是本轮 FAIL 条件。''',
7:'''3600 个 conditioned full-merge 输入的显式 reduced-mass DeltaE_diss 均 >=0。
原生 O2 replay 的完整 KE 前后差亦单独记录；不通过回改 U 补能量。
正 M 和 COM 投影的解析式保证非负；若未来 event 超出冻结算术预算呈负耗散，必须 ENERGY_POLICY_INVALID_EVENT/whole trial discard，不得靠冷却 survivor。
本轮没有实际触发该负耗散拒绝路径；不是把无法生成的负值状态标为已原生测试。''',
8:'''严格 Urel=0 的 native collision 不发生，沿用 O2 no-collision regression。
conditioned merge unit 用于测试机械热化零贡献与非线性温度混合，不改变 native collision probability。
对于 T1=T2，极限下的温度差只有被冻结预算覆盖的 double 舍入；不能把最后几个 Urel 的不可分辨温升当作真实精确温升。
表中温升以同输入 zero-relative unit 的 T 基线相减。''',
9:'''等 represented mass、同组成/温度：U_B 为 COM，耗散能/总质量=Urel^2/8。
在同单滴直径时 np 也相同；O2 equal-diameter/反转容器测试继续通过。
热化单元通用结果遵守上述 represented identity；原生概率是否发生 coalescence 仍由 native We/random law 决定。''',
10:'''M1:M2=1:100、1:10、1:1、10:1、100:1；组合四个 T1/T2 与十五个 Urel、三个压力，总计3600状态。
3552 root 成功、48 高能态受控拒绝；另外48成功root触发低压沸腾判据，不能算物理合法 PASS。
没有因小 parcel 质量而豁免；所有状态使用同一冻结预算。''',
11:'''单元测试由固定 represented masses 与200/300 um单滴直径、actual rho反推 np，因此覆盖 unequal np，而非混用单滴能量和 parcel-total mass。
np1/np2 每行明确输出。原 O1/O2 另包含1 um/50 nm及不同np的真实碰撞 pair。
production injection 的 nominal represented mass/parcel=massTotal/(duration*parcelsPerSecond)，实际 rho 会更新该np换算；不拿 Cp0/rho0 当 caloric authority。''',
12:'''T1、T2 独立遍历285、300、305、320 K；零相对速度的285+320 K混合包含所有五种质量比。
温度、rho、mu、sigma、Cp通过 native API输出；equal-temperature endpoints 使用原 O2 128epsilon 的温度运算尺度判断 double 舍入，不裁剪返回T。
早期严格不等式造成14个端点误报，attempt日志保留；最终未放宽原 factor 或 energy budget。''',
13:'''`O2A_CERTIFIED_ENVELOPE_v1` **认证失败，不发布为 production-safe envelope**；预先冻结的 audited input envelope 在 envelope_before_tests.json。

实际300_2D文件：U=517.6 m/s、p初始/入口102243 Pa、T初始/入口166.67 K；injection T0=300 K，RosinRammler200–300 um，parcelsPerSecond=21220659，massTotal=0.0005262723452 kg，duration=1 s；nominal rho0=730、Cp0=2090。
这与用户未来锁定 gas2013.039 m/s、188330.307 Pa、400 K及燃料1.09609e-4 kg/s **不同**，两组输入分别记录，不修改case，不称已同步。
285–320 K与既有harness/EOS HARD温度试验范围对应；12 MPa只借用历史HARD压力上限做parcel stress，**不使用Eulerian EOS或C_L求parcel热量**。
实际 parcel速度分布/长期np分布未知，不运行CFD，不能将上述分支测试矩阵称为已测CFD distribution。''',
14:'''extended stress：O1/O2 d=50 nm..300 um；np由represented质量与真实单滴质量生成；Urel=0、1e-6..1、10/50/100/300/1000、2013.039、4026.078 m/s。
4026.078=2*未来gasU，预先定义的保守两向速度差branch bound，**不是气速必然等于液滴碰撞速度**。
p=188330.307/3e6/12e6 Pa，初始T285–320 K；压力/速度范围未由CFD估计。
高能拒绝不是通过事后缩小最大U隐藏；不可用压力上限变更把低压沸腾反例移出报告。''',
18:f'''native e(Tnew)独立回算全部3552成功root；最大specific-energy residual={n['maxRoundtripSpecificEnergyResidual']:.6g} J/kg，在原O2预算内。
本轮没有能量修补ledger；mass/species/P通过O2真实event回归，热化conditioned unit则用解析机械能量式核对。''',
19:'O1/O2 全部 mass regressions PASS；没有 positive deletion、carrier mass dump 或 alpha source。数学 closure 不代替相态 admissibility。',
20:'单组分走通用 represented species路径，O2 三个species-map账本继续PASS；synthetic两液体按质量得到Ynew后才求温度。没有自动renormalization修补。',
21:'O2完整pair/population动量回归PASS；先由M/Y构造COM U，然后求KE差和T。thermal root 不回改U；signed comparison仍用sum(abs(mU))的原固定预算。',
22:'''defined parcel caloric+translational KE 数学闭合PASS；不把这个结论扩大为完整微观能量或physical thermodynamic consistency。
压力功问题另存：在held-p下rho(T)变化，V改变，p*DeltaV不为零；isolated内部能量与固定外压enthalpy过程并非相同合同。例specific内部能量增加1000 J/kg、T300->300.451153 K时，3MPa下p*DeltaV/M=1.90294796 J/kg。
本轮仅报告此量，没有把它加到carrier dEt。后续需明确pressure-work/constant-volume近似及热化分配，不能让reference constant补掉它。''',
23:'Urel=0但T1!=T2时，合并e目标为原总caloric energy/M，而非T算术平均。285+320K与质量比扫描的返回T在端点区间内（冻结舍入预算）。零机械耗散不禁止不同温度的caloric mixing。',
24:f'''synthetic C10H22/C7H16单元通过actual liquidMixtureProperties.X/rho与组件h进行50:50质量混合，T1=285、T2=320 K，merged caloric T={n['twoLiquidMixT']:.12g} K，round-trip PASS。
它验证native composition-aware primitive，不认证不同燃料整个collision/breakup production graph；生产composition仍只有C10H22。''',
25:'**thermalization fraction=1**，为O2项目假设。不是Foundation native行为；未调0.5/0.1，也未为了温度可接受而做参数拟合。',
26:f'''数值成功反演T范围 {n['Tmin']:.9g}–{n['Tmax']:.12g} K。范围含物理待拒绝的低压沸腾态，不得命名“认证温度范围”。
3MPa普通下游探测T={n['downstreamT']:.12g} K<TMax；低压反例T={z['downstreamT']:.12g} K>TMax={z['downstreamLimit']:.12g} K。''',
27:f'''成功root的DeltaE_diss/M范围0–{n['maximumDissipationPerMass']:.12g} J/kg。
tiny residual整并的O1温升见15–17节；并非把全部事件KE只除以tiny residual mass。大温升反例来自预先冻结的高相对速度，不是人为质量分母错误。''',
28:f'''使用实际sphereDrag、stochasticDispersionRAS、ReitzKHRT、none heat/phase、blobsSheetAtomization模型图；T3A independent trial执行一次普通evolveTrial并discard。
强化反例：p=188330.307 Pa，T1=T2=320 K，d1=d2=1 um、represented mass各1e-12 kg，U1/U2=±2013.039/2 m/s，实际native collision update dt=1e-8 s。
保持native概率/随机数/系数，预先固定最多64次独立输入查询，实际第{z['nativeEventSearchUpdates']}次达到boiling态；不是强制full merge或修改probability。完整pair/population events在thermal_boiling/downstream.jsonl，独立M/Y/P/E检查{a['nativeBoilingCounterexampleLedgerChecks']}项通过。
随后复制该真实热化participant做单粒子downstream API probe，其他参与者仍在原event账本中；测试fixture隔离并非policy正质量cleanup，不生成carrier transfer。
普通3MPa状态 finite/API PASS；低压状态同样finite，但native SprayParcel先按pv>=0.999p设置boiling TMax={z['downstreamLimit']:.12g} K，随后none heat直接返回原T={z['downstreamT']:.12g} K，相变none不删质量。
**物理域兼容性FAIL**，不能因函数不崩溃就认证。普通更新含drag，所以这一步不声称carrier source increment为零；零源限制只针对内部collision。
committed cloud/carrier未改变，未做完整T3B重试。''',
29:'''SprayParcel::calc在普通update前后查询Cp/rho/sigma/mu；calcBreakup将rho、mu、sigma交给ReitzKHRT；后者计算weGas=0.5*rhoc*Urel^2*d/sigma，weLiquid=0.5*rho*Urel^2*d/sigma，reLiquid=rho*Urel*(d/2)/mu与其Oh/Taylor组合。
thermal_sweep.csv逐行输出新物性；native_properties.csv保存原温度对应API物性。
rho降低、sigma/mu变化均有明确的native温度相关式来源；d根据质量、np、新rho重建也影响We/Re。
没有声称breakup频率更正确，也未做CFD/实验拟合。''',
30:'native ORourke sigma参与We/coalescence decision，未持有显式sigma*A能量ledger。当前caloric+translational合同遗漏surface-energy；未补一个虚构surface reservoir。真实合并界面面积改变会影响物理能量分配，需另行模型论证。',
31:'实际SprayParcel拥有y/yDot，solveOscillationEq=true会调用TAB振荡；不能说完全没有deformation state。ReitzKHRT/TAB并未提供与O2碰撞联立的完整deformation-energy库存和转移账本。本轮不新建该能量项；当前total energy声明仅限caloric+translational。',
32:f'''对3552个成功root目标做5个common-reference shifts（-1e9,-10,0,10,+1e9 J/kg），{a['referenceShiftAlgebraChecks']}项Decimal代数检查PASS。
因为M及species守恒，共同常量（或未来species常量）在混合前后取消；T目标不变。未修改actual OF h coefficients，也未把Eulerian C_L或gasHc添加到parcel内能。
这是reference-shift algebra check，不声称实际OF热物性库在巨大reference offset下重编译测试。''',
33:'48高能无root态抛OROURKE_ENERGY_UNBRACKETED_HIGH；无温度clip、无excess-energy discard。O2热域溢出/duplicate-ID/clone拒绝回归仍PASS；whole dirty trial可discard。**当前另48低压boiling态未被该拒绝机制覆盖**，此缺口导致C分类。',
34:'同输入actual solveT重复10000次，T结果bit-identical。迭代次数未单独计数，不声称计数已测；算法无随机数、bracket/bisection分支确定。原O2同事件retry/next query及确定性identity顺序回归仍PASS。',
35:f'''standalone microbenchmark：final普通run root均摊{n['rootCostNs']/1000:.6g} us；native collideSorted（包含parcel副本准备、随机数、native合并/擦碰）{n['nativeSortedCostNsIncludingParcelCopies']/1000:.6g} us。
低压单独run结果分别{z['rootCostNs']/1000:.6g}/{z['nativeSortedCostNsIncludingParcelCopies']/1000:.6g} us；两次native时间差显示短微基准噪声，不能作稳定倍率或CFD性能结论。
未包含完整collision cell搜索/parcel追踪/输出；每项10000次。''',
36:'**C / THERMALIZATION_MODEL_BLOCKER**。理由是明确的native下游phase-domain反例，超过单纯“缺少实验数据”的B类问题。fraction=1和e合同还存在pressure-work与surface/deformation物理解释缺口；不把这些用epsilon或q修补。',
37:'**NO。** 当前v1不能作为覆盖本轮audited envelope的首轮激活策略；较低能量局部测试成功不足以豁免高能低压反例。不能事后调fraction或压缩报告范围取得A。',
38:'未运行CFD、实验对比或生产分布验证。即便未来A也只是first algorithmic activation适用性；本轮分类C，没有任何实验validated声明。',
39:'**NONE**。冻结fiveEqDPMSourceAdapter、dmG/dmYi/dM/dEt、DPM_EULERIAN_ENERGY_REFERENCE_LEDGER不修改。collision内部源delta为0；普通下游drag源独立存在，未被当作collision散热。',
40:'**NONE**。原O1/O2代码和证据不改写；production case96文件SHA不变；active solver方程、Make、运行选项不修改。新增仅tests/fiveEqORourkeThermal、tools/m8a3b_o2a_*、独立证据与阶段报告。',
41:'''首要：O2温度反演domain缺少与实际下一步SprayParcel boiling-related TMax一致的拒绝；不能靠none heat“自动修正”。
下一次O2A修订应先设计pressure/composition-dependent phase admissibility，域外controlled failure/whole trial discard，无clipping、无即时蒸发。
其次：明确e与h的pressure-work合同、surface/deformation遗漏以及fraction=1物理依据；如引入独立dissipation reservoir，需另milestone及restart/transaction/MPI设计，本轮不实现。
O1重复身份继续作为拒绝fixture；没有删除ORourke第一激活scope，也未自行选择上层替代路线。''',
42:'**NO，O2A=PARTIAL。** 数值单调/唯一、扫参、reference shift、守恒、普通API兼容检查通过；boiling-related thermodynamic state合法性失败，production-certified envelope不能冻结。不能将所有numerical assertions PASS折算为COMPLETE。',
43:'**NO；T3B继续BLOCKED。** 下一轮应先继续O2A的phase-domain/热力学合同修订与复测；不是直接恢复T3B。任何后续许可仍不授权本轮执行。',
44:'PARTIAL；T3A保持COMPLETE，T3B保持PARTIAL/BLOCKED。',
45:'**NO**。',46:'**PARTIAL**；source/energy PASS/FROZEN。',47:'**NO**。',48:'**NO**。',
50:'''| Milestone | 状态 |
|---|---|
| M8A source/energy | PASS / FROZEN |
| M8A.3A | COMPLETE |
| M8A.3B-T1 | COMPLETE / DESIGN ONLY |
| M8A.3B-T2 | COMPLETE / STRICT SUPPORT |
| M8A.3B-T3A | COMPLETE |
| M8A.3B-T3B | PARTIAL / BLOCKED |
| M8A.3B-O1 | COMPLETE / NATIVE CONSERVATION BLOCKER；重复ID披露保留 |
| M8A.3B-O2 | COMPLETE / DESIGN + OFFLINE AUDIT；不等于production physics |
| M8A.3B-O2A | PARTIAL / THERMALIZATION_MODEL_BLOCKER，C |
| T3 overall | PARTIAL |
| T4 | NO |
| M8A overall | PARTIAL |
| M6B.0 / M6B.1 | NO / NO |

**STOP。本轮不恢复T3B，不执行T4/M6B，不运行CFD。**'''}
for number,s in ((15,'A'),(16,'B'),(17,'C')):
 r=a['O1_thermal_replay'][s]
 c[number]=f'''exact O1 affected pair字段/ID及实际native RNG重放仍PASS；原全cloud重复ID限制保留，不宣称full historical identity byte equality。

| 量 | 结果 |
|---|---:|
| Eint before/J | {r['EintBefore']:.16g} |
| KE before/J | {r['KEbefore']:.16g} |
| KE after/J | {r['KEafter']:.16g} |
| DeltaE_diss/J | {r['dissipation']:.16g} |
| survivor Tnew/K | {r['Tnew']:.16g} |
| Eint after/J | {r['EintAfter']:.16g} |
| total energy residual/J | {r['totalEnergyResidual']:.6g} |

Pbefore={r['Pbefore']}；momentum residual={r['momentumResidual']} kg m/s；native collision sourceBefore=sourceAfter。'''
c[8]+='\n\n| Urel/m s^-1 | dissipation/total mass/J kg^-1 | T-T_zero/K |\n|---|---:|---:|\n'
seq=a['zeroRelativeVelocitySequence'];base=float(next(x['Tnew'] for x in seq if float(x['relU'])==0))
for row in seq:
 if float(row['relU'])<=1:
  c[8]+=f"| {float(row['relU']):g} | {float(row['diss'])/2e-12:.8g} | {float(row['Tnew'])-base:.8g} |\n"
c[49]='| Suite | Checks | Result |\n|---|---:|---|\n'
for name,r in a['regressions'].items():c[49]+=f"| {name} | {r['checks']} | PASS |\n"
c[49]+='\n8 source/energy goldens byte-identical；10584个pre-change保护文件核查通过，MILESTONE仅允许本轮append；actualcase96文件不变。O1九组native控制349项、O2三组27420项。temporal/restart与P2/recovery/R1沿用冻结runner；不宣称新增full transaction restart认证。'
doc='# M8A.3B-O2A Thermalization physical-consistency gate\n\n日期：2026-10-02。只执行offline/passive harness；native源码引用及快照位于fitting/dpm/m8a3b_o2a_v1/native_sources。\n\n'
for i,h in enumerate(heads,1):doc+=f'## {i}. {h}\n\n{c[i]}\n\n'
(b/'M8A3B_O2A_THERMALIZATION_PHYSICAL_GATE.md').write_text(doc,encoding='utf-8')
print('50-section report written; O2A PARTIAL / C.')
