"""Offline dimensional mapping arithmetic and actual wall-face census only."""
from pathlib import Path
import json,math,re,gzip,hashlib,csv
b=Path(__file__).resolve().parents[1];case=b.parent/'300_2D';out=b/'fitting/dpm/m8a3b_t1_v1'
if out.exists():raise SystemExit('Refusing to overwrite evidence')
out.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()}
(out/'case_before.json').write_text(json.dumps(inputs,indent=2))
active={p.relative_to(b).as_posix():sha(p) for p in list(b.glob('*.C'))+list(b.glob('*.H'))+list((b/'Make').glob('*')) if p.is_file()}
(out/'active_before.json').write_text(json.dumps(active,indent=2))
D=.0003;bz=.00005;mdot=1.09609e-4;rho=727.4329605;TL=300;pRef=3e6
Aphys=math.pi*D*D/4;Aold=D*bz;W=Aphys/Aold;Uref=mdot/(rho*Aphys);wEq=Aphys/bz;beff=Aphys/D;UC=mdot/(rho*Aold)
rows=[{'mapping':'A','numericalWidth_m':wEq,'meshDepth_m':bz,'numericalArea_m2':Aphys,'interpretationFactor':1.,'numericalMassFlow_kg_s':mdot,'physicalMassFlow_kg_s':mdot,'referenceVelocity_m_s':Uref,'interpretedAdvectiveMomentum_N':mdot*Uref,'interpretedKineticEnergyFlux_W':.5*mdot*Uref**2,'status':'SELECTED DESIGN ONLY'},
{'mapping':'B','numericalWidth_m':D,'meshDepth_m':bz,'numericalArea_m2':Aold,'interpretationFactor':W,'numericalMassFlow_kg_s':mdot/W,'physicalMassFlow_kg_s':mdot,'referenceVelocity_m_s':Uref,'interpretedAdvectiveMomentum_N':W*(mdot/W)*Uref,'interpretedKineticEnergyFlux_W':W*.5*(mdot/W)*Uref**2,'status':'NOT SELECTED / FULL SCALING IMPLEMENTATION AND CERTIFICATION REQUIRED'},
{'mapping':'C','numericalWidth_m':D,'meshDepth_m':bz,'numericalArea_m2':Aold,'interpretationFactor':1.,'numericalMassFlow_kg_s':mdot,'physicalMassFlow_kg_s':mdot,'referenceVelocity_m_s':UC,'interpretedAdvectiveMomentum_N':mdot*UC,'interpretedKineticEnergyFlux_W':.5*mdot*UC**2,'status':'NOT SELECTED / DIFFERENT PLANAR-SLOT PHYSICS'}]
for r in rows:r.update(velocityRatio=r['referenceVelocity_m_s']/Uref,momentumRatio=r['interpretedAdvectiveMomentum_N']/(mdot*Uref),kineticEnergyFluxRatio=r['interpretedKineticEnergyFlux_W']/(.5*mdot*Uref**2))
with (out/'mapping_comparison.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def body(name):
    s=gzip.decompress((case/'constant/polyMesh'/(name+'.gz')).read_bytes()).decode()
    s=re.sub(r'//[^\n]*|/\*.*?\*/','',s,flags=re.S);s=s[s.index('}')+1:]
    m=re.match(r'\s*(\d+)\s*\((.*)\)\s*$',s,re.S);assert m;return int(m[1]),m[2]
np,ps=body('points');points=[tuple(map(float,x.split())) for x in re.findall(r'\(([^()]*)\)',ps)];assert len(points)==np
nf,fs=body('faces');faces=[list(map(int,x.split())) for size,x in re.findall(r'(\d+)\(([^()]*)\)',fs)];assert len(faces)==nf
wall=json.loads((b/'fitting/dpm/m8a3b_t0_v1/audit.json').read_text())['mesh']['patches'][2];assert wall['name']=='bottomWall'
facesData=[];edges=set()
for fid in range(wall['startFace'],wall['startFace']+wall['faces']):
    v=[points[i] for i in faces[fid]];lo=[min(p[a] for p in v) for a in range(3)];hi=[max(p[a] for p in v) for a in range(3)]
    assert lo[1]==hi[1]==0;assert abs(hi[2]-lo[2]-bz)<1e-15
    edges.update([lo[0],hi[0]]);facesData.append({'face':fid,'xMin_m':lo[0],'xMax_m':hi[0],'width_m':hi[0]-lo[0],'zMin_m':lo[2],'zMax_m':hi[2],'area_m2':(hi[0]-lo[0])*(hi[2]-lo[2])})
with (out/'bottom_wall_faces.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(facesData[0]));w.writeheader();w.writerows(facesData)
checks=[('A area',abs(wEq*bz-Aphys)<1e-20),('B area',abs(D*beff-Aphys)<1e-20),('B global mass',abs(W*rows[1]['numericalMassFlow_kg_s']-mdot)<1e-18),('C velocity ratio',abs(UC/Uref-W)<1e-13),('C momentum ratio',abs(rows[2]['momentumRatio']-W)<1e-13),('C kinetic ratio',abs(rows[2]['kineticEnergyFluxRatio']-W*W)<1e-12),('actual wall face count',len(facesData)==210),('wall area',abs(sum(f['area_m2'] for f in facesData)-.08*bz)<1e-16)]
assert all(ok for _,ok in checks)
contract={'milestone':'M8A.3B-T1','status':'PARTIAL / NOZZLE_LOCATION_BLOCKER','selectedMapping':'MAPPING-A / EQUIVALENT-AREA SLOT','selectionBasis':'explicit user recommended default for first 2D algorithmic activation; no conflicting approved production interpretation found','runtimeImplemented':False,
 'physicalReference':{'D_m':D,'A_m2':Aphys,'mdot_kg_s':mdot,'TL_K':TL,'pReference_Pa':pRef,'rhoReference_kg_m3':rho,'rhoSource':'user-provided reference-EOS generated value, reused for arithmetic only; no EOS regeneration','UReference_m_s':Uref},
 'mappingA':{'numericalDepth_m':bz,'idealWidth_m':wEq,'idealArea_m2':Aphys,'globalExtensiveFactor':1.,'preserves':'integrated mdot, reference velocity, advective momentum and same-state thermal/kinetic energy flux','doesNotPreserve':'in-plane physical diameter or 3D circular-interface geometry'},
 'legacyAudit':{'slotArea_m2':Aold,'physicalToOldAreaRatio':W,'historicalFlowRatio':.0005262723452/mdot,'proximityIsNotMappingEvidence':True},
 'mappingAlternatives':rows,'mappingD':'future actual 3D circular-hole physical validation; not implemented',
 'location':{'xNozzle_m':None,'wall':None,'yNozzle_m':None,'fluidEntryDirection':None,'source':'USER_REQUIRED; TEST_DPM_INLET cannot establish center or wall','questionRequested':True},
 'conditionalBottomWallGeometry':{'status':'FORMULA ONLY / NOT LOCATED OR SELECTED','xInterval':'[xNozzle-wEq/2, xNozzle+wEq/2]','y_m':0,'zInterval_m':[.014975,.015025],'outwardNormal':[0,-1,0],'fluidEntryDirection':[0,1,0],'requires':'explicit bottom-wall design confirmation'},
 'wallCensus':{'faces':len(facesData),'xEdges_m':sorted(edges),'candidateNozzleFaces':None,'representedPatchArea_m2':None,'areaError':None,'URequired_m_s':None,'auditBasis':'actual mesh face vertices, not inferred nozzle'},
 'futureBC':{'controls':['integrated mdot','TL'],'pressure':'responds mechanically; 3 MPa reference only','coherentFields':['P2','mG','mL','M','Et','mYi'],'massFlux':'sum(rhoL_f*(U_f dot nIn_f)*A_f)=mdot; no independent velocity Dirichlet','finiteFaceAreaPolicy':'report actual area/geometric error and Urequired=mdot/(rhoL*Apatch); do not silently adjust geometry or mdot'},
 'ownership':{'physicalNozzleMassOwner':'Eulerian liquid inlet','independentProductionDPMNozzle':'OFF BY DEFAULT / CONTRACT ONLY','oldPoint':'TEST_DPM_INLET / zero production mass budget','conversion':'later subtract same mass/momentum/energy/species from Eulerian when creating parcels; not implemented'},
 'initialTopology':{'name':'INITIAL_TOPOLOGY_V1','interior':'gas','liquidLength_m':0,'fieldGenerated':False},
 'runtimeStressTopology':{'status':'NOT CREATED / LOCATION BLOCKER','origin':'future Eulerian patch only','direction':'user-frozen fluid entry direction','width_m':wEq,'lengthReference':'Dphysical=0.3mm, not equivalent slot width','L_over_Dphysical':[1,2,5,10],'lengths_m':[k*D for k in (1,2,5,10)],'L_over_w2D':[k*D/wEq for k in (1,2,5,10)],'traceBufferCells':[1,2,3],'purpose':'P2 support-only stress tests, not physical initial column'},
 'supportScanMayResume':False,'transactionMayResume':False,'M6B0':'BLOCKED','M6B1':'NO','activeSolverImpact':'NONE','noCFD':True,'checks':len(checks),'failures':0}
assert inputs=={p.relative_to(case).as_posix():sha(p) for p in case.rglob('*') if p.is_file()};assert all(sha(b/n)==h for n,h in active.items())
(out/'mapping_contract.json').write_text(json.dumps(contract,indent=2));(out/'checks.json').write_text(json.dumps(checks,indent=2))
print(json.dumps({'status':contract['status'],'Aphys':Aphys,'Aold':Aold,'W':W,'Uref':Uref,'wEq':wEq,'beff':beff,'UC':UC,'CkineticRatio':W*W,'checks':len(checks),'failures':0},indent=2))
