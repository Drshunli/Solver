from pathlib import Path
import hashlib,json,shutil
b=Path(__file__).resolve().parents[1]; e=b/'fitting/dpm/m8a2_v1';e.mkdir(parents=True,exist_ok=True)
if (e/'protected_before.json').exists():
 raise SystemExit('One-time preparation already performed; use existing build_run.sh. Do not overwrite evidence or finalized overrides.')
protected={}
for p in b.rglob('*'):
 if not any(x in p.parts for x in ('fitting','checkpoints','lnInclude','linux64GccDPInt32Opt')) and p.is_file():
  protected[str(p.relative_to(b))]=hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_text(json.dumps(protected,indent=2))
t=b/'tests/fiveEqDPMTransaction';(t/'Make').mkdir(parents=True,exist_ok=True)
for n in ('options','files'):
 (t/'Make'/n).write_bytes((b/'tests/fiveEqDPMProduction/Make'/n).read_bytes().replace(b'testFiveEqDPMProduction',b'testFiveEqDPMTransaction'))
f=t/'fixture';shutil.copytree(b/'tests/fiveEqDPMProduction/fixture',f,dirs_exist_ok=True,ignore=shutil.ignore_patterns('1e-*','2e-*','3e-*','4e-*','5e-*','lagrangian'))
shutil.copyfile(f/'constant/sprayCloudProperties',f/'constant/trialCloudProperties')
src=b/'fitting/dpm/m8a1_v1/source_audit/lagrangian'
def method(path,name):
 s=(src/path).read_text();at=s.index(name);start=s.rfind('template<class',0,at);start=s.rfind('template<class',0,start) if s[start:at].count('template<class')==1 and s[s.rfind('template<class',0,start):at].count('template<class')==2 else start
 # Locate exact preceding template block, avoiding unrelated preceding method.
 start=s.rfind('\ntemplate<class',0,at)+1
 if s[max(0,start-35):start].strip().endswith('template<class CloudType>') or s[max(0,start-40):start].strip().endswith('template<class ParcelType>'):
  start=s.rfind('\ntemplate<class',0,start-1)+1
 brace=s.index('{',at);depth=1;i=brace+1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[start:i]
inject=method(Path('intermediate/submodels/Kinematic/InjectionModel/InjectionModel/InjectionModel.C'),'void Foam::InjectionModel<CloudType>::inject\n')
inject=inject.replace('template<class CloudType>\ntemplate<class TrackCloudType>','template<>\ntemplate<>').replace('InjectionModel<CloudType>','InjectionModel<Foam::basicSprayCloud>').replace('TrackCloudType& cloud','Foam::basicSprayCloud& cloud').replace('typename CloudType::parcelType::trackingData','Foam::basicSprayParcel::trackingData')
inject=inject.replace('// Create a new parcel','fiveEq::m8a2InjectionGuard(cloud, pos, celli);\n\n                    // Create a new parcel')
inject=inject.replace('parcelType* pPtr = new parcelType(mesh, pos, celli);','std::unique_ptr<parcelType> provisional(new parcelType(mesh, pos, celli));\n                    parcelType* pPtr = provisional.get();').replace('cloud.addParticle(pPtr);','cloud.addParticle(provisional.release());').replace('delete pPtr;','provisional.reset();')
track=method(Path('intermediate/parcels/Templates/KinematicParcel/KinematicParcel.C'),'void Foam::KinematicParcel<ParcelType>::setCellValues')
track=track.replace('template<class ParcelType>\ntemplate<class TrackCloudType>','template<>\ntemplate<>').replace('KinematicParcel<ParcelType>','KinematicParcel<Foam::particle>').replace('TrackCloudType& cloud','Foam::basicSprayCloud& cloud')
track=track.replace('    tetIndices tetIs', '    fiveEq::m8a2TrackingGuard(cloud, *this);\n    tetIndices tetIs',1)
post=method(Path('intermediate/clouds/Templates/KinematicCloud/KinematicCloud.C'),'void Foam::KinematicCloud<CloudType>::postEvolve')
post=post.replace('template<class CloudType>','template<>').replace('KinematicCloud<CloudType>','KinematicCloud<Foam::Cloud<Foam::basicSprayParcel>>').replace('if (debug)','if (debug && !fiveEq::m8a2TrialContext())').replace('if (this->db().time().writeTime())','if (this->db().time().writeTime() && !fiveEq::m8a2TrialContext())')
fn=method(Path('intermediate/submodels/CloudFunctionObjects/CloudFunctionObject/CloudFunctionObject.C'),'void Foam::CloudFunctionObject<CloudType>::postEvolve')
fn=fn.replace('template<class CloudType>','template<>').replace('CloudFunctionObject<CloudType>','CloudFunctionObject<Foam::basicSprayCloud>').replace('if (this->owner().time().writeTime())','if (this->owner().time().writeTime() && !fiveEq::m8a2TrialContext())')
(t/'nativePassiveOverrides.H').write_bytes(('#pragma once\n// GPL-3.0-or-later: project-local OF7 method specializations.\n#include "fiveEqDPMTrialHooks.H"\n#include <memory>\n'+inject+'\n'+track+'\n'+post+'\n'+fn+'\n').encode())
reg=(b/'fitting/dpm/m8a_v1/run.sh').read_text().replace('fitting/dpm/m8a_v1/','fitting/dpm/m8a2_v1/energy_regressions/')
(e/'run_energy_regressions.sh').write_bytes(reg.encode())
script='''#!/bin/bash
source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
set -e
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMTransaction
wmake > ../../fitting/dpm/m8a2_v1/log.wmake 2>&1
cd ../../fitting/dpm/m8a2_v1
../../..//tests/fiveEqDPMTransaction/testFiveEqDPMTransaction /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMTransaction/fixture /mnt/d/DATA/Solver/300_2D/constant/thermal.dat > log.transaction 2>&1
'''.replace('../../..//tests','../../../tests')
(e/'build_run.sh').write_bytes(script.encode())
