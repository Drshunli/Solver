from pathlib import Path
import shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a1_v1';t=b/'tests/fiveEqDPMProduction';t.mkdir(exist_ok=True);(t/'Make').mkdir(exist_ok=True)
for name in ('options','files'):
 text=(b/'tests/fiveEqDPMNative/Make'/name).read_text(encoding='utf-8').replace('testFiveEqDPMNative','testFiveEqDPMProduction');(t/'Make'/name).write_bytes(text.encode())
f=t/'fixture';shutil.copytree(b/'tests/fiveEqDPMNative/fixtures/zero',f,dirs_exist_ok=True)
for name in ('sprayCloudProperties','turbulenceProperties'):shutil.copyfile(b.parent/'300_2D/constant'/name,f/'constant'/name)
# Exact production MODEL dictionary, manufactured geometry/fields only.
def header(n,cls='volScalarField'):return f'FoamFile {{version 2.0; format ascii; class {cls}; object {n};}}\n'
for name,value,dims in [('k',1,'0 2 -2 0 0 0 0'),('omega',100,'0 0 -1 0 0 0 0'),('nut',.01,'0 2 -1 0 0 0 0'),('alphat',.02,'1 -1 -1 0 0 0 0')]:
 (f/'0'/name).write_bytes((header(name)+f'dimensions [{dims}]; internalField uniform {value}; boundaryField {{outer {{type zeroGradient;}}}}').encode())
p=f/'constant/polyMesh/boundary';p.write_bytes(p.read_text().replace('type patch;','type wall;').encode())
(f/'system/controlDict').write_bytes((header('controlDict','dictionary')+'application nativeUnitHarness; startFrom startTime; startTime 0; stopAt endTime; endTime 1; deltaT 1e-6; writeControl timeStep; writeInterval 1;').encode())
(f/'system/fvSchemes').write_bytes(((f/'system/fvSchemes').read_text()+'\nwallDist {method meshWave;}\n').encode())
s='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\ncd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMProduction\nwmake > ../../fitting/dpm/m8a1_v1/log.wmake 2>&1\n'
(e/'build.sh').write_bytes(s.encode())
s='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\ncd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a1_v1\n/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMProduction/testFiveEqDPMProduction /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMProduction/fixture /mnt/d/DATA/Solver/300_2D/constant/thermal.dat > log.production 2>&1\necho "$?" > exit.production.txt\n'
(e/'run.sh').write_bytes(s.encode())
