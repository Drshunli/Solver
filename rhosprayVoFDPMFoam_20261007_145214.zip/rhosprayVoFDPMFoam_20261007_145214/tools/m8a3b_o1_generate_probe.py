from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o1_v1'
p=e/'native_sources/lagrangian/spray/submodels/StochasticCollision/ORourkeCollision/ORourkeCollision.C'
s=p.read_text();start=s.index('{',s.index('void Foam::ORourkeCollision<CloudType>::collide'));end=s.index('\n}\n',start)+2;body=s[start:end]
hooks=[]
def insert(old,new):
 global body
 assert body.count(old)==1
 body=body.replace(old,new);hooks.append((old,new))
insert('    // Create the occupancy','    a_.begin(this->owner());\n    // Create the occupancy')
insert('                    bool massChanged = collideParcels(dt, p1, p2, m1, m2);','                    ++a_.pairs; pair_=a_.pairs; decision_=merge_=false;\n                    bool massChanged = collideParcels(dt, p1, p2, m1, m2);')
insert('                }\n            }\n        }\n    }\n\n    // Remove','                    if(decision_){a_.log<<"{\\\"event\\\":"<<a_.updates<<",\\\"pair\\\":"<<pair_<<",\\\"type\\\":\\\"pair\\\",\\\"coalescence\\\":"<<(merge_?"true":"false")<<",\\\"before\\\":"<<pre_<<",\\\"after\\\":[";state(a_.log,p1);a_.log<<",";state(a_.log,p2);a_.log<<"]}\\n";}\n                }\n            }\n        }\n    }\n\n    a_.cleanup(this->owner());\n    // Remove')
insert('            this->owner().deleteParticle(p);','            a_.deletion(p);\n            this->owner().deleteParticle(p);')
insert('\n}', '\n    a_.end(this->owner());\n}')
restored=body
for old,new in reversed(hooks):restored=restored.replace(new,old)
assert restored==s[start:end]
(b/'tests/fiveEqORourkePopulation/nativeCollideInstrumented.H').write_text('namespace o1 {\nusing namespace Foam::constant::mathematical;\ninline void Probe::collide(Parcel::trackingData&td,scalar dt)\n'+body.replace(' = cbrt(', ' = Foam::cbrt(')+'\n}\n')
(e/'instrumentation_provenance.json').write_text(json.dumps({'nativeSourceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nativeBodyRecoveredExactlyAfterRemovingHooks':True,'probabilityAndRNGKernels':'delegated unchanged native collideParcels and collideSorted','hooks':hooks},indent=2))
