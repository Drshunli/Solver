from pathlib import Path
import shutil,struct,json,sys
b=Path(__file__).resolve().parents[1];s=b/'fitting/integration/m6b1_serial_dynamics_v1';root=s/'cases';root.mkdir(exist_ok=True)
mode=sys.argv[1] if len(sys.argv)>1 else 'gas'
def header(obj):return 'FoamFile {version 2.0; format ascii; class dictionary; object '+obj+';}\n'
def write(p,t):p.write_text(t,encoding='utf8',newline='\n')
fixtures=[]
for N in [100,200,400]:
 if mode=='gas':fs=[('gasPlus','acoustic',0.,0.,1,.0002),('gasMinus','acoustic',0.,0.,-1,.0002)]
 else:fs=[('liquidPlus','acoustic',-0.,0.,1,.0002),('mixed01','acoustic',.1,0.,1,.0002),('mixed05','acoustic',.5,0.,1,.0002),('mixed09','acoustic',-.1,0.,1,.0002),('traceLiquid','acoustic',1e-20,0.,1,.0002),('contact','contact',.1,47.,1,.00005),('speciesContact','speciesContact',.1,47.,1,.00005),('gasShock','gasRiemann',0.,0.,1,.0001),('materialRiemann','materialRiemann',.1,0.,1,.00008),('shockInterface','shockInterface',0.,0.,1,.00055),('gasBoost','acoustic',0.,2013.039,1,.0002),('contactBoost','contact',.1,2013.039,1,.00005)]
 for name,kind,p2,u,dr,end in fs:
  c=root/(name+'_'+str(N));(c/'system').mkdir(parents=True,exist_ok=False);(c/'constant').mkdir();(c/'0').mkdir()
  write(c/'system/controlDict',header('controlDict')+f'application rhosprayVoFDPMFoam; startFrom startTime; startTime 0; stopAt endTime; endTime {end:.17g}; deltaT 1; writeControl runTime; writeInterval {end:.17g}; purgeWrite 0; writeFormat binary; writePrecision 17; writeCompression off; timeFormat general; timePrecision 14; runTimeModifiable false;\n')
  write(c/'system/blockMeshDict',header('blockMeshDict')+f'''convertToMeters 1;
vertices ((0 0 0)(1 0 0)(1 1 0)(0 1 0)(0 0 1)(1 0 1)(1 1 1)(0 1 1));
blocks (hex (0 1 2 3 4 5 6 7) ({N} 1 1) simpleGrading (1 1 1)); edges ();
boundary (
left {{type cyclic; neighbourPatch right; transform translational; separationVector (1 0 0); faces ((0 4 7 3));}}
right {{type cyclic; neighbourPatch left; transform translational; separationVector (-1 0 0); faces ((1 2 6 5));}}
transverse {{type empty; faces ((0 1 5 4)(3 7 6 2)(0 3 2 1)(4 5 6 7));}}
); mergePatchPairs ();
''')
  write(c/'system/fvSchemes',header('fvSchemes')+'ddtSchemes {default Euler;} gradSchemes {default Gauss linear;} divSchemes {default none;} laplacianSchemes {default Gauss linear corrected;} interpolationSchemes {default linear;} snGradSchemes {default corrected;}\n')
  write(c/'system/fvSolution',header('fvSolution')+'solvers {}\n')
  constant='true' if kind in ['acoustic','gasRiemann','speciesContact'] else 'false'
  write(c/'constant/fiveEqBootstrap',header('fiveEqBootstrap')+f'verificationOnly true; DPM false; surfaceTension false; K 0; profile exactInitial; p 3000000; TG 800; TL 300; U ({u} 0 0); YG (0 .228 .772); dynamicDiagnostics true; constantP2 {constant}; snapshotEvery 10;\n')
  write(c/'constant/dynamicInitial',header('dynamicInitial')+f'N {N}; L 1; kind {kind}; p 3000000; TG 800; TL 300; U {u}; P2Bits "{struct.pack(">d",p2).hex()}"; amplitude 1e-6; direction {dr};\n')
  shutil.copyfile(b.parent/'300_2D/constant/thermal.dat',c/'constant/thermal.dat')
  fixtures.append(c.name)
(s/('fixture_'+mode+'.json')).write_text(json.dumps({'fixtures':fixtures,'scope':'same physical initial conditions, frozen strategy1/KT/P2/R1/joint CFL; no tuning'},indent=2))
commands='\n'.join('run_case '+name for name in fixtures)
script=r'''#!/bin/bash
source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
set -e
b=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam
s=$b/fitting/integration/m6b1_serial_dynamics_v1
run_case(){
 c="$s/cases/$1"
 timeout 60 blockMesh -case "$c" > "$c/log.blockMesh" 2>&1
 "$b/tests/fiveEqDynamicInitial/generateFiveEqDynamicInitial" "$c/constant/thermal.dat" "$c/constant/dynamicInitial" "$c/constant/fiveEqInitialState" > "$c/log.initial" 2>&1
 python3 - "$c" <<'INITIAL_DT'
from pathlib import Path
import json,re,sys
c=Path(sys.argv[1]);r=json.loads((c/'constant/fiveEqInitialState.reference.json').read_text())
dt=.15*(r['L']/r['N'])/(abs(r['U0'])+r['c'])
p=c/'system/controlDict';text=p.read_text();text=re.sub(r'deltaT 1;',f'deltaT {dt:.17g};',text);p.write_text(text)
INITIAL_DT
 set +e
 timeout 1800 "$FOAM_USER_APPBIN/rhosprayVoFDPMFoam" -serialFiveEq -case "$c" > "$c/log.solver" 2>&1
 code=$?
 echo "$code" > "$c/exit_status.txt"
 set -e
 if [ "$code" != 0 ]; then echo "STOP $1 exit=$code"; tail -30 "$c/log.solver"; exit "$code"; fi
 echo "normal exit $1"
 python3 - "$c" <<'GATE'
from pathlib import Path
import json,sys
c=Path(sys.argv[1]);r=json.loads((c/'fiveEqEvidence/dynamic_summary.json').read_text())
out=json.loads((c/'fiveEqEvidence/result.json').read_text());assert out['steps']>=10 and out['acceptedRecoveryFailures']==0,out
assert r['violations']==0 and r['pMin']>0 and r['activeRhoMin']>0,r
assert max(r['maxScaledConservation'])<1e-10,r
print(c.name,'R1',r['R1calls'],'failures',r['R1failures'],'pMin',r['pMin'])
GATE
}
'''+commands+'\n'
write(s/('run_'+mode+'.sh'),script)
print('Generated',len(fixtures),mode,'dynamic cases')
