from pathlib import Path
from decimal import Decimal as D,localcontext
import csv,json,math,hashlib
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2a_v1'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
normal=read(e/'thermal/thermal_results.json');boiling=read(e/'thermal_boiling/thermal_results.json')
assert normal['failures']==boiling['failures']==0
assert boiling['downstreamT']>boiling['downstreamLimit']
assert boiling['nativeBoilingEvent'] and boiling['nativeEventT']==boiling['downstreamT']
native_event_checks=0
for line in (e/'thermal_boiling/downstream.jsonl').read_text().splitlines():
 event=json.loads(line,parse_float=D)
 if event['type']!='pair':continue
 before,after=event['before'],event['after'];epsilon=D(2)**-52
 def close(x,y,scale=None):
  global native_event_checks
  u,v=scale if scale is not None else (abs(x),abs(y))
  assert abs(y-x)<=D('1e-30')+128*epsilon*(abs(u)+abs(v))
  native_event_checks+=1
 close(sum(p['mass'] for p in before),sum(p['mass'] for p in after))
 for j in range(len(before[0]['Y'])):
  close(sum(p['mass']*p['Y'][j] for p in before),sum(p['mass']*p['Y'][j] for p in after))
 for j in range(3):
  pp=[p['mass']*p['U'][j] for p in before];zz=[p['mass']*p['U'][j] for p in after]
  close(sum(pp),sum(zz),(sum(abs(x) for x in pp),sum(abs(x) for x in zz)))
 close(event['Ebefore'],event['Eafter'])
rows=list(csv.DictReader((e/'thermal/thermal_sweep.csv').open()))
assert len(rows)==3600
valid=[r for r in rows if r['Tnew']!='NaN'];rejected=[r for r in rows if r['Tnew']=='NaN']
assert len(valid)==3552 and len(rejected)==48
assert all(r['propertyDomain']=='OROURKE_ENERGY_UNBRACKETED_HIGH' for r in rejected)
assert all(float(r['diss'])>=0 for r in rows)
limits=[r for r in rows if r['p']=='3000000' and r['T1']==r['T2']=='300' and r['ratio']=='1']
reference_checks=0
with localcontext() as ctx:
 ctx.prec=80
 for r in valid:
  a=D('1e-12');z=a/D(r['ratio']);M=a+z;internal=D(r['EintBefore']);diss=D(r['diss'])
  for shift in (D('-1000000000'),D('-10'),D(0),D(10),D('1000000000')):
   # Exact reference-shift cancellation: no OF parameter is changed.
   shifted=(internal+M*shift+diss)/M-shift
   original=(internal+diss)/M
   assert abs(shifted-original)<D('1e-65')
   reference_checks+=1
def rho(T):return 60.94208835/.25745**(1+(1-T/617.7)**.28912)
def alpha(T):return -math.log(.25745)*.28912/617.7*(1-T/617.7)**(-.71088)
def cp(T):return 1958.18252099659-1.39094071757388*T+.00754612221948905*T*T
lo=243.51;upper=.999*617.7;lower_bound=1e99
while lo<upper:
 hi=min(upper,lo+.01)
 # Cp increasing; alpha/rho increasing on this subcritical interval.
 lower_bound=min(lower_bound,cp(lo)-12e6*alpha(hi)/rho(hi));lo=hi
assert lower_bound>0
o1_thermal={}
for s in 'ABC':
 p=e/f'O2_regression/{s}/scenario_7_ledger.json';a=read(p);ev=json.loads((p.parent/'scenario_7.jsonl').read_text().splitlines()[0])
 before,after=a['before'],a['after']
 o1_thermal[s]={'EintBefore':before['E'],'KEbefore':before['KE'],'Pbefore':before['P'],
  'KEafter':after['KE'],'dissipation':before['KE']-after['KE'],'Tnew':ev['after'][0]['T'],
  'EintAfter':after['E'],'totalEnergyResidual':after['E']+after['KE']-before['E']-before['KE'],
  'massResidual':after['m']-before['m'],'speciesResiduals':[y-x for x,y in zip(before['Y'],after['Y'])],
  'momentumResidual':[y-x for x,y in zip(before['P'],after['P'])]}
 assert a['sourceBefore']==a['sourceAfter']
reg={}
for folder in ('O1_regression','O2_regression','energy_regressions','rebinding','D_regressions','carrier_verified','support_regression','temporal'):
 ps=list((e/folder).rglob('test_results.json'));assert ps,folder
 values=[read(p) for p in ps];assert all(x.get('failures',0)==0 for x in values),folder
 reg[folder]={'files':len(ps),'checks':sum(x.get('checks',0) for x in values),'failures':0}
native=read(e/'support_regression/native_comparison.json');assert native['failures']==0;reg['support_regression']['checks']=native['checks']
goldens=list((e/'energy_regressions').rglob('golden_energy.csv'));assert len(goldens)==8
for p in goldens:assert p.read_bytes()==(b/'fitting/dpm/m8a3b_o2_v1'/p.relative_to(e)).read_bytes()
protected=read(e/'protected_before.json');changed=[rel for rel,h in protected.items() if sha(b/rel)!=h]
if 'MILESTONE_STATUS.md' in changed:
 before=e/'MILESTONE_STATUS.beforeO2A.md';assert sha(before)==protected['MILESTONE_STATUS.md']
 assert (b/'MILESTONE_STATUS.md').read_bytes().startswith(before.read_bytes());changed.remove('MILESTONE_STATUS.md')
assert not changed,changed
case=read(e/'case_before.json');assert all(sha(b.parent/'300_2D'/rel)==h for rel,h in case.items())
out={'O2AStatus':'PARTIAL / THERMALIZATION_MODEL_BLOCKER','physicalClassification':'C',
 'numericalAudit':'PASS','normal':normal,'boilingCounterexample':boiling,'uniqueSweepStates':3600,
 'nativeBoilingCounterexampleLedgerChecks':native_event_checks,
 'referenceShiftAlgebraChecks':reference_checks,'analyticEnergySlopeLowerBound':lower_bound,
 'zeroRelativeVelocitySequence':limits,'O1_thermal_replay':o1_thermal,'regressions':reg,
 'goldensByteIdentical':8,'protectedFilesAudited':len(protected),'activeSolverImpact':'NONE','caseFilesUnchanged':len(case),
 'T3BResumed':False,'noCFD':True,'firstActivationAllowed':False,
 'blocker':'Accepted thermalized state exceeds next native boiling-related TMax with phaseChange/heatTransfer none; no event phase-domain rejection.',
 'secondaryUnresolved':'Pressure-work semantics and surface/deformation-energy omissions not physically validated.'}
(e/'audit_summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ('zeroRelativeVelocitySequence','O1_thermal_replay')},indent=2))
