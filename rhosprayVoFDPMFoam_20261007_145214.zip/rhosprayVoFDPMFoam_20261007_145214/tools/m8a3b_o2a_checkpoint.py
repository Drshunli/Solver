from pathlib import Path
import json,hashlib,zipfile,sys
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2a_v1'
a=json.loads((e/'audit_summary.json').read_text());assert a['physicalClassification']=='C' and a['numericalAudit']=='PASS'
before=e/'MILESTONE_STATUS.beforeO2A.md'
if not before.exists():
 before.write_bytes((b/'MILESTONE_STATUS.md').read_bytes())
 with (b/'MILESTONE_STATUS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-02 M8A.3B-O2A

PARTIAL / THERMALIZATION_MODEL_BLOCKER; physical classification C.
Numerical caloric audit PASS:3600 unique conditioned-merge states,3552 roots,
48 controlled high-energy rejections; another48 accepted roots meet boiling
criterion at low pressure. Native API monotonic/roundtrip/composition/limits
and10000 deterministic inversions checked, with original O2 budget.
Stronger actual unmodified native-probability O2 collision reached486.41247553K
at188330.307Pa; next ordinary update sets boiling-relatedTMax473.49379916K
but none heat/phase retains that temperature. Finite API is not physical-domain
certification; no first-activation approval. Complete pair ledger retained.
O1 349/O2 27420 and all mandatory frozen regression groups PASS;8 goldens
byte-identical. Historical O1 identity defect/O2 modeled-closure scope preserved.
Active solver/source adapter and96 actualcase files unchanged. NoCFD.
T3B remainsPARTIAL/BLOCKED; T3PARTIAL; T4NO; M8APARTIAL; M6B.0/1NO.
Next work must remainO2A: pressure/composition-dependent phase admissibility
and explicit pressure-work/thermalization contract, then replay; no clipping,
fraction tuning, immediate evaporation or residual reservoir added this turn.
See M8A3B_O2A_THERMALIZATION_PHYSICAL_GATE.md and fitting/dpm/m8a3b_o2a_v1.
STOP this turn; no T3B resumption.
''')
print('O2A PARTIAL milestone appended with original prefix preserved.')
if '--pack' in sys.argv:
 dest=b/'checkpoints/M8A3B_O2A_thermalization_v1_PARTIAL_BLOCKER.zip';assert not dest.exists()
 paths=[]
 for root in (e,b/'tests/fiveEqORourkeThermal'):
  for p in root.rglob('*'):
   rel=p.relative_to(b)
   if 'lnInclude' in rel.parts or ('Make' in rel.parts and p.name not in ('files','options')):continue
   if p.name=='core' or p.name.startswith('core.') or p.name=='testFiveEqORourkeThermal':continue
   if p.is_symlink() or not p.is_file():continue
   paths.append(p)
 paths+=list((b/'tools').glob('m8a3b_o2a_*.py'))
 paths.extend((b/'M8A3B_O2A_THERMALIZATION_PHYSICAL_GATE.md',b/'MILESTONE_STATUS.md'))
 manifest={str(p.relative_to(b)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in paths:z.write(p,str(p.relative_to(b)).replace('\\','/'))
  z.writestr('O2A_CHECKPOINT_MANIFEST.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  assert all(hashlib.sha256(z.read(rel)).hexdigest()==h for rel,h in manifest.items())
 out={'status':'PARTIAL / THERMALIZATION_MODEL_BLOCKER','classification':'C',
  'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(paths),'bytes':dest.stat().st_size,
  'manifestAndCRCVerified':True,'excluded':'build objects/executable/core dumps; logs and intermediate attempts retained',
  'activeSolverImpact':'NONE','T3BResumed':False,'noCFD':True}
 dest.with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
