from pathlib import Path
import re,difflib,json,hashlib
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a2_v1';old=b/'fitting/dpm/m8a1_v1/source_audit';new=e/'native_sources';local=b/'tests/fiveEqDPMTransaction/nativePassiveOverrides.H';s=local.read_text()
def body(text,needle):
 at=text.index(needle);start=text.rfind('\ntemplate',0,at)+1
 if text[max(0,start-35):start].strip().endswith('template<>') or re.search(r'template<class \w+>\s*$',text[max(0,start-40):start]):start=text.rfind('\ntemplate',0,start-1)+1
 brace=text.index('{',at);i=brace+1;depth=1
 while depth:depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[start:i]
specs=[
 ('lagrangian/basic/Cloud/CloudIO.C','void Foam::Cloud<ParticleType>::readCloudUniformProperties','void Foam::Cloud<Foam::basicSprayParcel>::readCloudUniformProperties'),
 ('lagrangian/intermediate/submodels/CloudFunctionObjects/VoidFraction/VoidFraction.C','void Foam::VoidFraction<CloudType>::write','void Foam::VoidFraction<Foam::basicSprayCloud::kinematicCloudType>::write'),
 ('lagrangian/intermediate/submodels/Kinematic/InjectionModel/InjectionModel/InjectionModel.C','void Foam::InjectionModel<CloudType>::inject\n','void Foam::InjectionModel<Foam::basicSprayCloud::kinematicCloudType>::inject'),
 ('lagrangian/intermediate/parcels/Templates/KinematicParcel/KinematicParcel.C','void Foam::KinematicParcel<ParcelType>::setCellValues','void Foam::KinematicParcel<Foam::particle>::setCellValues'),
 ('lagrangian/intermediate/clouds/Templates/KinematicCloud/KinematicCloud.C','void Foam::KinematicCloud<CloudType>::postEvolve','void Foam::KinematicCloud<Foam::Cloud<Foam::basicSprayParcel>>::postEvolve'),
 ('lagrangian/intermediate/submodels/CloudFunctionObjects/CloudFunctionObject/CloudFunctionObject.C','void Foam::CloudFunctionObject<CloudType>::postEvolve','void Foam::CloudFunctionObject<Foam::basicSprayCloud::kinematicCloudType>::postEvolve')]
out=[];manifest=[]
for path,orig,target in specs:
 p=new/path
 if not p.exists():p=old/path
 a=body(p.read_text(),orig);z=body(s,target)
 out.extend(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='OF7/src/'+path,tofile=str(local)))
 manifest.append({'originalFile':'/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src/'+path,'function':orig,'localFile':str(local),'originalSHA256':hashlib.sha256(p.read_bytes()).hexdigest()})
(e/'project_local_overrides.diff').write_text(''.join(out))
(e/'override_manifest.json').write_text(json.dumps(manifest,indent=2))
