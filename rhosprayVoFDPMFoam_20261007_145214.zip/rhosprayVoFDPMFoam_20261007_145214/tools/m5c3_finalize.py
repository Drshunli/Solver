from pathlib import Path
import hashlib,json,csv,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/integration/m5c3_v1'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def write(p,data):p.write_bytes((json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode())
contract=read(e/'contract/test_results.json');oldtime=read(e/'oldtime/test_results.json')
assert contract['failures']==oldtime['failures']==0
assert (e/'compile_exit.txt').read_text().strip()=='0'
assert (e/'oldtime_compile_exit.txt').read_text().strip()=='0'
expected=read(b/'fitting/reconstruction/m5c2d_v1/assessment_results.json');d_results={}
for name,value in expected.items():
    actual=read(e/'D_regressions'/name/'test_results.json')
    assert actual==value,(name,actual,value)
    assert (e/'D_regressions'/name/'exit_status.txt').read_text().strip()=='0'
    d_results[name]=actual
regressions={}
for p in sorted((e/'regressions').iterdir()):
    if not p.is_dir():continue
    code=int((p/'exit_status.txt').read_text())
    historical=p.name.startswith('historical_B')
    assert code==(1 if historical else 0),(p.name,code)
    result=p/'test_results.json'
    if p.name=='OF7_actual_interpolation':result=p/'of7_interpolation.json'
    data=read(result)
    if historical:assert data['failures']==(26 if p.name.endswith('100') else 14)
    else:assert data.get('failures',data.get('totalFailures',data.get('implementation_failures',0)))==0
    regressions[p.name]={'exit':code,'status':'EXPECTED HISTORICAL FAILURES REPRODUCED' if historical else 'PASS','result':data}
orders=list(csv.DictReader((e/'D_regressions/ordering/long_profiles.csv').open()))
worst=max(float(r['pRelative']) for r in orders if r['strategy']=='1');assert worst<1e-8
continuation=list(csv.DictReader((e/'contract/continuation.csv').open()))
assert len(continuation)==4 and all(r['bitwiseEquality']=='1' for r in continuation)
assert int(continuation[0]['rejected'])>0
gates=[
'actual legacy temporal order audited','fiveEq stage ordering frozen','coherent stage-state ownership frozen','dt retry semantics frozen','P2 oldTime semantics frozen','P2 restart roundtrip PASS','trace state survives restart','restart versioning implemented','legacy-restart conversion policy frozen','P2 communication pack/unpack PASS','boundary state builder implemented','pure-gas BC state PASS','pure-liquid BC state PASS','mixed BC state PASS','liquid mass-flow/TL inlet contract frozen','inlet pressure not overconstrained','gas inflow/outflow semantics audited','wall/symmetry/empty semantics frozen','boundary recovery PASS','initialization builder PASS','runtime initialization uses production EOS only','future startup field list frozen','derived fields non-authoritative','complete source ownership audit done','chemistry-energy ownership closed or explicit pre-M6B blocker','DPM interface frozen for M8A','synthetic temporal driver PASS','continuous vs restart continuation equivalence PASS','retry/restart integrity PASS','pressure-contact 1e-8 regression PASS','all M5C.2D regressions PASS','active solver physics unchanged','no CFD run']
assert len(gates)==33
energy=b/'ENERGY_REFERENCE_AUDIT.md'
addition='''\n## M5C.3 temporal/source ledger audit (2026-10-01, NOT ACTIVE)\n\nThe local Foundation7 StandardChemistryModel::Qdot implementation is -sum(Hc_i*RR_i), while laminar::R(Yi) supplies RR_i and its correct() integrates/calculates chemistry before legacy species solves. noCombustion::R/Qdot are zero; the current three-species case has no enabled reactions. Gas Es=Hs-p/rho and Hs=Ha-Hc remain unchanged. Future bulk gas species source S_i must pair Et_sens source -sum(Hc_i*S_i), preserving Et_sens+sum(mYi*Hc_i) for a closed mass-conserving chemistry substep. Intrinsic gas-volume rates require alphaG conversion once; already bulk-integrated rates must not be weighted again. A passive actual-Hc identity test passes, including trace weighting. This does not validate reaction integration or transport.\n\nThe future source stage must recover a complete new Q/P2 tuple and reject it atomically on failure. Reactive activation is a PRE-M6B BLOCKER until a real mechanism, gas-state rate/volume adapter and coupled source-step tests exist; otherwise chemistry-on is explicitly rejected. DPM hsTrans remains an enthalpy transfer ledger, not automatically Et; pressure work, mass/kinetic/drag work and DPM-to-production liquid reference/caloric mapping belong to mandatory M8A. No q, gas JANAF zero, production liquid offset, recovery numerical order or active source placement changed. See docs/FIVE_EQ_SOURCE_OWNERSHIP_AUDIT.md.\n'''
if '## M5C.3 temporal/source ledger audit' not in energy.read_text(encoding='utf8'):energy.write_bytes((energy.read_text(encoding='utf8')+addition).encode())
milestone=b/'MILESTONE_STATUS.md';s=milestone.read_text(encoding='utf8')
s=s.replace('| M5C.3 | **ELIGIBLE FOR NEXT REQUEST / NOT STARTED** | Standalone M5C.2 closed; future temporal/boundary/startup/restart gate remains unimplemented. |','| M5C.3 | **COMPLETE / STANDALONE CONTRACT / NOT ACTIVE** | 33 gates; exact-bit restart, actual OF7 oldTime, coherent BC/init, retry/continuation, source audit and all frozen D regressions PASS. See M5C3_TEMPORAL_BOUNDARY_RESTART_GATE.md. |')
s=s.replace('| M8A | **BLOCKED / NOT STARTED** | Conservative DPM source adapter comes after M5C.3; existing cloud/source placement unchanged. |','| M8A | **ELIGIBLE FOR NEXT USER REQUEST / NOT STARTED** | M5C.3 standalone complete; conservative gas-carried parcel mass/momentum/Et/species and rollback/reference adapter is mandatory before M6B. |')
milestone.write_bytes(s.encode())
before=read(e/'protected_before.json');changed=[];unchanged=0
for name,h in before.items():
    p=b.parent/name if name.startswith('300_2D\\') or name.startswith('300_2D/') else b/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:changed.append(name)
    else:unchanged+=1
assert set(changed)=={'ENERGY_REFERENCE_AUDIT.md','MILESTONE_STATUS.md'},changed
write(e/'protection_check.json',{'before_count':len(before),'unchanged':unchanged,'authorized_document_updates':changed,'active_solver_physics_unchanged':True,'frozen_EOS_recovery_P2_KT_unchanged':True,'case_unchanged':True})
write(e/'assessment_results.json',{'contract':contract,'actual_OF7_oldTime':oldtime,'D_regressions':d_results,'frozen_regressions':regressions,'contact_worst':worst,'continuation':continuation})
result={'milestone':'M5C.3','status':'COMPLETE / STANDALONE CONTRACT / NOT ACTIVE','gates':{g:'PASS' for g in gates},'selected_reconstruction':'R1-P2-residualSpecies-v1','alpha_DOF':1,'restart':'fiveEqRestart-v1 / P2-v1 / binary64-hex-msb','M8A':'ELIGIBLE FOR NEXT USER REQUEST / NOT STARTED','M6B':'NO / BLOCKED','CFD_run':False,'active_solver_impact':'NONE','limitations':['Actual new patch/decomposition/field wiring unactivated','Fixed-mesh periodic Euler synthetic driver; no source/RK/LTS/AMR/ALE time driver','M8A parcel conservation/energy/reference/rollback adapter mandatory','Reactive-on and viscous/thermal/turbulence source adapters are pre-enable blockers','Atomic partition/mesh/parcel checkpoint publishing and configuration fingerprint wiring remain activation plumbing','Ordinary OF7 ASCII P2 restart prohibited, including17 digits','Finite sampled dtThermo admissibility is not a continuum theorem','No universal compiler/horizon/contact-margin guarantee']}
write(e/'milestone_result.json',result)
report=f'''# M5C.3 — temporal / BC / initialization / restart / activation-readiness gate

Date:2026-10-01. Scope: passive/standalone only. No CFD, no M8A, no M6B. Tests use installed Foundation7, production ndecane_gibbs_v1 and actual JANAF/perfectGas gas evaluator. Original numerical modules unchanged.

# 1. M5C.3 status

**COMPLETE / STANDALONE CONTRACT / NOT ACTIVE**,33/33 scoped gates. This does not claim production patch integration or permission to run the coupled solver. Machine record: fitting/integration/m5c3_v1/milestone_result.json.

# 2. Legacy temporal audit

See LEGACY_TEMPORAL_ORDER_AUDIT.md. Actual alpha→interface/diagnostics→parcels.evolve→rho→rhoU→rhoY/reaction→rhoE/thermo→turbulence→write. Non-LTS adjusts dt using previous Co before new face reconstruction; actual case Euler. Lazy OF7 oldTime and mesh/time order audited in installed source. Legacy case gas inlet differs from locked engineering scenario and lacks0/alphaL.

# 3. Frozen fiveEq stage ordering

Committed Qn/P2→whole-cell recovery→preliminary dt constraints→R1 reconstruction→face recovery→one shared KT flux→flux-dependent algebraic bounds/nonconservative alpha source→complete conservative/P2 trial→whole trial recovery→accept/reject. Flux-dependent bounds necessarily refine after flux construction. Source stages, if later enabled, precede atomic commit and undergo full-state recovery.

# 4. State ownership per stage

Authoritative tuple:P2,mG,mL,M,Et,mYi plusgeometry/time. q[0]/alphaL/alphaG/rhoMix/U/Y are derived; p/T/phase rho/c are recovered caches of that same generation. No old pressure authority combined with new conserved fields. See FIVE_EQ_FIELD_OWNERSHIP_FINAL_v3.md; historical v2 unchanged.

# 5. dt/retry contract

min of acoustic,alpha,phase-mass,species,volume/user bounds; frozen .95 positivity factors. Interior-invalid proposal refines frozen connected thermo dt and retries from identical Qn. Atomic commit only after all trials valid. Certified high-only boundary exhaustion permits whole-flux R0 rollback; high+low outward stops. Uncertified zero connected dt stops requesting classification. No commit-and-repair or positive floor.

# 6. P2 oldTime contract

Exact signed coordinate in every level, including−0. Actual installed OF7 GeometricField oldTime test: **{oldtime['checks']} checks,0 failures**. Both trace sides 1e-8/1e-12/1e-16/1e-20 and pure/half states; restore→update exact. Synthetic old tuple/clock immutable through failed proposals.

# 7. P2 restart serialization

Actual Foam scalarField streams: ASCII6 loses5/16 payload bits; ASCII17 loses1/16 (−0→+0); binary local DP loses0. Chosen explicit16-hex-digit IEEE binary64 record stores all Q/P2,oldTime,volumes,time and metadata/checksum. Ordinary ASCII P2 restart is prohibited.

# 8. Restart trace preservation

Both minority sides survive exact IO and continuation,including1e-20. Dominant decoded alpha may remain1; it is never serialized as fraction authority. Pure liquid−0 and both half-state branch signs preserved.

# 9. Restart versioning

Implemented header:fiveEqRestart-v1/P2-v1/binary64-hex-msb/ndecane_gibbs_v1/runtime species signature. UnknownP2 version with recomputed valid checksum still rejected; corrupt checksum and wrong species rejected. Full committed/old tuple recovered before returning. FNV64 detects accidental corruption only.

# 10. Legacy restart policy

Reject alphaL-only/gas-only records as non-fiveEq restart. Any explicitly requested cold conversion must acknowledge irreversible trace loss and generate complete Q from physical inputs/EOS. It is not implemented as an automatic restart fallback.

# 11. P2 communication test

Eight-byte network-order pack/unpack preserves exact signed bits. Three offline partitions written,destroyed,reloaded and merged using known addressing: exact Q/P2/old/time equality. No MPI CFD,decomposePar or reconstructPar execution. Their future hooks must carry exact authority/global IDs,not ordinary alpha output.

# 12. Boundary builder API

fiveEqBoundaryStateBuilder::build(BoundaryPrimitive)→PrecisionCell; recoverBoundaryState→P2-aware recovery. Explicit commonp/U,phaseT,canonicalY andP2. Reflected/orthogonal transformed ghost helpers included. Invalid state is failure,not clamp. State builder is not a characteristic patch implementation.

# 13. Pure-gas boundary result

Actual OF7 gas p/T/Y→rho/e→Q recovery PASS; no hardcodedgamma/Rair. P2+0,mL0,mG=rhoG,Et=mG eG+kinetic,speciesclose.

# 14. Pure-liquid boundary result

Production EOS p/TL→rho/e→Q recovery PASS; P2−0,mG/species0. This is a state constructor test,not the mass-flow inlet BC.

# 15. Mixed boundary result

Commonp/U with independentTG400/TL300,widealpha/trace states,p0.1/3/8MPa,U0/47/2013.039 and transversevelocity PASS. Constructor matrix144 states. No shared gas/liquidT assumption.

# 16. Liquid injection BC contract

One .3mm roundhole,mdot1.09609e-4kg/s,TL300. Responding p andun determined jointly by integrated KT liquid flux and outgoing acoustic compatibility. 3MPa initialreference,not independent pressure Dirichlet. Production reference velocity sanity≈2.1316743m/s,not activeBC. 2D depth/represented-flow conversion must be explicitly defined. Full patch characteristic solve is not implemented.

# 17. Gas inflow/outflow contract

Audit un±cMix relative to patch/mesh. Supersonic inflow supplies all independent state data;supersonic outflow extrapolates complete Q. Subsonic inflow uses incoming material/thermal/tangential data plus one acoustic constraint/outgoing compatibility; subsonic outflow one incoming acoustic condition. Do not copy pressure-based p/T/U combinations without characteristic count.

# 18. Wall/symmetry contract

Copy scalar/P2 data;reflect normalM,zero normal material/energy flux,retain pressuretraction. empty suppresses nonphysicaldimension;wedge/coupled transforms rotateM,copyP2 bits,Et invariant under coordinate rotation. Reflection/orthogonal transform tests PASS. Viscous wall/thermal/contact-angle adapters need their specific closures before enablement.

# 19. Boundary recovery result

All constructed Q recover using exact P2,phase masses/species andEt. Invalid TL/energy rejected. No pressure,alpha or EOS clamp. Inheritedp1e-8,T1e-8,U1e-7,Y1e-12 checks; root/evaluation order unchanged.

# 20. Initialization API

fiveEqInitialStateBuilder uses same coherent constructor. Cold start from physical primitives/material specification;assignold=initialcommitted onlyafterwhole-state recovery. Legacyrho/rhoE cannot be independently mixed withalpha.

# 21. Initial gas state

p188330.307Pa,T400K,Y=(0,.228,.772) gives actual OF7rho1.63268590011162kg/m³,eG−11812.9587301765J/kg. Nominal1.6338 is not independently enforced. Actual stored300_2D case remains different and unchanged.

# 22. Initial liquid state

Production p3MPa,T300K givesrho727.432960545318kg/m³,eL_solver−66.4153259710411J/kg. Negative sensible energy is legal under the frozen reference. No CoolProp initialization.

# 23. Initialization roundtrip

Pure/mixed/trace/fullspeed constructor and recovery matrix PASS; gas/liquidpresent testsandruntimeY closure. Together with temporal/IO/boundary tests:**{contract['checks']} checks,0 failures** in the final harness.

# 24. Future startup fields

Normative exact bundle MUST_READ on restart; physical initialconfiguration MUST_READ on coldstart. RuntimeP2/Qfields constructedfromsingleauthority;standardoutputs notindependentrestartsources. Mesh/thermo/speciesconfiguration MUST_READ andconsistent. See docs/FIVE_EQ_INITIALIZATION_CONTRACT.md for NO_READ/AUTO_WRITE/optional diagnostic READ_IF_PRESENT policy.

# 25. Derived-field restart policy

p/TG/TL/rhoG/rhoL/rhoMix/c/U/Y/decodedalpha have no restartauthority. Optionalold diagnosticoutputs may onlybe compared/replaced by recovery; neveralterQ.

# 26. Source ownership audit

Complete table in docs/FIVE_EQ_SOURCE_OWNERSHIP_AUDIT.md coversconvection/pressure,stress/work,heat/speciesdiffusion,chemistry,turbulence,fvOptions,radiation,gravity,parcelmass/momentum/enthalpy/species andcapillarity. Active fvOptionscallsabsent;somegravity/parcelheat termscurrentlyonlyviscousbranch. No "same aslegacy" futuretarget ambiguity.

# 27. Chemistry-energy audit

Installed JANAF Es=Hs−p/rho,Hs=Ha−Hc;StandardChemistryModelQdot=−ΣHc RR. Future S_mYi andEtchemicalsourcepaired,conservingEt_sens+ΣmYiHc inaclosedmass-conservingsubstep. Actual-Hc passiveidentityPASS. Currentnone/emptymechanismzeroledgerclosed. Reactive-on adapter/mechanism/source-recovery/diffusiontestingexplicit PRE-M6B blocker; do not claimreactingactivationvalidated.

# 28. DPM future source contract

M8A ownsparcelmass→mG,parcelmomentum→M,parcelenergy→Et,species→mYi;equal/oppositeledger,onevolume/dtnormalization,gascarrier sampling androllback/reference/kineticwork/P2response closure. CloudSh is not automaticallyEt. No implementation thisround.

# 29. Surface-tension source status

M7futuremomentumandpairedEtwork/interfaceenergyowner. Currentforceonlydiagnostic;unchanged. No capillary activation.

# 30. Temporal/source ordering

Futureflux→recover→explicitlytypedsource-stage(s)→whole-Qrecovery→atomiccommit. Unsupportedreactive/viscous/thermal/turbulence/radiation/capillarymodesmustbe rejectedbeforeenabled,not silentlyinheritprimitiveoverwrites. Parcelstagemustberollback-safe underM8A. Currentstandalonedriverzero physicalsources.

# 31. Synthetic temporal driver

R1-P2-residualSpecies-v1 fixed-meshperiodicEuler,realEOS,wholeQrecovery,currentbounds,trial/retry/commit andIO. Fourprofiles100 acceptedstepseach:sharpcontact,tracegas,traceliquid,halfbranch. No CFD case/PDEsolverrun.

# 32. Restart-continuation result

Continuous100 vs50+write+destroy+reload+50: **4/4 bitwise equality** forP2,masses,M,Et,species,oldTime,volumes,time/dt/step. Maxsyntheticcontactpressureerror≈2.34799e-11.

# 33. Retry/restart integrity

Deliberateactualoversizedtrial rejectedonce,thenacceptedfromoriginalanchor;restartcontinuationidentical. Invalidanchorcontrolledstop leavescommitted/old/timeunchanged. Trialbuffersnotserialized.

# 34. P2 branch-switch restart result

Explicitrestartimmediatelybefore/afteractual .5branchswitch,thencontinue:bitwisePASS.100-stepbranchprofileswitchandpressurecontinuityPASS. No alpha decode/reencode.

# 35. Pressure-contact worst-case regression

Frozen1000-stepmovingcontactR1,baseline/O0≈9.832876846e-9;alternative ordering worst **{worst:.17g}<1e-8**. Gateunchanged;~1.4488% worstmargin. No solver/root/energyreference/decoding/evaluation-order modification. No extrapolated compiler/horizon guarantee.

# 36. Frozen regression status

All11 accepted D groups matchpreviousmachine results exactly;fullrecovery/bridge/flux/admissibility/C1/fixedspecies/actualOF7interpolationregressionsPASS. HistoricalB original14facefailures and26 auditfailures reproduced as expectednegativecontrols,notnewfailures. Alloutputs are innewm5c3_v1directories; historicalevidenceunchanged. Performance reruncostsamplesundercorrectnessscopearenotnewthroughputclaims.

# 37. Added files

fiveEqIntegration/fiveEqTemporalContract.H,fiveEqBoundaryStateBuilder.H,fiveEqInitialStateBuilder.H,fiveEqP2IO.H,fiveEqSourceOwnership.H;two standalone testtargets;LEGACY_TEMPORAL_ORDER_AUDIT.md;five docs contracts/audits;ownershipv3;thisreport;reproducibility tools/new evidence. ENERGY_REFERENCE_AUDIT.md andMILESTONE_STATUS.md append/update only. No activeMake/library source change.

# 38. Compile status

Foundation7 C++11/-Werror **PASS** fornewtemporalandactualoldTime targets. Initialmisleading-indentationcompileerrorsfixedinnewheaders;initialASCII17 assumed-lossless testfailurepreservedthenreplacedbyexplicitprohibition. No frozen numericaltolerancechange. Installed EOS/thermo library SHA256 identicalto D. Finalcompilelogsretained. Oldactive solvernot rebuilt/activatedthisround.

# 39. Active solver impact

**NONE.** {unchanged}/{len(before)} protectedfilesunchanged;theonly2changedexistingfilesareauthorizedenergy/milestone documents. Main/equations/alpha/KT/timestep/cloud/case/frozenEOS/P2/recoveryunchanged. No activecallto newmodules,noCFD.

# 40. Remaining blockers

MandatoryM8Aadapter;actualregistry/patch/characteristic/decomposition/atomic checkpointwiring;explicit2D injectionrepresentation;reaction/viscous/heat/species/turbulencesourceadaptersbeforethosemodes;source/parcelrollbackandenergyreferenceclosure. Thesearefutureactivationwork,notclaimedcompletedbythestandalonecontractgate. Fixed-domainEOSlimitsandfinite-sampleadmissibility/marginsremain.

# 41. M8A start permission

**Eligible for next user request / NOT STARTED.** ScopeofthisrequestendsatM5C.3;no automaticM8Aexecution.

# 42. M6B permission

**NO / BLOCKED.** M8A COMPLETE andallfrozenM5C/M6Agatesrecheckedaremandatory;standaloneM5C.3completionisnotatomicactivationpermission.

# 43. Updated milestone matrix

| Stage | Status |
|---|---|
|M0–M4|COMPLETE;activelegacyunchanged|
|M5A/M5B|COMPLETE / ACTIVE REFERENCE/DESIGN|
|M6A productionEOS/recovery|existingfrozencompletionretained|
|M5C.1/M5C.2A/M5C.2C.1/M5C.2D|COMPLETE / frozenstandalone|
|M5C.2|COMPLETE / STANDALONE|
|M5C.2C.2|NOT REQUIRED BY CURRENT EVIDENCE / NOT STARTED|
|M5C.3|COMPLETE / STANDALONE CONTRACT / NOT ACTIVE|
|M8A|ELIGIBLE FOR NEXT USER REQUEST / NOT STARTED|
|M6B|NO / BLOCKED|
|M7|NOT STARTED|

**STOP at M5C.3. No M8A, no M6B, no CFD.**
'''
(b/'M5C3_TEMPORAL_BOUNDARY_RESTART_GATE.md').write_bytes(report.encode())
print('M5C.3 verified:',contract,oldtime,'protected',unchanged,'worst',worst)
