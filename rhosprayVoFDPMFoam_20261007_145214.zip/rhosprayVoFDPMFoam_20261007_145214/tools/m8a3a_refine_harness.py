from pathlib import Path
p=Path(__file__).resolve().parents[1]/'tests/fiveEqDPMRebinding/testFiveEqDPMRebinding.C'
s=p.read_text()
start=s.index(' // Lifecycle seed')
end=s.index(' std::ofstream result',start)
block=s[start:end].replace(' // Lifecycle seed is the current evolved state (S+10) pending exact S replay.',' // Repeated construction uses the exact native A/B/C seed, before future evolution.')
block=block.replace('for(unsigned i=0;i<1000;++i)','const unsigned cycles=std::getenv("M8A3A_CYCLES")?std::stoul(std::getenv("M8A3A_CYCLES")):1000;\n time.setDeltaT(1e-12);\n for(unsigned i=0;i<cycles;++i)').replace('i==999','i+1==cycles')
block+=' time.setDeltaT(1e-6);\n'
s=s[:start]+s[end:]
s=s.replace(' std::unique_ptr<m8a3a::ReconstructedCloud> trial;',block+' std::unique_ptr<m8a3a::ReconstructedCloud> trial;')
s=s.replace('if(argc!=3)return 2;const std::string','if(argc!=3)return 2;\n const std::string')
p.write_bytes(s.encode())
