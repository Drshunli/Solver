from pathlib import Path
import os,json,hashlib,shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3_v1'
if e.exists():raise SystemExit('M8A.3 evidence directory already exists; do not overwrite.')
e.mkdir(parents=True)
manifest={}
for root,dirs,names in os.walk(b):
 dirs[:]=[n for n in dirs if n not in ('lnInclude','Make','linux64GccDPInt32Opt','.git','m8a3_v1')]
 for name in names:
  p=Path(root)/name
  if p.is_symlink():continue
  try:manifest[p.relative_to(b).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
  except OSError:continue
(e/'protected_before.json').write_text(json.dumps(manifest,indent=2))
t=b/'tests/fiveEqDPMEvolvedAudit';(t/'Make').mkdir(parents=True)
for n in ('files','options'):
 (t/'Make'/n).write_bytes((b/'tests/fiveEqDPMProduction/Make'/n).read_bytes().replace(b'testFiveEqDPMProduction',b'testFiveEqDPMEvolvedAudit'))
fixture=t/'fixture'
for n in ('0','constant','system'):shutil.copytree(b/'tests/fiveEqDPMTransaction/fixture_noWrite'/n,fixture/n)
reg=(b/'fitting/dpm/m8a_v1/run.sh').read_text().replace('fitting/dpm/m8a_v1/','fitting/dpm/m8a3_v1/energy_regressions/')
(e/'run_energy_regressions.sh').write_bytes(reg.encode())
reg=(b/'fitting/dpm/m8a_v1/run_frozen_regressions.sh').read_text().replace('fitting/dpm/m8a_v1/D_regressions','fitting/dpm/m8a3_v1/D_regressions')
(e/'run_frozen_regressions.sh').write_bytes(reg.encode())
header='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\n'
(e/'build_run.sh').write_bytes((header+'set -e\ncd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMEvolvedAudit\nwmake > ../../fitting/dpm/m8a3_v1/log.wmake 2>&1\ncd ../../fitting/dpm/m8a3_v1\n../../../tests/fiveEqDPMEvolvedAudit/testFiveEqDPMEvolvedAudit /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMEvolvedAudit/fixture > log.evolved_audit 2>&1\n').encode())
(e/'run_temporal.sh').write_bytes((header+'set -e\nmkdir -p /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3_v1/temporal\ncd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3_v1/temporal\n/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqTemporalContract/testFiveEqTemporalContract /mnt/d/DATA/Solver/300_2D/constant/thermal.dat /mnt/d/DATA/Solver/300_2D/constant/reactions > log.run 2>&1\n').encode())
