#!/bin/bash
src=/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src
find "$src/finiteVolume" -name 'volPointInterpolation*' -o -name 'interpolationCellPoint*'
cat "$src/finiteVolume/interpolation/volPointInterpolation/volPointInterpolation.H"
cat "$src/finiteVolume/interpolation/volPointInterpolation/volPointInterpolation.C"
