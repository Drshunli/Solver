"""Immutable S2 evidence seal; no runtime or physics action."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/dpm/m8a3b_t4_s2_final_seal_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_text())
gate=j(s/'S2_FINAL_gate.json');assert gate['status']=='COMPLETE / FROZEN' and gate['failed']==[]
assert gate['newPhysicsRuns']==gate['newCompilations']==0
matrix=j(s/'T4_S2_FINAL_AUTHORITY_MATRIX_v1.json');assert len(matrix)==36 and all(x['verdict']=='PASS' for x in matrix)
for row in matrix:
 for e in row['evidence']:assert sha(Path(e['path']))==e['sha256'],e
before=j(s/'frozen_before.json');allowed={'rhosprayVoFDPMFoam/MILESTONE_STATUS.md'}
delta=[k for k,h in before.items() if not (root/k).is_file() or sha(root/k)!=h]
assert set(delta)==allowed,delta
milestone=b/'MILESTONE_STATUS.md';old=j(s/'milestone_before_sha.json')
assert hashlib.sha256(milestone.read_bytes()[:old['bytes']]).hexdigest()==old['sha256']
closing={'priorProtectedEntries':len(before),'priorUnchanged':len(before)-len(delta),'authorizedChanges':delta,'unexpectedChanges':[],'milestoneAppendOnly':True,'newRuntimeDelta':[],'newPhysicsRuns':0,'newCompilations':0,'activeImpact':'NONE','productionImpact':'NONE','mandatoryPASS':36,'mandatoryOPEN':0}
(s/'protected_closing_audit.json').write_text(json.dumps(closing,indent=2))
files={p for p in s.rglob('*') if p.is_file() and p.name not in ['frozen_after.json','checkpoint_manifest.json','checkpoint_seal.json']}
files.update([b/'T4_S2_FINAL_AUTHORITY_MATRIX_v1.md',b/'T4_S2_FINAL_SEAL_REPORT_v1.md',milestone,b/'tools/aggregateT4S2FinalSeal.py',b/'tools/reportT4S2FinalSeal.py',Path(__file__).resolve()])
# Preserve the four immutable authoritative archives inside the aggregate ZIP.
for v in gate['parentArchives'].values():
 p=Path(v['archive']);assert sha(p)==v['sha256'];files.add(p)
chain=j(s/'common_source_chain.json')
for v in chain['chain']:
 p=Path(v['archive']);assert sha(p)==v['archiveSHA256']==v['expectedSHA256']
common=j(s/'common_source_current_hashes.json')
for k,h in common.items():assert sha(root/k)==h;files.add(root/k)
for k,v in j(s/'active_source_audit.json').items():assert sha(root/k)==v['historical']==v['current'];files.add(root/k)
manifest={p.relative_to(root).as_posix():sha(p) for p in sorted(files)}
mf=s/'checkpoint_manifest.json';mf.write_text(json.dumps(manifest,indent=2));files.add(mf)
archive=root/'checkpoints/M8A3B_T4_S2_FINAL_SEAL_COMPLETE_FROZEN_v1.zip';assert not archive.exists(),'refuse checkpoint overwrite'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for p in sorted(files):f.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as f:
 assert f.testzip() is None
 assert len(f.namelist())==len(set(f.namelist()))
 for k,h in manifest.items():assert hashlib.sha256(f.read(k)).hexdigest()==h,k
 assert f.read(mf.relative_to(root).as_posix())==mf.read_bytes()
seal={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(files),'CRC':'PASS','perFileSHA256':'PASS','duplicateEntries':False,'S2':'COMPLETE / FROZEN','mandatoryPASS':36,'mandatoryOPEN':0,'scope':'passive offline, fixed mesh, two-rank OF7-native parcel evidence','parentArchivesEmbedded':4,'commonSourceChainExternalArchiveReferences':'pinned SHA; copied member metadata embedded; historical partial used for source provenance only','T4':'PARTIAL','M8A':'PARTIAL','S3':'NOT AUTHORIZED / NOT EXECUTED','newPhysicsRuns':0,'newCompilations':0,'globalMPITransactionCertified':False,'productionRestart':'NOT CERTIFIED','CFD':False}
(s/'checkpoint_seal.json').write_text(json.dumps(seal,indent=2))
after=dict(before)
for p in sorted(files):after[p.relative_to(root).as_posix()]=sha(p)
for p in [s/'checkpoint_seal.json',archive]:after[p.relative_to(root).as_posix()]=sha(p)
# Protect external authority chain archives and anchor as well as copied metadata.
for v in chain['chain']:after[Path(v['archive']).relative_to(root).as_posix()]=v['archiveSHA256']
after[Path(chain['anchor']).relative_to(root).as_posix()]=chain['anchorSHA256']
(s/'frozen_after.json').write_text(json.dumps(after,indent=2))
print(json.dumps({'seal':seal,'closing':closing,'frozenAfterEntries':len(after)},indent=2))
