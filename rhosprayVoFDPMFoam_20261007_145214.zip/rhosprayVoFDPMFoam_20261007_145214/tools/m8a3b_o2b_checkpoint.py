from pathlib import Path
import json,hashlib,zipfile,sys
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o2b_v1'
a=json.loads((e/'audit_summary.json').read_text());assert a['selectedPolicy'] is None and not a['firstActivationAllowed']
before=e/'MILESTONE_STATUS.beforeO2B.md'
if not before.exists():
 before.write_bytes((b/'MILESTONE_STATUS.md').read_bytes())
 with (b/'MILESTONE_STATUS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-02 M8A.3B-O2B

PARTIAL / COLLISION_ENERGY_MODEL_BLOCKER; Outcome C; selected policy NONE.
Native probability replay reproduces486.41247553K vs473.49379916K limit.
Correction: the actual counterexample is native grazing (coalesced:false),
not coalescence. Existing grazing fallback cannot remove this blocker.
A/B reservoir mappings close extended defined energy but do not establish
physical identity/release/work/deletion closure. A additionally has16 strict
property-domain endpoint failures; B no thermal-domain failure in3600
conditioned merges. D all energy to carrier NOT JUSTIFIED. E exclusion
requires explicit project-owner scope approval, not granted this turn.
Original full thermalization:96/3600 conditioned candidates inadmissible;
unweighted grid proportion is not a production occurrence frequency.
3664 prototype assertions and160 independent ledger checks PASS;256 state
contract design examples PASS, not native codec/MPI certification.
O1/O2/O2A and every required frozen regression PASS;8 energy goldens byte
identical.11471 protected existing files +2 activeMake files checked;
96 actualcase files unchanged. Standalone OF7 prototype wmake PASS.
No active solver/source adapter/production patch. No CFD.
T3B PARTIAL/BLOCKED, T3PARTIAL, T4NO, M8APARTIAL, M6B.0/1NO.
O2C not executed; policy/physical-model decision required before O2C.
See M8A3B_O2B_COLLISION_ENERGY_DECISION_GATE.md and fitting/dpm/m8a3b_o2b_v1.
STOP this turn.
''')
if '--pack' not in sys.argv:
 print('O2B PARTIAL status appended with historical prefix preserved.');sys.exit()
dest=b/'checkpoints/M8A3B_O2B_collision_energy_decision_v1_PARTIAL_BLOCKER.zip';assert not dest.exists()
paths=[]
for root in (e,b/'tests/fiveEqORourkeEnergyDecision'):
 for p in root.rglob('*'):
  rel=p.relative_to(b)
  if 'lnInclude' in rel.parts or ('Make' in rel.parts and p.name not in ('files','options')):continue
  if p.name=='core' or p.name.startswith('core.') or p.name=='testFiveEqORourkeEnergyDecision':continue
  if p.is_symlink() or not p.is_file():continue
  paths.append(p)
paths+=list((b/'tools').glob('m8a3b_o2b_*.py'))
paths.extend((b/'M8A3B_O2B_COLLISION_ENERGY_DECISION_GATE.md',b/'MILESTONE_STATUS.md'))
manifest={str(p.relative_to(b)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,str(p.relative_to(b)).replace('\\','/'))
 z.writestr('O2B_CHECKPOINT_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(rel)).hexdigest()==h for rel,h in manifest.items())
out={'status':a['status'],'selectedPolicy':None,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(paths),'bytes':dest.stat().st_size,'manifestAndCRCVerified':True,'activeSolverImpact':'NONE','noCFD':True,'T3BResumed':False}
dest.with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
