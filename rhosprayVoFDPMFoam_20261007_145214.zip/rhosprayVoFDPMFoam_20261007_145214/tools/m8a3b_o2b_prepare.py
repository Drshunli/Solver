from pathlib import Path
import json,hashlib,shutil
b=Path(__file__).resolve().parents[1];old=b/'fitting/dpm/m8a3b_o2a_v1';e=b/'fitting/dpm/m8a3b_o2b_v1'
assert not e.exists(),'Do not overwrite historical evidence'
e.mkdir();t=b/'tests/fiveEqORourkeEnergyDecision';(t/'Make').mkdir(parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_text(json.dumps({str(p.relative_to(b)):sha(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_o2b_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()},indent=2))
shutil.copyfile(old/'case_before.json',e/'case_before.json')
for folder in ('fixtures','branch_fixtures','rebinding_fixtures'):shutil.copytree(old/folder,e/folder)
for s in 'ABC':shutil.copyfile(old/f'O1_{s}_collision_entry.txt',e/f'O1_{s}_collision_entry.txt')
shutil.copyfile(old/'envelope_before_tests.json',e/'inherited_envelope.json')
shutil.copyfile(old/'thermal/thermal_sweep.csv',e/'O2A_reference_sweep.csv')
for name in ('run_all_regressions.sh','run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','run_rebinding.sh','run_support.sh','run_carrier_verified.sh','run_o1.sh','run_o2.sh','read_sources.sh','run.sh','run_boiling.sh'):
 (e/name).write_bytes((old/name).read_bytes().replace(b'm8a3b_o2a_v1',b'm8a3b_o2b_v1'))
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqORourkeEnergyDecision"\nwmake > "$base/fitting/dpm/m8a3b_o2b_v1/log.wmake" 2>&1\n').encode())
(e/'run_prototypes.sh').write_bytes((head+'cd "$base/fitting/dpm/m8a3b_o2b_v1"\nmkdir -p prototypes\ncd prototypes\n"$base/tests/fiveEqORourkeEnergyDecision/testFiveEqORourkeEnergyDecision" "$base/fitting/dpm/m8a3b_o2b_v1/branch_fixtures/A" A /mnt/d/DATA/Solver/300_2D/constant/thermal.dat "$base/fitting/dpm/m8a3b_o2b_v1/event_inputs.csv" > log.run 2>&1\n').encode())
(t/'Make/options').write_bytes((b/'tests/fiveEqORourkeThermal/Make/options').read_bytes().replace(b'-I../fiveEqORourkePopulation',b'-I../fiveEqORourkeThermal -I../fiveEqORourkePopulation'))
(t/'Make/files').write_bytes((b/'tests/fiveEqORourkeThermal/Make/files').read_bytes().replace(b'testFiveEqORourkeThermal',b'testFiveEqORourkeEnergyDecision'))
# Ledger mapping inputs; exact full native graph/replay is covered by frozen re-runs.
events=[]
for s in 'ABC':
 p=old/f'O2_regression/{s}/scenario_7_ledger.json';ledger=json.loads(p.read_text());pair=json.loads((p.parent/'scenario_7.jsonl').read_text().splitlines()[0]);events.append((s,3e6,ledger,pair,p))
lines=[json.loads(x) for x in (old/'thermal_boiling/downstream.jsonl').read_text().splitlines()]
pair=next(x for x in lines if x['type']=='pair' and x['update']==11);population=next(x for x in lines if x['type']=='population' and x['update']==11)
events.append(('O2A_486',188330.307,population,pair,old/'thermal_boiling/downstream.jsonl'))
csv=['name,p,m1,m2,T1,T2,Kbefore,Kafter,EintBefore,merge,ux1,uy1,uz1,ux2,uy2,uz2,id1,id2']
provenance={}
for name,p,l,pair,path in events:
 pre=pair['before'];post=[x for x in pair['after'] if x['mass']>0];merge=len(post)==1
 v=post[0]['U'];w=post[1]['U'] if len(post)>1 else [0,0,0]
 csv.append(','.join(map(str,[name,p,pre[0]['mass'],pre[1]['mass'],pre[0]['T'],pre[1]['T'],l['before']['KE'],l['after']['KE'],l['before']['E'],int(merge),*v,*w,pre[0]['id'],pre[1]['id']])))
 provenance[name]={'path':str(path),'sha256':sha(path),'eventKind':'coalescence' if merge else 'native grazing','fullStateReplay':'frozen native regressions; candidate tool is ledger-state mapping only'}
(e/'event_inputs.csv').write_text('\n'.join(csv)+'\n');(e/'event_provenance.json').write_text(json.dumps(provenance,indent=2))
print(e)
