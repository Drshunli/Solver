from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a1_v1';e.mkdir(parents=True,exist_ok=True)
baseline={}
for root,label in [(b,''),(b.parent/'300_2D','CASE/')]:
 for p in root.rglob('*'):
  if 'lnInclude' in p.parts or 'checkpoints' in p.parts or 'm8a1_v1' in p.parts or any('linux64Gcc' in x for x in p.parts):continue
  if p.is_file() and (label or p.suffix in ('.H','.C','.md','.json','.csv','.py','.sh') or p.name in ('files','options')):baseline[label+str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_bytes(json.dumps(baseline,indent=2).encode())
(e/'FROZEN_CONTRACT.json').write_bytes(json.dumps({'P2':'signed minority, no decode/reencode','support':'strict ALL real contributors; absent/nonfinite/inconsistent -> controlled rejection','RNG':'exact repeat; no reseeding','rollback':'exact serial state/source/Q or UNSUPPORTED; never approximate accept','energy':'M8A immutable','weights':'actual OF7 weights; no masking/renormalization','CFD':False},indent=2).encode())
dirs=['finiteVolume/interpolation/interpolation/interpolationCellPoint','finiteVolume/interpolation/interpolation/interpolationCell','finiteVolume/interpolation/volPointInterpolation','lagrangian/intermediate/submodels/Kinematic/InjectionModel/ConeInjection','lagrangian/intermediate/submodels/Kinematic/InjectionModel/InjectionModel','lagrangian/intermediate/submodels/Kinematic/PatchInteractionModel/StandardWallInteraction','lagrangian/intermediate/submodels/CloudFunctionObjects/VoidFraction','lagrangian/intermediate/submodels/CloudFunctionObjects/CloudFunctionObject','lagrangian/intermediate/submodels/cloudSubModelBase','lagrangian/intermediate/submodels/CloudFunctionObjects/CloudFunctionObjectList','lagrangian/intermediate/clouds/Templates/KinematicCloud','lagrangian/intermediate/parcels/Templates/KinematicParcel','lagrangian/intermediate/parcels/Templates/ThermoParcel','lagrangian/intermediate/parcels/Templates/ReactingParcel','lagrangian/spray/clouds/Templates/SprayCloud','lagrangian/spray/submodels/StochasticCollision/ORourkeCollision','lagrangian/spray/submodels/BreakupModel/ReitzKHRT','lagrangian/spray/submodels/AtomizationModel/BlobsSheetAtomization','lagrangian/turbulence/submodels/Kinematic/DispersionModel/StochasticDispersionRAS','lagrangian/basic/particle']
s='#!/bin/bash\nset -e\nroot=/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src\n'
for d in dirs:
 out=e/'source_audit'/d;out.parent.mkdir(parents=True,exist_ok=True)
 s+=f'if [ -d "$root/{d}" ]; then cp -r "$root/{d}" /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a1_v1/source_audit/{d}; else echo "MISSING {d}"; fi\n'
(e/'capture.sh').write_bytes(s.encode());print('protected',len(baseline))
