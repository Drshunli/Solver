from pathlib import Path
import json,hashlib,zipfile,re,os
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/integration/m6b1_sr1_serial_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
g=json.loads((s/'gate_status.json').read_text());assert g['status']=='COMPLETE / DIAGNOSIS ONLY';assert all(v=='PASS' for v in g['gates'].values())
report=b/'M6B1_SR1_SERIAL_DIAGNOSIS_REPORT_v1.md';assert len(re.findall(r'^## \d+\.',report.read_text(),re.M))==32
baseline=json.loads((s/'protected_before.json').read_text());after={};changed=[]
for rel,h in baseline.items():
 current=sha(root/rel);after[rel]=current
 if current!=h:changed.append(rel)
assert changed==['rhosprayVoFDPMFoam/MILESTONE_STATUS.md'],changed
for rel,h in json.loads((s/'exact_input_sha.json').read_text()).items():assert sha(s/'case'/rel)==h,rel
parent=root/'checkpoints/M6B1_SERIAL_EULERIAN_DYNAMICS_PARTIAL_STOP_v1.zip'
assert sha(parent)=='075a4979209fe437e9883a5da668e468c5c906ba982f1764bae1ac1331663f79'
manifestSources={}
for base in [s/'diagnostic_solver',b/'tests/fiveEqSR1Query']:
 for wd,dirs,names in os.walk(base):
  dirs[:]=[x for x in dirs if x not in ['lnInclude','linux64GccDPInt32Opt']]
  for name in names:
   p=Path(wd)/name
   if p.suffix in ['.C','.H'] or p.name in ['files','options']:manifestSources[p.relative_to(root).as_posix()]=sha(p)
(s/'final_source_sha.json').write_text(json.dumps(manifestSources,indent=2))
(s/'closing_protection.json').write_text(json.dumps({'checked':len(baseline),'unexpectedChanges':[],'historyAppendOnly':changed,'exactInputFiles':17,'parentSHA256':sha(parent),'noRepair':True},indent=2))
files=[p for p in s.rglob('*') if p.is_file() and p.name not in ['frozen_after.json','checkpoint_seal.json','checkpoint_contents.json']]
files.extend([report,b/'MILESTONE_STATUS.md',b/'tools/m6b1_sr1_seal.py'])
for wd,dirs,names in os.walk(b/'tests/fiveEqSR1Query'):
 dirs[:]=[x for x in dirs if x!='lnInclude'];files.extend(Path(wd)/n for n in names)
manifest={p.relative_to(root).as_posix():sha(p) for p in sorted(set(files))}
contents=s/'checkpoint_contents.json';contents.write_text(json.dumps({'status':'COMPLETE / DIAGNOSIS ONLY','rootClass':'CLASS F / MIXED_CAUSE','M6B1':'PARTIAL / STOP','noRepair':True,'parentCheckpointSHA256':sha(parent),'files':manifest,'observerStartupAttemptRetained':True},indent=2));manifest[contents.relative_to(root).as_posix()]=sha(contents)
archive=root/'checkpoints/M6B1_SR1_SERIAL_DIAGNOSIS_COMPLETE_v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel in manifest:z.write(root/rel,rel)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for rel,h in manifest.items():assert hashlib.sha256(z.read(rel)).hexdigest()==h,rel
seal={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(manifest),'CRC':'PASS','perFileSHA256':'PASS','status':'COMPLETE / DIAGNOSIS ONLY','classification':'CLASS F / MIXED_CAUSE','M6B1':'PARTIAL / STOP','noRepair':True}
(s/'checkpoint_seal.json').write_text(json.dumps(seal,indent=2))
for p in set(files+[contents,s/'checkpoint_seal.json',archive]):after[p.relative_to(root).as_posix()]=sha(p)
(s/'frozen_after.json').write_text(json.dumps(after,indent=2));print(json.dumps(seal,indent=2));print('Frozen entries',len(after))
