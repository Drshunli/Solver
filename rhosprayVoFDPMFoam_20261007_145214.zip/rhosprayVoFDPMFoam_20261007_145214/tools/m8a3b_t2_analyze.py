from pathlib import Path
import json,csv,math
from collections import deque
import numpy as np
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t2_v1'
def read(name):return list(csv.DictReader((e/name).open()))
geo=read('cells.csv');n=len(geo)
G={k:np.array([float(r[k]) for r in geo]) for k in geo[0]}
graph=[[] for _ in range(n)]
for r in read('adjacency.csv'):
 a,z=int(r['owner']),int(r['neighbour']);graph[a].append(z);graph[z].append(a)
results=[];distanceRows=[]
def stats(v):
 if not len(v):return {'count':0,'min':None,'median':None,'P95':None,'max':None}
 return {'count':len(v),'min':float(np.min(v)),'median':float(np.median(v)),'P95':float(np.percentile(v,95)),'max':float(np.max(v))}
for scenario in read('scenarios.csv'):
 name=scenario['scenario'];rows=read(name+'.csv');A={k:np.array([float(r[k]) for r in rows]) for k in rows[0]};assert len(rows)==21000
 lo,hi,L=[float(scenario[k]) for k in ('x0','x1','L')]
 phase=A['phase'];gas=A['scalar'].astype(bool);valid=A['full'].astype(bool);dep=A['futurePatchDependent'].astype(bool)
 knownBad=(A['absentCellRefs']+A['absentBoundaryRefs'])>0
 band=gas&knownBad
 externalBand=band&(phase!=3)
 internalTraceBand=band&(phase==3)
 # Center-to-rectangle boundary distance; cut-cell centers may lie inside.
 dx=np.maximum(np.maximum(lo-G['x'],G['x']-hi),0);dy=np.maximum(np.maximum(-G['y'],G['y']-L),0)
 outside=(dx>0)|(dy>0);distance=np.hypot(dx,dy)
 insideDist=np.minimum.reduce([G['x']-lo,hi-G['x'],G['y'],L-G['y']]);distance=np.where(outside,distance,insideDist)
 # Finite segments, including corner projections; near-wall=actual wall-adjacent cells.
 sideDistance=np.minimum(np.hypot(G['x']-lo,dy),np.hypot(G['x']-hi,dy));tipDistance=np.hypot(dx,G['y']-L)
 region=np.where(G['y0']==0,'wall',np.where((dx>0)&(dy>0),'corner',np.where(sideDistance<=tipDistance,'lateral','tip')))
 hx=G['x1']-G['x0'];hy=G['y1']-G['y0'];local=np.where(region=='lateral',hx,np.where(region=='corner',np.hypot(hx,hy),hy))
 # Face graph is used only for connectivity/trace layering, never U interpolation.
 seen=np.zeros(n,dtype=bool);components=[]
 for seed in np.flatnonzero(valid):
  if seen[seed]:continue
  seen[seed]=True;queue=deque([int(seed)]);component=[]
  while queue:
   c=queue.popleft();component.append(c)
   for z in graph[c]:
    if valid[z] and not seen[z]:seen[z]=True;queue.append(z)
  components.append(component)
 far=[c for c in components if any(G['x0'][i]==0 or G['x1'][i]==.08 or G['y1'][i]==.03 for i in c)]
 main=max(far,key=len) if far else []
 m=np.array(main,dtype=int)
 # Layer distance in cell face graph from gas-containing geometric cut cells.
 depth=np.full(n,-1,dtype=int);queue=deque()
 for c in range(n):
  if A['geometricAlphaL'][c]>0:depth[c]=0;queue.append(c)
 while queue:
  c=queue.popleft()
  for z in graph[c]:
   if depth[z]<0:depth[z]=depth[c]+1;queue.append(z)
 # Full gas-side bounding-box extent beyond ideal sides/tip, excluding pure liquid.
 lateralExtent=np.maximum(np.maximum(lo-G['x0'],G['x1']-hi),0)
 tipExtent=np.maximum(G['y1']-L,0)
 regions={}
 for category in ('lateral','tip','wall','corner'):
  mask=band&(region==category);indices=np.flatnonzero(mask)
  exterior=externalBand&(region==category)
  runs={}
  for c in np.flatnonzero(mask):
   key=(float(G['x0'][c]),float(G['x1'][c])) if category=='tip' else (float(G['y0'][c]),float(G['y1'][c]),bool(G['x'][c]<.015))
   runs[key]=runs.get(key,0)+1
  regions[category]={'centerDistance_mm':stats(distance[mask]*1000),'centerDistance_localWidths':stats(distance[mask]/local[mask]),'maxFaceLayersFromCoreOverlap':int(max(depth[mask])) if len(indices) else 0,
   'maxExcludedRowsAlongNormal':max(runs.values()) if runs else 0,'distance_over_dx':stats(distance[mask]/hx[mask]),'distance_over_dy':stats(distance[mask]/hy[mask]),'externalNonTraceCenterDistance_mm':stats(distance[exterior]*1000),
   'gasSideOuterEnvelope_mm':float(max((tipExtent if category=='tip' else lateralExtent)[mask])*1000) if len(indices) else 0.}
 for c in np.flatnonzero(band):distanceRows.append({'scenario':name,'cell':int(c),'region':region[c],'centerDistance_mm':distance[c]*1000,'localWidth_mm':local[c]*1000,'normalizedDistance':distance[c]/local[c],'faceLayers':int(depth[c]),'futurePatchDependent':int(dep[c])})
 expected=(hi-lo)*L*.00005;actual=float(sum(A['geometricAlphaL']*G['volume']));assert abs(actual-expected)<=1e-12*max(expected,1e-30) if name!='ALL_GAS' else actual==0
 counts={'cells':n,'pureGas':int(sum(phase==0)),'mixed':int(sum(phase==1)),'pureLiquid':int(sum(phase==2)),'trace':int(sum(phase==3)),'gasPresentNormal':int(sum((phase==0)|(phase==1))),'gasAbsent':int(sum(phase==2)),
 'scalarValid':int(sum(gas)),'UCertifiedValid':int(sum(A['U'])),'fullDPMCertifiedValid':int(sum(valid)),'gasRejectedKnownStencil':int(sum(band)),
 'gasOnlyFuturePatchDependent':int(sum(gas&dep&~knownBad)),'gasStencilAndFutureDependent':int(sum(band&dep)),'futurePatchDependentCells':int(sum(dep)),
 'externalGasOrMixedKnownExclusion':int(sum(externalBand)),'interiorTraceKnownExclusion':int(sum(internalTraceBand))}
 scalar={k:int(sum(A[k])) for k in ('rho','p','T','Cp','mu','kappa','species')}
 result={'scenario':name,'L_mm':L*1000,'L_over_Dphysical':L/.0003,'L_over_w2D':L/(hi-lo),'shift_mm':float(scenario['shift'])*1000,'bufferCells':int(scenario['buffer']), 'counts':counts,'scalarProperties':scalar,'geometricVolume_m3':actual,'expectedGeometricVolume_m3':expected,
 'farfieldBoundaryInvalidCells':int(sum(~valid&((G['x0']==0)|(G['x1']==.08)|(G['y1']==.03)))),
 'exclusionCenterDistance_mm':stats(distance[band]*1000),'exclusionLocalWidthRatio':stats(distance[band]/local[band]),'regions':regions,'connectedValidComponents':len(components),'farfieldConnectedCells':len(main),
 'externalNonTraceExclusionDistance_mm':stats(distance[externalBand]*1000),'internalTraceExclusionDistance_mm':stats(distance[internalTraceBand]*1000),
 'connectedNearestLateralCenterDistance_mm':float(min(sideDistance[m])*1000) if len(m) else None,'connectedNearestTipCenterDistance_mm':float(min(tipDistance[m])*1000) if len(m) else None,
 'connectedNearestPureGasLateralCenterDistance_mm':float(min(sideDistance[m[phase[m]==0]])*1000) if len(m[phase[m]==0]) else None,
 'connectedNearestPureGasTipCenterDistance_mm':float(min(tipDistance[m[phase[m]==0]])*1000) if len(m[phase[m]==0]) else None,
 'invalidCellContributorRefs':int(sum(A['absentCellRefs'][band])),'invalidKnownBoundaryRefs':int(sum(A['absentBoundaryRefs'][band])),
 'structuralVerdict':'PASS_CANDIDATE / localized known exclusion; connected certified farfield gas region' if len(main) and (name=='ALL_GAS' or counts['gasRejectedKnownStencil']<counts['scalarValid']) else 'BLOCKER',
 'futureBoundaryVerdict':'FUTURE_PATCH_DEPENDENT' if sum(dep) else 'NOT_DEPENDENT'}
 if name=='ALL_GAS':assert counts['fullDPMCertifiedValid']==21000
 results.append(result)
with (e/'distance_map.csv').open('w',newline='') as f:
 if distanceRows:w=csv.DictWriter(f,fieldnames=list(distanceRows[0]));w.writeheader();w.writerows(distanceRows)
(e/'topology_analysis.json').write_text(json.dumps(results,indent=2))
with (e/'topology_counts.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['scenario']+list(results[0]['counts']));w.writeheader()
 for r in results:w.writerow({'scenario':r['scenario'],**r['counts']})
print(json.dumps([{k:r[k] for k in ('scenario','counts','exclusionCenterDistance_mm','farfieldConnectedCells')} for r in results],indent=2))
