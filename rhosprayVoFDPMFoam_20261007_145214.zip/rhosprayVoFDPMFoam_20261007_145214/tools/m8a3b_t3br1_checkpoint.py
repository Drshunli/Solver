from pathlib import Path
import zipfile,hashlib,json
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3br1_v1';out=b/'checkpoints/M8A3B_T3BR1_native_OF7_serial_PARTIAL_v1.zip'
assert not out.exists();out.parent.mkdir(exist_ok=True)
roots=[e,b/'tests/fiveEqDPMNativeTransaction',b/'tests/fiveEqDPMRebinding',b/'tests/fiveEqDPMCarrierPublication',b/'tests/fiveEqDPMSerialTransaction',b/'tests/fiveEqDPMSupportScan',b/'dpmFiveEq',b/'fiveEqPrecision',b/'fiveEqThermo',b/'fiveEqFlux',b/'fiveEqReconstruction',b/'fiveEqIntegration',b/'fiveEqHighOrderPrecision',b/'liquidEOS/library']
files={}
for root in roots:
 for p in root.rglob('*'):
  parts=p.relative_to(b).parts
  if 'lnInclude' in parts or ('Make' in parts and not (p.parent.name=='Make' and p.name in ('files','options'))):continue
  if p.name=='core' or p.name.startswith('core.') or p.is_symlink() or not p.is_file():continue
  if p.parent==root and p.name.startswith('testFiveEq') and p.suffix!='.C':continue
  files[str(p.relative_to(b)).replace(chr(92),'/')]=p
for name in ('FIRST_ACTIVATION_OROURKE_LIMITATIONS.md','M8A3B_T3BR1_CAPABILITY_MATRIX.md','M8A3B_T3BR1_NATIVE_SERIAL_TRANSACTION.md','MILESTONE_STATUS.md'):
 files[name]=b/name
for p in (b/'tools').glob('m8a3b_t3br1_*.py'):files[str(p.relative_to(b)).replace(chr(92),'/')]=p
manifest={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in files.items()}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('CHECKPOINT_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert set(z.namelist())==set(manifest)|{'CHECKPOINT_MANIFEST.json'}
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h,name
receipt={'path':str(out),'files':len(manifest),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'CRC':'PASS','manifestHashes':'PASS','status':'PARTIAL / SERIAL_TRANSACTION_CLOSURE_INCOMPLETE','noCFD':True}
(e/'checkpoint_receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
