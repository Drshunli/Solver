from pathlib import Path
import json,hashlib,csv
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3_v1'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
transactions={s:read(e/'transaction'/s/'test_results.json') for s in 'ABC'}
independence={s:read(e/'rebinding'/s/'test_results.json') for s in 'ABC'}
energy={p.parent.name:read(p) for p in (e/'energy_regressions').glob('*/test_results.json')}
critical={p.parent.name:read(p) for p in (e/'D_regressions').glob('*/test_results.json')}
temporal=read(e/'temporal/test_results.json');support=read(e/'support_regression/test_results.json');native=read(e/'support_regression/native_comparison.json')
all_results=list(transactions.values())+list(independence.values())+list(energy.values())+list(critical.values())+[temporal,support,native]
assert all(r['failures']==0 for r in all_results)
assert sum(r['checks'] for r in energy.values())==9288
assert sum(r['checks'] for r in independence.values())==6375
assert sum(r.get('checks',0) for r in critical.values())==105775
assert temporal['checks']==9663 and native['checks']==1725880
assert all(r['discardCycles']==1000 and r['acceptedPromotions']==0 for r in transactions.values())
assert all(r['blockedReason']=='COMMIT_ARCHITECTURE_BLOCKER_CARRIER_VIEW_REFRESH' for r in transactions.values())
assert len(energy)==8 and len(critical)==10
golden=[]
for mode in energy:
 p=e/'energy_regressions'/mode/'golden_energy.csv';q=b/'fitting/dpm/m8a3b_t2_v1/energy_regressions'/mode/'golden_energy.csv'
 assert p.read_bytes()==q.read_bytes();golden.append({'mode':mode,'sha256':sha(p),'byteEqual':True})
with (e/'support_regression/ALL_GAS.csv').open(encoding='utf8') as f:
 rows=list(csv.DictReader(f))
# Native T2 writer names its certified full-support column 'full'.
columns=rows[0].keys()
full_col=next((c for c in columns if c in ('full','fullValid','fullSupportValid')),None)
assert full_col is not None,columns
assert len(rows)==21000 and sum(int(r[full_col]) for r in rows)==21000
fixture_io={}
for s in 'ABC':
 root=e/'fixtures'/s
 dirs=sorted(p.name for p in root.iterdir() if p.is_dir())
 assert dirs==['0','constant','system'],dirs
 changes=[]
 for name in ('0','system'):
  for original in (b/'tests/fiveEqDPMRebinding'/('fixture'+s)/name).rglob('*'):
   if original.is_file():
    target=root/original.relative_to(b/'tests/fiveEqDPMRebinding'/('fixture'+s))
    if sha(original)!=sha(target):changes.append(str(target))
 assert not changes
 fixture_io[s]={'noNewTimeDirectories':True,'inputChanges':changes}
gate={'status':'PARTIAL','stopCode':'COMMIT_ARCHITECTURE_BLOCKER_CARRIER_VIEW_REFRESH','architecture':'A_DUAL_CLOUD_ROLE_SWAP','transactions':transactions,'sourceEnergyChecks':9288,'energyReferenceGoldens':golden,'independenceChecks':6375,'criticalChecks':105775,'subULPStepsPerScheme':critical['subulp']['steps_per_scheme'],'temporalRestartChecks':9663,'allGasSupportValid':21000,'nativeInterpolationChecks':1725880,'nativeInterpolationMaxError':native['maxError'],'fixtureIO':fixture_io,'T3_COMPLETE':False,'T4_may_start':False,'M8A_COMPLETE':False,'M6B0':False,'M6B1':False,'noCFD':True}
(e/'gate.json').write_text(json.dumps(gate,indent=2,ensure_ascii=False),encoding='utf8')
table='\n'.join(f"| {s} | {r['historySteps']} | {r['seedParcels']} | {r['discardCycles']} | {r['checks']} | {r['failures']} | {r['acceptedPromotions']} |" for s,r in transactions.items())
memory='\n'.join(f"| {s} | {r['seconds']:.3f} | {(r['peakRSSPages']-r['warmRSSPages'])*4096/1024:.1f} |" for s,r in transactions.items())
models=['coneInjection','sphereDrag','stochasticDispersionRAS','blobsSheetAtomization','ReitzKHRT','ORourke','rebound','voidFraction']
matrix='\n'.join(f'| {m} | BLOCKER | 完整 source/carrier/output/event 重试门槛未关闭 |' for m in models)
sections=[
('M8A.3B-T3 status','**PARTIAL / COMMIT_ARCHITECTURE_BLOCKER_CARRIER_VIEW_REFRESH**。按本轮 STOP 条件停在受控提交拒绝，不执行 T4/M6B。该状态表示当前被动原型未闭合；不声称双云架构在原则上不可实现。'),
('Selected commit architecture','**选择 A：dual-cloud logical role swap**。没有 import-back 混合实现。'),
('Reason for architecture selection','M8A.3A 已证明新云模型 owner/RNG 独立；整体 role handle 能避免逐项拷回模型。当前 native carrier 引用还需要另行解决。'),
('Complete serial transaction state','原型持有 Q/P2 exact bits、ordered native parcels、injector/wall mutable state、源项和系数、逻辑 allocator、Time/index/dt、generation、内存 pending theta。完整 RNG codec、sorted identity view、支持缓存与 durable output metadata 尚未闭合，不能称 complete schema。'),
('begin/evolve/validate/commit/discard API','已实现 beginTrial/evolveTrial/validateAll/commitAll/discardAll。真实 closed same-cell endpoint source conversion 和 Q recovery 在 validate 内；完整事件级 extract/convert/build/recover 独立接口尚缺。嵌套、无 trial、未验证提交及双重 discard 受控拒绝。'),
('Committed-state mutation sentinel','A/B/C 每次构造/演化/销毁比较 committed sentinel。Q/P2 用位模式；native parcels 保留顺序；RNG 使用冻结 128 次 future probe，尚不是通用完整状态序列化证明。'),
('Cloud/Q atomicity','代码采用一个 State unique_ptr 交换；提交前封存候选并检查变动。实际 accepted publication 未通过（0/100），故不得宣称 cloud/Q atomic commit PASS。'),
('Source accumulator transaction','重建云独立拥有 rhoTrans/UTrans/hsTrans、species 和系数。闭合无跨单元 population 使用实际 before/after/native transfers 调冻结 adapter；注入/删除/跨单元必须有事件级账本，目前拒绝。'),
('Native-vs-transaction accepted regression','冻结 M8A.3A 的 native-vs-reconstructed 10 步仍通过；T3 accepted 非零源项 wrapper 比较尚未完成。'),
('ConeInjection retry','初次探索 A 的真实大步从 106 增至 318 parcels，拒绝后 sentinel 恢复；仅证明深演化 discard。正式 injection direct-small/retry 完整 Q/source/output goldens 未完成。'),
('Stochastic retry','初次探索证明 trial RNG advance/discard；冻结 A/B/C 各 10 stochastic renewals 通过。T3 forced rejected-large + 10 renewals future goldens 未完成。'),
('SphereDrag retry','Native evolved 路径和冻结 energy momentum 模式回归通过；T3 非零 dM/Et accepted/retry 尚未完成。'),
('BlobsSheetAtomization event','本机源码确认模型在 walk > lBU 时把 liquidCore 置 0，本身不创建 child。T3 实际 branch mutation retry 未完成；不以 ordinary model-called 代替。'),
('ReitzKHRT child retry','初次探索 A 使用合法 branch-only parcel state、原生产系数、真实 SprayParcel::calc → ReitzKHRT → native child creation，107 → 108，discard sentinel 恢复。证据为 transaction_attempt1_A；未完成合法 accepted child/Q 及 direct-small goldens。'),
('ORourke collision result','本机 coalescence/删除路径已读取。T3 真实 collision mutation retry 未完成；普通 collide 调用不能作为通过证据。'),
('Merge/delete retry','尚未完成；未替换真实模型或修改生产系数制造通过。'),
('Rebound transaction','冻结 M8A.3A 原生 rebound 等价通过；T3 patch statistics/source/pending-output 完整 retry 未完成。'),
('Parcel deletion retry','minimum-mass 删除和计数减少事务门槛未完成。'),
('Combined-event retry','初次探索大步有 ongoing injection/RNG/motion；没有已通过的 injection + stochastic + drag + breakup/collision + nonzero-source 完整 retry 组合。'),
('Support-failure retry','T2 strict-support 判据与原生权重保持冻结。真实 trajectory 进入 exclusion 的 runtime before-query hook/retry 未完成；TEST_DPM_INLET 没有被当作 production nozzle。'),
('Source/thermo-failure retry','实际捕获的是 carrier-view freshness guard，不是 EOS domain violation，也不是故意损坏 Et。合法 oversized-source EOS 失败/小步成功门槛未完成。'),
('Trace-gas transaction','冻结 energy trace/pure-liquid contracts 保持通过；T3 trace-gas full-cloud 接受/拒绝未完成，没有增加 trace buffer 或 fake gas。'),
('Canonical state comparison','transactionState-v1-PROTOTYPE 不是最终 versioned complete codec。完整 authoritative hidden RNG/output/canonical sorted identity 要继续审计。'),
('Direct-small-step equivalence','相关比较代码保留为后续门槛，当前在第一个合法候选的 carrier refresh guard 处 STOP；没有已通过的 T3 direct/retry 完整 canonical equality。'),
('Accepted output commit','只实现内存 theta staging 和 publication counter；durable accepted output 一次提交尚未完成，实际没有成功 publication。'),
('Rejected output result','最终 A/B/C 输入目录未出现新的 time directory，0/system 内容保持原样。没有 native trial 永久输出；这不是 accepted output golden 已通过。'),
('VoidFraction result','沿用冻结原生 trajectory-time integral。未改成 final occupancy；输出发布 retry 尚缺。'),
('Post-commit future equivalence','T3 未出现 accepted commit，因此 >=10 post-commit future gate 未执行；冻结 M8A.3A 的 future equivalence 不升级为 T3 证明。'),
('Serial conservation ledger','冻结 source/energy 9288 checks 和 32 个 JANAF/reference goldens byte-identical。T3 真实 closed-population source 转换/恢复已执行，但全事件 accepted exchange ledger 未关闭。'),
('Repeated lifecycle result',f'最终 A/B/C：\n\n| state | 历史步 | seed parcels | begin/evolve/discard | checks | failures | accepted promotions |\n|---|---:|---:|---:|---:|---:|---:|\n{table}\n\n要求的每组 100 accepted promotions 未完成。'),
('Registry/reference result','3000 discard 周期 registry 回到基线，committed/allocator 哨兵保持不变。初版 100 个零事件 promotion 曾使原生 Theta registry 数量改变，100 个失败保留在 attempt1。不能用该探索结果证明 accepted 生命周期；后续版本禁止无 evolve 的晋升。'),
('Model capability matrix',f'| 模型 | 串行完整事务能力 | 原因 |\n|---|---|---|\n{matrix}\n\n这些 BLOCKER 是本轮证据门槛未闭合，不撤销 M8A.3A independence COMPLETE。'),
('Frozen M8A regression','8 modes 合计 **9288 checks / 0 failures**；32 reference-energy rows byte-identical。未更改 source equations/energy ledger；reaction-enabled closure 仍未激活。'),
('Frozen M8A.3A regression','A/B/C 合计 **6375 checks / 0 failures**，每组 1000 lifecycles 与 10 native/reference future steps。'),
('Frozen T2 support regression','19 topologies / 25 exact EOS states / 0 failures；all-gas **21000/21000** full-valid；native interpolation **1725880 checks / 0 failures**，max error 3.84593e-16。P2/recovery/R1 **105775 checks / 0 failures**，sub-ULP 每 scheme 1000 steps；temporal/restart **9663 / 0**。'),
('Performance/memory cost',f'| state | 本轮 harness 秒数 | warm→peak RSS KiB |\n|---|---:|---:|\n{memory}\n\n这是 1000 discard + guard 探测的成本；不是生产性能或正式 leak proof。'),
('Project-local overrides','复用冻结 modelAdapters.H/outputIsolation.H；新增 serialTransaction.H 与被动 test executable。没有新增模型 physics override 或修改系统 OF7；仅被动输入复制了独立 role dictionaries。'),
('Active solver impact','**NONE**：active solver/Make、生产 mesh、case BC、源项位置和时间循环保持不变；没有 CFD、alpha source、masked interpolation、VOF→DPM 或 MPI 激活。SHA 校验见 protection_verification.json。'),
('Remaining blockers','候选拥有且 native-bound 的 carrier bank；真实事件 admission/motion/deletion/wall work 账本；完整 RNG/identity codec；strict-support runtime hooks；accepted durable output；全部 forced-event/direct-small goldens 与 100 accepted promotions。未用任意 residual、clip 或改权重绕过。'),
('Whether T3 COMPLETE','**NO / PARTIAL**。合法 tiny-step 产生实际非零横向 dM，Q 的 My 改变但 native U 仍是源云字段。source 与 Q 原始数值在 carrier_refresh_source.csv/carrier_refresh_failure.csv。'),
('Whether T4 may start','**NO**。本轮不实施 MPI crossing/global retry。'),
('Whether M8A COMPLETE','**NO / PARTIAL**。'),
('M6B.0 permission','**NO**；reaction-enabled closure 未关闭。'),
('M6B.1 permission','**NO**。'),
('Updated milestone matrix','| 阶段 | 状态 |\n|---|---|\n| M5C.1–.3 | COMPLETE / NOT ACTIVE |\n| M8A source/energy | PASS / FROZEN |\n| M8A.3A | COMPLETE |\n| T1 | COMPLETE / DESIGN ONLY |\n| T2 | COMPLETE / SYNTHETIC SERIAL GAS-SIDE STRICT-SUPPORT FEASIBLE |\n| T3 | PARTIAL / carrier-view publication blocker |\n| T4 | NOT STARTED |\n| M8A.3B / M8A overall | PARTIAL |\n| M6B.0 / M6B.1 | NO |\n\nSTOP。')
]
assert len(sections)==45
report='\n\n'.join(f'# {i}. {title}\n\n{body}' for i,(title,body) in enumerate(sections,1))+'\n'
(b/'M8A3B_T3_SERIAL_TRANSACTION_GATE.md').write_text(report,encoding='utf8')
print(json.dumps({'status':gate['status'],'transactionChecks':sum(r['checks'] for r in transactions.values()),'sections':len(sections)},ensure_ascii=False))
