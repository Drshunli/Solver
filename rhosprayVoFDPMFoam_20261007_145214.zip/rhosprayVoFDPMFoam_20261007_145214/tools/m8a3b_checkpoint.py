from pathlib import Path
import json,hashlib,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_v1'
status=b/'MILESTONE_STATUS.md';save=e/'milestone_before.md'
if not save.exists():
    save.write_bytes(status.read_bytes())
    text='''

## M8A.3B full production transaction gate (2026-10-01)

**PARTIAL / INTENDED_TOPOLOGY_INPUT_REQUIRED.** Selected architecture A:
dual-cloud logical role swap, DESIGN FROZEN only, not implemented.
New serial native sparse support tool has no 256 cap and scans actual 300_2D:
21000 cells / 63620 candidate entities; 8 coloring groups. Native numerical
comparison 1725880 checks, zero failures, max absolute error 3.84593e-16.
Sharp/1/2/3-cell trace maps are P2-authoritative diagnostic fixtures only;
each excludes one gas-present row from whole-cell support. No intended initial
liquid/P2 topology exists in the actual case, so production feasibility remains
UNKNOWN. No trace-gas creation or interpolation masking is performed.
Full scalar transport/property validity, native production hooks, cloud/Q
commit, forced-event retry, accepted output and real MPI crossing are pending.
Frozen M8A source/energy 9288 (32 stable goldens byte equal), P2/recovery/R1
105775 plus subULP 1000 steps per scheme, temporal/restart 9663, and full
M8A.3A A/B/C 6375 checks all pass. Historical code/evidence unchanged.
Only project-local passive tools/fixtures/report and this appended record.
Active solver/case impact NONE; no CFD. M8A PARTIAL, M6B.0 BLOCKED, M6B.1 NO.
See M8A3B_FULL_TRANSACTION_GATE.md and docs/M8A3B_ROLE_SWAP_DESIGN.md.
'''
    with status.open('ab') as f:f.write(text.encode())
else:raise SystemExit('Refusing to append/checkpoint twice')
