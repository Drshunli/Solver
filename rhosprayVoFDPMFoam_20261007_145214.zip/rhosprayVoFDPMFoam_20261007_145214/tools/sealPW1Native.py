"""Seal PW1 qualification artifacts; refuses to overwrite a checkpoint."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/dpm/m8a3b_t4_s2_pw1_native_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_text())
previous=j(s/'frozen_before.json');authorized={'rhosprayVoFDPMFoam/MILESTONE_STATUS.md'}
delta=[k for k,h in previous.items() if not (root/k).is_file() or sha(root/k)!=h];assert set(delta)==authorized,delta
m=j(s/'milestone_before_sha.json');milestone=b/'MILESTONE_STATUS.md';assert hashlib.sha256(milestone.read_bytes()[:m['bytes']]).hexdigest()==m['sha256']
gate=j(s/'PW1_gate.json');assert gate['status']=='COMPLETE / OF7-NATIVE WEIGHTED PARCEL QUALIFIED';assert gate['failed']==[]
(s/'protected_closing_audit.json').write_text(json.dumps({'entries':len(previous),'unchanged':len(previous)-len(delta),'authorized_changes':delta,'unexpected_changes':[],'milestone_append_only':True,'physics_tests_after_STOP':False},indent=2))
files=set()
for folder in [s,b/'tests/fiveEqDPMPW1Native']:
 for p in folder.rglob('*'):
  if p.is_file() and not any(x in p.parts for x in ['linux64GccDPInt32Opt','lnInclude']) and p.name not in ['frozen_after.json','checkpoint_manifest.json','checkpoint_seal.json'] and p.suffix not in ['.o','.dep']:files.add(p)
for p in [b/'M8A3B_T4_S2_PW1_NATIVE_REPORT.md',milestone,b/'tools/auditPW1Native.py',b/'tools/preparePW1Native.py',b/'OF7_PARCEL_WEIGHTING_AUDIT_v1.md',Path(__file__).resolve()]:files.add(p)
manifest={p.relative_to(root).as_posix():sha(p) for p in sorted(files)}
manifestfile=s/'checkpoint_manifest.json';manifestfile.write_text(json.dumps(manifest,indent=2));files.add(manifestfile)
archive=root/'checkpoints/M8A3B_T4_S2_PW1_NATIVE_COMPLETE_QUALIFIED_v1.zip';assert not archive.exists(),'immutable checkpoint already exists';archive.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 for k,h in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==h,k
 assert z.read(manifestfile.relative_to(root).as_posix())==manifestfile.read_bytes()
seal={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(files),'CRC':'PASS','per_file_SHA256':'PASS','duplicate_entries':False}
(s/'checkpoint_seal.json').write_text(json.dumps(seal,indent=2))
closing=dict(previous)
for k in authorized:closing[k]=sha(root/k)
for p in sorted(files):closing[p.relative_to(root).as_posix()]=sha(p)
for p in [s/'checkpoint_seal.json',archive]:closing[p.relative_to(root).as_posix()]=sha(p)
(s/'frozen_after.json').write_text(json.dumps(closing,indent=2))
print(json.dumps({'seal':seal,'protected_closing':j(s/'protected_closing_audit.json'),'frozen_after_entries':len(closing)},indent=2))
