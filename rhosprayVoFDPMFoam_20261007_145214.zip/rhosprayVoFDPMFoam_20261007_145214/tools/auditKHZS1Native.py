"""Offline gate audit only; does not mutate test inputs, native sources, or solver."""
from pathlib import Path
import json,hashlib,subprocess,sys,csv,collections,difflib,math
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(l) for l in p.read_text().splitlines()]
def entry(p):return next(r for r in rows(p) if 'nativeArgs' in r)
def val(r):return float(r['value'])
gates={};detail={}
allowed={'rhosprayVoFDPMFoam/tests/fiveEqDPMParcelC2/parcel/LazySprayParcel.C'}
protected=read(s/'frozen_before.json');delta=[k for k,h in protected.items() if not (root/k).is_file() or sha(root/k)!=h]
gates['protected_project_scope']=set(delta)==allowed
detail['protected_hashes']={'entries':len(protected),'unchanged':len(protected)-len(delta),'authorized_changes':delta,'unexpected':[k for k in delta if k not in allowed]}
(s/'protected_before_history_append.json').write_text(json.dumps(detail['protected_hashes'],indent=2))
for name,count in [('installed_source_verification.txt',6717),('native_parcel_verification.txt',19)]:
 lines=(s/name).read_text().splitlines();gates[name]=len(lines)==count and all(l.endswith(': OK') for l in lines);detail[name]={'checks':len(lines),'failures':sum(not l.endswith(': OK') for l in lines)}
old=b/'fitting/dpm/m8a3b_t4_s2_kh_fpe2_native_v1'
a=entry(old/'exact_debug_final/calls.rank1.jsonl');c=entry(s/'serial_zero_observed_final/calls.rankserial.jsonl')
diff={k:[v,c['nativeArgs'].get(k)] for k,v in a['nativeArgs'].items() if k not in ('this','KHindex') and v!=c['nativeArgs'].get(k)}
gates['captured_native_args']=not diff and a['model']==c['model'] and a['averageParcelMass']==c['averageParcelMass']
detail['captured_native_args']={'deltas_except_intentional_temporary_index':diff,'model_equal':a['model']==c['model'],'average_mass_equal':a['averageParcelMass']==c['averageParcelMass']}
for kind in ['zero','near','positive','rt']:
 q=read(s/f'serial_{kind}/ZS1_probe.json');detail[kind]=q
 gates['probe_'+kind]=all(q[k] for k in ['finite','neutral','nativeParity','RNGsame','sourcesSame']) and q['children']==0 and q['sourceMag']==0
 r=rows(s/f'serial_{kind}_observed_final/calls.rankserial.jsonl');e=next(x for x in r if 'nativeArgs' in x);post=next(x for x in r if x.get('stage')=='PROJECT_AFTER_INDEX_WRITEBACK')
 gates['guard_'+kind]=e['khZeroSlipCompat']==int(kind in ['zero','rt'])
 if kind in ['zero','rt']:gates['real_index_'+kind]=val(post['this']['KHindex_'])==0 and val(post['khIndexEval'])==1
 if kind=='near':gates['exact_near_slip']=val(e['nativeArgs']['Urmag'])==1.4210854715202004e-14
 if kind=='rt':gates['native_RT_reached']=sum(x.get('stage')=='NATIVE_RT_BRANCH' for x in r)==2 and q['d']<.0009999999999999998
 if kind=='zero':
  gates['zero_full_neutrality']=all(e['this'][k]==post['this'][k] for k in ['d_','nParticle_','KHindex_','tc_','ms_','y_','yDot_'])
for case in ['mpi_zero','mpi_zero_observed_final','id1','n1_valid','n1_forward','n1_reverse']:
 q=[read(p) for p in sorted((s/case).glob('processor*/native_crossing_result.json'))];detail[case]=q;gates['native_completion_'+case]=len(q)==2 and all(x['globalFailures']==0 and x['nativeCloudEvolve'] for x in q)
for case in ['mpi_zero','forward','positive','id1']:
 p=subprocess.run([sys.executable,str(b/'tools/auditS2R1Boundary.py'),str(s/case)],capture_output=True,text=True);q=json.loads(p.stdout);detail['migration_'+case]=q;gates['migration_'+case]=p.returncode==0
 (s/('boundary_'+case+'.json')).write_text(json.dumps(q,indent=2))
parity=read(s/'trajectory_birth_parity.json');detail['parity']=parity
for case,q in parity.items():gates['trajectory_'+case]=bool(q) and all(q.values())
rs=rows(s/'mpi_zero_observed_final/calls.rank1.jsonl');e=next(x for x in rs if 'nativeArgs' in x);post=next(x for x in rs if x.get('stage')=='PROJECT_AFTER_INDEX_WRITEBACK');gates['MPI_zero_real_index_preserved']=e['khZeroSlipCompat']==1 and val(post['this']['KHindex_'])==0
later=[x for x in rs if 'nativeArgs' in x and x['sequence']>e['sequence']];gates['later_native_nonzero_writeback']=bool(later) and later[0]['khZeroSlipCompat']==0 and val(later[0]['nativeArgs']['Urmag'])>0
detail['MPI_first_zero']={'entry':e,'post':post,'later_nonzero':later}
for name,result,count in [('k1','event_result.json',108),('c2','basic_result.json',17),('i1','gate_result.json',12083),('r2b','test_results.json',252194)]:
 q=read(s/f'regressions/{name}/{result}');detail['regression_'+name]=q;gates['regression_'+name]=q['checks']==count and q['failures']==0
q=[read(p) for p in sorted((s/'reg_fixture_s1').glob('processor*/support_result.json'))];detail['S1']=q;gates['S1']=len(q)==2 and sum(x['checks'] for x in q)==20051 and all(x['globalFailures']==0 for x in q)
for kind in ['forward','reverse']:
 l=[read(p) for p in sorted((s/('n1_'+kind)).glob('processor*/C1_latch.json'))];gates['N1_invalid_'+kind]=len(l)==2 and all(x['trialRejected'] for x in l) and any(x['failed'] and x['reason']=='GAS_SUPPORT_INVALID:EXACT_GAS_ABSENT' for x in l)
for f in s.glob('exit.*.txt'):gates['exit_'+f.name]=f.read_text().strip()=='0'
# Exact fixture file bytes remain equal; no boundary coefficient retuning.
input_hashes={}
for oldcase,newcase in [('exact_release','mpi_zero'),('forward_debug','forward'),('forward_debug','positive')]:
 checks=[]
 for p in (old/oldcase).rglob('*'):
  rel=p.relative_to(old/oldcase);parts=rel.parts
  if p.is_file() and (parts[0] in ['0','constant','system'] or parts[0] in ['processor0','processor1'] and len(parts)>1 and parts[1] in ['0','constant']):checks.append({'file':str(rel),'equal':p.read_bytes()==(s/newcase/rel).read_bytes()})
 input_hashes[newcase]=checks;gates['input_'+newcase]=len(checks)==69 and all(x['equal'] for x in checks)
detail['input_hashes']=input_hashes
src=b/'tests/fiveEqDPMParcelC2/parcel/LazySprayParcel.C';(s/'source_delta.diff').write_text(''.join(difflib.unified_diff((s/'LazySprayParcel.before.C').read_text().splitlines(True),src.read_text().splitlines(True),fromfile='before/LazySprayParcel.C',tofile='after/LazySprayParcel.C')))
# Observer errors or a stopped inferior cannot silently qualify the gate.
for case in ['mpi_zero','serial_zero','serial_near','serial_positive','serial_rt']:
 folder=s/(case+'_observed_final');gates['no_observer_failure_'+case]=not list(folder.glob('failure*.json'))
 for f in folder.glob('calls*.jsonl'):
  for r in rows(f):
   if r.get('stage')=='PROJECT_AFTER_INDEX_WRITEBACK':
    gates['positive_state_'+case+'_'+f.name+'_'+str(r['sequence'])]=all(val(r['this'][k])>0 and math.isfinite(val(r['this'][k])) for k in ['d_','nParticle_','rho_'])
result={'status':'COMPLETE' if all(gates.values()) else 'PARTIAL','gates':gates,'failed':[k for k,v in gates.items() if not v],'detail':detail,'S2':'PARTIAL','R1':'NEXT ROUND ONLY','S3':False,'M6B':False,'CFD':False}
(s/'ZS1_gate.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'gate_count':len(gates),'failed':result['failed'],'hashes':detail['protected_hashes']},indent=2));sys.exit(not all(gates.values()))
