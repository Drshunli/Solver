from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parents[1]
e=b/'fitting/integration/m5c3_v1'
e.mkdir(parents=True,exist_ok=True)
files={}
for p in b.rglob('*'):
    if 'lnInclude' in p.parts:continue
    if p.is_file() and 'm5c3_v1' not in p.parts and p.name!='m5c3_prepare.py' and ('linux64Gcc' not in str(p)) and (p.suffix in ('.H','.C','.md','.json','.csv','.py','.sh') or p.name in ('files','options')):
        files[str(p.relative_to(b))]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in (b.parent/'300_2D').rglob('*'):
    if p.is_file():files[str(p.relative_to(b.parent))]=hashlib.sha256(p.read_bytes()).hexdigest()
(e/'protected_before.json').write_text(json.dumps(files,indent=2),encoding='utf8')
print('protected',len(files))
