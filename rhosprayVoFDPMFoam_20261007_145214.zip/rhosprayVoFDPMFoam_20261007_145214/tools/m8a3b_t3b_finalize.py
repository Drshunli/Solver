from pathlib import Path
import hashlib,json,csv,re,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3b_v1'
def load(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ledger={s:load(e/'ledger'/s/'test_results.json') for s in 'ABC'}
carrier={s:load(e/'carrier_verified'/s/'test_results.json') for s in 'ABC'}
for s,r in ledger.items():
 assert r['failures']==0 and r['adapterReason']=='PARCEL_SPECIES_LEDGER_MISMATCH'
 assert r['removedMassKg']>0 and r['nativeMassTransferKg']==0 and r['acceptedCommits']==0
 assert r['fullCloudTimeStepProof'] is False and r['completeCodec'] is False
 assert (e/'ledger'/s/'test_failures.txt').stat().st_size==0
assert sum(r['checks'] for r in ledger.values())==57
assert sum(r['checks'] for r in carrier.values())==64395
for r in carrier.values():assert r['failures']==0 and r['CV1transverse']
groups={'sourceEnergy':list((e/'energy_regressions').glob('*/test_results.json')),'rebinding':list((e/'rebinding').glob('*/test_results.json')),'critical':list((e/'D_regressions').glob('*/test_results.json'))}
for paths in groups.values():
 for p in paths:assert load(p)['failures']==0,p
assert sum(load(p)['checks'] for p in groups['sourceEnergy'])==9288
assert sum(load(p)['checks'] for p in groups['rebinding'])==6375
assert sum(load(p).get('checks',0) for p in groups['critical'])==105775
assert load(e/'D_regressions/subulp/test_results.json')['steps_per_scheme']==1000
assert load(e/'temporal/test_results.json')=={'checks':9663,'failures':0}
assert load(e/'support_regression/native_comparison.json')['checks']==1725880
assert load(e/'support_regression/native_comparison.json')['failures']==0
assert load(e/'support_regression/test_results.json')['failures']==0
rows=list(csv.DictReader((e/'support_regression/ALL_GAS.csv').open()))
assert len(rows)==21000 and all(int(r['full'])==1 for r in rows)
for p in (e/'energy_regressions').glob('*/golden_energy.csv'):
 assert p.read_bytes()==(b/'fitting/dpm/m8a3b_t3a_v1/energy_regressions'/p.parent.name/p.name).read_bytes()
before=load(e/'protected_before.json');changes={name:{'before':h,'after':sha(b/name) if (b/name).exists() else None} for name,h in before.items() if not (b/name).exists() or sha(b/name)!=h}
active=load(b/'fitting/dpm/m8a3b_t1_v1/active_before.json')
for name,digest in active.items():assert sha(b/name)==digest,(name,'active/frozen T1 hash changed')
for name in changes:
 normalized=name.replace('\\','/')
 assert normalized=='MILESTONE_STATUS.md' or normalized.startswith('tests/fiveEqDPMEventLedger/'),changes
case=b.parent/'300_2D';case_now={str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()}
assert case_now==load(e/'case_before.json')
fixture_unchanged={}
for s in 'ABC':
 root=e/'fixtures'/s;old=b/'fitting/dpm/m8a3b_t3a_v1/fixtures'/s
 newfiles={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
 oldfiles={str(p.relative_to(old)):sha(p) for p in old.rglob('*') if p.is_file()}
 assert newfiles==oldfiles
 fixture_unchanged[s]=True
resources={}
for s in 'ABC':
 log=(e/'ledger'/s/'log.resource').read_text();resources[s]={'maxRSSKiB':int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',log)[1]),'wallTime':re.search(r'Elapsed .*?: (\S+)\n',log)[1]}
summary={'milestone':'M8A.3B-T3B','status':'PARTIAL / EVENT_LEDGER_BLOCKER','stopRule':'user section 48',
 'scope':'actual ORourke collision-kernel minimum-mass cleanup entry, not full cloud timestep or coalescence reachability proof',
 'eventChecks':57,'eventFailures':0,'ledger':ledger,'T3Achecks':64395,'T3Afailures':0,
 'regressions':{'sourceEnergy':9288,'rebinding':6375,'nativeSupport':1725880,'allGasFull':21000,'critical':105775,'temporal':9663,'subULPStepsPerScheme':1000},
 'fixtureNoPermanentOutput':fixture_unchanged,'protectedFileChanges':changes,'caseUnchanged':True,'activeSolverImpact':'NONE',
 'completeTransactionCodec':False,'persistentAcceptedOutputImplemented':False,'acceptedCommits':0,'modelTransactionsComplete':False,
 'resources':resources,'T3':'PARTIAL','T4':'NO','M8A':'PARTIAL','M6B.0':'NO','M6B.1':'NO','noCFD':True}
(e/'gate_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
models=['coneInjection','sphereDrag','stochasticDispersionRAS','blobsSheetAtomization','ReitzKHRT','ORourke','rebound','voidFraction']
matrix='| Model | Capability | Evidence / missing gate |\n|---|---|---|\n'+'\n'.join('| '+m+' | MODEL_FULL_TRANSACTION_BLOCKER | '+('Native cleanup deletion has unclosed mass/species ledger; kernel-entry reproduction only' if m=='ORourke' else 'Shared full codec/event/retry/output gate remains incomplete; no new model defect asserted')+' |' for m in models)
native='`fitting/dpm/m8a3b_t3b_v1/native_sources/lagrangian/spray/submodels/StochasticCollision/ORourkeCollision/ORourkeCollision.C`'
audit=f'''# ORourke minimum-mass cleanup ledger preflight

Date: 2026-10-02. Result: **EVENT_LEDGER_BLOCKER** under the frozen adapter contract; T3B PARTIAL.

## Reproduction scope and admissibility

The unchanged production-model graph is created from the frozen A/B/C dictionaries and evolved for 5/7/9 native steps (106/148/190 parcels). A positive-weight C10H22 parcel at 300 K and diameter 0.3 mm is placed in the last gas-present test cell. Its represented mass is half the actual native minParcelMass=1e-15 kg; density and caloric state use native liquid properties. All Q states are EOS-legal gas-present states; no Et/species corruption, alpha change, negative mass, invented native source or altered coefficient is used.

This is a **collision-kernel entry preflight**, not a proof that this parcel survives the preceding motion/ReactingParcel::calc in an ordinary full cloud timestep. In fact, ReactingParcel::calc checks the same weighted threshold and has a separate conservative absorption path. No pair collision/coalescence was established here. The historical pairs are examined by the native loop and its RNG advances; that does not certify a collision mutation. This limitation is explicit in every result JSON.

The preflight isolates a real native branch that also runs after coalescence. Source shows coalescence can leave a positive remnant m2=(1-prob)*m2Org, followed by min-mass cleanup; full-step reachability within the intended envelope remains to be demonstrated. The test does **not** assert that production already loses this amount in a CFD run.

## Actual source distinction

{native}, lines 108–118: the post-collision sweep deletes any parcel whose represented mass is below minParcelMass. It does not update rhoTrans, UTrans or hsTrans, retain a deletion transfer, or define an external mass sink.

`native_sources/lagrangian/intermediate/parcels/Templates/ReactingParcel/ReactingParcel.C`, lines 492–513: when its calc path removes a parcel, the coupled branch adds carrier species mass, sensible enthalpy and momentum before returning. Therefore the frozen disappearance regression cannot be used as proof for ORourke cleanup.

## Measured kernel event

| Quantity | Observation |
|---|---|
| Native threshold | 1e-15 kg |
| Before represented mass | 5e-16 kg |
| After represented mass | 0 |
| Native mass/species transfer | 0 |
| Native UTrans/hsTrans | 0 / 0 |
| Carrier+parcel mass residual | -5e-16 kg |
| Frozen adapter result | PARCEL_SPECIES_LEDGER_MISMATCH |
| Accepted commits | 0 |
| Committed ledger contribution | 0 |

The species mismatch exceeds the unchanged endpoint tolerance by many orders of magnitude. Its small absolute mass is not justification for silently dropping it or relaxing tolerances. Conversion stops at its first species check; dmG/dmYi/dM/dEt and recovered QTrial are **unavailable**, not fabricated zero increments. Exact endpoint momentum/kinetic/raw-liquid-H and source coefficients are retained in EVENT_LEDGER_v1.txt. No energy residual has been used to invent heat/work.

Native cloud role trial is deep-copied through the unchanged T3A beginTrial contract. After the real cleanup, the frozen adapter refuses conversion and the unchanged discard method restores the tested aggregate cloud sentinel, Q bits, carrier values/generation, allocator and registry. The sentinel includes complete native parcel serialization plus a finite RNG future probe; it is **not** the requested complete transactionState-v1 codec.

## Why no repair is applied

Passing the missing parcel mass to gas by editing the native buffers would create a new deletion-coupling rule. Treating it as outflow would invent a physical sink, since no boundary crossing occurred. Excluding the deleted parcel from endpoint totals would hide the discrepancy. Keeping it or merging its remainder would change the native cleanup/model behavior. None is authorized by this turn's frozen-source and model constraints.

Following user section 48, further event development stops. Mandatory frozen regressions and documentation are completed. This gate cannot mark ORourke or the eight-model matrix FULL-SERIAL-TRANSACTION-SAFE.

## Exact next engineering gate

Perform **ORourke cleanup reachability and conservation-policy review** first: instrument ordinary coalescence→cleanup, capture the positive remnant before native deletion, distinguish it from the already-conservative ReactingParcel::calc path, and assess its occurrence in the certified envelope. If reachable, present an explicit conservative cleanup-coupling design for review while preserving the existing frozen source adapter; do not implement it, discard the remainder, change minParcelMass, disable coalescence, or modify production code in this turn. If certified unreachable, prove the relevant entry invariant rather than assuming it from the pre-move calc check. Then resume codec/event/retry/output gates. No alternative EOS, T4 or M6B work is implied.
'''
(b/'OROURKE_CLEANUP_LEDGER_AUDIT.md').write_text(audit,encoding='utf8')
pending='NOT EXECUTED after the user-required event-ledger stop; no PASS claimed.'
sections=[
('T3B status','**PARTIAL / EVENT_LEDGER_BLOCKER.** Stopped under user section 48 after an actual native minimum-mass cleanup event failed the frozen endpoint/species ledger.'),
('transactionState-v1 codec','NOT COMPLETE. Actual Random has private x_, scalarNormalStored_, scalarNormalValue_; the existing 128-output normal/uniform probe is not a complete codec. Native value-copy restoration remains unchanged, but no full serialization/decoding proof is claimed. Restart/P2 formats are unchanged.'),
('Event ledger architecture','Added a diagnostic EventLedgerV1 observation record for actual before/after mass, species, momentum, kinetic energy, raw liquid H/volume, native rhoTrans/UTrans/hsTrans and coefficients, Qbefore and conversion status. It calls the frozen adapter. A general event-local/injection/child/cross-cell ledger is NOT COMPLETE; failed conversion leaves converted increments/QTrial unavailable.'),
('Committed-state sentinel','A/B/C each pass the inspected aggregate cloud sentinel, native parcel identity/order serialization, Q/P2 bits, carrier snapshot/generation, allocator and registry after discard. This finite sentinel is not the full canonical codec.'),
('Native/reference accepted-event regression',pending),
('ConeInjection retry','Historical injector states are nonzero (5/7/9 steps), but full injection admission, late-reject/direct-small retry is '+pending),
('Stochastic retry','Native collision loop advances root RNG in trial; aggregate discard sentinel matches. This is not stochasticDispersionRAS branch/retry or complete RNG codec proof. '+pending),
('SphereDrag event/ledger','Frozen source/energy drag regressions replay PASS. New full nonzero-source/Q retry is '+pending),
('BlobsSheet mutation transaction',pending),
('ReitzKHRT child rollback','Historical T3 exploration is preserved, not upgraded to a golden full transaction here. '+pending),
('ReitzKHRT accepted child event',pending),
('ORourke collision event','Actual ORourke.update() executes unchanged. The proof is its cleanup count-changing event; no pair collision/coalescence mutation is certified. Kernel-entry scope is explicit.'),
('ORourke merge/delete result','Delete PASS as an observation, conservation FAIL: A107→106, B149→148, C191→190. A positive 5e-16kg represented parcel disappears with native mass/species transfer zero. Adapter rejects PARCEL_SPECIES_LEDGER_MISMATCH. Merge/coalescence reachability and accepted conversion remain unproven; see OROURKE_CLEANUP_LEDGER_AUDIT.md.'),
('Rebound transaction',pending),
('Minimum-mass deletion','Two different paths audited. ReactingParcel::calc adds coupled residual transfers; ORourke cleanup simply deletes. The latter is a blocker for full branch-closure claims. Frozen disappearance regression remains PASS and is not evidence for collision cleanup.'),
('Combined-event retry',pending),
('Runtime support-failure retry','T2 scan replays PASS; no new tracking-runtime failure hook or full retry proof is claimed. '+pending),
('Source/thermo-failure search/result','NOT SEARCHED: stop occurred before QTrial could be built. Do not label NOT TRIGGERED IN CERTIFIED TEST ENVELOPE without the requested search/margins.'),
('Trace-gas event','T3A trace refresh and frozen source tests replay PASS; new full trace event transaction is '+pending),
('Pure-liquid rejection','Unchanged frozen policy; T3A controlled refusal replays PASS. No gas manufacture, alpha source or tiny-gas insertion.'),
('Persistent output architecture','NOT IMPLEMENTED. No new event-specific transaction API or speculative filesystem commit primitive was added. T3A publication architecture stays frozen; future accepted-output exactly-once preparation/publication remains a blocker.'),
('Accepted output exactly-once','NOT TESTED; accepted commits=0. Test diagnostic logs/ledger files are not production accepted output.'),
('Rejected output','Zero native permanent files in copied fixtures, confirmed by full file-tree hashes. Diagnostic rejected EVENT_LEDGER_v1 evidence is intentionally kept outside the case.'),
('VoidFraction trajectory result','Frozen native trajectory-time semantics and output suppression unchanged; not replaced by occupancy. New accepted trajectory-output commit is '+pending),
('Mass ledger','Native cleanup observed ΔmParcel=-5e-16kg, ΔmCarrier=0: unclosed at model-kernel entry. No external mass sink is defined. Adapter fails before Q conversion. Rejected committed increment is exactly zero.'),
('Species ledger','All deleted parcel mass is C10H22; native species transfer zero. The frozen endpoint check detects this directly. No normalization, source correction or tolerance relaxation.'),
('Momentum ledger','Before deletion momentum=(2.35e-14,0,0)kg·m/s, native UTrans=0. Frozen dM is NOT AVAILABLE because conversion stops at species. No fabricated accepted impulse.'),
('Total-energy ledger','Endpoint raw liquid H, kinetic energy and volume are recorded; frozen gas reference treatment unchanged. No converted dEt or accepted total-energy closure is claimed after the earlier mass/species refusal.'),
('Kinetic-energy double-count result','Frozen drag/mass/combined energy-reference regression replay PASS with golden CSV byte equality. New accepted event-level closure is NOT COMPLETE.'),
('JANAF reference result','Unchanged gas sensibleInternalEnergy/Hc compatibility goldens replay PASS. C_L remains unused for DPM→gas. No arbitrary q/reference repair.'),
('Canonical direct/retry equivalence','NOT COMPLETE; no direct-small/rejected-large canonical equality is claimed.'),
('Post-commit future equivalence','T3A prescribed-carrier 10-step proofs replay PASS. New coupled T3B accepted-event ≥10-step proofs NOT EXECUTED.'),
('Sequential commit result','T3B accepted commits=0. T3A129/seed promotions remain baseline evidence, not T3B100 coupled commits.'),
('Alternating commit/discard result','Only failed cleanup discard observed; no alternating accepted/rejected event series.'),
('Registry/reference result','Native trial scope retirement restores registered count; stable external carrier field identity/schema checks are unchanged. T3A3000 prepare/discard cycles replay PASS.'),
('Carrier-generation result','Failed conversion/discard leaves committed generation unchanged. No stale interpolation override or publication bypass was introduced.'),
('Eight-model capability matrix',matrix+'\n\nPending labels are shared gate blockers, not evidence that every model has a physical defect. No model is disabled or relabelled FULL-SERIAL-TRANSACTION-SAFE.'),
('Frozen regression result','PASS: source/energy9288, rebinding6375, T2native1725880/all-gas21000, T3A64395, critical105775+subULP1000 steps/scheme, temporal9663. New native cleanup preflight57 assertions/0 failures reproduce the controlled physics-ledger rejection; zero test failures does not mean conservation passed.'),
('Performance/memory result','Native preflight resource measurements: '+json.dumps(resources)+'. No 100-commit event performance or leak proof claimed; frozen 3A/T3A lifecycle tests replayed. Full performance evaluation remains pending.'),
('Project-local overrides','Only new passive test EventLedgerV1, native-kernel preflight and preparation/finalization tooling. Reuse frozen T3A generation/publication, model adapters and output isolation without modification. No native source or random codec override.'),
('Active solver impact','**NONE.** SHA-256 audit verifies active solver/equations/Make, frozen libraries, T3A and previous evidence unchanged; actual 300_2D all96 files unchanged. Independent test wmake PASS; no CFD.'),
('Production patch status','FUTURE_PATCH_DEPENDENT: Mapping-A/xNozzle15mm/bottom/+y design remains frozen. No production patch or BC created; TEST_DPM_INLET used only in all-gas test history.'),
('Remaining blockers','Earliest blocker: ORourke positive-mass cleanup lacks a compatible native mass/species transfer under current frozen adapter. Ordinary coalescence→cleanup reachability still needs proof. Complete codec, all event/retry/generic recovery/runtime support/persistent output/conservation gates remain. Next gate is reachability and conservative policy review; no unauthorized repair.'),
('Whether T3B COMPLETE','**NO. PARTIAL / EVENT_LEDGER_BLOCKER.**'),
('Whether T3 COMPLETE','**NO.** T3A remains COMPLETE, T3B PARTIAL.'),
('Whether T4 may start','**NO.** T3 is not COMPLETE; no MPI work performed.'),
('Whether M8A COMPLETE','**NO. PARTIAL.**'),
('M6B.0 permission','**NO.**'),
('M6B.1 permission','**NO.**'),
('Updated milestone matrix','| Milestone | Status |\n|---|---|\n| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE |\n| M8A source/energy | PASS / FROZEN |\n| M8A.3A | COMPLETE |\n| T1 | COMPLETE / DESIGN ONLY |\n| T2 | COMPLETE / STRICT-SUPPORT FEASIBLE |\n| T3A | COMPLETE / SERIAL CARRIER-PUBLICATION CONTRACT |\n| T3B | PARTIAL / EVENT_LEDGER_BLOCKER |\n| T3 | PARTIAL |\n| T4 | NOT STARTED / NO |\n| M8A | PARTIAL |\n| M6B.0 | BLOCKED / NO |\n| M6B.1 | NO |\n\nSTOP under user section48; no further events, T4, M6B or CFD.')]
assert len(sections)==50
report='# M8A.3B-T3B event ledger stop gate\n\n2026-10-02. Evidence: `fitting/dpm/m8a3b_t3b_v1`. Scope is an actual native collision-kernel cleanup preflight, not a completed full cloud transaction.\n\n'+'\n\n'.join(f'## {i}. {title}\n\n{body}' for i,(title,body) in enumerate(sections,1))+'\n'
(b/'M8A3B_T3B_SERIAL_EVENT_LEDGER_GATE.md').write_text(report,encoding='utf8')
status=b/'MILESTONE_STATUS.md';old=status.read_text(encoding='utf8');marker='## M8A.3B-T3B serial event-ledger stop (2026-10-02)'
if marker not in old:
 old+='\n\n'+marker+'\n\nPARTIAL / EVENT_LEDGER_BLOCKER. Actual unchanged ORourke.update cleanup\nremoves positive5e-16kg below native minParcelMass1e-15kg, with no carrier\nmass/species transfer; frozen adapter refuses PARCEL_SPECIES_LEDGER_MISMATCH.\nA/B/C evolved histories reproduce kernel-entry count107->106/149->148/191->190,\n57 assertions/zero test failures; no accepted commit. This is NOT full cloud\ntimestep/coalescence reachability proof, and NOT complete transactionState-v1\ncodec. Discard inspected cloud/Q/carrier/generation/allocator/registry sentinel\nPASS. Under user section48, event development stops; no source/physics repair.\nAll mandatory frozen regressions including T3A64395 PASS; actualcase and active\nsolver, T3A architecture, frozen source/P2/R1/EOS and historical evidence\nunchanged. No CFD. T3 remainsPARTIAL, T4NO, M8APARTIAL, M6B.0/1NO. Next gate:\nordinary coalescence->cleanup reachability and explicit conservation-policy\nreview before resuming codec/event/retry/output closure. See\nOROURKE_CLEANUP_LEDGER_AUDIT.md, M8A3B_T3B_SERIAL_EVENT_LEDGER_GATE.md and\nfitting/dpm/m8a3b_t3b_v1. STOP.\n'
 status.write_text(old,encoding='utf8')
archive=b/'checkpoints/M8A3B_T3B_event_ledger_v1_PARTIAL.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for root in (e,b/'tests/fiveEqDPMEventLedger'):
  for p in root.rglob('*'):
   if '/Make/linux' in p.as_posix() or '/lnInclude/' in p.as_posix():continue
   if p.is_file() and not p.is_symlink() and p.suffix not in ('.o','.dep'):z.write(p,str(p.relative_to(b)))
 for name in ('M8A3B_T3B_SERIAL_EVENT_LEDGER_GATE.md','OROURKE_CLEANUP_LEDGER_AUDIT.md','MILESTONE_STATUS.md','tools/m8a3b_t3b_prepare.py','tools/m8a3b_t3b_finalize.py'):z.write(b/name,name)
(e/'checkpoint.json').write_text(json.dumps({'path':str(archive),'sha256':sha(archive)},indent=2),encoding='utf8')
print(json.dumps({'status':summary['status'],'eventChecks':57,'T3Achecks':64395,'activeSolverImpact':'NONE','checkpoint':str(archive)}))
