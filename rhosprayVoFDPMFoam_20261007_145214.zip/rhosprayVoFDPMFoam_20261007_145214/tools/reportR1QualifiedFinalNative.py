"""Write the requested 50-item report only after the fresh gates pass."""
from pathlib import Path
import json,csv,math
b=Path(__file__).resolve().parents[1]
s=b/'fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1'
d=json.loads((s/'R1_FINAL_gate.json').read_text())
assert d['status']=='R1 FINAL COMPLETE' and not d['failed']
def rows(p):return list(csv.reader(p.open()))
c=s/'pilot_corrected'
end=[rows(p)[-1] for p in c.glob('processor*/R1_continuation.csv')]
counters={name:sum(int(r[k]) for r in end) for name,k in [('drag',4),('stochastic',5),('random',6),('KH',8)]}
birth=[r for p in c.glob('processor*/PW1_births.csv') for r in rows(p)]
nps=[float(r[4]) for r in birth]
reg=d['regressions']
items=[
('结论','**R1 FINAL COMPLETE**，限定为当前 OF7 native、50 parcels/s、两 rank 固定网格有界 fixture。S2/T4/M8A 保持 PARTIAL；不扩展为生产认证。'),
('Weighted parcel 基础','采用冻结 PW1 COMPLETE / OF7-NATIVE WEIGHTED PARCEL QUALIFIED。无需 superparcel、自定义 multiplicity 或 runtime merge。'),
('Native 实现','实际调用 OF7 ConeInjection、InjectionModel、Cloud::move、native streams/iNew、sphereDrag、stochasticDispersionRAS、ReitzKHRT、ORourke、VoidFraction。已有项目包装与冻结 ZS1/ID1 策略保留。'),
('采样率','parcelsPerSecond=50。候选字典与 PW1 candidate_final 的 roleA/roleB 文件逐字节一致。'),
('物理参数冻结','SOI=1 s、duration=1 s、massTotal=0.0005262723452 kg、RosinRammler 200–300 μm、组成、300 K、速度规则、锥形几何和原有模型系数不变。此测试 fixture 不是 production 入口工况。'),
('Injection requested','12 个 dt=0.2 s 步；有注入的每步 requested=10，零注入步保持零；每步 requested=actual added。'),
('Injection actual','每个主运行实际新建 50 parcels，全局最大 population=50；不存在百万 parcel batch。'),
('nParticle',f'出生 nParticle 全部有限且正；min={min(nps):.17g}，mean={math.fsum(nps)/len(nps):.17g}，max={max(nps):.17g}。由 native mass-basis 权重产生。'),
('Identity','每个独立运行中出生 identity 唯一，所有穿越四个边界记录一一对应；不同进程运行允许重新从初始 identity 起始，统计按 run 分域。'),
('代表质量','50 个出生 parcel 的 Σ nParticle × singleDropletMass 与物理注入质量相符至 roundoff；没有为减少计算 parcel 而减少物理质量。'),
('RNG 完整状态','记录 x_、scalarNormalStored_ 和 scalarNormalValue_ 的标量 bits；缓存标志和值纳入精确比较。'),
('Prepare RNG','1050 个本轮主运行穿越的 SEND_BEFORE_PREPARE/SEND_AFTER_PREPARE RNG 精确一致。'),
('Correct RNG','RECEIVE_BEFORE_CORRECT/RECEIVE_AFTER_CORRECT 的本地 RNG 精确一致；迁移不抽取随机数。'),
('Serial reference 定义','对迁移后同一 parcel、同一目的 owner 的状态，直接调用 native stochasticDispersionRAS 作串行无迁移下一更新参考；仅为配对测试恢复该 owner 的本地 RNG 副本，再运行实际 continuation。没有 rank RNG 同步，也没有声称两条独立完整 serial/MPI cloud 轨迹相同。'),
('RNG next-result',f'{d["RNGNextRecords"]} 个 weighted parcel 的下一 RNG、UTurb、tTurb、native update 返回值全部 bit 相同；其中 47 个探针真实消费 RNG，3 个依照 native 涡寿命规则保留现有 UTurb 并推进 tTurb；两条路径的参考和 continuation 均精确一致。'),
('Fresh stochastic calls',f'新 pilot 的记录累计 stochastic update calls={counters["stochastic"]}。数据来自本轮运行，不引用历史 droplet 结果。'),
('Random consumption',f'记录的 randomCalls={counters["random"]}，含义是发生器 uniform 序列发生改变的 stochastic 更新次数，不冒称底层随机抽样总个数。每步另有完整 state before/after，50 个 next-result 探针也记录缓存状态。'),
('UTurb','真实 native evolve 步已有 UTurb≠0，50 个下一更新探针也全部产生非零 UTurb；不是只调用一个不更新的模型。'),
('Fresh drag',f'记录累计 native drag calls={counters["drag"]}；保存 {d["dragSegments"]} 个具有非零速度变化和非零源项的实际轨迹段。observer 只读 native 调用及结果。'),
('Drag source','记录单滴 mass、nParticle、ΔU 和 UTrans 增量。比较实际 source 与 nParticle × mass × (U_before−U_after)，避开壁面反弹对全局动量比较的混淆。'),
('Single weighting',f'最大 |source−nParticle×mass×(U_before−U_after)|/|source|={d["dragMaximumRelativeResidual"]:.17g}，小于预先沿用的 1e-12 roundoff 检查界限。无额外 nParticle 因子。'),
('VoidFraction repeated',f'pilot 原生 postMove 轨迹段计数={d["pilotVoidSegments"]}；50 次穿越，超过 ≥10 要求。另有 20 个独立运行全部逐步通过。'),
('Theta 公式','沿用 native dt × nParticle × singleDropletVolume，再按本步 dt 与 cell volume 归一化。轨迹 oracle 不写 theta；native function object 写 theta。'),
('Theta 对照','每个 rank、每个步的 cell theta 与独立累计轨迹值逐 bit 检查，所有 PW1_void.csv verdict=1；没有 double weighting。'),
('KH bounded compatibility',f'本轮 pilot native KH calls={counters["KH"]}；保持 CRT=.1、有界参数和有限状态。正常退出，无 SIGFPE。此项不认证 KH 统计收敛。'),
('ZS1/FPE 边界','冻结 ZS1 项目调用点策略原样使用。没有修 FPE1/FPE2，没有修改 Foundation 模型公式或系数。历史失败证据保留。'),
('Native child path',f'fresh K1: checks={reg["k1"]["checks"]}，failures=0；births={reg["KH_identity"]["births"]}，independent identity negative checks={reg["KH_identity"]["identityNegativeChecks"]}，later child queries={reg["KH_identity"]["laterChildQueries"]}。测试专用拒绝注入仍不是实际空间无效支撑证明。'),
('ORourke','当前 weighted cloud 的 native ORourke 更新实际执行并正常结束；新模型计数包含每个 evolve 的 updates。'),
('统计范围','collision statistics NOT CERTIFIED。随机弥散、破碎和碰撞的采样率依赖仍是 native 模型限制；不宣称采样或喷雾统计收敛。'),
('MPI crossing',f'本轮 pilot={d["pilotCrossings"]}，独立压力测试={d["stressCrossings"]}，主验证总数={d["pilotCrossings"]+d["stressCrossings"]}；这些是实际 Cloud::move processor crossing，不是序列化循环次数。'),
('Ownership','主压力测试为 0→1 穿越；每次 send/receive quartet 完整，identity/physical fields/history/barycentric reflection 正确，逐步全局 one owner。N1 另有 forward/reverse destination rejection 回归。'),
('Independent runs','20 个独立启动的 bounded MPI runs，每个 12 步、50 次穿越。不是单个 case 做 1000 次穿越；独立运行共享固定测试初始分布不构成统计独立样本认证。'),
('≥1000 gate',f'20×50={d["stressCrossings"]} 次成功 native 穿越，不使用历史计数、不计入 pilot，也不计入 I1 内部回滚循环。'),
('Normal exit/no timeout',f'20 个 exit code 全为 0，wall={min(r["wallSeconds"] for r in d["runs"]):.2f}–{max(r["wallSeconds"] for r in d["runs"]):.2f} s；每个 55 s watchdog 未触发。'),
('Lifetime','主运行每 rank constructed=destroyed=50，live=baseline=0。非空 accepted rollback 保留 accepted baseline，并要求 trial ctor/dtor 对称、最终 live=baseline。'),
('Registry','主运行 registry 稳定；discard 后 delta=0，carrier binding 清空。回滚和 N1 回归同样检查 registry 与 live baseline。'),
('Nonempty rollback','使用同一个 50 parcels/s、SOI=1 的原物理字典，6 个 0.2 s native warmup 步形成 accepted weighted cloud；再运行一个普通 trial 并 discard。before/after accepted parcel 全流字节一致。'),
('Allocator','discard 检查 native particleCount_==accepted allocator，完整 accepted codec key 相同，不仅检查 parcel 数量。'),
('RNG/nParticle/identity restore','完整 codec 覆盖 accepted RNG、normal cache、nParticle、identity、模型状态、时间和源数组；accepted before/after stream 也精确一致。'),
('Source/output rollback','pending ticket 在 discard 后不发布，output publications=0；accepted carrier view/source state 完整 key 恢复。没有认证跨 rank global transaction。'),
('Fresh S1 subset',f'重跑 distributed support mixed/trace/absent/generation/pose 和 topology/native-weight 检查；support checks={sum(x["checks"] for x in reg["s1"])}，topology checks={sum(x["checks"] for x in reg["s1_topology"])}，全部 globalFailures=0。范围仍是固定 2-rank mesh。'),
('Fresh N1','新启动 valid、forward invalid、reverse invalid 三个运行；预期支撑拒绝受控返回、ownership 合法、discard 精确；globalFailures=0。'),
('Fresh C2',f'重新编译并运行 basic codec: {reg["c2"]["checks"]} checks / 0 failures；并有主运行 native stream full-state migration oracle。'),
('Fresh I1',f'重新编译并运行 matrix: {reg["i1"]["checks"]} checks / 0 failures；该内部循环不冒充 native 穿越计数。'),
('Fresh R2B',f'重新编译并运行 lazy carrier: {reg["r2b"]["checks"]} checks / 0 failures。'),
('Hashes','本轮 post-test Foundation 6717 文件、native parcel 19 文件全部 SHA-256 PASS；项目 frozen_before 26479 项未变。所有新 executable、输入/日志和 artifacts 另入不可覆盖 checkpoint。MILESTONE_STATUS 仅随后追加本轮记录。'),
('新增/修改文件','只新增隔离 Native/Rollback/K1/C2/I1/R2B/N1/S1Support/S1Topology 目标和本轮 fixture、审计/报告/封存工具；Native 相比 PW1 仅 main 与 Make/files 不同。初次只读 collision observer 类型不匹配导致 bad_cast；仅修正测试 cast。非空回滚首轮仍使用空 cloud 数量断言，rank1 的 10 个合法 accepted parcels 因而被误报；其余状态/回滚检查均通过，仅修正测试初始数量断言。MPI exit0 曾掩盖该结果文件失败，驱动发现后中止 I1，保留已启动的 K1/C2 记录，再添加逐项 JSON guard 并重新运行全部回归。回滚误报的原始代码/二进制以及两次尝试的日志/哈希保留。首次离线汇总另误要求每个 next-update 都抽样、以及非空 accepted cloud 必须在 rank0；按 native 涡寿命行为和实际目的 owner 修正这两个测试期待，原汇总保留。无物理模型修复。'),
('Active impact','**NONE**。active solver、方程、thermo、KT、coupling 和冻结共享实现未修改。没有 CFD 验证，也没有生成生产注入配置。'),
('Production impact','**NONE**。production restart NOT CERTIFIED；没有 global MPI source/output transaction，未进入 M6B 或 two-phase activation。'),
('T4 状态与 STOP','R1 FINAL COMPLETE；PW1、R2-FINAL、T3、T4-S1、C1-N1、ZS1、ID1 冻结不变。S2/T4/M8A 保持 PARTIAL；T4-S3 NOT AUTHORIZED。本轮到此 STOP。')]
assert len(items)==50
text='# M8A.3B-T4-S2-R1-FINAL-NATIVE — 50 项报告\n\n日期：2026-10-04。所有数值验证为离线 native parcel/cloud fixture；未运行 CFD。\n\n'
text+='\n\n'.join(f'## {i}. {title}\n\n{body}' for i,(title,body) in enumerate(items,1))+'\n'
(b/'M8A3B_T4_S2_R1_FINAL_QUALIFIED_NATIVE_REPORT.md').write_text(text,encoding='utf-8',newline='\n')
milestone=b/'MILESTONE_STATUS.md'
entry='\n\n## M8A.3B-T4-S2-R1-FINAL-NATIVE — COMPLETE / bounded native gates (2026-10-04)\n\n'
entry+=f'R1 FINAL COMPLETE within frozen PW1 50parcels/s two-rank fixedmesh scope. Physical candidate dictionaries unchanged. Fresh pilot50crossings plus20independent bounded runs×50=1000stress crossings, allnormalexit/no timeout/oneowner; fullnative streams/history/geometry/RNGprepare-correct exact. Fifty sameparcel destinationowner serial-no-migration next stochastic reference comparisons bitPASS, notwholecloud serialtrajectory orrankRNG synchronization. Freshnonzero UTurb/RNGconsumption anddragactualsource singleweight residual{d["dragMaximumRelativeResidual"]:.3e}; repeatednative theta allsegmentsPASS. NativeKHfinite/currentfrozenZS1 plusfreshK1childrenPASS, noFPE/modelrepair/noKHstatisticalclaim. NativeORourke executes, collisionstatisticsNOTCERTIFIED. Nonemptyaccepted weighted candidate ordinarytrialdiscard exactcodec/allocator/RNG/nParticle/identity/source/output/lifetime/registryPASS. FreshK1/C2/I1/R2B/S1support+topology/N1valid+forward+reversePASS. PosttestsFoundation6717/nativeparcel19SHA PASS,26479frozenentries unchangedbeforeauthorized append. Firstobserverbad_cast andnonemptytestinitialpopulation assertionattempts retained, onlyisolatedtestscaffold repaired;resultJSONguards added. NineisolatedtargetscompiledPASS; allshared/frozen/active/production NONE. S2/T4/M8APARTIAL;S3NOTAUTHORIZED/globaltransactionNO/M6BNO/CFDNO/restartNOTCERTIFIED. See M8A3B_T4_S2_R1_FINAL_QUALIFIED_NATIVE_REPORT.md. STOP.\n'
with milestone.open('a',encoding='utf-8',newline='\n') as f:f.write(entry)
print('Wrote 50-item report and append-only milestone entry')
