from pathlib import Path
import re,json
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_o1_v1'
for s in 'ABC':
 src=(e/'fixtures'/s/'constant/polyMesh/points').read_text()
 def point(m):
  x,y,z=map(int,m.groups())
  if x<7:return m[0]
  return f'({7+(x-7)*2e-5:.17g} {0.5+(y-.5)*2e-5:.17g} {0.5+(z-.5)*2e-5:.17g})'
 (e/'branch_fixtures'/s/'constant/polyMesh/points').write_text(re.sub(r'\((\d+) ([01]) ([01])\)',point,src))
d=json.loads((e/'design.json').read_text());d.update(branchMesh='last cell is 20 micrometre cube; nominal seeded DPM volume fraction about 0.173; no production frequency claim',seedMassKg=[1e-12,1.05e-15],seedDiameterM=[1e-6,5e-8],seedKHindex=1,seedRelativeVelocityMS=10,dtBranch=1e-8)
(e/'design.json').write_text(json.dumps(d,indent=2))
