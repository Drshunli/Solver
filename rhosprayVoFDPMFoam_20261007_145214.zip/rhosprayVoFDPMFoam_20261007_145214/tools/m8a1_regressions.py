from pathlib import Path
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a1_v1'
s=(b/'fitting/dpm/m8a_v1/run.sh').read_text(encoding='utf-8').replace('fitting/dpm/m8a_v1/','fitting/dpm/m8a1_v1/energy_regressions/')
(e/'run_energy_regressions.sh').write_bytes(s.encode())
