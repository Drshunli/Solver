from pathlib import Path
import json,hashlib,zipfile
b=Path(__file__).resolve().parents[1];e=b/'fitting/integration/m5c3_v1'
r=json.loads((e/'assessment_results.json').read_text(encoding='utf8'))
sections=[
('M5C.3 status','**COMPLETE / STANDALONE CONTRACT / NOT ACTIVE**。33 项门槛全部通过；这只关闭本轮独立契约门槛，不代表活动输运、生产边界或 CFD 验证完成。'),
('Legacy temporal audit','实际顺序：alpha/MULES → 界面及诊断物性 → parcel 演化 → rho → rhoU → rhoY/反应 → rhoE/thermo → turbulence → write。非 LTS 步长使用上一轮 Co；当前 case 的 ddt 为 Euler。详见 LEGACY_TEMPORAL_ORDER_AUDIT.md，包含 mesh、oldTime、thermo 和各条件分支的源码审计。'),
('Frozen fiveEq stage ordering','Qn/P2 完整恢复 → 初步时间步约束 → R1 重构 → 面状态恢复 → 单一共享 KT 通量 → 通量相关代数约束及 alpha 非保守源 → 完整 trial Q/P2 → 全部单元恢复 → 原子提交或拒绝。通量相关约束必须在通量建立后细化，不能使用新 Q 与旧压力混合计算。'),
('State ownership per stage','每层唯一权威状态：P2、mG、mL、M、Et、mYi，加体积和时间元数据。alphaL/alphaG、rhoMix/U/Y 为派生视图；p/TG/TL/rhoG/rhoL/cMix 为该层恢复缓存。q[0] 是兼容视图。新增 FIVE_EQ_FIELD_OWNERSHIP_FINAL_v3.md；旧 v2 不变。'),
('dt/retry contract','保留冻结的 acoustic/alpha/mG/mL/species/volume 约束及 .95 安全系数。内部 trial 非法时从同一 Qn 细化 connected dtThermo 并重试；所有单元恢复成功才提交。认证边界 high-only outward 可全通量退回 R0；high+low outward 停止。未认证的零合法步长必须受控停止请求分类，不能假造 EOS 耗尽证据或强行小步。'),
('P2 oldTime contract','保存 signed minority coordinate 原始位，包括 -0；不得从 decoded alpha 重新编码。实际 Foundation7 GeometricField::oldTime 测试 **192 项、0 失败**。两侧 1e-8/1e-12/1e-16/1e-20、纯相和半相，恢复后更新逐位一致。'),
('P2 restart serialization','真实 Foam scalarField 流测试：ASCII 6 位有 5/16 个位模式不一致；ASCII 17 位有 1/16（-0→+0）；本机 DP binary 为 0/16。正式冻结精确位记录：每个 double 使用 16 位十六进制 IEEE binary64 数据。普通 ASCII 权威 P2 重启禁用。'),
('Restart trace preservation','两侧 1e-20 微量相在精确保存、读取及续算后保留；dominant decoded alpha 可以仍为 1，但它没有重启权威性。-0 与 ±0.5 分支标记也精确保留。'),
('Restart versioning','已实现 fiveEqRestart-v1 / P2-v1 / binary64-hex-msb、ndecane_gibbs_v1 与运行时组分顺序元数据、FNV64 校验。未知版本即使校验正确仍拒绝；损坏、组分顺序不匹配、非法完整状态均受控失败。FNV 用于意外损坏检测，不是安全认证。'),
('Legacy restart policy','拒绝仅 alphaL 或气相 legacy 数据作为 fiveEq restart。单独授权的冷启动转换必须明确已丢失的 trace 信息，并从物理输入及生产 EOS 生成完整 Q；本轮不提供自动转换。'),
('P2 communication test','8 字节网络顺序 pack/unpack 逐位通过。完整状态分成 3 个离线分区，写入、清空内存、重读、按地址合并后 Q/P2/oldTime/体积一致。实际 processor、decomposePar、reconstructPar 集成尚未执行。'),
('Boundary builder API','fiveEqBoundaryStateBuilder::build(BoundaryPrimitive) 返回完整 PrecisionCell；recoverBoundaryState 使用同一 P2-aware 恢复。提供法向反射及正交变换辅助函数。该构造器是物理状态构造器，不是已完成的特征边界 patch。'),
('Pure-gas boundary result','纯气 p/T/U/Y → 实际 OF7 JANAF/perfectGas EOS → Q → 恢复：PASS。P2=+0、mL=0、mG=rhoG、Et=mG eG+动能；没有硬编码 gamma 或 Rair。'),
('Pure-liquid boundary result','纯液 p/TL/U → ndecane_gibbs_v1 → Q → 恢复：PASS。P2=-0、mG/mYi=0、mL=rhoL。这是状态测试，不等同于正式质量流入口 BC。'),
('Mixed boundary result','144 个初始/边界状态覆盖纯相、混合相和两侧 trace；p=0.1/3/8 MPa，U=0/47/2013.039 m/s，含横向速度。使用 TG=400 K、TL=300 K 独立温度：PASS。'),
('Liquid injection BC contract','控制单孔 mdot=1.09609e-4 kg/s 与 TL=300 K。响应压力及法向速度由“patch 集成 KT 液体质量通量=-mdot”和域内出射声学兼容关系联合决定；3 MPa 只作参考初态。生产参考密度下速度筛查约 2.1316743 m/s，不能写成固定 U。2D 厚度/等效质量流映射及完整特征 patch 求解尚需后续接入。'),
('Gas inflow/outflow contract','使用相对法向速度 un±cMix 判断特征方向。超声速入口给全部独立状态，出口由完整 Q 外推；亚声速入口用入射物质/热/切向数据及一个声学控制条件配合出射兼容关系；亚声速出口只指定一个入射声学条件。现有 pressure-based 边界组合不能直接照搬。'),
('Wall/symmetry contract','静止无黏壁面/对称面保留 P2、质量、Et、组分，仅反射法向 M，法向物质与能量通量为零、压力牵引保留。empty 排除非物理方向；wedge/coupled 正交变换旋转 M、保留 P2 位及 Et。反射/旋转测试通过；黏性壁面、壁面传热及接触角仍需相应物理适配。'),
('Boundary recovery result','构造后的完整 boundary Q 使用 P2-aware cell/face 等价恢复；非法 TL 和能量拒绝，不 clamp。采用继承门槛 p 相对 1e-8 或绝对 1e-4 Pa、温度相对 1e-8、U 绝对 1e-7 m/s、Y 1e-12；根求解与其内部容差未改。'),
('Initialization API','fiveEqInitialStateBuilder 复用物理状态构造器：物理 primitive/material 输入 → 生产 EOS → 完整 Q/P2 → 全状态恢复 → oldTime=初始 committed。禁止 legacy rho/rhoE 与 alpha 独立拼接。'),
('Initial gas state','工程参考 p=188330.307 Pa、T=400 K、Y=(0,.228,.772)：实际 OF7 rhoG=1.63268590011162 kg/m³、eG=-11812.9587301765 J/kg。nominal rho=1.6338 不覆盖 EOS。磁盘 300_2D 的旧入口数据不同，本轮没有修改算例。'),
('Initial liquid state','pL_ref=3 MPa、TL=300 K：生产 EOS rhoL=727.432960545318 kg/m³、eL_solver=-66.4153259710411 J/kg。负 sensible 能量符合冻结参考约定；没有 CoolProp runtime 初始化。'),
('Initialization roundtrip','纯气、纯液、混合、两侧 trace 及高速度状态往返通过。最终综合构造/边界/时间/IO/账本测试 **9663 项、0 失败**。'),
('Future startup fields','冷启动 MUST_READ 物理初始化配置；重启 MUST_READ 完整精确位 bundle，包含 P2/Q、oldTime、体积及时间。运行时 P2/Q 从该唯一来源建立；普通输出字段不再独立成为重启来源。mesh/thermo/species 配置 MUST_READ 并匹配身份。详见初始化契约中的 NO_READ/AUTO_WRITE/诊断 READ_IF_PRESENT 表。'),
('Derived-field restart policy','p/T/rho/c/U/Y/decoded alpha 没有磁盘权威性。旧诊断输出只能核对并由完整 Q 恢复覆盖，不能反向修改 Q。'),
('Source ownership audit','完整表覆盖对流/压力、黏性应力及功、导热、组分扩散、化学/湍流、fvOptions、辐射、重力、DPM 和表面张力，并指定未来目标与时间位置。当前 fvOptions 仅创建，无活动源调用；重力及部分 parcel 耦合仅在黏性分支，这是实际源码事实。'),
('Chemistry-energy audit','实际 Es=Hs-p/rho，Hs=Ha-Hc，Qdot=-ΣHc RR。未来 bulk 组分源 S_mYi 与 Et 源 -ΣHc S_mYi 同时更新，闭合 Et_sens+ΣmYi Hc。实际 Hc 离线账本恒等式通过；当前 none/无活动机制的零源已闭合。反应启用仍须真实机制、气相体积适配、source-step 恢复及扩散账本验证，明确为 PRE-M6B reactive-mode blocker。'),
('DPM future source contract','M8A：parcel mass→mG，momentum→M，energy→Et，species→mYi；等量反向 parcel 账本、一次 V/dt 归一化、气相 carrier 采样、重试回退、动能/压力功/能量参考/P2 响应必须统一。Sh 不能直接视为 Et 源。本轮仅冻结接口。'),
('Surface-tension source status','未来 M7 负责 M 与配对 Et 功/界面能账本；现有界面力仍只作诊断，未激活。'),
('Temporal/source ordering','未来采用通量 trial → 完整恢复 → 显式声明的 source stage → 完整恢复 → 原子提交。source 失败必须回退整个步；不支持的反应/黏性/传热/湍流/辐射/毛细模式必须拒绝启用。当前独立 driver 的非零物理源为空，M8A 负责 parcel 回退安全。'),
('Synthetic temporal driver','R1-P2-residualSpecies-v1，固定网格、周期、Euler，实际 EOS、共享 KT、完整 trial/recovery/commit/IO。四组各 100 步：尖锐接触、trace gas、trace liquid、半相分支。没有真实 CFD case run。'),
('Restart-continuation result','连续 100 步与 50 步→写盘→销毁状态→读取→50 步：**4/4 最终逐位相同**，比较所有权威 Q/P2、oldTime、体积、time/dt/step。综合新 driver 最大压力接触误差约 2.34799e-11。'),
('Retry/restart integrity','真实过大 trial 拒绝 1 次，从原 anchor 细化步长后接受；随后重启续算仍逐位相同。非法 anchor 受控停止且 committed/oldTime/clock 不变。trial buffer 不写盘。'),
('P2 branch-switch restart result','在实际跨 0.5 更新的前后分别写入/读取，并继续更新：逐位 PASS。100 步分支测试也保持压力连续，无 decode/re-encode。'),
('Pressure-contact worst-case regression','冻结 1000 步 R1 moving contact 重跑：baseline/O0 约 9.832876846e-9；替代求值顺序最坏 **9.855119165180781e-9 < 1e-8**，余量约 1.4488%。容差、EOS、能量参考和冻结求值顺序未改；不宣称任意编译器/步数都保持该余量。'),
('Frozen regression status','11 组已接受 D 测试的机器结果与旧记录一致；recovery/bridge/flux/admissibility/C1/fixed-species/实际 OF7 插值通过。原 B 的 14 项 face failure 和 26 项 audit failure 作为历史负控正确复现，不算新失败。全部输出位于新目录，历史证据未改；本轮 cost 输出仅用于回归，不作新性能结论。'),
('Added files','新增五份 fiveEqIntegration 头文件、两个独立测试目标、legacy 时间审计、五份 docs 契约/审计、ownership v3、本报告及可复现工具/证据。现有文件仅更新 ENERGY_REFERENCE_AUDIT.md 和 MILESTONE_STATUS.md。'),
('Compile status','Foundation7 C++11、-Werror：两个新目标编译 PASS。最初新头文件缩进警告已修正，日志保留；ASCII17 的错误“预期无损”假设被证据推翻，初始失败保留，最终改为明确禁止。安装的生产 EOS/thermo 库 SHA256 与 D 一致。活动求解器本轮没有重新编译或激活。'),
('Active solver impact','**NONE**。1985 个审计保护文件中，1983 个不变，另外 2 个仅为上述授权文档更新。活动主程序、方程、alpha、KT、时间步、cloud、case、冻结 EOS/P2/recovery 均不变；没有运行 CFD。'),
('Remaining blockers','强制 M8A 守恒/能量/回退适配；实际 field registry、特征 patch、decomposition 和原子 checkpoint wiring；2D 注入量映射；启用各反应/黏性/传热/扩散/湍流模式前的对应适配。独立 IO 的直接写盘会由校验拒绝部分文件，但生产分区/mesh/parcel 原子发布和配置指纹绑定仍需后续实现。'),
('M8A start permission','**ELIGIBLE FOR NEXT USER REQUEST / NOT STARTED**。本轮只到 M5C.3；未执行 M8A。'),
('M6B permission','**NO / BLOCKED**。必须先完成 M8A，并重新审核全部冻结 M5C/M6A 门槛及启用物理配置；本轮 COMPLETE 不授予活动输运权限。'),
('Updated milestone matrix','''| 阶段 | 状态 |
|---|---|
| M0–M4 | COMPLETE |
| M5A/M5B | COMPLETE / ACTIVE REFERENCE / ACTIVE DESIGN |
| 生产 EOS / fiveEq recovery / KT flux | 保留原冻结完成状态 |
| M5C.1 / M5C.2A / M5C.2C.1 / M5C.2D | COMPLETE / STANDALONE |
| M5C.2 | COMPLETE / STANDALONE |
| M5C.2C.2 | NOT REQUIRED BY CURRENT EVIDENCE / NOT STARTED |
| M5C.3 | COMPLETE / STANDALONE CONTRACT / NOT ACTIVE |
| M8A | ELIGIBLE FOR NEXT USER REQUEST / NOT STARTED |
| M6B | NO / BLOCKED |
| M7 | NOT STARTED |

**STOP：没有执行 M8A、M6B 或 CFD。**''')]
assert len(sections)==43
report='# M5C.3 时间推进、边界、初始化、重启与激活准备审计\n\n2026-10-01。范围：独立/被动模块；Foundation7；R1-P2-residualSpecies-v1；ONE alpha DOF；ndecane_gibbs_v1。\n\n'
for i,(title,body) in enumerate(sections,1):report+=f'# {i}. {title}\n\n{body}\n\n'
(b/'M5C3_TEMPORAL_BOUNDARY_RESTART_GATE.md').write_bytes(report.encode())
freeze=e/'freeze_v1';freeze.mkdir(exist_ok=True)
source=[]
for folder in [b/'fiveEqIntegration',b/'tests/fiveEqTemporalContract',b/'tests/fiveEqP2OldTime',b/'docs']:
 for p in folder.rglob('*'):
  if p.is_file() and 'linux64' not in str(p) and p.suffix in ('.H','.C','.md') or p.is_file() and p.name in ('files','options'):source.append(p)
source += [b/'LEGACY_TEMPORAL_ORDER_AUDIT.md',b/'FIVE_EQ_FIELD_OWNERSHIP_FINAL_v3.md',b/'M5C3_TEMPORAL_BOUNDARY_RESTART_GATE.md',b/'ENERGY_REFERENCE_AUDIT.md',b/'MILESTONE_STATUS.md']
for p in (b/'tools').glob('m5c3_*.py'):source.append(p)
hashes={}
for p in source:
 rel=p.relative_to(b);target=freeze/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());hashes[str(rel)]=hashlib.sha256(p.read_bytes()).hexdigest()
(freeze/'source_hashes.json').write_bytes(json.dumps(hashes,indent=2).encode())
(freeze/'version.json').write_bytes(json.dumps({'version':'M5C3-v1','status':'COMPLETE / STANDALONE CONTRACT / NOT ACTIVE','restart':'fiveEqRestart-v1/P2-v1','frozen_numerical_core':'M5C2D-v1 unchanged','M8A':'NOT STARTED','M6B':'NO'},indent=2).encode())
readme='''# Reproduction, no CFD

The runners are LF shell scripts executed under the installed Foundation7 environment. They write only to m5c3_v1. To preserve this accepted record, make a versioned copy before rerunning.

1. build_run.sh: new standalone temporal/BC/IO/source-identity target.
2. oldtime_build_run.sh: actual OF7 passive field oldTime fixture, no PDE solves.
3. run_frozen_regressions.sh: historical negative controls intentionally exit1 (14/26 failures); all accepted regression targets exit0.
4. run_D_regressions.sh and run_D_stress.sh: all11 accepted D test groups; no active solver/case run. Cost samples here are correctness replay, not isolated benchmark claims.
5. tools/m5c3_finalize.py validates33 gates/results/protection and updates the two allowed documents; tools/m5c3_report_checkpoint.py writes the Chinese43-section report and checkpoint.

protected_before.json was captured before new implementation; protection_check.json permits only energy/milestone document updates. Earlier snapshots/initial compile and ASCII-expectation failures are retained. Source audit copies are local Foundation7 originals. No active main/equation/timestep/parcel placement change.
'''
(e/'README.md').write_bytes(readme.encode())
archive=b/'checkpoints/M5C3_temporal_boundary_restart_v1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(e.rglob('*')):
  if p.is_file() and p.name!='checkpoint_sha256.txt':z.write(p,str(p.relative_to(b)))
 for p in source:z.write(p,str(p.relative_to(b)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
checksum=hashlib.sha256(archive.read_bytes()).hexdigest();(e/'checkpoint_sha256.txt').write_bytes((checksum+'  '+archive.name+'\n').encode())
print('report43 sections; checkpoint',archive.name,archive.stat().st_size,'bytes SHA256',checksum)
