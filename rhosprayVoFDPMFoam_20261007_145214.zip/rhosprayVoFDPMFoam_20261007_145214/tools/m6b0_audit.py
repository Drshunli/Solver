from pathlib import Path
import hashlib,json,re,struct,shutil,difflib
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/integration/m6b0_serial_active_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
checks={};results={};details={}
def check(k,v):checks[k]=bool(v)
check('fresh_clean_compile', (s/'compile_exit.txt').read_text().strip()=='0' and (s/'log.wclean').exists())
log=(s/'log.wmake').read_text();check('no_compile_errors',not re.search(r'error:|undefined reference',log));check('no_compile_warnings','warning:' not in log)
exe=sha(s/'runtime/rhosprayVoFDPMFoam');check('exact_executable_identity', all((s/f).read_text().split()[0]==exe for f in ['executable.sha256','executable_before_tests.sha256','executable_after_tests.sha256']))
for name in ['gas','liquid','mixed01','mixed05','mixed09','traceLiquid','traceGas','contact','speciesContact','smooth']:
 c=s/'cases_final'/name;r=read(c/'fiveEqEvidence/result.json');d=read(c/'fiveEqEvidence/primitive_diagnostics.json');results[name]=r;details[name]=d
 check(name+'_normal_serial_exit',(c/'exit_status.txt').read_text().strip()=='0' and 'nProcs : 1' in (c/'log.solver').read_text() and 'normal exit' in (c/'log.solver').read_text())
 check(name+'_steps',r['steps']>=10);check(name+'_registry',d['registryChecked'] and r['registeredFields']==20)
 check(name+'_recovery',r['acceptedRecoveryFailures']==0 and r['allRecoveryFailuresIncludingProbes']==0 and r['allRecoveryCalls']>r['acceptedRecoveryCalls'])
 check(name+'_conservation',r['maxConservationRelative']<1e-11);check(name+'_species_closure',r['maxSpeciesClosureRelative']<1e-12)
 check(name+'_pressure',r['maxPressureRelative']<1e-8)
 f=c/'fiveEqEvidence/final_fiveEqRestart';raw=f.read_text();body,tail=raw.rsplit('checksum ',1);h=14695981039346656037
 for v in body.encode():h=((h^v)*1099511628211)&((1<<64)-1)
 check(name+'_restart_contract',h==int(tail.strip(),16) and body.startswith('fiveEqRestart-v1 P2-v1 binary64-hex-msb ndecane_gibbs_v1 C10H22:O2:N2'))
 lines=body.splitlines();count=int(lines[1].split()[3]);cells=[line.split() for line in lines[2:2+count]]
 decode=lambda v:struct.unpack('>d',bytes.fromhex(v))[0]
 for cell in cells:
  coord=decode(cell[2]);q=list(map(decode,cell[3:]));check(name+'_legal_P2_'+cell[0],abs(coord)<=.5 and q[0]>=0 and q[1]>=0)
 if r['profile']=='uniform':
  bits=re.search(r'P2Bits "([0-9a-f]+)"',(c/'constant/fiveEqBootstrap').read_text())[1]
  check(name+'_P2_exact',all(cell[2]==bits for cell in cells))
  check(name+'_uniform',r['maxUniformRelative']<1e-11 and d['maxUniformPrimitiveDrift']==0 and r['maxTraceRelative']==0)
  if name=='gas':check('pure_gas_no_liquid_query',r['liquidQueries']==0 and all(decode(cell[4])==0 for cell in cells))
  if name=='liquid':check('pure_liquid_no_gas_query',r['gasQueries']==0 and all(decode(cell[3])==0 for cell in cells))
  if name.startswith('trace'):check(name+'_both_masses_positive',all(decode(cell[3])>0 and decode(cell[4])>0 for cell in cells))
 if name=='smooth':
  # No convergence-order/accuracy tolerance was specified by owner. Gate is actual
  # K=0 transport, bounded P2, no clipping, with analytical error reported openly.
  check('smooth_actual_transport',d['maxAlphaChange']>0 and r['steps']>=20)
  check('smooth_not_clipped',all(0<abs(decode(cell[2]))<.5 for cell in cells))
# Verify the complete prior frozen tree except precisely owner-authorized main entry.
protected=read(s/'protected_before.json');allowed={'rhosprayVoFDPMFoam/'+v for v in ['rhosprayVoFDPMFoam.C','MILESTONE_STATUS.md','Make/files','Make/options','Make/linux64GccDPInt32Opt/options','Make/linux64GccDPInt32Opt/rhosprayVoFDPMFoam.C.dep','Make/linux64GccDPInt32Opt/rhosprayVoFDPMFoam.o','Make/linux64GccDPInt32Opt/sourceFiles','Make/linux64GccDPInt32Opt/fiveEqIntegration/fiveEqRuntimeBridge.C.dep']}
deltas={};unexpected=[]
for rel,v in protected.items():
 p=root/rel;now=sha(p) if p.is_file() else None
 if v!=now:
  deltas[rel]={'before':v,'after':now}
  if rel not in allowed:unexpected.append(rel)
check('frozen_dependencies_unchanged',not unexpected)
(s/'frozen_delta_audit.json').write_text(json.dumps({'count':len(protected),'allowedChanges':sorted(allowed),'changes':deltas,'unexpectedChanges':unexpected},indent=2))
production=read(s/'production_before.json');changed=[rel for rel,v in production.items() if not (root/rel).is_file() or sha(root/rel)!=v];check('production_unchanged',not changed)
(s/'production_audit.json').write_text(json.dumps({'files':len(production),'changed':changed},indent=2))
for name in ['foundation_verification.txt','foundation_parcel_verification.txt']:
 lines=(s/name).read_text().splitlines();check(name+'_all_pass',bool(lines) and all(line.endswith(': OK') for line in lines))
main=(b/'rhosprayVoFDPMFoam.C').read_text();active=(b/'serialFiveEq/runSerialFiveEq.C').read_text()
check('early_exclusive_dispatch',main.index('return runSerialFiveEq(runTime, mesh);')<main.index('#include "createFields.H"'))
check('no_old_equation_in_active', all(x not in active for x in ['rhoEqn.H','rhoUEqn.H','rhoEEqn.H','rhoYEqn.H','alphaEqn.H','fvm::','fvc::','pEqn','pimple','piso']))
check('no_active_cloud_or_ST',all(x not in active for x in ['parcels.','cloud.','clouds','surfaceTensionForce','interfaceProperties','MULES','cAlpha','rhosprayLiquidThermo']))
check('reuse_frozen_driver','driver.advance(candidate,request)' in active and 'fiveEqTemporalDriver driver(op,rec)' in active)
check('Nminus1_residual', 'c.q[9]=c.q[1]-(c.q[7]+c.q[8])' in active and 'normalize(' not in active and 'clip(' not in active)
check('P2_initial_exact','parseHexDouble' in active and 'cfg.lookup("alphaL")' not in active)
check('field_publication_after_whole_recovery',active.index('recovered.push_back(op.recover(c))')<active.index('scalars[j].primitiveFieldRef()'))
check('fixed_periodic_geometry_guards','M6B0_UNIT_AREA_REQUIRED' in active and 'M6B0_RING_END_PAIR_REQUIRED' in active)
# Source manifest resolved from this fresh compilation's dependencies and Make.
files={b/'Make/files',b/'Make/options'}
for dep in (b/'Make').rglob('*.dep'):
 for line in dep.read_text().splitlines()[1:]:
  v=line.strip().removesuffix('\\').strip()
  if not v or '$' in v or v.startswith('/'):continue
  f=(b/v).resolve()
  if f.is_file() and f.is_relative_to(root):files.add(f)
for line in (b/'Make/files').read_text().splitlines():
 if line.strip().endswith('.C'):files.add(b/line.strip())
manifest={f.relative_to(root).as_posix():sha(f) for f in sorted(files)}
(s/'compiled_project_source_manifest.json').write_text(json.dumps(manifest,indent=2))
for rel in manifest:
 f=root/rel;dest=s/'compiled_sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
# Record original main/Make delta without modifying historical reference equations.
with (s/'active_source.patch').open('w',encoding='utf8',newline='\n') as out:
 for rel in ['rhosprayVoFDPMFoam.C','Make/files','Make/options']:
  before=(s/'active_before'/rel).read_text().splitlines(True);after=(b/rel).read_text().splitlines(True)
  out.writelines(difflib.unified_diff(before,after,fromfile='before/'+rel,tofile='after/'+rel))
summary={'status':'COMPLETE' if all(checks.values()) else 'PARTIAL','scope':'serial fixed uniform unit-area periodic one-dimensional active bootstrap; verification micro-cases only','executableSHA256':exe,'checks':checks,'failed':[k for k,v in checks.items() if not v],'results':results,'primitiveDiagnostics':details,'compiledProjectFiles':len(manifest),'allRecoveryCalls':sum(r['allRecoveryCalls'] for r in results.values()),'allRecoveryIterations':sum(r['allRecoveryIterations'] for r in results.values()),'allRecoveryFailures':sum(r['allRecoveryFailuresIncludingProbes'] for r in results.values()),'acceptedRecoveryCalls':sum(r['acceptedRecoveryCalls'] for r in results.values())}
(s/'M6B0_gate.json').write_text(json.dumps(summary,indent=2))
print(summary['status'],len(checks),'checks; failed',summary['failed'])
assert all(checks.values()),summary['failed']
