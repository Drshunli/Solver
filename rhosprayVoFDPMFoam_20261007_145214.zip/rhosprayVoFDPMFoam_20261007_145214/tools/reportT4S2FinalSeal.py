"""Generate the S2 authority matrix and 36-item report from verified evidence."""
from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parents[2];b=root/'rhosprayVoFDPMFoam';s=b/'fitting/dpm/m8a3b_t4_s2_final_seal_v1'
r=b/'fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1';w=b/'fitting/dpm/m8a3b_t4_s2_pw1_native_v1';z=b/'fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1';i=b/'fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1'
g=json.loads((s/'S2_FINAL_gate.json').read_text());assert g['status']=='COMPLETE / FROZEN' and not g['failed']
pro=g['sourceProvenance'];scope='passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures'
def link(p):return '['+p.name+']('+p.as_posix()+')'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
definitions=[
('Native migration semantics','R1 FINAL / ZS1 / C2',[s/'boundary_reaudit.json',r/'pilot_corrected/processor0/R1_boundary.csv',r/'pilot_corrected/processor1/R1_boundary.csv'],['R1_NATIVE','ZS1','C2'],'same native sender/receiver fields/history; identity/nParticle; geometry; RNG'),
('Valid forward crossing','R1 FINAL',[r/'independent_runs/run_00/processor0/R1_boundary.csv',r/'boundary.run_00.json'],['R1_NATIVE'],'real native 0→1; no manual send'),
('Valid reverse crossing','ZS1',[z/'exit.mpi_zero.txt',z/'mpi_zero/processor0/native_crossing_result.json',z/'mpi_zero/processor1/native_crossing_result.json',s/'boundary_reaudit.json',s/'compatibility_audit.json'],['ZS1'],'INHERIT PASS: real native 1→0; current shared source identical; not N1 invalid rejection'),
('≥1000 successful crossings','R1 FINAL',[r/'R1_FINAL_gate.json',s/'S2_FINAL_gate.json',r/'stress.sh'],['R1_NATIVE'],'20 independent runs ×50 forward crossings; all exit0; no timeout; historical failures excluded'),
('Ownership / no loss','R1 FINAL / ID1 / N1',[s/'S2_FINAL_gate.json',i/'identity_acceptance_audit.json',r/'n1_forward/processor1/native_crossing_result.json'],['R1_NATIVE','ID1','N1'],'per-run full identity exactly one cloud owner; birth set equals final main-run owner set'),
('Identity / allocator','ID1 / K1 / R1',[b/'dpmFiveEq/KHNewbornIdentityV1.H',i/'identity_acceptance_audit.json',r/'regressions/k1/identity_result.json'],['ID1','K1','R1_NATIVE'],'migration pair preserved; physical newborn birth rank + native getNewParticleID; no receive renumber'),
('S1 destination rebuild','R1 FINAL / S1',[r/'pilot_corrected/processor1/R1_queries.csv',r/'pilot_corrected/processor1/R1_continuation.csv'],['R1_NATIVE','S1'],'new destination support session; no source support token transferred'),
('Mixed / trace / absent / stale','R1 FINAL fresh S1',[r/'reg_fixture_s1/processor0/support_result.json',r/'reg_fixture_s1/processor1/support_result.json'],['S1'],'mixed .1/.5/.9; trace 1e-20; absent; generation and pose invalidation'),
('Invalid destination forward/reverse','R1 FINAL fresh N1',[r/'n1_forward/processor1/C1_latch.json',r/'n1_reverse/processor0/C1_latch.json'],['N1'],'EXACT_GAS_ABSENT; zero dependent thermo calls at refused destination; no fake gas'),
('Communication-safe reject','C1-N1 / R1 FINAL',[r/'n1_forward/processor1/C1_phases.csv',r/'n1_reverse/processor0/C1_phases.csv',s/'S2_FINAL_gate.json'],['N1'],'native move returns; post-evolve reduce; local discard; normal exit; no global commit assertion'),
('Migration RNG semantics','R1 FINAL / ZS1',[s/'boundary_reaudit.json',r/'pilot_corrected/processor1/R1_boundary.csv'],['R1_NATIVE','ZS1'],'prepare/correct no draw; rank RNG not synchronized'),
('RNG next-result','R1 FINAL',[r/'pilot_corrected/processor1/R1_rng_next.jsonl',r/'R1_FINAL_gate.json'],['R1_NATIVE'],'50/50 exact full RNG/cache/UTurb/tTurb/update-return paired continuation; local serial no-migration reference'),
('Fresh stochasticDispersionRAS','R1 FINAL',[r/'pilot_corrected/processor0/R1_fresh_models.csv',r/'pilot_corrected/processor1/R1_continuation.csv',r/'pilot_corrected/processor1/R1_rng_next.jsonl'],['R1_NATIVE'],'6503 recorded calls; 462 RNG-consuming-update counter; nonzero UTurb; finite; no convergence claim'),
('Fresh sphereDrag','R1 FINAL',[r/'pilot_corrected/processor0/R1_fresh_drag.csv',r/'pilot_corrected/processor1/R1_fresh_drag.csv'],['R1_NATIVE'],'actual local non-roundoff momentum/source; 32 segment witnesses; not global source ledger'),
('Native weighted parcel','PW1 / R1 FINAL',[w/'PW1_gate.json',r/'pilot_corrected/processor0/PW1_births.csv'],['PW1','R1_NATIVE'],'mass basis; Ncomp 1/10/100/1000 ladder; represented mass; finite positive nParticle'),
('No double weighting','PW1 / R1 FINAL',[r/'R1_FINAL_gate.json',r/'pilot_corrected/processor0/R1_fresh_drag.csv',r/'pilot_corrected/processor1/PW1_void.csv'],['PW1','R1_NATIVE'],'native birth and physical nParticle updates retained; no extra coupling multiplier or merge'),
('VoidFraction repeated','R1 FINAL',[r/'pilot_corrected/processor0/PW1_void.csv',r/'pilot_corrected/processor1/PW1_void.csv',r/'R1_FINAL_gate.json'],['R1_NATIVE'],'7380 native trajectory segments; rank/cell/step theta bit oracle; local segmentation only'),
('blobsSheetAtomization','R1 FINAL',[r/'pilot_corrected/processor1/R1_continuation.csv',r/'pilot_corrected/processor1/R1_boundary.csv',b/'tests/fiveEqDPMParcelC2/modelAdapters.H'],['R1_NATIVE'],'50 native atomization calls; core>0.5 branch; all weighted migrated cores reach0; finite; no statistics certification'),
('ReitzKHRT bounded domain','R1 FINAL / ZS1',[z/'ZS1_gate.json',z/'source_delta.json',r/'pilot_corrected/processor1/R1_continuation.csv'],['R1_NATIVE','ZS1'],'unchanged Foundation; frozen exact-zero policy; CRT=.1 bounded native path; FPE1/FPE2 diagnosis remains'),
('KH physical newborn','ID1 / fresh K1 / ZS1',[i/'identity_acceptance_audit.json',r/'regressions/k1/identity_result.json',z/'trajectory_birth_parity.json'],['ID1','K1','ZS1'],'real birth; local allocator; independent child preflight; rollback; fresh92 child identity checks; spatial-invalid-at-birth not claimed'),
('Native coneInjection','PW1 / R1 FINAL',[r/'pilot.sh',r/'pilot_corrected/processor0/PW1_steps.csv',r/'pilot_corrected/processor0/PW1_births.csv'],['PW1','R1_NATIVE'],'native injected weighted births; no manual seed; requested=added; global population≤50'),
('ORourke bounded state','R1 FINAL / frozen T3',[r/'pilot_corrected/processor1/R1_fresh_models.csv',b/'SERIAL_DPM_KNOWN_LIMITATIONS_v1.md'],['R1_NATIVE'],'migration/state compatibility PASS; NATIVE-PHYSICS-LIMITATION; NOT FULL-CONSERVATION-SAFE'),
('Native rebound','R1 FINAL fresh wall evidence',[r/'pilot_corrected/processor1/R1_fresh_models.csv',b/'tests/fiveEqDPMParcelC2/modelAdapters.H'],['R1_NATIVE'],'INHERITED from R1: 2357 native Rebound::correct delegates; real wall fixture; no artificial U flip'),
('Lifetime','R1 FINAL / ID1 / N1',[r/'pilot_corrected/processor0/native_crossing_result.json',r/'rollback_bounded/processor1/native_crossing_result.json',r/'n1_reverse/processor0/native_crossing_result.json',i/'identity_acceptance_audit.json'],['R1_NATIVE','R1_ROLLBACK','N1','ID1'],'constructed=destroyed+baseline; no leak/orphan; committed baseline10 retained in rollback'),
('Registry','R1 FINAL / N1',[r/'pilot_corrected/processor1/R1_final_stability.csv',r/'rollback_bounded/processor1/N1_discard.csv',r/'n1_forward/processor1/N1_discard.csv'],['R1_NATIVE','R1_ROLLBACK','N1'],'stable registry; discard delta0; bindings cleared; owner/latch scope teardown'),
('Rollback','R1 FINAL / ID1',[r/'rollback_bounded/processor1/PW1_accepted_before.txt',r/'rollback_bounded/processor1/PW1_accepted_after_discard.txt',r/'rollback_bounded/processor1/N1_discard.csv',i/'identity_acceptance_audit.json'],['R1_ROLLBACK','ID1'],'nonempty weighted accepted codec/RNG/allocator/identity/source/view/pending restoration; rank-local only'),
('Serial regressions','R1 FINAL',[r/'regressions/r2b/test_results.json',r/'regressions/i1/gate_result.json',r/'regressions/c2/basic_result.json',r/'regressions/k1/event_result.json'],['R2B','I1','C2','K1'],'fresh-in-R1 252194/12083/17/108 checks; failures0; current source compatible; no rerun'),
('S1 regressions','R1 FINAL',[r/'reg_fixture_s1/processor0/support_result.json',r/'reg_fixture_s1/processor1/support_result.json',r/'reg_fixture_topology/processor0/topology_result.json',r/'reg_fixture_topology/processor1/topology_result.json'],['S1','TOPOLOGY'],'20051 support +3364 topology; zero errors; real remote contributors and exact native weights'),
('N1 regressions','R1 FINAL',[r/'n1_valid/processor0/native_crossing_result.json',r/'n1_forward/processor1/native_crossing_result.json',r/'n1_reverse/processor0/native_crossing_result.json'],['N1'],'valid and forward/reverse invalid; globalFailures0; not a valid-reverse substitute'),
('Foundation unchanged','Final seal / frozen Foundation baseline',[s/'installed_source_verification.txt',s/'native_parcel_verification.txt',s/'foundation_native_source_manifest.json'],['FOUNDATION'],'fresh read-only 6717/19 SHA PASS; native ownership files inspected; no physics replay'),
('No custom MPI infrastructure','Architecture source audit',[s/'foundation_native_source_read.txt',b/'tests/fiveEqDPMR1QualifiedNative/parcel/LazySprayParcel.H',b/'dpmFiveEq/KHNewbornIdentityV1.H',s/'authority_provenance.json'],['R1_NATIVE','FOUNDATION'],'certified path uses Cloud::move/native streams-iNew; no custom MPI transport/packer/global ID/RNG/merge/superparcel'),
('Active solver unchanged','Source protection audit',[s/'active_source_audit.json',s/'common_source_chain.json'],['SOURCE_AUDIT'],'main and 5 equation files equal historical bytes; no active runtime edit or integration'),
('Production unchanged','Frozen records / seal activity scope',[s/'S2_FINAL_gate.json',s/'frozen_before.json'],['SOURCE_AUDIT'],'no production mesh/BC/injection writes, execution, or new production inputs'),
('No global transaction claim','R1 FINAL / ID1 scope',[r/'pilot_corrected/processor1/native_crossing_result.json',i/'identity_acceptance_audit.json',s/'S2_FINAL_gate.json'],['R1_NATIVE','ID1'],'globalMPITransactionCertified=false; S3 global commit/reject/ledger/output explicitly excluded'),
('No restart claim','Final seal scope',[s/'S2_FINAL_gate.json'],['SOURCE_AUDIT'],'production restart NOT CERTIFIED'),
('No CFD','Final seal scope / inherited noCFD receipts',[s/'S2_FINAL_gate.json',r/'regressions/k1/event_result.json'],['SOURCE_AUDIT'],'new physics runs0; new compilations0; no CFD; no S3/M6B')]
assert len(definitions)==36
matrix=[]
for n,(requirement,milestone,evidence,labels,limit) in enumerate(definitions,1):
 assert all(p.is_file() for p in evidence),[(str(p),p.exists()) for p in evidence]
 hashes={}
 for label in labels:
  if label in pro:hashes[label]=pro[label]
  else:
   file=s/('foundation_native_source_manifest.json' if label=='FOUNDATION' else 'active_source_audit.json')
   hashes[label]={'sourceManifest':str(file),'sourceManifestSHA256':sha(file),'executable':'NONE: read-only seal audit'}
 fresh='FRESH READ-ONLY AUDIT' if n>=30 else 'INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated'
 matrix.append({'gate':n,'requirement':requirement,'authoritativeMilestone':milestone,'evidence':[{'path':str(p),'sha256':sha(p)} for p in evidence],'executableAndSourceSHA':hashes,'freshOrInherited':fresh,'scope':scope+'; '+limit,'verdict':'PASS'})
(s/'T4_S2_FINAL_AUTHORITY_MATRIX_v1.json').write_text(json.dumps(matrix,indent=2))
intro='# T4-S2 FINAL AUTHORITY MATRIX v1\n\n**36 mandatory gates PASS. T4-S2 COMPLETE / FROZEN within passive, fixed-mesh, two-rank native scope.**\n\n所有模型证据均为继承；本轮只重新读取与校验哈希/边界记录。SHA-set 标签逐一对应文末的完整 executable/source SHA 与源文件清单；机器可读矩阵还列出每一个证据文件的独立 SHA。\n\n'
text=intro+'| Gate | Requirement | Authority | Exact evidence | Executable/source SHA-set | Fresh/inherited | Scope / result |\n|---|---|---|---|---|---|---|\n'
for row in matrix:
 text+=f'| {row["gate"]} | {row["requirement"]} | {row["authoritativeMilestone"]} | '+ '<br>'.join(link(Path(v['path'])) for v in row['evidence'])+' | '+', '.join(row['executableAndSourceSHA'])+' | '+row['freshOrInherited']+' | PASS — '+row['scope']+' |\n'
text+='\n## Exact executable/source SHA sets\n'
for label,v in pro.items():
 text+=f'\n### {label}\n\nExecutable: {link(Path(v["executable"]))}\n\nSHA-256: `{v["executableSHA256"]}`\n\nProject source manifest: {link(Path(v["projectSourceManifest"]))}\n\nSHA-256: `{v["projectSourceManifestSHA256"]}` ({v["projectFiles"]} resolved files)\n\n'
for label,name in [('FOUNDATION','foundation_native_source_manifest.json'),('SOURCE_AUDIT','active_source_audit.json')]:
 p=s/name;text+=f'\n### {label}\n\n{link(p)} — SHA-256 `{sha(p)}`. Executable: NONE; read-only audit.\n'
text+='\n## Provenance boundary\n\n'+link(s/'common_source_chain.json')+' pins the 34 shared dependencies omitted from the prior R1 list through frozen T3 dependency metadata → C2 complete archive → R2B archive → historical R2 protected-source snapshot. The historical PARTIAL archive supplies source bytes/hashes only; none of its failed cases or status supplies a PASS gate. ID1 differs only by the already frozen ZS1 call-site policy, bridged by exact accepted-birth payload parity.\n\ntransactionState-v1 remains an existing **local transaction/checkpoint codec**, explicitly owned by the project; it is not an MPI parcel serializer. This matrix certifies absence of custom MPI transport/serialization in the selected S2 path, not absence of all local checkpoint codecs or historical test artifacts.\n\n'
text+=link(s/'T4_S2_FINAL_AUTHORITY_MATRIX_v1.json')+' contains full paths and SHA values for every row. No global commit, distributed source ledger, output exactly-once, production restart, or CFD certificate. STOP.\n'
(b/'T4_S2_FINAL_AUTHORITY_MATRIX_v1.md').write_text(text,encoding='utf-8',newline='\n')
nativeOwners='Cloud::move; native tracking; processor crossing; prepare/correct transfer; PstreamBuffers; UOPstream/UIPstream; ParticleType::iNew protocol; Random; ConeInjection; InjectionModel mass weighting; sphereDrag; stochasticDispersionRAS; blobsSheetAtomization; ReitzKHRT; ORourke; rebound; VoidFraction'
projectOwners='P2/R1/recovery; lazy support-first; S1 distributed support; MPIFailureLatch; transactionState-v1 local codec; I1 ownership wrapper; KH newborn identity adapter; frozen ZS1 exact-zero call-site compatibility; local source/output staging'
parts=[
('S2 final status','**T4-S2 = COMPLETE / FROZEN**，限定于 passive/offline、固定网格、Foundation7 DP/Int32、两 rank native parcel 证据。36 个 mandatory gates 均有兼容且 hash-consistent authority。'),
('Complete authority matrix',link(b/'T4_S2_FINAL_AUTHORITY_MATRIX_v1.md')+'；36 行完整 requirements、milestones、路径、SHA-set、fresh/inherited、scope、PASS。机器可读版本提供每个证据文件 SHA。'),
('Native OF7 architecture',nativeOwners+'。本机 22 个 native 所有权相关文件已实际读取；6717 源码及 19 native parcel 指纹再次核验。已有 lazy parcel 使用 OF7-compatible 原生 stream/iNew 协议；没有另写 MPI packet/queue。'),
('Project-local exceptions',projectOwners+'。所有运行实现本轮零修改。现有本地 transactionState-v1 codec 不冒称为不存在；它不用于 MPI parcel 传输。'),
('Migration semantics','R1 pilot、20 个 stress runs 和 ZS1 reverse 原始边界 CSV 重新只读校验：sender/receiver snapshots、identity、nParticle、物理/历史 fields、native geometry correction、prepare/correct RNG 全 PASS。C2 只作 oracle。'),
('Valid directions','Forward: R1 1000 个 successful 0→1 crossings。Reverse: ZS1 mpi_zero 正常 exit0、一次真实 Cloud::move 1→0，原始 full-state/geometry/RNG oracle PASS；shared source SHA=c264b0b22cb95d96dc6349fdb40f2993e04a146958cc9f881f15ef54aaf007b5，与当前 R1 相同，INHERIT PASS。未以 invalid rejection 替代 valid reverse；本轮不需补 replay。'),
('1000-crossing stress','继承 20 个独立有界 MPI 运行，每个50次、共1000次；全部 exit0，1.38–3.99s，未触发55s watchdog。不计入历史失败、I1 循环或 ID1 步数；本轮没有重跑。'),
('Ownership','weighted 主运行出生 identity 集合与最终 owners 集合相等，50/50、每个完整 pair 恰有一个 cloud owner、无丢失/重复；KH newborn 继承 ID1/K1，invalid destination 继承 N1 的受控 reject/discard。'),
('Identity','Existing parcel 迁移保存 origProc/origId。真实 KH birth 的 origProc=Pstream::myProcNo，origId=child.getNewParticleID。没有 global ID allocator 或 receive-time renumber。'),
('Support','继承 S1/R1：先 preflight 支撑、后 thermo；目的 rank 新建 session，实际 remote contributors；没有迁移源 support token。固定拓扑支撑范围之外不扩张。'),
('Invalid support','N1 forward/reverse 的目的 rank 均 EXACT_GAS_ABSENT，零 dependent rho/T/Y/Cp/mu/kappa/recovery；native communication 返回后 reduce、discard、正常退出。未制造 fake gas。'),
('RNG','继承 R1 完整 x_、scalarNormalStored_、scalarNormalValue_ bits 和50/50 paired next-result 精确比较。参考是同一目的 owner 上同一 parcel 的串行无迁移下一更新，不是两条独立完整 cloud 轨迹或 rank RNG 同步。47次抽样、3次按 native 涡寿命规则保留 UTurb 均精确一致。'),
('stochasticDispersionRAS','R1 fresh evidence：6503 calls、462 RNG-consuming-update counter、真实非零 UTurb、有限状态、weighted parcel 正常。462是发生器序列改变的更新数，不是底层随机抽样总数。'),
('sphereDrag','R1 fresh native calls=12906；32个实际非零速度/源项轨迹段。source=nParticle×singleMass×(Ubefore−Uafter) 最大相对残差2.1493859013912846e-13；没有额外 multiplicity 因子。只认证 local model source，不认证 global ledger。'),
('Weighting','PW1 native mass basis，1/10/100/1000计算 parcel 梯级代表质量保持、nParticle 有限正值、迁移 multiplicity bit parity、非空 rollback parity。保持原生/已有物理 parcel 更新，未新增 merge、superparcel 或自定义 weighting。'),
('VoidFraction','继承7380个 native postMove轨迹段及每rank/每步/cell theta bit oracle；dt×nParticle×singleDropletVolume，仅一次计权，再按 dt/Vcell 归一化。本项是 S2 segmentation，不是 S3 global publication。'),
('Breakup / KH','Foundation ReitzKHRT 未改；FPE1 保留 historical CLASS D，FPE2 保留 CLASS E diagnosis。ZS1 只在 Urmag==0 且 real KHindex<.5 时改临时调用 index，保留真实 history。当前 CRT=.1 有界路径及 native child path正常，不能推断 OF7 KH 永不失败或统计收敛。blobsSheet50次原生调用和 migrated liquidCore=0 提供自然 core transition 证据。'),
('Injection','PW1/R1 的 native ConeInjection/InjectionModel weighted birth；注入 gate无manual seed。50 parcels/s、每个注入步 requested=added=10、总50、global population≤50；原物理 mass/SOI/duration/分布/组成/速度/几何/系数不变。这不是生产预算认证。'),
('ORourke limitation','**Migration/state compatibility PASS; NATIVE-PHYSICS-LIMITATION; NOT FULL-CONSERVATION-SAFE.** weighted native ORourke实际运行；不认证 distributed collision conservation 或 collision statistics。'),
('Rebound','**INHERITED**：R1 fresh wall counter2357次，WallAdapter 只读计数并调用 native Rebound::correct，fixture为真实wall路径；不是人工U flip。'),
('Lifetime','valid/weighted迁移、KH newborn、invalid destination、rollback证据均满足constructed=destroyed+live baseline。主运行各rank50/50/live0；非空回滚目的rank40/30/live10=accepted baseline，未把合法accepted parcel当泄漏。'),
('Registry','重复有界运行 registry稳定，discard delta0；已有代码检查 carrier binding empty、S1 owner/session/latch作用域正常结束，无累积。'),
('Rollback','R1非空accepted weighted stream before/after一致，完整codec/allocator/RNG/cache/nParticle/identity/source/view/pending output恢复。ID1正常 rejected birth→discard→retry accepted payload相等。本项是existing rank-local rollback，未认证global atomicity。'),
('Source boundary','认证 local native/model source、nParticle scaling 和rollback；**不认证** distributed global dmG/dmYi/dM/dEt ledger。'),
('Output boundary','认证 pending output rollback、identity consistency；**不认证** MPI global exactly-once publication。'),
('Serial regression','继承R1 fresh：R2B252194/0，I112083/0，C217/0，K1108/0。exe/source provenance核对通过，未重复运行。K1新增92个真实child identity负向检查和5694次laterchild queries；不是实际空间无效出生证据。'),
('S1 regression','继承R1 fresh：support20051/0、topology3364/0；mixed/trace/absent/generation/pose/remote/native weights覆盖。'),
('N1 regression','继承R1 fresh valid、forward invalid、reverse invalid，全部globalFailures0。invalid reverse独立列明，不加入valid reverse或1000 successful统计。'),
('Foundation hashes','本轮fresh只读：6717 Foundation、19 native parcel SHA全部PASS；Cloud/particle transfer、Random、InjectionModel/Cone、streams/iNew、ReitzKHRT原字节保持。'),
('Project hashes','30535 frozen entries本轮初始核验全部不变。34个共同编译依赖经冻结T3依赖SHA链定位历史snapshot，与当前全相等；active主.C及五个方程.H历史字节也相等。ID1→ZS1是已批准冻结差异，accepted birth payload parity桥接；本轮无新runtime delta。历史PARTIAL archive只提供源字节来源，不提供任何PASS或成功穿越计数。'),
('Active solver impact','**NONE**。没有active solver、方程、EOS、KT、source或runtime coupling修改/激活。'),
('Production impact','**NONE**。没有production mesh/BC/injection/restart修改或执行；production restart NOT CERTIFIED；CFD NO。'),
('Unresolved limitations','全局MPI commit/failure atomicity、global source/output exactly-once、完整distributed model graph、1/2/4rank比较属于S3。ORourke守恒/统计限制保留；KH非测试域可能失效；实际空间无效child-at-birth、自然多代、动态网格/AMR、跨ABI/restart不在本S2证书中。mandatory S2 gates OPEN=0，不把范围外限制伪装为已闭合。'),
('Whether S2 COMPLETE','**YES — COMPLETE / FROZEN**，以本轮authority matrix和不可覆盖最终seal为准。Inherited证据已校验，不要求为“fresh”重新跑物理。'),
('Whether S3 may be considered','**NEXT ROUND ONLY**，仅可讨论；当前NOT AUTHORIZED / NOT EXECUTED，不自动执行。'),
('Milestone matrix','| Milestone | Status |\n|---|---|\n| R2-FINAL / T3 | COMPLETE / FROZEN |\n| T4-S1 / C1-N1 | COMPLETE / FROZEN |\n| FPE1 / FPE2 / TIMEOUT-D1 | COMPLETE / DIAGNOSIS ONLY / FROZEN |\n| ZS1 / ID1 / PW1 / R1 FINAL | COMPLETE / FROZEN within recorded scope |\n| **T4-S2** | **COMPLETE / FROZEN** |\n| T4 / M8A | PARTIAL / PARTIAL |\n| T4-S3 | NOT AUTHORIZED / NOT EXECUTED |\n| M6B / CFD | NO / NO |\n| Production restart | NOT CERTIFIED |\n\nSTOP。')]
assert len(parts)==36
report='# T4-S2 FINAL SEAL REPORT v1\n\n本轮：M8A.3B-T4-S2-FINAL-SEAL。0 new physics runs，0 new compilations；只读证据汇总、源码和checkpoint哈希核验、文档与封存。\n\n'
report+='\n\n'.join(f'## {n}. {title}\n\n{body}' for n,(title,body) in enumerate(parts,1))+'\n'
(b/'T4_S2_FINAL_SEAL_REPORT_v1.md').write_text(report,encoding='utf-8',newline='\n')
with (b/'MILESTONE_STATUS.md').open('a',encoding='utf-8',newline='\n') as f:
 f.write('\n\n## M8A.3B-T4-S2-FINAL-SEAL — COMPLETE / FROZEN\n\n')
 f.write('All36mandatoryS2gates PASS within passive/offline Foundation7DPInt32 fixedmesh two-rank native parcel scope. Read-only aggregation: no newphysics/compilation/runtime/MPI/model. FrozenR1 evidence20×50=1000forward native crossings,allnormal/no timeout/oneowner/no loss; validreverse INHERITPASS fromZS1 actual1→0 withsamefinalsharedSHA,notinvalidN1. NativeRNG/cache50/50nextpairedresult,stochastic/drag/weighting/theta/core/KH/children/ORourke/rebound/lifetime/registry/rollback andfresh-in-R1regressions tracedtoexactpaths/source+exeSHA. Foundation6717/nativeparcel19currentSHA PASS;30535priorfrozenentries unchangedbeforeauthorized historyappend.34commoncompileddependencies tracedvia frozenT3 archiveSHAchain;historicalPARTIAL snapshotusedonlyasbyteauthority,notgatePASS. ExistinglocaltransactionState-v1codec retained,notMPIparcelserializer;no customtransport/ID/RNG/merge/superparcel. ID1/ZS1 areonlyalreadyfrozenruntimecompatibilitydeltas,nosealdelta. MandatoryOPEN0; ORourkeNATIVE-PHYSICS-LIMITATION/NOTFULL-CONSERVATION-SAFE andspatialinvalidchild/globaltransaction/restartlimitationsremainoutsidecertificate. T4-S2COMPLETE/FROZEN;T4/M8APARTIAL;S3NOTAUTHORIZED/NOTEXECUTED/NEXTROUNDONLYdiscussion;M6BNO/CFDNO/productionrestartNOTCERTIFIED;active/productionNONE. See T4_S2_FINAL_AUTHORITY_MATRIX_v1.md and T4_S2_FINAL_SEAL_REPORT_v1.md. STOP.\n')
print('36 PASS authority rows; 36-section report; append-only S2 completion entry')
