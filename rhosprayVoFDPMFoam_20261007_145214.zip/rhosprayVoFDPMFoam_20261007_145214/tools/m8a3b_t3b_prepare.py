from pathlib import Path
import hashlib,json,shutil
b=Path(__file__).resolve().parents[1];e=b/'fitting/dpm/m8a3b_t3b_v1'
if e.exists():raise RuntimeError('Never overwrite prior evidence')
e.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
protected={str(p.relative_to(b)):sha(p) for p in b.rglob('*') if '/Make/' not in p.as_posix() and '/lnInclude/' not in p.as_posix() and '/m8a3b_t3b_v1/' not in p.as_posix() and not p.is_symlink() and p.is_file()}
(e/'protected_before.json').write_text(json.dumps(protected,indent=2),encoding='utf8')
case=b.parent/'300_2D';(e/'case_before.json').write_text(json.dumps({str(p.relative_to(case)):sha(p) for p in case.rglob('*') if p.is_file()},indent=2),encoding='utf8')
t=b/'tests/fiveEqDPMEventLedger';(t/'Make').mkdir(parents=True)
(t/'Make/files').write_bytes((b/'tests/fiveEqDPMCarrierPublication/Make/files').read_bytes().replace(b'testFiveEqDPMCarrierPublication',b'testFiveEqDPMEventLedger'))
(t/'Make/options').write_bytes((b/'tests/fiveEqDPMCarrierPublication/Make/options').read_bytes().replace(b'-I../fiveEqDPMRebinding',b'-I../fiveEqDPMCarrierPublication -I../fiveEqDPMRebinding'))
for s in 'ABC':
 shutil.copytree(b/'fitting/dpm/m8a3b_t3a_v1/fixtures'/s,e/'fixtures'/s)
 shutil.copytree(b/'fitting/dpm/m8a3b_t3a_v1/rebinding_fixtures'/s,e/'rebinding_fixtures'/s)
head='#!/bin/bash\nsource /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1\nset -e\nbase=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam\n'
(e/'build.sh').write_bytes((head+'cd "$base/tests/fiveEqDPMEventLedger"\nwmake > "$base/fitting/dpm/m8a3b_t3b_v1/log.wmake" 2>&1\n').encode())
for name in ('run_energy_regressions.sh','run_frozen_regressions.sh','run_temporal.sh','run_rebinding.sh','run_support.sh','run_carrier_verified.sh'):
 (e/name).write_bytes((b/'fitting/dpm/m8a3b_t3a_v1'/name).read_bytes().replace(b'm8a3b_t3a_v1',b'm8a3b_t3b_v1'))
(e/'read_sources.sh').write_bytes((head+'''src=$FOAM_SRC
out="$base/fitting/dpm/m8a3b_t3b_v1/native_sources"
mkdir -p "$out"
for name in Random.H RandomI.H Random.C ORourkeCollision.H ORourkeCollision.C StochasticCollisionModel.H StochasticCollisionModel.C KinematicCloud.C ReactingParcel.C ReactingParcelI.H KinematicParcelI.H VoidFraction.C SprayParcel.C InjectionModel.C; do
 find "$src" -name "$name" -not -path '*/lnInclude/*' | while read -r file; do
  relative="${file#$src/}"; mkdir -p "$out/$(dirname "$relative")"; cp "$file" "$out/$relative"
 done
done
''').encode())
(e/'run_ledger.sh').write_bytes((head+'''for state in A B C; do
 mkdir -p "$base/fitting/dpm/m8a3b_t3b_v1/ledger/$state"
 cd "$base/fitting/dpm/m8a3b_t3b_v1/ledger/$state"
 /usr/bin/time -v "$base/tests/fiveEqDPMEventLedger/testFiveEqDPMEventLedger" "$base/fitting/dpm/m8a3b_t3b_v1/fixtures/$state" "$state" /mnt/d/DATA/Solver/300_2D/constant/thermal.dat > log.run 2> log.resource
done
''').encode())
print(e)
