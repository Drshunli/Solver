from pathlib import Path
b=Path(__file__).resolve().parents[1];t=b/'tests/fiveEqP2OldTime';(t/'Make').mkdir(exist_ok=True)
(t/'Make/files').write_bytes(b'testFiveEqP2OldTime.C\nEXE = $(PWD)/testFiveEqP2OldTime\n')
s=(b/'tests/fiveEqHighOrderPrecisionFinal/Make/options').read_text().replace('-I$(LIB_SRC)/finiteVolume/lnInclude','-I$(LIB_SRC)/finiteVolume/lnInclude -I$(LIB_SRC)/meshTools/lnInclude')
(t/'Make/options').write_bytes(s.encode())
e=b/'fitting/integration/m5c3_v1';(e/'oldtime').mkdir(exist_ok=True)
script='''#!/bin/bash
source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqP2OldTime
wmake > /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/log.oldtime.wmake 2>&1
code=$?
echo "$code" > /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/oldtime_compile_exit.txt
if [ "$code" != 0 ]; then tail -30 /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/log.oldtime.wmake; exit "$code"; fi
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m5c3_v1/oldtime
/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqP2OldTime/testFiveEqP2OldTime /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqOF7Interpolation/fixture > log.run 2>&1
code=$?
echo "$code" > exit_status.txt
cat log.run
exit "$code"
'''
(e/'oldtime_build_run.sh').write_bytes(script.encode())
