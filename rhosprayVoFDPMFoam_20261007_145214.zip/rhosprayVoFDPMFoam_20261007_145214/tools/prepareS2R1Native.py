"""Create isolated read-only native migration observers; never edit frozen N1."""
import pathlib, shutil, json, hashlib
root=pathlib.Path(__file__).resolve().parents[1]
old=root/'tests/fiveEqDPMNativeMPIN1'
new=root/'tests/fiveEqDPMMigrationR1Native'
ev=root/'fitting/dpm/m8a3b_t4_s2_r1_native_v1'
assert not new.exists() and not ev.exists()
new.mkdir(); (new/'parcel').mkdir(); (new/'Make').mkdir(); ev.mkdir()
frozen=json.loads((root/'fitting/dpm/m8a3b_t4_s2_c1_n1_v1/frozen_after.json').read_text())
for p,h in json.loads((root/'fitting/dpm/m8a3b_t4_s2_c1_n1_v1/selected_source_hashes.json').read_text()).items():
 frozen[str(pathlib.Path('rhosprayVoFDPMFoam')/p)]=h
assert all(hashlib.sha256((root.parent/p).read_bytes()).hexdigest()==h for p,h in frozen.items())
(ev/'frozen_before.json').write_text(json.dumps(frozen,indent=2))
for f in ['localTypes.H','localRegistration.C','localTypeSymbols.C']:
 shutil.copyfile(old/f,new/f)
opts=(old/'Make/options').read_text().replace('-I../fiveEqDPMDistributedSupportS1','-I../fiveEqDPMNativeMPIN1 -I../fiveEqDPMDistributedSupportS1')
(new/'Make/options').write_text(opts,newline='\n')
files=(old/'Make/files').read_text().replace('testFailureDisposition','testNativeMigration')
(new/'Make/files').write_text(files,newline='\n')
header=(old/'parcel/LazySprayParcel.H').read_text()
header=header.replace('#include "MPIFailureLatch.H"','#include "MPIFailureLatch.H"\n#include "MigrationObserver.H"')
anchor='        // Main calculation loop'
hooks='''        // Test-only read-only delegates. Native methods remain the implementation.
        void prepareForParallelTransfer()
        {
            migrationR1::observe("SEND_BEFORE_PREPARE", *this);
            ParcelType::prepareForParallelTransfer();
            migrationR1::observe("SEND_AFTER_PREPARE", *this);
        }
        void correctAfterParallelTransfer(const label patchi, trackingData& td)
        {
            migrationR1::observe("RECEIVE_BEFORE_CORRECT", *this);
            ParcelType::correctAfterParallelTransfer(patchi, td);
            migrationR1::observe("RECEIVE_AFTER_CORRECT", *this);
        }

'''
assert header.count(anchor)==1
(new/'parcel/LazySprayParcel.H').write_text(header.replace(anchor,hooks+anchor),newline='\n')
(new/'MigrationObserver.H').write_text('''#pragma once
#include "particle.H"
#include <functional>
namespace Foam {namespace fiveEqDPM {namespace migrationR1 {
inline std::function<void(const char*, const particle&)>& observer(){
 static std::function<void(const char*, const particle&)> callback;return callback;
}
inline void observe(const char*stage,const particle&p){if(observer())observer()(stage,p);}
}}}
''',newline='\n')
main=(old/'testFailureDisposition.C').read_text()
main=main.replace(' C&cloud=*tx.trial().cloud;',' C&cloud=*tx.trial().cloud;\n  std::ofstream boundary((runTime.path()/"R1_boundary.csv").c_str(),std::ios::app);\n  boundary<<std::setprecision(17);\n  fiveEqDPM::migrationR1::observer()=[&](const char*stage,const particle&base){\n   const auto&p=dynamic_cast<const P&>(base);\n   boundary<<cycle<<","<<stage<<","<<Pstream::myProcNo()<<","<<p.origProc()<<","<<p.origId()<<",";\n   bool geometric=std::string(stage)=="SEND_BEFORE_PREPARE"||std::string(stage)=="RECEIVE_AFTER_CORRECT";\n   if(geometric)boundary<<p.position().x()<<","<<p.position().y()<<","<<p.position().z();else boundary<<"NA,NA,NA";\n   boundary<<","<<p.cell()<<","<<p.face()<<","<<p.tetFace()<<","<<p.tetPt()<<","<<r1::rng(cloud.rndGen())<<","<<p.active()<<","<<p.typeId();\n   auto fields=r2::parcelScalars(const_cast<P&>(p));\n   for(auto f:fields)boundary<<","<<r1::bits(*f);\n   boundary<<"\\n";boundary.flush();\n  };')
main=main.replace(' tx.discard();',' fiveEqDPM::migrationR1::observer()={};\n tx.discard();')
(new/'testNativeMigration.C').write_text(main,newline='\n')
src=root/'fitting/dpm/m8a3b_t4_s2_c1_n1_v1/valid_final'
case=ev/'boundary_forward'
shutil.copytree(src,case,ignore=shutil.ignore_patterns('C1*','N1*','native_crossing*','S2_invalid*','N1_staged_output','log.*'))
(ev/'build.sh').write_text('''#!/bin/bash
source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
set -e
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMMigrationR1Native
wmake > /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_native_v1/log.wmake 2>&1
''',newline='\n')
(ev/'boundary_forward.sh').write_text('''#!/bin/bash
source /home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/etc/bashrc >/dev/null 2>&1
s=/mnt/d/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_native_v1
mpirun --allow-run-as-root --oversubscribe -np 2 /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMMigrationR1Native/testNativeMigration -parallel -case "$s/boundary_forward" > "$s/log.boundary_forward" 2>&1
rc=$?;printf '%s\\n' "$rc" > "$s/exit.boundary_forward.txt";exit "$rc"
''',newline='\n')
print('Prepared isolated R1 target and protected',len(frozen),'frozen files')
