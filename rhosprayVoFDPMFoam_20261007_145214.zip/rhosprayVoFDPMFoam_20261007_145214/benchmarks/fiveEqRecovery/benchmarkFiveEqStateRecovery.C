#include "fiveEqStateRecovery.H"
#include <chrono>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
using namespace fiveEq;
struct Sample { double us,iterations,gas,liquid,residual,fallback; };
int main(int argc,char** argv){
    if(argc!=2)return 2;
    fiveEqGasThermoEvaluator gas(argv[1]);fiveEqLiquidThermoEvaluator liquid;fiveEqStateRecovery kernel(gas,liquid);
    std::ofstream raw("benchmark_raw.csv"),out("benchmark_results.json");raw<<std::setprecision(17)<<"group,us,iterations,gasQueryCalls,liquidPublicQueryCalls,residualEvaluations,fallbackSteps\n";
    out<<std::setprecision(17)<<"{\"groups\":{";bool first=true;double checksum=0;
    for(unsigned mode=0;mode<3;++mode)for(unsigned guess=0;guess<(mode==1?3u:1u);++guess){
        std::vector<Sample> samples;std::string name=mode==0?"PURE_GAS":mode==2?"PURE_LIQUID":guess==0?"MIXED_MIDPOINT":guess==1?"MIXED_PROVIDED_1.02p":"MIXED_ENERGY_SECANT";
        for(unsigned repeat=0;repeat<3;++repeat)
        for(double a:mode==1?std::vector<double>{1e-12,1e-8,1e-4,.01,.1,.5,.9,.99,1-1e-8}:std::vector<double>{mode==0?0.:1.})
        for(double p:mode==1?std::vector<double>{500000.,3000000.,6000000.}:std::vector<double>{50000.,500000.,3000000.,6000000.,12000000.})for(double TL:mode==1?std::vector<double>{295.,300.,305.}:std::vector<double>{285.,300.,320.})for(double TG:{400.,800.,1200.,2000.}){
            auto q=kernel.generate(a,p,TG,TL,{{2013.039,-42,18}},{0,0.228,0.772});
            RecoveryOptions options;options.initialGuess=guess==0?InitialGuess::MIDPOINT:guess==1?InitialGuess::PROVIDED:InitialGuess::ENERGY_SECANT;options.knownPressure=1.02*p;
            // Untimed warm query; no cross-query state/cache is retained.
            kernel.recover(q,options);
            auto start=std::chrono::steady_clock::now();auto s=kernel.recover(q,options);auto stop=std::chrono::steady_clock::now();
            Sample x={std::chrono::duration<double,std::micro>(stop-start).count(),double(s.iterations),double(s.calls.gas),double(s.calls.liquid),double(s.calls.residual),double(s.calls.fallback)};
            samples.push_back(x);checksum+=s.p+s.cMix;raw<<name<<','<<x.us<<','<<x.iterations<<','<<x.gas<<','<<x.liquid<<','<<x.residual<<','<<x.fallback<<'\n';
        }
        std::vector<double> times,it;double total=0,iterations=0,g=0,l=0,r=0,fb=0;unsigned queriesWithFallback=0;
        for(auto s:samples){times.push_back(s.us);it.push_back(s.iterations);total+=s.us;iterations+=s.iterations;g+=s.gas;l+=s.liquid;r+=s.residual;fb+=s.fallback;if(s.fallback)++queriesWithFallback;}
        std::sort(times.begin(),times.end());std::sort(it.begin(),it.end());
        auto quantile=[](const std::vector<double>& v,double f){return v[static_cast<unsigned>(f*(v.size()-1))];};
        if(!first)out<<',';
        first=false;
        out<<'\n'<<'"'<<name<<"\":{\"count\":"<<samples.size()<<",\"mean_us\":"<<total/samples.size()<<",\"median_us\":"<<quantile(times,.5)<<",\"P95_us\":"<<quantile(times,.95)<<",\"P99_us\":"<<quantile(times,.99)<<",\"max_us\":"<<times.back()<<",\"mean_iterations\":"<<iterations/samples.size()<<",\"P99_iterations\":"<<quantile(it,.99)<<",\"max_iterations\":"<<it.back()<<",\"fallback_query_frequency\":"<<double(queriesWithFallback)/samples.size()<<",\"mean_fallback_steps\":"<<fb/samples.size()<<",\"mean_gas_query_calls\":"<<g/samples.size()<<",\"mean_liquid_public_query_calls\":"<<l/samples.size()<<",\"mean_residual_evaluations\":"<<r/samples.size()<<'}';
    }
    out<<"},\"checksum\":"<<checksum<<",\"measurement\":\"warm standalone OF7 C++ including validity interval construction; no CFD/MPI cost\",\"counterSemantics\":\"adapter entry calls, including all liquid PT queries for bracket construction; frozen EOS internal polynomial/Newton work and gas internal temperature iterations are not separate public calls\"}\n";
    std::cout<<"Benchmark complete\n";return 0;
}
