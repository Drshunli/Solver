# M3 interface geometry (Foundation OpenFOAM 7)

The active solver directly instantiates OF7 `interfaceProperties(alphaL,U,dict)`.
The dictionary is `constant/interfaceProperties`, separate from the legacy gas
thermophysical dictionary. A constant model example is:

```
FoamFile
{
    version 2.0;
    format ascii;
    class dictionary;
    object interfaceProperties;
}
sigma sigma [1 0 -2 0 0 0 0] 0.072;
```

The numeric value is an example for a future case, not hard-coded in C++.
OF7 also accepts a `sigma { type constant; sigma ...; }` subdictionary.
`cAlpha` stays in `system/fvSolution` under the `alphaL` solver entry; both
M2 transport and the OF7 interface object read that same entry.

After every MULES transport (including subcycles), `vofInterface.correct()`
updates OF7's face normal `nHatf_` and private curvature `K_`. OF7 obtains a
face gradient from interpolated `grad(alphaL,"nHat")`, divides it by its
magnitude plus `deltaN`, applies `alphaContactAngle` boundary correction when
present, and dots it with `Sf`. It then uses `K_=-fvc::div(nHatf_)`.
`vofCurvature` is an output mirror of that same expression because OF7 has no
public `K()` accessor. Its sign is identical to OF7's liquid-first convention.

OF7 `surfaceTensionForce()` evaluates
`interpolate(sigma*K)*snGrad(alphaL)`. The exported
`vofSurfaceTensionForce` is a **surfaceScalarField at faces**, with
force/volume dimensions [1 -2 -2 0 0 0 0], not a face-integrated force.
The source checks dimensions at runtime: `nHatf` area,
`vofCurvature` inverse length, `sigmaK` pressure and force density.
The constant model declares sigma [1 0 -2 0 0 0 0]. Future M7 must derive
a conservative capillary coupling compatible with the KT momentum flux; this
field is not injected into `rhoU`, `U`, `phiUp` or pressure here.

OF7 contact-angle boundary conditions are inherited through `alphaL` and `U`.
No new dynamic wetting model is implemented. Moving-mesh and contact-angle
behavior, Laplace pressure, parasitic currents and case stability have not
been tested in M3. No CFD case was executed.

Source reviewed: OF7
`src/transportModels/interfaceProperties/interfaceProperties.{H,C}`,
`surfaceTensionModels/surfaceTensionModel/{surfaceTensionModel.C,newSurfaceTensionModel.C}`,
`surfaceTensionModels/constant/constantSurfaceTension.C`,
`src/transportModels/twoPhaseProperties/alphaContactAngle/` and the
respective `Make` files.
