# M6B.1-MC1-COMMON-PRESSURE-CLOSURE-REVIEW — v1

2026-10-05。DIAGNOSIS ONLY。用户要求存于 `request_MC1.txt`；依据开发日志及 TD1/TD2/IDP1 最新追加状态。历史日志/封存判定保持原样。

1. **MC1 status**：**COMPLETE / COMMON-PRESSURE CLOSURE MECHANISM CLASSIFIED / STOP**。19 项诊断门槛 PASS。结论是 MC-F 混合机制：**MC-D/MC-E 解释进入和离开冻结域的方向，MC-A 解释容差带内继续接受，浮点表示为次级影响**。没有修改或安装任何活动修复；严格 boundary attractor 未建立。

2. **Frozen anchor set**：复用 IDP1 全 25 个状态，包含要求的 230/235/240/330/1000/1309/10000/24000/28000/30000/32219/32252，以及260/530/651/3000/6000/10852/15000/20000/22260/26000/27659/31000/32000。每 anchor 审计 cells51–55，共125个 committed states，全部原生 R1 PASS。原 Q/P2 位串准确解码；frozen inputs 可独立复查。所有空间公式、volume=.01、R1/P2/EOS/能量参考/时间策略均冻结。

3. **Committed root geometry**：`committed_geometry.csv` 保存 p/TG/TL/rhoG/rhoL/alpha/mG/mL/Eint/pLo/pHi/FLo/FHi/energyTol/两端 dFdp/rootMarginLo/strictRoot/nativeAccepted。micro cell53 p=pLo≈3.2858482766 MPa、pHi=12 MPa，FHi>0、dFdp>0；FLo>0但≤energyTol，所以属于 **tolerance-band endpoint acceptance**，没有严格零残差的 interior root。原生判定的合法性与数学严格根存在性明确区分。125个邻域状态中只有24个micro cell53 strict shadow不通过，其余101个通过。

4. **Boundary-distance history**：已有低温 cell53 记录32067行，覆盖连续step186…32252，保存TL/alpha/mL及原生mL/alpha密度；另外3206个完整committed快照（step200…32250、stride10）重新求根，合并detail与短窗得到3275个完整root geometry历史点。72个逐步历史回放（230→260共30步；32210→32252共42步，总数≤100）在原accepted dt上重建Q，all100 raw/post恢复、已有全100 snapshot Q/P2位串及time相加位串全部一致。没有新shock长跑。

   230→235的TL为265.932285787、265.727974785、265.527608740、265.330995962、265.137961851、265 K；rootMargin约3.003289e6、2.368198e6、1.733679e6、1.098707e6、4.625974e5、4.463654e-7 J/m³。是有限时间降向边界并在235进入容差带，随后长时间滞留；不是从healthy230就以1e-18渐近推进。

   完整rootMargin并非原日志每步都有Q：本轮**逐accepted-step的ΔrootMargin只对72步短窗精确重建**；其余位置是stride10及detail，不插值、不伪造未保存的每步根余量。温度/相量历史则有连续的32067步既有记录。该覆盖范围在gate中明确声明。

5. **Boundary attractor verdict**：**NOT ESTABLISHED**，不能将向外瞬时方向或TL钉住等同于严格动力学吸引子。30步onset窗余量下降13、上升12、相等5；42步late窗下降8、上升13、相等21。排除前5步宏观接近后，67个micro transitions只有16个余量下降。用户“绝大多数步余量下降”条件不成立。成立的是 **BOUNDARY PINNING / TOLERANCE-BAND STALL**：TL停在下界附近，浮点更新使余量在窄带内波动，真实物理时间进展极小。逐步ΔTL/Δmargin/ΔpLo/Δrho及除以原accepted dt的比值见 `accepted_step_deltas.csv`。

6. **Binary64/native comparison**：native micro rootMargin范围1.4231733e-8…1.5965488e-6 J/m³，24/24原生accepted；FLo为正，只有端点容差支持接受。IDP1既有相邻PASS/FAIL平台保留。MC1为每个anchor的committed、selected、nextafter上下邻居、64×selected、1e-12宏观微扰保存完全相同的Q/P2 input bits，共150个状态，并分别求3种算术参考。

7. **High-precision comparison**：long double algebra和Boost100位十进制（远大于80-bit）只用于隔离诊断。保持相同输入Q/P2 decoded fraction、native局部JANAF mixture coefficients/R/Hc、原v3六组数学多项式/81 potential coefficients、C_L及R1残差式。exact转换以原binary64 mantissa/exponent为准，未重新拟合、未归一化fraction/species。高精度只更精确计算rho、相同HARD内的density crossing/temperature inversion和FLo；没有调用HARD外EOS或提交结果。

   75个合法PT数学函数对照的native/100digits最大rho相对差=1.110223025e-15、liquid e差=3.929017112e-10 J/kg、gas e差=2.328306437e-10；差异小，但液体等温密度导数很小，逆映射放大到pLo/FLo。100digits reference在24个micro committed states的rootMargin为 **−4.0514097e-6…−2.2764576e-6**，24个均不在相同1×数学容差带内。anchor235 native rho=754.44744534423728、pLo=3285848.2765736477、FLo=8.245930075645447e-6；100digits rho≈754.44744534423723651、pLo≈3285848.276574602816、FLo≈1.09687531126e-5。long double与100digits接近，native差异主要经endpoint逆映射体现。`function_checks.csv`与`precision_inputs.csv`保证函数/物理输入相同。

   这不重写冻结的native operational-domain资格；它揭示native接受与高精度数学参考的区别。高精度参考的严格根/容差负余量不等于授权替换活动R1或修正Q。

8. **Precision significance**：未取得≥1e6倍更大合法dt。全部已测试micro高精度状态在1×数学容差下均不接受，甚至committed baseline已为负余量，不能声称“精度升级救回推进”。此处不能把一个负余量硬转成正的dtLegal。连续向外root slope仍约2.9584e11，energyTol量级仅8.69e-6；修改浮点表示并不建立宏观interior窗口。**MC-B不获primary promotion，表示影响仍次级**。测试范围不是全正dt不存在性证明。

9. **energyTol definition**：原RecoveryOptions energyRelativeTol=2e-12、energyScalePerMass=1e5。`energyTol=2e-12*max(abs(Eint),(mG+mL)*1e5)`，等价于状态相对项与质量关联能量floor的较大者，无独立固定J/m³绝对tol。cell53 Eint≈4.3461477e6，大于rhoMix*1e5≈1.3923e6，所以Eint项控制，energyTol≈8.6922955e-6。pTol=1e-4+2e-11*abs(p)是另一个收敛指标，不可代替根域存在；最终state validation原4×energyRelativeTol也未改。各anchor FLo/energyTol见分类表。

10. **Strict-root shadow**：诊断条件FLo≤0≤FHi，不修改活动recover。24/24 micro cell53原生committed仅因tolerance接受，125邻域中strict shadow失败24个；healthy230及邻cell51/52/54/55均strict内侧。能量距严格根存在约FLo=7.10e-6…8.68e-6 J/m³；局部线性压力指示FLo/dFdp约2.49e-6…3.04e-6 Pa，意味着严格根在下端之外，但本轮没有在那里查询或解根。

11. **Tolerance sensitivity**：原冻faces/trial algebra不变，只有离线RecoveryOptions的energyRelativeTol乘0.1/1/10/100，pTol/maxIterations保持原值；原species/phasepresence与raw及original residual-species post均检查。共16852个cell53 shadow evaluations，全部候选从已接受尺度增长至freshCap，FAIL后继续。0.1×的24个micro baseline即不合法；10×最大已测cell53合法dt为2.13476314e-16…2.57748391e-16，100×为2.44527414e-15…2.88678197e-15 s。不是all100/time/production资格，也没有改活动tol。

| anchor | 0.1× largest tested dt | 1× | 10× | 100× |
|---|---:|---:|---:|---:|
| 235 | 0.000000000e+00 | 1.066048333e-18 | 2.387948267e-16 | 2.729083733e-15 |
| 330 | 0.000000000e+00 | 5.211824075e-19 | 2.134763141e-16 | 2.561715769e-15 |
| 1309 | 0.000000000e+00 | 6.064668015e-19 | 2.328832518e-16 | 2.484088019e-15 |
| 10000 | 0.000000000e+00 | 1.971017105e-18 | 2.522901894e-16 | 2.522901894e-15 |
| 28000 | 0.000000000e+00 | 1.667783704e-18 | 2.134763141e-16 | 2.561715769e-15 |
| 32219 | 0.000000000e+00 | 1.326646128e-18 | 2.377349861e-16 | 2.716971270e-15 |
| 32252 | 0.000000000e+00 | 1.326646128e-18 | 2.377349861e-16 | 2.716971270e-15 |

12. **Tolerance scaling**：支持 **带偏置的容差窗口规律** `dt_local≈max(0,(s*energyTol−FLo)/dFLo_dt)`；不支持无条件dt∝s，尤其1×时FLo已贴近energyTol、0.1×为零。100×/10×已测比为10…12，符合offset law及有限候选网格误差；仍距1e-6 cap极远。根窗口由容差定义的边界余量限制，而不是strict interior；放宽容差只容许更大数学残差，不能作为修复方案。

13. **EOS endpoint geometry**：Tmin=265 K冻结。cell53 rho≈754.44744534，沿lower-T曲线dpLo/drho≈1.5357568684e6 Pa/(kg/m³)，drho/dp|T≈6.5114474e-7；betaL≈0.001393249266 J/kg/Pa；沿Tmin的deL/drho≈−545.6488154 J/kg/(kg/m³)。使用有效HARD内的一侧热力学导数，不做Tmin外外推。1e-13的rho变化可引起~1e-7Pa endpoint变化，再经主导gas energy beta放大到~1e-7…1e-6 J/m³，足以改变剩余tol-band margin。该几何敏感性是比值和EOS逆映射共同作用。

14. **Alpha asymptotic experiment**：25 anchors×4 scales×2 controls=200记录。A把alpha、mL同步缩放1/1/2/1/4/1/10以保持intrinsic rho；B只改alpha保持mL。调整gas mass以保持原gas intrinsic state、species与原U；重建phase energy和kinetic同时保留原Eint相对恢复phase-energy的deficit，避免把重生成strict equilibrium误作扩大合法域。所有操作仅是local数学diagnostic，没有FV提交。

15. **Fixed-rhoL experiment A**：pLo/pHi约束保持O(1)，mL eL贡献按scale减小。方向参考同步缩放phase mL/alpha derivatives，其他conservative derivatives沿原冻flux方向，用1e-12 probe观察FLo slope；不是重新部署空间通量。anchor235液相能量从约−1137至−113.7 J/m³，root slope仍约2.9584e11；local slack dt约1.509e-18、1.513e-18、1.515e-18、3.978e-18。最后一个scale的ratio/endpoint舍入变化明确保留；本地slack估计可能为负，不能把重生成的非法样本宣称PASS。

16. **Fixed-mL experiment B**：alpha减半/四分之一/十分之一将rho变为约1508.895/3017.790/7544.474 kg/m³，超过该冻结EOS density image；75个缩小alpha B样本均为`NO_LIQUID_PRESSURE_INTERVAL`，root margins不伪造数值。未访问HARD外PT。该控制不是物理可接受相态，也不是候选production更新。

| scale | experiment | rhoL | native legal | reason | local slack dt |
|---|---|---:|---:|---|---:|
| 1 | A_fixed_rho | 754.447445344 | 1 | PASS | 1.5088009960197365e-18 |
| 1 | B_fixed_mass | 754.447445344 | 1 | PASS | nan |
| 0.5 | A_fixed_rho | 754.447445344 | 1 | PASS | 1.5128597023591935e-18 |
| 0.5 | B_fixed_mass | 1508.89489069 | 0 | NO_LIQUID_PRESSURE_INTERVAL | nan |
| 0.25 | A_fixed_rho | 754.447445344 | 1 | PASS | 1.5148889164204738e-18 |
| 0.25 | B_fixed_mass | 3017.78978138 | 0 | NO_LIQUID_PRESSURE_INTERVAL | nan |
| 0.10000000000000001 | A_fixed_rho | 754.447445344 | 1 | PASS | 3.9776374229351425e-18 |
| 0.10000000000000001 | B_fixed_mass | 7544.47445344 | 0 | NO_LIQUID_PRESSURE_INTERVAL | nan |

17. **Singular-variable verdict**：主要限制由 **rhoL=mL/alphaL决定的液相pressure interval及其与共同压力能量根的交切** 驱动，不由液相能量权重本身驱动。alpha→0⁺、rhoL固定时mL eL与mL betaL为O(alpha)，但任何PRESENT液相的合法P_L(rhoL)仍是O(1)约束：root pressure仍需P_G∩P_L。alpha=0/mL=0才进入纯气体拓扑，不能人为阈值删除phase模拟该极限。微小liquid energy contribution不意味着对共同压力closure无约束。

18. **Alpha-mass compatibility**：Ccompat=(dmL/mL)−(dalpha/alpha)=rhoDot/rho。anchor235左面≈+3768.79062/s、右面≈−3678.77215/s，合计+90.01846988/s；rhoDot≈67914.204633 kg/m³/s。这是正的intrinsic-density drift，需要审查热力学兼容性，但**不是仅凭Ccompat≠0就证明离散错误**：K=0 compression本来就使rho变化。

19. **Flux consistency**：同一reconstructed states、same KT weights下，若face intrinsic rho恒定，则mLΦ=rho*alphaΦ（仅有舍入误差）。一般状态有rho梯度与alpha advective source。离散导数可分解

   `Ccompat=−div(phiStar)−[(mLΦR−rho*alphaΦR)−(mLΦL−rho*alphaΦL)]/(V*mL)`。

   anchor235压缩项=132.039866941/s，transport-gradient项=-42.0213970627/s，合计90.01847/s；gradient项是抵消作用。身份式与DD alpha导数roundoff逐anchor核对，`compatibility_decomposition.json`保存结果。当前方向造成 **MODEL/THERMODYNAMIC PHASE-MASS/FRACTION COMPATIBILITY LIMITATION**；generic discrete contact-incompatibility bug未建立，不能将期待rho恒定错误地用于压缩流。

20. **Exact-contact control**：100-cell periodic、constant p=3MPa/Ux=20/rhoL/TG=800，alpha=2e-5*(1+0.5sin)，mL与alpha一致，TL分别300与265。原reconstruction+KT一显式步dt≈6.4733e-7；两种温度all100 raw/post均PASS。最大p误差分别2.79e-9与3.51e-7 Pa（远小于原pTol），rhoL误差≤2 ULP=2.27e-13；rootMargin相对相同constant-p equilibrium reference的误差分别1.86e-9与1.207e-6 J/m³，均在原energyTol内，265K后的min margin≈6.72e-6为正。小相量甚至在Tmin并不自动要求micro dt；更新方向决定是否离开root域。constructed contact不是原shock的替代same-anchor admissible FV witness，不能由此重写IDP1 scheme资格。

21. **Compression control**：local smooth stencil U=−kappa*x，constant p/T/rho/alpha，kappa=.001/.01/.1/1，native两面KT与一显式dt=1e-8。解析K=0参考为alphaDot=0、mGDot=k mG、mLDot=k mL、EintDot=k(Eint+p)、中心M=0。8个控制的alpha不变、phase-mass同步；relative mass/energy误差随k下降，最大约8.94e-6/1.425e-5（空间截断项），同一k的native与analytic root-slope相对差<2e-5。TL300四个raw/post全PASS但液体温度下降；k=1时ΔTL≈−9.491e-6 K，Δp≈0.04069 Pa。TL265四个native/analytic都向low-root外，raw/post全拒绝；FLo slopes约3.263e6/3.263e7/3.263e8/3.263e9 J/m³/s。不是shock专属或仅靠重构造成的结果。

22. **K=0 review**：活动方程为两相质量守恒、momentum、total energy，加上D_t alphaL=0；没有独立液相能量方程，TG/TL由rhoG/rhoL和共同p/Eint恢复。压缩下D_t rhoL=−rhoL divu即使alpha输运完全正确也成立。small liquid的energy derivative权重小，共同p响应趋近gas主导；沿液相EOS有

   `TLdot=(pdot−(dp/drho)_T*rhoLdot)/(dp/dT)_rho`。

   gas主导p响应在控制中约几MPa/s每单位kappa，而维持TL265所需rhoL*(dp/drho)_T约1e9 Pa/s每单位kappa，两者差导致TL向下。根能量等式和当前K=0选择会将自然演化方向带出冻结single-liquid numerical domain；endpoint决定停止位置。没有证明物理液相/固相适用性，也没有改K、Kapila source或BN relaxation。

23. **Alternative closure controls**：CONTROL1原K0冻方向dFLo/dt≈+2.9584e11；CONTROL2保持dmL原值、令dalpha=dmL/rhoL以保证rhoDot=0；CONTROL3保持dalpha原值、令dmL=rhoL*dalpha。24 micro控制2/3的root slopes均为负，anchor235约−1.569292688e9与−1.569172383e9。这确认ratio/interval漂移是主要耦合通道。它们只是在同一state上的infinitesimal数学对照：独立改alpha导数或mL导数不自动FV conservative，未进行all100替代方案资格、未修复初始高精度负余量，绝非production模型。

24. **MC-A…F per anchor**：24 micro正式分类MC-F；组成MC-D/MC-E origin + MC-A continuation，表示效应secondary。MC-C generic discrete bug未建立；MC-B≥1e6 precision promotion criterion未满足；healthy230为CONTROL。

| anchor | MC class | native margin (J/m³) | 100digits margin | native FLo/energyTol |
|---|---|---:|---:|---:|
| 230 | CONTROL | 3.003289243e+06 | 3.003289243e+06 | -3.4628972e+11 |
| 235 | MC-F | 4.463654077e-07 | -2.276457629e-06 | 0.94864816 |
| 240 | MC-F | 4.556786335e-07 | -2.477039568e-06 | 0.94757672 |
| 260 | MC-F | 4.649918592e-07 | -2.283212855e-06 | 0.94650529 |
| 330 | MC-F | 1.423173309e-08 | -2.892010933e-06 | 0.99836272 |
| 530 | MC-F | 6.917976499e-08 | -2.941581830e-06 | 0.99204125 |
| 651 | MC-F | 5.711626327e-07 | -2.561433673e-06 | 0.93429093 |
| 1000 | MC-F | 6.661575353e-07 | -2.428488393e-06 | 0.9233623 |
| 1309 | MC-F | 2.913289428e-08 | -3.813767013e-06 | 0.99664842 |
| 3000 | MC-F | 4.594039238e-07 | -3.226097827e-06 | 0.94714815 |
| 6000 | MC-F | 1.977022803e-07 | -3.309372430e-06 | 0.97725546 |
| 10000 | MC-F | 8.067872441e-07 | -3.147689703e-06 | 0.90718364 |
| 10852 | MC-F | 1.013540856e-06 | -2.931704644e-06 | 0.88339779 |
| 15000 | MC-F | 9.898208738e-08 | -2.949178412e-06 | 0.98861266 |
| 20000 | MC-F | 8.868809855e-07 | -2.993620772e-06 | 0.8979693 |
| 22260 | MC-F | 2.470623767e-07 | -3.403203521e-06 | 0.97157685 |
| 24000 | MC-F | 2.545129573e-07 | -3.475175788e-06 | 0.97071971 |
| 26000 | MC-F | 5.148463608e-08 | -4.051409662e-06 | 0.99407698 |
| 27659 | MC-F | 4.789616978e-07 | -3.103762896e-06 | 0.94489813 |
| 28000 | MC-F | 5.609180844e-07 | -3.373125028e-06 | 0.93546951 |
| 30000 | MC-F | 5.804758585e-07 | -3.219892397e-06 | 0.9332195 |
| 31000 | MC-F | 1.353473595e-06 | -2.613780606e-06 | 0.84429043 |
| 32000 | MC-F | 1.596548787e-06 | -2.279950544e-06 | 0.81632599 |
| 32219 | MC-F | 1.169071726e-06 | -2.543558826e-06 | 0.86550483 |
| 32252 | MC-F | 1.175590984e-06 | -2.929969148e-06 | 0.86475483 |

25. **Dominant MC class**：MC-F=24/24 micro。此轮不能无歧义把MC-D与MC-E拆成唯一主因：当前K0/common-p方向造成降温/密度轨迹，冻结Tmin面切断该路径；MC-A定义在该边界上仍可接受的狭窄带。不同贡献的证据均有控制支持。native连续余量下降的严格attractor判据未满足，但model direction/EOS交切/容差钉住机制已分类。范围限定现有anchors与bounded controls，不推广至所有five-equation models或production flows。

26. **Candidate repairs ranked — NOT IMPLEMENTED**：

| rank | candidate / mechanism addressed | conservation impact | P2 impact | species impact | model impact |
|---|---|---|---|---|---|
| #1 | 最小model-applicability/common-pressure closure实验：研究K0方向与冻结EOS operating set交切（MC-D/E） | 审查阶段不改积分；未来模型须保持phase mass、momentum、Et守恒 | 不删除PRESENT，任何新fraction/source须保留authority | mG/mYi共同守恒及N−1 closure | 必须独立资格；当前不改K/源项/模型，不扩EOS |
| #2 | recovery acceptance formulation审查：辨别strict interior、endpoint容差及native/reference差（MC-A） | 首选拒绝/报告/rollback语义；不事后改Et或cell masses | 不独立alpha clip | 不normalize/修补species | 不保证能推进到endTime；不能简单放宽tol |
| #3 | representation/error-budget研究：ratio、EOS normalization/crossing与reference判定（次级） | 表示更换前须重核实际积分/face-pair守恒 | 同一signed minority semantics与PRESENT不损失 | 同一raw/post residual语义 | 没有million gain证据；不能替代closure applicability审查 |

27. **Conservation implications**：原shared face numerical flux未改。contact/compression使用原守恒更新；math control2/3不是face-pair conservative修复。未来通量/源项设计须给出两面等量反号或合法模型source，不能per-cell post-clipping、单独改mL/Et来“使R1可解”。source_delta为空。

28. **P2 implications**：mL/alpha敏感性不能以threshold deletion、independent alpha clip或把PRESENT误判ABSENT解决。任何未来设计必须保留P2唯一authority、exact presence、trace/subnormal原政策；本轮alpha缩放是数学实验而非删phase。

29. **Species implications**：原species equations/faces及N−1 residual closure保留。影子R1同时检查raw及q9=q1−(q7+q8) post。任何未来limiting须mG/mYi同系数，不允许normalize(Y)。高精度比较保留native局部composition/mixture energy参考，不以高精度重归一化改变输入。

30. **Model implications**：证据支持审查当前K0/common-pressure closure在强压缩/small-liquid/frozen-domain组合中的适用性，而不是继续temporal tuning或扩EOS。恒ρcontact可宏观推进，压缩即使同步守恒也可冷却液体并离开域，说明generic contact-discrete bug不是已证根因。固液phase certificate仍DEFERRED/CLASS D；数学closure越界不等于已证明真实液体相态转变。

31. **EOS hashes**：HARD p=.05–12MPa/T=265–400K、81coeff/C_L=369229.9537234281永久冻结；数学shadow未改活动模块。

- `liquidEOS/ndecane_gibbs_v3/coefficients.json`：`610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`
- `liquidEOS/ndecane_gibbs_v3/energy_reference.json`：`ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`
- `liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H`：`421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d`
- `liquidEOS/ndecane_gibbs_v3/metadata.json`：`9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`

32. **TD1 hashes**：TD1 fixes保留；无growth/connected/escape/search新调整。

- `serialFiveEq/runSerialFiveEq.C`：`3327f1988bcca53a459d01f9cb2db0fd7624d946b6da378477c679fbcec7907a`
- `fiveEqIntegration/fiveEqTemporalContract.H`：`e47e6466de56e82856ebc66281acf40061dd121ae917144a1343cf6f9019ba89`
- `fiveEqIntegration/fiveEqTemporalPolicy.H`：`a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062`

33. **Foundation/project hashes**：110 active sources、exe/custom libraries、115 installed libraries完全同SHA；Foundation6717/native parcel19全部OK；5453旧证据SHA不变；IDP1 ZIP `12d7ddd0346cd436951b2b82fb82ae1ecfe9539a9187faff4daf8ef4b7ba3274` freshSHA/CRC核验PASS。只有独立MC1代码/数据/报告及milestone追加；旧milestone prefix保持。隔离初次编译indentation warning日志保留，最终0warning/error；追加input/function审计后的8个既有results逐字节复现。

34. **MC1 COMPLETE?**：YES，19项诊断门槛PASS，含negative attractor verdict与partial-cadence history的明确范围；不代表implementation/TD1完整资格。未保存的每步rootMargin不声称补齐。

| gate | status |
|---|---|
| detail anchors recovered | PASS |
| boundary distance history | PASS |
| rootMargin evolution | PASS |
| binary64 vs high precision | PASS |
| tolerance sensitivity | PASS |
| strict-root shadow | PASS |
| alpha/mL asymptotics | PASS |
| intrinsic rho sensitivity | PASS |
| phase mass/fraction compatibility metric | PASS |
| flux compatibility audit | PASS |
| exact-contact control | PASS |
| compression control | PASS |
| K=0 geometry reviewed | PASS |
| MC-A...F classification | PASS |
| dominant mechanism justified | PASS |
| no active source change | PASS |
| EOS unchanged | PASS |
| TD1 unchanged | PASS |
| Foundation unchanged | PASS |

35. **Next permitted milestone**：MC-F对应下一轮**最小双机制实验**，优先model-applicability/common-pressure operating-set审查与recovery-formulation审查；需下一轮独立授权。本轮不自动执行model、precision、tolerance、alpha/K、flux或limiter修改。冻结EOS endpoint不可继续扩。

36. **TD1 status**：PARTIAL / LOCAL CORRECTNESS PASS / MICROSTEP EFFICIENCY UNRESOLVED。root cause修复/资格完成后才可重新验证；没有新temporal tuning，72步历史诊断不能算TD1 COMPLETE。

37. **DYN-CLOSURE status**：NOT AUTHORIZED / NOT EXECUTED，TD1 COMPLETE prerequisite仍未达。

38. **M6B.1/M6B status**：PARTIAL。MC1只关闭机制分类子阶段，未取得shock endTime/production CFD/restart/active DPM资格。

39. **Milestone matrix**：

| milestone | authoritative status |
|---|---|
| PHASE-DEFER | COMPLETE / POLICY FROZEN；historical CLASS D / phase certificate unresolved |
| EOS3-NUMERICAL | COMPLETE / OPERATIONAL DOMAIN FROZEN，265–400K；非phase/production资格 |
| ADM1 | COMPLETE / OUTCOME C / TRIAL REJECTION SEMANTICS CLOSED |
| TD1 | PARTIAL / LOCAL CORRECTNESS PASS / MICROSTEP EFFICIENCY UNRESOLVED |
| TD2 | PARTIAL / DIAGNOSIS CLOSED / MICROSTEP ADMISSIBILITY LIMIT |
| IDP1 | COMPLETE / MECHANISM CLASSIFIED；IDP-G(C主导/F次级)24/24 |
| MC1 | COMPLETE / COMMON-PRESSURE CLOSURE MECHANISM CLASSIFIED / MC-F / STOP |
| model / precision / recovery / alpha-mass implementation | NOT EXECUTED，下一轮独立授权 |
| DYN-CLOSURE | NOT AUTHORIZED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL |
| M6B.2 / DPM / T4-S3 / production CFD | NOT EXECUTED / 未认证 |

**STOP。** 没有活动修复或后续阶段自动执行。全部ledger/gates位于 `fitting/integration/m6b1_mc1_common_pressure_closure_review_v1/`；封存包为 `D:/DATA/Solver/checkpoints/M6B1_MC1_COMMON_PRESSURE_MECHANISM_CLASSIFIED_STOP_v1.zip`，SHA/CRC见 `checkpoint_gate.json`。
