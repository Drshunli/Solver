# M8A.3B-T1：二维 Eulerian 注入表示与喷孔所有权冻结

2026-10-01。仅设计、实际壁面坐标审计及离线代数核算。
新证据：`fitting/dpm/m8a3b_t1_v1`。现有 case、BC、mesh、solver 不变。

## 1. M8A.3B-T1 status

**COMPLETE / DESIGN ONLY**。Mapping-A 和唯一 future Eulerian footprint 已冻结。
用户在本轮明确提供 PROJECT_DESIGN_INPUT：xNozzle=15mm、底壁 y=0、进入方向 +y；
原始回复标签 DESIGN_INPUT_PROPOSAL 已保存，作为本轮几何设计来源采纳。
它独立于 TEST_DPM_INLET。现有 mesh 尚无喷孔 patch，未来实际建网/BC 激活仍未执行。
整面离散误差已量化，未批准任何近似替代。

## 2. Physical circular-hole area

单孔 Dphysical=0.3mm：
`Aphys=πDphysical²/4=7.068583470577033e-8m²`。
mdot=1.09609e-4kg/s、TL=300K。所有引用物性只复用用户给定参考值，
未拟合 EOS、生成 reference table 或运行 CFD。

## 3. Old numerical slot area

actual sprayCloudProperties:88 的 legacy DPM 注释面积：
`Aold=(300μm)*(50μm)=1.5e-8m²`。
这是 point-cone 模型中的等效面积，不是现有 Eulerian boundary patch。
T0 已核对 dOuter=138.1976598μm 与该面积一致。

## 4. Area ratio

`Aphys/Aold=4.71238898038469`。
历史 DPM 配置流量/新目标=4.801360702。
**两者数值接近不能证明旧模型的预期生产映射。**
选定 Mapping-A 不由旧 DPM 流量或位置导出；不使用 2.62583 缩放。

## 5. Physical reference velocity

使用用户给定 reference-EOS generated rhoL≈727.4329605kg/m³，
pRef=3MPa、TLRef=300K：
`Uref=mdot/(rhoL*Aphys)=2.131674300619m/s`。
这是参考算术值，不是固定速度边界；边界压力/密度变化时速度随质量流量控制响应。

## 6. Mapping-A definition

**Equivalent-area slot**：数值深度 bz=50μm，
`wEq=Aphys/bz=1.413716694115mm`，理想 A2D=Aphys。
普通局部守恒通量，不引入额外 extensive weighting，W=1。
给定同一参考状态，质量、速度、advective momentum、热力学随质量输运的能量
及动能通量与圆孔 reference 一致。
平面内宽度变为物理 D 的 4.7124 倍；不保留圆形界面、三维曲率、周长、
spanwise 运动或实际圆孔破碎尺度。该模型适合二维算法激活，不是三维物理验证。

## 7. Mapping-B definition

**Diameter-preserving representative-depth model**：w=Dphysical=0.3mm，
Uref 不变，beff=Aphys/Dphysical=235.619449019μm。
数值 bmesh=50μm，W=beff/bmesh=4.712388980385。
数值槽的 mdotNum=mdotPhys/W≈2.32597522098e-5kg/s。
W*mdotNum=mdotPhys。

必须采用统一的全域 extensive 解释：

| Subsystem | 必须一致的规则 |
|---|---|
| Eulerian mass/momentum/energy/species | intensive Q 不乘 W；physical integrals=W∫QdVnum |
| Liquid 与 gas boundary totals | physical integrated flux=W*numeric integrated flux，不能只缩放喷孔 |
| Gas crossflow inventories/ledgers | 同样使用有效深度，所有 extensive 总量同乘 W |
| DPM multiplicity | physical represented multiplicity=W*nNum；不能只扩大 Eulerian 预算 |
| DPM native transfers | physical integrated transfer=W*numeric transfer；数值 source density 保持 ΔNum/Vnum，因分子分母同乘 W |
| Conservation/restart | 固定保存 mapping ID/W/数值与物理解读；避免重启后重复缩放 |
| Future phase transfer | 同一 W 和同一预算闭合，质量/动量/能量/物种一致扣加 |

上述是候选必须满足的合同规则，未实现或认证，**Mapping-B 不接受为首次激活方案**。
错误做法是仅把 nozzle mdot 乘 W，或把体积源密度再乘 W。
保持局部平面内 D 不等于恢复三维圆孔物理。

## 8. Mapping-C definition

**Diameter-preserving direct-mdot slot**：w=0.3mm、bz=50μm，
将全孔 mdot 直接施加到 Aold，W=1。
`UC=mdot/(rhoL*Aold)=10.045278484005m/s`。
参考速度比=4.712388980385；advective momentum flux 比=4.712388980385；
kinetic-energy flux 比=22.206609902451。
这改变参考流动，应仅用于明确另定义的 planar-slot jet，本轮不选择。
**22.2066 是动能通量比，不是总能量通量比**；同一热力学状态下热力学能量
随相同 mdot 输运部分不因该因子扩大。没有凭空指定绝对 e/h/q。

## 9. Selected 2D mapping

**MAPPING-A / DESIGN FROZEN / NOT IMPLEMENTED**。
依据本轮用户明确推荐的首次二维算法激活默认方案；项目检索没有发现
已批准的其他生产物理解释。历史建议的 slice-area scaling 未获生产批准，
本轮将其保留为未选候选 B，不把它作为 A 的来源。

## 10. Selection rationale

| Criterion | A | B | C |
|---|---|---|---|
| Local conservative consistency |普通数值通量|局部可一致，但全域解释合同必需|普通数值通量|
| Physical integrated mdot |直接保留|统一 W 后保留|直接保留|
| Reference exit U |保留|保留|增大4.7124倍|
| In-plane Dphysical |不保留|保留|保留|
| Reference advective momentum |保留|统一 W 后保留|增大4.7124倍|
| Reference kinetic-energy flux |保留|统一 W 后保留|增大22.2066倍|
| Same-state thermal energy flux |保留|统一 W 后保留|相同 mdot 下保留|
| fiveEq KT BC |常规一致边界构造|额外全域 ledger/解释规则|可构造，但对应不同流动|
| DPM source compatibility |无额外 W；常规冻结源项语义|parcel/transfer/volume/ledger必须统一|常规源项语义，流动已改变|
| Complexity / interpretation |最低，面积等价清晰|最高，需要全域 scaling certification|低，但不得冒充圆孔参考|
| Current decision |SELECTED DESIGN|NOT SELECTED|NOT SELECTED|

Mapping-D=真实三维圆孔，仅记录为 future physical-validation path，不实现。
A/B/C 的上述“保留”均为同状态理想面积的入口通量代数关系，非动态喷流结果。

## 11. Nozzle center source

**PROJECT_DESIGN_INPUT / 本轮用户明确回复**，来源不是旧 DPM point。
原始数据及标签保存在 user_design_input.json。
此前位置未确定的中间版本另存 mapping_before_location_input.json 和
report_before_location_input.md；最终合同采用新的独立设计输入。

## 12. xNozzle

**xNozzle=15.0mm**，设计冻结。数值 z 中心采用实际二维层中面 z=15.0mm，
它是 mesh 层几何定义；未来 patch 中心 (0.015,0,0.015)m。

## 13. Injection wall

**bottomWall，y=0**，按用户 PROJECT_DESIGN_INPUT 冻结。
这是未来从完整底壁划分入口的设计，不是已存在的 nozzle patch。

## 14. Injection direction

**fluid-entry direction=(0,+1,0)**，按用户回复冻结；
未来入口 patch outward normal=(0,-1,0)。二者符号明确区分。

## 15. Ideal patch width

**理想 patch 宽=1.413716694115mm**。
唯一 future footprint：x∈[14.2931416529423,15.7068583470577]mm、y=0，
z∈[14.975,15.025]mm。ideal area=Aphys。
不将该连续几何边缘吸附到当前网格点；未改变物理 mdot。

## 16. Existing wall-face representation

actual bottomWall 210 faces 已逐面审计，global IDs=41890–42099；
完整坐标见 bottom_wall_faces.csv，目标附近 dx=50μm。
理想两个 x 边缘分别位于 faces **41965 / 41994** 内，现有 whole faces 不能精确表示。

| 只读审计候选 |Global face IDs|x区间(mm)|宽度(mm)|中心误差|
|---|---|---|---:|---:|
|完全位于理想槽内的28面|41966–41993|14.3–15.7|1.4|0|
|覆盖理想槽的30面|41965–41994|14.25–15.75|1.5|0|

两者都是 AUDIT CANDIDATES，**均未选为 production patch**。
未来要精确保留 Mapping-A，需要另轮授权在理想边缘进行一致的网格面/单元划分，
或重新生成相应网格；不是在当前 boundary 中写一个名字即可。
没有给定或伪造可接受几何误差阈值；本轮不改 mesh。

## 17. Numerical patch area

理想 Aphys=7.068583470577033e-8m²。
28-face 候选 Apatch=7.0e-8m²；30-face 候选 Apatch=7.5e-8m²。
两者含实际输入坐标的浮点积分误差约1e-22m²。
理想区间与现有面作数学相交的面积等于 Aphys，但这些交片并非现有 native patch faces。
故 future 理想面积已知、数值候选面积已知，**当前 production patch 仍未建立**。

## 18. Patch-area geometric error

28-face 候选面积误差 **−0.9702576317%**，槽宽误差 −13.716694μm。
30-face 候选面积误差 **+6.1032953946%**，槽宽误差 +86.283306μm。
两者中心误差为零。无 quantized fallback 获批准；ideal width 不变。

## 19. Resulting inlet velocity

理想 reference U=2.131674300619m/s。
若仅为审计把同一 mdot/rho 放到28面候选：Urequired=**2.152559675144m/s**，
相对变化 **+0.9797638654%**。
30面候选：Urequired=**2.009055696801m/s**，变化 **−5.7522203923%**。
这是面积误差后果，不是正式入口速度或已采纳替代。
未来 coherent BC 下 rho 随机械响应压力变化，不额外固定 U。

## 20. mdot consistency

理想及两种 audit candidates 均检查 Urequired=mdot/(rho*Apatch) 恒等式。
保留 physical mdot=1.09609e-4kg/s，未为近似面积静默调整流量。
没有 native patch、BC 或 CFD 验证：runtime integrated flux **NOT IMPLEMENTED**。
未来必须满足 Σ_f rhoL_f*(U_f·nIn_f)*A_f=mdotTarget；不能以参考均匀算术
替代非均匀 coherent face-state 构造。

## 21. Pressure BC semantics

控制变量冻结为 integrated mdot + TL=300K；压力响应 outgoing/mechanical
信息，pRef=3MPa 仅参考/初始状态。
future boundary builder coherent 构造 P2,mG,mL,M,Et,mYi。
禁止 p/TL/mdot 三个独立 Dirichlet；参考 U 不是额外独立控制。
BC builder 本轮未实现。

## 22. Initial topology

保持 INITIAL_TOPOLOGY_V1：**interior gas，t=0 Eulerian liquid-column L=0**。
不预填液柱；未生成或改动 alpha/P2/phase-mass 字段。

## 23. TEST_DPM_INLET status

旧点 (0.015,5e-6,0.015) 仍为 TEST_DPM_INLET，仅测试；生产预算为零。
独立新设计输入冻结后，可计算它位于 future nozzle 中心的 +y 方向5μm处、
在理想槽的平面内中心线上。这个关系是确认后的几何结果，不是设计来源。
当前 legacy case active=true 未改变，不从该点生成 synthetic core。

## 24. Production nozzle ownership

physical nozzle liquid mass 由 **Eulerian liquid inlet** 独占。
independent production DPM nozzle 默认 OFF（设计合同，runtime 未实现）。

## 25. Anti-double-injection contract

同一物理喷孔 mdot 不得再由 independent DPM 注入；若另有物理 DPM source，
必须另行明确预算。未来 VOF→DPM 创建 parcel 时，从 Eulerian 同时扣除同一
质量、动量、能量和物种；本轮不实现转换。

## 26. Runtime synthetic topology definition

**家族几何规则已可唯一确定，本轮不实例化或扫描。**
长度参考 Dphysical=0.3mm，横向宽度用 wEq；起点为上述 future Eulerian footprint，
沿 +y，sharp core alphaL=1、外部=0，由P2构造，另1/2/3-cell TRACE_PRESENT版本。

| L/Dphysical |L(mm)|L/w2D|
|---:|---:|---:|
|1|0.3|0.2122065908|
|2|0.6|0.4244131816|
|5|1.5|1.0610329539|
|10|3.0|2.1220659079|

全部为 SUPPORT STRESS TOPOLOGIES，不是物理初始液柱；初始L仍为0。
future production discretized footprint 须精确保留理想映射，未选28/30面近似。

## 27. Whether support scan may resume

**YES，几何/所有权前置条件已冻结，可在下一轮单独请求支撑扫描。**
仅针对冻结理想 footprint 定义 support-only stresses；本轮没有执行。
实际 native nozzle patch 生成/BC 激活仍需另轮授权，不能声称现有case已实现喷孔。

## 28. Whether M8A.3B may resume

**NO，完整 transaction 暂不能恢复。**
T1设计完成不等于新 topology 的完整 strict-support gate 通过；后者尚未运行。
原子cloud/Q提交、forced-event/MPI等M8A.3B门槛仍待完成，本轮明确禁止继续。

## 29. Active solver impact

**NONE**。只新增离线审计、合同、CSV/JSON、报告、checkpoint及状态追加。
actual case/mesh/BC 和 active source/Make 哈希不变，旧3A/3B/T0证据不覆盖。
8项初始映射/壁面核算及4组新增位置/候选几何断言通过，0失败。
无C++改动，无wmake/CFD/EOS fitting/reference-table生成。

## 30. Updated milestone matrix

| Milestone |Status|
|---|---|
|M8A source/energy|PASS / FROZEN|
|M8A.3A|COMPLETE / frozen serial scope|
|M8A.3B-T0|PARTIAL / historical evidence retained|
|M8A.3B-T1|COMPLETE / DESIGN ONLY|
|Mapping-A / center / wall / direction|DESIGN FROZEN / not active|
|Native Eulerian nozzle patch / BC|NOT IMPLEMENTED; exact ideal edges require future mesh work|
|Support topology family|geometry defined / scan NOT RUN|
|M8A.3B / M8A overall|PARTIAL|
|M6B.0|BLOCKED|
|M6B.1|NO|

STOP。不修改mesh/BC，不继续transaction/M6B，不运行CFD。
