# Gas-thermo dependency audit for the five-equation KT path

`psiReactionThermo` remains the **gas** thermo, not mixture thermo. This
audit records current Foundation OF7 dependencies; it changes no equation.

| Current site | Current owner/dependency | Five-equation migration obligation |
|---|---|---|
| `createFields.H` | `thermo=psiReactionThermo::New(mesh)`; `e=thermo.he()`; legacy gas `rho` initializes from `thermo.rho()` | Keep gas thermo separate from conserved `mG/mL/M/Et`; recover intrinsic `rhoG=mG/alphaG` with a defined small-alpha policy |
| `createFieldRefs.H` | `p=thermo.p()`, `T=thermo.T()`, `psi=thermo.psi()`, `mu=thermo.mu()` | Future `p` is common recovered pressure; `T,psi,mu,he` remain gas-specific; liquid `TL` can differ from gas `TG` |
| Main `.C` | Gas `Cp/Cv/psi` sets current gas KT wave speed; directed fluxes reconstruct legacy gas `rho` | Replace with one consistent two-material left/right state and mixture acoustic speed during M5C/M6B switch |
| `rhoEEqn.H` | `e=rhoE/rho-|U|²/2`, `thermo.correct()`, `p=rho/psi`, boundary `rho=psi*p` | Retire legacy pressure recovery atomically when common-pressure recovery from `mG,mL,Et,alphaL` becomes active |
| `rhosprayVoFMixture.C` | Diagnostic gas `rhoG` view and gas `mu/Cp/kappa`; liquid database is queried at gas `p,T` only for M4 diagnostics | Do not promote diagnostic liquid properties to authoritative EOS state |
| `createClouds.H` | OF7 cloud holds const carrier `rhoG` reference and receives `SLGThermo` | Keep cloud on intrinsic gas density and gas thermo after KT ownership switch |
| Turbulence/reaction | `compressible::turbulenceModel::New(rho,U,phi,thermo)`; reaction uses gas thermo | Define gas/mixture density and mass-flux adapters without confusing `rhoMix` with gas thermo |

Current `thermo.rho()` initializes legacy gas `rho` only. `rhoEqn.H` is its
interior writer; `rhoEEqn.H` reconciles the boundary and calls
`thermo.correct()`. The transitional `rhoG` reference is read-only and adds
no gas continuity equation. It is **not** final five-equation ownership.
