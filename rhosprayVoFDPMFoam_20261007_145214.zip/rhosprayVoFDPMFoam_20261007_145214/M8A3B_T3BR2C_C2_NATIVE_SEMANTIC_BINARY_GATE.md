# M8A.3B-T3B-R2C-C2 — native-compatible parcel binary semantic contract gate

## 1. C2 status

COMPLETE within OF7/GCC11.4/C++11/DPInt32/x86-64 serial passive scope. Final10-case matrix 2901 checks/0 failures; 133419 constructors=133419 destructors/live0. No remaining mandatory C2 gate open.

## 2. Selected binary contract

FIRST-ACTIVATION RAW PARCEL BINARY CONTRACT = NATIVE-COMPATIBLE / SEMANTIC-NONCANONICAL. Object-bounded IO, exact persisted fields and continuation are required; raw hashes across fresh objects are not semantic authority.

## 3. Why C1 remains PARTIAL

C1 strict fresh-object raw-byte determinism failed and its historical documents/tests are unchanged. C2 changes the project prerequisite, not the C1 verdict. C1 strict raw determinism is no longer a prerequisite under this selected first-activation contract.

## 4. Exact padding map

Measured stream offsets78,79,80;84,85,86;91,92,93,94. They correspond to actual object109..111 encountered twice and116..119. Pointer-based field catalog plus actual write tracing, not guessed ranges. See PARCEL_PADDING_MAP_C2.md.

## 5. Authoritative byte map

37 typed field regions compared exactly; categories {'nativeFraming': 15, 'authoritativeField': 266, 'padding': 10, 'nativePersistedField': 64}. All non-padding stream bytes, including native framing, compared. Tracking/IDs, bool/label/scalar/vector state, composition, spray and native-persisted histories included. The duplicate active byte from native base-tail reuse is not masked.

## 6. Native padding control

PASS: unmodified basicSprayParcel reader/writer and identical measured mask. Controlled stream padding mutation preserves native fields; fields and semantic bytes match local. Native source remains oracle; no claims of native field loss.

## 7. Local padding control

PASS: only proven padding stream positions changed; physical fields unaffected. No constructor storage poisoning, whole-object memset, padding zeroing, magic extent, serializer or ABI change.

## 8. Writer fence

PASS: independent placement copies preserve32-byte leading/trailing fences; traced object raw blocks are bounded, explicit Y raw bytes lie within measured field storage.

## 9. Reader fence

PASS: native-compatible stream-constructor readback preserves32-byte leading/trailing fences and all fields.

## 10. Different-address result

PASS for identical physical objects at distinct placement/allocation addresses: authoritative/native-persisted bytes equal; only proven padding may differ. Full raw equality is diagnostic, not a prerequisite.

## 11. Copy result

PASS basic fields/semantic bytes and full-population copy continuation10 accepted steps per path.

## 12. Clone result

PASS basic fields/semantic bytes and full-population clone continuation10 accepted steps per path.

## 13. Basic iNew

PASS. 17 checks/0 failures,8constructors=8destructors/live0. Write/iNew/read/write-again field and semantic equality, writer/read fences, repeated write, native control and corruption challenges executed.

## 14. Evolved population IO

| Case | Roundtripped population | Fields / semantic bytes | Accepted future steps per path |
|---|---:|---|---:|
| injected | 318 | PASS | 10 |
| copy | 318 | PASS | 10 |
| clone | 318 | PASS | 10 |
| padding | 318 | PASS | 10 |
| stochasticDispersionRAS | 213 | PASS | 10 |
| sphereDrag | 213 | PASS | 10 |
| blobsSheetAtomization | 213 | PASS | 10 |
| ReitzKHRT | 217 | PASS | 10 |
| ORourke_coalescence | 214 | PASS | 10 |
| rebound | 213 | PASS | 10 |

Final acceptance run final_matrix_v5 contains all10 cases in one successful run, with actual case count10. No aggregation of failed partial runs is used for COMPLETE.

## 15. KH parent/child IO

PASS: actual native ReitzKHRT creates identified child IDs in parent event. All217 persisted parcels roundtripped; identity, breakup fields, Y,d,T,U and histories exact;10-step future equality.

## 16. ORourke-mutated IO

PASS: actual native coalescence is asserted. Controlled passive fixture uses native nu0 formula, nMin=20/nu0, nu=20, exp(-nu)=2.0611536224385579e-9; particle volume fraction1/3 in unit test cell. This dense fixture is solely a native IO event trigger, not production injection data or CFD validation. No RNG draws/algorithm/probability thresholds altered. Observed local wrapper and unmodified native ORourke kernel yield identical complete event transaction state. All214 parcels roundtripped, then10-step future equality. Known native conservation limitation retained.

## 17. Rebound-mutated IO

PASS: actual native rebound with positive reflected U_y asserted;213 parcels roundtripped; wall position/velocity/IDs/spray fields preserved;10-step future equality.

## 18. Authoritative corruption test

PASS: one measured T-field serialized byte intentionally changed; both non-padding byte comparison and explicit restored-field comparison detect the difference. Expected negative fixture, not a hidden real readback failure.

## 19. Padding-only behavior

PASS native/local controlled streams; unchanged physical fields. Dedicated318-parcel padding-modified population also passes10-step future equality. No opaque native parser assumptions beyond observed valid readback.

## 20. Future continuation

PASS for all10 cases, two paths each,10 accepted steps per path. Complete transactionState-v1 keys compare Q/P2, typed parcel fields/IDs, allocator, RNG/cached normal, histories, sources, generation/time and pending output; common-carrier snapshots and actual query result strings compare independently. Raw parcel padding hashes never substitute for this authority.

## 21. External lifetime instrumentation

PASS: C2 parcel family is byte-identical in source to C1 external-instrumentation candidate; no LifetimeToken member or global allocator interception. Final133419/133419/live0; guard/adoption counts retain external ownership evidence.

## 22. I1 A-H replay

FRESH PASS: old raw-newborn orphan reproduces and is separately cleaned after evidence; guarded path deletes exactly once and restores baseline. A-H/pre-adoption/adoption/zero-output/registry/source/support-first checks PASS. Existing legal move(true) adoption and real support exception replayed. Native move(false)18/0 with2ctor=2dtor/live0. Support retry61/0,243/243/live0 and10future steps. I1 original frozen verdict unchanged.

## 23. 1000 invalid-birth stress

FRESH PASS: 12083/0,1000 actual invalid births,1009constructors=1009destructors/live0; per-cycle registry/canonical/allocator/lifetime baseline restored.

## 24. R2B replay

FRESH PASS 252194/0,21000all-gas cells, local whole-fieldCp=0/kappa=0; real cloud motion executed. Pure-liquid rejection before gas queries preserved. No support-first framework edits.

## 25. Native physical equivalence

FRESH existing I1 valid-domain local/reference programs3728/0 each;328 transaction canonical files byte-identical. This is a replay of frozen valid-domain tests, not remaining R2C-R1 development. R2B covers native gas-property/species samples including Cp/mu/kappa. Actual positive ORourke event additionally compared against native kernel with matching RNG/state. Native raw padding excluded from physical equality.

## 26. Compiler/ABI scope

Actual GCC11.4, C++11, DPInt32, x86-64 current serial ABI, Foundation7. Previous Intel2021 assumption explicitly not merged; Intel/cross-compiler/ABI/MPI certification absent.

## 27. Restart limitation

Production DPM restart NOT CERTIFIED. No new restart version, serializer or MPI migration format. Serial parcel transport/field restoration/continuation only; transactionState-v1 stays separate authority.

## 28. Foundation hashes

FRESH6717 installed source/Make entries and19native parcel files PASS unchanged; ORourke unchanged. OSstream/particle/injection/tracking/collision provenance copies retained. I1/R2B240 frozen, R2B30, C1 family/report113 and145protected project files unchanged.

## 29. Active solver impact

NONE. Active equations, EOS/recovery/KT/source adapter/cloud integration unchanged. Production mesh/BC unchanged. Five independent C2 test targets compiled; no blockMesh/checkMesh/CFD solver execution. Changes only passive targets, evidence/tool scripts and new/append-only documentation.

## 30. Whether C2 COMPLETE

YES for selected semantic contract and tested passive serial environment. Raw canonical byte determinism and production restart remain outside this certificate.

## 31. Whether R2C-R1 may resume

YES, NEXT ROUND ONLY. Resume using externally instrumented C2 parcel family; frozen I1 layout-polluted binary is retained as historical reference and is not silently certified. Remaining trace/mixed/rebound-invalid/KH-invalid/ORourke branch/lifecycle/capability gates stay unclosed. R2-FINAL/T4/M6B/CFD still NO.

## 32. Updated milestone matrix

| Milestone | Status |
|---|---|
| R2B | COMPLETE / FROZEN |
| R2C-I1 | COMPLETE / FROZEN / original passive ownership scope |
| R2C-C1 | historical PARTIAL / NONDETERMINISTIC_BINARY_BLOCKER |
| R2C-C2 | COMPLETE / serial native-compatible semantic contract |
| R2C-R1 | PARTIAL / next-round resume permitted |
| R2C | PARTIAL |
| R2-FINAL | NOT AUTHORIZED |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NO |
| CFD | NO |


## Failed fixture attempts retained

- evolved_v1 and stochastic_diagnostic_v2 reached the frozen50000-query harness work budget. A direct dispersion-only action advanced transaction time without updating injector history; reducing the next carrier deltaT produced late newborns with negative stepFraction. Native InjectionModel source/diagnostic evidence identified this harness orchestration error. Corrected C2 triggering through native whole-cloud evolve; budget never raised and physical formulas unchanged.
- evolved_v3 successfully completed seven cases then stopped because the sparse unit-cell ORourke pair did not collide. That assertion was misleadingly named PARCEL_CODEC_BLOCKER:NO_ACTUAL_OROURKE; it is an untriggered fixture, not authoritative field loss. Its raw failure record is retained; final controlled fixture asserts actual merge and native equality.
- collision_rebound_v4 validated two selected cases. Its early JSON literal cases=9 was a harness reporting error; it is not used as a full matrix PASS. Final source counts completed cases dynamically; final_matrix_v5 reports10 and contains all10 rows.
- No real field-restoration failure, continuation divergence, weakened ownership or unexpected native/local layout difference was observed. COMPLETE is based exclusively on final successful matrix and fresh required regressions. C1 historical strict failure remains unchanged.

## Added target/evidence paths

Tests: fiveEqDPMParcelC2 (external hook family/I1 reproducer); fiveEqDPMParcelCodecC2 (semanticBinary.H, testParcelCodec.C); fiveEqDPMInjectionC2Gate/Retry/Core (unchanged frozen programs with C2 includes/registration). Evidence: fitting/dpm/m8a3b_t3br2c_c2_v1. All native-compatible binary expressions retained; no production format added. Stop after report/hash/checkpoint closure; no same-round R2C-R1 resume.
