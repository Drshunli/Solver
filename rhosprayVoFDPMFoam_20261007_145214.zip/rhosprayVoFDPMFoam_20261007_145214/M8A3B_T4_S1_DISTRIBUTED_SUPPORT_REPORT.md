# M8A.3B-T4-S1 — Distributed carrier-support backend gate

2026-10-04. **COMPLETE within the isolated two-rank fixed-mesh support scope. T4 remains PARTIAL.**

## Architecture and mathematical basis

Project-local `tests/fiveEqDPMDistributedSupportS1/DistributedSparsePointSupport.H` coexists with the frozen serial backend. No serial MPI guard was removed. Logical keys are `(owningRank, entityKind, localEntity, physicalPatch)` in a fixed decomposition; kind 0 means cell and kind 1 means an independently prescribed physical boundary-face authority. Coupled processor faces are **not** treated as local physical boundary authorities. The processor interface relates rank0 and rank1 through the actual processor patches in the copied eight-cell mesh (four cells per rank). No pointer or registry address participates in key identity.

The collective discovery publishes the rank/entity catalog, then applies one unit vector component per logical authority to the actual OF7 `volPointInterpolation`. Its three responses give the complete 3x3 tensor at each local point, including native coupled point synchronisation and physical patch constraints. Nonzero responses define membership. Query weights are `I*wCell` plus the three native point coefficients multiplied by actual `cellPointWeight` barycentric weights. No weights are dropped, renormalized or replaced by equal weights. Mandatory own-cell scalar support is retained even at zero centre velocity weight.

Independent weight oracle evaluates each global impulse directly through native `interpolationCellPoint<vector>::interpolate` at non-centre synthetic poses. This follows the native query path rather than the backend point-tensor summation. Both ranks have real nonzero remote contributions; membership and all nine tensor components are exact, maximum error zero. `topology.csv` records local cell/position and contributor rank/kind/local entity/physical patch and diagonal weights (the fixture has zero off-diagonal components). The processor patches and mesh geometry remain archived in the test fixture. Native coupled formulas/transfer are unchanged.

`DistributedCarrierSupport.H` provides explicit collective `prepare`, support-only `publish`, communication-free `preflight/materialize/query`, and move/rebound/generation invalidation. This is carrier-support publication, **not** global parcel transaction prepare/commit. Publication exchanges only signed P2 payload, ten conservative components and generation; it does not exchange Cp/mu/kappa or construct whole-field gas properties. Each side's physical-face states are generated independently from the fixture primitive at that face centre, not copied from local cell owners and not used as a processor fallback.

P2 payload retains signed minority representation, including trace gas and signed zero. Gas absence and mG/P2 inconsistency are tested from authoritative state, not from `1-alphaL`. Queries first check current-rank pose, view generation, each contributor generation, phase/mass metadata and finite conservative prerequisites. Only after the entire actual set passes do they invoke frozen P2 recovery on actual contributors and read scalar own-cell properties; common U uses all validated distributed conservative momenta. No fake gas, masking or fallback is used. The support certificate here covers the generated legal P2/EOS fixture states: arbitrary corrupt EOS-domain states have no new global certificate; frozen recovery remains authoritative and may throw before packet properties are recorded. Full thermodynamic-domain publication certification and parcel transaction failure propagation are not silently claimed by S1.

Publication order: collective raw-input readiness -> gather/scatter raw state -> explicit collective generation readiness -> immutable copied committed view -> local pose/stencil construction -> local preflight -> local recovery/property access. Prepared/discarded candidates cannot change committed authority. A rank-local malformed state-list negative test causes controlled support-publication rejection on both ranks before exchange. Query failure has no implicit communication, so rank0 failure cannot strand rank1 in a query collective. These support-only collectives must remain outside future native parcel-transfer collectives; their integration is not certified this round.

## Required 36-item report

| # | Item | Result |
|---|---|---|
| 1 | T4-S1 status | COMPLETE, isolated two-rank fixed-mesh scope |
| 2 | Original blocker reproduction | PASS, unchanged serial constructor rejects both MPI ranks |
| 3 | Backend architecture | Project-local distributed catalog + native impulse stencil + immutable raw-state view |
| 4 | Serial separation | Serial source unchanged; one-rank reference uses original CarrierQueryOwner |
| 5 | Contributor identity | Explicit rank/kind/local entity/patch tuple, stable across fresh reconstruction |
| 6 | Processor topology | PASS, one real processor patch per rank; both query poses include remote contributors |
| 7 | Coupled weights | PASS, exact membership and nine-component native impulse oracle equality |
| 8 | Remote state | Signed P2 + conservative q[0..9] + generation; no whole-field gas properties |
| 9 | Generation protocol | Explicit completed exchange then support-view publication; prepared discard unchanged |
| 10 | All gas | PASS; rho,p,T,Cp,mu,kappa,Y bit exact vs frozen one-rank reference |
| 11 | Mixed0.1 | PASS |
| 12 | Mixed0.5 | PASS |
| 13 | Mixed0.9 | PASS |
| 14 | Trace alphaG=1e-20 | PASS; signed payload and positive mG preserved, query valid |
| 15 | Remote exact gas absent | PASS; rank0 real remote rank1 absence rejects, rank1 current absence also controlled |
| 16 | Support-first | PASS in generated legal fixture domain; all contributor prerequisites before recovery/property access |
| 17 | Property-call counters | Gas-absent/stale rejection increments zero, including recovery; 8064 valid thermo calls per rank |
| 18 | Stale generation | PASS; requested N+1 cannot read committed N |
| 19 | Mixed generation | PASS; injected rank1 N with view N+1 rejects before dependent calls |
| 20 | Destination pose rebuild | PASS; current mesh builds cellPointWeight, no source cache; rebuilt logical keys/weights exact |
| 21 | Invalidation | PASS move/rebound/generation/session and position/cell/face/owner context guards |
| 22 | Communication order | Explicit preparation/publication phases; query performs no communication |
| 23 | 1000-cycle stress | PASS on each rank; 1000 valid, 1000 invalid, 1000 stale paths plus discard/invalidation checks |
| 24 | Deadlock | No hang or mismatched communication observed in completed two-rank stress |
| 25 | Native/serial equivalence | Tensor weights exact; scalar/Y exact; U max error 7.105427357601002e-15 m/s within gamma32 rounding bound |
| 26 | Serial regression | Fresh eight-query one-rank frozen-backend reference PASS; historical large suites preserved, not rerun |
| 27 | Foundation hashes | Fresh6717 installed source +19 native parcel entries PASS |
| 28 | Project hashes | 2422 frozen source/evidence entries unchanged before authorized milestone append |
| 29 | Active solver impact | NONE |
| 30 | Production mesh/BC impact | NONE; only copied passive fixture used |
| 31 | S1 COMPLETE? | YES, within stated passive two-rank fixed-decomposition fixture scope |
| 32 | S2 next round? | MAY START NEXT ROUND ONLY; NOT EXECUTED |
| 33 | T4 overall | PARTIAL; no actual parcel crossing/global parcel transaction certification |
| 34 | M8A | PARTIAL |
| 35 | M6B/CFD permissions | NO; no active integration, production restart or CFD |
| 36 | Milestone matrix | See below |

## Evidence and limitations

Topology final: 3364 checks /0 failures. Support final: 20051 checks /0 failures. Total explicit assertions 23415 /0 failures; all-gas offline equality checks are additionally recorded in `equivalence.json`. Each rank completes 1000 stress cycles, 1000 controlled absent and stale cycles; generation 2006 after the final pose-reconstruction checks. No raw parcel binary or new serializer is involved.

Initial test poses accidentally pointed rank1 away from the interface, so its remote-pose assertion failed (weight error remained zero). Those logs/results are retained in `attempt1`; the original fixture/results are not reused as passing evidence. Corrected symmetric near-interface poses pass in `fixture_retry`; final support publication/invalidation/serial comparison results are in `fixture_final`. Process exit zero is not treated as authority: final audit explicitly reads every local/global failure count. Prior commentary that called the first topology test passed was corrected when aggregate evidence showed this fixture coverage failure.

U tensor-sum evaluation and native point-then-tet evaluation have different floating addition orders. The standard `gamma_n=n*u/(1-n*u)` absolute forward-error bound uses n=32, u=epsilon/2 and maximum positive fixture component magnitudes 65/4/3 m/s. The field is linear, each tet uses four coefficients and each wall point at most four physical-face contributions. Actual U0 error is one double ULP (7.11e-15); U2 error is 4.44e-16; U1 exact. Bound and actual error are recorded per component; scalar/Y comparisons allow **zero** error. No engineering tolerance is substituted for this floating evaluation bound.

The discovery algorithm performs global impulse probes and exchanges the tiny fixture authority catalog. It is intentionally a passive reference backend, not a scalable production communication plan. Scope is fixed mesh, two ranks, direct processor coupling with independently prescribed physical patch authority. Other coupled patch types are explicitly unsupported. Fixed rank/local entity keys do not claim invariance under repartitioning/AMR/restart. Production boundary models, pathological raw EOS inputs, arbitrary meshes and concurrent native parcel-transfer ordering require later gates. No serial fallback is used at processor boundaries.

## Modified files / build

Added only `tests/fiveEqDPMDistributedSupportS1/DistributedSparsePointSupport.H`, `DistributedCarrierSupport.H`, `testTopology.C`, `testSupport.C`, isolated Make configuration, copied fixtures, audit/run tools and report/status evidence. Original solver/library/serial sources remain hash-identical. Build dependencies reuse the frozen standalone support/precision harness libraries; no active Make change. Foundation OF7 wmake PASS for topology and full support test. Each implemented block was compiled and tested before the next block. New files and evidence are checkpointed together after aggregate success.

## Milestone matrix / stop

| Milestone | Status |
|---|---|
| R2-FINAL/T3A/T3B/T3 | COMPLETE/FROZEN, existing serial scope and native ORourke limitations |
| C2 / KH / serial support contracts | FROZEN, unchanged |
| T4-S1 | COMPLETE within isolated two-rank support gate |
| T4-S2 | NOT STARTED; NEXT ROUND ONLY |
| T4 / M8A | PARTIAL |
| M6B.0/M6B.1 | NO |
| Production restart / AMR | NOT CERTIFIED |
| Active integration / CFD | NOT EXECUTED |

Next: separately authorized S2 real native processor-crossing migration, identity/fields/ownership/destination support and then global transaction/source/output/RNG/native-model gates. Four-rank extension and complete T4 certification remain future work. **STOP; no S2 this round.**
