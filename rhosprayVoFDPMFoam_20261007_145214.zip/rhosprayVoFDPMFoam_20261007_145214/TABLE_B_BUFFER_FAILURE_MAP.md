# TABLE-B BUFFER failure attribution

Frozen coefficients only; no fitting occurred before this attribution.
Primary categories are exclusive; G/H diagnostic tags can overlap. Linear root estimates outside HARD are audit-only, not runtime states.

| Category | Meaning | Count |
|---|---|---:|
| A | T-lower-bound bracket failure | 39 |
| B | T-upper-bound bracket failure | 27 |
| C | p-lower-bound failure | 29 |
| D | p-upper-bound failure | 0 |
| E | corner-state failure | 4 |
| F | interior root failure | 0 |
| G | validity-classification disagreement | 0 |
| H | root exists but solver failed | 0 |
| I | potential/property evaluation failed | 0 |
| J | acceptance-error threshold failure | 0 |

## Locations

| Row | p Pa | T K | Stage | Category | rho model-reference |
|---|---:|---:|---|---|---:|
| buffer_states_00413 | 50000 | 285 | pressure | E | 5.16559e-09 |
| buffer_states_00414 | 50000 | 286.166667 | pressure | C | 5.68195e-09 |
| buffer_states_00415 | 50000 | 287.333333 | pressure | C | 5.80087e-09 |
| buffer_states_00416 | 50000 | 288.5 | pressure | C | 5.75915e-09 |
| buffer_states_00417 | 50000 | 289.666667 | pressure | C | 5.68139e-09 |
| buffer_states_00418 | 50000 | 290.833333 | pressure | C | 5.62227e-09 |
| buffer_states_00419 | 50000 | 292 | pressure | C | 5.59567e-09 |
| buffer_states_00420 | 50000 | 293.166667 | pressure | C | 5.5951e-09 |
| buffer_states_00421 | 50000 | 294.333333 | pressure | C | 5.60624e-09 |
| buffer_states_00422 | 50000 | 295.5 | pressure | C | 5.61704e-09 |
| buffer_states_00423 | 50000 | 296.666667 | pressure | C | 5.61795e-09 |
| buffer_states_00424 | 50000 | 297.833333 | pressure | C | 5.60647e-09 |
| buffer_states_00425 | 50000 | 299 | pressure | C | 5.58407e-09 |
| buffer_states_00426 | 50000 | 300.166667 | pressure | C | 5.55463e-09 |
| buffer_states_00427 | 50000 | 301.333333 | pressure | C | 5.52359e-09 |
| buffer_states_00428 | 50000 | 302.5 | pressure | C | 5.49403e-09 |
| buffer_states_00429 | 50000 | 303.666667 | pressure | C | 5.46811e-09 |
| buffer_states_00430 | 50000 | 304.833333 | pressure | C | 5.44526e-09 |
| buffer_states_00431 | 50000 | 306 | pressure | C | 5.42173e-09 |
| buffer_states_00432 | 50000 | 307.166667 | pressure | C | 5.39467e-09 |
| buffer_states_00433 | 50000 | 308.333333 | pressure | C | 5.36181e-09 |
| buffer_states_00434 | 50000 | 309.5 | pressure | C | 5.32293e-09 |
| buffer_states_00435 | 50000 | 310.666667 | pressure | C | 5.28371e-09 |
| buffer_states_00436 | 50000 | 311.833333 | pressure | C | 5.25483e-09 |
| buffer_states_00437 | 50000 | 313 | pressure | C | 5.24915e-09 |
| buffer_states_00438 | 50000 | 314.166667 | pressure | C | 5.27984e-09 |
| buffer_states_00439 | 50000 | 315.333333 | pressure | C | 5.35124e-09 |
| buffer_states_00440 | 50000 | 316.5 | pressure | C | 5.44583e-09 |
| buffer_states_00441 | 50000 | 317.666667 | pressure | C | 5.50699e-09 |
| buffer_states_00442 | 50000 | 318.833333 | pressure | C | 5.41013e-09 |
| buffer_states_00443 | 50000 | 320 | pressure | E | 4.9298e-09 |
| buffer_states_00444 | 348750 | 285 | pressure | A | 5.58987e-09 |
| buffer_states_00466 | 647500 | 285 | pressure | A | 5.83418e-09 |
| buffer_states_00487 | 647500 | 320 | temperature | B | 5.25813e-09 |
| buffer_states_00488 | 946250 | 285 | pressure | A | 5.9415e-09 |
| buffer_states_00509 | 946250 | 320 | temperature | B | 5.58407e-09 |
| buffer_states_00510 | 1245000 | 285 | pressure | A | 5.95435e-09 |
| buffer_states_00531 | 1245000 | 320 | temperature | B | 5.78268e-09 |
| buffer_states_00532 | 1543750 | 285 | pressure | A | 5.9116e-09 |
| buffer_states_00553 | 1543750 | 320 | temperature | B | 5.81531e-09 |
| buffer_states_00554 | 1842500 | 285 | pressure | A | 5.84407e-09 |
| buffer_states_00575 | 1842500 | 320 | temperature | B | 5.70185e-09 |
| buffer_states_00576 | 2141250 | 285 | pressure | A | 5.76131e-09 |
| buffer_states_00597 | 2141250 | 320 | temperature | B | 5.45106e-09 |
| buffer_states_00598 | 2440000 | 285 | pressure | A | 5.70674e-09 |
| buffer_states_00619 | 2440000 | 320 | temperature | B | 5.19299e-09 |
| buffer_states_00620 | 2738750 | 285 | pressure | A | 5.67707e-09 |
| buffer_states_00642 | 3037500 | 285 | pressure | A | 5.67559e-09 |
| buffer_states_00664 | 3336250 | 285 | pressure | A | 5.70026e-09 |
| buffer_states_00686 | 3635000 | 285 | pressure | A | 5.74471e-09 |
| buffer_states_00708 | 3933750 | 285 | pressure | A | 5.8011e-09 |
| buffer_states_00730 | 4232500 | 285 | pressure | A | 5.85965e-09 |
| buffer_states_00752 | 4531250 | 285 | pressure | A | 5.91126e-09 |
| buffer_states_00774 | 4830000 | 285 | pressure | A | 5.94798e-09 |
| buffer_states_00795 | 4830000 | 320 | temperature | B | 5.13933e-09 |
| buffer_states_00796 | 5128750 | 285 | pressure | A | 5.96413e-09 |
| buffer_states_00817 | 5128750 | 320 | temperature | B | 5.24722e-09 |
| buffer_states_00818 | 5427500 | 285 | pressure | A | 5.95639e-09 |
| buffer_states_00839 | 5427500 | 320 | temperature | B | 5.2878e-09 |
| buffer_states_00840 | 5726250 | 285 | pressure | A | 5.92388e-09 |
| buffer_states_00861 | 5726250 | 320 | temperature | B | 6.66296e-09 |
| buffer_states_00862 | 6025000 | 285 | pressure | A | 5.86874e-09 |
| buffer_states_00883 | 6025000 | 320 | temperature | B | 6.51482e-09 |
| buffer_states_00884 | 6323750 | 285 | pressure | A | 5.79519e-09 |
| buffer_states_00905 | 6323750 | 320 | temperature | B | 6.26426e-09 |
| buffer_states_00906 | 6622500 | 285 | pressure | A | 5.71004e-09 |
| buffer_states_00927 | 6622500 | 320 | temperature | B | 5.92013e-09 |
| buffer_states_00928 | 6921250 | 285 | pressure | A | 5.61954e-09 |
| buffer_states_00949 | 6921250 | 320 | temperature | B | 5.63034e-09 |
| buffer_states_00950 | 7220000 | 285 | pressure | A | 5.53155e-09 |
| buffer_states_00971 | 7220000 | 320 | temperature | B | 5.45458e-09 |
| buffer_states_00972 | 7518750 | 285 | pressure | A | 5.45162e-09 |
| buffer_states_00993 | 7518750 | 320 | temperature | B | 5.2936e-09 |
| buffer_states_00994 | 7817500 | 285 | pressure | A | 5.38444e-09 |
| buffer_states_01015 | 7817500 | 320 | temperature | B | 5.1748e-09 |
| buffer_states_01016 | 8116250 | 285 | pressure | A | 5.33134e-09 |
| buffer_states_01047 | 8415000 | 285 | pressure | A | 5.28883e-09 |
| buffer_states_01078 | 8713750 | 285 | pressure | A | 6.67433e-09 |
| buffer_states_01108 | 8713750 | 320 | temperature | B | 5.22698e-09 |
| buffer_states_01109 | 9012500 | 285 | pressure | A | 6.63101e-09 |
| buffer_states_01139 | 9012500 | 320 | temperature | B | 5.37295e-09 |
| buffer_states_01140 | 9311250 | 285 | pressure | A | 6.56837e-09 |
| buffer_states_01170 | 9311250 | 320 | temperature | B | 5.5436e-09 |
| buffer_states_01171 | 9610000 | 285 | pressure | A | 6.47015e-09 |
| buffer_states_01201 | 9610000 | 320 | temperature | B | 5.69605e-09 |
| buffer_states_01202 | 9908750 | 285 | pressure | A | 6.3219e-09 |
| buffer_states_01232 | 9908750 | 320 | temperature | B | 5.78257e-09 |
| buffer_states_01233 | 10207500 | 285 | pressure | A | 6.243e-09 |
| buffer_states_01263 | 10207500 | 320 | temperature | B | 5.75994e-09 |
| buffer_states_01264 | 10506250 | 285 | pressure | A | 6.1799e-09 |
| buffer_states_01294 | 10506250 | 320 | temperature | B | 5.60487e-09 |
| buffer_states_01295 | 10805000 | 285 | pressure | A | 6.08827e-09 |
| buffer_states_01325 | 10805000 | 320 | temperature | B | 5.33714e-09 |
| buffer_states_01326 | 11103750 | 285 | pressure | A | 6.00585e-09 |
| buffer_states_01357 | 11402500 | 285 | pressure | A | 6.00164e-09 |
| buffer_states_01388 | 11701250 | 285 | pressure | A | 6.18968e-09 |
| buffer_states_01418 | 11701250 | 320 | temperature | B | 5.33271e-09 |
| buffer_states_01419 | 12000000 | 285 | pressure | E | 6.74208e-09 |
| buffer_states_01449 | 12000000 | 320 | temperature | E | 6.81598e-09 |
