# Five-equation admissibility and vanishing-phase policy

Design only. Do not modify active fields or inherit MFC's clamp/floor semantics.

| Check | Acceptance / failure meaning |
|---|---|
| alpha | finite 0<=alphaL<=1, alphaG derived; no independent sum drift |
| partial mass | finite mG,mL>=0; negative mass is a conservative-state failure |
| total density | finite rho=mG+mL>0; zero total density is invalid |
| internal energy | finite, EOS-admissible after kinetic subtraction; absolute e need not be positive |
| pressure recovery | valid branch/bracket and root; root failure is not alpha clipping |
| EOS domain | correct phase and declared support, NORMAL/BUFFER/INVALID |
| acoustics | finite positive phase and selected mixture c^2, valid caloric derivatives |

Native reference energy may be negative. "Internal-energy positivity" must
mean EOS thermal admissibility (e.g. T>0 and correct energy reference), not
Et-|M|^2/(2rho)>0 on an arbitrary absolute zero. Pressure positivity applies
to this project's positive absolute-pressure support domain; no generic claim
for tensile/cavitation states is made.

## Presence classifier before every division

alphaMin is dimensionless; massMin uses partial-density units kg/m3 and a
declared scaling, not parcel mass units. Numeric values are not set here.
`phasePresentGas/Liquid` require coherent volume and partial mass evidence.
Pure gas requires alphaL<=alphaMin AND mL<=massMin; pure liquid uses the gas
counterpart. Significant mass with vanishing volume, significant volume with
vanishing mass, both phases absent, negative alpha/mass, or nonfinite input
produces explicit failure rather than enormous intrinsic density or guessed EOS.

Exact zero absent mass/volume is safe to skip. Threshold residuals are NOT
automatically discarded. M6A2 must define a conservative residual treatment
or a diagnosed controlled failure before accepting near-pure states; it must
preserve sum masses/Et and account for any real material correction. A branch
label alone does not prove conservation. Present-phase states still obey their
EOS validity; no calls for missing phases and no made-up missing c/rho/beta.

## Limiting and correction

Prefer reconstruction limiting toward an admissible conservative cell state,
with all reconstructed components and alpha assessed together; a diagnosed
first-order fallback is permitted only if that complete state is valid.
Independent alpha clipping with unchanged mG,mL,Et is prohibited. After a
bad cell update, bounded step retry is permitted only with full transactional
state/cloud/source/RNG rollback; otherwise controlled failure. No post-hoc
partial mass/Et clipping is allowed without an explicit conservation ledger
and an accepted correction algorithm. No acoustic floor hides an invalid EOS.
MFC mpp_lim/mixture_err inspire what to check, not how to modify the state.

## Required failure reporting

Report cell/face/root origin, mesh identity/rank, state, presence flags,
kinetic/internal energies, energy-reference tag, failed validity and attempted
fallback. EOS out-of-domain and PURE_PHASE_STATE_RECOVERY failures remain
distinct. In future tests require conservation diagnostics whenever correction
touches mG,mL or Et, including distributed and DPM bookkeeping.
