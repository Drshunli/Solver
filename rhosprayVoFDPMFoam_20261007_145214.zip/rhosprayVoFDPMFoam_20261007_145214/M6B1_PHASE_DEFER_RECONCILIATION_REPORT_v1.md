# M6B.1-PHASE-DEFER 政策与当前状态核对

日期：2026-10-05（北京时间）。本轮性质：POLICY / SCOPE ONLY。

读取用户本轮附件、开发日志、既有 policy/gate、里程碑最新追加记录后，确认附件描述的是 active v2 / shadow v3 的历史阶段。现有项目已经执行后续 EOS3 安装并封存为 PARTIAL / STOP。本轮保留当前 active v3，不回滚到 v2，不重写历史 gate，不重新运行 EOS3。附件中的下一轮范围不视为本轮执行授权。

## 1. PHASE-DEFER status

既有 **COMPLETE / POLICY FROZEN** 决定继续适用；机器证据为 `fitting/integration/m6b1_eos3_numerical_v1/PHASE_DEFER_POLICY.json` 的 FROZEN。本轮完成政策及阶段核对；不是重新关闭一个 active-v2 阶段。本轮不声称所有历史前提在当前项目重新满足，尤其 active v2 已被后续授权安装的 v3 取代。

## 2. Owner scope decision

固液相认证采用 **DEFERRED / NOT CERTIFIED / NOT CLOSED**。它不再作为数值单液相求解器开发的硬前提；此决定不消除数值 EOS 合法域拒绝，也不授权直接进入生产 CFD。当前注入目标 TL≈300 K，不要求先认证每个压力下 275 K 都是稳定液体。

## 3. Preserved CLASS D result

LB2B/LB2C 历史 **CLASS D / PHYSICAL EVIDENCE UNRESOLVED** 原样保留。延期不是 PASS，不改为 CLASS A。LB2 Part A 的表示合同 COMPLETE / FROZEN 保留。

## 4. HARD-domain new semantics

HARD 永久指 **numerical EOS admissibility domain**，与实验认证的相稳定区分开。当前 active v3 的 HARD 为 p=0.05–12 MPa、T=275–330 K；该矩形不代表已经认证整个区间都是稳定液体，也不保证任意 PDE 候选 Q 存在合法公共压力能量根。旧文档中的 v1/v2 域须按历史阶段阅读，本报告不回写历史材料。

## 5. Numerical continuation scope

只允许 **NUMERICALLY QUALIFIED SINGLE-LIQUID-BRANCH CONTINUATION** 的适用性声明。同一冻结 potential、81 系数、C_L=369229.9537234281 J/kg、同一压力域继续保留。既有 lower 9801、old 3721、upper 3721 点属性资格，130/130 frozen R1、old184、accepted6200、representation contract PASS 作为既有证据保留，本轮没有重新执行这些回归。十个 M6B.0 微算例通过也不能替代 EOS3 动力学完成判据。

## 6. Physical certification scope

不存在定量固液相边界证书；不得声明全 275–330 K 稳定液体认证。不加入 solid、melting、freezing、phase equilibrium、latent heat 或固液转变模型。LB2B/LB2C 证据包保留 DEFERRED / NOT CLOSED；未来获得可追溯定量曲线可单独重启认证。

## 7. Low-temperature limitation

TL<285 K 解释为 **EOS numerical continuation outside certified solid-liquid phase scope**；不得因该温度自动拒绝状态、删液、冻结、转相或重置到 285 K。既有合法域及公共根判据仍有效，延期不允许域外外推。既有 shock 最低 TL=278.59992814822976 K 仅为数值延拓记录。

## 8. Trace-state policy

P2 保持 phase present 合同，无 alpha 阈值删相或 ABSENT 转换。历史 lower blocker 的 alphaL≈1e-15 与新 upper blocker 的 alphaL≈1.8383391125689919e-21 均不能通过删相绕过恢复。允许合法域内 EOS 分支求值，不宣称 trace state 的相稳定性经实验认证。

## 9. 5% future evidence policy

未来相边界认证仍采用 ≤5% 的 melting-boundary evidence uncertainty allowance，并遵守既有保守上界规则。仅适用于 Tmelt 证据，不传播到 EOS fitting、R1、conservation、species、P2 或 timestep。

## 10. Production monitoring rule

真正 production CFD 阶段必须记录 minimum TL、TL<285 K 对应的 liquid volume fraction 及 represented liquid mass，并说明空间/时间统计与质量积分定义。若出现 non-trace / dynamically significant 的低温液体，重新开启 SOLID-LIQUID PHYSICAL VALIDITY GATE；只要求 report and reassess，不预设任意 alpha 阈值删相。现有只读低温诊断不改变解或时间步，也不代表生产监测资格已闭合。

## 11. v3 revised qualification label

政策层面的 v3 候选标签为 **NUMERICALLY DESIGN QUALIFIED FOR SINGLE-LIQUID CONTINUATION / NOT PHASE CERTIFIED**。当前安装状态采用既有 gate 的更具体标签：**INSTALLED / PROPERTY-REGRESSION QUALIFIED / SINGLE-LIQUID CONTINUATION / NOT PHASE CERTIFIED**。这不是 full physical DESIGN QUALIFIED，也不是 EOS3 shock 完成。

## 12. Source changes

本轮求解器、EOS、R1、P2、temporal driver 源码修改：**0**。没有编译 active solver，没有运行 shock 或 CFD。仅新增本报告以及独立核对目录 `fitting/integration/m6b1_phase_defer_reconciliation_v1/` 中的审计脚本、清单及结果；没有修改已有日志、里程碑、EOS3 证据或封存包。

## 13. Foundation/project hashes

本轮新做的核对：已编译源码清单及 v1/v2 历史版本共 67 项逐文件 SHA PASS；既有 EOS3 证据、开发日志和里程碑共 1320 文件保留清单，交付前复核。范围不是全项目 37020 项重新核验。完整逐文件值见新目录的 `audit_result.json` 和 `preserved_files_before.json`。

| 产物 | SHA-256 |
|---|---|
| 三版 coefficients.json（相同） | `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac` |
| EOS3 封存 ZIP（本轮重新核验 PASS） | `67933d6c153845d54ca9120eeba72d0c7b756ad8470d75d9c9dbe8d5de503137` |
| compiled_project_source_manifest.json | `1af9422d786414990cdeb67fe0e12f3e6680cec3bda14518c19fa48fada33952` |
| Foundation 原生源码基线 SHA 清单文件 | `53068eb81a5219763619fc3e3e8027e4c32519525b29241076bb9f6ec342865a` |
| 既有 foundation_gate.json | `185c434a8cccf45f842b34e2c804b1104facdaf91f1675230ce40fcddbfa429c` |

Foundation 上一轮 6717 原源码＋19 native parcel 文件 PASS 是历史证据。本轮 WSL 枚举及路径访问被环境拒绝，未重新核验 Linux Foundation 文件或运行时库；上表后两项是证据文件自身哈希，不能称为本轮 Foundation 全量 PASS。本轮未执行任何 Foundation 写入。

## 14. Whether EOS3-NUMERICAL may start

历史 PHASE-DEFER 的 scope decision 已允许下一轮单独授权 EOS3-NUMERICAL；后续日志证明它已经执行。**当前不能重新标记 NEXT ROUND ONLY，也不能标记 COMPLETE。** 当前状态为 PARTIAL / EOS3_NEW_DOMAIN_BLOCKER / STOP。本轮到此停止，不自动扩 v4、改变 EOS 域、执行 TD1 或重放 shock。

下一开发需求应围绕 anchor153/cell27 exact-Q、能量账本、330 K 上界参考与合法域分类单独明确。新失败的合法公共压力区间约 0.398112–3.117393 MPa；F(lo)≈−7.411003 MJ/m³，F(hi)≈−0.383776 MJ/m³，TL(hi)=330 K。合法区间未括住公共能量根，不能归类为 EOS 已闭合且仅剩时间策略问题。本轮仅保留该既有诊断，没有新增 root 求解。

## 15. EOS2 status

历史 **PARTIAL / NEW LOWER-HARD-DOMAIN BLOCKER / STOP** 保留。v2 文件本轮 SHA 核对 PASS，当前不 active；旧 lower blocker 被后续 v3 恢复消除，不追溯重写 EOS2 历史判定。

## 16. TD1 status

**REQUIRED / SEPARATE STAGE / NOT EXECUTED**。时间步继承及浮点时间停滞技术债仍存在，本轮未授权实施；不改变 connectedDt、retry、dt growth 或 Time。

## 17. M6B.1 status

**PARTIAL / STOP**。新公共根域失败未闭合，完整 shock、后续 wave ladder 等未认证。M6B.2、high-Mach、active DPM、global MPI transaction、production CFD 和 production restart 不获得新资格。

## 18. Milestone matrix

| 阶段 | 当前状态 |
|---|---|
| M6B.0 | COMPLETE / FROZEN，v3 限定微算例重跑证据保留 |
| SR1 | COMPLETE / DIAGNOSIS ONLY |
| EOS1 | COMPLETE / DESIGN QUALIFIED（历史范围） |
| EOS2 | PARTIAL / STOP（历史） |
| v2 | PRESERVED / NOT ACTIVE |
| LB2 Part A | COMPLETE / FROZEN |
| LB2B / LB2C | DEFERRED / PHYSICAL CERTIFICATE NOT CLOSED |
| historical physical class | CLASS D / PRESERVED |
| PHASE-DEFER | COMPLETE / POLICY FROZEN（既有决定继续适用） |
| v3 | ACTIVE / PROPERTY-REGRESSION QUALIFIED / SINGLE-LIQUID CONTINUATION / NOT PHASE CERTIFIED |
| EOS3-NUMERICAL | PARTIAL / EOS3_NEW_DOMAIN_BLOCKER / STOP |
| TD1 | REQUIRED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL |
| M6B.2 | NOT AUTHORIZED |
| production CFD / restart | NOT CERTIFIED |

本轮完成政策核对并 STOP；开发日志建议的下一步未在本轮执行。
