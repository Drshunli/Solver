# M6A1b-2A.3 EOS operating-envelope hardening

## 1. Status

**COMPLETE. Overall M6A1b-2A = COMPLETE under the user-authorized design-envelope definition.** Current physical scales are retained as screening, a distinct production envelope is selected, a tested project HARD envelope and failure contract are defined. Completeness does not claim prediction of CFD extrema, production EOS acceptance or resolved energy offsets. Stop before M6A1b-2B.

## 2. Locked reference and expected physical range

Gas U=2013.039 m/s, p=188330.307 Pa absolute, T=400 K, supplied rho=1.6338 kg/m3, approximate screening Mach=5.021. C10H22, Nh=1, d=0.3 mm, mdot=1.09609e-4 kg/s, TL_ref=300 K, pL_ref=3 MPa absolute. Reference HEOS rho=727.432960546 kg/m3, c=1244.718107 m/s, Cp=2196.745004 J/(kg K), Cv=1781.914274 J/(kg K), U_ref=2.1316743005 m/s remain unchanged. The selected boundary controls mdot and TL; pressure responds.

Expected/screening coordinates remain approximately **0.188330–6.201421 MPa, 299.440696–301.200448 K**. They include ambient, 3 MPa inlet, normal-shock/stagnation loading scales, reversible expansion/compression and a limiting dissipative release. They are not guaranteed solution bounds. The previous 0.180–6.250 MPa / 299–302 K proposal is superseded as an operating-domain definition, but remains historical evidence of those paths.

## 3–5. Candidate pressure/temperature comparison

Compare P1=0.10–8 MPa, P2=0.10–10 MPa, P3=0.05–12 MPa with T1=295–305 K, T2=290–310 K, T3=285–320 K. These were candidates until the offline checks completed. All nine combinations were evaluated using CoolProp 8.0.0 HEOS, with no forced phase and native DEF energy.

Before querying, `fitting/envelope_audit_config.json` fixed numerical gates: finite values; required positive thermodynamics and derivatives; identities <=1e-8 relative; finite-difference derivative agreement <=1e-4; neighboring change <=10%; normalized slope-change <=2%; p_min/psat(T_max)>=10; at least 100 K below Tc and 30 K above triple-point Tmin. Those are reference numerical/engineering gates, not experimental uncertainty or future production fit tolerances. Minimum production allowances from expected coordinates were 50 kPa below, 1 MPa above and 3 K on each temperature side. A design envelope, unlike a predicted physical extreme, is allowed to be selected with these declared support margins.

| Candidate | Audited PT states | Result | Closest p/psat | Illustrative fixed-resolution nodes |
|---|---:|---|---:|---:|
| P1 x T1 | 700 | PASS; selected production | 345.22 | 693 |
| P1 x T2 | 700 | PASS | 250.09 | 1353 |
| P1 x T3 | 728 | PASS | 136.21 | 2343 |
| P2 x T1 | 700 | PASS | 345.22 | 861 |
| P2 x T2 | 700 | PASS | 250.09 | 1681 |
| P2 x T3 | 728 | PASS | 136.21 | 2911 |
| P3 x T1 | 700 | PASS | 172.61 | 1029 |
| P3 x T2 | 700 | PASS | 125.05 | 2009 |
| P3 x T3 | 728 | PASS; selected project HARD | 68.11 | 3479 |

Each grid starts with 25 uniform pressure and 25 uniform temperature levels, then includes inlet/current screening anchors, resulting in 700 or 728 states. Total **6384 PT assessments** were stored with p,T, phase,rho,e,h,s,Cp,Cv,c, compressibility, expansion, bulk moduli and derivatives. These are **REFERENCE-EOS GENERATED ENVELOPE ASSESSMENT**, not a production training/calibration table. Exact per-candidate property ranges and provenance are in `fitting/M6A1b2A3_envelope_audit.json`; states are in `fitting/M6A1b2A3_envelope_assessment.csv`.

Cost comparison uses an illustrative common resolution of 0.25 MPa × 0.5 K, with endpoint inclusion and 18 doubles/node. It is not a prescribed final grid: P1T1 would require about 99,792 raw bytes; P3T3 about 500,976 bytes, excluding phase flags/indexes/refinement. Wider candidates increase model/table coverage cost without addressing a presently required trajectory. P1T1 is the smallest **tested** passing rectangle meeting the declared margins; no continuous global-minimum claim is made.

## 6. Phase and reference validity

All grid points return `liquid` or exact backend flag `supercritical_liquid`. The physical interpretation of the latter is **dense/compressed liquid with T<Tc and p>pc**, not a conventional supercritical-fluid state above both critical coordinates. No liquid-vapor MODEL-SCOPE CONFLICT or backend exception was found. Properties vary smoothly across the pressure-label transition near pc; the label transition below Tc is not a coexistence crossing.

At the HARD hottest/lowest-pressure corner, psat(320 K)=approximately 734.153 Pa and p-psat=49,265.847 Pa. HARD T_max is approximately 297.699 K below Tc=617.698845 K; T_min=285 K is 41.5 K above fluid triple-point Tmin=243.5 K. All states are far inside the formal Tmax=675 K and pmax=800 MPa. Saturation monotonicity and corner separation exclude vapor coexistence throughout each rectangle; dense spot checks support liquid-branch numerical stability.

These are backend liquid-vapor and derivative checks, not an experimental phase diagram or uncertainty certification. The fluid definition has no verified pressure-dependent solid/liquid melting line; that provenance limitation remains explicit. The tested moderate-pressure liquid domain is adopted for the project's intended fluid scope, not extended toward freezing or critical conditions. Independent rho/c/Cp validation remains an M6A1b-2B obligation.

## 7–8. Properties and derivative-quality gate

At every audited point rho,c²,Cp,Cv,kappaT,alphaP and the required pressure/energy derivatives are positive and finite. rho increases with p at fixed T. The identities c²=(dp/drho)|e+(p/rho²)*(dp/de)|rho, (de/dp)|rho*(dp/de)|rho=1, Cp-Cv=T*alphaP²/(rho*kappaT), and h-e=p/rho close within the declared tolerances.

Central finite differences at ten interior/reference states per candidate independently compare backend derivatives using fixed-density pressure probes and fixed-energy/fixed-density inverse queries. Across all candidates the largest relative derivative discrepancy is approximately **2.253e-9**, well below 1e-4. The largest neighboring relative property/derivative change is about **1.214%** and normalized neighboring slope-change about **1.593e-4**, below the predeclared 10%/2% screens. Exact maxima and sampling definitions are retained; these are resolution-dependent irregularity checks, not mathematical proof of global interpolation accuracy.

## 9. Selected PRODUCTION DESIGN ENVELOPE

**0.10–8.00 MPa, 295–305 K**, inclusive, absolute pressure. It includes the locked inlet and all current screening states, meets explicit design allowances and passes phase/property/derivative gates. Pressure headroom relative to expected scales is 88.330 kPa lower and 1.798579 MPa upper; temperature headroom is 4.440696 K lower and 3.799552 K upper. Selection defines supported normal operation/calibration scope; it does not claim that reconstruction or actual flow can never leave it.

## 10. Selected PROJECT HARD EOS VALIDITY

**0.05–12.00 MPa, 285–320 K**, inclusive. It is the largest passing rectangle in this audited candidate family, not the entire HEOS domain. Reference-backend support is audited; a future accepted production EOS must separately certify this region before BUFFER evaluation/runtime activation. A table covering only PRODUCTION cannot extrapolate into HARD. No production EOS family is selected here.

## 11–15. State classification, root and face policy

The full design contract is `EOS_OUT_OF_DOMAIN_POLICY.md`, with a machine-readable counterpart `fitting/liquid_eos_domain_contract.json`.

- NORMAL: valid state inside PRODUCTION, normal EOS evaluation.
- BUFFER: valid state outside PRODUCTION but inside HARD, controlled **same-EOS** evaluation with counters/warning, only after buffer certification.
- INVALID: outside HARD, wrong phase, nonfinite/nonpositive required thermodynamics, backend failure or unacceptable derivatives; explicit EOS state failure, no silent extrapolation/clipping.

Controlled fatal diagnostics are the safe default until a transactional timestep rollback including DPM is available. Pressure brackets must lie in a connected **joint gas/liquid admissible** interval inside HARD; recovered temperatures/phase validity also matter. No valid bracket/root means failure, not endpoint clamping. Cells and faces use the same EOS; explicit face buffer is HARD minus PRODUCTION. Invalid face reconstruction may later use a diagnosed conservative lower-order reconstruction if admissible, otherwise fail; independent primitive clipping is prohibited.

alpha->0/1 division/phase-presence handling is **PURE_PHASE_STATE_RECOVERY**, separate from EOS domain validity. Thresholds, absent-phase branches and conservative residual handling belong to M6A2. Enlarging the domain or extrapolating enormous rho to hide tiny-alpha recovery is prohibited.

## 16. Resulting reference state ranges

These are sampled marginal statistics, not an admissible Cartesian rho/e box or independently imposed runtime cutoffs. Exact PT recovery/classification remains authoritative. Values below retain native reference energy:

| Quantity | PRODUCTION assessment range | HARD assessment range |
|---|---|---|
| rho (kg/m3) | 721.203450–735.017381 | 709.486172–745.193482 |
| e (J/kg) | -382240.364094 to -356990.442234 | -405173.460341 to -323265.239030 |
| h (J/kg) | -378846.160978 to -349427.879219 | -400521.487872 to -312082.367297 |
| c (m/s) | 1206.207558–1294.901569 | 1147.899628–1356.660045 |
| Cp (J/kg K) | 2174.735231–2218.147947 | 2137.290314–2275.954166 |
| Cv (J/kg K) | 1760.982765–1804.004558 | 1722.547911–1865.484432 |
| kappaT (1/Pa) | 9.997634e-10–1.174339e-9 | 9.014415e-10–1.309043e-9 |
| alphaP (1/K) | 1.010305e-3–1.077437e-3 | 9.813749e-4–1.099056e-3 |
| Ks (Pa) | 1.049305e9–1.232455e9 | 9.348712e8–1.371548e9 |
| de/dp at fixed rho (m3/kg) | 1.746557e-3–1.961990e-3 | 1.587879e-3–2.215093e-3 |
| dp/drho at fixed e (m2/s2) | 1.454839e6–1.668292e6 | 1.317629e6–1.826917e6 |
| dp/de at fixed rho (kg/m3) | 509.686719–572.554946 | 451.448415–629.770859 |

## 17. Energy-reference status

Native DEF e/h are retained for differences/statistics. The gas/Eulerian-liquid/DPM canonical offset is **UNRESOLVED**, and no solver Et or q is initialized. Coordinate translation QA with a deliberately arbitrary test Delta=1e6 J/kg gives zero relative difference at the reference state after translating e back for EOS evaluation; no backend reference reset was made. This is a test offset, not a mapped physical zero. The algebra shows all required derivatives, c and PT phase/domain validity are invariant under an explicit constant translation.

## 18–19. Impact and final 2A gate

Active solver impact **NONE**. Offline assessment and 13 domain-policy boundary/failure checks pass. Protected solver/equation/Make files are unchanged by hashes. No production fitting, final table, runtime EOS, common-pressure solve, mG/mL/cMix/KT activation, surface-tension coupling, transfer or CFD run is performed.

M6A1b-2A.3 and overall M6A1b-2A are **COMPLETE as an engineering domain/policy design gate**. Stage 2A.2 remains historically partial because it attempted to infer physical extrema; this stage closes the explicitly revised task without relabeling those estimates as guarantees. Future model certification and numerical offset mapping remain separate gates.

## 20. Exact next M6A1b-2B task (not started)

Freeze the approved domains and native-reference/provenance contract; design and generate a **new versioned reference training/holdout dataset** in PRODUCTION with separate HARD/BUFFER validation coverage and phase flags/derivatives. Retain an independent measured rho/c/Cp validation ledger. Compare allowed production candidates (NASG, thermodynamically complete Mie-Gruneisen variants, or consistent reference-table approaches) by per-property/derivative/inversion errors and cost; do not revive rejected constant SG. Require all candidates to certify BUFFER or explicitly fail it before activation. Energy-offset alignment remains pre-M6A2; no model is selected here. Do not automatically treat this assessment CSV as the final training set.

## 21. Milestone matrix

M0–M4 COMPLETE; M5A/M5B COMPLETE active reference/design; M6A1a COMPLETE; M6A1b-1 MODEL GATE COMPLETE / SG REJECTED; M6A1b-2A.1 input gate passed; M6A1b-2A.2 historical provisional reference audit; M6A1b-2A.3 COMPLETE; overall M6A1b-2A COMPLETE; M6A1b-2B NEXT / NOT STARTED; M6A2 and two-phase activation NOT STARTED. Stop after this report.
