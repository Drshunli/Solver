# Field ownership versions

Current future numerical contract: [v2](FIVE_EQ_FIELD_OWNERSHIP_FINAL_v2.md).

Historical physical/bridge contract: [v1](FIVE_EQ_FIELD_OWNERSHIP_FINAL.md), retained byte-identical. Active runtime remains unchanged.
