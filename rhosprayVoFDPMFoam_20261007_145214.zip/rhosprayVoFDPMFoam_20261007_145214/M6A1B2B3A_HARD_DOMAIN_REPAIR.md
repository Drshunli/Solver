# M6A1b-2B.3A — HARD domain closure audit and repair

本轮结论：**PARTIAL / HARD REFERENCE COVERAGE NOT CLOSED**。没有生产 EOS 晋升；3B 未执行；M6A2 不允许启动。

## 1. M6A1b-2B.3A status

PARTIAL。完成归因、两种势函数约束重拟合、严格域分类/求根和离线复测，但完整 HARD 参考状态覆盖仍失败。

## 2. Old BUFFER failure classification

| Category | Meaning | Count |
|---|---|---:|
| A | T-lower-bound bracket failure | 39 |
| B | T-upper-bound bracket failure | 27 |
| C | p-lower-bound failure | 29 |
| D | p-upper-bound failure | 0 |
| E | corner-state failure | 4 |
| F | interior root failure | 0 |
| G | validity-classification disagreement | 0 |
| H | root exists but solver failed | 0 |
| I | potential/property evaluation failed | 0 |
| J | acceptance-error threshold failure | 0 |

99 个旧失败全部重现，主分类互斥。G=29/H=28 为可重叠诊断标记。H 表示初始安全反演能找到根，主分类仍按所在 T/p 边界记录。旧分类先完成并落盘，再允许修改表示。

## 3. Failure-location map

见 TABLE_B_BUFFER_FAILURE_MAP.md 与 tableB_buffer_failure_map.json。每个旧失败记录 p/T/rho、距四边界距离、温度端点残差、可用的压力端点能量残差、旧恢复温度及候选密度偏差。域外线性温度估计明确标记为 audit estimate，未作为合法状态使用。旧算法的端点残差容差曾接受部分严格域外密度；因此新严格算法的 111 个 BUFFER 失败不能直接用旧 99 作为上限。

## 4. Reference rho-p NORMAL domain

NORMAL: p∈[0.10,8] MPa，rhoRef(p,305)≤rho≤rhoRef(p,295)。新增 1612 个参考边界曲线状态，包含 p=0.05/0.10/8/12 MPa；reference_boundary_curves.json。它们是 supplemental REFERENCE-EOS GENERATED 审计数据，冻结 v1 未改。

## 5. Reference rho-p HARD domain

HARD: p∈[0.05,12] MPa，rhoRef(p,320)≤rho≤rhoRef(p,285)。候选 classify(rho,p) 先使用自己的同一 g 的 rhoHot/rhoCold 分类，再求 T；不是运行时查 CoolProp。满足 NORMAL 返回 NORMAL，否则 HARD 内返回 BUFFER，域外 INVALID；不添加 p/T/rho 容差带。边界误差、斜率误差和分类偏差见 rho_p_domain_crosscheck.json 及 spline 对应文件。

## 6. Monotonicity result

完整 HARD 域 g_pT>0 且 v>0，故 drho/dT|p=-g_pT/v²<0。全局 Chebyshev 使用系数绝对和界；分片势使用 B-spline 导数控制系数凸包界。g_pp<0 也获得全域证书。另检查 13041 点正物性。global_stability_certificate.json 给出全域 Cp/Cv/c²/beta 的稳定性下界；没有仅用稀疏网格宣称单调。

## 7. TABLE-B representation changes

先修复算法，再评估 degree 8×8 全局 Chebyshev，81 个系数、8 个 v/e 角点等式、73 个自由方向；约束子空间条件数 148868。随后评估 degree 5×5、25 patch 的单一 tensor B-spline 势，100 个系数，C4 拼接；条件数 70274.4。普通新边界标定点与冻结 holdout 交集为零。4 个角点作为显式拟合锚点，不能再称独立 holdout；密集边界检查保留其工程验收意义。未重新拟合 NASG/MG/TABLE-A。

## 8. Thermodynamic-potential consistency

所有性质来自同一 g：v=g_p，rho=1/v，s=-g_T，h=g-Tg_T，e=h-pv，Cp=-Tg_TT，Cv=Cp+Tg_pT²/g_pp，c²=-v²/(g_pp-g_pT²/g_TT)，beta=T(g_TT*g_pp/g_pT-g_pT)。dp/de|rho=1/beta；dp/drho|e=c²-p/(rho² beta)。没有独立 rho/c/beta 补丁。

## 9. Boundary constraints

在 T=285/295/305/320 K 和 p=0.05/0.10/8/12 MPa 加入错位边界导数观测；HARD 四角对 v 和 e 加等式约束。记录 boundary_calibration_states.json 的坐标和用途。边界权重 50、普通 BUFFER 支持权重 0.1 属于拟合策略，不是改变验收门槛。有限精度下拟合角点约束不自动证明域闭合。

## 10. NORMAL retest

924 个 NORMAL 独立验证状态：两种候选均零评估失败并通过冻结物性/导数/反演门槛。详细 MARE/RMS/MAX/P95/P99 见 retest_results.json 与 spline_retest_results.json；196 条路径状态也均通过。

## 11. BUFFER retest

完整 1245 状态：Chebyshev 90 个失败；C4 spline 104 个失败。4 个 fitted corners 单独披露，剩余 1241 点未进入新标定。两者均 FAIL_BUFFER；可评估状态的极小误差不能覆盖失败记录。

## 12. HARD edge tests

四条边共 2004 次查询（2000 个不同 p/T，角点重复于两条边），Chebyshev 1239 次失败，C4 spline 1432 次失败。详细位置/原因/残差在 hard_edge_stress.json 及 spline 对应文件。四个 fitted corners 是约束检查，不是独立预测证据。

## 13. HARD corner tests

4 个参考角点：Chebyshev 1 个失败，C4 spline 4 个失败。严格 rho-p 分类仍适用于角点；参考角点因表示误差落在域外时照常失败。

## 14. Just-outside rejection tests

每个候选 36 个分类/拒绝检查通过：包括 model 边界精确值、rho 差 1e-7 kg/m³ 的内外探针、p 差 1e-3 Pa 的域外点、T 差 1e-6 K 的域外点。Chebyshev 另有四个参考 just-inside PT 状态检查通过（距压力边界 1 Pa、温度边界 1e-5 K）。这组小样本不替代完整边界检查。

## 15. rho-p temperature inversion

严格 classifier 先于 T root；HARD bracket 为 [285,320] K，safeguarded Newton + bisection fallback。f=v-1/rho，残差预算 2e-18 m³/kg；由 g_pT 下界可换算约 1.6e-12 K 的理想残差误差界。T HARD 同号端点残差仍失败。NORMAL 分类边界附近仅探索满足同一残差预算和原分类的相邻浮点根，用于数值平局处理；不会修改输入或增加域容差。

## 16. rho-e pressure inversion

纯液体 precursor，非 common-pressure solver：先与冷/热边界曲线求交得到合法 p 区间，再 Brent 反演。p 求根 xtol=1e-7 Pa；能量端点残差预算=64*binary64_epsilon*max(|e|,1e5)，来源是数值消减预算，不是压力/温度/密度域容差。只有搜索端点因浮点舍入落在域外时，向区间内移动可表示数；不移动返回状态，也不接受没有合法根的参考状态。记录迭代、区间宽度与残差。

## 17. Derivative results

固定 rho、p±100 Pa 的 beta 有限差分相对误差最大值：Chebyshev 1.39471e-09，C4 spline 2.18878e-08。声学恒等式残差约 binary64 舍入级。完整域物性与导数误差仍使用冻结工程门槛；仅成功可评估状态的统计不能构成域验收。

## 18. Allaire acoustic sensitivity

实际本机 Foundation OF7 JANAF/perfectGas 独立 C++ 查询，N2=0.772/O2=0.228；Tg=400/800/1200/2000 K，标签 ALGORITHMIC SENSITIVITY STATE。包含 freestream-like p=188330.307 Pa/Tg=400 K。alphaL=0,1e-6,1e-4,.01,.1,.5,.9,.99,.9999,1-1e-6,1；纯相直接返回 cG/cL，不计算 m/alpha。最大条件相对误差：Chebyshev_boundary_constrained 1.70797e-09, C4_spline 7.9237e-08。液体 T 查询失败数另列，完整覆盖未通过；这些气态不是预测 CFD 状态。

## 19. Final candidate C++ API

最终 liquid API 尚未实现/冻结。按用户条件，必须先通过严格表示修复才补全生产 C++。离线 Python 已有统一状态字典 pt/rp、classify、pure-liquid pe 与诊断；不是最终 runtime class。未来单次查询复用 basis、T root、g derivatives 的契约保留，不引入全局/跨单元缓存。

## 20. Full C++ benchmark

NOT PERFORMED / gate deferred。没有把此前 0.314 us/state 当成 evaluateRhoP 或 full recovery 的成本。完整液体 evaluatePT/evaluateRhoP/pFromRhoE/full-state 的 median/P95/P99/max/iterations 尚未认证。OF7 gasJANAF 编译与查询 PASS 是气相查询工具的结果，不是液体 EOS API 的编译通过。

## 21. Memory footprint

Chebyshev 81 个基础系数=648 B；六组紧凑 g 导数系数共约 3320 B（含 g）。C4 spline 100 个势系数=800 B、knots=128 B；Python 两个 basis 对象另有约 1600 B identity 数值矩阵及对象开销。未来 native spline 不必保留这些构造用矩阵。每 rank 复制；未包含 mesh state/caches，未声明最终 C++ memory gate 通过。

## 22. Production energy-offset candidate

reference C_L=369229.953724953 J/kg 保留。由各候选自身在 3 MPa/298.15 K 计算 -h_anchor：Chebyshev_boundary_constrained: 369229.953723428072 J/kg, C4_spline: 369229.953672395379 J/kg。两者都是 candidate-only，production C_L=null，未直接复制 HEOS 数值。

## 23. Energy-offset invariance

通过 30 个独立 NORMAL 样本的偏移检查；将 g 整体加常数，比较 rho/T/p/c/Cp/Cv/beta、有效性、逆映射与 e/h 翻译残差。未发现偏移导致的测试失败。有限精度差异见 candidate_energy_offsets.json；此检查不消除本轮 HARD 失败。

## 24. DPM energy-reference status

仍需 state-dependent physical energy ledger。常量能量零点映射不能消除 Eulerian EOS 与 OF7 DPM sensible enthalpy 的 caloric-model discrepancy。未来转换须核对 donor/receiver 的实际内能/焓、压力功和动能；没有实现转换或蒸发能量耦合。

## 25. Active solver impact

NONE。主程序、createFields/createClouds、五个受保护方程与 Make files/options 共 10 个文件保持 SHA-256 一致。冻结参考 v1、批准域、误差门槛未变；没有 CFD、common-pressure、mG/mL、cMix/K runtime、新 KT、CSF 或转移激活。

## 26. M6A1b-2B.3B status

NOT EXECUTED。3A mandatory gates 未通过，因此未进行生产 EOS 最终晋升。

## 27. Production EOS acceptance decision

NOT ACCEPTED / selectedProductionEOS=null。TABLE-B 仍是已评估修复候选；不是已接受生产模型。TABLE-A 保留 FALLBACK，本轮未重拟合或激活。

## 28. Model/coefficient hashes

为本轮候选和证据生成 SHA-256，但它们是审计版本标识，不是生产冻结。acceptance_3a.json 包含候选系数哈希，artifacts.sha256 包含本目录产物；旧数据集及旧 competition 产物不覆盖。

## 29. Exact remaining blockers

(1) 严格域外参考边界密度；(2) rho/e 参考输入无域内能量根；(3) 密集 HARD 边界不闭合；(4) C4 自身模型仍有数值能量端点失败；(5) final liquid C++ API 和 full-query benchmark 未解锁。增加连续性/点权重本身不能保证 rho-p/rho-e 两个映射同时包络参考边界。若下一阶段执行 TABLE-A fallback，应先明确同一 strict domain closure 与数值合同；本轮不扩大域或放宽门槛。

## 30. M6A1b-2B final status

PARTIAL / NO PRODUCTION EOS ACCEPTED。3A 评估与修复尝试已完成，但 mandatory acceptance 未完成。

## 31. M6A2 start permission

NOT ALLOWED。生产 EOS、完整合法域、双反演、API/成本验收及生产专用 C_L 均须先关闭。没有启动 M6A2。

## 32. Updated milestone matrix

M0–M4 COMPLETE；M5A/M5B ACTIVE REFERENCE+DESIGN；M5B.1 DESIGN ONLY；M6A1a COMPLETE；M6A1b-1 SG REJECTED；2A COMPLETE；2B.1 FROZEN；2B.2 COMPETITION PERFORMED；2B.3A PARTIAL；2B.3B NOT EXECUTED；2B overall PARTIAL；M6A2/两相 KT/转换 NOT STARTED。STOP。
