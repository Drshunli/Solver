# M6A1 Eulerian liquid thermo closure — historical SG prototype only

**M6A1b-2A retirement notice:** constant-parameter SG is `REJECTED FINAL EOS`. This file documents the compiled but uninstantiated M6A1a prototype; its parameters are not the next calibration target. See `EOS_MODEL_ADEQUACY.md` and `FIVE_EQ_LIQUID_EOS_INTERFACE.md` for the selected future interface. The rest of this document is retained for algebra audit only.

## Historical candidate and state

`rhosprayLiquidThermo` implements a standalone, dictionary-parameterized stiffened-gas closure for **Eulerian** C10H22. It is compiled but not instantiated by the current solver; no numerical parameters have been accepted or inferred. The independent state is `(rhoL,p)` or equivalently `(p,TL)`. Common mechanical pressure does not imply `TL=TG`.

The prototype dictionary entries are `component` (matching the sole `SLGThermo` liquid), dimensionless `gamma`, pressure `pInf` [Pa], `Cv` [J kg^-1 K^-1], and energy offset `q` [J kg^-1]. All are mandatory if this historical class were constructed; the solver reads no such dictionary. There are no C++ parameter defaults. This class is **not eligible for future activation** after the M6A1b-1 adequacy rejection.

## Equations and API

For `gamma>1`, `Cv>0`, `pInf>=0`, `rho>0`, `T>0`, `p+pInf>0`:

```text
p = (gamma-1)*rho*(e-q) - gamma*pInf
e = q + Cv*T + pInf/rho
p + pInf = (gamma-1)*rho*Cv*T
rho(p,T) = (p+pInf)/((gamma-1)*Cv*T)
T(rho,p) = (p+pInf)/((gamma-1)*rho*Cv)
eFromRhoP(rho,p) = q + (p+gamma*pInf)/((gamma-1)*rho)
h(p,T) = e(p,T) + p/rho(p,T) = q + gamma*Cv*T
c^2(rho,p) = gamma*(p+pInf)/rho
Cp = gamma*Cv
c^2 = gamma*(gamma-1)*Cv*T = (gamma-1)*Cp*T
drhoDpConstT = 1/((gamma-1)*Cv*T)
deDpConstRho = 1/((gamma-1)*rho)
xi = d(rho*e)/dp|rho = 1/(gamma-1)
```

All functions above are in the new class except `Cp`, which is stated here as the analytic consequence and is not needed by the current interface. It can be exposed when the property comparison is activated. `rho`, `e`, and `c` derived from `(p,T)` are consistent with recovery from `(rho,p)`: substitution of `rho(p,T)` into `T(rho,p)` returns `T`; substitution into `eFromRhoP` returns `q+Cv*T+pInf/rho`. The admissibility inequalities imply positive `rho,T,c^2`. This is an **algebraic check**; no calibrated-state numerical/API run has been performed because no approved parameter set exists.

The candidate is local to a fitted state window. A constant-parameter stiffened gas need not reproduce the full C10H22 `Cp(T)` or density correlation; fitting and validation against measured density, sound speed and caloric data are required. It is a stronger total-energy candidate than a bare Tait pressure law. The primary mathematical stiffened-gas and two-medium context is discussed in [Allaire, Clerc and Kokh (2002)](https://www.cmap.polytechnique.fr/~allaire/ack.pdf); this source does **not** provide validated C10H22 coefficients for the present case.

Here `Cp=gamma*Cv` follows by differentiating `h=q+gamma*Cv*T` at fixed
pressure; it is **derived from this EOS**, not copied from an ideal-gas
assumption. Accordingly `Cv=Cp/gamma`, not `Cv=Cp`. More seriously, the
constant-parameter candidate predicts `c^2=gamma*(gamma-1)*Cv*T`: at fixed
`T` its sound speed is independent of `p`, and at fixed `p` it rises with
`T`. Published pure-liquid n-decane sound-speed measurements report a
decrease with temperature along isobars
([2020 experiment](https://doi.org/10.1016/j.jct.2020.106127)). This
structural conflict means the class remains a **candidate interface**, not
a validated physical C10H22 closure; a fit over the approved range must
quantify the discrepancy and may reject this EOS family.

At an approved reference `(pRef,TRef,rhoRef,cRef,eRef)`, the closure requires
`pInf=rhoRef*cRef^2/gamma-pRef`,
`Cv=(pRef+pInf)/((gamma-1)*rhoRef*TRef)`, and
`q=eRef-Cv*TRef-pInf/rhoRef`. These equations expose the missing independent
caloric/acoustic fit (`gamma` or `Cv`) and the energy-zero datum `eRef`;
`rhoRef` and a bulk modulus alone are insufficient. The current case and
local OF7 database supply no validated set for this target, and the stage3
experimental `bulkModulus` is explicitly provisional.

## Future pressure recovery and monotonicity

With fixed `alphaL,mG,mL,M,Et`, positive intrinsic densities `rhoG=mG/alphaG`, `rhoL=mL/alphaL`, and `Eint=Et-|M|^2/(2*(mG+mL))`, M6A2 will solve

```text
R(p) = mG*eG(rhoG,p,YG) + mL*eL(rhoL,p) - Eint = 0.
dR/dp = mG*deG/dp|rhoG,YG + mL/((gamma-1)*rhoL).
```

The liquid contribution is positive for `mL>0`. Positivity and monotonicity of the **whole** residual must still be established for the active gas mixture and temperature bounds. M6A2 needs a bracketed/safeguarded root solver, `alphaMin`, `rhoMin`, `pMin`, `TMin`, internal-energy admissibility, and absent-phase branches; no current field is clipped here.

For the selected isobaric acoustic model, use `xiL=1/(gamma-1)` and `cL` above, with the separate gas `xiG,cG`. The exact pure-liquid limit gives `cMix->cL`. In the pure-gas limit the liquid branch must not be evaluated and existing `psiReactionThermo`, gas JANAF energy, and gas sound speed must remain authoritative.

## Ownership and M4 comparison

Current `rhosprayVoFMixture::rhoL()` is `rhoLProperty`, a read-only M4 diagnostic from the spray liquid database at gas `T`. It remains untouched. Future `rhoLEOS` would be a **separate** comparison field from calibrated EOS `rho(p,TL)`; future authoritative intrinsic `rhoL` is `mL/alphaL` checked against the EOS. Without calibration or an independent `TL`, emitting `rhoLEOS` from gas `T` would misrepresent the target model, so no such diagnostic field is created in M6A1. DPM `SLGThermo` and parcel properties remain independent and unchanged.
