# M8A.3B-T4-S2-R1-NATIVE-RESUME — stopped partial report

2026-10-04。执行范围仅隔离原生MPI迁移与模型延续，不运行CFD。

## 1. T4-S2 final status

**PARTIAL / KH_SIGFPE_UNEXPECTED_BLOCKER**。本轮 M8A.3B-T4-S2-R1-NATIVE-RESUME 在反向原生模型更新出现 SIGFPE 后立即停止。不得将局部新证据合并为 S2 COMPLETE。

## 2. OF7-native components used

Foundation7 cloud.evolve、Cloud::move、particle tracking、processor prepare/correct、native streams/iNew/Pstream、Random、coneInjection、stochasticDispersionRAS、sphereDrag、blobsSheetAtomization、ReitzKHRT、ORourke、rebound、voidFraction。继续复用冻结 fiveEq/S1/N1/I1/C2 适配器，无新 MPI 传输或模型。

## 3. New local code

新增独立 tests/fiveEqDPMR1ResumeNative，复制冻结 NewbornID1MPI 测试入口；只添加 -nativeInjectionProbe：不创建手工 seed，before=0/after=1，使用真实 native cone 注入。Make 指向新的 testR1ResumeNative。新增本轮 fixture、执行脚本、离线审计和报告；未改共享实现。

## 4. Why unavoidable

Foundation7 已提供全部物理、注入和迁移能力：YES，直接使用。新代码只用于观察原生注入从空 cloud 到单 parcel 的计数，原测试默认要求手工 seed；未新增模型或 fiveEq 算法。测试输入置于新目录，旧冻结案例不变。

## 5. RNG ownership result

Random 属于 rank-local cloud，迁移 parcel 不迁移或同步 cloud RNG。新 injection 和 forward 各一条边界事件的 prepare 与 correct 前后，x_、scalarNormalStored_、scalarNormalValue_ 编码一致，无迁移调用额外抽样。注入的 rank0 RNG 抽样与 rank1 不同是原生 ownership 行为，不要求跨 rank RNG相等。

## 6. RNG next-result result

**NOT COMPLETED**。等价 post-cross physical state 下的 no-migration / crossing 下一次真实 stochastic 模型对照尚未执行；prepare/correct 不抽样不能替代 next-result gate。

## 7. stochastic continuation

Fresh 注入 parcel 在 destination 实际执行 dispersion（4 calls），forward destination 2 calls；本轮这两短轨迹 randomCalls=0，因此没有新 actual stochastic RNG update/nonzero UTurb 证明。历史 droplet 轨迹有4次 RNG更新和非零 UTurb，属于 inherited；fresh gate仍未关闭。

## 8. sphereDrag continuation

Fresh forward source/destination 各4次 native drag call；destination local UTrans 范数约3.17992514e-21，仅舍入量级，不能认证所要求的非零物理速度更新。注入 coherent-core drag call=0。历史 droplet 有非零更新；本轮 fresh gate未完成。无 global source closure 声明。

## 9. blobsSheet continuation

Fresh真实注入 parcel 迁移后 native blobsSheet update 4次，liquidCore保持1，完整转变未到达：**bounded update evidence**。B=0.5、angle=0 保持来源 dictionary，不为通过修改系数。

## 10. ReitzKHRT continuation

CRT=0.1 的 forward 更新完成，反向 rank1 出现 signal8。地址0x80a7a由 addr2line 定位至 native ReitzKHRT::update，后续栈为 LazySprayParcel::calcBreakup/calc、LazyKinematicParcel::move。具体表达式和有限输出域合法性尚未诊断。不能沿用历史 CRT=1e9 Class-D 解释，也未证明 Foundation缺陷或迁移因果。冻结ID1仍保留1800合法出生证据；本轮fresh KH专用轨迹未运行。

## 11. coneInjection MPI gate

**Fresh PASS，单出生/单跨界 scope**。空 cloud，source x=3.9999999m，SOI=0、duration=10us、parcelsPerSecond=100000，massTotal=1.09609e-9kg（已确认每孔流量×时长）。原生 cone/frozen I1 wrapper 合计 Added1，pair(0,0)，rank0→rank1，destination唯一parcel，represented mass=1.09609e-9kg。没有 manual seed；无跨 rank双注入。出口速度由现有 flowRateAndDischarge 原生规则计算；这是隔离 MPI 测试，不是 production入口更新。

## 12. ORourke migration note

Fresh成功的两个事件全部 C2 physical/history 字段和 flags 语义匹配，包含 ORourke相关 d、nParticle、rho、T、U、Y等。没有新 collision/coalescence完整分布式物理证明。保持 **NATIVE-PHYSICS-LIMITATION / NOT FULL-CONSERVATION-SAFE**；留给S3。

## 13. rebound evidence

历史自然rebound轨迹：同一core32 evolves内38次跨界、19每方向，inherited。Fresh stress未执行，没有人为翻转速度或强制rebound。

## 14. VoidFraction segmentation

**Fresh单次正向跨界 PASS，重复spot未完成**。原生 postMove +=dt*nParticle*volume，postEvolve归一化；initial x3.9/U47、dt0.004，跨界x4：source时间0.002127659574468087s、dest0.0018723404255319132s。native theta积分分别2.785099870203717e-10、2.4508878857792667e-10m³；推回总时间0.003999999999999997s，相对误差≤1.12e-15。边界stepFraction/位置匹配；nParticle*d³ represented volume变化≤7.9e-16。只认证此原生单跨界积分，不宣称逐子段完整日志或production Theta commit。

## 15. C2 migration semantics

Fresh forward与cone注入各1event：原生sender/receiver scalar、flags、particle history、几何反射、位置及prepare/correct RNG检查全部PASS。未新增serializer，未比较padding。reverse在成功跨界前fatal；KH fresh spot未运行，要求的三类覆盖未完成。

## 16. identity regression

Fresh两成功轨迹均pair(0,0)保持，稳定边界全球唯一、恰有1parcel。新cone birth归属rank0，本轮没有手工赋ID。冻结ID1 sourcechild/destination births已闭合，仅作为inherited；fresh KH子迁移未重放。

## 17. destination support

Fresh cone destination4 queries、forward2 queries；每次generation1，9 stencil entries/4 remote contributors，support rebuilt后才thermo，未报告无效/stale。不新增query collective。

## 18. invalid destination regression

本轮未执行fresh fwd/reverse EXACT_GAS_ABSENT：STOP阻断。冻结N1 inherited正/反向正常reject、zero thermo，范围不变，不能写成本轮fresh。

## 19. valid crossing count

本轮有效 **2次 rank0→rank1**（native cone1、seed forward1）；reverse fatal不计成功。历史100个KH接受轨迹的200跨界、历史core38跨界均保持inherited，N1失败1000次不计。

## 20. >=1000 crossing result

**NOT EXECUTED / NOT PASS**。反向SIGFPE触发STOP后，core/droplet/KH及>=1000计划未启动；不得累加旧failed crossing或用未运行fixture作为压力测试证据。

## 21. ownership

Fresh成功两案例稳定边界one logical parcel/one Cloud owner；注入前空cloud，冻结I1 scoped newborn采用后由nativeCloud唯一持有；native stream/iNew实现跨rankownership。无owner map。反向fatal没有完成全流程归还证明。

## 22. lifetime

Fresh注入global ctor2=dtor2+live0；forwardglobal ctor4=dtor3+baseline live1，disposable trial增量全部销毁，baseline不计leak。反向fatal不能给出析构/rollback证书；>=1000globalstress未完成。

## 23. registry

Fresh成功两案例warm baseline/teardown一致，stable registry61，discard后registry delta0/bindingempty，live delta0。不能声明重复1000次无增长；failed reverse无teardown证书。

## 24. communication/deadlock

Fresh两成功运行正常finalize；reverse rank1SIGFPE导致mpirun终止，**完整communication gate未通过**。无timeout、无cleanup作为PASS；停止后process snapshot没有testR1ResumeNative/mpirun/orted遗留进程。首forward准备错误：输出过滤C1*误删C10H22初始字段，thermo初始化即失败，未evolve；恢复原species字段后重跑通过，该准备失败保留，未计stress。未增加barrier/transport/queryRPC。

## 25. serial regressions

本轮STOP前未执行fresh R2B/I1/C2/K1/serial-phase subsets；上一轮current-source回归R2B252194/I112083/C217/K1108 checks0failures为inherited，不冒充fresh。

## 26. S1 regressions

本轮fresh coupled查询局部PASS；完整topology/weight/allgas/trace/absent/stale矩阵未执行，上一轮20051checks0failure为inherited。

## 27. N1 regressions

本轮没有fresh N1 valid/forward-invalid/reverse-invalid完整矩阵；旧冻结证据保持，未因两成功trajectory代替N1负控。

## 28. Foundation hashes

停止后fresh SHA检查：**6717/6717 Foundation PASS、19/19 native parcel PASS**。ReitzKHRT/Cloud::move/Random/native parcels/streams未改。详见本轮两个verification.txt。

## 29. project hashes

本轮初始和停止后的protected manifest均18412项、0变化（此数包括冻结源码、工件及checkpoint）。之后唯一旧文档授权append是MILESTONE_STATUS.md；旧checkpoint及共享实现不改。新测试副本与新阶段输出单独归档。

## 30. active solver impact

**NONE**。active solver/方程/Make、物性/源项/alpha/flux/时间循环未修改，未实例化新active模型。

## 31. production mesh/BC impact

**NONE**。production mesh/BC/injector条件未改；近processor注入仅在new isolated fixture。productionrestart **NOT CERTIFIED**。

## 32. whether S2 COMPLETE

**NO**。MPI injection和单次VF新增证据不能抵消unexpected native KH SIGFPE、未闭合RNGnext、fresh stochastic/drag、重复VF、>=1000stress及完整freshregressions。

## 33. whether S3 may start

**NO**。T4-S2未COMPLETE；S3仍NOTAUTHORIZED，本轮未执行，只有未来独立授权且S2 gate通过后才可NEXT ROUND。建议下一轮仅诊断CRT=.1反向zero-slip fixture的具体FPE表达式与原生输入域，不预先修改或调参。

## 34. T4 status

**PARTIAL**。R2-FINAL/T3、S1、C1-N1保持冻结完成；ID1保持isolated两rankidentity scope完成。

## 35. M8A/M6B/CFD status

**M8A PARTIAL / M6B NO / CFD NO**；无global MPI transaction/source-outputclosure/activeintegration/productionrestart。

## 36. updated milestone matrix

见下表。所有COMPLETE仍限定原有冻结scope，本轮R1/S2未升级。

| Milestone | Status |
|---|---|
| R2-FINAL / T3 | COMPLETE / FROZEN |
| T4-S1 | COMPLETE / FROZEN |
| T4-S2-C1-N1 | COMPLETE / FROZEN |
| T4-S2-KH-FPE1-NATIVE | COMPLETE / DIAGNOSIS ONLY / historical CLASS D |
| T4-S2-ID1-FIXTURE-NATIVE | COMPLETE / FROZEN / isolated two-rank identity scope |
| T4-S2-R1-NATIVE / RESUME | PARTIAL / KH_SIGFPE_UNEXPECTED_BLOCKER |
| T4-S2 | PARTIAL |
| T4-S3 | NOT AUTHORIZED |
| T4 / M8A | PARTIAL / PARTIAL |
| M6B / CFD | NO / NO |
| production restart | NOT CERTIFIED |

## Evidence

- fitting/dpm/m8a3b_t4_s2_r1_native_resume_v1/closing_audit.json
- native_injection.boundary_audit.json / forward.boundary_audit.json
- log.native_injection / log.forward / log.reverse / log.wmake
- fpe_address_symbols.txt / STOP.txt / process_closing_snapshot.txt
- frozen_before.json / protected_audit_initial.json / installed_source_verification.txt / native_parcel_verification.txt

**STOP. No post-blocker model replay, fixture tuning or subsequent milestone execution.**
