# FIRST_ACTIVATION_OROURKE_LIMITATIONS

2026-10-02 — O2D COMPLETE / NATIVE_OF7_OROURKE_FIRST_ACTIVATION.
Explicit project-owner decision recorded in fitting/dpm/m8a3b_t3br1_v1/owner_decision.txt.
This is a collision-policy decision, not permission to activate the solver.

1. Foundation OF7 native ORourke equations, coefficients, probability, grazing,
   coalescence, temperature treatment, RNG law/order and cleanup are retained.
2. Collision-level strict physical mass/momentum/total-energy conservation is NOT certified.
3. Positive represented-mass cleanup truncation is known and reachable:
   NATIVE_POSITIVE_MASS_TRUNCATION / KNOWN_NATIVE_MODEL_LIMITATION.
4. Native coalescence momentum offset is known:
   KNOWN_NATIVE_OROURKE_MOMENTUM_SEMANTIC.
5. Grazing kinetic dissipation has no explicit internal/carrier/reservoir destination:
   NATIVE_UNTRACKED_COLLISION_DISSIPATION.
6. No compensating gas mass/species/momentum/energy source is added. The frozen
   strict adapter is unchanged; collision residuals are never converted to gas sources.
7. These limitations describe first activation only. The exception is ONLY ORourke;
   drag, heat, phase change, inlet/wall exchange, source mapping and parcel minimum-mass
   deletion remain subject to their original strict requirements.
8. High-fidelity collision development is deferred until the owner explicitly reopens it.
   O2/O2A/O2B remain research/audit-only, excluded from the new candidate compile graph.

## Historical temperature correction

486.41247553 K came from O2 conservative reinterpretation of a native grazing event.
It is NOT native ORourke heating. Earlier language about native-probability replay
refers to the native random branch replayed through the conservative experiment.
The new unchanged-native equal-temperature grazing fixture records both parcels
at 320 K before and after. Native coalescence temperature behavior is also retained.

All historical reports/data remain unchanged. Do not mark their defects FIXED,
CONSERVED or RESOLVED BY SOURCE ADAPTER.

## Reporting limits

Use: native Foundation OF7 ORourke collision semantics with documented collision-level
conservation limitations. Do not claim fully conservative DPM collision,
total-energy-conservative ORourke, or collision energy transferred to gas.

T3B-R1 remains PARTIAL. The kernel/model-event proofs are isolated standalone tests,
not FULL-SERIAL-TRANSACTION-SAFE certification. See M8A3B_T3BR1_NATIVE_SERIAL_TRANSACTION.md.
