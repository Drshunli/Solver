# M2: one-way VOF alpha transport

This implementation was checked against the local OpenFOAM Foundation 7
`applications/solvers/multiphase/VoF/alphaEqn.H`, `alphaEqnSubCycle.H`,
`alphaCourantNo.H`, `createAlphaFluxes.H`,
`src/finiteVolume/cfdTools/general/include/alphaControls.H`, and
`applications/solvers/multiphase/compressibleInterFoam/` including
`compressibleAlphaEqnSubCycle.H`. The solver retains density-based KT gas
flow and does not copy the OF7 pressure/PIMPLE loop or two-phase thermo.

Execution order each main time step:

```
mesh update -> KT face states -> phi (gas mass flux)
            -> phiV (volume flux) -> alpha Courant diagnostic
            -> alpha subcycles -> MULES alphaL and alphaPhi
            -> alphaG=1-alphaL -> parcels.evolve()
            -> original rho/rhoU/species/rhoE equations
```

`phiV=aphiv_pos+aphiv_neg` after mesh-relative KT face reconstruction.
`alphaEqn.H` constructs convection with `phiV` and a compression flux using
`phic=cAlpha*|phiV|/|Sf|`, a temporary alpha-gradient face normal and
`alphaL*(1-alphaL)`-type nested flux. `MULES::explicitSolve` limits the flux
and updates `alphaL`; that limited flux is the per-substep `alphaPhi`.
For the one-way passive marker in a compressible gas velocity field, the
source `alphaL*div(phiV)` keeps the material fraction form
`D(alphaL)/Dt=0`. It does not assert conservation of liquid partial mass;
that requires the future coupled phase-density and mass-flux equations.

For `nAlphaSubCycles>1`, OF7 `subCycle<volScalarField>` advances alpha at
substeps; the main-step `alphaPhi` is the sum of each limited substep flux
weighted by `deltaT_sub/deltaT_main`. A local Euler substep adjustment is
created when the legacy solver uses LTS. `alphaG` is always derived, never
solved independently. Values beyond `alphaBoundTolerance` outside [0,1]
cause an error; no clipping is applied.

Required case entries (read-only reference; no case was modified or run):

```
// system/fvSolution
solvers
{
    alphaL
    {
        nAlphaCorr      1;
        nAlphaSubCycles 2;
        cAlpha          1;
    }
}

// system/fvSchemes divSchemes
div(phiV,alphaL)  Gauss vanLeer;
div(phirb,alphaL) Gauss linear;

// system/controlDict, optional diagnostic threshold
maxAlphaCo 0.1;
```

`0/alphaL` is mandatory. An Euler `ddtSchemes` entry is the current supported
design; Crank-Nicolson alpha off-centering and old correction flux restart
are not implemented. `maxAlphaCo` defaults to 0.1 and is **reported only**;
the legacy `setDeltaT.H` does not enforce it yet. The diagnostic uses all
cells because M3's near-interface model does not exist. Mesh motion is
removed from `phiV` after mesh update; full dynamic-mesh flux remapping and
restart consistency require later verification.

`Make/files` and `Make/options` are unchanged. The existing finiteVolume and
OpenFOAM dependencies supply `CMULES.H`, `subCycle.H`, `fvc::flux` and the
local Euler API. No interfaceProperties or surface-tension library was added.
No CFD case or numerical boundedness test was run in this request.
