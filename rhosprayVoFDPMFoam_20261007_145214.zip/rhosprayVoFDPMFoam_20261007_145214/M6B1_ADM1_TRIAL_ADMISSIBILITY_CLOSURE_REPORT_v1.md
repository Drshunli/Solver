# M6B.1-ADM1-TRIAL-ADMISSIBILITY-CLOSURE REPORT v1

2026-10-05。只审查 trial admissibility semantics。active ndecane_gibbs_v3 HARD p=0.05–12 MPa / T=265–400 K；EOS、metadata、R1、P2、KT、species、temporal/retry/Time与已安装exe/library本轮均无变化。

## 1. ADM1 status

**COMPLETE / TRIAL REJECTION SEMANTICS CLOSED / OUTCOME C / STOP**。三次请求候选拒绝均有原 positive retry，238个committed states（含初始）合法。first true blocker为step237时间不推进；同时存在更大、all100合法、经过原species residual闭合仍合法并可推进时间的候选。没有证明EOS/common-pressure hard blocker。

## 2. Anchor234 committed legality

100/100 committed cells native R1 PASS；anchor234/time=.00028199155942697967 bits3f327b0886864f88。冻结全部Q/P2、200 reconstruction sides与100 faces，原始字段位一致；face/reconstruction mismatch0。cell53 V=.01 m³，physical source0。本轮离线没有PDE/Time advancement。`exact_anchor234_gate.json`。

## 3. Requested candidate result

dt_req=1.2050921343033288e−6 s，cell53原native R1 FAIL `NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN`。这仅描述该trial，不等价于committed invalidity或不存在positive dt。原explicitTrial浮点顺序：Qj(dt)=(V·Qj_old−dt·(Fright−Fleft))/V；My/Mz=0，P2使用原DD fraction numerator与signed minority advanced，并回写Q0。独立重算Q1/Q2/Q3/Q6及生成全部Q/P2 bits匹配原捕获。

|field|requested value|binary64 bits|
|---|---|---|
|P2hi|2.0280533455853129e-05|3ef54403a5a2a7b0|
|P2lo|0|0000000000000000|
|Q0|2.0280533455853129e-05|3ef54403a5a2a7b0|
|Q1|13.908501831358603|402bd12726ec1526|
|Q2|0.015301408454907038|3f8f5658472c298c|
|Q3|517.27107029892443|40802a2b26e7a661|
|Q4|0|0000000000000000|
|Q5|0|0000000000000000|
|Q6|4356277.6776724132|41509e2d6b5efc1d|
|Q7|0|0000000000000000|
|Q8|3.1711384175497619|40095e7dd193b92e|
|Q9|10.73736341380884|40257987b28726da|

|affine conserved component|dQ/dt at frozen faces|
|---|---:|
|Q1|2849.4453040402277|
|Q2|262.85430967608676|
|Q3|1369732.8748689964|
|Q6|1613953465.4117584|


## 4. Accepted retry result

原first retry dt_acc=8.7185434459499146e−7 s；all100 raw trial R1 PASS，原N−1 species residual赋值后all100再PASS；实际step235时间增加。没修改retry算法。冻结anchor234的原connectedDt与dt_acc位一致；但它只处于薄的合法舍入平台，不是有设计裕量的内部点。

## 5. dtCrit

数值上界 envelope dtCrit=8.7185434459650744e-07 s。单次二分不能解析全部native合法集合：初始按原32scan/52refine得到局部相邻边界，换初始bracket会得到不同局部边界。随后枚举固定cell53候选binary64平台，在原connectedDt±1e−11 relative窗口内共3739平台，每个平台lo/mid/hi均恢复all100，并找到最高legal平台上端；窗口上端及32个更高外侧control全部FAIL。扩大窗口后最大值不变。

**这里dtCrit是已审查舍入窗口中的最大native合法候选，不意味着所有dt≤dtCrit都PASS。** 原fixed-flux分量在窗口内单调，组合rhoL=mL/alphaL与native接受结果可非单调；其他99cells在所有authority测试中PASS。报告不把局部二分结果当作全局安全连接区间，也不声称对任意更远、不稳定大步长作形式证明。原几何root失败区间与远侧controls保留在`audits/234/`。

## 6. dtCrit bits

`3ead412bfaae4719`。下一binary64为 `3ead412bfaae471a`，nativeFAIL；下一较小值PASS。精确相邻最大平台边界已定位；其它微邻域存在非法口袋。

## 7. Limiting cell

全100cells authority，最高legal envelope的下一ULP由cell53限制；reason=`NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN`。不是fresh acoustic限制cell82。

## 8. Limiting mechanism

低端共同压力/液相TL265 K，原R1 endpoint tolerance维持不变。native接受的最高候选在lower endpoint，归一化energy残差约1.97508e−12，Flo为小正数并处于原容差预算内，不能声称严格F=0。邻近mL和alphaL分别舍入，rhoL ratio及对应pressureInterval端点产生合法/非法平台；3739个平台中1931合法，在首次失败后229个平台再次合法（不是229次solver retry）。

邻域**不满足严格单调PASS/FAIL稳定性**：最大值−1e−12 relative亦FAIL；−1e−9则PASS。不能把“降低一点dt必然合法”作为本轮结论。

|test|dt s|bits|all100 result|limiting cell|
|---|---:|---|---|---|
|maximum_native_legal_in_window|8.7185434459650744e-07|3ead412bfaae4719|PASS|-1|
|maximum_plus_ulp|8.7185434459650754e-07|3ead412bfaae471a|FAIL|53|
|maximum_minus_ulp|8.7185434459650733e-07|3ead412bfaae4718|PASS|-1|
|maximum_minus_1e12|8.7185434459563563e-07|3ead412bfaae26ef|FAIL|53|
|maximum_plus_1e12|8.7185434459737935e-07|3ead412bfaae6744|FAIL|53|
|maximum_minus_1e9|8.7185434372465314e-07|3ead412bfa30a15a|PASS|-1|
|maximum_plus_1e9|8.7185434546836184e-07|3ead412bfb2becd9|FAIL|53|


## 9. Boundary p / TL

最高native legal候选：p*=3285848.2752389498 Pa，TL*=265 K，rhoL=754.44744534336792 kg/m³，alphaL=2.0165507298936475e-05，mL=0.015213815465735664 kg/m³；共同lo=3285848.2752389498 / hi=12000000 Pa，Flo=8.5840001702308655e-06 / Fhi=28764177.723656166 J/m³。边界由观测识别，未预设；没有域外root求解。

## 10. dt_acc / dtCrit

0.99999999999826117。距离上包络仅约1.739e−12 relative；在native薄legal平台内，**roundoff-close / 无实用安全裕量**。原retry本身经过双次R1/闭合复核有效，但不能保证其任意微小扰动有效。

## 11. dt_req / dtCrit

1.3822172726122541。请求约为最大native合法候选的1.382217倍，需要自适应拒绝。

## 12. connectedDt comparison

anchor234 connectedDt=8.7185434459499146e-07 s（bits 3ead412bfaae0f2b），<=dtCrit：按用户定义 **CASE A**，原重试已有合法性搜索。注意jointBound本身不包含完整R1合法性；connectedDt在首个reject后才调用。anchor235 connected=1.9852287781860227e−18 / envelope3.4350658998830625e−18；anchor236 connected=2.3690109654364757e−20 / envelope2.0610395399297343e−18，仅1.149425287%包络。原32scan/52bisection止于首次非法段，不能越过非单调合法平台，可能非常保守；不符合connected>>dtCrit的CASE C。

## 13. Fresh bound comparison

anchor234 fresh joint=min acoustic=1.2050934787792038e-06 s；request仍用incoming inherited1.2050921343033288e−6。freshJoint/dtCrit=1.3822188146999701，limiting acoustic cell82。停滞前anchor236 fresh joint/acoustic=1.2050935080033052e−6，远大于实际native合法包络；声学上限不能替代root-admissibility。原caller setDeltaT(acceptedDt)继承当前步长，不主动regrowth，代码未改。

## 14. ULP comparison

|anchor|time ULP s|native dtCrit / ULP|accepted retry / ULP|retry advances time?|
|---|---:|---:|---:|---|
|234|5.4210108624275222e-20|16082873964323.549|16082873964295.584|YES|
|235|5.4210108624275222e-20|63.365781531469651|36.621007198960669|YES|
|236|5.4210108624275222e-20|38.019468918879888|0.43700538987218251|NO|

原Time round-to-nearest不能以“dt>0”保证推进。anchor236 envelope约38.02ULP，有实际all100+post-species合法、可推进见证；原retry仅0.437005389872ULP导致tNew=tOld。此处halfULP/ULP候选本身可能FAIL，合法集合不连续；不能简单clamp dt到ULP。最高合法见证的Time加法只在离线验证，没有实际推进PDE。

## 15. Anchor105 comparison

来源 `m6b1_eos1_cap1_serial_v1/case` 的原committed Q/P2，在current final v3下100/100合法；原requested dt=1.2050921343033288e-06 PASS，原retry=9.1990382482555322e-07 PASS。current all-grid numerical dtCrit=0.00045266881686800226 s，bits 3f3daa85c3ad8fa7，limiting cell=22 / NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN；current connectedDt=1.2050921343033288e-06。原105/114/153/174历史requested已在current v3合法，不再出现该历史domain reject。dtCrit使用当前EOS从冻结committed重构的current faces，与原版本flux并非混用；其数值search上界为R1/mass admissibility，可能远大于acoustic稳定上限，不授权PDE使用这个大步长。旧报告原verdict不回写。历史较远边界报告为原32scan/52refine加binary64相邻定位的connected-search结果，未声称穷尽所有舍入口袋。

## 16. Anchor114 comparison

来源 `m6b1_eos2_ndecane_v1/diagnostic_case` 的原committed Q/P2，在current final v3下100/100合法；原requested dt=1.2050921343033288e-06 PASS，原retry=2.4645706092801419e-07 PASS。current all-grid numerical dtCrit=0.00048142173832592107 s，bits 3f3f8cea9f274acb，limiting cell=23 / NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN；current connectedDt=1.2050921343033288e-06。原105/114/153/174历史requested已在current v3合法，不再出现该历史domain reject。dtCrit使用当前EOS从冻结committed重构的current faces，与原版本flux并非混用；其数值search上界为R1/mass admissibility，可能远大于acoustic稳定上限，不授权PDE使用这个大步长。旧报告原verdict不回写。历史较远边界报告为原32scan/52refine加binary64相邻定位的connected-search结果，未声称穷尽所有舍入口袋。

## 17. Anchor153 comparison

来源 `m6b1_eos3_numerical_v1/diagnostic_case` 的原committed Q/P2，在current final v3下100/100合法；原requested dt=1.2050921343033288e-06 PASS，原retry=6.977512364266908e-08 PASS。current all-grid numerical dtCrit=0.00056572343827473548 s，bits 3f4289a1d53e86d6，limiting cell=26 / NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN；current connectedDt=1.2050921343033288e-06。原105/114/153/174历史requested已在current v3合法，不再出现该历史domain reject。dtCrit使用当前EOS从冻结committed重构的current faces，与原版本flux并非混用；其数值search上界为R1/mass admissibility，可能远大于acoustic稳定上限，不授权PDE使用这个大步长。旧报告原verdict不回写。历史较远边界报告为原32scan/52refine加binary64相邻定位的connected-search结果，未声称穷尽所有舍入口袋。

## 18. Anchor174 comparison

来源 `m6b1_eos3_ub1_domain_closure_v1/diagnostic_case` 的原committed Q/P2，在current final v3下100/100合法；原requested dt=1.2050921343033288e-06 PASS，原retry=7.3978782992392903e-07 PASS。current all-grid numerical dtCrit=0.00053440912227800555 s，bits 3f4182f2d9f794f5，limiting cell=27 / NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN；current connectedDt=1.2050921343033288e-06。原105/114/153/174历史requested已在current v3合法，不再出现该历史domain reject。dtCrit使用当前EOS从冻结committed重构的current faces，与原版本flux并非混用；其数值search上界为R1/mass admissibility，可能远大于acoustic稳定上限，不授权PDE使用这个大步长。旧报告原verdict不回写。历史较远边界报告为原32scan/52refine加binary64相邻定位的connected-search结果，未声称穷尽所有舍入口袋。

## 19. Anchor234 comparison

来源 `m6b1_eos3_lr1_lower_range_closure_v1/diagnostic_case` 的原committed Q/P2，在current final v3下100/100合法；原requested dt=1.2050921343033288e-06 FAIL，原retry=8.7185434459499146e-07 PASS。current all-grid numerical dtCrit=8.7185434459650744e-07 s，bits 3ead412bfaae4719，limiting cell=53 / NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN；current connectedDt=8.7185434459499146e-07。按本轮定义为TRIAL_REJECTION_RECOVERABLE；实际retry/timeadvance已确认。相邻及非单调平台见第5–14项，不再将单次requested无根等价为hard model blocker。

## 20. Continuation length

从原fresh初始态独立重放active exe及未修改的上一轮只读diagnostic exe。active/diagnostic0–237共238完整history rows全部字段一致。237accepted transactions，time严格增加到step236；step237首次nonprogress时外部SIGTERM（均exit−15）停止。t=.00028286341377157669 s；配置endTime=.00055 s未到达。不在第一个requested reject停止。当前生产/求解器源码没有修改；没有把外部观测停止记为正常solver退出。

## 21. Rejected trial count

237首次请求；240总尝试（237接受+3拒绝）。main/requested rejects=3，均NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN，anchors234/235/236 cell53 attempt0。另73 connected search probe rejects单独计数，不计为主trial/retry。234步无retry、3步各1retry。逐步incoming/firstTrial/accepted/retry/reason/limiting/dtCrit：`REJECTION_LEDGER.csv`与JSON。

## 22. Recoverable reject count

3。每个原请求拒绝均有原算法正retry，committed保持合法。anchor234、235重试后time增加；anchor236重试R1合法但clock不增加，故trial failure可恢复与temporal outcome分别记录。

## 23. Unrecoverable reject count

0（观测范围内）。无committed invalid、无NO_CONNECTED_DT fatal、无retry budget fatal、无证明所有positive binary64 dt失败的状态。不能从一个候选失败推断hard admissibility。

## 24. Minimum accepted dt

2.3690109654364757e-20 s，step237；ULP5.4210108624275222e−20，accepted/ULP=.43700538987218251。

## 25. Minimum diagnosed dtCrit

2.0610395399297343e-18 s，anchor236，bits 3c43027df520f055，约38.019468918879888 ULP。terminal235/236平台全枚举1800/1361，分别291/120合法；合法包络比actual retry大。窗口放大、远侧32controls检查均未改变上包络。只对明确诊断的七锚点给dtCrit，未为每个无reject step假造dtCrit。

## 26. First true blocker

**TEMPORAL_POLICY_BLOCKER**：step237，tOld=tNew=.00028286341377157669。较大post-species合法候选仍存在，故当前证据未选择true IDP/no-positive-dt分支。主机制包括native非单调接受与first-connected policy的保守选择；incoming dt inheritance/no regrowth同样存在，但本轮不声称仅改regrowth就能修好，亦未修改R1/connected/Time。

## 27. Time monotonicity

0–236严格推进；236→237相等，停止。仅step计数增加不能作为time advance证据；Time driver当前不拒绝这种commit，本轮保留原行为观测。

## 28. Conservation

原accepted trajectory max scaled conservation=1.098754595397559e-15，原mG/mL/momentum/Et/species各component gates<=1e−12 PASS。每个trial基于const committed anchor生成独立候选，reject只丢弃trial、未改committed totals；离线anchor bit identity PASS。全replay conservation ledger保留，不修改数值容差。

## 29. P2 / species status

23800实际committed cell records exact bits检查；PRESENT→ABSENT次数0（逐步检查gas/liquid，而非仅初始掩码），P2lo0，Q0/P2decoded匹配。已有纯相保持原定义，minimum alpha/mL=0不是删除。max species closure=1.7101421570792262e-16。原dependent N2=q1−(q7+q8)未改变/未normalize；max234/235/236候选及原retry均原操作前后all100 PASS。`postcheck/`。

## 30. EOS source hashes

所有EOS源/metadata SHA保持不变，完整列表`source_hash_groups.json` EOS group。metadata SHA `9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`；81coeff SHA `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`；energy-reference SHA `ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`；C_L=369229.9537234281不变。265/400/pHard永久保留；未新建v4/260shadow或域外新root。metadata中LR1历史verdict未改写，新operational判据结论写在本轮gate/报告/追加milestone。

## 31. Temporal source hashes

完整`source_hash_groups.json` temporal与serialTimeCaller groups（以及R1/P2/KT/species）全部before/after一致。`fiveEqIntegration/fiveEqTemporalContract.H`、`serialFiveEq/runSerialFiveEq.C`、PrecisionOperator connectedDt/retry，Time Foundation原样。active exe SHA `049e21b7c0533b5bb2566dcfce74b68530510a02a3a91bb95958639987b1481c`测试前后相同。没有本轮solver observer改动，直接复用未修改LR1诊断exe，SHA `5ee471f88dfa52ca02972b5c7dab71dd1c14545bccb13b4e531c6247023d5299`。仅新增独立离线审查工具与报告。

## 32. Foundation/project hashes

109共享项目源文件changes0；115librarieschanges0；6717Foundation / 19nativeparcel before-afterPASS；历史证据与文档1471 entries无变化（最终milestone仅授权追加，旧prefix保存）；原shock17inputsSHA一致。LR1 parent checkpoint SHA `5ed9d1b720a4a672c52f1c87f92d97cd71b06ccd5149544b53cdcf32c623f3f3`。`project_protection.json`含完整source/installed/input hash；最终helper重新规范Make/options格式，audit二进制SHA未变。

## 33. EOS3 operational domain verdict

按本轮新gate：**EOS3-NUMERICAL COMPLETE / OPERATIONAL DOMAIN FROZEN / active v3 265–400 K**。238committed states合法、3trial rejects均positive retry、accepted无outside HARD、未遇到unrecoverable positive-dt state。冻结含义限于已经观察的accepted轨迹与数值回归资格；不要求所有optimistic trial恢复，不等价于endTime完成、所有网格/时间状态证明、稳定性/production或solid-liquid相认证。历史EOS1/EOS2/UB1/LR1 verdict及metadata字节保持，不回写；新增current-solver admissibility interpretation。PHASE-DEFER COMPLETE/POLICY FROZEN，historicalCLASS D与仅未来Tmelt证据5%政策不变。

## 34. TD1 authorization?

**NEXT ROUND ONLY / REQUIRED / NOT EXECUTED / 本轮未授权TD1源码修改**。后续TD1 scope应明确处理representable time advance、合法候选选择/舍入非单调、accepted dt inheritance及regrowth，并保持EOS/R1/P2契约。不能仅凭更大fresh acoustic bound直接增dt，也不能clamp到ULP后不做all100恢复。本轮不设计或实现修复。

## 35. IDP review required?

本轮证据不要求转入IDP1。没有no-positive legal dt证明，且停滞状态有38ULP可推进见证；不将三次有限锚点急降直接推断systematic dtCrit→0。若后续独立授权TD1中发现真正不可推进的可接受域或finite-state→zero上限，再另行审查invariant-domain；本轮不修改flux/limiter/positivity算法。

## 36. M6B.1 / M6B status

M6B.1 PARTIAL / M6B PARTIAL / TEMPORAL BLOCKER / STOP。ADM1语义审查闭合不等价于shock endTime完成或整个wave ladder完成。M6B.2、高Mach、active DPM、T4-S3、production CFD未执行，production restart NOT CERTIFIED。

## 37. Milestone matrix

|milestone|current status|
|---|---|
|PHASE-DEFER|COMPLETE / POLICY FROZEN / NOT PHASE CERTIFIED|
|LR1历史报告|PARTIAL / EOS_RANGE_CHASING_DETECTED / 原verdict保留|
|ADM1|COMPLETE / TRIAL REJECTION SEMANTICS CLOSED / OUTCOME C|
|EOS3-NUMERICAL新operational gate|COMPLETE / OPERATIONAL DOMAIN FROZEN 265–400 K|
|committed legality / recoverable rejects|238 states PASS / 3 recoverable / 0 unrecoverable|
|native admissibility边界|非单调舍入口袋；上包络与first-connected分别记录|
|continuation|step237 first time nonprogress / endTime未到|
|primary blocker|TEMPORAL_POLICY_BLOCKER|
|M6B.1-TD1|NEXT ROUND ONLY / REQUIRED / NOT EXECUTED|
|M6B.1-IDP1|本轮未选定 / NOT EXECUTED|
|M6B.1 / M6B|PARTIAL / STOP|
|remaining waves / high-Mach / M6B.2|NOT EXECUTED|
|active DPM / T4-S3 / production CFD|NOT EXECUTED|
|production restart|NOT CERTIFIED|

## STOP

本轮到此停止。未执行EOS extension、v4、Tmin<265、Tmax>400、TD1/IDP源码修改、remaining wave ladder、high-Mach、M6B.2、active DPM、T4-S3或production CFD。封存索引及checksum另见stage内checkpoint_contents.json / checkpoint_seal.json。
