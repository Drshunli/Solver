# Offline five-equation acceptance tests — design only

No state recovery, production EOS or numerical flux is implemented/tested in
M5B.1. This file specifies future tests and oracles. Use validated canonical
gas/liquid energy references; do not promote illustrative SG parameters.

## T1: pressure-equilibrium contact, conversion only

Choose p0,U0,YG; build two admissible mixed states with different alpha and,
where EOS validity allows, different intrinsic densities and phase temperatures.
For each side independently compute mG,mL,M and
Et=sum(m_k*e_k(rho_k,p0))+rho*|U0|^2/2. Run recovery independently.
Require pRecovered=p0 and URecovered=U0 within declared root/floating-point
tolerances, consistent EOS temperatures and mass/energy round trip. Include
stationary and moving contacts and both NORMAL/BUFFER states. Test tolerances
must be fixed before implementation evaluation. No unspecified digits are
claimed today; recovery acceptance budgets belong to M6A2.

## T2: alpha-only pressure inconsistency

For a legal two-phase reference state keep mG,mL,M,Et fixed and replace alphaL
by alphaL+delta with both phases still present. Then

    d(rhoL)/d(alphaL)=-rhoL/alphaL
    d(rhoG)/d(alphaL)=+rhoG/alphaG
    dp/d(alphaL)=(rhoL^2*eL_rhoAtP-rhoG^2*eG_rhoAtP)
                 /(mG*betaG+mL*betaL).

The numerator is generally nonzero for unlike EOSs. Even if it cancels at an
exceptional state, phase densities change and caloric/acoustic properties can
change. Future tests compare actual recovered pressure differences with this
linear sensitivity as delta->0; also deliberately choose a state with nonzero
sensitivity. An invalid perturbed state must fail, not extrapolate. This is the
formal reason alpha-only cAlpha compression is not an accepted production path.

## T3: discrete contact and KT alpha compatibility — separate gate

T1 does not demonstrate that a conservative numerical update preserves p0.
For fixed phase densities/energies and equal p0,U0, a contact-compatible common
mixing weight must update alpha,mG,mL,Et consistently so the new energy root is
p0. Check zero-velocity contacts too: KT acoustic diffusion moves conservative
states even when an alpha-only advective flux is zero. With arbitrary EOSs and
different intrinsic states, nonlinear averaging can create additional errors;
do not generalize the fixed-phase-state identity. M5C/M6B must derive/test the
nonconservative KT discretization before claiming contact preservation.

## T4–T9: other mandatory offline contracts

- T4 pure-gas: no liquid calls; compare legacy phi/phiUp/phiEp using identical
  reconstructed states, both fixed/moving mesh and retained KT/Tadmor branches.
- T5 pure-liquid: no gas psi or EOS call; liquid energy pressure recovery and cL.
- T6 vanishing phase: coherent exact endpoints; threshold residual handling;
  inconsistent tiny alpha/significant mass must fail before division.
- T7 acoustics: baseline c_A against differentiated PDE eigenvalues; Wood/K
  matched extension only; positive finite interface c; pure limits; input beta
  variation at fixed alpha,rho,c demonstrates six-input API insufficiency.
- T8 domain: NORMAL/BUFFER/INVALID including joint temperature-constrained root
  brackets, no root, backend failure, out-of-range face and missing phase.
- T9 energy shifts: shifting phase e by Delta_k requires Et shift by
  mG*DeltaG+mL*DeltaL; consistent shift preserves p/c, inconsistent shift fails
  round-trip/contact expectations. Ledger handles future transfer/source shifts.

CFD validation is separate and is not performed in this milestone.


## M6A2.1 standalone completion

M6A2.1 algebraic recovery contact, alpha-pressure, offsets, pure limits and validity tests now pass. This does not validate KT face/contact transport. Exact valid singleton bracket acceptance was explicitly approved by user; negative width/no-root still fail. See M6A2_1_STANDALONE_STATE_RECOVERY.md and tests/fiveEqRecovery/test_results.json.
