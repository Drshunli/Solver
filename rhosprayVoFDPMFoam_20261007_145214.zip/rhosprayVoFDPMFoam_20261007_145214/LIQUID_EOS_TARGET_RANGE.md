# M6A1b-1: Eulerian n-decane EOS operating envelope (29 September 2026)

**M6A1b-2A update:** this is a historical audit and screening calculation. The user later supplied a new gas state (`U_inf=2013.039 m/s`, `p_inf=188330.307 Pa`, `T_inf=400 K`, `rho_inf=1.6338 kg/m3`, approximately Ma 5.02). [OPERATING_ENVELOPE_M6A1B2A.md](OPERATING_ENVELOPE_M6A1B2A.md) is now the authoritative condition ledger: gas partially locked, liquid p/T envelope blocked, final Mach unconfirmed. None of the older numbers below is an approved calibration range.

## Evidence from `300_2D` (absolute pressure)

| Quantity | Actual file/value | Interpretation |
|---|---|---|
| Gas inlet/base | `0/p`: 102243 Pa; `0/T`: 166.67 K; `0/U`: (517.6,0,0) m/s | Gas only; the 101325 Pa in the outlet `value` is a wave-transmissive placeholder. |
| Set-field gas states | `system/setFieldsDict`: base 101325 Pa, 300 K; hot region 4053000 Pa, 2000 K and U=(0,0,1980) m/s | The hot region is a prescribed gas initial state. It is neither measured liquid loading nor liquid temperature. |
| Gas composition | `0/O2=0.228`, `0/N2=0.772`; `constant/thermophysicalProperties`: JANAF/perfectGas | Gas gamma and R vary with state/composition. |
| DPM liquid | `constant/sprayCloudProperties`: C10H22, T0=300 K, rho0=730 kg/m3, Cp0=2090 J/(kg K); cone injection `flowRateAndDischarge` | No parcel injection pressure; DPM constants are not independent EOS observations. |
| Resolved liquid | No production `alphaL` inlet/initial state in `300_2D` | No prescribed VOF column p or TL. The user's 0.3 mm column diameter is geometric only. |

The current inlet speed and temperature imply **approximately Mach 2.0** if an illustrative ideal-air `gamma=1.4`, `R=287 J/(kg K)` is used: `517.6/sqrt(1.4*287*166.67)=2.00`. This is an analytic estimate, not the solver's composition-dependent Mach result. The requested **Ma > 7** is a future design scenario and is not encoded by this inlet. The hot set-field region is not evidence that the existing inlet itself is Ma > 7.

## State labels and design bounds

| Bound | Actual target for five-equation liquid | Provisional *screening scenario*, never an approved calibration envelope |
|---|---|---|
| `p_min` | **Unresolved:** injector and local decompression pressure unknown | 0.10 MPa, near current gas ambient. Assumes no lower pressure during breakup. |
| `p_ref` | **Unresolved:** VOF injection static pressure unknown | 0.102243 MPa, current gas inlet pressure, for comparison only. |
| `p_max` | **Unresolved:** future Mach, shock geometry and liquid loading unknown | 10 MPa, a rounded margin above the illustrative 6.5 MPa normal-shock stagnation estimate for Ma=7. This is **not an upper bound for Ma>7**. |
| `TL_min` | **Unresolved:** VOF inlet temperature and cooling/decompression unknown | None. |
| `TL_ref` | **Unresolved:** VOF inlet temperature unknown | DPM parcel T0=300 K is a possible *hypothesis*, not a VOF state. |
| `TL_max` | **Unresolved:** compression heating, thermal exposure and phase-change policy unknown | None. Gas 2000 K is not used as TL. |

At the hypothetical upstream state `(Ma=7, p1=102243 Pa, gamma=1.4)`, an ideal-gas **normal-shock estimate** gives `p2/p1=1+2*gamma/(gamma+1)*(Ma²-1)=57`, hence `p2=5.83 MPa`. `M2²=(1+0.2*Ma²)/(gamma*Ma²-0.2)=0.1579`; isentropic stagnation of the shocked gas gives `p02=p2*(1+0.2*M2²)^(gamma/(gamma-1))≈6.50 MPa`. This is a loading scale, not a liquid-interface solution or guaranteed maximum; oblique shocks, focusing, different Mach and evolving composition change it. The prescribed 4.053 MPa gas region is separate case evidence. Local decompression motivates margin below the 0.102243 MPa inlet but no credible minimum can yet be fixed.

Liquid `TL` must be determined independently because the planned five-equation model allows `TG != TL`. Compression heating requires an accepted liquid caloric EOS and a loading path. Thermal exposure requires time and heat-transfer information; the current spray case has `heatTransferModel none`, which does not establish the future Eulerian exposure. Thus a numeric TL ceiling would be invented.

**Gate:** the true six bounds remain open after the user confirmed that liquid inlet pressure, temperature and thermal ceiling are not yet determined. The 0.1–10 MPa / 288–403 K ranges used in the *limited structural data check* are measured-data windows, not this project's target envelope. No M6A1b-2 parameter fit may use the screening scenario as accepted operating conditions.
