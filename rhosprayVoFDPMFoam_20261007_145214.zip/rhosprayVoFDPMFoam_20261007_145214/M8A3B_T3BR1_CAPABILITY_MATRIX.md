# M8A.3B-T3B-R1 capability matrix

| Enabled model | Verified R1 scope | Complete serial capability |
|---|---|---|
| coneInjection | Ongoing native admission; exact reference and rollback | PARTIAL: external inlet ledger/accepted retry open |
| stochasticDispersionRAS | Accepted isolated retry; 10 future RNG-consuming renewals | PARTIAL: full codec/timestep/output open |
| sphereDrag | Nonzero source; strict adapter, Q update, energy/momentum ledger/retry | PARTIAL: whole timestep/restart/output open |
| blobsSheetAtomization | Actual liquidCore 1→0; strict isolated retry/reference | PARTIAL: whole timestep/restart/output open |
| ReitzKHRT | Real child creation; strict accepted retry/IDs/reference | PARTIAL: future child evolution/restart/output open |
| ORourke | Native no-event/grazing/coalescence/cleanup kernel reference/retry | PARTIAL / NATIVE-PHYSICS-LIMITATION; not full serial safe |
| standardWallInteraction/rebound | Actual bottom-wall rebound; reference/rollback | PARTIAL: wall impulse/energy ledger/accepted retry open |
| voidFraction | Native residence-time hooks; copied theta/output probe | PARTIAL: full trajectory/restart/persistent output open |

ThermoParcel minimum-mass deletion is an additional event gate. Actual native
coupled deletion passes the unchanged strict adapter with gas chemical-reference
accounting; no ORourke exemption applies.

No row is FULL-SERIAL-TRANSACTION-SAFE. Full graph codec/decoder, native event-local
inlet/wall accounting, runtime support retries, ordinary whole-cloud future evolution,
complete pending-output publication and lifecycle memory checks remain prerequisites.
