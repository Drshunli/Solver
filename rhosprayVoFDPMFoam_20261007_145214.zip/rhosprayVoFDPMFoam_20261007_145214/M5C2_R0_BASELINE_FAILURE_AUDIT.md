# M5C.2 R0 baseline and update-admissibility failure audit

Date: 2026-09-30. Status: **PARTIAL / R0 ADMISSIBILITY GATE FAILED**.
No active solver, M5C.1 flux source, EOS coefficient or M6A2 recovery change.
No CFD. R1/R2 are not implemented: the user's section 3 explicitly requires the
low-order baseline to pass before discussing high-order limiting.

## 1. The two gates remain separate

Reconstruction admissibility: a valid cell contributes a valid face state.
Update admissibility: valid faces and finite fluxes produce a recoverable next
cell average. Here R0 copies valid cell averages exactly. All 405 uniform matrix
cases and 45,040 evolving stencil faces are valid. Nevertheless 21 of 42 evolution
scenarios stop at a post-update recovery failure. Therefore face validity alone
does not close this stage. Failed trial states are never committed.

## 2. Implemented standalone ownership

`MaterialCell = {alphaL,mG,mL,Mx,My,Mz,Et,mY0,mY1,mY2}`.
The three species mass entries follow the audited runtime name order; the bridge
maps them to actual JANAF species. Intrinsic Yi=mYi/mG only for mG>0; no default
air in library code. Absent gas cannot carry species mass. Input conversion rejects
that inconsistency rather than silently losing the mass. sum(mYi)=mG is checked
with the existing 1e-12 relative composition tolerance, without normalization.

All p,T,c,rhoG,rhoL,U are recovered. No second thermodynamic authority. No field
creation or registry objects. Negative sensible/internal energies are allowed;
only actual recovery establishes thermodynamic admissibility.

## 3. Actual source audit and temporal scope

The current main .C computes face fluxes before sequential `rhoEqn.H`,
`rhoUEqn.H`, `rhoYEqn.H`, `rhoEEqn.H`. `300_2D/system/fvSchemes` uses Euler;
advective divergences are explicit fvc terms, with legacy viscous/source corrections
and thermo updates afterward. This is not an existing simultaneous five-equation
SSP stage. LTS/local Euler and provisional alpha subcycling remain separate active
mechanisms. None are modified or selected for atomic activation here.

Actual Foundation 7 Minmod.H/.C and LimitedScheme/NVDTVD.H/NVDVTVDV.H were read
under `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src/finiteVolume/interpolation/surfaceInterpolation/limitedSchemes/`.
Minmod returns max(min(r,1),0); MinmodV uses a vector gradient projection.
No arbitrary componentwise slope was introduced or described as actual MinmodV.
These reads prepare a later comparison; they do NOT constitute an implemented
R1/R2 or full legacy reconstruction regression.

The harness uses one explicit simultaneous Euler transport trial, frozen old-cell
alpha in its source, and real recovery before committing ANY next cell. Every
accepted state used by EOS/flux must be admissible. Multi-stage ordering,
boundaries, initialization and restart remain M5C.3 work, unexecuted.

## 4. Exact timestep derivation including ALE

Use one-dimensional cells with both face fluxes oriented left-to-right.
V>0, D=meshPhiR-meshPhiL, Vnew=V+dt D.

```
Nalpha = -(FalphaR-FalphaL)
         + alphaOld*(phiRelR-phiRelL)
alphaNew = alphaOld + dt*Nalpha/(V+dt D)
```

The second expression follows from the physical source
`dt alphaOld*(phiPhysR-phiPhysL)` after analytical GCL cancellation. It does NOT
replace the physical source with a relative source. `sourceIntegral` explicitly
stores the physical expression and is audited in the alpha ledger.

For a=alphaOld in [0,1], the lower and upper constraints are:

```
a V + dt*(a D+Nalpha) >= 0
(1-a)V + dt*((1-a)D-Nalpha) >= 0
```

Define B(z,r)=z/r if r>0, otherwise infinity:

```
dtAlpha=min(B(aV,-aD-Nalpha), B((1-a)V,Nalpha-(1-a)D))
```

For D=0 and Lalpha=Nalpha/V: dtAlpha=(1-a)/Lalpha when Lalpha>0,
or a/(-Lalpha) when Lalpha<0, infinity when zero. The flux and nonconservative
source both enter; mass CFL alone is insufficient.

For each conserved nonnegative density z (mG,mL,mYi):

```
zNew=(Vz-dt*(FzR-FzL))/Vnew
dtZ=B(Vz,FzR-FzL)
dtVolume=V/(-D) if D<0, otherwise infinity
dtAcoustic=0.15*2V/(max(|apL|,|amL|)+max(|apR|,|amR|))
dtJoint=min(dtAcoustic,0.95*dtAlpha,0.95*dtMG,
            0.95*dtML,0.95*dtSpecies,0.95*dtVolume)
```

0.15 acoustic CFL and 0.95 analytic-bound safety were fixed BEFORE execution.
Neither is tuned after failure. These formulas guarantee the tested scalar bounds
for this frozen flux/Euler trial, NOT common-pressure root existence. No thermo
retry factor is secretly added. A zero joint bound is a controlled no-advance
condition; negative/zero volume is rejected. Species flux sum follows M5C.1;
no independent species repair after update.

## 5. Matrix and actual results

405 uniform cases: alpha 0/1, 1e-12/1e-10/1e-8/1e-6 and complements,
0.01/0.1/0.5/0.9/0.99; p=0.1/3/8 MPa, TG=400/800/1400 K,
TL=295/300/305 K. Real face and post-update recovery PASS.

42 periodic scenarios: 14 initial profiles times 20/60/200 cells. Ordinary
20-cell cases request 100 steps; 60/200 cells request 10. Four HARD outward-loading
profiles request one step. Length/area/volume are synthetic (initial V=1, face
area=1), not the physical 0.3 mm injector mesh. The HARD inward-loading extension
listed in the initial plan is not separately assessed; no claim of full planned
coverage is made.

| Scenario | N=20 | N=60 | N=200 |
|---|---|---|---|
| Stationary contact | 100 steps PASS | stops before step 10 | stops before step 10 |
| Moving contact | 100 steps PASS | stops before step 10 | stops before step 10 |
| Near-pure 1e-12 contact | 100 PASS | 10 PASS | 10 PASS |
| Smooth material | 100 PASS | 10 PASS | 10 PASS |
| Mild compression | 100 PASS | 10 PASS | 10 PASS |
| Mild expansion | 100 PASS | 10 PASS | 10 PASS |
| Pure gas shock-like | 100 PASS | 10 PASS | 10 PASS |
| Mixed shock/interface | stops before step 9 | stops before step 9 | stops before step 9 |
| ALE contact | 100 PASS | stops before step 10 | stops before step 10 |
| ALE uniform | 100 PASS | 10 PASS | 10 PASS |
| Four HARD outward-loading profiles | first trial rejected | first trial rejected | first trial rejected |

21 scenarios finish, 21 do not. 1098 global steps are committed after all-cell
recovery. 368,617 implementation/linear-bound/closure/ledger/contact assertions
have zero assertion failures; this does NOT mean the update gate passes. The
separate 21 recovery failures explicitly produce process exit code 1.

## 6. Failure A: phase-presence predicate rejects a consistent trace

Actual source `fiveEqThermo/fiveEqStateRecovery.C:27–33`:

```
massTol = massAbsoluteTol + massRelativeTol*rhoMix
if(alpha <= alphaPresenceTol && mass > massTol)
    reject INCONSISTENT_DISAPPEARING_PHASE
```

Both default relative tolerances are 64*epsilon=1.4210854715202004e-14.
Static 60-cell contact, tenth attempted step, cell 9:

```
alphaL = 6.9241358403509355e-15
mL = 5.0368446335644225e-12 kg/m3
massTol = 1.8479656162340748e-13 kg/m3
```

The predicate rejects it. Independently evaluated rhoL/rhoG at 3 MPa,
TL=300 K,TG=800 K match mL/alphaL and mG/(1-alphaL) to roughly 1.6e-16.
The corresponding energy residual is 1.21e-16 after scaling. This is a
consistent dense-liquid trace, NOT negative mass/alpha, absent phase with mass,
or loss of the material contact identity. A mixture-density-scaled mass threshold
can reject a liquid volume trace because rhoL is much larger than rhoMix.

There are legal trace states on either side of this predicate's excluded interval;
admissibility along a theta/timestep segment therefore cannot simply be assumed
convex or monotone. A reduced timestep might avoid a particular trace rejection,
but an arbitrary factor is not an admissibility proof. The frozen recovery policy
is respected here: no threshold edit, mass deletion, alpha floor or alternate
production recovery. The evidence requires a subsequent policy/compatibility audit.

## 7. Failure B: legal scalar state, no thermodynamic pressure root

Mixed interface initial states: left alpha=.01,p=1 MPa,TG=400 K,TL=295 K,U=20;
right alpha=.99,p=8 MPa,TG=1400 K,TL=305 K,U=-20. Initial cells and all faces
before failure are within their EOS domains. After eight accepted steps, the
ninth 20-cell trial has:

```
alpha=.018810207641899182; mG=8.620083437967612; mL=13.878874471833576
Et=-93759.19702466005 J/m3; Eint=-93834.70327453157 J/m3
legal common-pressure bracket = [1.565218278 MPa, 12 MPa]
mixture Eint at bracket low  = 866983.226355078 J/m3
mixture Eint at bracket high = 35929214.422863193 J/m3
F(low)  = 960817.929629610 J/m3 > 0
F(high) = 36023049.126137726 J/m3 > 0
```

These endpoints were queried with real phase evaluators; no extrapolation.
Positive caloric derivative in the frozen model means no pressure root in this
legal interval. The negative energy itself is not the criterion: many initial
negative-energy liquid states pass. Recovery checks the actual legal EOS image.
Conservative KT mixing plus scalar timestep bounds does not guarantee membership
in that image. This requires update-level protection, not a face-only theta limiter.

## 8. Failure C: HARD boundaries are not an invariant physical domain

All initial liquid states at p=0.05/12 MPa or T=285/320 K are legal. Prescribed
neighbor velocities +/-10 m/s create local compression/expansion. At the central
cell with U=0, obtain rhoDot from mass flux and eDot=(EtDot-e*rhoDot)/rho.
Use real, legal-state EOS derivatives:

```
pDot = dpDrhoE*rhoDot + dpDeRho*eDot
eRhoT = (p - T*Cv/beta)/rho^2
TDot = (eDot-eRhoT*rhoDot)/Cv
```

| Boundary and outward loading | pDot (Pa/s) | TDot (K/s) |
|---|---:|---:|
| T=320 K, compression | 9.79305e9 | +2101.926 |
| T=285 K, expansion | -1.24857e10 | -2297.680 |
| p=12 MPa, compression | +1.24865e10 | +2332.218 |
| p=0.05 MPa, expansion | -1.08150e10 | -2152.708 |

The local thermodynamic tangent points out of the HARD rectangle. Hence no
generic positive acoustic CFL can make that rectangle invariant under arbitrary
admissible initial loading. Scan dt fractions 1,0.1,...,1e-6: scalar bounds remain
valid, central real recovery fails throughout. This is diagnostic, not a solver
retry algorithm. Infinitesimal roundoff/tolerance acceptance is not a practical
physical advance. EOS coverage/controlled domain-exit policy must be explicit;
neither extrapolation nor artificially modified energy is acceptable.

## 9. Conservation, source balance and contact accuracy

R0 face states pass contact pressure checks while recoverable; maximum face/cell
errors and velocities are recorded in summary.json. Across 1098 accepted steps:
maximum normalized conserved-integral drift=4.60103e-15; maximum alpha integral
change minus cumulative physical source=8.52651e-14. Per-trial assertions also
cover rejected proposals; their conservation is not a claim of admissibility.

Each face is used once with opposite signs in adjacent cells. mG,mL,M,Et,mYi
remain conservative. Alpha is nonconservative and has a separate source ledger.
No reconstruction changes cell averages and no failed trial is committed.

## 10. Timestepping cost and actual recovery work

6440 sampled cell constraints: first and requested-final step (failed runs only
first). 1503 finite dtAlpha/dtAcoustic ratios, 4937 unbounded ratios. Nearest-rank
all-sample statistics: min=9.658813, median=infinity, P5=2569.1503,P95=infinity.
Finite-only median=31503.56,P5=53.2331,P95=3.32205e7.

All 1119 attempted global steps were controlled by acoustic CFL=0.15. This does
not contradict M5C.1's unsafe mass-CFL counterexample: that counterexample uses a
different stencil/timestep condition. The present mild gradients do not establish
production alpha cost or a high-order positivity theorem. R0 stencil faces made
590528 gas and 778088 liquid evaluator queries; no R1/R2 cost comparison exists.

## 11. Why no high-order or coupled limiter is claimed

Per user section 3, failed R0 prohibits proceeding to high-order acceptance.
R1 shared-theta and R2 thermodynamic candidates remain NOT STARTED. Their
analytic face bounds, N-1 species closure, EOS theta search and production
selection therefore remain gates, not inferred from R0.

User outcome B applies: update protection is REQUIRED. However standard
Flow+lambda*(Fhigh-Flow) assumes Flow's update is an admissible anchor. Here Flow
itself fails. Setting lambda=0 cannot fix it. A coupled flux limiter is not
implemented, and no guarantee of a positive feasible lambda is asserted.
Post-update recovery is a transaction gate, not a repaired numerical solution.

## 12. Exact next work within M5C.2

1. Audit trace-presence semantics against actual phase density ratios while
   preserving every nonzero partial mass; establish a contract compatible with
   conservative transport. This report does not change the frozen M6A2 code.
2. Separate numerical update defects from physical HARD-domain exits. Define
   an EOS/presence path admissibility bound or alternative proven low-order
   update, with controlled failure when no forward admissible step exists.
3. Re-run all frozen R0 stress tests. Only after an admissible low-order anchor
   exists, implement R1 common-theta and assess R2/legacy reconstruction.
4. Test higher-order updates and, if necessary, implement a shared conservative
   correction including phiPhys/divU/source compatibility. Re-run the full gate.

No stage is skipped. M5C.3, M8A and M6B remain unexecuted.
