# M6B.1-EOS3-UB1-DOMAIN-CLOSURE

日期：2026-10-05（北京时间）。证据目录：`fitting/integration/m6b1_eos3_ub1_domain_closure_v1/`。

## 1. UB1 status

**PARTIAL / EOS_MODEL_RANGE_BLOCKER / STOP。** 原 anchor153/cell27 和全部 133 个 upper-domain 事件已关闭，CLASS A 成立；同版本 active v3 已修订并安装 HARD 275–400 K，完整属性、恢复及 M6B.0 新鲜回归通过。原 shock 在 anchor174/cell49 出现新的 275 K 下界公共根域失败，故“无新 EOS blocker”完成门槛不满足。不报告 EOS3 COMPLETE。

## 2. Exact anchor153 state

冻结定位：anchor153、cell27、attempt0。time=`0.00018437909654840973`，bits=`3f282abc6125ca75`；attempted dt=`1.2050921343033288e-06`，bits=`3eb437d4d06feded`。与 anchor 元数据、rejections、main_0 和 first_candidate 核对通过。

| 项 | binary64 数值 | bits |
|---|---:|---|
| P2hi / Q0 | 1.8383391125689919e-21 | `3ba15cd4cbef135c` |
| P2lo | 0 | `0000000000000000` |
| Q1 | 13.805368585421387 | `402b9c59456f38a6` |
| Q2 | 1.2953725683309386e-18 | `3c37e53958083e5c` |
| Q3 | 463.98892507319408 | `407cffd2a318f902` |
| Q4 | 0 | `0000000000000000` |
| Q5 | 0 | `0000000000000000` |
| Q6 | 4297935.5019778293 | `41506533e020679e` |
| Q7 | 0 | `0000000000000000` |
| Q8 | 3.147624037476076 | `40092e5582e8817c` |
| Q9 | 10.657744547945311 | `402550c3e4b51847` |

`capture_gate.json` 与 `EOS3_UB_133_INDEX.csv` 保留全部 actual Q/P2、time、dt、bits 和捕获文件 SHA。捕获 CSV 的 cell=0 是导出单元素向量的局部编号；物理 cell27 来自事件索引，不混淆二者。

## 3. Energy ledger

Et=`4297935.5019778293`、kinetic=`7797.1740217759225`、Eint=`4290138.3279560534` J/m³。从冻结 committed Q 和左右 face flux 按原 explicitTrial 公式独立重算 Q1、Q2、Q3、Q6，全部 bit 相同；`(V*Et-dt*(EtPhiR-EtPhiL))/V` 直接复现总能量。另一动能公式的差值为 0。

恢复根上 mG·eG=`4290138.3279560534`、mL·eL=`8.7652256259696994e-14` J/m³，原 binary64 residual=0。液体 offset 贡献=`4.7829035345943065e-13` J/m³，保留求值，即使加到主能量时被 binary64 舍入淹没。species mass residual=0，YG=`[0,0.22799999999999998,0.772]`，原冻结 JANAF Es 与 C_L 未变。没有发现该候选的 Et 构造、动能扣除、species ledger 或能量参考不一致。此结论限于捕获状态和原公式，不宣称一般 PDE 精度。

## 4. Required anchor153 root

先在独立 shadow400 中使用原 gas evaluator、同一 Gibbs potential 和冻结 R1 求根，再用安装后的 active factory 新鲜求根。两者输出逐字段相同，保留 trace liquid，未夹温、删相或修改容差。

## 5. Root TL/p

p*=`3252798.006604576` Pa；TL*=`330.16785059318408` K；TG*=`817.05540649965621` K；cL=`1132.9342669620962` m/s；cA=`564.18400446979979` m/s。normalized residual=0，iterations=5。原 330 K 上端 F(hi)<0；shadow400 公共区间扩大后括住根。

## 6. 133 accounting

main=4、probe=129、total=133、missing=0、duplicate event keys=0、Q/P2 bit mismatches=0。实际 binary64 payload 有 74 个不同状态，另外 59 个事件重复某个 payload，来自极小 dt 附近的实际捕获；没有删除这些事件，也没有把 payload 重复计作新增独立状态。所有 133 事件均逐项分类和恢复。完整索引包含最终 active 结果列；published probe stream 的 72 完整行不作为 129 capture 的替代。

## 7. Required TL envelope

133 个根的 TL 范围：`330.0000000000034–330.1678505931841 K`。400 K 足以涵盖这组已捕获 upper-domain 状态，最低值接近旧边界并保留实际 binary64 结果。

## 8. Required p envelope

p 范围：`3252798.006604576–3255426.3117808746 Pa`。rhoL：`704.6428808886717–704.7735677690077 kg/m³`；alphaL：`1.5986249413774786e-21–1.838339112568992e-21`；mL：`1.1266686034591265e-18–1.2953725683309386e-18 kg/m³`。

## 9. Classification A–D

原 133 状态全部 **CLASS A / ARTIFICIAL UPPER DOMAIN LIMIT**：根位于 330<TL≤400 K、压力合法，同一 potential 新鲜通过误差预算。CLASS B/C/D 数量为 0，指本轮原 upper-domain family。该数值 CLASS A 不改写历史固液相证据的 CLASS D。

## 10. Final v3 HARD domain

active `ndecane_gibbs_v3`：HARD p=0.05–12 MPa、T=275–400 K；NORMAL p=0.1–8 MPa、T=295–305 K。HARD 只表示数值 EOS admissibility，不表示固液相稳定性证书。当前域是已安装的数值候选，EOS3 未达到完整冻结门槛；未创建 v4。

## 11. Source delta

三个源码文件及一个 metadata 文件改变：v3 header 的上界检查/反演搜索端点 330→400；liquid evaluator 的压力区间上界温度 330→400；dynamicObservation 增加只读 TL>330 K cell/质量输出；metadata 更新域和阶段状态。`active_extension.patch` 为准确补丁，`source_before/` 保留扩域前源码和 metadata；`runtime_before/` 保留原 executable 和两库。

degree8×8 potential、81 系数、导数、反演算法、压力域、C_L、R1 residual/derivative/tolerances、P2、KT、species、temporal driver、connectedDt/retry/Time 均保持。只修改反演的数值域端点，不重写算法。隔离诊断副本沿用既有只读 SR1 捕获插桩，其结果与 active 轨迹核对，不安装为 active solver。

## 12. Coefficients/C_L

三版 coefficient SHA 均为 `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`。C_L=`369229.9537234281 J/kg`；energy_reference SHA=`ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`。没有 refit 或 runtime CoolProp；CoolProp 8.0.0 仅用于离线误差比较。

## 13. 330–400 property regression

fresh shadow 和 fresh active native 各验证 34,001 点，p 覆盖 HARD，T 步长 0.25 K。rho/e/h/Cp/Cv/beta/c/dpDe/dpDrho 全部通过原 NORMAL/BUFFER 预算，无 property/inversion failure。最终 active 上段最大误差如下，未放宽预算：

| 属性 | 最大误差 | BUFFER 预算 |
|---|---:|---:|
| rho，relative | 9.9120211e-6 | 0.005 |
| e，absolute J/kg | 12.51689734 | 200 |
| h，absolute J/kg | 12.44512450 | 200 |
| Cp，relative | 0.0004027993 | 0.02 |
| Cv，relative | 0.0013931651 | 0.02 |
| beta，relative | 0.0063069975 | 0.02 |
| c，relative | 0.0027928845 | 0.01 |
| dpDe，relative | 0.0062674686 | 0.02 |
| dpDrho，relative | 0.0055725356 | 0.02 |

## 14. Full EOS regression

fresh active：275–285 K 9,801 点；285–320 K 3,721 点；320–330 K 3,721 点；330–400 K 34,001 点；总计 51,244 点。九属性 PASS，rho,p 与 rho,e 反演 unexpected failures=0；最大 inverse T 差=`1.8189894035458565e-12 K`、最大 inverse p 差=`4.192814230918884e-6 Pa`。旧域九属性与保留的 v2 direct PT mismatch=0；274.999 K 和 400.001 K 仍严格拒绝。

## 15. 133 active R1

133/133 PASS，stillNoRoot=0、otherFailure=0，各 5 iterations；完整 residual、p、TL、TG、cL、cA 见 `active133_recovery.csv`。`active133_gate.json` 验证 present cL>0、域合法、shadow/active 全字段相同。原 R1 源码及默认容差没有改变。

## 16. lower130

fresh 130/130 PASS；最大 normalized residual=`8.570596875729471e-16`。p/TG/TL/cL/cA 对 prior active-v3 差值均为 0。

## 17. old184

fresh 184/184 PASS；最大 normalized residual=`8.611343140285418e-16`，最大 p 差=`1.3969838619232178e-9 Pa`；TL 差为 0，其余差仅 binary64 舍入量级。

## 18. accepted6200

fresh prior5500+neighbors700=6200/6200 PASS；无新非法状态。最大 normalized residual：prior5500=`9.824406182180786e-13`，neighbors700=`2.0258035338020126e-13`，均在原恢复判据内。未删相、归一化或更改 P2 payload。

## 19. anchor153 active result

最终 active exact anchor153/cell27 恢复 PASS：p/TL 同第 5 项，residual=0、iterations=5。这是冻结原候选的直接关闭证据；新 replay 超过旧失败点，不假设新旧 PDE 轨迹每个 candidate 都相同。

## 20. M6B.0 rerun

原十个 serial micro-cases 全部正常退出，314 项原验收检查 PASS。accepted R1 failures=0，conservation、species closure、uniform P2 exact 和 trace presence 合同通过。无 clipping 或 normalization。fresh build：0 errors、3 条既有 misleading-indentation warnings、unexpected warnings=0。

## 21. Shock replay

原 `shockInterface_100` 输入 17 文件 SHA 一致，active 串行有界重放已执行。隔离诊断与 active 完整 history 的前 175 行（step0–174）逐字段文本一致。诊断在首个新 explicit rejection 捕获后外部 SIGTERM；active 在同一新 blocker 的首次 retry 后外部 SIGTERM，最后完整 accepted step175，time=`0.00021042581919870364 s`。未达到 endTime；两次 −15 是有记录的观察器停止，不报告正常完成。

## 22. First new blocker

anchor174/cell49/attempt0，time=`0.00020968603136877972 s`，trial dt=`1.2050921343033288e-6 s`。最终 active native exact-Q 核对再次返回 `NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN`，iterations=0。

alphaL=`3.4655813536316512e-9`，mL=`2.588104550168383e-6 kg/m³`，rhoL=`746.8024224727136 kg/m³`。公共合法 p 区间：`3352159.0373128895–12000000 Pa`；TL(lo)=275 K，TL(hi)=`282.80140663418359 K`；F(lo)=`+195059.59186974261`、F(hi)=`+28771554.884417579 J/m³`。正导数原 residual 在合法区间没有根，下端受 275 K 限制，分类 **EOS_MODEL_RANGE_BLOCKER / STOP**。

新候选 Q/P2 bit 验证和 Q1/Q2/Q3/Q6 flux 更新复算通过。未求解 TL<275 K 的液体 root。gas-only diagnostic p=`3283933.3980672932 Pa` 不是 mixed candidate 的恢复结果，不宣称域外所需 TL 的具体值。

## 23. Timestep behavior

到新阻塞前 accepted dt 保持约 `1.2050921343033288e-6 s`；active step175 首次 retry 后 accepted dt=`7.3978782992392903e-7 s`。已观察区间没有 time nonprogress。本轮因新的 EOS 范围阻塞停止，不能判为仅剩 TEMPORAL_POLICY_BLOCKER。未改变 dt growth/reseed/floor、nextafter、t+dt guard、connectedDt 或继承逻辑。

## 24. Low/high-T diagnostics

以下来自 active 已接受状态的只读输出，均不反馈解：

| 统计 | TL<285 K | TL>330 K |
|---|---:|---:|
| summary / cell rows | 176 / 659 | 176 / 82 |
| 最大 cell count | 19 | 5 |
| 最大积分液体质量 kg | 6.662149647567536e-6 | 2.3592949198273606e-19 |
| alphaL range | 2.6731225649745397e-24–7.412052859669536e-7 | 8.191983844618542e-25–3.023618461313017e-20 |
| mL range kg/m³ | 1.975812090260504e-21–0.0005483176430315955 | 5.77272961763513e-22–2.1301893458554226e-17 |
| TL range K | 275–284.99649938488824 | 330.0059672727802–334.4837710729761 |

积分质量采用 Σvolume·mL；不设置删相阈值。整个 accepted 区间 minimum TL=275 K、maximum TL=`334.4837710729761 K`。单液相数值延拓与固液相物理认证仍分开。

## 25. Conservation

active shock 最大 scaled conservative discrepancy=`8.894249781274648e-16`；最大 species closure=`1.7101421570792262e-16`。十个 M6B.0 算例均满足原 conservation<1e-11、species closure<1e-12 阈值。新阻塞不通过能量/物种修补绕过。

## 26. Executable/library SHA

扩域前的副本和逐文件 SHA 已保存；最终文件在所有测试后哈希仍相同：

| 产物 | 最终 SHA-256 |
|---|---|
| active executable | `049e21b7c0533b5bb2566dcfce74b68530510a02a3a91bb95958639987b1481c` |
| libRhosprayLiquidEOS.so | `9f1244ed9954a4014498abcc7e435aa7aecdfa4695b9c149e09b7ef191cff73c` |
| libRhosprayFiveEqThermo.so | `c7b74a206e0876283d91b342dcff4732631f4a9a162f1502d8f543790e820fe6` |

扩域前 executable SHA=`50c19e1be182bec08cee0a91d77ab44dee5e654ddf143ef86fc5082e617fcecd`；两个扩域前库 SHA 见 `installed_before.sha256`。扩域前 v3 header SHA=`b02e23db1872a19428c435e3450d103f983c9fdbba7535410e2db8dc43b6610d`；metadata SHA=`414d70d330d55cc3cc233dcac8fbb28f687f6e348e7b72442092e896adf6cd84`。

## 27. Foundation/project hashes

Foundation 6,717 原源码＋19 native parcel 文件本轮前后 fresh SHA 全部 PASS。115 库中仅两个授权自定义库改变，其余不变。71 个选定 active 子目录源/metadata 文件核对，变化恰为第 11 项四文件；R1/P2/temporal 原源码不变。1,320 项既有 EOS3 证据及日志核对保留；里程碑仅追加本轮记录，旧字节前缀保留。该范围不冒充全项目 37,020 项重新扫描。

扩域后 v3 header SHA=`686df0e43b92ce2404b72885b40ae47766ec67b132d50ad4cb51371957c74ce1`。原 EOS3 checkpoint SHA 仍为 `67933d6c153845d54ca9120eeba72d0c7b756ad8470d75d9c9dbe8d5de503137`。完整前后文件哈希和准确 patch 见 `project_protection.json`、`active_extension.patch`。

## 28. EOS3 COMPLETE?

**NO。** exact anchor153、能量账本、133 分类/包络、CLASS A、275–400 安装、相同 coefficients/C_L、新鲜属性、133 active R1、历史恢复、M6B.0、bounded shock、P2/R1/temporal/Foundation 保护均满足；**no new EOS domain blocker=false**。`EOS3_UB1_stop_gate.json` 明确保留 EOS3Complete=false。

## 29. TD1 status

**REQUIRED / NOT EXECUTED**。本轮未实施时间策略修复；当前新 EOS 范围失败尚未闭合，不能以纯时间策略原因打开 TD1。

## 30. Next permitted milestone

需要对新 lower-domain/model-range blocker 单独作 owner scope decision。当前没有自动获准的后续实现里程碑；不继续扩大到更高温度或更低温度，不创建 v4，不删 trace phase。只有 EOS domain gate 闭合后，另轮处理 TD1。生产 restart 保持 NOT CERTIFIED，helper 未作为本轮前置。

## 31. M6B.1/M6B status

**PARTIAL / STOP**。本轮不认证完整 shock、remaining wave ladder、high-Mach、M6B.2、active DPM、MPI active solver 或 production CFD。

## 32. Milestone matrix

| 阶段 | 状态 |
|---|---|
| M6B.0 | COMPLETE / FROZEN；final active v3 十例新鲜重跑 PASS |
| SR1 | COMPLETE / DIAGNOSIS ONLY |
| EOS1 | COMPLETE / DESIGN QUALIFIED（历史范围） |
| EOS2 | PARTIAL / STOP（历史）；v2 PRESERVED / NOT ACTIVE |
| LB2 Part A | COMPLETE / FROZEN |
| LB2B / LB2C | PHYSICAL CERTIFICATE DEFERRED / NOT CLOSED |
| historical physical class | CLASS D / PRESERVED |
| PHASE-DEFER | COMPLETE / POLICY FROZEN；未来 5% 只适用 Tmelt evidence |
| v3 | ACTIVE / HARD 275–400 / PROPERTY-REGRESSION QUALIFIED / SINGLE-LIQUID CONTINUATION / NOT PHASE CERTIFIED |
| 原 UB 133 事件 | CLASS A / CLOSED |
| UB1 / EOS3-NUMERICAL | PARTIAL / EOS_MODEL_RANGE_BLOCKER / NEW LOWER 275 K / STOP |
| TD1 | REQUIRED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL |
| M6B.2 | NOT AUTHORIZED |
| production restart / CFD | NOT CERTIFIED |

本轮按新 EOS 模型范围阻塞条件 STOP。
