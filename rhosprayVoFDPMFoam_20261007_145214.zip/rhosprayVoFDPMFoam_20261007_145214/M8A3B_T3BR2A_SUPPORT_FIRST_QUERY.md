# M8A.3B-T3B-R2A — Support-first carrier query audit

2026-10-03; Foundation OF7 本机离线候选。

# 1. R2A status

**PARTIAL / QUERY CORE PASS, COMPLETE NATIVE TRACKING BRIDGE OPEN.** 本轮只执行 R2A。独立候选查询路径和所有已实现测试通过；完整 SprayParcel 调用链的懒构造和反弹后首查询尚未闭合，因此不标 COMPLETE。

# 2. Original eager-thermo blocker

本机 Foundation OF7 ThermoParcelTrackingDataI.H 的构造列表无条件求 cloud.thermo().thermo().Cp() 和 kappa()，早于 setCellValues / 最终支撑拒绝。旧 R2 与冻结 T3A 仍保持原实现。新查询路径不构造该 eager trackingData。

# 3. GasSupportMap architecture

immutable map 持有 committed Q、P2、边界 Q、phase/support certificate 与 generation。ABSENT 槽位没有 gas 对象。地图准备对 PRESENT 做冻结恢复并缓存合法导出状态；纯液体恢复 gasCalls=0。publication EOS 调用与 parcel preflight/materialization 的计数严格分开。

# 4. Phase authority

依据冻结 P2 v2 与 mG 判断 PRESENT / TRACE_PRESENT / ABSENT / INCONSISTENT。alphaG=mG=0 为精确 ABSENT；不以全场 rhoG 槽位判断。alphaG/mG 不一致状态拒绝发布。无 epsilon、clipping 或相创建。

# 5. Preflight API

CarrierQueryOwner::preflightSupport(position,cell,required,face) 只访问几何、原生系数、支撑证书、所有者与 generation；不读取 gas rho/T/Y，不调用 Cp/mu/kappa。结果 context 绑定 owner/map/generation/position bits/cell/face/property mask。

# 6. Materialize API

materializeCarrier 首先验证 map identity/generation/context validity/位置与拓扑；全部通过后才读取合法 gas 导出量、计算需要的 native transport，并调用 native U interpolation。旧 context 在任何物性访问前抛出 STALE_QUERY_REJECT。

# 7. Native stencil discovery

复用冻结 NativeSparsePointSupport 的原生几何 basis/operator 与 cellPointWeight。没有邻居近似、cell-only U 替代、删除 contributor 或重归一化。实际 U 仍由 Foundation OF7 interpolationCellPoint 执行。L10_SHARP 的 phase authority/scalar 与冻结 T2 一致；21000 个当前位置 U 查询与独立 native oracle 一致。T2 wholeCell 是整单元位置并集，与当前位置查询有73个预期范围差异；没有原整单元合法而当前位置非法的逆转。

# 8. Property requirement mapping

Rho/P/T/Cp/Mu/Kappa/Y/U 位掩码与内部依赖。孤立 SphereDrag kernel 的 mask 为 Rho|Mu|U；完整 Thermo/SprayParcel.calc 的需求更大，不可用此 mask 冒充。八模型需求及尚未接通的调用链见 M8A3B_T3BR2A_PROPERTY_AUDIT.md。

# 9. Pure-liquid result

精确纯液体全域地图创建成功，无 gas 对象；首次查询受控拒绝。没有创建假的 rhoG/TG/YG/Cp/mu/kappa，没有 nearest/previous-state fallback。

# 10. Pure-liquid thermo-call counters

preflight=1, rejected=1；rho=p=T=Y=Cp=mu=kappa=U=models=pointBuilds=0。该纯液体地图的 frozen recovery gasCalls=0。计数文件 runtime_gate_v4/pure_liquid_counters.json。

# 11. Trace-gas result

alphaG=1e-20，mG=alphaG*rhoG，合法 EOS 状态允许查询；P2 hi/lo 与 Q authority 查询前后不变。不存在把 trace gas 当 absent 的截断阈值。

# 12. Mixed-cell result

alphaL=.1/.5/.9，全 stencil gas-valid 时允许查询，rho/Cp/mu/kappa 合法。mixed 不等同 invalid。测试为明确的 synthetic 状态，不是 CFD 解。

# 13. U-stencil-invalid result

自身 scalar gas-valid 而原生 U stencil 涉及 ABSENT 的排除带单元，被 Drag 查询拒绝。该次 query 的 rho/p/T/Y/Cp/mu/kappa/U/model 调用增量全部为 0。

# 14. Scalar-support result

同一排除带单元仅请求 Rho 时合法并读取一次 rho；当模型需要 U 时必须验证整个 U stencil，不允许只检查自身 cell。

# 15. Exact gas-absent crossing

实际 native particle::track 几何端点进入 exact ABSENT，随后首个原生 drag 查询在零气相物性/model 调用下拒绝。此几何端点探针不意味着允许物理 parcel 穿过纯液体；逐段查询版本更早在排除带拒绝。

# 16. Runtime reject point

实际 particle::trackToCell 分段跟踪后、SupportCheckedTrackingData materialization/model 前拒绝。dtLarge=1e-5 s 第二段检测 EXACT_GAS_ABSENT 支撑；此前合法段已调用一次实际 SphereDragForce kernel。非法段没有新增物性/U/model 调用。

# 17. Reject/discard/retry result

大步 trial parcel 和 force-event vector 独立，拒绝后丢弃；committed anchor 逐位不变；从同一 anchor 以 dtSmall=1e-6 s 重试通过。不删除/冻结/手动移回 parcel，不改变 alpha，不定义界面交互。

# 18. Canonical equality

committed Q/P2+generation、native parcel 17 位序列化、force event bits 的 directSmall 与 retrySmall canonical bytes 完全相同；10 个未来合法步 (dt=1e-8 s) 继续一致。该证书不是完整 cloud/model graph codec。初始 v1 的 1e-7 未来步在第六步再次越界，被正确拒绝；失败记录保留。

# 19. Cp lazy-evaluation result

Rho-only 和独立 Drag query 均不求 Cp。只有 Cp 请求或 native kappa 内部依赖时求 Cp。新 mixed-domain path 无全场 Cp 构造。native 全气域 reference 才允许构造全场 Cp 用于比较。

# 20. mu lazy-evaluation result

新路径没有全场 mu。需要 Mu 时，在已认证 own-cell composition/p/T 上调用实际 Sutherland::mu；Rho-only/无效支撑不调用。

# 21. kappa lazy-evaluation result

新路径没有全场 kappa。需要 Kappa 时才调用 native kappa，并计入其内部 Cp 调用。无效支撑和独立 Drag query 均为 0。

# 22. Species lazy-evaluation result

只有 Y 或 transport 依赖才从合法 gas Q/mG 构造 Y；按冻结残余物种顺序计算第三物种。无 whole-mesh normalization、无纯液体 composition 占位。

# 23. Pressure semantics

p 是冻结 isobaric five-equation recovery 的共同压力；请求 p 的 gas query 仍必须有合法 gas support。本轮不生成新的压力解，不改 EOS/pressure recovery；壁面或碰撞仅需共同 p 的独立接口不可被误判为 gas thermo。

# 24. Velocity semantics

commonU=M/(mG+mL)，纯液体也物理有效。它是唯一全场 candidate 插值存储，并不是假 gas velocity。完整 gas stencil 认证后才构造 native cellPoint 插值；没有把液相支撑掩去。

# 25. Generation safety

staged/discard 不发布；commit n→n+1；旧 ticket 的读取在物性前失败，位置 bit/cell/face 改变亦拒绝。固定网格以外路径显式不支持。

# 26. Cache semantics

native U point cache 按 generation 管理，每次 commit 清除；几何 stencil 为固定网格元数据。要求 mask 与 pose 随 query context 固定；不缓存 previous gas physical state。100 次 rebuild 每次得到当前 generation。

# 27. Staged QTrial support publication

冻结 adapter 的非零示例 increment 生成 QTrial 后 prepare/support-map validation，再串行 quiescent publish。P2 和 mL 不变；pure-liquid 非零 gas source 请求拒绝。该 increment 是 adapter 合约测试，不宣称由原生 drag 自动产生。

# 28. Boundary contributor result

实际 inlet/outlet/wall/empty stencil metadata 纳入 map；原生非零 boundary contributor 独立设为 ABSENT 时查询在物性前拒绝。测试使用冻结 T2 diagnostic boundary-owner Q oracle；未重新定义 production BC。empty 42000 faces 的 commonU stored values=0。未来 nozzle=FUTURE_PATCH_DEPENDENT。只给现有底壁重叠面附加T2元数据，不创建patch；实际非零 pending contributor 在物性前拒绝，未使用该boundary的 scalar查询仍允许。

# 29. Injection query timing

新 native parcel 在 ABSENT 出生位置构造/bookkeeping 后，第一次实际 drag carrier query 在零物性/model 调用且 parcel bytes 不变时拒绝。完整 ConeInjection→SprayParcel 初始化链尚未装入新 packet，故这部分 OPEN。不是 gas source 测试。

# 30. Rebound query timing

原生墙模型只需几何/velocity，旧 R2 实际 rebound 回归通过；新 query 的 pose-change ticket guard 已通过。原生 rebound 后第一 mixed-domain query 的完整联接探针尚未实现；这是 R2A 未完成项，不以旧全气域回归代替。

# 31. ORourke impact

NONE。本轮前后本机原生 .C/.H SHA-256 一致，全部 R2A native source snapshots 与当前 OF7 文件一致。碰撞/cleanup 的既有 native limitations 不修复、不加气相补偿、不宣称严格能量守恒。

# 32. All-gas native equivalence

21000/21000 单元，rho,p,T,Cp,mu,kappa,三种 Y、三个 U 分量，共252000项浮点位比较全部相同；maxDifference=0。状态 p=188330.307 Pa,TG=400 K,TL=300 K，U 为 synthetic 非均匀 common velocity。

# 33. T2 1725880 comparison result

冻结原生 stencil/operator 比较重新运行1725880项，0 failures，maxError=3.84593e-16（原指标）；另有新路径全气域逐位相等与L10_SHARP 相权威/scalar一致及21000同位置原生查询一致。wholeCell并集与当前位置的73个差异已分别记录，不谎称二者等价。

# 34. Performance

仅 harness microbenchmark：几何 discovery 0.069987 s；map prepare 0.059548 s；native eager reference setup 0.003215 s；21000 native tuples 0.005061 s；support-first tuples 0.017906 s；其中 preflight 0.009673 s、materialize 0.005423 s、native point rebuild 0.000406 s。样本非相同工作量：support-first还含guards/bit assertions，不能当生产加速或公平纯物性成本结论。

# 35. Registry result

100 次 generation/publication/query lifecycle，registry values=[21]，全部相同。仅所测串行固定网格 harness。

# 36. Memory result

100 次生命周期 RSS resident pages：first=111804, max=111804, last=111804；见 query_lifecycle.csv 与 /usr/bin/time log.resource。无持续增长出现在所测后段；不宣称无限期 leak-free、全生产 cloud 或 MPI 内存认证。

# 37. Source/energy regression

9288 checks，0 failures；8份 energy goldens 与 m8a_v1 逐字节相等。冻结 adapter/energy convention 没有修改。

# 38. M8A.3A regression

6375 checks，0 failures；A/B/C 各2125。

# 39. T3A regression

64395 checks，0 failures；A/B/C 各21465。原冻结 carrier owner 仍保持原合法全气域能力限制。

# 40. P2/R1 regression

105775 checks，0 failures。不变更 precision/reconstruction/flux 激活。

# 41. Temporal/restart regression

9663 checks，0 failures。没有替换原 transaction restart 编码。

# 42. R2 existing-event regression

旧不可变 binary 重放：core A/B/C 各3729，共11187；collision A/B/C 各3415，共10245；总21432，0 failures。注入/stochastic/drag/atomization/KHRT/ORourke/rebound/output 等既有检查没有回归；这不是本轮恢复 R2 closure，也不是新 packet 的完整八模型验收。

# 43. Active solver impact

NONE。protected_before 14424份旧文件 SHA 全相等；old R2 55348份 SHA 全相等。仅新增 tests/fiveEqDPMCarrierQueryR2A、独立 stage、审计文档，MILESTONE_STATUS 仅追加当前状态。active Make/files/options 亦受保护。

# 44. Production mesh/BC impact

NONE。300_2D 96份文件 SHA 全相等；没有创建 nozzle patch、改 empty、初始化生产 alpha 或运行任何 CFD。

# 45. Whether R2A COMPLETE

**NO。** 查询核心 PASS；完整 native-compatible trackingData、ThermoParcel surface/source-correction 接口及 post-native-rebound mixed query 仍 OPEN。不能由孤立 SphereDrag 与 geometry probe 推导 complete SprayParcel path安全。

# 46. Whether R2 may resume — NEXT ROUND ONLY

本轮不恢复。下一轮先补 R2A 剩余 bridge/query probes；R2A全部通过后才允许下一轮回 R2，集中验证 pure-liquid full gate、runtime retry、combined transaction、八模型 closure。不要重做已有 native event physics。

# 47. T3B status

PARTIAL。R1/R2与本轮R2A的能力范围分开记录；没有 full-serial-safe 声明。

# 48. T3/T4 status

T3 PARTIAL；T4 NO。禁止由本轮局部成功自动升级。

# 49. M8A/M6B permissions

M8A PARTIAL；M6B.0 NO；M6B.1 NO。active cloud.evolve、two-phase KT activation、CFD仍未执行。

# 50. Updated milestone matrix

见下表。按用户要求到此 STOP，不恢复 R2、不执行 T4/M6B/CFD。

| Milestone | Status |
|---|---|
| M8A source/energy | PASS / FROZEN |
| M8A.3A | COMPLETE |
| T1 | COMPLETE |
| T2 | COMPLETE / STRICT-SUPPORT FEASIBLE |
| T3A | COMPLETE |
| O2D | COMPLETE / native ORourke first activation |
| T3B-R1 | PARTIAL |
| T3B-R2 | PARTIAL / FROZEN THIS ROUND |
| T3B-R2A | PARTIAL / query core PASS, complete tracking bridge OPEN |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NO |

## Reproducible evidence

`fitting/dpm/m8a3b_t3br2a_v1/runtime_gate_v4`: final273263/0, exact source snapshots/build_sources.sha256/executable.sha256. Initial compile attempt and runtime_gate_v1 failure kept. runtime_gate_v2=252260/0; v3 adds birth query and geometry-cost instrumentation (252261/0); final v4 adds21000 actual-position oracle comparisons and2future-boundary tests. The failed pre-report wholeCell-vs-position equality assertion is retained as investigation context; final criterion explicitly distinguishes those scopes. Source files/Make are new standalone target; active Make unchanged.

`independent_results_audit.json`, `protected_after_audit.json`, `native_collision_after.sha256`, and the property-audit document define evidence/scope. All source/case hash guards passed before this report/status append. No CFD.
