# M6A1b-2A reference-grid and validation separation

## Current authority — M6A1b-2A.3 (2026-09-30)

Overall **M6A1b-2A COMPLETE as a project domain/policy design gate**. Expected
physical screening is 0.188330–6.201421 MPa / 299.440696–301.200448 K;
approved PRODUCTION is **0.10–8 MPa / 295–305 K**; project HARD is
**0.05–12 MPa / 285–320 K**, absolute pressure and inclusive boundaries.
These design support limits do not predict guaranteed CFD extrema.
The former 0.180–6.250 MPa / 299–302 K proposal is historical and superseded.
See [current assessment](M6A1B2A3_ENVELOPE_HARDENING.md) and
[domain/failure policy](EOS_OUT_OF_DOMAIN_POLICY.md); the machine-readable
authority is `fitting/liquid_eos_domain_contract.json`.
M6A1b-2B is NEXT / NOT STARTED. Production model selection, final reference
training/holdout generation and solver energy-offset alignment remain open.
No active solver or CFD case changes were made.

The assessment CSV is assessment-only, not the final reference training set. Future candidates must certify NORMAL and BUFFER separately, using phase flags, caloric/acoustic data, derivatives, inversion and independent experimental checks.

## Historical audit (superseded status statements below)


**2026-09-30 gate update:** Base gas scenario approximately Mach 5.02, exit-plane topology and TL,in=300 K are locked. Nh=1 and proposed per-hole 1.09609 kg/s conflict with previous total 2.62583 kg/s; the proposed flow also implies approximately 2.124e4 m/s through a 0.3 mm hole at nominal rho=730 kg/m3. `pL_exit` is unknown. Reference-grid generation remains BLOCKED; no fitting or data generation begins.

No local CoolProp Python module was found in WSL, no REFPROP executable/data export or C10H22 reference-grid file was found in this workspace; **no grid was generated this round**. The selected *data architecture* does not depend on assuming either package is installed.

## M6A1b-2A.1 grid-readiness gate

The offline [operating-condition contract](fitting/OPERATING_CONDITION_INPUT_CONTRACT.md) now separates supplied base gas state, unspecified future `Ma>7` state, and still-null liquid pressure/temperature envelopes. Planned axes are `p` and `TL`, with an explicit single-liquid phase-validity mask. Plan three grids **after** bounds are approved: coarse exploratory coverage of expected states; refined calibration coverage at reference states and high property gradients; and safety-margin coverage for pressure recovery/bracketing. Final endpoints, spacing, node counts, phase masks and dataset generation are **BLOCKED** until `pL,in`, `TL,in`, final scenario and a declared margin/thermal-exposure policy exist. The current 5.509/6.201 MPa gas analytic shock scales do not supply grid endpoints.

## Layer 1: high-fidelity reference EOS

After the operating envelope is approved, pin backend name/version/build, fluid identifier/CAS, underlying equation citation (e.g. Lemmon–Span 2006), reference-state convention, unit system, generation script hash and date. Generate a grid over the approved **single-liquid** states, with explicit extension for numerical safety brackets. Per point store `p,T,rho,e,h,Cp,Cv,c` and preferably `Ks`, `(de/dp)|rho`, `(dp/drho)|e`, `(dp/de)|rho`, `kappaT`, `alphaP`, quality/phase and status. `data_type=reference-EOS generated`; preserve numerical backend version and fluid-file/hash. A Helmholtz potential provides derivative-consistent properties in principle; export QA must still check Maxwell/acoustic identities and inversion round trips. [CoolProp thermodynamic formulation](https://coolprop.org/fluid_properties/PurePseudoPure.html); [NIST REFPROP documentation](https://pages.nist.gov/REFPROP-docs/).

Do not populate a rectangular array by blindly interpolating across saturation, critical, vapor, two-phase-equilibrium or metastable regions. Record a phase-validity mask, saturation boundary and conservative distance-to-boundary guard. An imposed liquid phase does not prove equilibrium stability; REFPROP warns that forced phases can return metastable states. Table lookup must signal `invalid_phase`, `out_of_bounds` or `nonmonotone` instead of clipping. Above critical conditions, an explicit *dense-fluid* modeling decision is required; it is not silently classified as Eulerian liquid.

## Layer 2: independent experiment ledger

Retain the primary measured data and uncertainty from `C10H22_REFERENCE_DATA.md` in separate files with `data_type=measured`, DOI, author, table, p/T units and sampling method. Measured P24 rho/c, Z20 pressure-dependent c, R17/W19 Cp and high-pressure density series supply external validation. Never merge generated and measured rows under one label. If an experiment contributed to fitting the reference EOS itself, document that dependence and seek an independent holdout series before calling it external validation.

## Training/validation protocol

Fit a reduced production model to a *training* reference-grid subset. Evaluate dense-grid interpolation/fitting residuals as **agreement with the reference EOS**. Evaluate withheld reference states for interpolation/fit generalization, then independent measured rho/c/Cp (and later h/e differences) with published uncertainties. Compare energy-reference-adjusted h/e *differences* as well as absolute values only after the zero is declared. Record per-property MARE/RMS/max/reference-state errors and error maps vs p,T, plus derivative and inversion failure counts. A favorable rho/c fit cannot compensate for poor `e(rho,p)` or `(de/dp)|rho`.

## Corrected single-hole inputs — 2026-09-30 (current authority)

The user corrected per-hole flow to 1.09609e-4 kg/s and supplied exit static pressure 3 MPa (recorded as absolute). Nh=1, diameter=0.3 mm, internalNozzleIncluded=false, C10H22 TL,in=300 K and the supplied approximately Mach 5.02 gas state are confirmed. Total flow is therefore DERIVED as 1.09609e-4 kg/s; previous 2.62583 kg/s and mistaken 1.09609 kg/s are superseded, not alternative active inputs.

A=7.06858347e-8 m2 and nominal rho=730 kg/m3 imply U_nominal=2.124178 m/s. This is an offline mass/area sanity check, not an EOS density calculation or prescribed inlet velocity. Formal UL remains null. The injector input consistency gate passes; the earlier input-conflict sections are historical. Full liquid p/T envelope endpoints, thermal ceiling, phase validity and margins remain unapproved. Reference grid generation, EOS fitting and solver activation remain deferred. No active solver or CFD case is changed or run.

## M6A1b-2A.2 current authority — 30 September 2026

The current reference inlet, user-selected boundary control and provisional envelope are documented in M6A1B2A2_OPERATING_ENVELOPE.md. CoolProp 8.0.0 HEOS rho(3 MPa,300 K)=727.432960546 kg/m3 gives DERIVED reference U=2.1316743005 m/s; the mass-flow/300 K boundary lets pressure and velocity respond. User confirmed adiabatic mechanical scope. Candidate safe region 0.180–6.250 MPa × 299–302 K passes liquid-vapor phase checks, including reversible entropy paths and a limiting dissipative decompression path. Pressure and thermal engineering extrema remain provisional, so the overall stage is PARTIAL and M6A1b-2B does not start. The earlier null-input/conflict notes are historical where superseded. No active solver or case is changed.
