# KH SIGFPE expression audit v1

## Exact source and executable

Foundation7: `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src/lagrangian/spray/submodels/BreakupModel/ReitzKHRT/ReitzKHRT.C:161`.

```cpp
scalar lambdaRT = constant::mathematical::twoPi*cRT_/(KRT + vSmall);
```

Native ReitzKHRT template is instantiated in the **diagnostic executable**, not an out-of-line shared-library update. Exact executable: `tests/fiveEqDPMKHFPE1Native/testKHFPE1Native`; SHA256 `657222383cd67bbe48d9a4a0e2212b4715f35fc4883a0594fbd5379fa29dddd4`. Linked installed library hashes and resolved paths: `debug_executable.ldd`, `loaded_library_hashes.sha256`. Installed native source, lnInclude source and reference snapshot SHA match (`native_model_source.sha256`). Debug flags only: -O0 -g3 -fno-omit-frame-pointer -femit-class-debug-always. No installed library replacement.

## Operand and hardware evidence

| Operand | Value |
|---|---|
| twoPi | 6.2831853071795862 |
| cRT_ | 1000000000 |
| KRT | 0 |
| vSmall | 2.2250738585072014E-308 |
| numerator | 6283185307.1795862000000000 |
| denominator | 2.2250738585072014E-308 |
| real-arithmetic quotient | 2.8238097729461283931133406693564071587890154386471557138291400104741425737839486E+317 |
| double maximum | 1.7976931348623157e308 |

Gdb SIGFPE stops at native line161; instruction `divsd %xmm1,%xmm0`. MXCSR=0x1928 contains OE (overflow), with overflow unmasked. Denominator is positive, **not division by zero**. LambdaRT and later local variables have not been assigned at the trapped instruction: any raw debugger stack values for these variables are uninitialized and must not be interpreted as model output.

All34 scalar argument/vector components, coefficients and averageParcelMass recorded are finite. Arguments y,yDot,muc exist but are not used by this native update body; g/U/Urel vector components are captured. Positive d,d0,rho,mu,sigma,rhoc,tMom,averageParcelMass and nonzero mag(U); zero Urel/Urmag is legal mechanically. No negative sqrt/pow inputs or zero denominators before line161 in this trace. Native nParticle positive; ms=-great is the native newborn sentinel, not a diagnosed defect.

## Source-implied arithmetic domain

For finite positive cRT_ and finite positive KRT+vSmall, a finite double result requires

`KRT + vSmall >= abs(twoPi*cRT_)/DBL_MAX`.

For this CRT the required denominator is `3.4951378437904596987610694499335983341675580584159520131619475853265368135782805E-299`; observed is2.2250738585072014e-308. At KRT=0 the arithmetic upper bound on CRT is approximately0.6366197723675813. This is a **conditional representability bound**, not a recommended parameter or a published physical KH coefficient limit. No parameter changed.

The exact fixture uses CRT=1e9. At finite zero acceleration, gt=0 → helpVariable=0 → KRT=0. Its fixed coefficient violates this expression's finite-output domain. The native vSmall protection avoids exact division by zero but cannot prevent overflow of an arbitrarily large numerator.

## Before-call operands (17-digit records)

| Argument | Value |
|---|---|
| dt | 2.9999999999999997e-06 |
| g | (0, 0, 0) |
| d | 3.9922177082177593e-08 |
| tc | 0 |
| ms | -4503599627370496 |
| nParticle | 2296664553.4200964 |
| KHindex | 1 |
| y | 0 |
| yDot | 0 |
| d0 | 3.9922177082177593e-08 |
| rho | 725.21967199798883 |
| mu | 0.00084834571996310901 |
| sigma | 0.023208780744580066 |
| U | (47.471629073545508, 0.86856375485953841, 0.57032625730456021) |
| rhoc | 22.292403376773496 |
| muc | 3.8978930586897334e-05 |
| Urel | (0, 0, 0) |
| Urmag | 0 |
| tMom | 1.6473868106346646e-09 |
| dChild | 0 |
| massChild | 0 |

| Model member | Value |
|---|---|
| b0_ | 0.60999999999999999 |
| b1_ | 15 |
| cTau_ | 1 |
| cRT_ | 1000000000 |
| msLimit_ | 0.20000000000000001 |
| weberLimit_ | 6 |

averageParcelMass=2.4800000094247781e-11 kg.

## Origin trace and classification

The coefficient1e9 exists in the original fixture dictionary before birth/migration. The failing object is actual rank1 newborn(1,0), copied from migrated parent(0,0), initialized with finite native physical/history fields. Its observed slip falls through0.29734376054834138,0.00027727439254537212,8.6726145285168567e-7,8.1563959721327408e-10,7.6738664451951123e-13 to exactly0 through native parcel evolution. Zero slip itself is not an invalid parcel/carrier state and must not be clamped. With g=0 and tMom>0 it produces KRT=0. Bad result is produced **inside line161**, not transported in from another rank.

Classification: **CLASS D / FIXTURE_DOMAIN_INVALID**, specifically the source-implied finite-double-output domain of the configured RT expression. This does not establish a general physical inadmissibility of quiescent droplets or all use of CRT=1e9 at nonzero KRT. No extra documented physical lower-diameter limit is invented. Both serial and rank1 no-crossing native-only captured-state controls reproduce the same source line with all actual native arguments, coefficients and averageParcelMass exactly equal; MPI transport is not necessary for this failure.

Native update contains no Random draws. Current native RNG before failure: x_=110983831113855,scalarNormalStored_=false,scalarNormalValue_=0. No signal-to-transaction conversion or fallback.

## Scope and STOP

Arithmetic cause established for exact fixture. No fix, clamp, reset, tuning or alternate model. FPE1 COMPLETE / DIAGNOSIS ONLY; ID1 remains PARTIAL / KH_SIGFPE_BLOCKER. Owner must separately authorize any subsequent fixture-domain/model policy. STOP.
