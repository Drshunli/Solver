# M6B.1-DYN-SP1-SHOCK-PATH-DYNAMIC-CLOSURE REPORT v1

2026-10-06；NONZERO_K_PE_v1；serial/fixed mesh/strategy0；DIAGNOSIS / CONVERGENCE CLOSURE ONLY。

## 1. SP1 status

**PARTIAL / MEASUREMENT_RESOLUTION_UNRESOLVED（结果 D）**。主指标尾端下降，但 N3200 的末段有限差分速度引起残差变化大于主残差，不能据此证明动态 endpoint jump 的非零极限或宣布闭合。已完成全部必需六网格及九项振幅矩阵数据；八次新增实际PDE，四个原弱激波数据保留并只读重放。

## 2. Source / binary identity

使用原 DYN 的完全相同 executable，未重建 active solver；独立只读harness编译。111源 manifest零delta，model/MC3预算/DYN预算/EOS/R1/TD1/KT/strategy0保护PASS。preservation_gate.json包含完整来源。

## 3. Extended mesh ladder

| N | origin | steps | measured s | speed rel error | plateau error | cons RH max |
| --- | --- | --- | --- | --- | --- | --- |
| 100 | retained DYN | 54 | 236.3148032 | 0.001525759751 | 0.003445678897 | 0.003869085467 |
| 200 | retained DYN | 109 | 236.2016774 | 0.001046321165 | 0.0008434228175 | 0.00204370553 |
| 400 | retained DYN | 218 | 236.1258373 | 0.0007249033531 | 0.0001289427064 | 0.001192619914 |
| 800 | retained DYN | 435 | 236.0734061 | 0.0005026943522 | 2.768035379e-05 | 0.000766243086 |
| 1600 | fresh SP1 | 871 | 236.0366118 | 0.0003467564574 | 1.591961676e-05 | 0.000513512438 |
| 3200 | fresh SP1 | 1742 | 236.0108059 | 0.0002373887416 | 1.05891961e-05 | 0.0003441145689 |

固定 mixed01/p ratio1.05、同物理初值/CFL策略/模型/path。N6400为条件可选，未执行：六级下降趋势已经可辨，速度敏感性已经符合结果D；本轮使用D分类并停止，不无限加密，不将可选级包装为已运行。

## 4. Plateau uncertainty

预先冻结 primary post[.425,.455]/pre[.54,.60]；inner post[.4325,.4475]/pre[.555,.585]；outer post[.42,.46]/pre[.53,.61]。主判定不换窗口。辅助 N100 inner仅少量样本，独立标记数量；其最低采样数放宽只用于诊断，原primary三格最低数不改。

| N | primary raw | inner raw | outer raw | max raw variation | variation/primary |
| --- | --- | --- | --- | --- | --- |
| 100 | 0.0001794151184 | 1.048055491e-06 | 0.0001472637113 | 0.0001783670629 | 0.9941584884 |
| 200 | -0.0003046790769 | -0.0003764091026 | -0.000202032433 | 0.0001026466439 | 0.3369008628 |
| 400 | -0.0003221294747 | -0.0003339089347 | -0.0002868798746 | 3.524960007e-05 | 0.1094268077 |
| 800 | -0.0002182497247 | -0.0002051028584 | -0.0002267397691 | 1.314686626e-05 | 0.06023772209 |
| 1600 | -0.0001353267911 | -0.0001273290718 | -0.0001453978056 | 1.007101446e-05 | 0.07441996055 |
| 3200 | -8.354293104e-05 | -7.869850752e-05 | -8.947350225e-05 | 5.930571214e-06 | 0.07098830674 |

## 5. Shock speed convergence

保守子系统速度门PASS，s_ref=235.95479291662429。原 [.35,.62] 正压降加权centroid保持；主速度=(x−.4)/actual final t。N3200 s=236.0108059279787，相对误差 .000237388742。FD与reference只作离线敏感性，不替换主定义。

## 6. Plateau convergence

原主窗口平台误差逐级下降到1.0589196103e-5。只读均匀体积保守量/alpha均值回收，不修改任何 committed state；secondary采样用于不确定性。

## 7. Conservative RH convergence

mG/mL/momentum/Et/independent species及dependent residual species的 s[Q]=[F] 逐级最大残差下降至 .000344114569，冻结 finest .05 门通过；无 SHOCK_SYSTEM_DYNAMIC_BLOCKER。原各Q逐项 shock_RH.csv 保留。

## 8. Endpoint alpha residual

| N | R_endpoint final | scaled | speed term | transport jump | minus I_endpoint final |
| --- | --- | --- | --- | --- | --- |
| 100 | 0.0001794151184 | 0.0002494508427 | 0.716519158 | -0.719240378 | 0.002900635174 |
| 200 | -0.0003046790769 | 0.0003989615237 | 0.7602944218 | -0.7636803521 | 0.003081251208 |
| 400 | -0.0003221294747 | 0.0004153907991 | 0.7720339393 | -0.7754853391 | 0.00312927033 |
| 800 | -0.0002182497247 | 0.0002807296425 | 0.7740819513 | -0.7774374049 | 0.003137203872 |
| 1600 | -0.0001353267911 | 0.0001740490781 | 0.77424801 | -0.777520873 | 0.00313753626 |
| 3200 | -8.354293104e-05 | 0.0001074487332 | 0.774293294 | -0.7775143418 | 0.003137504901 |

符号 −s[a]+[au]−I，left=post/right=pre，仍使用冻结KT uStar及三腿顺序。400→800→1600→3200尾端下降且最细绝对门通过；原100→200→400非单调事实保留，不能把趋势PASS与测量分辨率闭合等同。

## 9. Reference alpha residual

| N | reference raw | construction scaled |
| --- | --- | --- |
| 100 | -3.428690751e-11 | -4.427730206e-11 |
| 200 | -3.428690751e-11 | -4.427730206e-11 |
| 400 | -3.428690751e-11 | -4.427730206e-11 |
| 800 | -3.428690751e-11 | -4.427730206e-11 |
| 1600 | -3.428690751e-11 | -4.427730206e-11 |
| 3200 | -3.428690751e-11 | -4.427730206e-11 |

全部12项最大normalized reference residual=4.4277302055405463e-11≤1e-10。同一 reference states、公式/符号/Hugoniot合同未被分析破坏，不调整参考状态。

## 10. Discrete-profile alpha residual

| N | actual preceding anchor t | R_discrete primary | scaled | R_discrete edge CV |
| --- | --- | --- | --- | --- |
| 100 | 0.0003301611132 | 0.0005066764416 | 0.0007093555804 | -0.0006940703011 |
| 200 | 0.0003363894429 | -0.0002237071519 | 0.0002933109777 | -0.0007594210817 |
| 400 | 0.0003379465697 | -0.0003092909176 | 0.0003988899864 | -0.0006054070704 |
| 800 | 0.0003379471702 | -0.0002162008242 | 0.0002780964264 | -0.0004056811474 |
| 1600 | 0.0003387267492 | -0.0001341734484 | 0.0001725657206 | -0.0002516449774 |
| 3200 | 0.0003389223552 | -8.248295781e-05 | 0.0001060854482 | -0.000159157828 |

R_discrete=−s[a]+[au]−I_discrete 使用实际最后接受步的前anchor ledger与同时间platform。final主endpoint另列，避免跨时混算。FD/reference敏感性同样保留。它在细网格下降，但有限数据尚不能分辨约1e-6偏移。R_CV是实际离散方程残差，不能冒充跳跃残差。

## 11. Control-volume alpha balance

CV 预冻结 [.425,.60] 的cell-centre选区；实际网格face边界逐级记录。R_CV=Delta integral(alpha dx)+dt*DeltaF_alpha−dt*sum((alpha+K)Deltaphi)。每接受步记录原DD transport、Ksource、alpha变化及边界flux。最大积分残差 3.131176403533729e-19，最大rate残差 3.595165716267021e-13，满足原1e-14+1e-10*term-scale；roundoff floor不要求人为单调。没有 ALPHA_DISCRETE_BALANCE_BLOCKER。

## 12. I_endpoint

同时间preceding实际anchor的原主平台单端点冻结路径：

| N | I_endpoint primary anchor | final endpoint I |
| --- | --- | --- |
| 100 | -0.002880439665 | -0.002900635174 |
| 200 | -0.003077245843 | -0.003081251208 |
| 400 | -0.003128837501 | -0.00312927033 |
| 800 | -0.003137178399 | -0.003137203872 |
| 1600 | -0.003137536226 | -0.00313753626 |
| 3200 | -0.003137504914 | -0.003137504901 |

## 13. I_discrete

| N | actual (a+K) cell sum | internal frozen face sum | boundary legs | face total | actual minus face total |
| --- | --- | --- | --- | --- | --- |
| 100 | -0.003119698792 | -0.003106150519 | -1.354827309e-05 | -0.003119698792 | 1.301042607e-18 |
| 200 | -0.003137428089 | -0.00313662804 | -8.000493116e-07 | -0.003137428089 | 1.95156391e-17 |
| 400 | -0.003138630674 | -0.003138627087 | -3.586661548e-09 | -0.003138630674 | 1.214306433e-17 |
| 800 | -0.003138586262 | -0.003138585473 | -7.88149163e-10 | -0.003138586262 | 2.818925648e-17 |
| 1600 | -0.003138553447 | -0.003138553174 | -2.72871925e-10 | -0.003138553447 | 1.170938346e-17 |
| 3200 | -0.003138530273 | -0.003138530178 | -9.512290977e-11 | -0.003138530273 | 3.035766083e-18 |

真实冻结driver在原native选中dt/time上重放，所有保守/P2更新与native最终committed/old bits匹配。profile_cells.csv记录各cell实际a*dphi、K*dphi与累计量；profile_faces.csv记录每个实际anchor face的三腿贡献与累计internal IaK。包含CV边界半腿的总量与actual a+K源可有原预算内binary roundoff；无state修正。未宣称新增native插桩计数器。

## 14. DeltaI

| N | CV I_discrete - plateau I_endpoint | scaled | matched profile chain - edge endpoint | matched scaled |
| --- | --- | --- | --- | --- |
| 100 | -0.000239259127 | 0.0003349668209 | -8.187916486e-07 | 1.063927262e-06 |
| 200 | -6.018224611e-05 | 7.890723787e-05 | -9.339851044e-07 | 1.201951271e-06 |
| 400 | -9.793173109e-06 | 1.263017588e-05 | -9.814338451e-07 | 1.262228776e-06 |
| 800 | -1.407862278e-06 | 1.810915706e-06 | -1.002398514e-06 | 1.289211328e-06 |
| 1600 | -1.017220764e-06 | 1.308287416e-06 | -1.01491441e-06 | 1.305322474e-06 |
| 3200 | -1.025359411e-06 | 1.318765908e-06 | -1.024480152e-06 | 1.317636153e-06 |

主平台差值与完全匹配profile首末状态差值都记录。前者粗网格受到platform/CV端点区别影响；后者排除端点采样位置差异，细网格趋于约−1.02e-6。有限profile非加性证据明确，但 formal outcome B 的动态非零endpoint极限仍未证实。

## 15. Residual decomposition

相对于原exact shock reference，用四项重构R_num−R_ref：−(s_num−s_ref)[a]_num；−s_ref([a]_num−[a]_ref)；[au]_num−[au]_ref；−(I_num−I_ref)。

| N | speed estimation | plateau alpha jump | transport jump | endpoint path change | sum reconstruction error |
| --- | --- | --- | --- | --- | --- |
| 100 | 0.001091570618 | -0.0589399988 | 0.05826466558 | -0.0002368222397 | -2.45029691e-17 |
| 200 | 0.0007946806541 | -0.01486784505 | 0.01382469156 | -5.620620623e-05 | 7.502679034e-17 |
| 400 | 0.000559244593 | -0.002892891456 | 0.002019704506 | -8.187083551e-06 | 7.437626903e-17 |
| 800 | 0.0003889311116 | -0.0006745659895 | 6.763872939e-05 | -2.535418794e-07 | 3.317658648e-17 |
| 1600 | 0.0002683824337 | -0.0003879586228 | -1.582941357e-05 | 7.884576401e-08 | 1.805196617e-17 |
| 3200 | 0.0001837648869 | -0.0002580570876 | -9.298182953e-06 | 4.748685269e-08 | 2.081668171e-17 |

speed与platform项有显著相消，端点函数自身变化不是主残差唯一来源；不能根据单一合成残差归因alpha source。

## 16. uStar convergence

| N | uL | uR | KT uStar | s | uStar-s | KL | KR | IaK final |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 100 | 6.996843194 | 0.01710193076 | 3.574219654 | 236.3148032 | -232.7405836 | -0.1026076869 | -0.09960733948 | -0.002900635174 |
| 200 | 7.399332527 | 0.0007244795929 | 3.775222723 | 236.2016774 | -232.4264547 | -0.1027854956 | -0.09960035272 | -0.003081251208 |
| 400 | 7.509331609 | 2.41686208e-06 | 3.832084459 | 236.1258373 | -232.2937529 | -0.1028354032 | -0.09960004461 | -0.00312927033 |
| 800 | 7.52754667 | 5.9892132e-11 | 3.841555847 | 236.0734061 | -232.2318502 | -0.1028447092 | -0.09960004358 | -0.003137203872 |
| 1600 | 7.52826631 | -2.552462699e-13 | 3.841925701 | 236.0366118 | -232.1946861 | -0.1028459151 | -0.09960004358 | -0.00313753626 |
| 3200 | 7.528162943 | -2.596659549e-13 | 3.841868839 | 236.0108059 | -232.1689371 | -0.1028464624 | -0.09960004358 | -0.003137504901 |

uStar进入约3.84 m/s窄区间；shock速度约236 m/s。uStar≠s本身是冻结数值path设计的一部分，本轮不把它替换或拟合。

## 17. Speed-estimator sensitivity

| N | centroid s | reference s | FD last10% s | FD adjacent s | FD last10% raw residual | FD change/primary |
| --- | --- | --- | --- | --- | --- | --- |
| 100 | 236.3148032 | 235.9547929 | 236.2575884 | 236.1178755 | 5.936666473e-06 | 0.9669110021 |
| 200 | 236.2016774 | 235.9547929 | 236.0748946 | 236.0658521 | -0.000712772132 | 1.339419363 |
| 400 | 236.1258373 | 235.9547929 | 236.038012 | 236.0385649 | -0.0006092820598 | 0.891419779 |
| 800 | 236.0734061 | 235.9547929 | 236.0120189 | 236.0105928 | -0.0004195376267 | 0.9222825012 |
| 1600 | 236.0366118 | 235.9547929 | 235.993588 | 235.9930781 | -0.0002764536038 | 1.042859374 |
| 3200 | 236.0108059 | 235.9547929 | 235.9805657 | 235.9810069 | -0.0001827536224 | 1.187541425 |

N3200 FD变化=-9.92106913794144e-05，主残差=-8.354293103572446e-05；二者比=1.1875414251026233。reference速度差敏感性/主值=2.1996461538456518。速度估计不能排除为主要测量贡献。FD规则（最后10%时间secant/相邻最后步）运行前冻结，主metric不变。

## 18. Profile-path accumulation

对相同实际anchor W_first→...→W_last，每相邻面调用同一冻结path并累加，与同一首末原生状态的single endpoint path比较；matchedProfileEndpointAudit记录完整结果。内部sum与原actual ledger face贡献在原algebra预算内吻合。不存在path additive假设，也没有alternative uStar、leg order、midpointK、Roe或path fitting测试。

## 19. Weak-shock amplitudes

| ratio | N | dp Pa | R_endpoint | DeltaI primary | matched profile DeltaI | strict cells |
| --- | --- | --- | --- | --- | --- | --- |
| 1.01 | 400 | 30000 | -1.287429192e-05 | -2.146190001e-06 | -8.29921359e-09 | 85600 |
| 1.01 | 800 | 30000 | -9.297821915e-06 | -1.240363534e-07 | -8.480757271e-09 | 342400 |
| 1.01 | 1600 | 30000 | -6.183756097e-06 | -9.620651698e-09 | -8.598281968e-09 | 1371200 |
| 1.02 | 400 | 60000 | -5.15899721e-05 | -4.146125018e-06 | -6.546454588e-08 | 86000 |
| 1.02 | 800 | 60000 | -3.660620848e-05 | -2.762937261e-07 | -6.689017129e-08 | 344000 |
| 1.02 | 1600 | 60000 | -2.391172215e-05 | -6.995664182e-08 | -6.779564892e-08 | 1377600 |
| 1.05 | 400 | 150000 | -0.0003221294747 | -9.793173109e-06 | -9.814338451e-07 | 87200 |
| 1.05 | 800 | 150000 | -0.0002182497247 | -1.407862278e-06 | -1.002398514e-06 | 348000 |
| 1.05 | 1600 | 150000 | -0.0001353267911 | -1.017220764e-06 | -1.01491441e-06 | 1393600 |

1.01/1.02各400/800/1600为六次fresh实际PDE；1.05的400/800保留原PDE，1600为fresh扩展。只是有界诊断，不建立新的正式shock gate。

## 20. Weak-limit scaling

| N | endpoint fitted slope | endpoint pair slopes | matched profile fitted slope | matched pair slopes |
| --- | --- | --- | --- | --- |
| 400 | 2.000443235 | [2.0025975796609936, 1.9989575163227904] | 2.96498207 | [2.9796672446869104, 2.954854615165349] |
| 800 | 1.960202062 | [1.9771236544030082, 1.9485322885042058] | 2.964662846 | [2.9795292415748897, 2.954410415226869] |
| 1600 | 1.915954989 | [1.9511627161415819, 1.8916744031499764] | 2.963806338 | [2.9790723578711606, 2.9532783111107017] |

三项有限dp的endpoint残差近O(dp^2)，匹配profile路径差近O(dp^3)。弱化后快速下降，支持有限振幅路径差解释；只有三幅值，不能称严格dp→0证明，也没有证明finite offset/线性实现失效。

## 21. Strict / native stats

12项调查（8 fresh/4 retained）；接受步 6434，native=strict=11037200，toleranceOnly=0，acceptedRecoveryFailures=0；minimum root margin=6472041.839237715，TL=[299.99932171175413,300.0295394802436] K。每步inspect全部cells；N3200仅限制逐cell输出体积，不减少检查，N100两个输出版本trajectory/CV/profile/gate/state bits完全相同。详见bounded_equivalence_gate。

## 22. P2 / species

P2sole authority、无阈值/clip，P2 mismatch=0、presenceLoss=0；max原始N−1 species closure=1.5179033951537162e-16<1e-12。完整committed/old/P2/independent conservative bit验证通过。

## 23. Temporal regression

min dt=1.256421693465238e-07，min accepted/fresh=1.0，median ratio=1.0；requested reject/rejected candidates/retry/rescue均0。无collapse；TD1 COMPLETE preserved。没有 retune。

## 24. Conservation

全周期、原积分ledger max=3.970519600488405e-15<1e-10；未改state。conservative RH趋势PASS，CVbalancePASS，原微观path代数max=5.551115123125783e-17；driver guard calls派生=11037200，不是新增native插桩计数。

## 25. Classification

**结果 D：MEASUREMENT_RESOLUTION_UNRESOLVED**。排除当前implementation/ledger平衡阻塞；观察到细网格primary endpoint trend下降，仍存在同量级speed-estimator敏感性。不能宣布A的物理dynamic gate闭合，也不能仅凭有限profile差宣布B的全部jump-limit条件成立。

## 26. Path mismatch established?

实际profile path累积与完全相同首末状态的single endpoint path差异已明确观察、随refinement稳定，且弱幅值呈近三次缩放；这是真实有限profile非加性证据。**formal EFFECTIVE_PATH_MISMATCH ESTABLISHED（结果B）尚不宣告**：主dynamic endpoint的非零极限小于当前speed敏感性，R_discrete与endpoint jump limit尚不能分辨。微观CV精确平衡不替代非保守jump动态资格。

## 27. Implementation balance issue?

NO observed。本轮所有实际接受步R_CV满足冻结离散预算，source/transport/face累积一致；不重新打开EOS/R1/TD1/P2/species问题，不自动实施implementation补丁。

## 28. Measurement issue?

YES。最细primary raw=-8.354293103572446e-05，primary窗口变化=5.930571214376925e-06（0.07098830674064938倍）；FD-speed变化=-9.92106913794144e-05（1.1875414251026233倍）。当前主限制主要为speed/finite-resolution shock measurement，窗口影响较小仍显式保留。optional6400没有自动执行，因为既有趋势与D分类已明确；后续若继续测量闭合，仍须保留原主定义及最后一级有界限制。

## 29. Next permitted milestone

保持SP1 measurement-resolution closure；如后续继续，可在原合同下使用尚未执行的最后可选N6400，不能无限加密。不自动进入 DYN-RESUME，也不自动进入 SP2 path modification/review执行。若用户后续授权新阶段，应结合本轮明确profile差与测量敏感性证据。

## 30. DYN status

PARTIAL / 原SHOCK_PATH_DYNAMIC_BLOCKER动态闭合未取得。Acoustic/contact PASS历史证据保留；moderate/original refinement/high-Mach/Galilean本轮未执行。

## 31. M6B.1 status

PARTIAL；M6B也PARTIAL。MC3/MC4/MC4A/MC5/TD1/EOS3既有COMPLETE保护，不提升DYN或M6B.1。

## 32. Hashes

| installed artifact | SHA256 |
| --- | --- |
| /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/bin/rhosprayVoFDPMFoam | 43facf56b8137bf658bb7c960718d186665160a3eb028b6f913204f3dfef2cd3 |
| /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayLiquidEOS.so | 1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888 |
| /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayFiveEqThermo.so | f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896 |

| frozen artifact | SHA256 |
| --- | --- |
| FIVE_EQ_NONZERO_K_MODEL_v1.md | be2e3d414dcfffd7a9ae498fa14f4a4f8de934b60c5c87f78a696bdf041b5270 |
| fitting/integration/m6b1_mc3_nonzero_k_model_design_v1/error_budget.json | c6377d653599a24903440b119a8d5e9ea0541ea88db96d0bc40ad8803309d12b |
| DYN/error_budget.json | 23f11df196517e2bf684b65283ffa56ec880ad145f71c692a499302db4a4c371 |
| SP1/analysis_definitions_before_runs.json | 3ce611c9c4166e9a69cfacee8b99a3f5038a850fd6ae6b87a3af18f1e76816b7 |

111源manifest SHA `faa51fb1175308183f3760f097dd26b0bf3b288550f8a5b874e93c51e71e6885`；TD1contract `d415b10f2b1eb67e77e1c0062950b2afeaf7033ca9491592edc1d0ec0af1fba1`；TD1policy `a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062`。115运行库、Foundation6717、native parcel19、原DYN全部封存文件及MC4/MC5/DYN ZIP均PASS。EOS/R1含于原111项manifest，源码delta={}。

## 33. Milestone matrix

| stage | status |
| --- | --- |
| MC3 / MC4 / MC4A / MC5 | COMPLETE / PRESERVED |
| TD1 / EOS3 | COMPLETE / PRESERVED |
| DYN acoustic / contact | PASS / PRESERVED |
| SP1 CV / strict / conservative / temporal | PASS |
| SP1 finite-profile path difference | OBSERVED / near cubic weak-amplitude scaling |
| SP1 formal dynamic closure | PARTIAL / MEASUREMENT_RESOLUTION_UNRESOLVED |
| DYN / M6B.1 / M6B | PARTIAL |
| N6400 | OPTIONAL / NOT EXECUTED |
| SP2 / DYN-RESUME / M6B.2 / active DPM / MPI / production | NOT EXECUTED |

**STOP**。本轮没有修改active source/path/budget，也没有执行禁止阶段。
