# T4-S2 FINAL SEAL REPORT v1

本轮：M8A.3B-T4-S2-FINAL-SEAL。0 new physics runs，0 new compilations；只读证据汇总、源码和checkpoint哈希核验、文档与封存。

## 1. S2 final status

**T4-S2 = COMPLETE / FROZEN**，限定于 passive/offline、固定网格、Foundation7 DP/Int32、两 rank native parcel 证据。36 个 mandatory gates 均有兼容且 hash-consistent authority。

## 2. Complete authority matrix

[T4_S2_FINAL_AUTHORITY_MATRIX_v1.md](D:/DATA/Solver/rhosprayVoFDPMFoam/T4_S2_FINAL_AUTHORITY_MATRIX_v1.md)；36 行完整 requirements、milestones、路径、SHA-set、fresh/inherited、scope、PASS。机器可读版本提供每个证据文件 SHA。

## 3. Native OF7 architecture

Cloud::move; native tracking; processor crossing; prepare/correct transfer; PstreamBuffers; UOPstream/UIPstream; ParticleType::iNew protocol; Random; ConeInjection; InjectionModel mass weighting; sphereDrag; stochasticDispersionRAS; blobsSheetAtomization; ReitzKHRT; ORourke; rebound; VoidFraction。本机 22 个 native 所有权相关文件已实际读取；6717 源码及 19 native parcel 指纹再次核验。已有 lazy parcel 使用 OF7-compatible 原生 stream/iNew 协议；没有另写 MPI packet/queue。

## 4. Project-local exceptions

P2/R1/recovery; lazy support-first; S1 distributed support; MPIFailureLatch; transactionState-v1 local codec; I1 ownership wrapper; KH newborn identity adapter; frozen ZS1 exact-zero call-site compatibility; local source/output staging。所有运行实现本轮零修改。现有本地 transactionState-v1 codec 不冒称为不存在；它不用于 MPI parcel 传输。

## 5. Migration semantics

R1 pilot、20 个 stress runs 和 ZS1 reverse 原始边界 CSV 重新只读校验：sender/receiver snapshots、identity、nParticle、物理/历史 fields、native geometry correction、prepare/correct RNG 全 PASS。C2 只作 oracle。

## 6. Valid directions

Forward: R1 1000 个 successful 0→1 crossings。Reverse: ZS1 mpi_zero 正常 exit0、一次真实 Cloud::move 1→0，原始 full-state/geometry/RNG oracle PASS；shared source SHA=c264b0b22cb95d96dc6349fdb40f2993e04a146958cc9f881f15ef54aaf007b5，与当前 R1 相同，INHERIT PASS。未以 invalid rejection 替代 valid reverse；本轮不需补 replay。

## 7. 1000-crossing stress

继承 20 个独立有界 MPI 运行，每个50次、共1000次；全部 exit0，1.38–3.99s，未触发55s watchdog。不计入历史失败、I1 循环或 ID1 步数；本轮没有重跑。

## 8. Ownership

weighted 主运行出生 identity 集合与最终 owners 集合相等，50/50、每个完整 pair 恰有一个 cloud owner、无丢失/重复；KH newborn 继承 ID1/K1，invalid destination 继承 N1 的受控 reject/discard。

## 9. Identity

Existing parcel 迁移保存 origProc/origId。真实 KH birth 的 origProc=Pstream::myProcNo，origId=child.getNewParticleID。没有 global ID allocator 或 receive-time renumber。

## 10. Support

继承 S1/R1：先 preflight 支撑、后 thermo；目的 rank 新建 session，实际 remote contributors；没有迁移源 support token。固定拓扑支撑范围之外不扩张。

## 11. Invalid support

N1 forward/reverse 的目的 rank 均 EXACT_GAS_ABSENT，零 dependent rho/T/Y/Cp/mu/kappa/recovery；native communication 返回后 reduce、discard、正常退出。未制造 fake gas。

## 12. RNG

继承 R1 完整 x_、scalarNormalStored_、scalarNormalValue_ bits 和50/50 paired next-result 精确比较。参考是同一目的 owner 上同一 parcel 的串行无迁移下一更新，不是两条独立完整 cloud 轨迹或 rank RNG 同步。47次抽样、3次按 native 涡寿命规则保留 UTurb 均精确一致。

## 13. stochasticDispersionRAS

R1 fresh evidence：6503 calls、462 RNG-consuming-update counter、真实非零 UTurb、有限状态、weighted parcel 正常。462是发生器序列改变的更新数，不是底层随机抽样总数。

## 14. sphereDrag

R1 fresh native calls=12906；32个实际非零速度/源项轨迹段。source=nParticle×singleMass×(Ubefore−Uafter) 最大相对残差2.1493859013912846e-13；没有额外 multiplicity 因子。只认证 local model source，不认证 global ledger。

## 15. Weighting

PW1 native mass basis，1/10/100/1000计算 parcel 梯级代表质量保持、nParticle 有限正值、迁移 multiplicity bit parity、非空 rollback parity。保持原生/已有物理 parcel 更新，未新增 merge、superparcel 或自定义 weighting。

## 16. VoidFraction

继承7380个 native postMove轨迹段及每rank/每步/cell theta bit oracle；dt×nParticle×singleDropletVolume，仅一次计权，再按 dt/Vcell 归一化。本项是 S2 segmentation，不是 S3 global publication。

## 17. Breakup / KH

Foundation ReitzKHRT 未改；FPE1 保留 historical CLASS D，FPE2 保留 CLASS E diagnosis。ZS1 只在 Urmag==0 且 real KHindex<.5 时改临时调用 index，保留真实 history。当前 CRT=.1 有界路径及 native child path正常，不能推断 OF7 KH 永不失败或统计收敛。blobsSheet50次原生调用和 migrated liquidCore=0 提供自然 core transition 证据。

## 18. Injection

PW1/R1 的 native ConeInjection/InjectionModel weighted birth；注入 gate无manual seed。50 parcels/s、每个注入步 requested=added=10、总50、global population≤50；原物理 mass/SOI/duration/分布/组成/速度/几何/系数不变。这不是生产预算认证。

## 19. ORourke limitation

**Migration/state compatibility PASS; NATIVE-PHYSICS-LIMITATION; NOT FULL-CONSERVATION-SAFE.** weighted native ORourke实际运行；不认证 distributed collision conservation 或 collision statistics。

## 20. Rebound

**INHERITED**：R1 fresh wall counter2357次，WallAdapter 只读计数并调用 native Rebound::correct，fixture为真实wall路径；不是人工U flip。

## 21. Lifetime

valid/weighted迁移、KH newborn、invalid destination、rollback证据均满足constructed=destroyed+live baseline。主运行各rank50/50/live0；非空回滚目的rank40/30/live10=accepted baseline，未把合法accepted parcel当泄漏。

## 22. Registry

重复有界运行 registry稳定，discard delta0；已有代码检查 carrier binding empty、S1 owner/session/latch作用域正常结束，无累积。

## 23. Rollback

R1非空accepted weighted stream before/after一致，完整codec/allocator/RNG/cache/nParticle/identity/source/view/pending output恢复。ID1正常 rejected birth→discard→retry accepted payload相等。本项是existing rank-local rollback，未认证global atomicity。

## 24. Source boundary

认证 local native/model source、nParticle scaling 和rollback；**不认证** distributed global dmG/dmYi/dM/dEt ledger。

## 25. Output boundary

认证 pending output rollback、identity consistency；**不认证** MPI global exactly-once publication。

## 26. Serial regression

继承R1 fresh：R2B252194/0，I112083/0，C217/0，K1108/0。exe/source provenance核对通过，未重复运行。K1新增92个真实child identity负向检查和5694次laterchild queries；不是实际空间无效出生证据。

## 27. S1 regression

继承R1 fresh：support20051/0、topology3364/0；mixed/trace/absent/generation/pose/remote/native weights覆盖。

## 28. N1 regression

继承R1 fresh valid、forward invalid、reverse invalid，全部globalFailures0。invalid reverse独立列明，不加入valid reverse或1000 successful统计。

## 29. Foundation hashes

本轮fresh只读：6717 Foundation、19 native parcel SHA全部PASS；Cloud/particle transfer、Random、InjectionModel/Cone、streams/iNew、ReitzKHRT原字节保持。

## 30. Project hashes

30535 frozen entries本轮初始核验全部不变。34个共同编译依赖经冻结T3依赖SHA链定位历史snapshot，与当前全相等；active主.C及五个方程.H历史字节也相等。ID1→ZS1是已批准冻结差异，accepted birth payload parity桥接；本轮无新runtime delta。历史PARTIAL archive只提供源字节来源，不提供任何PASS或成功穿越计数。

## 31. Active solver impact

**NONE**。没有active solver、方程、EOS、KT、source或runtime coupling修改/激活。

## 32. Production impact

**NONE**。没有production mesh/BC/injection/restart修改或执行；production restart NOT CERTIFIED；CFD NO。

## 33. Unresolved limitations

全局MPI commit/failure atomicity、global source/output exactly-once、完整distributed model graph、1/2/4rank比较属于S3。ORourke守恒/统计限制保留；KH非测试域可能失效；实际空间无效child-at-birth、自然多代、动态网格/AMR、跨ABI/restart不在本S2证书中。mandatory S2 gates OPEN=0，不把范围外限制伪装为已闭合。

## 34. Whether S2 COMPLETE

**YES — COMPLETE / FROZEN**，以本轮authority matrix和不可覆盖最终seal为准。Inherited证据已校验，不要求为“fresh”重新跑物理。

## 35. Whether S3 may be considered

**NEXT ROUND ONLY**，仅可讨论；当前NOT AUTHORIZED / NOT EXECUTED，不自动执行。

## 36. Milestone matrix

| Milestone | Status |
|---|---|
| R2-FINAL / T3 | COMPLETE / FROZEN |
| T4-S1 / C1-N1 | COMPLETE / FROZEN |
| FPE1 / FPE2 / TIMEOUT-D1 | COMPLETE / DIAGNOSIS ONLY / FROZEN |
| ZS1 / ID1 / PW1 / R1 FINAL | COMPLETE / FROZEN within recorded scope |
| **T4-S2** | **COMPLETE / FROZEN** |
| T4 / M8A | PARTIAL / PARTIAL |
| T4-S3 | NOT AUTHORIZED / NOT EXECUTED |
| M6B / CFD | NO / NO |
| Production restart | NOT CERTIFIED |

STOP。
