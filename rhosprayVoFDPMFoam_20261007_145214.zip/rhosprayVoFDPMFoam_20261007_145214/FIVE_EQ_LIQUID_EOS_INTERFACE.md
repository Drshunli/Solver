# Future liquid EOS contract for density-based KT five-equation solver

**Design only. No class or solver field is instantiated in M6A1b-2A.** The current `rhosprayLiquidThermo` is a compiled, uninstantiated *constant-SG historical prototype*: its parameter members (`gamma,pInf,Cv,q`) and class semantics cannot become the general liquid EOS API. Later introduce a separately named `rhosprayLiquidEOS` strategy interface and implementations, selected once from a dictionary at solver construction. Do not retrofit the old class into runtime by a silent rename.

## Material state and primary API

Use SI units. The EOS is for *intrinsic Eulerian liquid* C10H22, not mixture density or DPM parcel volume fraction. A per-call `LiquidState` should include `p,T,rho,e,h,c2,Cp,Cv`, `validity/phase`, `deDpConstRho`, `dpDrhoConstE`, `dpDeConstRho`, and a backend status. Methods must expose:

```text
statePT(p,T)          -> rho,e,h,c2,Cp,Cv,phase,derivatives
stateRhoP(rho,p)      -> e,T,h,c2,deDpConstRho,phase,derivatives  [hot path]
stateRhoE(rho,e)      -> p,T,h,c2,phase,derivatives               [inverse]
rho(p,T), p(rho,e), e(rho,p), T(rho,p), h(rho,p), c(rho,p)
valid(p,T,rho)        -> in-domain, single-liquid, stable, positive
```

Return `h=e+p/rho` on the **same declared energy reference**. Reject invalid states explicitly; no silent clamping or vapor/two-phase interpolation. Derivatives may be analytic or computed from a thermodynamically consistent potential/table; finite differences in a pressure root require an explicit accuracy gate. `rho(p,T)` is needed for inlet initialization and data comparison. `stateRhoP` is the critical runtime access pattern.

## M6A2 common-pressure recovery

Known at a cell: `alphaL`, `alphaG=1-alphaL`, `mL`, `mG`, mixture momentum `M`, total-energy density `Et`, gas composition `YG`. Compute `rhoMix=mL+mG`, `U=M/rhoMix`, `rhoL=mL/alphaL`, `rhoG=mG/alphaG`, and `Eint=Et-|M|²/(2rhoMix)`. At fixed recovered intrinsic densities and frozen composition, solve

```text
F(p) = mG*eG(rhoG,p,YG) + mL*eL(rhoL,p) - Eint = 0
F'(p) = mG*(deG/dp)|rhoG,YG + mL*(deL/dp)|rhoL .
```

The liquid API must provide `eL(rhoL,p)` and `(deL/dp)|rhoL` over every admissible bracket. A safeguarded Newton/bisection method must find a *positive, single-phase, unique* root inside both EOS domains; positivity and derivative sign are checked, not assumed. Pure-gas/pure-liquid limits skip absent-phase divisions and calls. Energy-offset changes shift `F` and therefore **do affect pressure recovery** unless `Et` and transfer sources are shifted consistently.

For a generic `p(rho,e)`, local inverse differentiation gives `(de/dp)|rho=1/(dp/de)|rho` when that derivative is nonzero. Acoustic consistency requires

```text
c² = (dp/drho)|e + (p/rho²)*(dp/de)|rho > 0
```

from `de = p/rho² d(rho)` along an isentrope. These derivatives are useful for KT and table QA even if the M6A2 solver receives direct `e(rho,p)` and `de/dp`. For the selected M5B isobaric acoustic closure, `xiL=rhoL*(deL/dp)|rhoL`; `cMix` uses `xiG,xiL,cG,cL` as specified in `M5B_TWO_PHASE_MODEL.md`. Do not substitute Wood's speed from a different five-equation closure.

## Implementation boundary

Proposed `src/rhosprayVoF/liquidEOS/{rhosprayLiquidEOS,helmholtzTableEOS,NASGEOS,mieGruneisenEOS}` with pure state evaluators, optional statically selected/templated hot-loop dispatch, and a factory used only after model acceptance. The present `rhosprayLiquidThermo` remains historical and uninstantiated. EOS objects own parameters/tables, not `rho`, `alphaL`, `mL`, `p`, or flux fields. Every backend uses the same validity and energy-reference test suite before M6A2 integration.
