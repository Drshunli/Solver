# R2A native property demand audit

Source: actual local Foundation OF7. This audit uses `native_sources` snapshots
in R2/R2A; no OpenFOAM.com substitutions. Source bodies remain unchanged.

| Model/event | Native kernel needs | Native caller/context dependencies | R2A status |
|---|---|---|---|
| coneInjection | position/direction/time/RNG/diameter/injection bookkeeping; no gas EOS in that bookkeeping | pressureDrivenVelocity also uses cloud.pAmbient and parcel.rho; flowRateAndDischarge uses parcel.rho; initialization and first SprayParcel carrier query require validated context/common p/liquid properties | born native parcel first force query tested; complete ConeInjection-to-SprayParcel bridge OPEN |
| sphereDrag | native force kernel accepts Re and muc, parcel mass/rho/d | calculating Re needs gas rho/common U/mu; full ThermoParcel.calc also constructs Ts/rhos/mus/kappas/Pr before force | isolated native kernel PASS with Drag mask; full thermal surface path OPEN |
| stochasticDispersionRAS | Uc, parcel U, UTurb/tTurb, cell k/epsilon, RNG including normal cache | no gas Cp/kappa in dispersion kernel; its RAS provider/lifetime still must be tied to selected generation | property audit only; new packet dispatch OPEN; immutable R2 replay retained |
| blobsSheetAtomization | diameter/liquid props/mass-flow and caller-prepared average gas density/Tav | SprayParcel derives Wc from rhoc,Tc,pc and Tav from liquid T/Tc before native update | new query dispatch OPEN |
| ReitzKHRT | native update receives rhoAv/muAv/Urel plus liquid properties/child state | SprayParcel derives rhoAv from rhoc,Tc,pc, uses muc/Uc and child initialization | new query dispatch OPEN |
| ORourke | native pair parcels, common cell pressure and liquid composition/enthalpy/property relations, RNG | not a gas rho/T/Y/Cp/mu/kappa query for pair bookkeeping; subsequent parcel carrier step still needs preflight | native model unchanged; frozen collision replay PASS; mixed-query dispatch OPEN |
| rebound | wall patch geometry, patch motion, parcel velocity, e/mu interaction coefficients | next carrier query must use current post-event position/cell/face and renewed preflight | pose-ticket rejection PASS; actual post-native-rebound new-query probe OPEN |
| voidFraction | parcel volume, cell volume, trajectory/occupation/time bookkeeping | no gas EOS requirement | no gas query added; frozen R2 trajectory semantics replay |

## Exact local references

* `fitting/dpm/m8a3b_t3br2a_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcelTrackingDataI.H`: eager native `Cp_` and `kappa_` members.
* `fitting/dpm/m8a3b_t3br2_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcel.C`: setCellValues at lines 45/47, source correction 74/75, surface construction 106–129, unconditional call 155.
* `fitting/dpm/m8a3b_t3br2_v1/native_sources/lagrangian/spray/parcels/Templates/SprayParcel/SprayParcel.C`: liquid p/property use 83–99; atomization 164–169; breakup 235–244 and child 283.
* `fitting/dpm/m8a3b_t3br2a_v1/native_sources/lagrangian/intermediate/submodels/Kinematic/ParticleForces/Drag/SphereDrag/SphereDragForce.C`: actual native force body.
* R2 `native_sources/.../StochasticDispersionRAS.C`: Uc and k/epsilon, RNG normal sampling.
* R2 `native_sources/.../StandardWallInteraction.C`: geometry/velocity rebound; no eager gas thermal query in kernel.
* R2 `native_sources/.../ConeInjection.C` and native ORourke source audit/hashes retained.

## Do not understate requirements

`Drag = Rho|Mu|U` applies to the isolated force evaluation. It is not a safe mask
for a complete native SprayParcel advance: even heat transfer disabled does not
remove `ThermoParcel::calcSurfaceValues` from the native caller. Future bridging
must preflight that real caller's requirement union before any surface property
or trackingData initialization. No model physics, source adapter or R2 codec is
changed to make a narrower mask appear sufficient.

Transport queries need species, p and T as internal dependencies. Y is evaluated
only on certified own-cell gas state, using the original residual-species order.
Cp/kappa stay lazy; native kappa's internal Cp call is explicitly counted.
