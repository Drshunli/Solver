# PW1: local Foundation 7 native parcel weighting

Source root: `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7`.
Numbered actual source excerpts and fresh protection checks are preserved under
`fitting/dpm/m8a3b_t4_s2_pw1_native_v1`. No OpenFOAM.com implementation used.

## Native API and dictionary

`src/lagrangian/intermediate/submodels/Kinematic/InjectionModel/InjectionModel/InjectionModel.H`
lines 80–87 defines `parcelBasis {pbNumber, pbMass, pbFixed}`.
`InjectionModel.C` lines 324–352 accepts exactly `number`, `mass`, `fixed`.

```foam
type coneInjection;
SOI 0;
duration 0.0001;
parcelBasisType mass;
parcelsPerSecond 10000; // N=1 over this full injection window
massTotal 0.0005262723452;
flowRateProfile table ((0 1) (1 1));
sizeDistribution
{
    type fixedValue;
    fixedValueDistribution { value 0.00025; }
}
```

Other cone geometry, flowType, discharge and angle entries remain required;
this excerpt is not a complete injector dictionary. The fixedValue constructor
reads `value` and `sample()` returns it directly (fixedValue.C lines 49, 70).

For transient injection `massTotal` is the physical mass over the entire event;
`SOI` is converted from user time. For steady injection, the native Function1
`massFlowRate` supplies mass per unit time. `fixed` ignores `massTotal` and reads
`nParticle`; it is not the selected mass-preserving representation.

## Native equations

ConeInjection.C lines 269–280:

`Nrequested = floor(parcelsPerSecond*time1 - parcelsAddedTotal)`

`time1` is relative to SOI; this is cumulative count bookkeeping, not independent
rounding of every dt. Positive-volume intervals with zero requested parcels hold
the earlier timeStep0 to carry the mass interval forward (InjectionModel.C 62–80).
The branch is limited by injection duration; actual counts must be measured.

ConeInjection.C lines 285–295 integrates flowRateProfile. Its integral over the
whole duration defines volumeTotal. Native newVolumeFraction is interval integral
divided by volumeTotal + rootVSmall (InjectionModel.C 62–64).

InjectionModel.C lines 185–221, mass basis:

`Vp = pi*d^3/6`

`nParticle = fraction*(massTotal/rho)/(Nrequested*Vp)`

`representedMass = nParticle*rho*Vp = fraction*massTotal/Nrequested`.

Density and diameter are actual parcel state after native property initialization.
They are not replaced by nominal 730 kg/m3. Each successfully constructed parcel
has a native origProc/origId, regardless of its droplet multiplicity.

`number` basis returns massTotal/(rho*volumeTotal); `fixed` returns nParticleFixed.
These are different semantics and must not be substituted for `mass` here.

InjectionModel.C lines 224–254 globally sums actual added count and injected mass,
updates parcelsAddedTotal, massInjected, time0 and injection count. Mass is counted
before initial move, so remaining cloud mass alone is not an injection certificate
if parcels leave or undergo deletion. PW1 observes native setNumberOfParticles
through the existing frozen ConeState birth hook, before evolution, without editing
its returned result. No post-injection renormalization is permitted.

## Existing project orchestration

The project already has frozen ExceptionSafeConeInjection and ConeState adapters.
They provide exception-safe lifetime ownership and transaction state observation;
model-specific native ConeInjection and InjectionModel weighting methods remain
the implementation. PW1 reuses these unchanged, rather than introducing another
injector/weighting implementation. Thus project orchestration is explicitly present;
it must not be described as an unwrapped InjectionModel::inject call.

## Source and VoidFraction weighting

Native ReactingParcel.C adds `np0*dUTrans`, `np0*Spu`, `np0*dhsTrans`, `np0*Sph`
once to accumulated cloud sources. Project LazyReactingParcel retains that pattern.
fiveEqNativeDPMExtraction reads aggregate sources directly; SourceAdapter.convert
does not multiply native aggregates by nParticle. Its independently computed parcel
endpoints use nParticle once to describe represented mass/energy/momentum.

Native VoidFraction.C 125–135 adds `dt*nParticle*volume`, and postEvolve divides
by `deltaT*cellVolume` (112–120). Existing TrajectoryVF repeats the expression in a
separate read-only expected-residence array; only its native base call writes theta.
The alternative deferred helper takes unweighted single-droplet volume and weights
once; it is not stacked onto native theta in this fixture.

Native atomization adjusts multiplicity for diameter change to conserve represented
volume; KH child multiplicity uses represented child mass/single-droplet mass.
Neither is an extra source multiplier. Frozen ID1 and exact-zero ZS1 remain intact.

## Qualification limits

Native weighting is AVAILABLE. No custom merge, packer, superparcel, droplet IDs,
MPI bulk packet, multiplicity codec or weighting formula is needed.
Numerical count changes stochastic sampling and collision resolution. No ORourke
statistical convergence, spray statistics, or production parcel-budget claim follows
from this qualification. All tests are isolated carrier/parcel fixtures, not CFD runs.
