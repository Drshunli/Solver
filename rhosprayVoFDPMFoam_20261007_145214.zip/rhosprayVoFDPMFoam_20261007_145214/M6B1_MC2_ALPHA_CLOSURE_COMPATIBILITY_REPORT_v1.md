# M6B.1-MC2-ALPHA-CLOSURE-COMPATIBILITY — v1

2026-10-05。OFFLINE / SHADOW ONLY。用户本轮要求完整保存为 `request_MC2.txt`。物理函数、EOS HARD domain、R1/P2、current K0、KT/reconstruction/species/TD1/Foundation/已安装 exe/library 均冻结；只创建独立影子工具和报告。以下严格区分本轮要求、旧日志事实及本轮计算结论。

1. **MC2 status**：**COMPLETE / ALPHA-CLOSURE HYPOTHESIS CLASSIFIED / STOP**，22门槛PASS。**OUTCOME M1（derived-compatible source preserving original transport）**：保留原alpha输运、加入独立推导的压力平衡K源项，24/24 micro anchors恢复all100 raw/post strict root并达到原freshCap，100digit参考确认。该实验支持下一轮模型设计，**不等于安装/生产/TD1资格**。要求中的literal PE `alphaDot=K_PE*divU` 是另一个已实测变体，失败并淘汰，不能用成功的补充变体冒充它通过。

2. **Anchor set**：healthy230 + 全24micro anchors：235, 240, 260, 330, 530, 651, 1000, 1309, 3000, 6000, 10000, 10852, 15000, 20000, 22260, 24000, 26000, 27659, 28000, 30000, 31000, 32000, 32219, 32252。每个保留100-cell exact Q/P2 bit strings、原reconstruction/faces与flux。2500committed native PASS；24个cell53从旧状态起就是tolerance-only，strict committed FAIL，不修改、不重置、不伪造strict基线。与IDP1原native faces的22500个conservative flux值逐位一致。110active source hash不变。

3. **Root-margin derivative**：定义margin `mathcalM=eta-FLo`，与momentum M明确区分。完整解析链式导数及endpoint分支推导见 `DERIVATION.md`；共2708个local derivative records（25×100+2×100contact+8compression）。保存mG、mL、momentum三分量、Et、alpha、species三分量各自qdot/partial/contribution。不是只用总有限差分。包含R1 J、rho/alpha/species链式响应、beta、实际下端LIQUID_TMIN/GAS_TLOW/HARD_PMIN及energyTol活动分支。Pure-phase共同根余量为N/A（以mixed标识），不把它硬写为二相根。

   anchor235 cell53 `FLoDot=2.958426072e+11`、`energyTolDot=0.001863865794`、`marginDot=-2.958426072e+11` J/m³/s；各项如下，严重抵消不隐藏：

| coordinate | qdot | partial FLo | partial eta | margin-rate contribution |
|---|---|---|---|---|
| alphaL | 0.37732004 | -1.638391013e+14 | 0 | 6.181977625e+13 |
| mG | 1695.893018 | -688.9513261 | 1.377902652e-09 | 1168387.743 |
| mL | 286.0376647 | 2.171642783e+11 | 1.377902652e-09 | -6.211716303e+13 |
| Mx | 793808.33 | 37.12011115 | -7.424022231e-11 | -29466253.45 |
| My | 0 | 0 | -0 | -0 |
| Mz | 0 | 0 | -0 | -0 |
| Et | 960033696.5 | -1 | 2e-12 | 960033696.5 |
| mY0 | 0 | 1196180.304 | 0 | -0 |
| mY1 | 386.6636081 | -304589.9578 | 0 | 117773852.1 |
| mY2 | 1309.22941 | -377822.3025 | 0 | 494656070.1 |

   225个受约束partial finite-difference独立核对，maxrelativeerror=4.140344501e-05，最大差来自mL有限扰动的endpoint逆映射曲率；没有据此放宽R1/物理门槛。导数是当前冻结数学函数在局部分支的解析线性化，不声称binary64台阶可微或存在全域光滑导数。

4. **Alpha sensitivity**：anchor235 `dFLo/d(alphaDot)=-1.638391013e+14`、`dMargin/d(alphaDot)=1.638391013e+14`。这里实际含义是FLo对alpha状态的partial系数乘入alphaDot；其它conservative derivatives完全冻结。液体Tmin active endpoint：`f_a=-mG betaG PG rhoG/alphaG +mL betaL PL rhoL/alphaL -J pL_rhoT rhoL/alphaL`。margin对alpha直接项=−f_a，eta对alpha直接partial=0。每anchor、每cell均保存，不由总FD倒推。

5. **K_req_neutral**：采用完整marginDot，`alphaDotN=alphaDotK0+marginDotK0/f_a`。anchor235 originaltotalalphaDot=0.37732004、neutral=0.3791257299 s⁻¹，divU=-132.0398669 s⁻¹。按要求literal KreqN=-0.002871297425。由于material alpha equation包含输运，物理source需扣除原transport：`KsourceN=(alphaDotN-alphaDotK0)/divU=-1.367533853e-05`。两者都报告，不能混用。|divU|≤1e-10时记录undefined，不伪造K。contact的divU=0附近不生成Kreq。

6. **K_req_interior**：指定有限诊断target `r=max(abs(marginDotK0),eta/1e-9 s)`，`alphaDotI=alphaDotN-r/f_a`；anchor235 target=2.958426072e+11，alphaDotI=0.3809314198，literal KreqI=-0.002884972763，sourceKreqI=-2.735067707e-05。RN使marginDot≈0；RI使marginDot≈target>0。因为energyTolDot不严格为0，neutral marginDot与neutral FLoDot差这项，未伪称二者数值完全等价。RN/RI是有意人工控制，不能视作model EOS closure。

7. **K_PE derivation**：在两phase mass conservation及局部isentropic压力响应下，`D rhoL=-rhoL(1+K/alphaL)divU`、`D rhoG=-rhoG(1-K/alphaG)divU`。令 `A_k=rho_k*c_k²`，压缩压力率相等要求 `AL(1+K/alphaL)=AG(1-K/alphaG)`，解得 `K_PE=alphaL*alphaG*(AG-AL)/(alphaG*AL+alphaL*AG)`。这是按当前alphaL符号重新推导；AL>AG⇒K<0，压缩divU<0⇒alphaL增加。完整推导、general-EOS/R1/energy/acoustic/ALE线性化保存为 `DERIVATION.md`，没有照搬文献作production模型。

8. **K_PE/K_req comparison**：24micro符号同向。literal `abs(KPE/KreqI)`≈0.006968554808，相差约143.5倍，**literal replacement不能直接采用**；扣除原alpha输运之后 `KPE/KsourceN`≈1.470098216、`KPE/KsourceI`≈0.7350491082，同数量级。anchor235 KPE=-2.010409083e-05，transport+PE使marginDot≈1.390750829e+11，向内但小于人工RI target。正确的source comparison与literal comparison都有证据，结果不是通过重定义K掩盖失败。

| anchor | Kreq neutral(total) | Kreq interior(total) | Ksource neutral | Ksource interior | K_PE |
|---|---|---|---|---|---|
| 230 | -0.001325672578 | -0.001338632453 | -1.295987548e-05 | -2.591975095e-05 | -1.819820207e-05 |
| 235 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 240 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 260 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 330 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 530 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 651 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 1000 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 1309 | -0.002871297425 | -0.002884972763 | -1.367533853e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 3000 | -0.002871297425 | -0.002884972763 | -1.367533854e-05 | -2.735067707e-05 | -2.010409083e-05 |
| 6000 | -0.002871297425 | -0.002884972763 | -1.367533854e-05 | -2.735067708e-05 | -2.010409083e-05 |
| 10000 | -0.002871297425 | -0.002884972764 | -1.367533854e-05 | -2.735067709e-05 | -2.010409083e-05 |
| 10852 | -0.002871297425 | -0.002884972764 | -1.367533854e-05 | -2.735067709e-05 | -2.010409083e-05 |
| 15000 | -0.002871297426 | -0.002884972764 | -1.367533855e-05 | -2.73506771e-05 | -2.010409083e-05 |
| 20000 | -0.002871297426 | -0.002884972764 | -1.367533855e-05 | -2.735067711e-05 | -2.010409083e-05 |
| 22260 | -0.002871297426 | -0.002884972765 | -1.367533856e-05 | -2.735067711e-05 | -2.010409083e-05 |
| 24000 | -0.002871297426 | -0.002884972765 | -1.367533856e-05 | -2.735067711e-05 | -2.010409083e-05 |
| 26000 | -0.002871297426 | -0.002884972765 | -1.367533856e-05 | -2.735067712e-05 | -2.010409083e-05 |
| 27659 | -0.002871297426 | -0.002884972765 | -1.367533856e-05 | -2.735067712e-05 | -2.010409083e-05 |
| 28000 | -0.002871297426 | -0.002884972765 | -1.367533856e-05 | -2.735067712e-05 | -2.010409083e-05 |
| 30000 | -0.002871297426 | -0.002884972765 | -1.367533856e-05 | -2.735067713e-05 | -2.010409083e-05 |
| 31000 | -0.002871297427 | -0.002884972765 | -1.367533856e-05 | -2.735067713e-05 | -2.010409083e-05 |
| 32000 | -0.002871297427 | -0.002884972765 | -1.367533857e-05 | -2.735067713e-05 | -2.010409083e-05 |
| 32219 | -0.002871297427 | -0.002884972765 | -1.367533857e-05 | -2.735067713e-05 | -2.010409083e-05 |
| 32252 | -0.002871297427 | -0.002884972765 | -1.367533857e-05 | -2.735067713e-05 | -2.010409083e-05 |

9. **K0 strict-root scans**：25anchors，每种从selected微尺度的1×/2×/4×…到freshCap，以及freshCap/2^j到selected/16，额外dt=0，FAIL后继续。每个candidate all100 raw/post原species closure/P2/presence/strict/native检查。24micro K0没有已测strict-positive-dt见证；healthy230达到freshCap。只说明本finite ladder，非全binary64/global无正dt证明。FLoDot向外≈2.9584e11。固定方向的1×/10×tolerance不会改变FLo或FLoDot。

10. **RN scans**：all100严格合法positive见证=0/24micro；cell53单独则24/24达到freshCap，`local_cell53_scans.csv`保留。将各cell下端margin都强行neutral的同一个规则，导致其它cell先触发EOS density interval等条件；不能用cell53成功替代all100。RN也破坏300K exact-contact p/rho property，作为实施候选拒绝。

11. **RI scans**：all100严格合法positive见证=0/24micro；cell53单独24/24达到freshCap。其它cells出现rho-domain/P2限制，300K contact property也破坏。RI只是root-direction响应控制；positive linear margin rate不保证完整PDE/gates。

12. **PE scans**：literal PE=KPE*divU替换**总alphaDot**，all100及cell53均无micro strictpositive见证；删除原transport，contact破坏，候选拒绝。补充且明确区分的 **PE_TRANSPORT** 用 `alphaDot=originalK0Derivative+KPE*divU`，其P2增量由原numerator DD增量加PE source DD构造，24/24micro all100 raw/post strict+native达到freshCap。其它Q1..Q9与K0 trial逐位一致，不改flux/sound speed。主表如下：

| anchor | largest known native K0 dt | K0 strict | RN strict | RI strict | PE strict | PE+transport strict | gain vs largest known native |
|---|---|---|---|---|---|---|---|
| 230 | 1.205093328e-06 | 1.205093328e-06 | 0 | 0 | 0 | 1.205093328e-06 | 1 |
| 235 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 240 | 1.644039241e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 7.330077519e+11 |
| 260 | 1.971017105e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.114069254e+11 |
| 330 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 530 | 9.590228906e-19 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 1.256584717e+12 |
| 651 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 1000 | 2.192052321e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 5.497558139e+11 |
| 1309 | 6.064668015e-19 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 1.987072508e+12 |
| 3000 | 9.590228906e-19 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 1.256584717e+12 |
| 6000 | 1.971017105e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.114069254e+11 |
| 10000 | 1.971017105e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.114069255e+11 |
| 10852 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 15000 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 20000 | 2.192052321e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 5.497558139e+11 |
| 22260 | 9.590228906e-19 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 1.256584717e+12 |
| 24000 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 26000 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 27659 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 28000 | 2.192052321e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 5.497558139e+11 |
| 30000 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 31000 | 2.192052321e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 5.497558139e+11 |
| 32000 | 2.192052321e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 5.497558139e+11 |
| 32219 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |
| 32252 | 1.918045781e-18 | 0 | 0 | 0 | 0 | 1.205093508e-06 | 6.282923587e+11 |

13. **Gain thresholds**：strict K0 baseline为空，strict/strict gain **undefined**，不除以0也不写inf。有限ratio的denominator=max(原selected、TD2/IDP1 largest tested original legal dt、本轮K0 native largest tested)，是“largest KNOWN TESTED native legal”，非全域maximum。relative to selected的另一列完整留在 `anchor_results.json`。阈值统计如下：

| variant | ≥10 | ≥1e3 | ≥1e6 | ≥1e9 | ≥1e12 | median gain | median strict dt |
|---|---|---|---|---|---|---|---|
| K0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| RN | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| RI | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| PE | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| PE_TRANSPORT | 24 | 24 | 24 | 24 | 4 | 6.282923587e+11 | 1.205093508e-06 |

   PE_TRANSPORT 24/24≥1e6，median gain=6.282923587e+11≥1e9，medianstrictdt=1.205093508e-06≥1e-9，24/24freshCap≈1.205e-6。≥1e12为4/24，不能把relative-to-selected较大比值冒充本正式denominator统计。material success针对**从原native合法committed到严格interior的新shadow witness**；旧24个strict-invalid baseline从未伪造为strict有效。不能宣称已获得从dt=0起全strict连通区间或TD1实际推进。

14. **FreshCap tests**：每anchor/fourrequestedvariants和supplementary PE_TRANSPORT直接测原freshCap。healthy230 K0及PE_TRANSPORT PASS，RN/RI/PE all100 FAIL；24micro只有PE_TRANSPORT all100 strict/native PASS。原cap、first limiting cell/condition、mass/species/P2 failures见 `scans.csv`/`anchor_results.json`。RN/RI firstcell随dt而变（常16–20/phase density或P2），literalPE常cell52/53或其它root；不把它们归为同一种机制。PE_TRANSPORT全部ladder mass/species/P2 failure计数0。

15. **Exact-contact controls**：复用MC1 periodic100cells，p=3MPa/U=20/TG800，alpha sinusoidal，TL300/265；dt=.25原jointcap≈6.4733e-7。PE_TRANSPORT与K0全部native property结果相同，U保持、p/rho误差与原R1/binary64相同。literalPE删除alpha输运：300K p误差.445Pa/rho误差.0351kg/m³；265K50/100 native失败，明确拒绝。RN/RI在300K的rho变化显著超出原binary误差，拒绝为contact-preserving模型。

| case | variant | native fail/100 | strict fail/100 | max Δp Pa | max ΔU m/s | max ΔrhoL kg/m³ |
|---|---|---|---|---|---|---|
| CONTACT_TL300 | K0 | 0 | 0 | 2.793967724e-09 | 1.065814104e-14 | 2.273736754e-13 |
| CONTACT_TL300 | RN | 0 | 0 | 0.0009742113762 | 1.065814104e-14 | 7.679793748e-05 |
| CONTACT_TL300 | RI | 0 | 0 | 0.002759017982 | 1.065814104e-14 | 0.0003001973964 |
| CONTACT_TL300 | PE | 0 | 0 | 0.4451479441 | 1.065814104e-14 | 0.03508956093 |
| CONTACT_TL300 | PE_TRANSPORT | 0 | 0 | 2.793967724e-09 | 1.065814104e-14 | 2.273736754e-13 |
| CONTACT_TL265 | K0 | 0 | 16 | 3.511086106e-07 | 1.865174681e-12 | 2.273736754e-13 |
| CONTACT_TL265 | RN | 0 | 17 | 3.511086106e-07 | 1.865174681e-12 | 2.273736754e-13 |
| CONTACT_TL265 | RI | 0 | 0 | 2.468004823e-08 | 1.865174681e-12 | 1.150738171e-09 |
| CONTACT_TL265 | PE | 50 | 50 | 0.4468103736 | 1.865174681e-12 | 0.03638444903 |
| CONTACT_TL265 | PE_TRANSPORT | 0 | 16 | 3.511086106e-07 | 1.865174681e-12 | 2.273736754e-13 |

   Tmin contact必须诚实区分native与strict：原K0及PE_TRANSPORT都有16/100 binary strict sign失败，却100/100原native R1接受、p/U/rho维持原精度。这是构造在exact265K边界的既有roundoff问题，不是新closure改善，也不记成“contact所有strict PASS”；该candidate通过的是用户要求的**原contact property回归**。phase boundary contact的严格表示设计仍属未来工作。

16. **Smooth-compression controls**：MC1同TL300/265、kappa=.001/.01/.1/1、centerU0/left+kappa*V/right−kappa*V，dt1e-8；四mandatory+supplementary共40controls。记录完整alphaDot/rhoLdot/pdot/TLdot/marginDot与strict/native。K0在265K全部root向外并FAIL；PE及PE_TRANSPORT在该homogeneous情形相同（originalalphaDot=0），8/8 native+strict PASS，100digit确认。RN marginDot≈0且265K仍tolerance-only；RI人工向内。fulltable如下：

| case | variant | alphaDot | rhoLdot | pdot | TLdot | marginDot | native fail | strict fail |
|---|---|---|---|---|---|---|---|---|
| COMPRESSION_TL300_K0.001000 | K0 | 0 | 0.7274329672 | 4069.196249 | -0.9491008407 | 9828.789216 | 0 | 0 |
| COMPRESSION_TL300_K0.001000 | RN | 6.581644505e-06 | -238.6578244 | 558.1784005 | 312.7758864 | 0 | 0 | 0 |
| COMPRESSION_TL300_K0.001000 | RI | 0 | 0.7274329672 | 4069.196249 | -0.9491008407 | 9828.789216 | 0 | 0 |
| COMPRESSION_TL300_K0.001000 | PE | 1.992797778e-08 | 0.002619573478 | 4058.565549 | 0.0007992291099 | 9799.029497 | 0 | 0 |
| COMPRESSION_TL300_K0.001000 | PE_TRANSPORT | 1.992797778e-08 | 0.002619573478 | 4058.565549 | 0.0007992291099 | 9799.029497 | 0 | 0 |
| COMPRESSION_TL300_K0.010000 | K0 | 0 | 7.274330258 | 40691.96695 | -9.491009171 | 98287.90345 | 0 | 0 |
| COMPRESSION_TL300_K0.010000 | RN | 6.581645261e-05 | -2386.578518 | 5581.784435 | 3127.759223 | 0 | 0 | 0 |
| COMPRESSION_TL300_K0.010000 | RI | 0 | 7.274330258 | 40691.96695 | -9.491009171 | 98287.90345 | 0 | 0 |
| COMPRESSION_TL300_K0.010000 | PE | 1.992797939e-07 | 0.02619573593 | 40585.65994 | 0.007992294241 | 97990.30623 | 0 | 0 |
| COMPRESSION_TL300_K0.010000 | PE_TRANSPORT | 1.992797939e-07 | 0.02619573593 | 40585.65994 | 0.007992294241 | 97990.30623 | 0 | 0 |
| COMPRESSION_TL300_K0.100000 | K0 | 0 | 72.74336111 | 406920.1125 | -94.91016795 | 982880.1528 | 0 | 0 |
| COMPRESSION_TL300_K0.100000 | RN | 0.0006581652749 | -23865.81236 | 55817.88785 | 31277.62785 | 1.164153218e-10 | 0 | 0 |
| COMPRESSION_TL300_K0.100000 | RI | 0 | 72.74336111 | 406920.1125 | -94.91016795 | 982880.1528 | 0 | 0 |
| COMPRESSION_TL300_K0.100000 | PE | 1.992799543e-06 | 0.2619575581 | 405857.0416 | 0.07992314299 | 979904.1783 | 0 | 0 |
| COMPRESSION_TL300_K0.100000 | PE_TRANSPORT | 1.992799543e-06 | 0.2619575581 | 405857.0416 | 0.07992314299 | 979904.1783 | 0 | 0 |
| COMPRESSION_TL300_K1.000000 | K0 | 0 | 727.439466 | 4069245.433 | -949.1093066 | 9828913.391 | 0 | 0 |
| COMPRESSION_TL300_K1.000000 | RN | 0.006581727656 | -238660.8422 | 558183.2275 | 312779.8415 | 0 | 0 | 0 |
| COMPRESSION_TL300_K1.000000 | RI | 0 | 727.439466 | 4069245.433 | -949.1093066 | 9828913.391 | 0 | 0 |
| COMPRESSION_TL300_K1.000000 | PE | 1.992815582e-05 | 2.619596668 | 4058614.638 | 0.7992499096 | 9799153.406 | 0 | 0 |
| COMPRESSION_TL300_K1.000000 | PE_TRANSPORT | 1.992815582e-05 | 2.619596668 | 4058614.638 | 0.7992499096 | 9799153.406 | 0 | 0 |
| COMPRESSION_TL265_K0.001000 | K0 | 0 | 0.754261098 | 4069.244528 | -0.9732677168 | -3263389.39 | 1 | 1 |
| COMPRESSION_TL265_K0.001000 | RN | 1.992975236e-08 | 0.002649264511 | 4058.573313 | -3.87162683e-14 | 0 | 0 | 1 |
| COMPRESSION_TL265_K0.001000 | RI | 3.985950473e-08 | -0.748962569 | 4047.902098 | 0.9732677168 | 3263389.39 | 0 | 0 |
| COMPRESSION_TL265_K0.001000 | PE | 1.994415564e-08 | 0.002106072785 | 4058.565601 | 0.0007033829802 | 2358.459564 | 0 | 0 |
| COMPRESSION_TL265_K0.001000 | PE_TRANSPORT | 1.994415564e-08 | 0.002106072785 | 4058.565601 | 0.0007033829802 | 2358.459564 | 0 | 0 |
| COMPRESSION_TL265_K0.010000 | K0 | 0 | 7.54261154 | 40692.44988 | -9.732677888 | -32633896.32 | 1 | 1 |
| COMPRESSION_TL265_K0.010000 | RN | 1.992975384e-07 | 0.02649264811 | 40585.73772 | 1.10708624e-13 | 0 | 0 | 1 |
| COMPRESSION_TL265_K0.010000 | RI | 3.985950768e-07 | -7.489626244 | 40479.02556 | 9.732677888 | 32633896.32 | 0 | 0 |
| COMPRESSION_TL265_K0.010000 | PE | 1.994415725e-07 | 0.02106068028 | 40585.6606 | 0.007033895278 | 23584.81518 | 0 | 0 |
| COMPRESSION_TL265_K0.010000 | PE_TRANSPORT | 1.994415725e-07 | 0.02106068028 | 40585.6606 | 0.007033895278 | 23584.81518 | 0 | 0 |
| COMPRESSION_TL265_K0.100000 | K0 | 0 | 75.4261761 | 406924.9418 | -97.32685712 | -326339225.5 | 1 | 1 |
| COMPRESSION_TL265_K0.100000 | RN | 1.992976986e-06 | 0.2649267697 | 405857.8193 | -4.133384367e-13 | 0 | 0 | 1 |
| COMPRESSION_TL265_K0.100000 | RI | 3.985953972e-06 | -74.89632257 | 404790.6969 | 97.32685712 | 326339225.5 | 0 | 0 |
| COMPRESSION_TL265_K0.100000 | PE | 1.994417331e-06 | 0.2106069772 | 405857.0481 | 0.07033910073 | 235848.6479 | 0 | 0 |
| COMPRESSION_TL265_K0.100000 | PE_TRANSPORT | 1.994417331e-06 | 0.2106069772 | 405857.0481 | 0.07033910073 | 235848.6479 | 0 | 0 |
| COMPRESSION_TL265_K1.000000 | K0 | 0 | 754.267832 | 4069293.728 | -973.2763951 | -3263418489 | 1 | 1 |
| COMPRESSION_TL265_K1.000000 | RN | 1.992993007e-05 | 2.649296564 | 4058622.417 | -3.936875176e-12 | -4.768371582e-07 | 0 | 1 |
| COMPRESSION_TL265_K1.000000 | RI | 3.985986014e-05 | -748.9692388 | 4047951.107 | 973.2763951 | 3263418489 | 0 | 0 |
| COMPRESSION_TL265_K1.000000 | PE | 1.994433383e-05 | 2.106086705 | 4058614.705 | 0.7034064613 | 2358538.296 | 0 | 0 |
| COMPRESSION_TL265_K1.000000 | PE_TRANSPORT | 1.994433383e-05 | 2.106086705 | 4058614.705 | 0.7034064613 | 2358538.296 | 0 | 0 |

   265K,kappa1：K0 TLdot≈−973.276 K/s、marginDot≈−3.2634e9；PE TLdot≈+.703406 K/s、marginDot≈+2.3585e6。既有total Et flux完全保留，PE抑制液体intrinsic density压缩过快并使endpoint方向进入strict域。kappa.001的微小变化也由高精度确认，非只binary64改善。

17. **High-precision confirmation**：11260 arithmetic/input rows，native及Boost100 decimal digits；数学函数、exact Q/P2、energy reference、native局部gas mixture与HARD内pressure interval保持MC1方法。每个positive all100最大strict witness均检查100cell raw+100cell post的100digit root：25 PE_TRANSPORT及healthyK0，共5200高精度cell checks PASS。PE_TRANSPORT最大dt cell53高精度margin量级163511.7563…3256935.893 J/m³，远离micro容差带；并检查各variant committed/selected/best/fresh及contact代表点、compression。旧micro committed在高精度仍不strict有效，不能因新shadow成功改写旧native operational-domain定义。100digit没有执行生产恢复/提交，也没有EOS HARD外查询。

18. **Recovery-only result**：冻结K0原direction对strict/native1×/diagnostic10×分开保存。FLoDot同一个解析值，不因tol因子改变；marginDot(s)=s*etaDot−FLoDot仍负，24/24micro向外。10×cell53最大已测native合法dt约1.402913486e-16…2.522901894e-16，仍micro，与usefulfreshCap差多个数量级；它不是all100/time资格。恢复语义A strict-only拒绝旧24baseline，B current允许endpointband，C BOUNDARY_ONLY可显式分类而不捏造interior（**C未实现**）。trial rollback需保留committed本身合法语义；若未来strict-only设计不能把旧committed-invalid当普通trial rollback解决。recovery-only不能逆转root方向或恢复usefulphysicaltime，**不得作为primary repair**。

19. **Acoustic implication**：**REQUIRED MODEL REDERIVATION**。不是假设旧Allaire仍可保留。当前代码 `c0²=(alphaG*xiG*AG+alphaL*xiL*AL)/(rhoMix*(alphaG*xiG+alphaL*xiL))`；actualenergy/R1线性化产生 `cK²=[B0+K*(xiL*AL-xiG*AG)]/(rhoMix*J)`。PE代入得到 `cPE²=1/(rhoMix*(alphaL/AL+alphaG/AG))`，独立数值核对25anchors均PASS。235 currentc=565.2824581，PElinearc=564.6016376 m/s，虽相差约0.12%但不相同。未来须重新推导特征/波界/KT/nonconservative terms/纯相及trace极限；本轮waves/cap全部original冻结，成功shadow不证明未来改变波速后的scheme资格。

20. **Energy implication**：Q6/Et conservative direction与原flux逐位一样，未添加heat/phase-energy/nonconservativeEt source。R1从相同totalenergy与变更fraction恢复commonp，所测宏观witness在strict域内满足原closure；smoothcompression pdot/TLdot由原beta/J/energychain给出。该局部一致性不证明TG!=TL的two-temperature shock模型、interphaseentropy/weakproducts或生产热过程完整性。当前测试不需要额外Et source；如果未来理论模型需要phasework分配，必须显式设计审查，不能偷偷加能量来救根。

21. **ALE implication**：只保存推导要求，未执行ALE。material `Da/Dt=K divUphysical`导出 moving-cell `d(Va)/dt+sum[a_f(phiPhysical-phiMesh)]=V(a+K)divUphysical`，GCL `dV/dt=sum phiMesh`。物理div与relativefluxdiv不能混同；需要一致alpha flux/source、mesh运动及GCL discretization/constant-state测试，不能简单append K*fvc::div(U)。完整推导见DERIVATION。

22. **P2 implication**：所有alpha shadow使用原signedminority/advanced DD、switching与PRESENT semantics，q0从同一fraction authority读取；无directalpha overwrite、clip、threshold、phase deletion或额外独立alpha。PE_TRANSPORT所有candidate P2 failures0；RN/RI可能触发P2/rho域限制，真实保留。未来source quadrature/pure/trace/crossing及ALE仍需单独设计资格。

23. **Species implication**：原frozen species flux，q7/q8及dependent q9 closure保持，raw/post逐cell全部审计。各variant Q1..Q9始终等于originaltrial位串；没有normalize(Y)。PE_TRANSPORT mass/speciesfailure0；gascompositionderivative通过conservative simplex链式分解，未添加mass transfer。

24. **Conservation / high-Mach implication**：phase masses、momentum、Et、species均沿原保守flux；只改变非保守alpha model诊断。不是正式timeadvance/shock/restart/productionconservationqualification。KPE仅thermodynamicstate、divU，显式不依赖absoluteU；RN/RI则是方向控制，不视作local EOS模型。75个coherent velocity offset algebra tests（−3000/+300/+10000m/s）内能导数不变量误差<1e-9相对，`galilean_control.json`保留。固定网格KT数值耗散/frame与正式high-Mach未测试，不能声称整体离散Galilean资格。

25. **Outcome M1–M5**：**M1，限定derived-compatible PE_TRANSPORT**。24/24满足≥1e6且中位≥1e9/≥1e-9 strict dt、no original-nativecommittedinvalidity/no massspeciesP2failure、all100 raw/post高精度确认、contactproperty回归、compressioncontrol。literalPE不同公式FAIL，不能采用；RN/RI只有局部成功而全域失败，非M2生产候选。不是M3全部alpha控制失败，不是M4 recoveryprimary。物理相态certificate unresolved和未来model/acoustic/ALE未知仍保留，不通过这些shadow自动获得production许可。

26. **Recommended next model stage**：NEXT ROUND ONLY **M6B.1-MC3-NONZERO-K-MODEL-DESIGN**，范围应先统一material/source semantics、currentenergy/generalEOS压力平衡响应、声速特征及ALE/GCL/entropy/puretrace/nonconservativeproducts。不能直接设置K!=0并沿用oldKT/sound/recovery。**本轮不实施、不安装、不重跑TD1/productionshock。**

27. **EOS hashes**：HARD p=.05–12MPa/T265–400K、81coeff/C_L=369229.9537234281永久冻结；高精度不是新EOS或新fit。

- `liquidEOS/ndecane_gibbs_v3/coefficients.json`：`610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`
- `liquidEOS/ndecane_gibbs_v3/energy_reference.json`：`ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`
- `liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H`：`421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d`
- `liquidEOS/ndecane_gibbs_v3/metadata.json`：`9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`

28. **Temporal hashes**：无搜索/增长/escape新优化，TD1三个既有文件原样：

- `serialFiveEq/runSerialFiveEq.C`：`3327f1988bcca53a459d01f9cb2db0fd7624d946b6da378477c679fbcec7907a`
- `fiveEqIntegration/fiveEqTemporalContract.H`：`e47e6466de56e82856ebc66281acf40061dd121ae917144a1343cf6f9019ba89`
- `fiveEqIntegration/fiveEqTemporalPolicy.H`：`a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062`

29. **Foundation/project hashes**：110sources byte unchanged，115libraries unchanged，Foundation6717/nativeparcel19全部OK；exe/customEOS/thermolibrary SHA前后完全一致；5741prior evidence untouched；MC1ZIP freshSHA/CRC PASS。22500原IDP1conservativeflux bits matched。两个隔离工具最终编译0warning/error。`preservation_gate.json`/empty`active_source.patch`保存证据。修改仅MC2独立工具、记录、milestone追加，旧milestone prefix保持。

30. **MC2 COMPLETE?**：YES，22项**诊断**门槛PASS，negative RN/RI/literalPE与contactTminstrict差异如实记录，不作失败候选PASS。成功的是所声明的补充derived-compatible model source影子。noactive source change/noactive install。

| MC2 gate | status |
|---|---|
| all frozen anchors reproduced | PASS |
| exact root-margin derivative | PASS |
| alpha sensitivity derived | PASS |
| K_req_neutral computed | PASS |
| K_req_interior computed | PASS |
| K_PE independently derived | PASS |
| K_PE vs K_req compared | PASS |
| K0/RN/RI/PE shadows run | PASS |
| strict-root dt scans completed | PASS |
| gain statistics completed | PASS |
| contact controls completed | PASS |
| compression controls completed | PASS |
| high-precision confirmation | PASS |
| recovery-only branch evaluated | PASS |
| acoustic consequence evaluated | PASS |
| energy consequence evaluated | PASS |
| ALE consequence documented | PASS |
| P2 implications documented | PASS |
| no active source modification | PASS |
| EOS unchanged | PASS |
| TD1 unchanged | PASS |
| Foundation unchanged | PASS |

31. **TD1 status**：PARTIAL / LOCAL CORRECTNESS PASS / MICROSTEP EFFICIENCY UNRESOLVED。没有TD1新跑；shadowusefuldt不是driver实际推进。只有未来模型设计/实现/资格后才能独立授权freshTD1。

32. **DYN-CLOSURE status**：NOT AUTHORIZED / NOT EXECUTED，TD1 COMPLETE prerequisite未满足。

33. **M6B.1/M6B status**：PARTIAL。MC2只关闭alpha-closure hypothesis诊断；endTime/productionCFD/restart/activeDPM/highMach/phasecertificate均未因此完成。

34. **Milestone matrix**：

| milestone | authoritative status |
|---|---|
| PHASE-DEFER | COMPLETE / POLICY FROZEN；historical CLASS D / phase certificate unresolved |
| EOS3-NUMERICAL | COMPLETE / OPERATIONAL DOMAIN FROZEN，265–400K；非phase/production资格 |
| ADM1 | COMPLETE |
| TD1 | PARTIAL / LOCAL CORRECTNESS PASS / MICROSTEP EFFICIENCY UNRESOLVED |
| TD2 | PARTIAL / DIAGNOSIS CLOSED / MICROSTEP ADMISSIBILITY LIMIT |
| IDP1 | COMPLETE / IDP-G / C primary + F secondary |
| MC1 | COMPLETE / MC-F |
| MC2 | COMPLETE / ALPHA-CLOSURE HYPOTHESIS CLASSIFIED / M1 derived-compatible PE source with transport / STOP |
| MC3 nonzero-K model design | NEXT ROUND ONLY / NOT EXECUTED |
| active nonzero-K / sound / alpha PDE / recovery tolerance changes | NOT EXECUTED |
| DYN-CLOSURE | NOT AUTHORIZED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL |
| M6B.2 / DPM / T4-S3 / production CFD | NOT EXECUTED / 未认证 |

**STOP。** 全部gates/ledger/推导位于 `fitting/integration/m6b1_mc2_alpha_closure_compatibility_v1/`。封存包 `D:/DATA/Solver/checkpoints/M6B1_MC2_ALPHA_CLOSURE_HYPOTHESIS_CLASSIFIED_STOP_v1.zip`，SHA/CRC见 `checkpoint_gate.json`。
