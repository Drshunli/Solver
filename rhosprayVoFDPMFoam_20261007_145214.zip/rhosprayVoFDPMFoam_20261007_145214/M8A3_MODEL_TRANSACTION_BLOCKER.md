# M8A.3 final report — MODEL_TRANSACTION_BLOCKER

The required stopping rule in user section 51 has been reached. No production
model has been disabled and no installation/active solver source is changed.
This round establishes a concrete evolved-state counterexample, not closure.

## 1. M8A.3 status

PARTIAL / MODEL_TRANSACTION_BLOCKER. Stop under section 51.

## 2. Evolved-cloud snapshot definition

S_cloud/S_total requirements are defined in docs/M8A3_TRANSACTION_STATE_INVENTORY.md.
Audit states A/B/C have 5/7/9 native accepted steps, 106/148/190 parcels and
nonzero ongoing injected mass. These are no-CFD native cloud evolutions.
Their histories are not represented as forced breakup/collision/rebound
histories; those required events remain untested.

## 3. Complete mutable-state inventory

Inventory separates authoritative state, immutable configuration, derived
cache and output-only state. Full Random includes x_, scalarNormalStored_
and scalarNormalValue_. The inventory is a requirement definition, not an
implemented canonical complete model-state dump.

## 4. Nested ownership audit

Actual source proves nested old owner, old properties_ and old distribution
RNG references. All eight native model clone owners alias committed in each
evolved state. Calling cloned coneInjection::setProperties advances committed
RNG, not clone RNG. The deliberate fixture audit effect is restored before
the next seed step; clone is never used as an eligible transaction.

## 5. Production model capability table

Classifications apply to the CURRENT evolved-cloud transaction implementation,
not the theoretical capability of each physical model.

| Enabled model | Final transaction classification | Blocking evidence |
|---|---|---|
| coneInjection | NOT TRANSACTION-SAFE | owner/properties/nested RNG retain original; actual committed RNG mutation |
| sphereDrag | NOT TRANSACTION-SAFE | evolved clone owner aliases committed; accepted baseline gate absent |
| stochasticDispersionRAS | NOT TRANSACTION-SAFE | evolved clone owner aliases committed; complete stochastic history gate absent |
| blobsSheetAtomization | NOT TRANSACTION-SAFE | evolved clone owner aliases committed; child/history contract absent |
| ReitzKHRT | NOT TRANSACTION-SAFE | evolved clone owner aliases committed; child/ID retry absent |
| ORourke | NOT TRANSACTION-SAFE | evolved clone owner aliases committed; mutation/deletion retry absent |
| rebound | NOT TRANSACTION-SAFE | evolved clone owner/properties alias; full statistics transaction absent |
| voidFraction | NOT TRANSACTION-SAFE | clone owner alias and native diagnostic copy-state loss; evolved commit absent |

No UNKNOWN/PARTIAL model classification is used to bypass closure.

## 6. Stochastic transaction result

NOT PASS. Random value is copied by native cloud, but selected model use
paths are not isolated. Scalar sequence probes demonstrate alias mutation;
they do not certify all normal variates/history.

## 7. Ongoing injection transaction

Evolved injected-mass and parcel initialization match native clone; owner
and nested RNG are unsafe. NOT PASS for continued transactional evolution.

## 8. Breakup child transaction

NOT EXECUTED after blocker; no child creation/rollback claim.

## 9. Collision/coalescence transaction

NOT EXECUTED after blocker; no merge/delete transaction claim.

## 10. Rebound transaction

Prior local proof preserved. New evolved full transaction NOT EXECUTED.

## 11. Source accumulator transaction

Native clone source arrays and coefficients initialize byte-equal in A/B/C.
This does not guarantee subsequent isolated accumulation through aliased
owners. Full transaction NOT PASS.

## 12. Support probe scalability fix

NOT EXECUTED after section-51 stop. Existing 256-entity bounded probe retained.

## 13. Full production mesh support scan

NOT EXECUTED. Previous mesh census is not a support scan. No fabricated
contributor counts, fractions or exclusion thicknesses are reported.

## 14. Strict-support feasibility

NOT ESTABLISHED. No claim of suitability/infeasibility without the full scan.

## 15. Support-cache/local-hook design

Previous strict-support hooks remain prototypes. Scalable local stencil and
accepted-Q invalidation/rollback cache not implemented this round.

## 16. Cloud/Q atomic commit architecture

Required S_total definition recorded; implementation NOT EXECUTED because
an eligible evolved trial cloud cannot yet be constructed.

## 17. Source-recovery rejection rollback

NOT EXECUTED. Frozen adapter remains unchanged.

## 18. Accepted-output commit

No evolved transaction commit implementation. The seed native accepted
steps use normal native output in an isolated new fixture; this is NOT proof
of deferred accepted output for transactions.

## 19. Rejected-output result

No eligible rejected evolved trial exists. Prior initial-state noWrite proof
retained; no new full output-gate PASS is asserted.

## 20. VoidFraction result

Diagnostic trajectory-time semantics unchanged. Native clone state loss
remains a blocker; accepted integral release is not implemented.

## 21. Native-vs-transaction accepted-event regression

NOT EXECUTED. Audit uses real native seed evolution, then demonstrates why
clone cannot be used for the independent future-evolution path.

## 22. Evolved direct-small-step result

NOT EXECUTED. Ordered parcel/source initialization equality is not whole-step
cloud/Q/output golden equivalence.

## 23. Oversized reject/retry result

NOT EXECUTED.

## 24. Injection retry

NOT PASS: an actual evolved copied-injector reference counterexample exists.

## 25. Breakup retry

NOT EXECUTED.

## 26. Collision retry

NOT EXECUTED.

## 27. Combined-event retry

NOT EXECUTED.

## 28. Support-failure retry

NOT EXECUTED for evolved full state.

## 29. Source-failure retry

NOT EXECUTED for evolved full state.

## 30. Repeated transaction lifecycle

1000 evolved begin/discard and repeated commit NOT EXECUTED. Previous fresh
lifecycle results are historical only and not promoted.

## 31. Registry/memory result

No new leak/readiness conclusion. Three audit clones are destroyed normally;
this is insufficient for the required repeated evolved ownership gate.

## 32. 2-rank parcel crossing

NOT EXECUTED after blocker. MPI environment availability was already proven;
the missing gate must not be described as an unavailable environment.

## 33. MPI global accept/discard

Only prior allocator protocol component retained. Full cloud/Q collective
commit/discard NOT IMPLEMENTED.

## 34. MPI communication drain

NOT IMPLEMENTED/TESTED for trial parcel transfer.

## 35. MPI reject/retry equivalence

NOT EXECUTED.

## 36. Global conservation ledger

Frozen source ledger is preserved; no new distributed cloud/Q conservation
result is claimed.

## 37. Particle identity result

Native copied ordered parcel serialization matches in A/B/C. Deliberate
marker allocation is scoped and allocator restored; destruction counter
check passes. Child/processor-crossing retry identity NOT PROVEN.

## 38. Frozen source/energy regression

New outputs under fitting/dpm/m8a3_v1, never historical directories. 9288
source/energy checks must pass and frozen golden/ledger files must be byte
identical; P2/recovery/R1 and temporal/restart results are in regression_summary.json.
Verified: source/energy 9288, P2/recovery/R1 105775 reported checks plus subULP 1000 steps per scheme, temporal/restart 9663 checks; all zero failures. Frozen source golden/ledger bytes and regression result bytes match baseline. These results are separate from transaction closure.

## 39. Project-local overrides

NONE added this round. The standalone audit links native basicSprayCloud;
it intentionally does NOT include M8A.2 overrides or activate a new cloud.
New code consists of audit harness and evidence/regression/report tools.

## 40. Active solver impact

NONE. Frozen DPM formulas, P2/R1/fiveEq thermo, active time loop/equations,
installed OF7 sources and existing case inputs unchanged. No CFD run.
Historical reports/checkpoints/evidence are hash-checked for preservation.

## 41. Remaining blockers

Immediate blocker: no versioned exact evolved model copy/rebinding contract
for owner_, properties_ and nested Random&. Recommended follow-up decision
is a project-local transactional wrapper/adapter with explicit new-owner,
new-properties and full-Random binding and future-evolution equivalence.
No production model is silently disabled. All downstream gates remain open.

## 42. Whether M8A.3 COMPLETE

NO — PARTIAL / MODEL_TRANSACTION_BLOCKER.

## 43. Whether M8A COMPLETE

NO — PARTIAL. Source/energy core remains PASS/FROZEN if regression checks pass.

## 44. M6B.0 start permission

BLOCKED. Do not begin runtime integration.

## 45. M6B.1 permission

NO.

## 46. Updated milestone matrix

| Milestone | Status |
|---|---|
| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE, retained |
| M8A source/energy core | PASS / FROZEN, regression evidence required |
| M8A.1 | PARTIAL, historical report preserved |
| M8A.2 | PARTIAL, historical report preserved |
| M8A.3 | PARTIAL / MODEL_TRANSACTION_BLOCKER |
| M8A overall | PARTIAL |
| M6B.0 | BLOCKED / NOT EXECUTED |
| M6B.1 | NO / NOT EXECUTED |

STOP under the explicit model-transaction blocker rule.
