# M5B — compressible two-material state and common KT flux architecture

## M5B.1 refinement (2026-09-30)

The authoritative next-activation contract is now FIVE_EQ_GOVERNING_CONTRACT.md,
with FIVE_EQ_ALPHA_MODEL.md, FIVE_EQ_ACOUSTICS.md and
FIVE_EQ_STATE_RECOVERY_CONTRACT.md. MFC's pinned implementation is audited in
MFC_FIVE_EQ_SOURCE_AUDIT.md. First activation is ALLAIRE_BASELINE, K=0 and
cAlpha artificial compression OFF. The arbitrary-EOS acoustic formula below
is retained and explicitly requires phase caloric pressure derivatives. No
runtime fields/fluxes or root solver have been added. Numerical KT alpha/contact
compatibility is still a future activation proof; design completion is not
discrete contact preservation or CFD validation.

## 1. Problem statement

The active `rhosprayVoFDPMFoam` is a density-based Kurganov–Tadmor/Tadmor
gas/spray solver. Its `phi`, `phiUp`, and `phiEp` form one conservative flux
family. M5A proved that neither diagnostic `rhoPhiVoF` nor `rhoPhiMix` can
replace `phi` alone. This document chooses a future two-material PDE and
derives a matching flux *architecture*. It activates no two-phase flux.
The user's VOF–DPM papers motivate resolved primary breakup and later
droplet transfer, but their pressure-based algorithms do not define this
solver's shock-capturing flux.

## 2. Existing gas KT system

Current conservative gas states are `rho`, `rhoU`, `rhoE` with `rhoE =
rho*(e+|U|²/2)`. The main `.C` constructs directed gas `rho±`, `rhoU±`,
`e±`, `p±`, gas sound speed `c`, and common `A±=aphiv_pos/neg`.
`phi=A+rho+ + A-rho-`; `phiUp` and `phiEp` use the same face states and
wave bounds. See `KT_FLUX_AUDIT.md` for the exact pressure, dissipation and
moving-mesh terms. The phase-specific, MULES-limited `alphaPhi` is separate.

## 3. Candidate two-phase formulations

| Choice | State and closure | Main benefit | Main difficulty |
|---|---|---|---|
| A. Homogeneous single-fluid VOF | `alphaL,rho,rhoU,rhoE`, one `p,U,T`, mixture EOS | Fewer conserved fields and superficially closer to M4 `rhoMix` | Phase masses not independently conserved; large density/EOS jumps and differently diffused alpha/energy can create pressure errors; shared T is a strong assumption |
| B. Isobaric five-equation, Allaire–Clerc–Kokh style | Conserved `mG,mL,M,Et` plus non-conservative `alphaL`, common `p,U`, phase EOSs | Explicit phase-mass conservation and a pressure-equilibrium closure with documented material-contact conditions | Needs a genuine liquid acoustic/caloric EOS and contact-compatible alpha/flux discretization |
| C. Mechanical-relaxation five-equation, Kapila style | Same conservative fields but alpha equation has a `K div(U)` source | Can represent a different relaxation/acoustic model | Its non-conservative source and Wood-type acoustics cannot be combined casually with B's isobaric closure or M2 alpha transport |

Primary mathematical reference for B: [Allaire, Clerc and Kokh, JCP 181
(2002), 577–616](https://www.cmap.polytechnique.fr/~allaire/ack.pdf).
That paper gives phase mass equations, total momentum/energy, advected volume
fraction, isobaric closure and its acoustic speed. Its numerical method is
Roe-type, so the present KT extension below remains a **proposed architecture**
whose pressure-equilibrium behavior must be proved and validated separately.

## 4. Selected first implementation model

Select **B, isobaric five-equation** as the target model for future work.
There is one mixture velocity and pressure, but no compulsory common phase
temperature. M4's use of the gas `T` to evaluate diagnostic liquid
properties is not a thermodynamic closure for this target model. Requiring
both `TL=TG` and independently conserved phase masses plus total energy can
overconstrain general EOSs: the two phase-density relations and energy may
not admit the same `p,T`. A thermal-equilibrium projection would be another
explicit physical/numerical model, not an implicit M5B assumption.

## 5. Conservative variables

In 3-D let `mG=alphaG*rhoG`, `mL=alphaL*rhoL`, `rho=mG+mL`,
`M=rho*U`, and `Et=rho*E`. The conserved vector is

```
Qc = [mG, mL, Mx, My, Mz, Et].
```

`alphaL` is the seventh, non-conservative material-volume state. Gas species
fractions add reacting-gas transport states in the actual solver; future DPM
mass and species sources must enter the gas phase, not both phase masses.
At M5B these are definitions, not active field replacements.

## 6. Primitive variables and state recovery

`W=[alphaL,rhoG,rhoL,U,p,TG,TL,YG]`, with `alphaG=1-alphaL`.
For present phases, `rhoG=mG/alphaG`, `rhoL=mL/alphaL`, `U=M/rho`, and
`rho*eMix=Et-|M|²/(2*rho)`. Recover common pressure as the root of

```
rho*eMix = mG*eG(rhoG,p,YG) + mL*eL(rhoL,p).
```

The phase EOSs then recover `TG` and `TL`. Near `alpha=0` or `1`, absent
phase divisions and EOS evaluations must be skipped; positivity and root
uniqueness are required. `TWO_PHASE_STATE_OWNERSHIP.md` records ownership.

## 7. Gas EOS

The current `300_2D` case uses OF7
`hePsiThermo/reactingMixture/sutherland/janaf/perfectGas` with sensible
internal energy. At frozen composition the gas relation is
`p=rhoG*R(YG)*TG`, `eG=eG(TG,YG)`, and
`cG²=(CpG/CvG)*p/rhoG`. The current code computes
`c=sqrt((thermo.Cp()/thermo.Cv())/thermo.psi())`; for perfect gas this
reduces to the expression above. Pure-gas matching must preserve this API,
species state and reference-energy convention.

## 8. Liquid EOS requirements

See `LIQUID_EOS_REQUIREMENTS.md`. Local Foundation OF7 `C10H22` spray
properties have a pressure-independent `NSRDSfunc5` density correlation;
`liquidProperties::psi()` returns zero. No finite `cL` or complete
`eL(rhoL,p)` recovery exists in M4. This blocks numerical two-phase KT
activation. A calibrated pressure-density EOS and consistent caloric energy
must be supplied before M6A/flux activation. No sound speed is guessed here.

## 9. Mixture thermodynamics

For the selected model,

```
rho*eMix = mG*eG(rhoG,p,YG) + mL*eL(rhoL,p)
Et       = rho*eMix + 0.5*rho*|U|².
```

Transport properties may still be mixed for viscosity/heat conduction, but
M4 `CpMix` and `kappaMix` do not by themselves define this pressure recovery.
The chosen inviscid flux does not assume `TL=TG`.

## 10. Sound-speed model

For the **selected isobaric model**, define
`xi_k=(partial(rho_k*e_k)/partial p)_{rho_k,Y_k}`,
`Y_k=m_k/rho`, `xi=alphaG*xiG+alphaL*xiL`, and

```
cMix² = (YG*xiG*cG² + YL*xiL*cL²)/xi.
```

This is the isobaric five-equation acoustic relation from the primary model
(its Eq. 29), **not** the Wood speed associated with a different relaxation
closure. It gives `cMix→cG` as `alphaL→0` and `cMix→cL` as `alphaL→1`
when EOS states are admissible. The current liquid lacks `cL,xiL`, so no
`cMix` field or fallback gas acoustic speed is produced.

## 11. Wave-speed model

Once both EOSs exist, reconstruct *one common* left/right two-phase state.
For a face of area `Sf`, set relative `q±=U±·Sf-mesh.phi()` and
`cSf±=cMix±*|Sf|`. The KT bounds are

```
ap = max(q+ + cSf+, q- + cSf-, 0)
am = min(q+ - cSf+, q- - cSf-, 0)
a+ = ap/(ap-am),  a- = 1-a+,  aSf = am*a+
A+ = a+*q+ - aSf,  A- = a-*q- + aSf.
```

The existing Tadmor branch would use its existing half weights and spectral
bound, but with `cMix`. A finite zero-wave-speed guard, positivity and
admissibility limits are needed before code activation.

## 12. Complete KT conservative flux family

Every state in the following family must come from the same reconstructed
`Qc±,alpha±`, EOS recovery and wave bounds:

```
F_mG = A+*mG+ + A-*mG-
F_mL = A+*mL+ + A-*mL-
F_rho = F_mG + F_mL
F_M = A+*M+ + A-*M- + (a+*p+ + a-*p-)*Sf
F_E = A+*(Et+ + p+) + A-*(Et- + p-)
    + aSf*(p+ - p-).
```

For a moving mesh, use the original solver's relative `q±` and matching
`mesh.phi()*(a+*p+ + a-*p-)` energy pressure-work correction. In expanded
form the mass, momentum and energy KT dissipation terms are respectively
`aSf*(m_k- - m_k+)`, `aSf*(M- - M+)`, and
`aSf*(Et- - Et+)`. This *formal* KT family is not yet a contact-preserving
two-material scheme; the next sections state its missing consistency work.

## 13. Alpha-equation compatibility

The selected Allaire-style model has `D_t alphaL=0` without transfer, or
equivalently `partial_t alphaL+div(alphaL U)=alphaL div(U)`.
M2's source structure resembles this form, but it uses the **legacy gas**
`phiV` and is not phase-mass synchronized. Future alpha transport must use
the same face velocity/time level as the two-phase state and account for the
non-conservative equation. A Kapila-style `K div(U)` term belongs to choice C
and must not be silently inserted into B.

## 14. Interface-compression compatibility

MULES `alphaPhi` contains advection, artificial compression and limiter
corrections. If alpha sharpens while `mG,mL,Et` stay fixed, intrinsic phase
densities `m_k/alpha_k` change, so pressure can change despite no physical
compression. Therefore the current compressed alpha flux cannot simply be
the phase-mass flux. First hyperbolic validation should disable compression
or use an explicitly coupled sharpening/remap of alpha, both phase masses
and energy that preserves pressure, positivity and conservation. M5B
implements neither path.

## 15. Stationary-interface pressure-equilibrium check

Consider a 1-D interface with common `U0,p0`, fixed intrinsic
`rhoG,rhoL,eG,eL` on both sides and differing alpha. For a contact-exact
advection update with `lambda=U0*dt/dx`, the downstream state obeys

```
alpha* = (1-lambda)*alphaR + lambda*alphaL
m_k* = alpha_k* * rho_k
M* = rho* * U0
Et* = sum_k(alpha_k* rho_k e_k) + 0.5*rho*U0².
```

Substitution into isobaric pressure recovery gives exactly `p*=p0` and
`U*=U0`. This is the required discrete contact condition, not an observed
result. The unmodified central-upwind KT flux is generally **not exact on
an isolated material contact**. At `U0=0`, its `aSf` term can diffuse phase
masses/energy while MULES alpha remains fixed (`phiV=0`); then
`m_k*/alpha_k*` changes and pressure recovery need not return `p0`.
Independent VOF compression can also break the displayed identities.
Hence a contact-compatible numerical flux/alpha coupling or a proven
equilibrium-preserving correction is a separate activation requirement.

The source model's contact-pressure argument assumes a contact-exact
Riemann flux; it does not prove that this KT extension has that property.
See [Allaire–Clerc–Kokh, Section 6](https://www.cmap.polytechnique.fr/~allaire/ack.pdf).

## 16. Pure-gas limit

As `alphaL,mL→0`, `mG→rho`, `Et→rhoE`, `p→pGas`, and `cMix→cG`.
With exactly the original gas reconstruction, `q±`, wave bounds and
reference energy, the proposed family gives `F_mG→phi`, `F_mL→0`,
`F_M→phiUp`, `F_E→phiEp`. This is a required algebraic design limit; no
two-phase flux is active to verify it numerically.

## 17. Pure-liquid limit

As `alphaL→1`, `mG→0`, `rho→rhoL` and `cMix→cL`; the formal family reduces
to compressible liquid mass, momentum and energy KT fluxes **only if** a
finite liquid sound speed, caloric EOS and admissible pressure recovery
exist. The current OF7 `C10H22` correlations fail that requirement.

## 18. Shock-interface considerations

Strong density and acoustic impedance jumps require positivity-preserving
phase-mass/alpha reconstruction, robust pressure inversion, controlled
shock/interface pressure oscillations, and time-step bounds using the
largest two-material wave speed. KT diffusion, MULES compression and
phase-density jumps need a common discrete balance. Surface tension later
adds a spatial pressure jump through CSF (M7); it is not an M5B flux term.
No shock-interface case was run.

## 19. Required changes for M6A

Provide a calibrated liquid `rhoL(p,T)`, `eL(rhoL,p)` or invertible
equivalent, `cL`, `xiL`, and validity ranges; preserve separate DPM liquid
transport properties or reconcile them explicitly. Implement gas and liquid
phase energy evaluation at arbitrary candidate face/cell states, unique
isobaric pressure recovery from `Qc,alpha`, phase temperatures, and
near-pure-phase/positivity guards. Validate the closure algebraically before
changing `rhoEEqn.H`. The current common `T` M4 diagnostic is insufficient.

## 20. Required changes before flux activation

After M6A, implement common reconstructed two-phase states and a candidate
contact-compatible flux/alpha discretization; prove/verify stationary
`p,U` preservation and pure-gas recovery, then compare shock tubes and
shock-interface cases. Only then may `rho`, `rhoU`, `rhoE` ownership and
`phi/phiUp/phiEp` be migrated **together**, with phase-mass, gas species
and DPM source bookkeeping. M5B does not modify those equations or fluxes.
