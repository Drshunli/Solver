# C10H22 reference data staging — no accepted CSV yet

No table in the current project supplies a jointly sourced multi-pressure,
multi-temperature **pure liquid** `rho,c,Cp/Cv` dataset and common energy
reference over an approved target range. Do not treat the case's parcel
`rho0=730` and `Cp0=2090` as measured state points. Do not treat OF7
`C10H22::rho(p,T)` as high-pressure density data: its pressure argument is
ignored.

## Primary/reference leads, not imported numeric observations

| Source | DOI / link | Reported scope | Classification and present limitation |
|---|---|---|---|
| Lemmon & Span, *J. Chem. Eng. Data* 51 (2006), 785–850 | [10.1021/je050186n](https://doi.org/10.1021/je050186n) | Short fundamental Helmholtz EOS includes decane | Reference **model**, not direct measurement. Need an authorized table export with specified reference state and validity range before use. |
| *J. Chem. Thermodynamics* 148 (2020), 106127 | [10.1016/j.jct.2020.106127](https://doi.org/10.1016/j.jct.2020.106127) | Measured decane sound speed at 298.32–653.93 K, 0.1–10 MPa; derived properties reported for 303.15–373.15 K up to 10 MPa | Primary experiment, but the accessible abstract is not a numerical table. Its liquid sound speed decreases with temperature along an isobar. |
| NIST Chemistry WebBook decane fluid properties | [NIST entry](https://webbook.nist.gov/cgi/cbook.cgi?ID=C124185&Mask=79) | Model-calculated state properties available through its fluid interface | The fluid table was not retrievable in this audit; no numbers were copied from snippets. Confirm model, phase and energy reference for any later export. |
| NIST TRC hydrocarbon supplement H132 | [NIST record](https://www.nist.gov/publications/trc-thermodynamic-tables-hydrocarbon-supplement-no-h132) | Lists decane real-fluid sound-speed tables | Catalog reference only; table not present locally. |

The 2020 paper and the NIST EOS are promising **different kinds of evidence**.
Do not relabel EOS-generated data as measured data. Mixed-source caloric
columns require compatible reference states and units. Mixture data involving
decane do not replace pure C10H22 data.

## CSV contract for `fitting/fitC10H22StiffenedGas.py`

UTF-8 CSV columns, SI units:

```text
p_Pa,T_K,rho_kg_m3,c_m_s,Cp_J_kgK,Cv_J_kgK,h_J_kg,e_J_kg,source_id,source_url,data_kind
```

`p_Pa,T_K,rho_kg_m3,c_m_s,source_id,source_url,data_kind` are mandatory in
each row. `data_kind` is `measured` or `model`. The URL should identify the
DOI or database entry. `Cp/Cv/h/e` may be empty, but strategy B requires
observed `Cp` or `Cv`. Record in an accompanying source note each row's
phase, measurement or EOS method, uncertainty, valid temperature/pressure
range, enthalpy/internal-energy zero and any unit conversion. Never fill
unavailable data from an unrelated hydrocarbon.

The script requires an explicit `--p-min/--p-max/--T-min/--T-max` and nominal
state, at least three pressure levels and two temperatures, and a dataset
spanning the declared bounds. Example invocation, after real data and bounds
are approved:

```text
python3 -B fitting/fitC10H22StiffenedGas.py data/approved.csv \
  --strategy B --p-min <Pa> --p-max <Pa> --T-min <K> --T-max <K> \
  --nominal-p <Pa> --nominal-T <K> --output data/candidate-fit.json
```

Strategy A fits density and sound speed. Strategy B adds available `Cp`
and/or `Cv`. Each property family contributes its **mean squared relative
error** with unit weight. This balances families with different units and
sample counts; it does not imply equal experimental uncertainty. Reviewers
may need uncertainty-weighted fitting once the actual data provenance is
known. The script reports mean, maximum and nearest-nominal relative errors,
checks analytic round trips and positivity, and writes only a candidate JSON.
It does not edit an OpenFOAM dictionary or declare acceptance. If a sourced
liquid internal-energy reference is provided, `--energy-reference` computes
a proposed `q`, again without solver activation.

**Structural warning:** for this constant-parameter candidate,
`c^2=gamma*(gamma-1)*Cv*T`. It predicts no pressure dependence of sound speed
at fixed temperature and a positive temperature slope. The published liquid
decane trend with temperature has the opposite sign. A broad multi-state fit
is therefore expected to fail acoustically; report its errors rather than
forcing approval or introducing unvalidated piecewise coefficients.
