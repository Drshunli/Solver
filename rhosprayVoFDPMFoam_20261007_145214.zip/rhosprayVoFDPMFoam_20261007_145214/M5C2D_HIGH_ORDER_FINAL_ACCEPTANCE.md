# 1. M5C.2D status

**COMPLETE / STANDALONE TESTED PROTOCOL / NOT ACTIVE.** All29 stated gates pass. M5C.2 closes the standalone spatial reconstruction/update acceptance gate; no active solver, BC, temporal startup/restart, DPM source adapter or CFD activation is implied. Evidence directory: fitting/reconstruction/m5c2d_v1. Original B/C.1 evidence and375 protected files remain unchanged. Every initial compile/test failure is retained.

Frozen version: R1-P2-residualSpecies-v1; immutable source copies and SHA-256 are in freeze_v1/version.json. No generic FCT implemented. Results are finite tested coverage, not an arbitrary-state interval proof.

# 2. P2 mathematical mapping

For |s|<=0.5: positive-sign branch gives alphaL=s, alphaG=1-s; negative-sign branch gives alphaL=1+s, alphaG=-s. +0=pure gas; -0=pure liquid. Both signs at0.5 encode the same physical state; resolved scalar constructor chooses+0.5. Switch only when updated minority exceeds0.5; otherwise retain the branch. Inverse from a resolved a: a<=0.5 gives s=a, else s=-(1-a). Precision-bearing input must construct from its known minority directly. Full mapping: FIVE_EQ_PHASE_FRACTION_NUMERICAL_REPRESENTATION.md.

# 3. Physical alpha DOF proof

ONE. The numerical coordinate and its sign encode a single scalar; alphaG is its mathematical complement. No independent alphaG PDE, phase floor or deletion exists. The two half-state encodings are representation redundancy, not two thermodynamic fields.

# 4. Numerical alpha ownership

Physical alphaL is the authoritative physical state; P2 is its authoritative numerical storage. MaterialCell.q[0] and conventional alpha outputs are decoded views. Recovery reads both phase fractions from P2 getters; it never subtracts a rounded dominant output to recover trace. Historical FIVE_EQ_FIELD_OWNERSHIP_FINAL.md remains byte-identical; current version is FIVE_EQ_FIELD_OWNERSHIP_FINAL_v2.md.

# 5. Branch-switch behavior

Tested0,1,0.5 and0.5±1e-12, plus smooth profiles crossing half under actual R1/R2 fixed/ALE updates. Physical alpha, EOS-generated masses/Et and recovered p/cMix are continuous; pressure update checks pass. No Minmod/vanLeer is applied to the discontinuous signed coordinate.

# 6. Sub-ULP operator behavior

Real selected high-order chain: reconstruct→KT face coefficients→combined alpha flux/source→P2 update→recovery. Both R1/R2 complete1000 steps on varying1e-20 trace profiles. A separate test starts half the cells as pure liquid and creates gas solely through conservative transport from neighboring1e-20 gas fractions. Newborn gas persists and accumulates while decoded alphaL remains1; gas mass ledger closes. C.1’s original1000-step compensation regression also reruns unchanged. No artificial phase-mass assignment is used.

# 7. R1 precision-aware formulation

For each owner, decode every stencil cell in the owner’s minority physical branch, call actual OF7 Minmod, and map the physical increment to deltaAlphaL. MinmodV applies to momentum. One thetaCell limits both faces of alpha, masses,M,Et and independent species; residual last-species slope follows conservation. at(0) returns the original P2 object directly; at(1) is the intended physical reconstruction. The P2 core remains byte-identical. Full path uses joint positivity/acoustic/volume bounds and frozen sampled dtThermo.

# 8. R2 precision-aware formulation

R2-HYBRID retains R1’s bounded true fraction, reconstructs present-phase p/U/T/composition, regenerates conservatives through real EOS and uses R1 on presence-pattern transitions or invalid primitive faces. It never recreates gas complement from rounded alphaL. R2 is fully compared here but remains an unselected prototype.

# 9. Species closure final formulation

mY_N=mG−sum_{i<N}mYi; FY_N=FmG−sum_{i<N}FYi. For independent species FY_i=A+*mYi_L+A-*mYi_R. KT linearity proves this equals transporting the residual species, apart from floating-point order. Negative residual states reject/reduce theta or dt. No normalization/clipping. The existing conservative per-species trial remains unchanged and closes its ledger within frozen roundoff budget.

# 10. Species extended regression

Main stress:12500 legal4-cell stencils,150000 shared-face flux evaluations and300000 owner-face checks across R0/R1/R2; includes gas/mixed/trace/fuel/strong gradients/shock-like/ALE. Additional variable-ALE matrix:3000 update paths. All species checks retain1e-12. Original B face executable still reproduces14 failures; repaired complete face suite14179/0. Historical full B rerun reproduces26 known failures (14species+12representation). New implementation passes. Exact output counts and flags are archived.

# 11. Smooth reconstruction convergence

Five distinct manufactured profiles: pure gas,pure liquid,mixed material,alpha-only crossing0.5,composition-only. N=20,40,80,160,320; R0/R1/R2. Conservative cell averages use three-point Gaussian quadrature; physical alpha’s sinusoidal cell average is analytic. Compare reconstructed face state against analytic EOS-generated face values. L1/L2/Linf reported for alpha,masses,Mxyz,Et,species,p, globally and away from extrema. No CFD solve.

# 12. Observed spatial orders

| profile | scheme | field | L1 order | L2 order | Linf order |
|---|---|---|---|---|---|
| 0 | R1 | alpha_awayExtrema | roundoff/constant | roundoff/constant | roundoff/constant |
| 0 | R1 | Et_awayExtrema | 2.01274 | 2.007913 | 1.996629 |
| 0 | R1 | p_awayExtrema | 2.012551 | 2.007515 | 1.996772 |
| 0 | R2 | alpha_awayExtrema | roundoff/constant | roundoff/constant | roundoff/constant |
| 0 | R2 | Et_awayExtrema | 2.013206 | 2.008106 | 1.99661 |
| 0 | R2 | p_awayExtrema | 2.012898 | 2.00813 | 1.996727 |
| 1 | R1 | alpha_awayExtrema | roundoff/constant | roundoff/constant | roundoff/constant |
| 1 | R1 | Et_awayExtrema | 2.011664 | 2.004969 | 1.988991 |
| 1 | R1 | p_awayExtrema | 2.013042 | 2.008117 | 1.997061 |
| 1 | R2 | alpha_awayExtrema | roundoff/constant | roundoff/constant | roundoff/constant |
| 1 | R2 | Et_awayExtrema | 2.011686 | 2.005001 | 1.98899 |
| 1 | R2 | p_awayExtrema | 2.013221 | 2.008138 | 1.997053 |
| 2 | R1 | alpha_awayExtrema | 2.013222 | 2.008139 | 1.997213 |
| 2 | R1 | Et_awayExtrema | 2.013046 | 2.007929 | 1.996809 |
| 2 | R1 | p_awayExtrema | 2.009591 | 2.006429 | 1.996987 |
| 2 | R2 | alpha_awayExtrema | 2.013222 | 2.008139 | 1.997213 |
| 2 | R2 | Et_awayExtrema | 2.013258 | 2.008173 | 1.996801 |
| 2 | R2 | p_awayExtrema | 2.013225 | 2.008131 | 1.99697 |
| 3 | R1 | alpha_awayExtrema | 2.013222 | 2.008139 | 1.997213 |
| 3 | R1 | Et_awayExtrema | 2.012645 | 2.006917 | 1.993118 |
| 3 | R1 | p_awayExtrema | 1.446972 | 1.356326 | 0.7038123 |
| 3 | R2 | alpha_awayExtrema | 2.013222 | 2.008139 | 1.997213 |
| 3 | R2 | Et_awayExtrema | 2.012645 | 2.006917 | 1.993118 |
| 3 | R2 | p_awayExtrema | 0.6202557 | 0.4916648 | -0.4150375 |
| 4 | R1 | alpha_awayExtrema | roundoff/constant | roundoff/constant | roundoff/constant |
| 4 | R1 | Et_awayExtrema | 2.013163 | 2.008045 | 1.996741 |
| 4 | R1 | p_awayExtrema | roundoff/constant | roundoff/constant | 0.08246216 |
| 4 | R2 | alpha_awayExtrema | roundoff/constant | roundoff/constant | roundoff/constant |
| 4 | R2 | Et_awayExtrema | 2.013209 | 2.008113 | 1.99673 |
| 4 | R2 | p_awayExtrema | 0.2325435 | 0.2294247 | -0.2636524 |

Actual observed160→320 orders are shown, not assumed. Full grid orders are in observed_orders.json. Constant/roundoff-dominated fields do not have a meaningful quotient order (display suppression below1e-14 is diagnostic only, not an acceptance tolerance). These are spatial face-reconstruction orders; no second-order time/CFD claim. Extrema norms are reported separately and no uniform second-order requirement is imposed.

# 13. Limiter smooth-region statistics

All manufactured grids have zero additional shared thermo-theta activation; thetaCell=1. Away-extrema mask |cos(2πx)|>0.35 is an analysis partition, not a limiter or physical threshold. OF7 TVD Minmod itself may reduce its gradient limiter at extrema; this is distinct from shared thermo theta. limiter_smooth.csv provides all counts. Smooth input averaging is documented; extra EOS restriction did not dominate refinement.

# 14. Pure-gas legacy end-to-end result

Actual Foundation OF7 Minmod/MinmodV and multivariate vanLeer are used. Existing real fvMesh interpolation fixture reruns successfully; of7_interpolation.json records428 checks/0 failures. New cell→face→flux comparison covers uniform/smooth/shock-like/strong composition fields over all5 grids. Legacy reconstructs rho,rhoU,rPsi,e,c and uses p=rho*rPsi; species common vanLeer weights include e and allYi, matching active field table. Uniform chain passes1e-10. Nonuniform R1/R2 differences are reported, not forced to equality. R1 matches legacy gas mass flux more closely; material species versus intrinsic-Y vanLeer differences are intentional and quantified in legacy_end_to_end.csv.

# 15. Pressure-path coverage

Algorithmic states only: reference p=0.10,0.5,1,3,6,8MPa; BUFFER/HARD interiors0.06,0.08,10,11.5MPa. TL=285.0001,295,300,305,319.9999K. Primitive→conservative→reconstruct→flux→trial→recover executed37500 times, plus3000 variable-ALE paths and4096 more strongly discontinuous near-edge stencils. Each cell is generated and checked using actual EOS before stressing reconstruction; illegal random Q is not treated as production input. All paths have positive connected steps. This is not a CFD pressure envelope prediction.

# 16. Alpha/trace coverage

All19 requested bands are constructed directly through P2 minority values/signs, including1−1e-20; no rounded dominant-alpha preconstruction. Coverage counts archived. Contact-family stencils intentionally override the base fraction with0.1/0.9; other families carry the requested fraction. Thus paths.csv alpha columns describe the base input, not a claim that every contact uses it. Strict trace dt statistics exclude that override and require positive tested minority<=1e-8. C.1 finite-support matrix reruns unchanged.

# 17. Gas-composition coverage

Actual OF7 JANAF at300,400,800,1200,2000K and within-validity perturbations. Fuel/O2/N2 mixtures:[0,.228,.772],[.01,.22572,.76428],[.1,.2,.7],[.4,.1,.5]. Shock-like pairs vary composition strongly. All labels are ALGORITHMIC TEST STATE, not evaporation or CFD predictions. EOS/reference library versions remain frozen.

# 18. High-velocity energy test

Includes base U=0,10,100,500,1000,2000m/s and multidirectional components, plus discontinuous velocity perturbations. All recover. Et−kinetic conditioning diagnostics retain complete worst-state conservatives. First stress harness incorrectly applied internal root2e-12 to final reconstructed-energy residual; six assertions at2.000007e-12…2.001252e-12 are preserved. Frozen final validation already permits4*energyRelativeTol=8e-12. Corrected test uses that exact existing rule; no root/EOS/acceptance tolerance changed. Same seeded matrix then637500/0. See energy_test_contract_correction.md.

# 19. High-order overshoot handling

4096 reproducible discontinuous near-edge stencils generate 20995 illegal raw faces; shared theta produces0 invalid limited faces and0 extra high-order no-step paths. Separate certified exact-boundary matrix1280 decisions: 38 high-only outward states have valid R0 trials; 634 both-outward states stop as EOS exhaustion. Near-boundary interiors are never mislabeled exact outward. Header fiveEqPrecisionBoundaryDecision.H exposes the frozen decision. Future integration must select one shared R0 flux family globally on rollback, not splice inconsistent cell-local fluxes; no BC/time integration is implemented here.

# 20. Pressure-contact worst case

| scheme | step | cell | relative error | tight-root contribution | P1 substitution contribution |
|---|---|---|---|---|---|
| 1 | 989 | 47 | 9.8328768460831384e-09 | 2.0333876212437947e-14 | 0 |
| 2 | 895 | 38 | 2.8250068950796958e-11 | 3.5390257835388186e-14 | 0 |

R1 worst at step989,cell47; all full Q and fractions saved. Tight root is diagnostic only. Root and P2 replacement contributions are much smaller than accumulated material reconstruction/update error. One-step long-double conservative re-evaluation also recorded; it cannot undo accumulated preceding double errors. R2 has a substantially better contact margin, acknowledged in selection.

# 21. Pressure-margin robustness

| execution | scheme | steps | max p relative | remaining margin % |
|---|---|---|---|---|
| long | R0 | 1000 | 2.6975865985434666e-11 | 99.73024 |
| long | R1 | 1000 | 9.8328768460831384e-09 | 1.671232 |
| long | R2 | 1000 | 2.8250068950796958e-11 | 99.7175 |
| ordering | R0 | 1000 | 2.6934787733523535e-11 | 99.73065 |
| ordering | R1 | 1000 | 9.8551191651807812e-09 | 1.448808 |
| ordering | R2 | 1000 | 2.8138713581427055e-11 | 99.71861 |
| O0 | R0 | 1000 | 2.6975865985434666e-11 | 99.73024 |
| O0 | R1 | 1000 | 9.8328768460831384e-09 | 1.671232 |
| O0 | R2 | 1000 | 2.8250068950796958e-11 | 99.7175 |

O3 baseline, separately compiled O0 local kernels and reconstruction, FMA algebraic ordering, diagnostic repeat and frozen C.1 repeat remain below ORIGINAL1e-8. R1’s worst tested ordering9.85512e-9 leaves1.4488% margin. No new5e-9/8e-9 threshold or tolerance relaxation. This finite sensitivity audit is not a promise for arbitrary compilers, fast-math or longer horizons.

# 22. R0 long-run result

| case | N | steps | outcome | p relative | conservation |
|---|---|---|---|---|---|
| stationaryContact | 60 | 100 | PASS | 2.1152413154368332e-11 | 1.3113775925000279e-15 |
| stationaryContact | 200 | 100 | PASS | 2.116906649973771e-11 | 4.576025010681413e-15 |
| movingContact | 60 | 1000 | PASS | 2.6975865985434666e-11 | 8.5845832313523582e-16 |
| movingContact | 200 | 100 | PASS | 2.0848434090225965e-11 | 1.5736531110000327e-15 |
| smoothAdvection | 60 | 100 | PASS | 1.0147438445073931e-13 | 4.7185434387594546e-16 |
| smoothAdvection | 200 | 100 | PASS | 1.0458300891968975e-13 | 5.8283448555556745e-16 |
| gasShock | 60 | 100 | PASS | 0 | 1.585430595423178e-15 |
| gasShock | 200 | 100 | PASS | 0 | 1.7254968322368742e-15 |
| mixedInterface | 60 | 100 | PASS | 2.2186696924109128e-11 | 2.264900850604531e-15 |
| mixedInterface | 200 | 100 | PASS | 2.2186696924109128e-11 | 3.3479874602274032e-15 |
| ALEContact | 60 | 100 | PASS | 2.0479618001445488e-11 | 1.1669277688742442e-15 |
| ALEContact | 200 | 100 | PASS | 2.0688561974679942e-11 | 1.9172187024854154e-15 |

Six requested families atN60/N200. N60 moving contact1000 accepted steps; all others100. Shock p relative=0 in this table means contact-pressure invariance is not applied to a shock, not zero shock error. No CFD case run.

# 23. R1 long-run result

| case | N | steps | outcome | p relative | conservation |
|---|---|---|---|---|---|
| stationaryContact | 60 | 100 | PASS | 2.365241336121926e-11 | 1.6524534760794118e-15 |
| stationaryContact | 200 | 100 | PASS | 2.3641977264787783e-11 | 3.0506833404542753e-15 |
| movingContact | 60 | 1000 | PASS | 9.8328768460831384e-09 | 1.3336317358562791e-15 |
| movingContact | 200 | 100 | PASS | 2.2170709712554526e-11 | 1.0002238018922087e-15 |
| smoothAdvection | 60 | 100 | PASS | 1.6342482922482304e-13 | 7.8642390645990904e-16 |
| smoothAdvection | 200 | 100 | PASS | 2.4946711363327267e-13 | 7.5496695020151213e-16 |
| gasShock | 60 | 100 | PASS | 0 | 1.13245042530227e-15 |
| gasShock | 200 | 100 | PASS | 0 | 1.1503312214912495e-15 |
| mixedInterface | 60 | 100 | PASS | 2.1320056831086731e-11 | 2.642384325705286e-15 |
| mixedInterface | 200 | 100 | PASS | 2.1320056831086731e-11 | 1.9315312270542713e-15 |
| ALEContact | 60 | 100 | PASS | 2.1836532582142354e-11 | 1.0199603497222439e-15 |
| ALEContact | 200 | 100 | PASS | 2.1888491019694811e-11 | 1.8027624785839995e-15 |

Six requested families atN60/N200. N60 moving contact1000 accepted steps; all others100. Shock p relative=0 in this table means contact-pressure invariance is not applied to a shock, not zero shock error. No CFD case run.

# 24. R2 long-run result

| case | N | steps | outcome | p relative | conservation |
|---|---|---|---|---|---|
| stationaryContact | 60 | 100 | PASS | 2.282141142728733e-11 | 1.5253416702271493e-15 |
| stationaryContact | 200 | 100 | PASS | 2.2749135908384233e-11 | 5.6437641798404096e-15 |
| movingContact | 60 | 1000 | PASS | 2.8250068950796958e-11 | 1.1669277688742442e-15 |
| movingContact | 200 | 100 | PASS | 2.1741497491234441e-11 | 1.1589187362325712e-15 |
| smoothAdvection | 60 | 100 | PASS | 1.0380585280245214e-13 | 3.7826057270785139e-16 |
| smoothAdvection | 200 | 100 | PASS | 1.6064927166326015e-13 | 5.6622521265113412e-16 |
| gasShock | 60 | 100 | PASS | 0 | 1.13245042530227e-15 |
| gasShock | 200 | 100 | PASS | 0 | 9.2026497719299957e-16 |
| mixedInterface | 60 | 100 | PASS | 2.5126789537921468e-11 | 2.8311260632556635e-15 |
| mixedInterface | 200 | 100 | PASS | 2.5079271992467511e-11 | 4.5069061964599658e-15 |
| ALEContact | 60 | 100 | PASS | 2.1456170173905775e-11 | 1.1656689711111359e-15 |
| ALEContact | 200 | 100 | PASS | 2.1463053556658451e-11 | 2.6841061834795815e-15 |

Six requested families atN60/N200. N60 moving contact1000 accepted steps; all others100. Shock p relative=0 in this table means contact-pressure invariance is not applied to a shock, not zero shock error. No CFD case run.

# 25. Selected first-activation scheme

**R1-P2-residualSpecies-v1.** Freeze source/API and tested protocol only. No active selection/dictionary changed. R2 remains comparison prototype; R0 remains certified low-order anchor and exact-boundary rollback reference.

# 26. Selection rationale

Both schemes pass tested admissibility, conservation and spatial accuracy. R2 visibly improves contact pressure margin; this benefit is not denied. R1 nevertheless satisfies the original robust pressure gate, keeps a single conservative shared-theta construction, is closer to the legacy gas mass/energy flux and is simpler. R2 reconstruction costs about16% more in this sample and adds primitive EOS regeneration/presence fallback. Under the stated robustness/conservative/legacy/simplicity priorities R1 is selected, with its narrow long-time pressure margin explicitly retained as a future risk. R2 is available for subsequent research, not activated.

# 27. dt constraint statistics

| R1 group | min ratio | median | P1 | P5 | P95 | P99 |
|---|---|---|---|---|---|---|
| smooth | 1 | 1 | 1 | 1 | 1 | 1 |
| contact | 1 | 1 | 1 | 1 | 1 | 1 |
| shockLike | 2.295122e-05 | 1 | 2.446466e-05 | 4.662008e-05 | 1 | 1 |
| trace | 1 | 1 | 1 | 1 | 1 | 1 |
| EOSnearBoundary | 0.001389518 | 1 | 0.004771073 | 0.07473849 | 1 | 1 |
| actual_trace_subset | 2.295122e-05 | 1 | 2.809171e-05 | 0.006075029 | 1 | 1 |

ratio=dtFinal/dtAcoustic. dt_statistics.csv/json separately give acoustic,physical-alpha,mass,species,volume,joint,thermo bounds for R0/R1/R2 and all families. Alpha/mass/species/volume columns are raw bounds; joint applies frozen0.95 safety and CFL0.15. Family labels are construction modes, not exclusive physical categories; actual_trace_subset is explicit. Variable-ALE paths include finite volume bounds. Geometry is unit-volume/unit-face standalone; these are not300_2D timestep prescriptions.

# 28. dtThermo statistics

37500 main and3000 extra ALE paths have positive sampled dtThermo. Interior/near-edge classification and ratios are retained, including small legitimate positive steps near the hard domain. Exact outward EOS stops are reported separately and excluded from tiny-positive statistics. The4096 severe near-edge stencils can demand very small steps because TL lies1e-6K from a bound; this is not hidden as a performance success. No arbitrary practical dt floor added. Finite32 samples/52 bisections do not prove every continuum intermediate state.

# 29. Conservation ledger

All36 long profiles pass mass,momentum,Et and each species ledger at5e-12. Maximum scaled drift 5.643764e-15. Sub-ULP emergence audits gas mass relative to its own tiny total, not an O(1) denominator. No P2-based mass/energy/species overwrite, no EOS clipping or normalization.

# 30. Physical alpha balance

Physical alpha, not signed-coordinate integral, satisfies periodic flux/source/GCL ledger. Maximum long-run absolute residual 2.570533e-15, against frozen5e-12*N. Structured DD numerator uses the same KT A± for alpha flux and physical source. C.1 fixed/ALE algebra and high-precision diagnostics rerun; accepted P2 update unchanged.

# 31. P2 runtime cost

| operation | mean ns | median ns | P95 ns | P99 ns |
|---|---|---|---|---|
| conversionNs | 3.023644 | 2.41605 | 5.4995 | 8.0302 |
| updateNs | 7.359074 | 5.8299 | 13.1187 | 16.846 |

250 batches×10000 actual coordinates, isolated after other tests. Authoritative payload8bytes; general comparison harness24bytes. Retaining conventional alpha outputs would add registry/storage cost in future integration. Timing includes volatile checksum overhead and is machine-local standalone cost, not CFD throughput.

# 32. R1/R2 runtime cost

| scheme | operation | mean us | median us | P95 us | P99 us |
|---|---|---|---|---|---|
| R0 | reconstructionNs | 0.390803 | 0.136 | 0.781 | 1.788 |
| R0 | faceNs | 100.2101 | 61.287 | 198.753 | 372.965 |
| R0 | updateNs | 414.5284 | 274.5335 | 880.668 | 1229.224 |
| R1 | reconstructionNs | 3250.52 | 2086.31 | 6931.815 | 8197.577 |
| R1 | faceNs | 101.8591 | 62.422 | 214.543 | 494.189 |
| R1 | updateNs | 412.7964 | 266.0835 | 885.143 | 1251.452 |
| R2 | reconstructionNs | 3773.496 | 2434.735 | 8037.948 | 9594.286 |
| R2 | faceNs | 101.1505 | 62.1265 | 206.987 | 340.867 |
| R2 | updateNs | 414.4614 | 273.3605 | 894.373 | 1286.173 |

Isolated1000 seeded cases. Reconstruction timing is per4-cell/8-owner-face batch, including shared theta search and EOS checks; face timing is4 shared faces with recovery+flux; update timing includes one connected-dt query and accepted trial/recovery, not only arithmetic. Full stats in performance_statistics.json. This is standalone measured cost; concurrency-loaded stress timings are not used.

# 33. Restart/storage contract

Schema P2-v1: save exact64-bit signed coordinate payload per cell/patch, e.g. canonical16-hex-digit word plus version, byte order,checksum,EOS version and conservatives. Preserve signed zero. Conventional alphaL=1 alone cannot reproduce trace gas and is not an adequate restart. Future field name phaseFractionCoordinate; alpha outputs read-only. Contract frozen, implementation deferred to M5C.3.

# 34. MPI/boundary integration contract

Exchange authoritative coordinate bits and conservative state; do not recreate complement from projected dominant alpha. Boundary construction can accept minorityPhase+minorityValue. Signed coordinate must not be fed to [0,1] alpha BCs. Physical mapping/AMR must decode one-DOF state and re-encode; direct interpolation of signed coordinate across half is prohibited. No MPI/BC/restart/AMR implementation or active ABI change.

# 35. Whether coupled limiter is required

**NOT REQUIRED BY THE TESTED EVIDENCE.** Representable R0,positive steps,closed species and non-exhausted interior states were checked; no additional inadmissibility remains for selected R1. Real EOS exhaustion is a stop, not FCT input. This does not prove universal arbitrary-state admissibility.

# 36. Whether M5C.2C.2 is required

**NOT REQUIRED / DO NOT START.** No generic coupled FCT written. Reopen only on genuinely additional interior high-order inadmissibility after the frozen prerequisites, not on old representation/species failures or exact outward EOS exhaustion.

# 37. Whether M5C.2 is COMPLETE

**COMPLETE / STANDALONE SPATIAL RECONSTRUCTION AND TESTED UPDATE GATE.** Historical B remains PARTIAL evidence, superseded for current acceptance by D; it is not rewritten as a pass. Temporal scheme/boundary/startup/restart and DPM/source activation remain separate later gates.

# 38. Active solver impact

**NONE.**375 protected files and frozen EOS/thermo shared-library hashes unchanged. Active rho/rhoU/rhoE,alphaEqn,reconstruction,timestep,cloud source mapping,surface tension and Make files unchanged. New code is standalone only; local targets compile with OF7 C++11 and-Werror. Initial compiler errors fixed without weakening flags. One build emitted make clock-skew warning; its actual compile/link and changed manufactured fixture results are archived. All intended final numerical runs succeed. No CFD, mesh generation or solver case run.

# 39. M5C.3 start permission

Eligible for the NEXT user request because the standalone M5C.2 gate is closed. **NOT EXECUTED THIS TURN.** First tasks would implement the frozen temporal/boundary/ownership/restart readiness contracts.

# 40. M6B permission

**NO.** M5C.3 and M8A source-adapter gates are not completed. No active two-material KT, new runtime mG/mL,cMix or pressure recovery is activated.

# 41. Updated milestone matrix

| milestone | status |
|---|---|
| M5C.1/M5C.2A | COMPLETE / frozen standalone |
| M5C.2B | HISTORICAL PARTIAL / retained |
| M5C.2C.1 | COMPLETE / unchanged |
| M5C.2D | COMPLETE / standalone |
| M5C.2C.2 | NOT REQUIRED BY TESTED EVIDENCE / NOT STARTED |
| M5C.2 | COMPLETE / standalone gate |
| M5C.3 | ELIGIBLE NEXT REQUEST / NOT STARTED |
| M8A | NOT STARTED |
| M6B | BLOCKED / permission NO |

STOP. No C.2,M5C.3,M8A,M6B or CFD performed. Version manifest and29 gates: milestone_result.json; checkpoint: checkpoints/M5C2D_high_order_acceptance_v1.zip. Frozen-regression evidence lives under regressions/, including original14/26 expected failures and all successful new/frozen regressions.
