# M6B.1-MC3-NONZERO-K-MODEL-DESIGN — v1

2026-10-05。**DESIGN ONLY / NO ACTIVE IMPLEMENTATION**。完整用户要求保存为 `request_MC3.txt`。权威前置状态来自MC2日志：OUTCOME M1 / PE_TRANSPORT支持，TD1仍PARTIAL，DYN-CLOSURE未授权。旧报告/封存结论不改写。完整连续模型与首版实现契约保存为根目录 **FIVE_EQ_NONZERO_K_MODEL_v1.md**；下面按要求43项报告。

1. **MC3 status**：**COMPLETE / NONZERO-K MODEL DESIGN FROZEN / STOP**，30设计门槛PASS。没有发现合格状态下的derivation/energy/hyperbolicity/puretrace/sourcebounds阻塞；冻结了明确的first-order numerical shock path契约，因此不是“无path解释即加source”。完整shock/entropy/ALE/高阶/production资格仍未取得。MC4未授权、未执行。

2. **Candidate model name**：**general-EOS common-pressure/common-velocity five-equation candidate with pressure-equilibrium alpha response**，Kapila-type **smooth structure**，加项目明确声明的KT-parameterized three-leg numerical path。不是Baer–Nunziato双压力双速度模型，也不声称本项目path等同BN弛豫极限。原论文的约化模型记录说明激波还需regularization；本轮仅借此限定label，公式独立推导。[Kapila et al. 2001 author-institution record](https://experts.illinois.edu/en/publications/two-phase-modeling-of-deflagration-to-detonation-transition-in-gr-2/)。来源细节保存为 `source_references.json`。

3. **Final PDE system**：phase masses `∂t mk+div(mk U)=0`；momentum `∂t M+div(M⊗U+pI)=0`；totalenergy `∂t Et+div((Et+p)U)=0`；alpha material equation `Da/Dt=KPE divU`；species conservative `∂t mYi+div(mYi U)=0`，N−1 independent和原dependent残差closure。Commonp/commonU，TG与TL独立，phaseEOS独立，一条totalenergy，无独立phaseenergyequations、mass/heattransfer/phasechange/extraEtsource。

4. **Alpha material equation**：`Da/Dt=KPE theta`，a=alphaL authority，theta=physical divU。总Eulerian alphaDot是原输运加source，**不使用MC2失败的alphaDot=KPE theta来替换全部更新**。

5. **Eulerian alpha form**：乘积法则独立得到 `∂t a+div(aU)=(a+K)divU`；K0极限为original material advection。连续K0极限和相同reconstruction option下P2 source=0的离散极限均恢复original；首版使用现有piecewiseconstant option，不伪称其等于另一高阶option的输出。

6. **ALE alpha form**：Reynolds transport theorem及GCL给出 `d(Va)/dt+Σ a_f(phiPhysical−phiMesh)=V(a+K)thetaPhysical`。这里physicaltheta由同一face phiPhysicalStar求和，不能用relative mesh flux divergence。dt source在movingvolume除以V'，不漏Vn/V'因子。

7. **K derivation**：从DmG/L=−mk theta和a/b变化得 `D rhoL=−rhoL(1+K/a)theta`、`D rhoG=−rhoG(1−K/b)theta`；phase acoustic response dp=c²drho，定义Ak=rhok ck²，匹配phasepdot解得 `K=ab(AG−AL)/(bAL+aAG)`。K无量纲；AL>AG⇒K<0，compressiontheta<0⇒a增加。没有TG=TL或等温假设。完整独立PDE→energy→pressure推导在冻结model文档，非复制MC2结论作证明。

8. **K stable algebra**：scale=max(AL,AG)、D=b*(AL/scale)+a*(AG/scale)，`K=(a*b)*(((AG−AL)/scale)/D)`；先原moduli差再scale，避免near-equal separately-normalized subtraction的可避免丢失。source响应diag用a*(AG/scale)/D及b*(AL/scale)/D，避免a+K/b−K相消。Aeff选 `AL/(a+bAL/AG)` 或 `AG/(b+aAG/AL)`、c²=Aeff/rho。63nativebinary-input/90digitreference合成controls含pure/trace/AL≈AG/极大比值，全部按预冻结预算PASS；qualifiedpositivefinite输入/结果是前提，不认证任意binary64范围且不clipK。

9. **General-EOS consistency**：当前JANAF/Gibbs分别给beta、Cv、c和 `P=(∂p/∂rho)e=c²−p/(rho² beta)`。独立90digit数学函数/相同nativecoeff输入，固定rho有限差分energypressurepartial核对beta；17 EOS/R1 checks maxrelativeerror=1.382659899e-16，≤预冻1e-8。无gamma常数、stiffenedgas替代或EOS重拟合；C_L/Hc原参考保持。

10. **R1 implication**：residual `R(p)=mG eG(mG/b,p,Y)+mL eL(mL/a,p)−I` 不变。alpha只改变trial intrinsic densities；recovery期间Q/P2固定，K不是迭代变量，所以R'=mGbetaG+mLbetaL，不加Kpartial。直接有限差分R1 derivative在5mixed/trace control核对PASS。纯相原branches、HARD interval、presence、tolerance原样。future新sound/K字段必须与model匹配，但不能因此改R1残差。

11. **Energy implication**：conservative momentum/Et推出 `DI=−(I+p)theta`；phaseEOSchain与mass/source变化一致，K源不直接注入/删除Et。phasee通过同一totalenergy/commonp recovery重新分配。无需pKtheta或heat source，未发现MODEL_ENERGY_CLOSURE_BLOCKER。smooth结果并非shock phaseentropy分配证明。

12. **Sound-speed derivation**：独立线性化 `J Dp=−BK theta`，xi=rho*beta、J=bxiG+axiL、`BK=bxiG AG+axiL AL+K(xiL AL−xiG AG)`，从P_k热力学identity抵消p项，`cK²=BK/(rhoMix J)`。K0复现实际旧Allaire的xi-weighted公式，而不是假定arithmetic mixture声速。

13. **cPE formula**：代入独立K后BK=J ALAG/(bAL+aAG)，故 `cPE²=1/[rhoMix(a/AL+b/AG)]`。future nonzeroK安装后旧cA必须在primitive/KT/CFL中换成cPE，不能以microanchor只差0.12%为由保留。纯相或Ak相等等已证相同的数学极限另论；trace中binary数值相同不证明非零trace模型处处相同。

| case | alphaL / alphaG | K stable | cA m/s | cPE m/s | relative cPE−cA |
|---|---|---|---|---|---|
| gas | 0 / 1 | 0 | 558.65682516 | 558.65682516 | -2.2204460493e-16 |
| liquid | 1 / 0 | 0 | 1244.7181069 | 1244.7181069 | 0 |
| mixed01 | 0.1 / 0.9 | -0.09960004358 | 846.92301892 | 231.03735936 | -0.72720382586 |
| mixed05 | 0.5 / 0.5 | -0.49641187298 | 995.21731386 | 147.80440553 | -0.85148529525 |
| mixed09 | 0.9 / 0.1 | -0.86860796567 | 1180.929764 | 244.79770557 | -0.79270765034 |
| traceLiquid | 1e-20 / 1 | -9.9639895196e-21 | 558.65682516 | 558.65682516 | 0 |
| traceGas | 1 / 1e-20 | -2.7669693418e-18 | 1244.7181069 | 1244.7181069 | 0 |

14. **Eigenstructure**：primitive W=(mG,mL,u,p,a)均匀态相对U的matrix只有u→mass/p/alpha及p→u列，rank2，charpoly `lambda³(lambda²−cPE²)`，零eigenspace维数3。acoustic vectors `(mG/lambda,mL/lambda,1,rho lambda,−K/lambda)`。五speeds U−cPE,U,U,U,U+cPE；N−1species及transversevelocity加advectedU modes。pureEuler需降维，不对ABSENTphase用奇异5-state参数map。

15. **Hyperbolicity**：AL/AG/rho>0⇒cPE²>0，J>0⇒mixedprimitive/conservativemap可逆，realcharacteristics。既有合格EOS状态上的代数结论覆盖该qualified set；420 HARD p/TL×gasT×fractions grid positivity PASS只是crosscheck，不冒充新fullEOS/phase资格。未发现HYPERBOLICITY_BLOCKER。

16. **Pure/trace limits**：a→0，K→0，cPE→cG、gasEuler；b→0，K→0，cPE→cL、liquidEuler；tracea/b~1e-20保留原P2 minority和tinyphase mass，K有限/符号正确。K/a或K/b可非零有限，不能以K小为由deletephase。exactpureK=0、signedzero原样，不queryabsentphase；originalsubnormalpolicy不变。phasecompfactor `a+K=aAG/H≥0`、`b−K=bAL/H≥0`，H>0，−a≤K≤b；no SOURCE_BOUND_BLOCKER。

17. **P2 source contract**：original DD transport numerator加 `K_i^n ΣphiPhysicalStar`；δa=dt/V'乘这个DD总numerator，调用原signedminority advanced一次，Q0只由authority重建。mass/M/Et/species originaltrial保持；PRESENT/TRACE_PRESENT/ABSENT及pure±0检查原契约。禁止directalphawrite、threshold/clip/deletion。源项加入candidate validation及source-aware fractional bound，不声称Kbounds保证有限dt域合法。

18. **Source quadrature**：首版**forwardEuler committed-cell K^n**。predictorK*需要一致阶段thermo/face/alpha更新，midpoint需要conservative/P2/GCL stagealignment；本轮均不选。时间Taylor一致性及明确定义的firstorderpath要求优先于提升order，不按方便选source态。首次空间qualification用**已有piecewiseconstant reconstruction option**对coupledfaces；original高阶源码不改，nonzeroK高阶source在新within-cellpath契约前不启用。MC2高阶facesshadow成功不能替代这个首版资格测试。

19. **divU definition**：fixedmesh theta=ΣphiPhysicalStar/V；ALE phiPhysStar=phiRelStar+phiMesh，theta仍physical。首版face physicalstar是同一KT左右committedstates/cPE波权重的 `w+ U_L·Sf+w− U_R·Sf`。sourceK来自committedcell，facec来自同一qualifiedface，均time n，无source/faceupdatedstate循环。未来需统一全部调用点，不临时混入另一独立divergence。

20. **Exact contact**：constantp/U/rhoG/rhoL/Y下，divU=0⇒Ksource=0，coupledconservative/alpha相同transportcoeff，恢复原exactcontactproperty。P2与phaseenergy由同一authority/totalenergy一致恢复。MC2nativeproperties作为已有证据，Tmin原16/100binary strictsignfails不升级为strictcontactPASS。M4必须重测新waves/source选项后的contact。

21. **Compression**：theta<0，Da=Ktheta，D rhok=−rhok Aeff/Ak theta，Dp=−Aefftheta；gas DTG=(RG TG/CvG)D rhoG/rhoG，liquid DTL=(Dp−pLrhoT D rhoL)/pLTrho。按实际EOSβ/energy/currentfrozenconservativedirection独立重算8个MC2 PE_TRANSPORT controls，maxpdotrelerror=1.8014856934e-15、scaledTLdotdifference=4.2315109506e-13。idealuniformrate与原FVdirectiontruncation分开保存；不为匹配加Et源。

22. **Expansion**：theta>0同一公式所有线性rates反号；qualifiedAL/AG/H正，不存在newsource分母奇异。7states的phase compression/expansion总24local checks，包括gas/liquid-dominant及trace，热力学rate审计PASS。expansion可能冷却出EOS265K下界，这是operating-set限制，不扩HARD或称phasechange资格。

23. **Entropy review**：smoothcandidate独立推得每phase `De=p/rho² D rho`，故Ds=0（DY=0）。90digit沿实际EOSpath finite-differenceenergy核对pressurework；maxscaledresidual=8.9200471728e-15≤1e-8。compression/expansion、gas/liquiddominant/trace没有明显错误entropy符号。以下全表保留：

| case | phase | divU | rhoDot | pDot | TDot | numeric entropy residual |
|---|---|---|---|---|---|---|
| gas | gas | -1 | 13.00390197 | 4058484.6228 | 282.26256607 | 9.1022227247e-25 |
| gas | gas | 1 | -13.00390197 | -4058484.6228 | -282.26256607 | 9.1022227247e-25 |
| liquid | liquid | -1 | 727.43296055 | 1127028737.2 | 221.93912442 | 8.9200471728e-15 |
| liquid | liquid | 1 | -727.43296055 | -1127028737.2 | -221.93912442 | 8.9200471728e-15 |
| mixed01 | gas | -1 | 14.443001084 | 4507623.7842 | 313.49963705 | 1.1228324933e-24 |
| mixed01 | gas | 1 | -14.443001084 | -4507623.7842 | -313.49963705 | 1.1228324933e-24 |
| mixed01 | liquid | -1 | 2.9094148235 | 4507623.7842 | 0.88765977558 | 8.9200425376e-15 |
| mixed01 | liquid | 1 | -2.9094148235 | -4507623.7842 | -0.88765977558 | 8.9200425376e-15 |
| mixed05 | gas | -1 | 25.914484636 | 8087844.5288 | 562.49954425 | 3.61480802e-24 |
| mixed05 | gas | 1 | -25.914484636 | -8087844.5288 | -562.49954425 | 3.61480802e-24 |
| mixed05 | liquid | -1 | 5.2202437224 | 8087844.5288 | 1.5926915384 | 8.9200425377e-15 |
| mixed05 | liquid | 1 | -5.2202437224 | -8087844.5288 | -1.5926915384 | 8.9200425377e-15 |
| mixed09 | gas | -1 | 125.95683033 | 39310805.342 | 2734.017699 | 8.5397180229e-23 |
| mixed09 | gas | 1 | -125.95683033 | -39310805.342 | -2734.017699 | 8.5397180229e-23 |
| mixed09 | liquid | -1 | 25.372889411 | 39310805.342 | 7.7412451256 | 8.9200425431e-15 |
| mixed09 | liquid | 1 | -25.372889411 | -39310805.342 | -7.7412451256 | 8.9200425431e-15 |
| traceLiquid | gas | -1 | 13.00390197 | 4058484.6228 | 282.26256607 | 9.1022227247e-25 |
| traceLiquid | gas | 1 | -13.00390197 | -4058484.6228 | -282.26256607 | 9.1022227247e-25 |
| traceLiquid | liquid | -1 | 2.6195210354 | 4058484.6228 | 0.79921344857 | 8.9200425376e-15 |
| traceLiquid | liquid | 1 | -2.6195210354 | -4058484.6228 | -0.79921344857 | 8.9200425376e-15 |
| traceGas | gas | -1 | 3611.1437094 | 1127028737.2 | 78383.44923 | 7.0192325072e-20 |
| traceGas | gas | 1 | -3611.1437094 | -1127028737.2 | -78383.44923 | 7.0192325072e-20 |
| traceGas | liquid | -1 | 727.43296055 | 1127028737.2 | 221.93912442 | 8.9200471728e-15 |
| traceGas | liquid | 1 | -727.43296055 | -1127028737.2 | -221.93912442 | 8.9200471728e-15 |

   Unresolved：shockentropyinequality、phaseentropyproduction/partition、所选numericalpath与物理regularization/相态适用性的关系、branchcrossing、mesh/frame/shocklimit。localDs0不证明这些，不是full数学entropyproof。

24. **Nonconservative-product issue**：alpha的(a+K)u_x是nonconservative；shockweaksolution须指定path/regularization。prescribedpath形式的consistency也不等于shockconvergence，后续必须测。[Castro et al. 2008 author-hosted primary paper](https://philippelefloch.org/wp-content/uploads/2009/09/leflochpares-jcp2008.pdf)。与纯cellsource无path解释的方案区别在于本轮明确了facepairsource如何对应每条velocityleg的积分。

25. **Shock/path treatment requirement**：冻结 **KT-parameterized three-leg numerical path**，u*=samephysicalfacevelocity：leftthermostate改变uL→u*；thermoa/p/TG/TL/Y在u*处变化；rightthermostate改变u*→uR。中段du=0；`IK=KL(u*−uL)+KR(uR−u*)`，`I_(a+K)=(aL+KL)(u*−uL)+(aR+KR)(uR−u*)`。左右cell分别取对应leg，sum两faces恰为committed(a_i+Ki)ΣphiPhysicalStar，符合原DDtransport+Ksource。16algebra controls PASS，包括给定face参数的pathreverse、equalU、coherentframe变换；这是明确的firstorderacceptednumericalregularization，**不是BNphysicalrelaxation/pathentropy/实际shockgridconvergence证明**。路径weights受interfaceframe影响，arbitraryALE/meshshockpathdependence需未来评估；不隐瞒此限制。首版采用piecewiseconstant以使path只依赖两端committedstates和facegeometry；高阶先不启用。

   Paththermoguards：EOSHARD/positiveEOS和continuousJANAFbranch；crossingnativebranchgap须reject/report，不假装Lipschitz，不外推；pure/mixedabsentpathcoordinate仅继承对端presentphase thermodynamics作path，不创造committedmass。pure-samephase降pureEuler。endpointR1残差仍是numerical预算，不能resetQ或作为extraEtphysics。M4须测path-sourceidentity、guards、RH/pathjump、contact，再做shockconvergence/entropy/ALE；如不能满足本contract则SHOCK_PATH_BLOCKER，不能退回无解释cellappend。

26. **RH consequence**：mG/mL/M/Et（species）保标准conservativeRH；alpha用 `−s[a]+[au]−∫Phi(a+K)du=0`，不得普通conservativealphaRH。futureRHledger必须记录shock两端、speed、conservative残差、declaredpathintegral/alpha残差及path/mesh敏感性；当前没有shock跑或RH资格。

27. **ALE/GCL**：mass mk(U−Umesh)·Sf；momentum M(U−Umesh)·Sf+pSf；energy Et(U−Umesh)·Sf+pU·Sf；alpha a(U−Umesh)·Sf，RHS V(a+K)divUphysical。uniformphysicalstate divU=0，q*dVdt与meshtransport逐项抵消，pforce及pUwork闭合；15movingvolumealgebra tests PASS。noALEimplementation/qualification。严禁把energypressurework误写p(U−Umesh)而漏pUmesh修正。

28. **CFL/KT contract**：a+=max(left/right relativeUn+cPE,0)、a−=min(left/right relativeUn−cPE,0)，fixedrelative=physical、ALE=Un−Umesh,n；实际面积形式详见modeldoc。futurefresh acoustic cap使用|relativeUn|+cPE，existingCFLparameters不改；更新primitive/face/CFL一致model，不混oldcA。模型sound较慢不自动证明可用dt更大，source/P2/EOS约束仍authoritative。

29. **Temporal implication**：futurejointbound加newalpha/source numerator和volume因素；`aV+dt(aDmesh+Ntotal)≥0`、`bV+dt(bDmesh−Ntotal)≥0`，V'>0。保持TD1actualtimeadvance/representableULP、原rollback/atomiccommit/增长策略，不做temporal优化。本轮TD1源码/driver未改；旧MC2cap/strictwitness不是新waves+piecewiseconstantmodel的dt资格，M4后需freshTD1。

30. **Recovery/strict-root policy**：R1/tol/HARD不变，tolerance numericalallowance不是modeldomainextension。futuretrial/committed同时记录native及strictroot、endpointmargin和toleranceonlycounts，目标strictinterior、toleranceonly减少/消失。原24microbaseline仍boundaryonly，不因设计改写；precision-onlyprimaryrepair已无支持，activebinary64不改。

31. **Numerical Jacobian validation**：预算 `error_budget.json` 先于formula/Jacobian计算冻结；Decimal90digits对actualEOSfunction/energyparameterization centralFD，独立从Q(W)和F(W)Jac转换成conservativeJac，加真正nonconservativealpha项。trace使用signedminority坐标，pure降Euler3state；dimensionlesssimilarityscaling避免tracecondition数掩盖声谱。relativeFDstep1e-12并halfstep，normalisedeigen预算2e-6，maxerror=3.304301277e-14、maximag=1.3078911955e-16，14checks PASS。此预算不是物理/R1容差放宽。

| case | independent dimension | normalized eigenvalues relative to U | max eigen error | max imaginary |
|---|---|---|---|---|
| gas | 3 | -1, -2.7755575616e-17, 1 | 2.2204460493e-16 | 0 |
| liquid | 3 | -1, -3.469446952e-18, 1 | 2.2204460493e-16 | 0 |
| mixed01 | 5 | -1, 1.3877787808e-17, 4.1633363423e-17, 1.7860712909e-14, 1 | 1.7860712909e-14 | 0 |
| mixed05 | 5 | -1, -2.4980018054e-16, 2.7755575616e-17, 2.1677104556e-14, 1 | 2.1677104556e-14 | 0 |
| mixed09 | 5 | -1, -3.304301277e-14, -2.7755575616e-17, 0, 1 | 3.304301277e-14 | 0 |
| traceLiquid | 5 | -1, -6.9388939039e-18, 6.9388939039e-18, 6.9388939039e-18, 1 | 6.9388939039e-18 | 1.3078911955e-16 |
| traceGas | 5 | -1, 0, 0, 0, 1 | 3.3306690739e-16 | 0 |

32. **MC2 anchor cross-check**：25anchors×100cells=2500singleformulaeval，含24microcell53；noPDEtimeadvance/no长shock。directK与MC2K**逐位相同**；stableK≤2ULP（预冻32ULP或abs/relbudget），全部PASS。细表/Allairecomparison完整CSV保留，cell53如下：

| anchor | K stable cell53 | stable/direct ULP | cA | cPE | relative speed difference |
|---|---|---|---|---|---|
| 230 | -1.8198202066e-05 | 0 | 565.12482328 | 564.50743854 | -0.0010924750112 |
| 235 | -2.010409083e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 240 | -2.010409083e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 260 | -2.010409083e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 330 | -2.010409083e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 530 | -2.010409083e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 651 | -2.010409083e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 1000 | -2.010409083e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 1309 | -2.010409083e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 3000 | -2.010409083e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 6000 | -2.010409083e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899823 |
| 10000 | -2.0104090831e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899824 |
| 10852 | -2.0104090831e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899824 |
| 15000 | -2.0104090832e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899824 |
| 20000 | -2.0104090832e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899825 |
| 22260 | -2.0104090833e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899825 |
| 24000 | -2.0104090833e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899825 |
| 26000 | -2.0104090833e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899825 |
| 27659 | -2.0104090834e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899825 |
| 28000 | -2.0104090834e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899825 |
| 30000 | -2.0104090834e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899826 |
| 31000 | -2.0104090834e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899826 |
| 32000 | -2.0104090834e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899826 |
| 32219 | -2.0104090834e-05 | 0 | 565.28245808 | 564.60163755 | -0.0012043899826 |
| 32252 | -2.0104090834e-05 | 1 | 565.28245808 | 564.60163755 | -0.0012043899826 |

33. **Frozen model document hash**：`FIVE_EQ_NONZERO_K_MODEL_v1.md` SHA256 **`be2e3d414dcfffd7a9ae498fa14f4a4f8de934b60c5c87f78a696bdf041b5270`**。`model_freeze.json`同时保存预冻errorbudgetSHA和quadrature/spatial/pathscope。此文档是standalonecandidateequations+implementationcontract；未安装。以后修改应新version/新授权，不重写已封存v1。

34. **Active source delta**：EMPTY，`source_delta.json={}`，`active_source.patch`为空。没有alphaPDE/newKsource/KTwaves/soundspeed/P2advancement/freshcap/executable安装。只新独立export/Decimal验证工具、设计/报告/log及milestone追加。

35. **EOS hashes**：HARD p=.05–12MPa/T265–400K，81coeff/C_L永久冻结；同JANAF/energyreference，不改EOS/phasepolicy。

- `liquidEOS/ndecane_gibbs_v3/coefficients.json`：`610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`
- `liquidEOS/ndecane_gibbs_v3/energy_reference.json`：`ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`
- `liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H`：`421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d`
- `liquidEOS/ndecane_gibbs_v3/metadata.json`：`9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`

36. **TD1 hashes**：3原temporal文件byteunchanged：

- `serialFiveEq/runSerialFiveEq.C`：`3327f1988bcca53a459d01f9cb2db0fd7624d946b6da378477c679fbcec7907a`
- `fiveEqIntegration/fiveEqTemporalContract.H`：`e47e6466de56e82856ebc66281acf40061dd121ae917144a1343cf6f9019ba89`
- `fiveEqIntegration/fiveEqTemporalPolicy.H`：`a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062`

37. **Foundation/project hashes**：110activeprojectsources、exe/customlibs及115installedlibs unchanged；Foundation6717/nativeparcel19全部OK；6014prior evidenceSHA不变；MC2ZIP freshSHA `956038d6c1e70fd60748ad4642d9c803902c756bc33ff94a5165709a469763c8`/CRC PASS。隔离export初次auto类型声明编译错误已修正、失败log保留；最终0warning/error。model/预算/验证ledger新文件正常记录，不把它们算activephysics修改。

38. **MC3 COMPLETE?**：YES，30项DESIGNgates如下。已指定可审查firstordernumericalpath，故无“不能解释source的SHOCK_PATH_BLOCKER”；它仍不代表physicalshockpath/entropy/convergence资格。各negative/limit范围未省略。

| MC3 design gate | status |
|---|---|
| nonzero-K PDE derived | PASS |
| source-vs-total alphaDot semantics frozen | PASS |
| K_PE derived independently | PASS |
| general-EOS compatibility | PASS |
| R1 unchanged proven | PASS |
| R1 derivative checked | PASS |
| energy equation consistency | PASS |
| no hidden Et source | PASS |
| cPE rederived | PASS |
| numerical eigenvalue check | PASS |
| hyperbolicity gates | PASS |
| pure limits | PASS |
| trace limits | PASS |
| stable K algebra | PASS |
| P2 source contract | PASS |
| divU contract | PASS |
| exact contact proof | PASS |
| compression proof | PASS |
| expansion proof | PASS |
| nonconservative shock issue documented | PASS |
| RH implications documented | PASS |
| ALE/GCL derived | PASS |
| CFL contract frozen | PASS |
| temporal implications documented | PASS |
| model document frozen | PASS |
| MC2 anchor K cross-check | PASS |
| no active source changes | PASS |
| EOS unchanged | PASS |
| TD1 unchanged | PASS |
| Foundation unchanged | PASS |

39. **MC4 authorized?**：**NO / NOT EXECUTED**。NEXT ROUND ONLY M6B.1-MC4-NONZERO-K-SERIAL-IMPLEMENTATION；需要下一轮独立授权，范围须遵循本source/cPE/P2/CFL/path/piecewiseconstant契约。MC3仅design，不自动setK!=0/换waves/重跑shock。

40. **TD1 status**：PARTIAL / LOCAL CORRECTNESS PASS / MICROSTEP EFFICIENCY UNRESOLVED。无freshTD1/endTimequalification，只有模型实现及回归后再独立授权验证。

41. **DYN-CLOSURE status**：NOT AUTHORIZED / NOT EXECUTED，TD1 COMPLETE prerequisite仍未满足。

42. **M6B.1/M6B status**：PARTIAL。MC3子阶段designfreeze不代表全milestone、物理phasecertificate、highMach/RH/ALE、production/restart/activeDPM资格。未来MC4通过后还须freshM6B0/TD1/shock/DYNprerequisite/highMach/RH/ALE/pathentropyqualification。

43. **Milestone matrix**：

| milestone | authoritative status |
|---|---|
| PHASE-DEFER | COMPLETE / POLICY FROZEN；historical CLASS D / phasecertificate unresolved |
| EOS3-NUMERICAL | COMPLETE / OPERATIONAL DOMAIN FROZEN，265–400K；非phase/production资格 |
| ADM1 | COMPLETE |
| TD1 | PARTIAL / LOCAL CORRECTNESS PASS / MICROSTEP EFFICIENCY UNRESOLVED |
| TD2 | PARTIAL / MICROSTEP ADMISSIBILITY LIMIT |
| IDP1 | COMPLETE / IDP-G |
| MC1 | COMPLETE / MC-F |
| MC2 | COMPLETE / M1 / PE_TRANSPORT SUPPORTED |
| MC3 | COMPLETE / NONZERO-K MODEL DESIGN FROZEN / STOP |
| MC4 | NEXT ROUND ONLY / NOT AUTHORIZED / NOT EXECUTED |
| active nonzero-K / waves / sound / P2 / sourcecap changes | NOT EXECUTED |
| DYN-CLOSURE | NOT AUTHORIZED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL |
| M6B.2 / DPM / T4-S3 / production CFD | NOT EXECUTED / 未认证 |

**STOP。** 全部evidence在 `fitting/integration/m6b1_mc3_nonzero_k_model_design_v1/`；封存包 `D:/DATA/Solver/checkpoints/M6B1_MC3_NONZERO_K_MODEL_DESIGN_FROZEN_STOP_v1.zip`，SHA/CRC见 `checkpoint_gate.json`。
