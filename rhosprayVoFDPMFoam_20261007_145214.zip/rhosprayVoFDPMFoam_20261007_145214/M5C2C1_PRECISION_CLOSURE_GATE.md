# 1. M5C.2C.1 status

**COMPLETE / STANDALONE TESTED DOMAIN / NOT ACTIVE.** All 21 C.1 gates pass under the documented finite sampled protocol. This is not an arbitrary-state/interval proof and does not close M5C.2. Scope: representation, residual-species algebra, the 12 isolated states, contact/trace updates and frozen regressions. No generic coupled FCT, temporal activation, DPM changes or CFD. Generated 2026-10-01.

The independent support contract is FIVE_EQ_PHASE_FRACTION_PRECISION_CONTRACT.md. The frozen pre-test tolerances are in test_contract.json; that file remains a pre-selection record, not a final decision.

# 2. Original 12 failure preservation

The entire old fitting/reconstruction/m5c2b_v1, old reports, checkpoint, active headers/Make and frozen kernels are SHA-256 protected: **241 files, zero changes**. Original 102-profile statistics and old N=20 1000-step records remain historical evidence. New isolation reruns the old operator and reproduces all 12 step-10 no-connected-dt failures. committed_states.csv includes every committed cell at steps 0–10; operator_fluxes.csv stores R0/R1/R2 faces at these frames. New flux_divergences.csv explicitly contains 4680 per-cell/operator step-10 divergences for alpha, mass, M, E and species. The committed step-10 subset has 1560 cells across 12 profiles. Conserved states are copied without repair.

# 3. Complement-cancellation analysis

P0 uses alphaG=1-alphaL. For a newly created trace gas, alphaL can round to exactly 1 while mG is positive; intrinsic rhoG=mG/0 is invalid. At dt=1e-6 in the isolated actual R0 update, **24 newborn gas cells** have positive 100-digit complements but zero double complements. This is a representation loss, not a proof that the PDE lacks an admissible step. Promoting the rounded post-state cannot recover the lost complement. The liquid-side analogue is audited through the trace matrix and normal/subnormal support checks.

# 4. ULP/conditioning analysis

conditioning.csv records ULP distances to both 0 and 1, eps/alphaL, eps/alphaG, masses and intrinsic divisions for pre-update states and projections of the high-precision trial. eps=2^-52. Pure absence before emergence is legitimate; alphaG=0 with mG>0 in a proposal is not. Each of the 12 groups has two such newborn cells. ULPdistance(alphaL,1)=0 and eps/alphaG=infinity there. Comparing to the actual nonzero reference complement distinguishes absence from a precision-dominated proposal. P0 gas-density error rises from ~5.02e-9 at alphaG=1e-8 to ~9.93% at 1e-16; at 1e-18 and smaller it cannot recover this test state.

# 5. High-precision replay result

Recomputed from the old pre-update Q and KT A+/A-/mesh fluxes: C++ long double (16-byte storage, 64-bit significand), Boost cpp_dec_float_100 and independent Decimal100. The update reconstructs alpha fluxes from pre-update fractions; it does not cast the failed alpha=1. All 1560 Boost-replayed R0 proposals recover using the actual double JANAF/liquid EOS with preserved minority fractions. In the 24 emergent cells alphaG100 is 2.91442e-18–7.09877e-18; long double resolves a positive complement with finite quantization error. EOS values, root solve and derivatives remain **double**, not 100-digit thermodynamic reference data. long_double_reference.csv separates these quantities.

# 6. Failure mathematical/FP classification

All 12 observed no-step groups: **FINITE_PRECISION_STATE_REPRESENTATION**. Their repaired R0/R1/R2 have positive connected sampled steps. Old default INTERNAL_PROGRAM_ERROR labels on early presence exits are not evidence of an EOS-library internal failure. The original 14 species failures are separately FLUX_EVALUATION_ROUNDOFF with summation as a secondary contribution. Genuine EOS-domain exhaustion in other old B profiles remains a controlled stop and is not reclassified away. Old committed density errors are not retroactively repaired by changing fraction storage.

# 7. P0 result

P0 is the preserved baseline. It stores alphaL in one double and loses every tested -1e-20 increment from pure liquid; 1000 steps leave alphaG=0. Gas trace intrinsic errors are precision-conditioned even when pressure remains accurate and mixture-weighted density error is tiny. Liquid trace at alphaL near zero does not suffer the same subtraction but still has finite normal/subnormal limitations. P0 is rejected as the authoritative phase representation for the tested emergence paths.

# 8. P1 result

Compensated alphaL=hi+lo with twoSum/FMA preserves one physical fraction and its tiny complement; 16-byte mathematical payload. Both trace sides pass down to DBL_MIN in these constructed recovery tests; 1000 sub-ULP increments accumulate. It is a viable alternative, not active. hi/lo are numerical precision components and may not be evolved as two independent alpha PDEs.

# 9. P2 result

Signed minority coordinate: positive stores alphaL<=0.5; negative stores alphaG<=0.5. +0 means pure gas, -0 pure liquid. Crossing 0.5 switches which complement is encoded through a well-conditioned subtraction. One-double payload, no second fraction field. Temporary DD arithmetic evaluates differences and source/flux cancellation. Both phases, the half switch, old anchors, 27 contacts and 42 trace evolution profiles pass.

# 10. P3 result if evaluated

**NOT EVALUATED / NOT ACCEPTED.** No asymptotic trace thermo, mass removal, phase floor, energy/species removal or irreversible phase deletion.

# 11. Selected phase-fraction representation

**P2 selected for standalone development.** The authoritative quantity is the signed coordinate. alphaL/alphaG double projections are views and must not be fed back to recreate the coordinate. Near pure liquid, alphaL may print as 1 while the authoritative gas minority stays positive. R1 evaluates Minmod in the owner's minority coordinate and applies a common theta to the state and true fraction increment. R2-HYBRID uses this R1-bounded fraction with its primitive reconstruction, and falls back to R1 when stencil presence changes. This adjusted R2 is a prototype, not a promotion of the frozen B implementation.

# 12. Physical alpha DOF count

**ONE.** Physical alphaL+alphaG=1 is enforced by construction from one coordinate. No independent alphaG transport equation exists. Mode tags and temporary DD arithmetic are harness/numerical ownership only. The normal double projection sum rounds to one; true small minority information is carried by the coordinate rather than by trying to subtract two projected doubles.

# 13. Sub-ULP update behavior

1000 increments deltaAlphaL=-1e-20 from pure liquid produce alphaG≈1e-17 under P1/P2; P0 remains zero. This is specifically sub-ULP relative to the dominant fraction. P2 does not promise to accumulate increments below the ULP of its *stored minority coordinate* in general bulk states. Both 0.4→0.6→0.4 switches pass. Additional real-operator tests transport positive trace mass into resolvable cells; no mass overwriting or deletion is used.

# 14. Trace liquid matrix

| minority | recovery | rho minority relative | p relative | energy residual | cMix relative |
|---|---|---|---|---|---|
| 1e-08 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 1e-10 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 9.9999999999999998e-13 | PASS | 0 | 2.22045e-16 | 8.91507e-16 | 0 |
| 1e-14 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 9.9999999999999998e-17 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 1.0000000000000001e-18 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 9.9999999999999995e-21 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 1e-50 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 1e-100 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 9.9999999999999998e-201 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 1e-300 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 2.2250738585072014e-308 | PASS | 0 | 0 | 2.22877e-16 | 0 |
| 4.9406564584124654e-324 | CONTROLLED STOP | N/A | N/A | N/A | N/A |

The 1e-8…1e-20 bands also run 60 real updates under each of R0/R1/R2, with a neighboring 0.1 fraction. All 21 profiles on this side preserve trace and reach resolvable values; conservative totals close. Static extreme-normal tests do not certify arbitrary long-time advection at DBL_MIN.

# 15. Trace gas matrix

| minority | recovery | rho minority relative | p relative | energy residual | cMix relative |
|---|---|---|---|---|---|
| 1e-08 | PASS | 0 | 9.00391e-14 | 7.92177e-16 | 0 |
| 1e-10 | PASS | 0 | 9.4702e-14 | 3.96889e-16 | 0 |
| 9.9999999999999998e-13 | PASS | 0 | 7.52731e-14 | 7.66572e-16 | 0 |
| 1e-14 | PASS | 1.11022e-16 | 8.11573e-14 | 1.01143e-15 | 0 |
| 9.9999999999999998e-17 | PASS | 2.22045e-16 | 8.4488e-14 | 5.61726e-16 | 0 |
| 1.0000000000000001e-18 | PASS | 0 | 8.4488e-14 | 5.61726e-16 | 0 |
| 9.9999999999999995e-21 | PASS | 0 | 8.4599e-14 | 5.71328e-16 | 0 |
| 1e-50 | PASS | 0 | 8.4599e-14 | 5.71328e-16 | 0 |
| 1e-100 | PASS | 0 | 8.4599e-14 | 5.71328e-16 | 0 |
| 9.9999999999999998e-201 | PASS | 0 | 8.4599e-14 | 5.71328e-16 | 0 |
| 1e-300 | PASS | 0 | 8.4599e-14 | 5.71328e-16 | 0 |
| 2.2250738585072014e-308 | PASS | 0 | 8.4599e-14 | 5.71328e-16 | 0 |
| 4.9406564584124654e-324 | CONTROLLED STOP | N/A | N/A | N/A | N/A |

The 1e-8…1e-20 bands also run 60 real updates under each of R0/R1/R2, with a neighboring 0.1 fraction. All 21 profiles on this side preserve trace and reach resolvable values; conservative totals close. Static extreme-normal tests do not certify arbitrary long-time advection at DBL_MIN.

# 16. Intrinsic-density accuracy

Static P2 intrinsic density is compared to actual EOS rho(p=3 MPa,TG=800 K,TL=300 K), not nominal hydrocarbon values. Maximum gas/liquid relative errors: 2.22045e-16/0. Across 42 trace evolution profiles: 1.40998e-14/1.34337e-14. Across 27 contacts: 3.14426e-11/2.66658e-11. The static CSV separately records the mass-weighted error (mG*errG+mL*errL)/(mG+mL); its smallness is not used to waive intrinsic gates. Old B 30% drift records remain unchanged.

# 17. Pressure accuracy

Static maximum relative error 9.4702e-14; trace evolution 3.33689e-12; contacts 9.83288e-09. The moving N60/R1 1000-step pressure error 9.83288e-9 is only 1.67% below the predeclared 1e-8 limit. This narrow margin limits confidence outside the tested horizon; no tolerance was loosened.

# 18. cMix accuracy

Static cMix is compared with the preserved-minority recovery of the same conservative state; maximum representation-induced relative difference 0. In dynamic trace tests the reference reconstructs actual EOS-consistent material states at p/T and the current true fraction: maximum relative cMix error 5.04041e-14. Static maximum normalized energy residual 1.01143e-15. These are double-EOS consistency/representation checks, not a new absolute EOS validation.

# 19. Precision-support boundary

**Frozen tested support:** IEEE binary64, P2 authoritative coordinate; each present fraction and mass normal and positive; nonnegative closed species; finite conservative state; valid frozen EOS intersection and energy root; no underflow/overflow in used updates. Static witnesses cover minority 1e-8 through 1e-300 and DBL_MIN=2.2250738585072014e-308 on both sides. Full dynamic intrinsic checks are certified only for the tested 1e-8…1e-20, contact states and sampled continuation. Subnormal present fraction/mass triggers controlled stop, never deletion. A mass-product underflow to zero with positive fraction is invalid. Below representability the state is diagnostic-only; arbitrary smaller phases are not claimed supported. No magnitude-based physical absence threshold is introduced.

# 20. Species 14-failure classification

species14_attribution.json lists all 14 with actual face Q, FmG, each FY, direct/fmath compensated sums, A+/A-, scales and residuals. Face mYi sums are within the quantified ULP budget. Primary cause: evaluating KT through mG*(mYi/mG) plus cancellation of large weighted terms; final summation adds secondary roundoff. No upstream face identity failure or mathematical species-PDE mismatch was found. The original maximum normalized flux closure residual was 3.75167e-12; frozen threshold is 1e-12.

# 21. Face species closure

Cell/face storage uses N−1 independent species and the dependent last species mY_N=mG−sum_{i<N}mYi. R1 uses the same residual slope; R2 constructs the residual last fraction/mass without renormalization. Actual stored species are used in KT. Old isolated faces already meet the ULP budget, so the flux repair does not conceal a bad face state. Runtime species mapping is canonical at recovery and uses the runtime dependent slot at transport.

# 22. Flux species closure

For i<N, FY_i=A+*mYi_L+A-*mYi_R; FY_N=FmG−sum_{i<N}FY_i. All 14 former failures now pass at the unchanged 1e-12 tolerance, with zero direct-sum normalized residual in these 14 cases. The full repaired B face matrix passes **14179 checks / 0 failures**, including 5832 closure checks, gas compatibility, corners, shared theta and runtime species permutation. Frozen original B source rerun intentionally reproduces its same 14 failures, with no new failure class; this is retained historical evidence, not a claim that untouched code was fixed.

# 23. Residual-species formulation

By KT linearity,

FY_N=A+*(mG_L−sum_i<N mYi_L)+A-*(mG_R−sum_i<N mYi_R)=FmG−sum_i<N FY_i.

Thus residual flux changes floating-point order, not the mathematical flux. The cell incremental identity ΔmY_N=ΔmG−sum_i<N ΔmYi follows. Standalone conservative trial retains the frozen per-species flux-divergence update; stored cell sums stay within the original roundoff budget and all conservative ledgers pass. No post-update species normalization or mass adjustment is used. Residual state/face construction is the dependent species identity, not a rescaling of all Yi.

# 24. Species positivity

Dependent last species must be nonnegative. Face trial and cell recovery reject negative masses, and shared theta/positive timestep constraints use all species, including the residual species. No max(last,0) or clipping. Corner, deliberate-slope, runtime permutation and multistep suites pass; invalid states remain controlled rejections.

# 25. R0 anchor revalidation

| case | old candidate | N | R0 connected dt |
|---|---|---|---|
| ALEContact | 1 | 60 | 0.00011567735388403751 |
| ALEContact | 1 | 200 | 0.00011567670874322797 |
| ALEContact | 2 | 60 | 0.00011567735388403743 |
| ALEContact | 2 | 200 | 0.00011567670874322797 |
| movingContact | 1 | 60 | 0.00011612440764248136 |
| movingContact | 1 | 200 | 0.00011612440764248136 |
| movingContact | 2 | 60 | 0.00011612440764248136 |
| movingContact | 2 | 200 | 0.00011612440764248136 |
| stationaryContact | 1 | 60 | 0.00012050921343033312 |
| stationaryContact | 1 | 200 | 0.00012050921343033312 |
| stationaryContact | 2 | 60 | 0.00012050921343033312 |
| stationaryContact | 2 | 200 | 0.00012050921343033312 |

All 12 are positive. Numerical unit-volume/unit-area stencils are used: these dt values are **standalone**, not physical timesteps for 300_2D. Protocol: joint bounds, then 32 samples and 52 bisections from dt=0, stopping at the first observed invalid point; finite sampling is not proof of every real-valued intermediate dt. No jump to later admissible islands.

# 26. R1 rerun

Same 12 unchanged committed states: 12/12 positive connected steps after R0 passes. Reinitialized precise contacts: 9/9 configurations pass, including N60 moving 1000 steps. Uses joint dt and dtThermo, true-fraction shared theta, residual-species closure. No coupled flux correction or energy repair.

# 27. R2 rerun

Same 12 states: 12/12 positive connected steps. Nine precise contact configurations pass, including N60 moving 1000 steps. Phase-aware fallback and primitive construction retain the standalone prototype status. Results do not establish formal order or all previously assessed non-contact stress paths for the precision-aware variant.

# 28. Contact multistep result

| case | N | operator | accepted | p relative | max rho relative |
|---|---|---|---|---|---|
| stationaryContact | 20 | R0 | 100 | 2.11242e-11 | 5.70655e-14 |
| stationaryContact | 20 | R1 | 100 | 2.4357e-11 | 3.35287e-14 |
| stationaryContact | 20 | R2 | 100 | 2.26783e-11 | 4.66294e-14 |
| stationaryContact | 60 | R0 | 100 | 2.11524e-11 | 2.72005e-14 |
| stationaryContact | 60 | R1 | 100 | 2.36524e-11 | 3.15303e-14 |
| stationaryContact | 60 | R2 | 100 | 2.28214e-11 | 3.41949e-14 |
| stationaryContact | 200 | R0 | 100 | 2.11691e-11 | 2.73115e-14 |
| stationaryContact | 200 | R1 | 100 | 2.3642e-11 | 3.21965e-14 |
| stationaryContact | 200 | R2 | 100 | 2.27491e-11 | 3.41949e-14 |
| movingContact | 20 | R0 | 100 | 2.11742e-11 | 5.4734e-14 |
| movingContact | 20 | R1 | 100 | 2.21707e-11 | 1.62315e-13 |
| movingContact | 20 | R2 | 100 | 2.17415e-11 | 3.64153e-14 |
| movingContact | 60 | R0 | 1000 | 2.69759e-11 | 1.07803e-13 |
| movingContact | 60 | R1 | 1000 | 9.83288e-09 | 3.14426e-11 |
| movingContact | 60 | R2 | 1000 | 2.82501e-11 | 1.0536e-13 |
| movingContact | 200 | R0 | 100 | 2.08484e-11 | 3.53051e-14 |
| movingContact | 200 | R1 | 100 | 2.21707e-11 | 1.63425e-13 |
| movingContact | 200 | R2 | 100 | 2.17415e-11 | 3.67484e-14 |
| ALEContact | 20 | R0 | 100 | 2.07048e-11 | 5.34017e-14 |
| ALEContact | 20 | R1 | 100 | 2.1914e-11 | 1.5743e-13 |
| ALEContact | 20 | R2 | 100 | 2.15379e-11 | 3.41949e-14 |
| ALEContact | 60 | R0 | 100 | 2.04796e-11 | 3.60822e-14 |
| ALEContact | 60 | R1 | 100 | 2.18365e-11 | 1.63203e-13 |
| ALEContact | 60 | R2 | 100 | 2.14562e-11 | 3.63043e-14 |
| ALEContact | 200 | R0 | 100 | 2.06886e-11 | 3.56382e-14 |
| ALEContact | 200 | R1 | 100 | 2.18885e-11 | 1.61871e-13 |
| ALEContact | 200 | R2 | 100 | 2.14631e-11 | 3.64153e-14 |

27/27 PASS; 24 profiles complete 100 accepted updates; N60 moving R0/R1/R2 each complete 1000. Existing old N20 1000-step evidence remains frozen, not overwritten. This is standalone discrete-operator evolution with unit geometry, not CFD case validation.

# 29. ALE result

All nine ALE configurations (N20/60/200, R0/R1/R2) pass 100 accepted steps with sinusoidal mesh flux and updated volumes. The same one-alpha equation is evaluated with relative KT fluxes and physical phi*=A++A-+meshPhi. Face source/flux uses one coefficient family. No independent alphaG PDE or ALE-only phase repair.

# 30. Conservation ledger

Periodic conservative totals for mG,mL,Mxyz,Et and all species are audited separately from alpha. Maximum scaled drift across 27 contacts 5.64376e-15, versus predeclared 5e-12. Trace evolution maximum 7.16172e-16. Precision storage never overwrites mass/momentum/energy/species to match a fraction or nominal density.

# 31. Alpha balance

Global ledger: sum(Vnew*alphaLnew)−sum(Vold*alphaLold)−sum(dt*alphaLold*div(phiPhysStar))=roundoff, for periodic fluxes. Maximum absolute discrepancy 2.57053e-15; tolerance 5e-12*N, declared before testing.

Cell update numerator is Σ_left A±(alpha_face−alpha_cell)−Σ_right A±(alpha_face−alpha_cell), with alphaNew=alphaOld+dt*Nalpha/Vnew. This is exactly the frozen nonconservative alpha equation after GCL cancellation, when phiRelStar=A++A-. Temporary DD arithmetic postpones rounding. The 20 local 400-digit fixed/ALE algebra checks agree below 1e-390. Independently rounded source and face coefficients are not allowed to break this identity. D alphaL/Dt=0 is unchanged.

# 32. Performance/memory cost

| mode | update ns | recovery ns | KT face ns | payload bytes | harness bytes |
|---|---|---|---|---|---|
| 0 | 9.8066200000000006 | 5319.5330000000004 | 11263.657999999999 | 8 | 24 |
| 1 | 15.37772 | 5084.6670000000004 | 11641.252 | 16 | 24 |
| 2 | 6.9321900000000003 | 5313.2359999999999 | 10843.309999999999 | 8 | 24 |

| mode | R strategy | reconstruction ns/face |
|---|---|---|
| 0 | 1 | 190786.79333333333 |
| 0 | 2 | 218524.05666666667 |
| 1 | 1 | 187432.75666666665 |
| 1 | 2 | 215859.03083333332 |
| 2 | 1 | 200821.13166666665 |
| 2 | 2 | 224970.95666666667 |

One standalone timing batch, not statistically established speed ratios. Updates:100000; recovery/KT faces:1000; reconstruction:30 batches ×20 cells ×2 faces, including thermodynamic checks. Different EOS branches dominate timings. Selected P2 payload=8 bytes, replacing authoritative alpha storage; retaining alphaL view would add 8 bytes/cell plus OpenFOAM field overhead. Harness uses 24 bytes/cell for mode+DD comparison. P1 needs16-byte payload.

Future ABI/runtime requirements at M5C.3/M6B: explicit fraction-aware recovery API, field ownership, BC/reconstruction integration, MPI/serialization/restart preserving tiny coordinate and signed zero, map/refinement of the physical scalar and sign switch. Reconstructing P2 from rounded alphaL is forbidden. None is activated here.

# 33. Whether coupled limiter is actually required

**NOT DEMONSTRATED / NOT REQUIRED for this retested contact/trace matrix.** Conditions A–D hold and no additional high-order inadmissibility (E) remains in these tests. The old no-step/species evidence cannot now justify generic FCT. This does not certify every interior path of the frozen B competition; precision-aware high-order promotion and the remaining shock/stress/accuracy matrix are still open.

# 34. Whether M5C.2C.2 must start

**NO, based on present C.1 evidence.** Not executed. Global need remains conditional: start only if a further test exhibits valid representable R0 with positive connected dt, correct species closure, no EOS exhaustion, and extra high-order inadmissibility. No coupled operator correction was implemented.

# 35. Whether M5C.2 may close

**NO; M5C.2 remains PARTIAL.** C.1 resolves the specific representation/species prerequisites. Precision-aware variants have not been promoted through the entire B formal-order/stress/limiter-selection gate, production fraction ABI/ownership and arbitrary-path concerns remain, and R1 long-time pressure margin is narrow. M5C.3/M8A/M6B stay blocked. No later milestone is executed.

# 36. Active solver impact

**NONE.** Active solver C/H/Make, reconstruction, timestep, gas equations, alphaEqn, DPM, surface tension and frozen EOS/thermo shared libraries remain unchanged. New code is only in fiveEqPrecision and standalone tests fiveEqPrecisionIsolation/fiveEqFractionPrecision/fiveEqSpeciesClosure. Four test harness builds pass Foundation OF7 wmake (initial skeleton and final diagnostics included), with -Werror. All numerical tests are offline, no blockMesh/checkMesh/solver case run.

| regression/test | checks | failures | interpretation |
|---|---|---|---|
| recovery | 2096 | 0 | PASS |
| bridge | 38 | 0 | PASS |
| flux | 34902 | 0 | PASS |
| admissibility | 362962 | 0 | PASS |
| original frozen B faces | 14179 | 14 | same known failures; no regression |
| residual-species B faces | 14179 | 0 | PASS |
| precision assessment | 280888 | 0 | PASS |
| additional assessment | 95026 | 0 | PASS |

Original frozen B face executable exit1 is the expected same14-failure signature; repaired candidate passes the complete face gate at original tolerances. No known failure is silently converted to PASS. protection_check.json and immutable library hashes record the active protection.

# 37. Updated milestone matrix

| milestone | status |
|---|---|
| M0–M4 | COMPLETE (historical scope) |
| M5A/M5B | COMPLETE / reference and design |
| M6A1/M6A2.1/M6A2.2 | standalone/passive frozen, not active |
| M5C.1 | COMPLETE / standalone |
| M5C.2A | COMPLETE / tested R0 protocol |
| M5C.2B | PARTIAL; historical evidence preserved |
| M5C.2C.1 | COMPLETE / standalone tested domain |
| M5C.2C.2 | NOT STARTED; not justified by retested failures |
| M5C.2 | PARTIAL |
| M5C.3/M8A/M6B | BLOCKED / NOT STARTED |

**STOP.** No C.2, M5C.3, M6B or CFD performed. Checkpoint: checkpoints/M5C2C1_precision_closure_v1.zip. Machine-readable decisions and every gate are in fitting/reconstruction/m5c2c1_v1/milestone_result.json.
