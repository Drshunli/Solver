# M8A.1 production gas support and transactional rollback gate

# 1. M8A.1 status

**PARTIAL.** Classifier/strict operator probes and native production-model events implemented/tested; production enforcement hooks and complete real transaction NOT closed.

# 2. Production cloud configuration

Actual 300_2D sprayCloudProperties copied byte-for-byte to a manufactured native harness. Source and runtime selection audited; fixture geometry/fields/write-time are unit inputs, not a CFD case run.

# 3. Enabled DPM models

coneInjection/RosinRammler; sphereDrag; heat none; phaseChange none; singlePhaseMixture; blobsSheetAtomization; ReitzKHRT; ORourke/coalescence; stochasticDispersionRAS; standardWallInteraction/rebound; voidFraction. RanzMarshall/evaporation coefficient dictionaries are inactive. See PRODUCTION_DPM_RUNTIME_AUDIT.md.

# 4. Actual carrier interpolation path

rho/mu/T/Cp/kappa/p=cell; U=cellPoint; species direct cell reads. Future rhoG/TG/YG must be intrinsic gas; native cellValueSourceCorrection uses rho*V and remains unresolved for mixed gas partial mass.

# 5. Interpolation stencil definition

Native vector basis expansion records exact tensor coefficients, physical patch contributors, constraints and mandatory scalar cell read; native particle barycentric/tet overload used after crossing. actual_stencil.csv contains measured injection weights. Serial <=256-entity diagnostic only; no production/MPI builder.

# 6. Gas-support classifier

fiveEqDPMCarrierSupport uses immutable committed signed P2 + mG consistency + frozen recovery. Controlled PRESENT/TRACE/ABSENT/INCONSISTENT/THERMO results; no FatalError or alpha decode heuristic.

# 7. Injection support policy

Validate actual native injector location/tet/stencil BEFORE allocation. Native setPositionAndCell + pre-allocation guard probe passes. Hook not installed in native InjectionModel::inject: production gate PARTIAL.

# 8. Tracking support policy

Native trackToAndHitFace crosses an internal face; same classifier rejects next absent cell before carrier query and permits trace gas. This guarded-caller probe does not install a guard in legacy move().

# 9. Source-deposition policy

sourceTrial calls the same classifier before unchanged adapter/recovery. Absent source rejects even if zero; production calc/accumulation interception unimplemented.

# 10. Trace-gas behavior

alphaG1e-20 recognized even with decoded alphaL1; zero source bit identity and excessive source recovery rejection pass. Rejected source preserves committed support snapshot.

# 11. Exact gas-absent behavior

Containing-cell, boundary-contributor, injection/track/source caller tests reject before native carrier query. No artificial gas creation. Complete production cloud crossing/discard remains unproven.

# 12. DPM applicability scope

Strict pre-existing gas support only. No renormalization, nearest-gas copy, dummy thermo, parcel deletion/bounce workaround or alpha source. Contract_v1 frozen.

# 13. Mutable cloud-state inventory

Parcel fields/IDs/tets, allocator, injector/distribution/time/counters, RNG, models/owner refs, force/dispersion caches, occupancy, sources/coefficients, solution/outputProperties, private theta, pending IO, caller Q/time/mesh and MPI enumerated in audit.

# 14. Native cloud restore limitations

Confirmed clone owner aliases original, cloudReset resets global ID allocator0, private theta is lost, native sources omitted, full solution/output dictionaries not reset, files not undone. Empty-cloud tests can hide allocator defects.

# 15. Selected transaction architecture

Preferred isolated trial cloud with correctly rebound owners and commit-deferred IO. Raw native clone is rejected; raw snapshot+source restore insufficient. No complete production implementation claimed.

# 16. Parcel-state rollback

Real minParcelMass deletion restores full native serialized parcel; repeat deletion passes. Actual enabled rebound restores/replays full serialized parcel. These local tests do not close global transaction.

# 17. Source-accumulator rollback

Frozen NativeDPMSourceSnapshot used alongside native snapshots; energy/source API implementation unchanged. Full atomic source+cloud+Q commit remains incomplete.

# 18. Injector-state rollback

Actual evolve injects21 parcels and5.26272e-10kg; count/mass retry match. First origId1 versus retry0 exposes incomplete allocator restoration, so injection rollback remains PARTIAL.

# 19. RNG rollback

Actual production random models run; post-event scalar RNG and cumulative impulse repeat. Full parcel/random-decision branch coverage, including forced breakup/coalescence, not proven; do not infer global deterministic rollback.

# 20. Patch-interaction rollback

Actual standardWallInteraction rebound invoked; native serialized parcel restoration and identical rebound replay PASS. Escape/stick modes not selected.

# 21. Breakup/collision rollback status

Both are ENABLED and run in native evolve; forced child creation/merge/deletion rollback NOT validated. They cannot be labeled outside production scope or PASS.

# 22. Output-side-effect handling

Native unit writeTime forced to exercise output: theta/outputProperties files remain after native restore, while theta memory field disappears. No commit-safe output implementation; hard blocker. No production write schedule changed.

# 23. begin/commit/discard API

Lifecycle capability gate rejects known unsupported production path BEFORE mutation, checks validated commit and single terminal call. It is a readiness interface, not the requested complete real-cloud transaction.

# 24. Oversized-step retry

NOT PROVEN: complete production transaction must exist before this golden test. No artificial mock success reported.

# 25. Small-step equivalence test

NOT PROVEN. Real nonzero allocator counterexample already disproves exact native reject/retry cloud equivalence.

# 26. Support-failure rollback

Immutable support and rejected coherent source tests PASS; whole native-cloud/Q/output rollback on gas-absent trajectory NOT PROVEN.

# 27. Real production-path harness

Actual basicSprayCloud, identical DPM dictionary/runtime models, real interpolation, injection, tracking, deletion, rebound, source accumulation and clone/restore used. 44 assertions/0 failures; includes assertions proving defects. productionTransactionComplete=false. No Eulerian equations or CFD run.

# 28. Energy-ledger regression

Eight M8A regressions rerun:9288 checks/0 failures. ledger.csv, golden_energy.csv, results and failure files byte-identical to frozen originals. Energy formulas/headers never edited.

# 29. Pure-gas legacy regression

Existing equivalent pure-gas accepted-source regression byte-identical. New support layer is passive; no active source-placement modification.

# 30. MPI/decomposition readiness

Serial diagnostic only. Processor-transfer support/owner/message buffers and collective accept/discard absent: PRE-M6B MPI BLOCKER.

# 31. No-alpha-source confirmation

Signed P2/Allaire K0 unchanged; no alpha equation/source or gas-volume creation.

# 32. Active solver impact

**NONE.** Protected old source/case/energy/result hashes audited; only MILESTONE_STATUS.md authorized update. No active timestep/cloud/equation/source edit; no CFD.

# 33. Remaining blockers

Scalable actual production stencil builder and injection/move/source hooks; owner-safe trial cloud or full snapshot including allocator/solution/properties/occupancy/private theta; commit-deferred IO; enabled breakup/collision branch rollback; oversized/small-step and full support-failure golden tests; MPI ownership.

# 34. Whether M8A.1 is COMPLETE

**NO.**

| Gate | Status |
|---|---|
| 1. actual production cloud config audited | PASS |
| 2. actual interpolation path audited | PASS |
| 3. authoritative gas-support classifier implemented | PASS |
| 4. P2 trace gas correctly supported | PASS |
| 5. exact gas-absent cells rejected | PASS |
| 6. injection support check implemented in production | PARTIAL |
| 7. tracking support check implemented in production | PARTIAL |
| 8. interpolation-stencil support check implemented in production | PARTIAL |
| 9. source-deposition support check implemented in production | PARTIAL |
| 10. no fake gas thermo introduced | PASS |
| 11. production applicability contract frozen | PASS |
| 12. complete mutable cloud state enumerated | PASS |
| 13. source accumulators included in COMPLETE transaction | PARTIAL |
| 14. injection rollback PASS | PARTIAL |
| 15. parcel deletion rollback PASS | PASS |
| 16. enabled patch-model rollback PASS | PASS |
| 17. enabled stochastic-model full RNG rollback PASS | PARTIAL |
| 18. enabled breakup/collision event rollback PASS | PARTIAL |
| 19. output side effects commit-safe | PARTIAL |
| 20. real cloud begin/commit/discard implemented | PARTIAL |
| 21. oversized-dt retry PASS | PARTIAL |
| 22. direct-small versus reject-retry equivalence PASS | PARTIAL |
| 23. gas-support failure WHOLE cloud/Q rollback PASS | PARTIAL |
| 24. trace-gas source trial PASS | PASS |
| 25. real production-path enforcement/transaction harness PASS | PARTIAL |
| 26. M8A energy regressions unchanged | PASS |
| 27. pure-gas legacy regression unchanged | PASS |
| 28. no alpha source | PASS |
| 29. active solver physics unchanged | PASS |
| 30. no CFD run | PASS |


# 35. Whether M8A is COMPLETE

**NO.** Accepted original ledger gates remain intact, but M8A.1 is PARTIAL.

# 36. M6B.0 start permission

**NO / BLOCKED.** Not executed.

# 37. M6B.1 permission

**NO.** No active equation switch.

# 38. Updated milestone matrix

| Stage | Status |
|---|---|
| M5C.1-M5C.3 | COMPLETE / NOT ACTIVE |
| Accepted M8A source/energy gates | unchanged / regression PASS |
| M8A.1 | PARTIAL / native defects and guard probes documented |
| M8A overall | PARTIAL |
| M6B.0/M6B.1 | BLOCKED / NOT STARTED |
| CFD | NOT EXECUTED |

STOP. No M6B.0/M6B.1 performed.

