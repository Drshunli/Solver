# K1 contract closure — 37-item final report

2026-10-04. Evidence directory: `fitting/dpm/m8a3b_t3br2c_k1_closure_v1`. Previous K1/R1 source and reports retained unchanged.

## 1. K1 status

COMPLETE / reachability-based contract correction. Fresh264746 checks,0failures. No physics/transaction source changes; no CFD.

## 2. Native KH birth semantics

Actual installed Foundation7 and frozen local source confirm copy construction from parent, new origId, carrier-dependent initialization, adoption. Local guard and lazy preflight additions are distinguished from native OF7.

## 3. Parent position/cell/tet

First actual record: (0.503,0.5,0.5),cell0,face-1,tetFace0,tetPt1; barycentric=(0.994,0.003,0,0.003), full precision in JSONL. Coordinates belong to the synthetic test mesh, not the production injector.

## 4. Child position/cell/tet

Exactly equal to the parent at all92 audited births. No coordinate/cell/tet modification.

## 5. Parent/child identities

First record parent origProc0/origId107; child origProc0/origId320. Distinct addresses recorded. Test-only fault child ID108 is a separate trial and not confused with the valid trajectory.

## 6. Parent support token

Actual authority is the composite identity/ID/pose/coordinates/generation/requirements key, not an invented integer token. Exported parent key in `support_authority_keys.json`; first generation1,All255. Old parent provider authority rejects the child.

## 7. Child support token

Exported child key has equal spatial entries/generation/requirements and distinct address/ID. It becomes authoritative only after independent child preflight. First provider preflightCount1408.

## 8. Session/token invalidation

Frozen local invalidateAfterMove precedes child preflight. Identity mismatch additionally prevents parent cache authorization. No cached parent PASS is used as child authority.

## 9. Child independent preflight

92 child-specific fresh validations PASS; queried identity/pose, count, generation, mask and result recorded. Negative parent-authority checks make zero property calls.

## 10. Birth support result

VALID at identical valid pose, spatialInvalidAtBirth=false. Expected result, not a synthetic failure.

## 11. Reachability proof

See `KH_CHILD_SUPPORT_REACHABILITY_v1.md`: equal S,G,R and fixed M imply equal spatial support. Identity authority remains separate. The old immediate spatial-invalid condition cannot be met without violating frozen assumptions.

## 12. Hidden KH-specific path audit

Actual source searches show no physical child-only predicate, requirement expansion or stencil. The explicit test-only reject hook is separately identified and is not a physical rule. ReitzKHRT calculation creates no separate support evaluator.

## 13. Cloud adoption boundary

Before adoption unique_ptr owns newborn; after release/addParticle cloud owns it. No ownership gap, double ownership or orphan observed.

## 14. Post-adoption generic-path proof

Installed Cloud iterates every particle through p.move. Frozen LazyKinematicParcel uses native trackToFace→invalidate→preflight→property materialization→model update; rebound invalidates too. Individual identity and generation checks remain. 5694 later child queries observed.

## 15. Real post-birth crossing result

Optional crossing NOT RUN this round and NOT CERTIFIED. Previous fixture attempt failed on parent first; child-first crossing remained FIXTURE_UNREACHABLE for that tested path only. No universal unreachability claim, no new large-dt/support/Q/child modification. Authorized generic-path alternative is used.

## 16. Property-call audit

Fresh strict owner1 remains gas-valid; stencil18–21 is gas-absent. At/after rho6/6,T6/6,Y6/6,Cp12/12,mu6/6,kappa6/6. Pure owner2 alphaG=mG0 gives all0/0. Six increments zero. Pure owner uses native geometric tracking then query, not full kinetic travel beyond earlier strict rejection.

## 17. Child ownership

KH valid:11562ctor=11562dtor,live0. KH fault:11135ctor=11135dtor,live0. Guard catches newborn exception before adoption; subsequent cloud lifecycle/destruction is closed.

## 18. Parent ownership

No parent ownership corruption or double destruction. Accepted parent/population unchanged after discard; trial-owned population released. ctor=dtor+cloud-owned-live holds at audited boundaries.

## 19. Rollback

Accepted transactionState-v1 and carrier snapshot match pretrial states. Includes parcel IDs/fields/KH history, native sources, pending output, model state, generation and time. Whole-trial rollback, not physical child deletion.

## 20. Allocator

Global particleCount and accepted allocator restored; canonical direct/retry future comparison includes allocator.

## 21. RNG

RNG/cached normal restored through frozen canonical codec and verified future equality. Observation consumes no model RNG.

## 22. Source semantics

Frozen source adapter/ledger unchanged. Failed-trial cleanup commits no dmG/dmYi/dM/dEt. Support failure is transaction failure, not compensated physical deletion.

## 23. Output semantics

Rejected trial has zero accepted publications; accepted output exactly once, duplicate publication idempotent. Each KH direct/retry path has77paired accepted output files, all equal. Diagnostic JSONL is outside accepted tickets. Production crash-safe restart not certified.

## 24. Direct/retry equality

Fresh valid prepared-event discard/small retry and fresh TEST_ONLY_KH_CHILD_SUPPORT_REJECT/discard/small retry both equal direct valid trajectory. The latter is transaction fault injection, NOT REAL_SPATIAL_INVALID_CHILD or PHYSICAL_SUPPORT_CROSSING.

## 25. >=10 future equality

11paired accepted states per scenario: first acceptance plus10future. Archived canonical binaries independently compared; all exact. Includes population,IDs,U/d/T/Y/history,RNG,allocator,source,output,generation and query results.

## 26. Revised KH support contract

Independent birth preflight, parent authority invalid for child, equal valid pose remains valid, post-adoption generic support/reject contract. All safety requirements preserved. Current explicit user request supplies revision authority.

## 27. Whether old gate retired

YES by REACHABILITY-CONTRACT REVISION. No fabricated spatial PASS and no rewritten historical R1 evidence.

## 28. ReitzKHRT capability result

FULL-SERIAL-TRANSACTION-SAFE within tested passive serial selected BoundCloud graph. Actual reachable birth/identity/guard/adoption/rollback/retry/future/output gates PASS. No active solver or distributed/production restart certification implied.

## 29. Eight-model capability matrix

| Model | Transaction capability | Qualification |
|---|---|---|
| coneInjection | FULL-SERIAL-TRANSACTION-SAFE | Frozen I1 plus fresh ownership/retry |
| sphereDrag | FULL-SERIAL-TRANSACTION-SAFE | Frozen R1 plus fresh runtime subset |
| stochasticDispersionRAS | FULL-SERIAL-TRANSACTION-SAFE | Frozen R1 evidence re-audited |
| blobsSheetAtomization | FULL-SERIAL-TRANSACTION-SAFE | Frozen R1 evidence re-audited |
| ReitzKHRT | FULL-SERIAL-TRANSACTION-SAFE | Revised reachability contract, fresh valid/fault |
| ORourke | FULL-SERIAL-TRANSACTION-SAFE | NATIVE-PHYSICS-LIMITATION; NOT FULL-CONSERVATION-SAFE |
| rebound | FULL-SERIAL-TRANSACTION-SAFE | Frozen actual rebound/invalid evidence |
| voidFraction | FULL-SERIAL-TRANSACTION-SAFE | Frozen owned-output evidence |

Labels apply only to audited passive serial scope. Matrix is a certificate document; no runtime capability flags/physics altered.

## 30. R2C full checklist audit

30explicit rows PASS,0OPEN. `R2C_COMPLETION_CHECKLIST.json` records each basis. Re-audited runtime/pure/strict/trace/mixed0.1/0.5/0.9,rebound/mixed/invalid,KH,injection,all4ORourke branches,minmass,combined,canonical/lifetime/future/output,100sequential accepts/100alternating/1000grouped discards,registry/RNG/allocator/generation/lazy cache. Frozen lifecycle CSV independently checked for counts,ctor=dtor+owned,constant registry and accepting generation sequence. Historical R1 final13969/0 is inherited, not relabeled fresh. Shared source hashes unchanged, so giant suites need not all rerun.

Fresh scope:

| Test | Checks | Failures |
|---|---:|---:|
| KH valid |108|0|
| KH test-only reject/retry |108|0|
| generic strict |87|0|
| generic pure owner |87|0|
| I1 ownership matrix |12083|0|
| I1 native-false |18|0|
| I1 retry |61|0|
| R2B support-first |252194|0|
| Total |264746|0|

## 31. Whether K1 COMPLETE

YES. Mandatory birth/authority/support/path/ownership/retry/future/hash gates PASS. Optional child-first spatial crossing not claimed.

## 32. Whether R2C COMPLETE

YES after explicit checklist audit. Previous sole impossible gate corrected; no other OPEN or mandatory blocker observed. C1 remains historical PARTIAL; C2 native-compatible semantic-noncanonical contract frozen; production restart NOT CERTIFIED.

## 33. Whether R2-FINAL may start NEXT ROUND ONLY

YES, eligible for next-round explicit user instruction. Not executed this round.

## 34. Foundation hashes

6717installed Foundation/Make entries and19native parcel entries verify OK. Native ReitzKHRT and ORourke fingerprints saved. Protected145/R2B30/I1-R2B240/C1113/C2-R1288/oldR1evidence1192/precedingK1367 entries unchanged. Compilation evidence inherited from frozen PASS; no new source/Make changes and no fresh compilation claimed.

## 35. Active solver impact

NONE. No active equations,thermo/recovery,P2/R1,source adapter,ledger,parcel serializer,KH/ORourke physics,shared transaction logic or ownership implementation modified. Added only offline auditing/runners and documentation.

## 36. Production mesh/BC impact

NONE. No production geometry,Q/support-map/boundary/time-step changes. No CFD or mesh generation/validation.

## 37. Updated milestone matrix

| Milestone | Status |
|---|---|
| R2B |COMPLETE/FROZEN|
| R2C-I1 |COMPLETE/FROZEN|
| R2C-C1 |HISTORICAL PARTIAL/NONDETERMINISTIC_BINARY_BLOCKER|
| R2C-C2 |COMPLETE/FROZEN/NATIVE-COMPATIBLE/SEMANTIC-NONCANONICAL|
| R2C-R1 |Historical PARTIAL; old sole gate corrected by K1|
| R2C-K1 |COMPLETE|
| R2C |COMPLETE/explicit checklist audit|
| R2-FINAL |MAY START NEXT ROUND ONLY/NOT EXECUTED|
| T3B/T3 |PARTIAL|
| T4 |NO|
| M8A |PARTIAL|
| M6B.0/M6B.1 |NO|
| CFD |NO|

STOP. Evidence/checkpoint manifest accompanies this report.
