# M6B1 MC4A KBOUND REPRESENTATION CLOSURE REPORT v1

2026-10-06。**MC4A COMPLETE；MC4 COMPLETE / MICRO-QUALIFIED / NOT DYNAMICALLY QUALIFIED。**

K公式和source保留原值，用稳定response guard和full-alpha path coefficient关闭1ULP误拒绝。最终全量重编译及全部mandatory复跑完成。MC5仅下一轮；本轮STOP。

1. **MC4A status** — COMPLETE / REPRESENTATION GUARD DEFECT CLOSED；MC4恢复完整资格并COMPLETE / NONZERO-K SERIAL MODEL IMPLEMENTED / MICRO-QUALIFIED / NOT DYNAMICALLY QUALIFIED。

2. **Exact old blocker reproduction** — 保留的旧MC4 micro二进制复现INVALID_PE_ACOUSTICS，exit=1，前后SHA不变。新最终helper的第一条控制直接使用a=.1,b=.9,AL=1.0000000000000002e100,AG=1e-100；保留K=-.10000000000000002，guard接受，Decimal90误差仍1.3877787807814457e-17。

3. **Root cause** — REPRESENTATION-LEVEL IMPLEMENTATION GUARD DEFECT：rounded K向外1ULP被直接边界比较误拒绝。修复不改变数学范围-a<=K<=b；稳定响应及精确二进制有理数参考验证其数学不变量。不是EOS/R1/model/hyperbolicity阻塞。

4. **Guard source delta** — MC4A仅修改1个active header：fiveEqPrecision/fiveEqNonzeroKModel.H；其余110项SHA不变。before 9b30adf3ac88358ad602dde659596f7365628fe7c4b45dd847c3772c0870ba4c；after e76a8cd968fa4b8d47f025fad40c33be37ddc9bca2aac5c01a9d2c14001c5f6f。exact active_source.patch/source_delta.json封存。

5. **Stable response formula** — nL=a*(AG/S)，nG=b*(AL/S)，D=nG+nL；responseL=nL/D，responseG=nG/D。hard guard检查有限输入/正moduli/正D/响应有限且在[0,1]及响应和1符合原MC3 5e-14+3e-20预算。pure gas=(0,1)，pure liquid=(1,0)，不查询缺相EOS。

6. **K formula preservation** — K=(a*b)*(((AG-AL)/S)/D)赋值行逐字不改，source仍使用它。没有K clipping、epsilon K-bound、改成response-a、EOS/R1/PDE/cPE数学修改或预算调整。

7. **Direct a+K audit** — new threeLegPath的full-alpha legs改用responseL；IK仍KL/KR。source numerator、source-aware bounds及DD/P2源码与MC4 STOP逐字节不变，不把source改成(responseL-a)*theta。全111-source audit见response_sound_audit.json。K_from_L/G只读诊断有2项近K=0消减误差不满足原K精度预算（ORIGINAL63_13, ORIGINAL63_48），如实标出，不作为K公式/数学边界/接受判据；未重定义预算。

8. **Adversarial controls** — B1–B8全部PASS，含两种alpha/extreme moduli、trace、near-equal moduli、1e308/1e-308及原失败exact payload。另2项a/b=min-normal=2.2250738585072014e-308代数控制通过；无threshold phase或manufactured phase。

9. **63-control algebra** — 原63 fresh native全部PASS，总74=exact旧payload首门+63+B8+2近表示下限控制。K/response/cPE用冻结Decimal90参考；对于1e-200的边界距离，Decimal90自身严格比较可能有~1e-90舍入，改用精确有理数binary-input数学界验证，无eps。K max绝对误差1.1102230246251565e-16，均符合未改的相对+绝对预算；9个rounded outward K也有合法稳定响应。

10. **cPE** — 冻结stable bulk/rho公式不变；pure/trace及全部代数范围finite/positive，cPE² max参考relative error2.611207975403701e-16。fresh active seven physical states对照独立实际EOS/Jacobian声速通过。

11. **Hyperbolicity** — 从本轮最终编译active helper/recovery输出的7个physical states fresh重算14个Decimal90实际conservative Jacobians/halfstep。max normalized acoustic error3.3043012770406222e-14，imag1.3078911955191812e-16，冻结2e-6预算内。没有引用旧MC3结果充当runtime PASS。

12. **P2 P1-P10** — 10项完整fresh复跑：zero-div、compression、expansion、pure gas/liquid、trace gas/liquid、minority switch、两端overshoot。P1–P8一次DD advanced authority与Q0一致，consv只等于原flux trial；P9/P10 expected reject，正/负pure zero与trace保留，P8确实切换signed minority。

13. **Source-aware bound** — 两种±1e12 synthetic prescribed physical-div source unit验证原transport+K源total-DD位串、exact original joint=min(acoustic,.95*alpha/mass/species/volume bounds)，joint下两分数非负；超过source bound 1%必须拒绝。合成unit只隔离source数学，真实同组KT/physicalphi集成由25×100最终锚点验证。

14. **R1 old184/lower130** — 314个原capture逐文件SHA/P2/Q bits校验；current frozen EOS下old K0 vs final NONZERO_K_PE_v1全部native PASS，p/TG/TL/cL位级相同。另代表pure/mixed/trace通过，R1残差/J/math来源完全不改。第一次输入合并CSV的CRLF尾字节导致Q_BITS发生在读入、未进R1；改为LF保留值/bit栏原样后全通过，失败日志保留。

15. **Exact contact** — TL300和265各100 periodic controls fresh raw/post native 100/100，p/U/rho/P2/species保持原预算。TL300 raw/post strict100/100；TL265两者78/100，22个cell为native接受但strict sign不通过，共44 raw/post tolerance-only。该端点rounding区别单列，不宣称Tmin contact strict资格或新模型回归FAIL。具体p/U/rho/source误差见contacts.csv。

16. **Compression** — TL300/265×kappa .001/.01/.1/1的8项fresh raw/post native+strict全部PASS。K/response、alpha/rho/p/T及native endpoint marginDot符号/有限性已记录；actual new-wave conservative方向独立Decimal90 gradient max error4.7191725502742466e-14 <冻结1e-8。ideal uniform与FV direction有原数值截断差异，分开报告；无Et source。参考在native合法p/T节点求EOS导数，不重置Q或对rounded density强行反演至T<265。

17. **Expansion** — 8项完整fresh，所有响应/rate/endpoint-margin符号按物理方向反转；TL300四项native+strict PASS；TL265四项因cooling越过HARD下界按设计明确拒绝。expected domain exit是operating-set控制PASS，不扩展EOS或伪造root。native finite-step marginDot是离散端点差商，只检查符号，不冒充超越binary端点分辨率的精确连续导数。

18. **Final path/source identity** — 最终代码25×100 K/full-response legs与committed source identity scaled max error6.9388939039072284e-18；另60 equal-U/compression/expansion/mixed/pure/trace/coherent-offset controls及normal reversal通过冻结path rel1e-10/abs1e-14。coherent fluid+interface-frame shifts仅read-only wave/path helper检查，runtime meshPhi!=0仍拒绝，未启用或qualify ALE。

19. **Path guards** — final endpoint/17-node guard执行；JANAF branch crossing显式PATH_THERMO_BRANCH_OR_DOMAIN_BLOCKER；invalid energy与HARD density明确拒绝；same-pure、opposite-pure、absent-one-endpoint inheritance及trace守卫通过。中段P2插值、继承坐标只用于路径，不改committed质量。17-node检查不是连续EOS全域/phase稳定性新证明。

20. **Final 25-anchor** — healthy230+全部24micro，最终source、strategy0、新K/cPE/同组KT物理phi、fresh source/acoustic caps：每个100单元raw/post native+strict PASS。全部由final wclean/wmake后的fresh native tester再次生成；未复用MC4 development结果。

21. **Strict/native statistics** — 锚点raw2500/2500 native+strict；post2500/2500 native+strict；合计5000/5000 native、5000/5000 strict、0 tolerance-only。24旧micro原committed tolerance-only基线事实不变，不做state reset。contact Tmin与expected TL265 expansion另列，不能混入锚点PASS统计。

22. **New freshCap** — 最终重新计算范围[1.2053951913444919e-06, 1.2054427043871449e-06] s，24/24 macro。数值接近development是重新计算结果，非复用。逐anchor旧/新acoustic、selected dt、final source cap在anchors.csv；用TD2逐anchor权威time snapshots验证actual time+dt>time，不依赖停止时未flush完整的最后TD1 ledger。

23. **Conservative audit** — 最终22500 Q1..Q9与同一实际new model faces的原explicitTrial位串比较，mismatch=0；Et/mG/mL/M/species flux equations SHA不变，K仅影响fraction。没有conservative repair。

24. **P2/species** — 最终2500 P2 payload/一次total-DD/Q0 authority mismatch=0；5000 raw/post mass/species/presence/finite检查通过，原N-1 dependent closure不改。signed zero、signed switch、trace与expected overshoot rejection均PASS。

25. **Local Galilean** — -3000、+300、+10000 m/s的local thermo K/cPE/Ktheta控制fresh通过；max relative thermo error1.8873791418627661e-14在原5e-14+3e-20代数预算内。theta为相同物理source参数；coherent frame path独立检查，不宣称fixed-grid discontinuous path任意frame不变、高Mach或ALE资格。

26. **Path/RH ledger** — fresh smooth local compression、material contact、discontinuous two-state三行输出conservative RH1..9、IK、IaK及-s[a]+[au]-IaK。+x/unit-area/fixed-mesh/path定义及orientation逆转另有metadata。contact alpha residual1.0842021724855044e-19；其他任意两态jump residual非零如实保留，不声称它们是RH shock解、entropy或shock convergence PASS。此gate只验证ledger实现合同。

27. **Restart/model tag** — NONZERO_K_PE_v1 restart-v2 write/read exact tag与P2/Q bits PASS；K0-v1 under new expected REJECT；new-v2 under K0 expected REJECT。production restart仍NOT CERTIFIED。默认HISTORICAL_K0/显式nonzero分支维持，禁止高阶new模型策略。

28. **Executable/library SHA** — final executable 43facf56b8137bf658bb7c960718d186665160a3eb028b6f913204f3dfef2cd3；LiquidEOS 1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888；FiveEqThermo f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896。main fresh wclean/wmake0 errors，3条既有TD1 warning逐字相同，unexpected0；5组tester最终clean builds0 errors/0 warnings。

29. **Source SHA** — 111-source manifest SHA 8c663c6566205fe4e7eb3e9b0c0a0e661173b212c27e9cac07a1fab8b9feab4b；本轮仅1header delta；source_final.json逐文件哈希及完整patch封存。MC4原授权实施delta保持；MC4A再没有动R1/source/cfl/P2/temporal方程。

30. **EOS hashes** — v3 potential/coefficients/energy_reference/metadata与MC4A_PRE逐文件SHA相同，HARD p0.05–12MPa/T265–400K和CL369229.9537234281冻结。下方列出SHA。

31. **TD1 hashes** — fiveEqTemporalContract.H d415b10f2b1eb67e77e1c0062950b2afeaf7033ca9491592edc1d0ec0af1fba1；fiveEqTemporalPolicy.H a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062；与MC4A_PRE相同。growth/representable-time/rollback/connected-rescue数学未改；新模型仍需下一轮fresh TD1动态qualification。

32. **Foundation hashes** — 6717 Foundation +19 native-parcel hash check全OK，115 library hashes逐项不变；prior evidence和旧MC4 IMPLEMENTED/STOP ZIP SHA/CRC preserved。

33. **MC4 COMPLETE?** — YES，仅NONZERO-K SERIAL MODEL IMPLEMENTED / MICRO-QUALIFIED / NOT DYNAMICALLY QUALIFIED；34门全部PASS。MC4A representation bug closure COMPLETE。

34. **MC5 authorized?** — NEXT ROUND ONLY。MC4 prerequisites已满足，本轮未执行MC5，不把后续阶段自动授权扩大到当前请求。

35. **TD1 status** — PARTIAL；未重跑TD1 qualification或长shock/endTime。

36. **DYN-CLOSURE** — NOT AUTHORIZED。

37. **M6B.1/M6B** — 均PARTIAL；没有dynamic/shock convergence/ALE/high-Mach/DPM/production资格。

38. **Milestone matrix** — MC2 COMPLETE/M1；MC3 COMPLETE/DESIGN FROZEN；MC4A COMPLETE/REPRESENTATION GUARD CLOSED；MC4 COMPLETE/MICRO-QUALIFIED；MC5 NEXT ROUND ONLY/NOT EXECUTED；EOS3 COMPLETE/DOMAIN FROZEN；TD1/M6B.1/M6B PARTIAL；DYN-CLOSURE NOT AUTHORIZED。STOP。

Frozen model SHA: be2e3d414dcfffd7a9ae498fa14f4a4f8de934b60c5c87f78a696bdf041b5270

Frozen MC3 budget SHA: c6377d653599a24903440b119a8d5e9ea0541ea88db96d0bc40ad8803309d12b

EOS hashes:

- `GibbsPotentialLiquidEOSV3.H`: `421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d`
- `coefficients.json`: `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`
- `energy_reference.json`: `ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`
- `metadata.json`: `9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`

MC4A_PRE SHA: dd1a32d12cca14ea6d98fd8034e62c1d42fde1c981b3da1bfbe25740c406d1e9

MC4_VALIDATED archive SHA/CRC/per-file hashes are written in seal_validated.json after sealing this report.
