#include "fiveEqSpeciesMap.H"
#include <cmath>
#include <algorithm>
namespace fiveEq {
fiveEqSpeciesMap::fiveEqSpeciesMap(const Foam::wordList& names,const Foam::dictionary& data,const fiveEqGasThermoEvaluator& evaluator){
    const auto expected=fiveEqGasThermoEvaluator::speciesNames();
    if(names.size()!=static_cast<Foam::label>(expected.size()))throw RecoveryError("SPECIES_MAP_UNSUPPORTED_MECHANISM_SIZE");
    for(unsigned i=0;i<expected.size();++i){
        unsigned found=0,index=0;
        for(Foam::label j=0;j<names.size();++j)if(names[j]==expected[i]){++found;index=j;}
        if(found!=1)throw RecoveryError("SPECIES_MAP_REQUIRED_NAME_MISSING_OR_DUPLICATE");
        if(!data.found(expected[i]))throw RecoveryError("SPECIES_MAP_JANAF_DATA_MISSING");
        const auto& d=data.subDict(expected[i]);
        if(!d.found("specie")||!d.found("thermodynamics"))throw RecoveryError("SPECIES_MAP_JANAF_METADATA_MISSING");
        const auto& sp=d.subDict("specie");const auto& th=d.subDict("thermodynamics");
        if(!sp.found("molWeight"))throw RecoveryError("SPECIES_MAP_MOLECULAR_WEIGHT_MISSING");
        for(const char* key:{"Tlow","Thigh","Tcommon","lowCpCoeffs","highCpCoeffs"})if(!th.found(key))throw RecoveryError("SPECIES_MAP_JANAF_METADATA_MISSING");
        const GasThermo actual(d);const auto& reference=evaluator.speciesData()[i];
        auto same=[](double a,double b){return std::isfinite(a)&&std::isfinite(b)&&std::abs(a-b)<=1e-12*std::max(1.,std::max(std::abs(a),std::abs(b)));};
        if(!same(actual.W(),reference.W()))throw RecoveryError("SPECIES_MAP_MOLECULAR_WEIGHT_MISMATCH");
        if(!same(actual.Tlow(),reference.Tlow())||!same(actual.Thigh(),reference.Thigh())||!same(actual.Tcommon(),reference.Tcommon()))throw RecoveryError("SPECIES_MAP_JANAF_RANGE_MISMATCH");
        for(unsigned j=0;j<7;++j)if(!same(actual.lowCpCoeffs()[j],reference.lowCpCoeffs()[j])||!same(actual.highCpCoeffs()[j],reference.highCpCoeffs()[j]))throw RecoveryError("SPECIES_MAP_JANAF_COEFFICIENT_MISMATCH");
        canonicalToRuntime_.push_back(index);
    }
}
bool fiveEqSpeciesMap::map(const Foam::scalarField& Y,std::vector<double>& canonical) const {
    if(Y.size()!=static_cast<Foam::label>(canonicalToRuntime_.size()))return false;
    canonical.resize(canonicalToRuntime_.size());double sum=0;
    for(unsigned i=0;i<canonical.size();++i){double y=Y[canonicalToRuntime_[i]];if(!std::isfinite(y)||y<0)return false;canonical[i]=y;sum+=y;}
    // Same explicit M6A2.1 budget. Accept tiny sum discrepancy as-is; no normalization.
    return std::isfinite(sum)&&std::abs(sum-1)<=1e-12;
}
}
