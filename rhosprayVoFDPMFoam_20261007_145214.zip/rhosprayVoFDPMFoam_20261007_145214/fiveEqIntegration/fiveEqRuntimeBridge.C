#include "fiveEqRuntimeBridge.H"
#include <cmath>
#include <cstring>
namespace fiveEq {
fiveEqRuntimeBridge::fiveEqRuntimeBridge(const std::string& path,const Foam::wordList& names,const Foam::dictionary& metadata):
    gas_(path),liquid_(),speciesMap_(names,metadata,gas_),recovery_(gas_,liquid_){}
const char* recoveryCodeName(RecoveryCode code){
    switch(code){
#define CODE(x) case RecoveryCode::x:return #x
    CODE(OK);CODE(INVALID_ALPHA);CODE(NEGATIVE_PARTIAL_MASS);CODE(INVALID_TOTAL_DENSITY);
    CODE(PHASE_PRESENCE_INCONSISTENT);CODE(GAS_EOS_INVALID);CODE(LIQUID_EOS_INVALID);
    CODE(NO_COMMON_PRESSURE_INTERVAL);CODE(NO_PRESSURE_ROOT);CODE(NONPOSITIVE_ROOT_DERIVATIVE);
    CODE(ROOT_NOT_CONVERGED);CODE(INVALID_SOUND_SPEED);CODE(NONFINITE_STATE);
    CODE(INTERNAL_PROGRAM_ERROR);CODE(INVALID_COMPOSITION);CODE(INVALID_DIMENSIONS);CODE(PHASE_PRECISION_UNRESOLVED);
#undef CODE
    }return "INTERNAL_PROGRAM_ERROR";
}
std::string formatDiagnostic(const fiveEqRecoveryDiagnostic& d){
    std::ostringstream out;out.precision(17);out<<recoveryCodeName(d.code)<<" alphaL="<<d.alphaL<<" mG="<<d.mG<<" mL="<<d.mL<<" rhoMix="<<d.rhoMix
      <<" bracketAvailable="<<d.bracketAvailable<<" bracket=["<<d.pBracketMin<<','<<d.pBracketMax<<"] p="<<d.finalPressure<<" residual="<<d.residual<<" iterations="<<d.iterations<<" fallback="<<d.fallbackCount;
    return out.str();
}
static RecoveryCode classify(const char* reason,bool liquid){
    if(std::strstr(reason,"SUBNORMAL_PRECISION_UNRESOLVED"))return RecoveryCode::PHASE_PRECISION_UNRESOLVED;
    if(std::strstr(reason,"NO_COMMON_VALID_PRESSURE_INTERVAL"))return RecoveryCode::NO_COMMON_PRESSURE_INTERVAL;
    if(std::strstr(reason,"NO_PHYSICAL_ENERGY_ROOT")||std::strstr(reason,"NO_GAS_ENERGY_ROOT")||std::strstr(reason,"energy not bracketed"))return RecoveryCode::NO_PRESSURE_ROOT;
    if(std::strstr(reason,"INVALID_THERMODYNAMIC_ROOT_DERIVATIVE"))return RecoveryCode::NONPOSITIVE_ROOT_DERIVATIVE;
    if(std::strstr(reason,"NOT_CONVERGED")||std::strstr(reason,"iterations"))return RecoveryCode::ROOT_NOT_CONVERGED;
    if(std::strstr(reason,"RECOVERED_STATE_VALIDATION_FAILED"))return RecoveryCode::ROOT_NOT_CONVERGED;
    if(std::strstr(reason,"INVALID_ALLAIRE_ACOUSTICS"))return RecoveryCode::INVALID_SOUND_SPEED;
    if(std::strstr(reason,"ABSENT_PHASE")||std::strstr(reason,"PRESENT_PHASE")||std::strstr(reason,"DISAPPEARING_PHASE"))return RecoveryCode::PHASE_PRESENCE_INCONSISTENT;
    if(std::strstr(reason,"INVALID_TOTAL_DENSITY"))return RecoveryCode::INVALID_TOTAL_DENSITY;
    if(std::strstr(reason,"INVALID_INTERNAL_ENERGY"))return RecoveryCode::NONFINITE_STATE;
    if(std::strstr(reason,"INVALID_GAS_COMPOSITION"))return RecoveryCode::INVALID_COMPOSITION;
    if(liquid||std::strstr(reason,"LIQUID_PRESSURE_INTERVAL")||std::strstr(reason,"INVALID_LIQUID"))return RecoveryCode::LIQUID_EOS_INVALID;
    if(std::strstr(reason,"INVALID_GAS"))return RecoveryCode::GAS_EOS_INVALID;
    return RecoveryCode::INTERNAL_PROGRAM_ERROR;
}
bool fiveEqRuntimeBridge::tryRecover(const fiveEqRuntimeInput& q,fiveEqRuntimeState& out,fiveEqRecoveryDiagnostic& d,PressureGuess guess,RecoveryContext context) const {
    out=fiveEqRuntimeState();d=fiveEqRecoveryDiagnostic();d.context=context;d.alphaL=q.alphaL.value();d.mG=q.mG.value();d.mL=q.mL.value();d.rhoMix=d.mG+d.mL;d.guessProvided=guess.supplied;
    auto fail=[&](RecoveryCode code){d.code=code;d.status=code==RecoveryCode::INTERNAL_PROGRAM_ERROR?RecoveryStatus::INTERNAL_FAILURE:code==RecoveryCode::INVALID_DIMENSIONS?RecoveryStatus::CONFIGURATION_FAILURE:RecoveryStatus::STATE_FAILURE;return false;};
    if(q.alphaL.dimensions()!=Foam::dimensionSet(0,0,0,0,0,0,0)||q.mG.dimensions()!=Foam::dimensionSet(1,-3,0,0,0,0,0)||q.mL.dimensions()!=Foam::dimensionSet(1,-3,0,0,0,0,0)||q.M.dimensions()!=Foam::dimensionSet(1,-2,-1,0,0,0,0)||q.Et.dimensions()!=Foam::dimensionSet(1,-1,-2,0,0,0,0))return fail(RecoveryCode::INVALID_DIMENSIONS);
    if(!std::isfinite(d.alphaL)||!std::isfinite(d.mG)||!std::isfinite(d.mL)||!std::isfinite(q.Et.value())||!std::isfinite(d.rhoMix))return fail(RecoveryCode::NONFINITE_STATE);
    for(unsigned j=0;j<3;++j)if(!std::isfinite(q.M.value()[j]))return fail(RecoveryCode::NONFINITE_STATE);
    if(d.alphaL<0||d.alphaL>1)return fail(RecoveryCode::INVALID_ALPHA);
    if(d.mG<0||d.mL<0)return fail(RecoveryCode::NEGATIVE_PARTIAL_MASS);
    if(d.rhoMix<=0)return fail(RecoveryCode::INVALID_TOTAL_DENSITY);
    fiveEqConservativeState state;state.alphaL=d.alphaL;state.mG=d.mG;state.mL=d.mL;state.Et=q.Et.value();
    for(unsigned j=0;j<3;++j)state.M[j]=q.M.value()[j];
    // Exact pure-liquid routing must never inspect undefined/absent gas composition.
    if(!(state.alphaL==1&&state.mG==0)&&!speciesMap_.map(q.YG,state.YG))return fail(RecoveryCode::INVALID_COMPOSITION);
    RecoveryOptions options;
    if(guess.supplied){options.initialGuess=InitialGuess::PROVIDED;options.knownPressure=guess.value;}
    fiveEqRecoveredState progress;RecoveryCode code=RecoveryCode::OK;
    try{out.thermo=recovery_.recover(state,options,&progress);}
    catch(const liquidEOS::EOSQueryError& e){code=classify(e.what(),true);}
    catch(const RecoveryError& e){code=classify(e.what(),false);}
    catch(const std::exception&){code=RecoveryCode::INTERNAL_PROGRAM_ERROR;}
    catch(...){code=RecoveryCode::INTERNAL_PROGRAM_ERROR;}
    d.recoveryMode=progress.recoveryMode;d.pBracketMin=progress.bracketMin;d.pBracketMax=progress.bracketMax;d.finalPressure=progress.p;d.residual=progress.energyResidual;d.iterations=progress.iterations;d.fallbackCount=progress.calls.fallback;
    d.bracketAvailable=progress.bracketMin>0&&progress.bracketMax>0;
    d.pressureAvailable=progress.p>0&&std::isfinite(progress.p);d.residualAvailable=progress.calls.residual>0||code==RecoveryCode::OK;
    d.gasValidity=progress.gasValidity=="VALID_JANAF"?PhaseValidity::VALID:(state.alphaL==1&&state.mG==0)?PhaseValidity::ABSENT:PhaseValidity::NOT_EVALUATED;
    d.liquidValidity=progress.liquidValidity=="NORMAL"?PhaseValidity::NORMAL:progress.liquidValidity=="BUFFER"?PhaseValidity::BUFFER:(state.alphaL==0&&state.mL==0)?PhaseValidity::ABSENT:PhaseValidity::NOT_EVALUATED;
    if(code==RecoveryCode::GAS_EOS_INVALID)d.gasValidity=PhaseValidity::INVALID;
    if(code==RecoveryCode::LIQUID_EOS_INVALID)d.liquidValidity=PhaseValidity::INVALID;
    d.guessIgnored=guess.supplied&&(!std::isfinite(guess.value)||!d.bracketAvailable||guess.value<=d.pBracketMin||guess.value>=d.pBracketMax||d.recoveryMode!=RecoveryMode::MIXED);
    if(code!=RecoveryCode::OK){out=fiveEqRuntimeState();return fail(code);}
    out.U=Foam::vector(out.thermo.U[0],out.thermo.U[1],out.thermo.U[2]);d.status=RecoveryStatus::SUCCESS;d.code=RecoveryCode::OK;return true;
}
fiveEqRuntimeState fiveEqRuntimeBridge::recoverOrFail(const fiveEqRuntimeInput& q,PressureGuess guess) const {
    fiveEqRuntimeState state;fiveEqRecoveryDiagnostic diagnostic;
    if(!tryRecover(q,state,diagnostic,guess))throw RecoveryError(formatDiagnostic(diagnostic));
    return state; // Caller may choose controlled fatal; bridge never invokes it.
}
}
