# FULL_TRACKING_QUERY_GRAPH — Foundation OF7 source audit

2026-10-03. Static caller graph of the actual selected `basicSprayCloud` / `basicSprayParcel` family. Not a certificate of new full-chain execution.

```text
ThermoCloud construction: acquire mu field, T/p references
SprayCloud.evolve()
  -> parcelType::trackingData td(*this)                 [EARLY BLOCKER]
     -> particle trackingData
     -> Kinematic trackingData
        rho/U/mu interpolation::New; U/cellPoint may build point values
     -> Thermo trackingData
        global thermo.Cp() -> global thermo.kappa() -> global Cp() again
        T/Cp/kappa interpolation::New; optional radiation G
     -> Reacting trackingData: p interpolation::New
     -> Spray trackingData: alias; no extra deferred layer
  -> KinematicCloud.solve
     -> preEvolve / cache fields / functions
     -> evolveCloud
        -> resetSourceTerms when coupled
        -> surfaceFilm.inject
        -> injectors.inject
           geometry/RNG -> new parcel -> setParcelThermoProperties
           -> setProperties -> checkParcelProperties -> parcel.move
        -> motion -> Cloud.move -> each parcel.move
           -> KinematicParcel.move: trackToFace
              -> Spray.setCellValues -> Reacting -> Thermo -> Kinematic
              -> calcDispersion
              -> optional cellValueSourceCorrection
              -> Spray.calc -> Reacting.calc -> surface and heat/mass/force paths
              -> age/functions.postFace/postMove -> hitFace/hitPatch
                 -> functions.postPatch / surfaceFilm / native wall rebound
              -> next segment: fresh setCellValues, then corrections/models
           -> KH child creation and immediate force/dispersion
        -> native stochasticCollision.update (ORourke)
     -> postEvolve/output according to native solve path
```

Native evolution constructs TD before `solve`: [SprayCloud.C:222](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/spray/clouds/Templates/SprayCloud/SprayCloud.C:222). Owned const thermal fields: [ThermoParcel.H:159](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcel.H:159); eager initialization: [ThermoParcelTrackingDataI.H:35](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcelTrackingDataI.H:35); Spray alias: [SprayParcel.H:131](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/spray/parcels/Templates/SprayParcel/SprayParcel.H:131). Full Cp traversal: [heThermo.C:315](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/thermophysicalModels/basic/heThermo/heThermo.C:315); kappa repeats Cp: [heThermo.C:730](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/thermophysicalModels/basic/heThermo/heThermo.C:730). Parcel update entry is later: [KinematicParcel.C:338](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/KinematicParcel/KinematicParcel.C:338).

## First possible acquisition/evaluation

| Property/helper | First native location | Important distinction |
|---|---|---|
| mu | ThermoCloud constructor acquires thermo.mu; Kinematic TD acquires mu interpolation | field getter/acquisition does not itself prove a new EOS evaluation; carrier values still require validity |
| rho | Kinematic TD creates rho interpolation; Kinematic.setCellValues reads rho | scalar `cell` factory stores references, other schemes may evaluate sooner |
| U | Kinematic TD creates U interpolation | native cellPoint creates point values before individual parcel setCellValues |
| Cp | Thermo TD constructor calls full heThermo.Cp | evaluates every internal cell and stored boundary value, including unrelated absent cells |
| kappa | Thermo TD constructor calls full heThermo.kappa | invokes full Cp again and multiplies by alpha field |
| T | cloud caches T reference; full Cp evaluates T before TInterp materialization | setCellValues later interpolates Tc |
| Y | full Cp invokes cellMixture using native Y fields | conditional surface correction also reads per-cell carrier Y |
| p | cloud caches p; full Cp uses p first; Reacting TD builds pInterp later | isobaric common p is different from requiring gas thermo everywhere |
| surface Ts/rhos/mus/kappas/Pr | Thermo.calcSurfaceValues | carrier-dependent; disabled heat transfer does not automatically eliminate this helper |
| liquid Cp/rho/mu/sigma/pv | Spray.calc uses parcel T/Y and td.pc | property is liquid-internal; obtaining its carrier-derived p input belongs behind a gate |
| source correction | after setCellValues and dispersion | uses rho/U/T/Cp and accumulated mass/momentum/heat; callable ordering exists but needs a safe TD first |

Surface rule: [ThermoParcel.C:106](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcel.C:106). Source Cp bypass via `.psi()[cell]`: [ReactingParcel.C:268](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ReactingParcel/ReactingParcel.C:268). Conditional Bird/composition path: [ReactingParcel.C:314](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ReactingParcel/ReactingParcel.C:314). Birth thermo initialization: [InjectionModel.C:477](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/submodels/Kinematic/InjectionModel/InjectionModel/InjectionModel.C:477). KH immediate child force reuses parent TD: [SprayParcel.C:295](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/spray/parcels/Templates/SprayParcel/SprayParcel.C:295).

## Consequences for entry/token design

Birth initialization has an additional direct field path: `ThermoCloud::setParcelThermoProperties` sets parcel-local T0/Cp0; ReactingCloud assigns parcel-local YMixture0; `SprayCloud::setParcelThermoProperties` then reads `this->p()[parcel.cell()]` and evaluates liquid Cp/rho/sigma/mu at that pressure and parcel T/Y. `checkParcelProperties` initializes diameter/breakup/core state. Therefore a guard only in `setCellValues` also misses born-property initialization. A future bridge must distinguish the physically defined common-pressure lookup from gas T/Y/Cp requirements, keeping liquid-only helpers out of an unnecessary gas gate.

Error classification required by the request remains a bridge contract, not newly implemented native exceptions: gas authority/support failure → GAS_SUPPORT_INVALID; changed generation → STALE_GENERATION; malformed/current-native-tet stencil → INVALID_STENCIL; certified-phase EOS failure → THERMO_DOMAIN_INVALID; native model failure → MODEL_EVENT_FAILURE. Preserve original reason evidence and do not collapse these into a generic tracking failure. Existing R2A exceptions/codec are untouched.

One accessor guard is insufficient. A future local bridge needs a non-materialized TD owned by the cloud entry, a requirement-aware gate before each carrier-dependent segment/helper and before born/child carrier initialization. `cloud.evolve` cannot require all cells gas-valid: valid parcel support with absent cells elsewhere is a required legal case.

Native interpolation in setCellValues uses `coordinates()` and `currentTetIndices()`. The frozen R2A point API uses physical position/cell/face. Their complete-chain equivalence has NOT been proved. A bridge token must include native cell/tet/barycentric/stencil provenance plus generation and requirements; do not substitute the earlier centre-only oracle or reuse a trajectory-wide true flag.

PostMove/postPatch functions and injection bookkeeping can mutate before the next invalid query. They must remain trial-local and rejected outputs must not commit. The current frozen codec/output transactions are references, not a new full-chain acceptance result.
