# M6B1-CRV3-2-VANISHING-VISCOSITY REPORT v1

2026-10-06。**BLOCKER_STOP / PRESENT_SUBNORMAL_PRECISION_UNRESOLVED**。黏性趋零未通过，M6B.1 保持 PARTIAL。按本轮用户规定的硬数学/相存在门停止后续资格测试。

## 主线与已完成工作

新 `NONZERO_K_PE_CRV3_v1` 已接入 project-local serial solver，旧模型仍可选。CRV3-1 基础范围已完成 fresh executable、动量应力/一致能量功、离散非负加热、P2/物种、联合时间步与基础回归。完整数据及范围见 `M6B1-CRV3-1-ACTIVE-INTEGRATION-AND-JOINT-DT_REPORT_v1.md`；该结果不能替代本轮更细原始激波资格。

CRV3-1 封存 ZIP SHA256 `caf1a3247a4b5e61e045903dabea0d956b99a0777175abf554e9a576a29a3733`，480 entries，CRC及逐项SHA256通过。旧 MC5/TD1、SP1、SP2 档案保持历史状态；旧 three-leg 仅作诊断。

## 两参数计划及执行状态

原始 shockInterface_100，endTime=0.00055，A序列 (N,mu)=(100,3),(200,1.5),(400,.75),(800,.375)；B序列 (100,3),(300,1.5),(900,.75),(2700,.375)。B的 dx/mu 每级减少2/3，以区别固定分辨率比例的A序列。

弱 shock ratio1.01：mu=.6/.3/.15/.075，A N128/256/512/1024；B N128/384/1152/3456。中等 shock ratio1.25 已计划同类阶梯，尚未运行。

原始初值由原100格精确保守/P2 cell states 按整数倍复制、重新写体积/索引/校验；仅作 fresh fixture，未强制恢复为原 EOS1。实际计算始终使用 EOS v3，没有状态修复。

完成原始前三层与6项弱激波。弱B N3456在独立硬阻塞确认后停止，未完成，不计PASS。原始B与中等阶梯未运行。

## 原始激波的已完成结果

|case|steps|max conservation|total viscous heating|entropy production trapezoid integral|final strict/native|
|---|---:|---:|---:|---:|---:|
|original_A_N100_mu3|431|1.161e-15|50.891434|0.06331475|100/100|
|original_A_N200_mu1.5|910|2.759e-15|36.625468|0.045611514|200/200|
|original_A_N400_mu0.75|1826|5.69e-15|26.073258|0.032520001|400/400|

各级均到达endTime，无accepted recovery failure。Et全局守恒与上述正黏性加热同时成立，因为一致能量功重新分配动能/内能，未给Et经验修正。entropy列是沿实际accepted黏性子步的正热力学权重梯形积分，未伪称精确全 PDE entropy balance。

液体温度已完成场约299.9857–300.2157K，所有相内禀状态由原生EOS守卫恢复。原始result中的 maxPressureRelative是相对于3MPa基态的真实波动幅度，不是工程误差；不能把正常激波压升当作>5%失败。

## 弱激波宏观观测

平台窗：post x=.18–.21，pre x=.59–.62；比较窗为中心±.12。速度由相对于参考行波的压力梯度质心位移估计，RH以同一平台/速度计算。所有Q先逆Galilean变换到lab再比较。P2检查在实际算子，species在导出的原始保守位串再次独立复核。

|case|speed error|pressure jump error|L1 against inviscid selected step/jump|total viscous heating|
|---|---:|---:|---:|---:|
|weak_A_N1024_mu0.075|0.0064829%|5.71905e-07%|0.313916%|0.05218817|
|weak_A_N128_mu0.6|0.0068541%|7.17774e-05%|2.04174%|0.075693075|
|weak_A_N256_mu0.3|0.00689514%|2.34178e-06%|1.18377%|0.069858723|
|weak_A_N512_mu0.15|0.00679474%|5.9e-06%|0.551495%|0.061925123|
|weak_B_N1152_mu0.15|0.00333471%|1.21048e-06%|0.529734%|0.082585513|
|weak_B_N384_mu0.3|0.00483789%|3.42504e-05%|1.08983%|0.086863543|

六项速度、压力/速度/alpha/密度跳跃、主要平台与阶跃L1工程量均<5%；守恒与物种硬门通过。全部黏性加热和局部熵生产积分非负。

四级A的阶跃误差下降，但黏性加热积分仍有分辨率/初始反向波过渡贡献，B的最细级未完成；不能据此宣布完整观测序列、唯一极限或vanishing viscosity PASS。宏观RH残差是有限时间平台测量，不替代全局硬守恒。

## 硬阻塞的精确证据

原始 A N800、mu=.375 在第208个完整accepted step后停止：

- tOld = 3.1332395491886647e-05；tBits=`3f006d5ce95af15f`。
- 最后accepted dt及joint cap = 1.5063651678791615e-07。
- 原生TD1 proposal的首个失败cell为311；该锚点液相 ABSENT（alphaL=0,mL=0）。
- 最大合法候选产生 alphaL=9.4155358720636813e-309，mL=6.849171134535951e-306。alphaL低于binary64 min normal=2.2250738585072014e-308；原生presence guard拒绝 `PRESENT_PHASE_SUBNORMAL_PRECISION_UNRESOLVED`。
- 该cell fraction numerator =7.8131253238216982e-305，phase mass numerator=5.6835248854192339e-302；形成normal alpha所需 dt=3.5598332394001347e-07，约2.36倍当前joint cap。
- time ULP=6.7762635780344027e-21。原TD1 connected/retry/rescue失败；独立79次全锚点预黏性/双曲候选探测未找到同时合法且可推进时间的候选。很小救援候选还触及cell208的subnormal trace。
- 完整锚点800个cell均通过原生恢复。黏性子步alpha、mG/mL、species固定分量变化次数=0；完整锚点到pre-viscous锚点同样为0。

因此当前阻塞来自双曲alpha/相质量输运的极微trace尾部与原normal-precision PRESENT合同的冲突。CRV3黏性项没有扩散相质量或alpha，未出现能量功不一致或负加热；不能把此处直接归因为黏性熵失败、EOS系数错误或旧endpoint路径差异。

本轮不接受通过删trace、将alpha/mass置零、关闭presence guard或放宽EOS来推进。相状态尚未被错误提交；时间仍在step208。需要单独处理相界面输运/精度合同并验证其物理、守恒、P2及物种一致性，随后才能重启黏性趋零资格。

失败日志、full anchor、pre-viscous anchor、raw candidate、exact hex payload、TD1 candidate ledger及独立probe保存于 `diagnosis/`。第一次失败与首轮缺积分账本的实验保存为历史证据，不计完整资格。

## 源与运行身份

stage1 executable保留不覆盖；stage2独立 executable加accepted-step加热/熵积分账本，并用经过整个coupled candidate重新验证的nested TD1 dt仅作retry guidance，未修改原 TD1 policy/contract。

完整journal仅为诊断开关 `CRV3fullJournal true`，其默认值false。instrumented源码由编译前SHA256精确复原并验证于 `source_instrumented/`，diagnostic当前源于 `source_after.json`；不会用当前源哈希冒充另一版本binary身份。各binary SHA256见instrumented_executables.sha256及runtime_after.sha256。

原111项仅6项授权project-local源码变化；EOS v3/header/81coeff/C_L、原model文档、原TD1及历史预算未改变。当前新增2个CRV3 helper及新模型文档。没有clipping、物种normalize、phase deletion、EOS更改或energy repair。

## 最新里程碑

|milestone|status|
|---|---|
|历史MC5 / TD1|COMPLETE preserved|
|CRV3-1基础串行集成/联合dt|PASS / scoped COMPLETE；保持已通过证据|
|CRV3-2|BLOCKER_STOP / PRESENT subnormal precision|
|CRV3-3～6|未进入完整资格|
|M6B.1 / M6B|PARTIAL，不能关闭|
|2D / surface tension / DPM / MPI / production restart|未进入|

工程5%政策不放宽相存在、P2、守恒和EOS硬门。后续资格测试已经停止；诊断与报告封存已完成。
