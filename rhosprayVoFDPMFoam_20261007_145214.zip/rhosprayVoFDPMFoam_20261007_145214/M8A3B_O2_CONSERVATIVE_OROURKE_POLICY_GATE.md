# M8A.3B-O2 Conservative ORourke policy design gate

日期：2026-10-02。范围：设计、Foundation OF7 本机源码审计、离线原生 harness。
版本：`OF7-ORourke-conservative-v1`。运行证据：`fitting/dpm/m8a3b_o2_v1/`。
本报告冻结所选项目策略的语义；不是完整 T3B、生产激活或 CFD 物理验证结论。

## 1. O2 status

**COMPLETE / DESIGN + OFFLINE-NATIVE HARNESS ONLY**。
采用 B：同一 coalescence 事件的 conservative internal merge，配合明确的绝热、内部液滴热化闭合。
原生模型本身仍具有守恒缺陷；所选策略是项目新模型扩展，不宣称 native ORourke 已被证明守恒。
本机 OF7 wmake 通过；A/B/C 27,420 项断言无失败；独立账本 2,697 项检查通过。

## 2. Native truncation baseline

O1 原始证据、调用链、lineage、fixture、账本和 checkpoint 全部保留。
普通 cloud.evolve 到 coalescence 后的正质量清理确实可达：

| O1 | 消失的 represented mass/kg | native carrier mass transfer |
|---|---:|---:|
| A | 2.39878e-16 | 0 |
| B | 8.06534e-16 | 0 |
| C | 2.28912e-16 | 0 |

本轮重新执行未修复的 terminal native event，仍检出缺陷，之后才执行独立 conservative trial。
另发现历史 O1 harness 新建 cloud 时 allocator 被清零，产生 A/B/C 5/6/11 个重复 ID。
原 O1 文件不修改；其质量截断结论不依赖按 ID 去重，仍成立，但整个历史 cloud 不能作为合法唯一身份状态直接接受。
本轮区分：①原字段、原 ID、原随机状态的**受影响事件精确重放**；②正确 TrialScope 下完整物理粒子群的守恒审计。
完整旧 cloud 的 byte-identical identity 重建标志为 false，绝不据此声称 true。

## 3. Native coalescence formulas

本机源根 `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src`；源码快照在 evidence/native_sources，保留真实相对路径。
`lagrangian/spray/submodels/StochasticCollision/ORourkeCollision/ORourkeCollision.C`：

| 行/函数 | 实际作用 |
|---|---|
| 40–121 collide | cell occupancy 两两处理；更新 rho/Cp/sigma/mu/d；114–116 按 represented mass 删除 |
| 124–180 collideParcels | 概率判断、随机数、按直径调用 collideSorted |
| 183–287 collideSorted | 合并与 grazing 两个分支 |
| 207 | mass-weighted Tave |
| 230–246 | dm、m1/m2、T1、U1、Y1、nParticle2 |

令初始 represented masses 为 a,b，native random draw 为 r，dm=r b，残余 s=b−dm：

```text
nu = min(np1,np2) * pi*(d1+d2)^2/4 * |U1-U2| * dt / Vcell
collision if xx > exp(-nu)
ratio=d1/d2; f=ratio^3+2.7*ratio-2.4*ratio^2
rhoAve=(a+b)/(a/rho1+b/rho2); dAve=sqrt(d1*d2)
We=0.5*rhoAve*|U1-U2|^2*dAve/sigmaAve
coalescenceProb=min(1,2.4*f/We)
coalescence if r < coalescenceProb and coalescence enabled
nProb=r*np2/np1; dm=np1*nProb*b/np2=r*b
m1=a+dm; m2=s
T1=((a*T1old+b*T2old)-s*T2old)/(a+dm)
U1=((a+dm)*U1old + (1-s/b)*s*U2old)/(a+dm)
Y1=(a*Y1old+dm*Y2old)/(a+dm)
np2=s/(rho2*pi*d2^3/6)
```

外层随后由 composition 实际液体物性更新 rho/Cp/sigma/mu，以及 d=cbrt(6m/(np*rho*pi))。
没有 carrier 或 external exchange 调用。sigma 用于 We 判据，没有可盘点的 surface-energy state。

## 4. Native multiplicity semantics

`KinematicParcelI.H::mass()` 是单滴质量 rho*pi*d^3/6。
represented mass 为 nParticle*mass()，species 为 m*Y_i；所有账本统一使用该定义。
native 清理比较的是 represented mass 与 minParcelMass，当前常量为 1e-15 kg；不是单滴 mass、直径或 np 的阈值。
合并不产生新粒子：native recipient np 保留，donor np 减小，recipient d 随总质量和新 rho 改变。

## 5. Native momentum semantics

源码注释以 conservation 为意图，但 U1 公式使用已增大的 m1 与剩余 m2。
清理前总动量偏差可解析化为 **dm*(U1old−r*U2old)**。
清理再独立丢掉 **s*U2old**。这两个缺陷应分别盘点。
grazing 的分组/np 加权也不能替代完整 represented momentum 证明。

## 6. Native energy semantics

native 合并温度是质量加权温度；非线性液体 caloric model 下不保证内能相加。
native 合并 U 不保证 P，故 KE 可增加或降低；grazing 对相对速度进行模型阻尼。
未发现把动能差写入液滴内能、carrier hsTrans、显式表面能或其他 reservoir 的调用。
因此 native modeled total energy 无闭合，不可仅凭 Tave 声称守恒。

## 7. Momentum offset classification

**D / TRUE NATIVE MOMENTUM NON-CONSERVATION**。
可由上述代数公式重现，不是 tiny-mass 浮点误差、np 误读或源码证明的 external impulse。
O1 cleanup 质量缺陷与 native U 公式缺陷分开记录。

## 8. Energy-loss classification

native grazing 的 resolved relative KE：DISSIPATED_BY_MODEL；其总能量去向：**UNACCOUNTED**。
native coalescence 同时存在错误动量造成的 KE 偏差及 caloric 混合误差，不能把每个 KE 变化都解释成物理耗散。
所选项目策略才明确采用 TRANSFERRED_TO_PARCEL_INTERNAL；不追溯声称 native 已实现热化。

## 9. Candidate A analysis

保留所有正 residual 自然保护 M/Y，但单独保留不能修复 native U/T。
需要同样的 P/E 闭合；孤立 tiny parcel 可长期存在，增加同格 O(N^2) 碰撞成本及 restart 条目。
不选为正常 coalescence cleanup 策略；无明确同事件 recipient 的既存正 orphan 仍必须保留，禁止随便合并。
该 fallback 未证明任意持续注入下粒子数有界。

## 10. Candidate B analysis

同事件明确 recipient 接收 residual 的 M/Y/P/E；donor 变为 exact zero 后仅记账删除。
需要正确 COM 速度、真实 caloric root、新 rho/d 与状态拒绝处理。
可避免该事件留下 tiny donor，不添加持久 reservoir。

| 比较维度 | A 保留 | B 同事件合并（选定） | C DPM reservoir | D carrier transfer |
|---|---|---|---|---|
| mass/species | 保留可闭合 | M/Y 闭合 | 需 reservoir 完整计量 | 无物理依据 |
| momentum | 仍需修 native U | 正确 represented COM | 需储存向量 P | 无 external impulse 依据 |
| total energy | 仍需 caloric 策略 | 内能+KE 闭合 | 需储存 E 与再生成规则 | 无 carrier heat 依据 |
| model fidelity | 留住物质，改变 cleanup | 改 cleanup/U/T，保留概率/几何 | 引入新种群状态 | 错把碰撞当蒸发 |
| parcel count | tiny 累积风险 | 同事件 donor 消除 | 可减少 parcel；reservoir 增长风险 | 减少但物理不成立 |
| deterministic retry | 状态更多 | stable ID/pair 顺序 | 需额外权威状态 | 需源账本但不合理 |
| restart complexity | 原 parcel 状态即可 | 无新 field；需模型版本 | 新 restart schema | 源参考映射 |
| MPI complexity | 既存 owner/IDs | cell owner+全局唯一 IDs | 分布式库存/迁移 | carrier exchange 汇总 |
| invasiveness | 小但 P/E 尚待修 | 局部 wrapper/factory | 大 | 越界改源模型 |
| future VOF-DPM | DPM 库存完整 | DPM 库存完整 | 需 transfer 编解码 | 无合法 alpha/mL 转移 |

## 11. Candidate C analysis

仅 A/B 不可行才考虑。本轮 B 已通过定义的闭合与域内原生测试，不启用 C。
新增 reservoir 会要求 M/Y/P/E/T/参考态、restart、MPI ownership、transaction rollback/publish 全部权威化，成本明显较高。

## 12. Candidate D analysis

**REJECTED AS UNJUSTIFIED**。没有蒸发、相变、external impulse/heat 证据。
不把 residual 给 gas dmG 或 Eulerian mL，不写 alpha source，不创造 chemistry/formation-energy source。

## 13. Selected policy

`OF7-ORourke-conservative-v1`：B + isolated adiabatic internal-DPM caloric thermalization。
正常合并保留 native sampled transfer；只在同事件 donor 满足 0<mResidual<minParcelMass 时全部并入该 recipient。
正 orphan 保留；零库存删除；非法态拒绝并丢弃独立 trial。

## 14. Selection rationale

recipient 由 native larger-droplet sorting 明确；残余来自该对液滴的同一次 coalescence。
符合质量、组分、动量闭合，并以明确的液滴内部能量 reservoir 完成 modeled E。
物理建模前提：事件短时封闭、无 carrier heat/mass/impulse，resolved 碰撞动能耗散最终归入液滴热内能。
这是第一版 lumped collision closure，未验证真实碰撞中振荡/表面能/气体功分配。
sigma 只维持 native 碰撞判据；不凭空添加 surface-energy inventory。
固定 carrier p 是 property-evaluation 输入，未建模外部 p*dV 功；不能将这里的算术闭合解释为完整可压液滴热力学验证。

## 15. Project-local wrapper architecture

```text
tests/fiveEqORourkeConservative/
  conservativePolicy.H      Policy : native ORourkeCollision
  captureNative.H           terminal native event/RNG entry capture
  testFiveEqORourkeConservative.C
  ARITHMETIC_CONTRACT.md
  Make/files, Make/options
tools/m8a3b_o2_prepare.py
tools/m8a3b_o2_generate_main.py
tools/m8a3b_o2_compare_capture.py
tools/m8a3b_o2_finalize.py
```

使用冻结 T3A beginTrial/prepare/publish/discard，先重建 fresh owner-bound native model graph，再由 test-only factory 显式安装 policy。
模型不可用 native clone 跨 owner 复制；clone 明确拒绝，要求 fresh-owner factory。
无 active runtime selection 注册；不是完整 T3B transactional model adapter。

## 16. Positive-residual handling

同事件 residual 必须保留正质量库存：合入 recipient 或保留自身。
阈值 1e-15 未降低/归零；其用途改为同事件路由，不能授权正质量 deletion。
无关 tiny orphan 留在原 ID；不得 nearest-parcel 合并。负/NaN mass、非法 np/d/rho/T/Y 一律拒绝。

## 17. Zero-residual handling

仅 represented mass 精确等于零且全部 represented species 精确零时允许 bookkeeping deletion。
np=0 不是 positive deletion；删除前仍有 unique ID 与状态预检。
零 parcel 的 lineage 在事件输出内保留，不引入 reservoir。

## 18. Survivor selection

同 cell 的 candidate pair 按 numeric (origProc,origId) 升序排列，随后原样调用 native collideParcels。
native recipient 为较大直径；完全相同直径时 native else 分支选择此 canonical pair 的较大 numeric identity。
不在随机判断前交换 native 参数；不依赖 pointer 或偶然容器顺序。
正 residual 仅给这一 recipient。equal-diameter 反转容器测试通过。

## 19. Identity policy

recipient 保持 origProc/origId；donor exact-zero 后退役，不分配新 ID。
preflight 拒绝重复 ID，canonical serialization 不静默折叠重复节点。
O1 历史重复身份源于 readCloudUniformProperties 在 TrialScope 外将 particleCount 清零；O2 用冻结隔离范围正确创建模型。
历史 fixture 作为非法 ID 负测试保存；诊断副本仅比较差异，不重写 owned parcel IDs。
原受影响 pair 的身份 106/107、148/149、190/191 与物理字段均精确保留。

## 20. Species handling

mYi=m*Y_i；partial merge Y'=(aY1+dmY2)/(a+dm)，full merge Y'=(aY1+bY2)/(a+b)。
Y 非负、总和检查，不自动 renormalize 掩盖错误。
当前单组分液滴走通用 Y 路径，population 输出走冻结 species mapping。
单组分通过不等于多燃料互溶/反应已验证。

## 21. Momentum update

partial survivor U'=(aU1+dmU2)/(a+dm)，donor U2 保持。
full survivor U'=(aU1+bU2)/(a+b)。
grazing 保留 native 计算的相对速度 vRel，但将 COM 纠正为旧 represented COM：
U1'=Ucom+b/(a+b)*vRel；U2'=Ucom−a/(a+b)*vRel。
没有 external impulse。grazing 若出现超过算术预算的 KE 增益，则拒绝状态。

## 22. Energy update

采用 actual parcel liquid caloric reference：

```text
m_i=np_i*mass_i()
e_i=h_native(p,T_i,Y_i)-p/rho_native(p,T_i,Y_i)
E_i=m_i*(e_i+|U_i|^2/2)
Rm = M_B-M_A + DeltaM_carrier - M_external
RYi= MYi_B-MYi_A + DeltaMYi_carrier - MYi_external
RP = P_B-P_A + DeltaP_carrier - I_external
RE = E_B-E_A + DeltaE_carrier - E_external
```

这里 source/external 增量均为零，由源码与 sourceBefore/After 逐项比对确认。
partial merge survivor internal target=a*e1+dm*e2+(KE_before−KE_after)，donor 内能保留。
full merge 为全部旧内能加 KE 差。grazing KE 损失按 represented mass 分摊给两个液滴内能。
输出 Total JSON 的 `E` 是内部能量，`KE` 单独输出；判断总能量必须相加，不能只比较 E。

## 23. Parcel thermal-state handling

实际 Foundation CompositionModel.C：H(LIQUID)=sum Y*h(p,T)，Hs=sum Y*(h(p,T)−h(p,298.15))，Hc=sum Y*h(p,298.15)。
不套用 gas JANAF，不使用 Eulerian C_L，也不重设 q。
本机 C10H22 h(T) 为原始积分多项式，rho 为原 NSRDS5，Cp 为原相关式。
300 K/3 MPa：rho=725.21967199798883 kg/m3，Cp=2220.0513054784406 J/(kg K)。
通过实际 liquidMixtureProperties 和 composition.H 求 e(p,T,Y) root，局部扩展 bracket、32 点单调性检查、相邻 double 收敛与 residual gate。
下界=max(native TMin,active liquid Tt)，上界=min(native TMax,mixture Tc)，Tc 端点开区间；C10H22 Tt=243.51 K、Tc=617.7 K。
不使用 DeltaT=DeltaE/Cp；越界/无 bracket/非单调拒绝，无 T clipping。
本轮包含极大碰撞 KE 的热域拒绝测试。只认证测试局部 caloric domain，不宣称整个压力温度范围 liquid EOS 已验证。

## 24. Carrier-source behavior

所有接受的内部事件 sourceBefore==sourceAfter；已有累计 drag source 可以非零，但本次 collision 增量为零。
dmG=dmYi=dM=dEt=0。没有蒸发、热交换、carrier impulse 或 chemistry 源。
不改冻结 DPM_EULERIAN_ENERGY_REFERENCE_LEDGER。

## 25. O1-A replay

9140 assertions，0 failures；精确受影响 pair 与其 native RNG 进入状态重放 PASS；一个 residual merge、exact-zero bookkeeping delete。
完整物理碰撞进入状态与 native entry 相同；历史无关新注入粒子的 5 个 ID 不同，完整 identity byte-equality 为 false。

## 26. O1-B replay

9140 assertions，0 failures；受影响事件精确重放及 M/Y/P/E PASS。
历史 6 个重复 ID 保留为负测试；没有改写 O1 证据。

## 27. O1-C replay

9140 assertions，0 failures；受影响事件精确重放及 M/Y/P/E PASS。
历史 11 个重复 ID 保留为负测试。

## 28. Mass ledger result

所有最终原生检查 PASS。独立 Decimal 复算最终 pair 及 endpoint ledger：最大 |Rm|=9.273e-28 kg。
非正质量静默删失结构上禁止，不靠全群误差掩盖 tiny loss。
固定 budget=1e-30+128*epsilon(double)*(endpoint magnitudes)；不是按粒子质量大小豁免。

## 29. Species ledger result

通用 represented species 路径 PASS；独立最大 |RYi|=9.273e-28 kg。
当前 active composition 为 C10H22；其他 gas species 映射库存零。

## 30. Momentum ledger result

原生完整 population 与 pair 均 PASS；独立 pair 最大分量 |RP|=3.318968549929e-26 kg m/s。
signed momentum 的预算尺度是 sum(abs(mU_j))，不是 abs(sum(mU_j))。
这使用同一个 128epsilon 因子并反映抵消条件数；没有把 near-zero net momentum 当作零运算尺度。
第一次错误尺度导致 stress 检查失败，results_attempt1 完整保留；最终冻结规则见 ARITHMETIC_CONTRACT.md。
冻结 source adapter 的任何 tolerance 未修改。

## 31. Energy ledger result

所声明的 modeled internal+translational KE 闭合 PASS；独立最大 |RE|=2.38076e-21 J。
2,697 项独立检查无失败，详见 independent_audit.json。
这是所选新热化语义的算术与原生 caloric 实现验证；不是 native total energy 守恒证明，也不是真实液滴碰撞能量分配验证。

## 32. Rollback spot-check

每个 A/B/C 都使用 T3A independent trial：实际 conservative event 后 discard。
committed parcel serialization、sources/diagnostics、finite RNG future probe、allocator、registry、Q/P2/carrier generation sentinel 不变。
out-of-domain thermal root、重复 ID、禁止 native clone 的拒绝路径同样丢弃 trial。
不宣称 dirty trial 在异常中 pair-atomic 原地恢复；保证的是独立 trial 被整体丢弃。

## 33. Accepted event spot-check

每个 seed 接受一个内部 collision-only event，prepare/publish 后 generation+1，结果与 prepared canonical population 相同。
Q/P2 不变；下一碰撞 query 与 independent fresh-owner reference 的 population 和 RNG future probe 相同。
仅 passive internal collision spot-check，不是普通全步 drag/heat/evaporation 的 combined retry 证明。

## 34. Repeated collision stress

| Seed | updates | max count | final count | min represented mass/kg | collisions | internal merges |
|---|---:|---:|---:|---:|---:|---:|
| A | 1000 | 16 | 3 | 1.1041773896286315e-15 | 135 | 13 |
| B | 1000 | 16 | 2 | 1.0211576396545184e-15 | 136 | 14 |
| C | 1000 | 16 | 4 | 1.2489041192266951e-15 | 135 | 12 |

每次 update 都检查 complete population M/Y/P/E 和零 collision carrier exchange。
另有 no-collision、native grazing、conservative coalescence、positive orphan、exact-zero cleanup、reverse-container equal-diameter、duplicate ID、thermal overflow、clone-refusal 测试。
全程序运行成本在各 log.resource；包含 native history/capture/transaction/tests/诊断 IO，不能解释为纯 collision kernel benchmark。

| Seed | user CPU/s | system CPU/s | wall/s | max RSS/KiB |
|---|---:|---:|---:|---:|
| A | 0.16 | 0.21 | 3.16 | 103232 |
| B | 0.21 | 0.12 | 2.88 | 103696 |
| C | 0.21 | 0.13 | 2.86 | 103904 |

## 35. Parcel-count behavior

所选同事件 merge 不创建 parcel，stress counts 未增长；orphan 测试保留其正库存。
无持续注入 stress、无全生产 mesh 碰撞成本结论。A-only 长期累积未用于通过 B。
生产中既存 orphan 的长期管理应另建物理规则，不能用 arbitrary merge/transfer 解决。

## 36. Restart implication

无新增 reservoir 或 parcel authoritative field；沿用 T/d/np/Y/U/IDs。
模型版本、fresh-owner factory、canonical pair-order contract 必须在后续 restart/model manifest 固定；不能读旧模型后默默回退 native ORourke。
fiveEqRestart-v1 当前文件未改；此次没有执行完整 restart round-trip 或全 transaction codec gate。
诊断计数和 event stream 不是权威物理状态，但未来 T3B 输出必须严格 publish-after-accept。

## 37. MPI implication

native 碰撞限于当前 cell occupancy；当前设计由该 cell owner 执行一次事件。
origProc/origId 全局唯一，迁移保持 identity，cell 内 numeric pair schedule 明确。
未来跨 rank ownership 改变需有稳定全局 cell/event key、单一 owner 与重复执行防护；不采用 pointer/rank-local容器排序。
本轮没有 MPI 测试或 rank-count invariance 证明，也没有 cross-rank collision 扩展。

## 38. Source-adapter regression

冻结 M8A source/energy 9288 项 PASS；8 个 golden_energy.csv 与 O1 byte-identical。
source adapter、energy reference ledger、evaporation/heat/drag 实现未修改。
其回归复跑与 policy-only collision checks 相互独立，不把两者合称完整 combined transaction 验证。

## 39. Frozen regressions

| Suite | Checks | Result |
|---|---:|---|
| M8A source/energy | 9288 | PASS；8 goldens identical |
| model rebinding | 6375 | PASS |
| native interpolation/support | 1725880 | PASS；max error 3.84593e-16 |
| T3A carrier publication | 64395 | PASS |
| critical precision/source tests | 105775 | PASS；含 subulp 长序列 |
| temporal | 9663 | PASS |

all-gas/support 当前 21000 cells、19 scenarios；证据在 support_regression。
所有冻结实现、旧结果保持 pre-change SHA；独立 audit 检查 9679 个保护文件和实际 300_2D 的 96 个文件。
MILESTONE_STATUS.md 仅允许本轮记录追加，原文快照与 prefix/SHA 单独检查。

## 40. Project-local overrides

原函数 ORourkeCollision::collide / collideSorted：局部代替正质量 deletion、守恒 U/T/np/d 处理和确定性 pair ordering。
原 collideParcels 与 base collideSorted 的概率、随机判断、We/geometry/coefficients 原样调用；wrapper 不额外取随机数。
canonical pair schedule 是显式执行顺序合同；合并改变后续 population，未来 native 与新策略随机消费数可以不同，不承诺整条 native trajectory 一致。
保留当前 production dictionary bytes 和 collision coefficients。安装源码未写入；active solver Make/options 未修改。

## 41. Active solver impact

**NONE**。无 active solver include/link/instantiation，无 rho/rhoU/rhoE/alpha/source 等方程修改。
无 alpha/mL/cL/cMix/pressure recovery/two-phase KT/VOF-DPM conversion 激活。
未运行 CFD、blockMesh 或 checkMesh。

## 42. Remaining blocker

native model 原始缺陷仍存在，但所选局部设计 gate 已闭合定义的库存。
T3B 仍缺完整 model adapter、canonical retry matrix、output publication、combined events、remaining models 与完整 codec/restart 验证。
O1 历史重复 ID 必须继续作为拒绝 fixture；后续完整合法历史 fixture 必须由正确 TrialScope/allocator 建立，不能静默重写旧身份。
热化假设尚无真实碰撞物理验证；压力功/界面能分配不在第一版 modeled inventory 中，未来物理升级需单独立项。

## 43. Whether O2 COMPLETE

**YES，限 design/native harness gate。**
源审计、A/B/C/D 比较、明确定义并选择 B、positive inventory 不丢失、M/Y/P/modeled E、determinism、rollback/accept/next query、stress、frozen regressions 全部通过。
精确 affected event replay 与完整历史 cloud 身份缺陷分别披露；没有以错误 byte-equality 判据充当证明。
不宣称 FULL-SERIAL-TRANSACTION-SAFE 或生产物理正确性。

## 44. Whether T3B may resume — NEXT ROUND ONLY

本轮 **NO**。下一轮可从局部 policy 的 fresh-owner adapter/完整 canonical retry 开始，先保留 duplicate-ID gate。
完整 ORourke merge/delete、combined events、source ledger、output 与剩余模型均须重跑，不直接 promotion。

## 45. T3 status

**PARTIAL**；T3A COMPLETE，T3B PARTIAL/BLOCKED pending next-round implementation/certification。

## 46. T4 permission

**NO**。

## 47. M8A status

**PARTIAL**；source/energy 仍 PASS/FROZEN。

## 48. M6B.0 permission

**NO**。

## 49. M6B.1 permission

**NO**。

## 50. Updated milestone matrix

| 项目 | 状态 |
|---|---|
| M8A source/energy | PASS / FROZEN |
| M8A.3A | COMPLETE |
| M8A.3B-T1 | COMPLETE / DESIGN ONLY |
| M8A.3B-T2 | COMPLETE / STRICT-SUPPORT FEASIBLE |
| M8A.3B-T3A | COMPLETE |
| M8A.3B-T3B | PARTIAL / BLOCKED；本轮未恢复 |
| M8A.3B-O1 | COMPLETE / NATIVE CONSERVATION BLOCKER；历史身份限制见本报告 |
| M8A.3B-O2 | COMPLETE / DESIGN + OFFLINE-NATIVE HARNESS ONLY |
| T3 overall | PARTIAL |
| T4 | NO |
| M8A overall | PARTIAL |
| M6B.0 / M6B.1 | NO / NO |

**STOP。未恢复 T3B，未执行 T4/M6B，未运行 CFD。**
