# M6B.1-EOS2-LB2-NDECANE — final report

Date:2026-10-05. Fresh native corner controls; LB1 numerical reuse explicitly labeled.

## 1. LB2 status

**PARTIAL / STOP / CLASS D.** Part A CLOSED / PASS; Part B PHYSICAL_PHASE_BOUNDARY_UNRESOLVED. No EOS3 authorization.

## 2. Exact corner issue

At alphaL=0.9, p=12 MPa and TL=275 K, alpha*rhoBoundary/alpha decodes +1 ULP outside the strict density boundary. Frozen R1 rejection is correct; neither R1 nor its tolerance was changed.

## 3. Primitive endpoint result

Fresh native standalone EOS API evaluatePT(12000000 Pa,275 K): PASS. Binary64 values/bits:

| Property | Value | Bits |
|---|---:|---|
| rho |752.53011910822875|4087843daf16469e|
| e |−56990.149412165956|c0ebd3c4c7fc05cd|
| h |−41043.943811491306|c0e40a7e33b42818|
| beta |0.0014659199155262672|3f58048386209c58|
| c |1396.1915066166578|4095d0c41a4f7e0d|

SI units: kg/m³, J/kg, J/kg, K⁻¹, m/s. Energy uses unchanged C_L; negative sensible energy does not establish a phase-stability defect.

## 4. Conservative round-trip table

| alphaL | decoded rho (kg/m³) | delta (kg/m³) | ULP | direction |
|---|---:|---:|---:|---|
| 0.10000000000000001 | 752.53011910822875 | 0 | 0 | EXACT |
| 0.5 | 752.53011910822875 | 0 | 0 | EXACT |
| 0.90000000000000002 | 752.53011910822886 | 1.1368683772161603e-13 | 1 | OUTWARD |
| 9.9999999999999995e-21 | 752.53011910822863 | -1.1368683772161603e-13 | -1 | INWARD |

One ULP=1.1368683772161603e−13 kg/m³. Full mass/density bits are retained in roundtrip.csv.

## 5. Interior control result

All 4 offline nextafter(rhoBoundary,0) constructions decode inside/on the admissible boundary and frozen R1 PASS. Energy is obtained from the actual decoded rho at 12 MPa. No runtime nextafter. Rounding may yield recovered p=11999999.999999914 Pa; PASS does not assert exact pressure bits.

## 6. Exterior negative result

All 4 offline nextafter(rhoBoundary,+infinity) constructions decode outside and frozen strict R1 rejects NO_LIQUID_PRESSURE_INTERVAL. No boundary relaxation. The endpoint energy is retained for these deliberately invalid states; rejection precedes energy recovery.

## 7. Final representation contract

HARD p/T is the primitive admissibility domain. Q admissibility depends on its actual decoded intrinsic state and frozen phase/P2 policy. Generators must inspect binary64 decoded state. Mathematically intended endpoint is not automatically a representable conserved endpoint. See REPRESENTABLE_HARD_CORNER_CONTRACT.md; runtime untouched.

## 8. Runtime relevance

Diagnosed minimum TL*=284.87337272298197 K, margin above candidate Tmin=9.87337272298197 K. This exact 275 K corner is absent from the diagnosed envelope. This is not a proof that future CFD cannot reach a corner.

## 9. Melting source

Primary target: A. Würflinger (1975), Differential Thermal Analysis under High Pressure IV, Ber. Bunsen-Ges. Phys. Chem.79,1195–1201, [DOI](https://doi.org/10.1002/bbpc.19750791206). Crossref metadata acquired. Public Wiley PDF request returned HTTP403; OpenAlex reports closed/no repository fulltext. [EES official documentation](https://fchartsoftware.com/ees/eeshelp/hs572.htm) explicitly cites this work for n-decane melting but publishes no equation/data. Original quantitative source NOT ACQUIRED. Search/retrieval logs and public responses preserved; no access-control workaround.

## 10. Melting relation

UNRESOLVED. ndecane_melting_curve_reference_v1 is a provenance/missing-data record, not a reproduced curve: equation=null, dataPoints=[], interpolation=null. No guessed fit or visual reading certificate.

## 11. Source validity range

EES states temperature context from triple point to293 K. It supplies no pressure validity, coefficients, uncertainty, page/table/figure. Those remain UNKNOWN. Paper title “up to3 kbar” is not proof of a n-decane correlation valid over that whole range. Source/interpolation/digitization uncertainties cannot be quantified.

## 12. Diagnosed p envelope

Unchanged 130 independent reference roots: p*=3285416.855452983–3286242.793380548 Pa (3.285416855453–3.286242793381 MPa). Requested melting evaluation pressures also recorded at3.285416855 and3.286242793 MPa.

## 13. Diagnosed Tmin

Unchanged TL*=284.87337272298197–285.00000000011846 K; minimum284.87337272298197 K. Exact values reuse hash-verified LB1 independent_reference_130.csv; no PDE continuation.

## 14. Melting T at diagnosed p

Both requested Tmelt values are null / PHYSICAL_PHASE_BOUNDARY_UNRESOLVED. No quantitative relation available. Diagnosed-envelope physical certificate remains UNRESOLVED.

## 15. Liquid margin

TL*−Tmelt(p*) and conservative margin after uncertainty are UNRESOLVED, not9.873 K. The9.873 K value measures table Tmin margin only, not melting margin. No physical-liquid approval.

## 16. Melting T at12 MPa

Tmelt(12 MPa)=UNRESOLVED; source pressure validity and uncertainty unavailable. Cannot certify275 K at12 MPa as stable liquid.

## 17. Full HARD-box validity

Independent second certificate: max Tmelt(p) over0.05–12 MPa UNKNOWN. The275–330 K rectangle is a numerically evaluated fluid-EOS candidate domain, not a certified stable-liquid rectangle. Diagnosed and full-box certificates both unresolved, recorded separately.

## 18. Fluid-EOS vs phase-stability scope

HEOS fluid phase=3, p>pSat/T<Tc, positive Cp/Cv/c² and numerical inversion pass are fluid-EOS checks only. None proves solid/liquid stability. No solid-phase calculation has been substituted with a vapor criterion.

## 19. Revised controls accounting

Fresh original280: VALID_EXPECT_PASS279/279; INVALID_EXPECT_REJECT1/1. Fresh REPRESENTATION_TEST12:7 valid PASS +5 expected reject (four direct round trips, four interior, four exterior). Combined292=286 legal passes+6 expected rejects. Primitive endpoint API separately PASS1. PHYSICAL_PHASE_TEST: two certificate scopes UNRESOLVED (three requested Tmelt evaluations); not counted as equation failures or passing physical tests.

## 20. Unexpected failures

0 unexpected failures in both fresh control groups. Historical LB1 result remains retained. Correct invalid-state reclassification does not relax equations or remove a prior record.

## 21. v3 numerical evidence status

HASH-VERIFIED REUSE, explicitly permitted by request §17; not fresh model regression. LB1 native17243 points: lower9801, old3721, upper3721, frozen nine-property budgets PASS. Same81 coefficients, same C_L=369229.9537234281 J/kg. Coefficients SHA256610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac.23 evidence/candidate files verified in LB1_evidence_reuse.json; no redesign/refit.

## 22. 130 R1 status

130/130 frozen shadow R1 PASS, hash-verified reuse; max normalized residual8.570596875729471e−16. MAIN4 + PROBE126, missing0/duplicate0. Fluid roots valid; solid/liquid certificate pending.

## 23. old184 status

184/184 PASS, reused SHA evidence; p/TG/TL/cL/cA output deltas0. No fresh EOS regression claim.

## 24. accepted6200 status

5500 prior accepted +700 new neighbors PASS, reused SHA evidence; no new invalid recovery. Maximum pressure differences1.862645149230957e−9 Pa and3.039836883544922e−6 Pa respectively.

## 25. Final class A–D

**CLASS D / UNRESOLVED.** Melting evidence cannot be quantified. A is not authorized; B/C are not established. Representation closure alone does not establish an artificial lower table limit physically.

## 26. Whether v3 DESIGN QUALIFIED

NO. ndecane_gibbs_v3_candidate remains SHADOW / NUMERICAL PASS / DESIGN PARTIAL. Active v2 preserved.

## 27. Source changes

Added only isolated offline cornerControls.C/Make/run scripts, source-data retrieval/provenance tools, representation contract, logs/CSV/JSON, this report and appended milestone journal. Copied frozen model/R1 source only for standalone tool. No active source, R1/P2 implementation, temporal driver, equation, production case or model parameter changes. No solver install/factory switch.

## 28. Foundation/project hashes

Fresh Foundation manifest6717 files and native parcel manifest19 files: PASS. Fresh55 loaded-library SHA: unchanged. Active executable99053c2f1837e3e524b2385a2004d8649d7fc0430a762dfd5cd5bddb01bf9a3d; liquidEOS library131f628aeac3cb9b08ab111fcd2e02bb5fa9b055f47ed0afbb1630f136173f2e; fiveEqThermo libraryc4b6c55b657b7189f1b327f8079bf03977d18178eea8a7a2878bbd03b0bbca70. Exact protected project count/delta in project_protection.json produced by final seal; only pre-existing milestone journal append allowed. Parent LB1 archive SHA22ad96d865bcafc03a6b614ce6ee5a41232198b09c34ec993b987aa6a5de17a0; CRC and per-file SHA checked during seal.

## 29. Whether LB2 COMPLETE

NO: quantitative original melting source, relation, diagnosed margin and full-box physical scope remain missing. Part A COMPLETE; Part B unresolved; overall PARTIAL / STOP. Required evidence: original n-decane melting data or traceable published coefficients, source locator, p/T validity and uncertainty, then evaluate both independent physical certificates.

## 30. Whether EOS3 may start

NO / NOT AUTHORIZED. LB2 COMPLETE and CLASS A are both required. No v3 install or new runtime work.

## 31. EOS2 status

M6B.1-EOS2 PARTIAL / STOP; active ndecane_gibbs_v2 ACTIVE / PRESERVED. Existing lower-domain/temporal blockers not closed by this offline representation test.

## 32. TD1 status

REQUIRED / NOT AUTHORIZED / NOT EXECUTED. No dt growth/time-progress guard or temporal-policy changes.

## 33. M6B.1 status

PARTIAL / STOP. Only allowed offline standalone compilation/control execution and read-only provenance/hash audits completed. No shock/PDE replay, wave ladder, RH, high-Mach, M6B.2, DPM or production CFD.

## 34. Milestone matrix

| Milestone | Status |
|---|---|
| M6B.0 | COMPLETE / FROZEN |
| M6B.1-SR1 | COMPLETE / DIAGNOSIS ONLY |
| M6B.1-EOS1 (CAP1 closure) | COMPLETE / DESIGN QUALIFIED |
| ndecane_gibbs_v2 | ACTIVE / PRESERVED |
| M6B.1-EOS2 | PARTIAL / STOP |
| M6B.1-EOS2-LB1 | PARTIAL / STOP / CLASS D |
| LB2 Part A | CLOSED / PASS |
| LB2 Part B | PHYSICAL_PHASE_BOUNDARY_UNRESOLVED |
| M6B.1-EOS2-LB2 | PARTIAL / STOP / CLASS D |
| v3 candidate | SHADOW / NUMERICAL PASS / DESIGN PARTIAL |
| EOS3 | NOT AUTHORIZED |
| TD1 | REQUIRED / NOT AUTHORIZED |
| M6B.1 / M6B | PARTIAL / STOP |
| M6B.2 | NOT AUTHORIZED |
| T4 / M8A | PARTIAL; S1/S2 FROZEN; S3 DEFERRED |
| Active DPM / production CFD/restart | NOT CERTIFIED / NOT EXECUTED THIS ROUND |

**STOP.**
