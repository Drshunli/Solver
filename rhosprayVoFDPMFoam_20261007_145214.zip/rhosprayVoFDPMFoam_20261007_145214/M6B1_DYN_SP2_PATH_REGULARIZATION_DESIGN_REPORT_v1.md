# M6B1 DYN SP2 路径正则化设计审查

SP2 设计审查完成，自动继续 SP3。没有取得新的 DYN 或生产资格。

- CRV1 标量黏性因热接触压力偏移而拒绝。
- CRV2 声学投影在分段内部 567 个原生状态上通过局部检查，并完成 1.01/1.02/1.05 弱激波自身行波射击；但独立相熵耗散审查得到稳定负值，判为 ENTROPY_DISSIPATION_BLOCKER，也不安装。
- N6400 原驱动在 PDE 前几何门槛拒绝，没有伪计为完成。
- 原 111 源文件、求解器与恢复/EOS 二进制哈希未改变。MC5、TD1 COMPLETE 与 DYN/M6B.1/M6B PARTIAL 保留。

完整推导、数值证据及失败明细：fitting/integration/m6b1_dyn_sp2_path_regularization_design_v1/PATH_REGULARIZATION_DESIGN_v1.md。

用户“自动进行下一步，不停止，以求解器设计为目标”的授权继续有效。下一步为 CRV3 动量应力/一致能量功正则化，目录 fitting/integration/m6b1_dyn_sp3_ke_work_regularization_v1。