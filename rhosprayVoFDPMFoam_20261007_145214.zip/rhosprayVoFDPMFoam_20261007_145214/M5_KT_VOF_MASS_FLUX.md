# M5A candidate mixture mass fluxes (design and diagnostics only)

See `KT_FLUX_AUDIT.md` for exact active KT reconstruction and OF7 comparison.
No candidate below is the authoritative mass flux of a conservative mixture
solver. Legacy `phi`, `phiUp`, `phiEp`, and their equations are unchanged.

## Candidate A: VOF phase-volume decomposition

Define `alphaPhiG = phiV-alphaPhi` and use **explicit linear face
interpolation** `rhoL_f=linearInterpolate(rhoL)` and
`rhoG_f=linearInterpolate(rhoGas)`. This interpolation is explicit and local;
it is chosen as a transparent diagnostic of the VOF decomposition, not as a
shock-stable numerical flux. Then

```
rhoPhiVoF = rhoL_f*alphaPhi + rhoG_f*alphaPhiG
          = rhoG_f*phiV + (rhoL_f-rhoG_f)*alphaPhi.
```

`alphaPhi` is the **limited** MULES flux. Before limiting, the code forms
`alphaPhiAdv=fvc::flux(phiV,alphaL,scheme)` and a nested compressive flux
`alphaPhiCompRaw`. After limiting,
`alphaPhi = alphaPhiAdv + alphaPhiCompRaw + limiterRemainder` algebraically;
the remainder includes MULES corrections. With repeated correctors or alpha
subcycles it also reflects the latest correction and weighted substep fluxes.
The current implementation does not retain a clean, unique split of the final
flux. Candidate A therefore includes artificial compression and limiter
corrections. Treating all of that as physical total-mass transport is not
justified by the current equations.

## Candidate B: frozen-wave KT mixture diagnostic

Use the **same directed interpolation** operator and `reconstruct(rho)`
scheme entry as the original mass flux,
now on the M4 diagnostic `rhoMix`, and reuse the current gas-derived
`aphiv_pos/neg` and their wave-speed weights:

```
rhoMix+ = interpolate(rhoMix,pos,rho.name())
rhoMix- = interpolate(rhoMix,neg,rho.name())
rhoPhiKTmix = A+*rhoMix+ + A-*rhoMix-
            = a+*q+*rhoMix+ + a-*q-*rhoMix-
              + aSf*(rhoMix- - rhoMix+).
```

The output field is named `rhoPhiMix` and means precisely this Candidate B;
it is *not* final `rhoPhi`. `rhoPhiDifference=rhoPhiMix-phi` measures the
candidate's departure from the legacy mass flux. This formula preserves the
KT density-jump term but uses **frozen gas velocities, gas sound speeds and
gas pressure states**. It is not a complete two-phase Riemann/KT system.

## Algebraic limits

| State | `rhoMix` | `rhoPhiVoF` | `rhoPhiMix` (Candidate B) |
|---|---|---|---|
| Pure gas, `alphaL=0`, `alphaPhi=0` | `rhoG=rho` | `rhoG_f*phiV`, generally **not** legacy `phi` | Exactly legacy `phi` if the same directed reconstruction and time-level states are used |
| Pure liquid, `alphaL=1`, `alphaPhi=phiV` | `rhoL` | `rhoL_f*phiV` | `A+*rhoL+ + A-*rhoL-`; equals `rhoL*phiV` for spatially constant `rhoL` |
| Interface | `alphaL*rhoL+alphaG*rhoG` | Carries VOF compression/limiter corrections weighted by density jump; lacks KT density dissipation | Carries KT mixture-density dissipation but does not explicitly transport the MULES compression flux |

Pure-phase equalities assume consistent boundary alpha fields. In a pure
liquid limit the present `q±`, `a±` and `aSf` still come from the legacy gas
state, so this is only an algebraic limit, not a validated liquid KT flux.
With variable phase densities, both candidates also require review of the
face density time level relative to alpha subcycling.

## Future M5B decision

Neither candidate may replace `phi` alone. Candidate A loses the KT density
jump dissipation and promotes artificial interface compression to physical
mixture mass flux. Candidate B has the correct pure-gas backward limit but
does not make the alpha, momentum and energy equations conservative as one
two-phase system. M5B must derive shared face states, wave bounds, phase
mass transport and matching `phiUp/phiEp` for a conserved mixture state,
including a defined treatment of alpha compression and DPM gas mass source.
Only after that derivation can a new authoritative mass flux be installed.
No CFD case was run in M5A.
