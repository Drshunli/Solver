# M8A.3B-T4-S2-ID1-FIXTURE-NATIVE report

2026-10-04. Evidence: fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1.

## 1. ID1 fixture status

**COMPLETE** within isolated two-rank fixed-mesh/native-identity scope. All mandatory ID1 gates satisfied; no global MPI transaction closure certificate.

## 2. Retired CLASS D fixture

Original CRT1e9 exact_final_fixture, failure JSON, expression audit, debugger artifacts and checkpoint remain immutable. They are HISTORICAL / INTENTIONALLY INVALID KH DIAGNOSTIC FIXTURE, excluded from normal identity/migration certification. Historical ClassD remains valid, not erased.

## 3. Native coefficient provenance

Source: D:/DATA/Solver/300_2D/constant/sprayCloudProperties, ReitzKHRTCoeffs. B0=.61,B1=15,Ctau=1,CRT=.1,msLimit=.2,WeberLimit=6. Original69 inputs preserved except three roleA/B/C properties CRT tokens changed1e9→.1; geometry/mesh/decomposition/parent/diameter/dt/p/T/RNG unchanged. Dictionary source SHA and exact changed-file hashes in fixture_provenance.json. No scanning/tuning.

## 4. ReitzKHRT source status

Foundation ReitzKHRT.C and formulas byte unchanged. No copied/custom runtime KH, limiter, guard, epsilon, clamp, signal recovery or alternate model. A test-only observer header uses the same birth assignment, then records native before/after counter and parent/child pairs; no production/shared adapter modification.

## 5. Finite-domain precheck

Offline worst-case nonnegative KRT=0:twoPi*.1/vSmall≈2.8238097729461284e307, finite double. Larger nonnegative KRT reduces this expression. Diagnostic assertion only; no runtime guard. This checks the diagnosed expression, not every possible KH arithmetic state.

## 6. Parent identity

Migrated parent remains(0,0) through each stable boundary; native transfer preserves pair, no destination renumber.

## 7. Newborn identity

True KH child only:birth-rank origProc plus existing getNewParticleID. Source child(0,1); destination children(1,0..16). Injection/copy/clone/stream/checkpoint untouched.

## 8. Sibling uniqueness

18 actual natural births per independent fixture; all children from parent(0,0), complete pairs unique across1000 stable test steps. No manually manufactured siblings. Multi-generation: NOT REACHED NATURALLY; not forced or tuned.

## 9. Both-rank births

Accepted stress totals rank0=100,rank1=1700. Numerically overlapping local IDs are legal because full pair differs; no global ID allocation/synchronization.

## 10. Child remigration

Source-born child(0,1) truly transfers0→1, preserving both components;200 native boundary events across100 accepted stress fixtures. Current requested at-least-one birth-rank-child-cross gate satisfied. Reverse transfer of a destination-born child is not claimed.

## 11. Accepted allocator

Actual per-birth nativecounter after=before+1,neworigId=before. Rank0initial1→2,rank1initial0→17; after existing local publication counters remain2/17. Each rank advances only for its own births. Native allocator unchanged.

## 12. Rejected allocator restore

Deliberate normal test rejection after10 valid native steps uses existing tx.discard, no SIGFPE. Source counter2→1,destination17→0; accepted parent/fields/RNG/source/view/output remain exact, newborn trial destroyed; pending output discarded with0publications. Then native retry.

## 13. Direct/retry

Both ranks ID1_local_accepted.bin byte identical between direct acceptance and rejected-birth→discard→same retry acceptance. Existing transactionState-v1 includes identity,parcel/history,clock,allocator,RNG/native source/output state. Each successful rank-local prepare/publish/flush publishes once. No new serializer.

## 14. K1 support revalidation

Fresh current-source K1:108 checks/0failures,92identity-negativechecks,5694laterchildqueries;22fullstate encodings equal frozen authorized version. Existing independent child preflight/session fences and parent authority invalidation preserved; native MPI child query rows have own pair and generation1. Immediate spatial-invalid birth gate not restored.

## 15. Native KH continuation

Each accepted fixture runs10 consecutive valid native steps without SIGFPE,duplicate,stale support or corrupted transfer. Accepted stress100fixtures =1000native steps; not the R1 gate of1000valid crossings. Local native trajectory equals original10-step valid CRT fixture exactly, observer is physically neutral.

## 16. Accepted birth count

**1800 actual accepted KH births** across100 independent native fixtures;1700 from migrated parent on destination rank. Counts are taken only from successful existing rank-local publication cases; exploratory disposable/rejected trial births excluded. Scope is local happy-path identity certificate, not atomic global MPI commit.

## 17. Migration/birth stress

100 independent accepted parent-cross→birth sequences and source-child birth→cross witnesses. All complete pairs unique within their own cloud population; restarted independent fixtures may naturally reuse IDs. No cross-fixture global identity service.

## 18. SIGFPE result

No unexpected SIGFPE in new native-valid fixture/control/stress. Old ClassD fixture remains frozen diagnostic evidence. No catch-and-continue or signal-to-latch conversion.

## 19. C2 migration semantics

Current-source C2 semantic/identity17checks0failures; new native target compiles current shared C2 transport. Actual accepted direct boundary2events/0errors:pair/raw stream scalars/flags/particle history/physical fields/native geometry and prepare/correct RNG PASS. Native stream/iNew authoritative, no packet or custom queue.

## 20. Serial regression

Fresh isolated targets rebuilt from current sources: K1 108/0,C2 17/0,I1 12083/0,R2B 252194/0. K1 22full-state files byte equal prior authorized-source result. Old binaries/checkpoints unmodified. Regression binaries are separately versioned.

## 21. S1/N1 regression

Fresh S1 coupled support and N1 valid/forward-invalid/reverse-invalid all ranks globalFailures0. S1 support20051 total checks/0failures. Failure latch/quarantine/post-evolve native reduction unchanged; no global transaction certification inferred.

## 22. Foundation hashes

Fresh6717Foundation and19nativeparcel SHA checks PASS; ReitzKHRT unchanged.

## 23. Project hashes

4367 protected entries all unchanged before authorized milestone append; historical FPE1 checkpoint exact SHA/CRC PASS. Shared C2 identity source, original adapter, S1/N1/contracts/oldtargets remain frozen. New target main/observer/Make and fixture deltas documented. Closing manifest separately protects all new evidence.

## 24. Active solver impact

**NONE.** No active solver equations, flux activation, thermo, source adapter, production coupling or runtime integration.

## 25. Production mesh/BC impact

**NONE.** New isolated test copies only. No mesh generation/CFD/production boundary changes.

## 26. Whether ID1 COMPLETE

YES, within this round's isolated identity certificate. Multi-generation not naturally reached as explicitly permitted. Does not certify global MPI commit, production restart, all native KH domains or remaining R1 gates.

## 27. Whether R1 may resume NEXT ROUND ONLY

YES, only NEXT ROUND after new user instruction. Remaining RNG/injection/VoidFraction/1000validcrossings/lifetime/model-continuation gates not executed here beyond ID scope.

## 28. T4-S2 status

PARTIAL; ID1 completion removes this identity-fixture prerequisite, not all S2 gates.

## 29. T4/M8A status

PARTIAL / PARTIAL; production restart NOT CERTIFIED.

## 30. M6B/CFD permissions

M6B NO,CFD NO,S3 NOT AUTHORIZED. No global MPI transaction closure/global source ledger/MPI output coordinator.

## 31. Updated milestone matrix

See below. STOP after ID1 closure.

## Local acceptance scope

The harness invokes the **existing** serial/local transaction prepare/publish/flush independently on each successful rank after native transport and the frozen diagnostic checks. No global two-phase commit, coordinator, source ledger or failure-atomic distributed publication protocol is added. Each receipt explicitly sets globalMPITransactionCertified=false. This certifies happy-path local accepted identities and rank-local rollback/retry in the two-rank fixture; it does not certify distributed commit under rank failure. Normal rejected trial output is discarded through the existing mechanism. All accepted stress cases are fresh processes/cases with10steps and100% unchanged physical inputs except restored CRT.

## Modified/added items

New isolated tests/fiveEqDPMID1FixtureNative: copied frozen harness/types/observers; test-only birth observer at existing identity assignment; disposition/allocator/state receipts; optional existing local acceptance on last successful trajectory. Native parcel physical equations are included from current shared source, not newly copied. New fresh build targets K1/C2/I1/R2B, offline audit tool and scripts. No shared/native physical source changes. Existing Make libraries unchanged. New fixture provenance lists exactly three CRT input deltas.

## Matrix

| Milestone | Status |
|---|---|
| R2-FINAL / T3 | COMPLETE / FROZEN |
| T4-S1 | COMPLETE / FROZEN |
| T4-S2-C1-N1 | COMPLETE / FROZEN |
| T4-S2-KH-FPE1 | COMPLETE / DIAGNOSIS ONLY; CLASS D historical |
| T4-S2-ID1-FIXTURE-NATIVE | COMPLETE, isolated scope |
| T4-S2-ID1-NATIVE | COMPLETE, isolated scope |
| T4-S2-R1-NATIVE / S2 | PARTIAL / PARTIAL |
| T4 / M8A | PARTIAL / PARTIAL |
| S3 | NOT AUTHORIZED |
| M6B / CFD | NO / NO |
| Production restart | NOT CERTIFIED |

No remaining R1 work in this round. STOP.
