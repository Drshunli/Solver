# M4 phase-property and mixture closure (Foundation OpenFOAM 7)

Current M4 diagnostic closure uses `SLGThermo.liquids()` at gas `p,T` as
query coordinates. The mixture and cloud receive the transitional `rhoG`
view of legacy gas `rho`. Diagnostic liquid `rhoL` is not the future
five-equation intrinsic liquid density; future `TL` need not equal gas `TG`.

## Actual property sources

The target creates `psiReactionThermo` and `SLGThermo(mesh,thermo)` in
`createFields.H`. Its `300_2D/constant/thermophysicalProperties` selects
`hePsiThermo/reactingMixture/sutherland/janaf/perfectGas` with sensible
internal energy, and declares one liquid, `C10H22`. `SLGThermo.C` constructs
`liquidMixtureProperties` from that `liquids` dictionary. OF7
`liquidMixtureProperties` can construct named liquid classes or dictionary
customizations. The current spray composition is `singlePhaseMixture` with
`C10H22 1`, so the new VOF module takes a const reference to the *same*
`SLGThermo.liquids()` object and uses its one-component mole fraction `X=1`.
It fails explicitly if a case declares zero or multiple liquid components;
an explicit composition adapter is needed for multicomponent liquids.

OF7 `SprayCloud::setParcelThermoProperties` overrides parcel initial `rho`,
`Cp`, `mu` and `sigma` from `composition().liquids()` at parcel pressure and
temperature. `SprayParcel::calc` refreshes those from the same database.
Thus the case's `constantProperties/rho0` and `Cp0` are initial placeholders,
not the runtime liquid-property owner. `liquidMixtureProperties::kappa(p,T,X)`
is available, but the inspected spray parcel code does not assign a parcel
conductivity field. Latent heat comes from `liquidProperties::hl(p,T)` through
`CompositionModel::L`; the present case sets `phaseChangeModel none` and
`heatTransferModel none`, so those effects are inactive.

Gas `rhoG` is a const reference to the legacy `rho` solved by `rhoEqn.H`;
no duplicate gas density equation or registered `rhoG` field exists. Gas
laminar `muG`, `CpG` and `kappaG` are fresh `psiReactionThermo` results from
`mu()`, `Cp()` and `kappa()` on each correction. Turbulent viscosity and
diffusivity remain owned by the existing turbulence model.

## Selected closure

The current model assumes a shared pressure and temperature for *evaluating*
VOF-liquid properties. It does not enforce thermal or pressure equilibrium in
the conserved equations. Liquid `rhoL`, `muL`, `CpL` and `kappaL` call the
same OF7 `liquidMixtureProperties` methods as the spray database. OF7's
liquid-property implementation clips temperatures near its critical range;
this is an OF7 database behavior, not a new liquid EOS.

```
alphaG = 1 - alphaL
rhoMix   = alphaL*rhoL + alphaG*rhoG
muMix    = alphaL*muL + alphaG*muG
CpMix    = (alphaL*rhoL*CpL + alphaG*rhoG*CpG)/max(rhoMix, SMALL kg/m3)
kappaMix = alphaL*kappaL + alphaG*kappaG
```

The viscosity and conductivity averages are explicit first-version closure
choices, not unique physical mixing laws. `CpMix` is mass weighted and has
a density floor only to prevent division by zero; near-vacuum behavior needs
case validation. No `rhoMix` value replaces legacy `rho`.

The module checks dimensions of all gas, liquid and mixture values at runtime:
`rho` [1 -3 0 0 0 0 0], `mu` [1 -1 -1 0 0 0 0],
`Cp` [0 2 -2 -1 0 0 0], `kappa` [1 1 -3 -1 0 0 0].
OF7 field arithmetic also dimension-checks each mixing expression.

`correct()` runs once after alpha/interface update and once after the
original gas density/energy/thermo update so AUTO_WRITE diagnostics reflect
end-of-step gas state. It only writes its own phase/mixture fields. No M5
`rhoPhi`, M6 mixture energy, M7 capillary momentum, DPM wrapper or transfer
is active. No CFD case was run in M4. M3 `sigma` still comes from its
constant interface dictionary; matching sigma to the spray database is
future work.
