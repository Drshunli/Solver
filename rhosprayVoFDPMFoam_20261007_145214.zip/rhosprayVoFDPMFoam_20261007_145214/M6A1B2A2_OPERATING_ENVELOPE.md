# M6A1b-2A.2 liquid reference-state and operating-envelope audit

## 1. Status

**PARTIAL / REFERENCE INLET AND BC CONTROL CLOSED / ENGINEERING BOUNDS PROVISIONAL.** The inlet reference state, reference-density velocity, isentropic paths, phase audit and boundary design are complete. Expected loading/rarefaction limits and dissipation/work limits are screening proposals, not proven extrema. Do not start M6A1b-2B, fit production EOS, build runtime tables or run CFD.

## 2. Locked conditions

Base air U=2013.039 m/s, p=188330.307 Pa absolute, T=400 K, supplied rho=1.6338 kg/m3. One 0.3 mm circular C10H22 exit plane, no internal nozzle, mdot=1.09609e-4 kg/s total and per hole, TL=300 K, reference exit static p=3 MPa absolute. User subsequently selected mass-flow/T control with outgoing pressure-wave response; p=3 MPa is the reference state, not an independent maintained face pressure. User selected adiabatic mechanical scope.

## 3. Reference backend and provenance

CoolProp 8.0.0 `HEOS::n-Decane`, revision `ae81610e7d23efc57f9d051c8e70a4d66e87537f`, Lemmon–Span (2006), [DOI 10.1021/je050186n](https://doi.org/10.1021/je050186n). The backend was installed only in `fitting/reference_backend`; it is not a solver library. All query results are **REFERENCE-EOS GENERATED DATA**. Fluid JSON hash `a77dcdaf28b43d92f291c4c9d5e0ea1f112d9ff7639849915ed9d2239addee60` refers to the exact returned JSON text; a formatted companion snapshot is retained. [Official fluid documentation](https://coolprop.org/fluid_properties/fluids/n-Decane.html) specifies the model and transport correlations. No experimental accuracy claim is inferred from software limits.

## 4–7. Inlet state, phase, density and velocity

| Property at 3 MPa, 300 K | Reference output |
|---|---:|
| Backend phase | supercritical_liquid (compressed liquid below Tc) |
| rho | 727.432960546 kg/m3 |
| e, native DEF | -369296.369049 J/kg |
| h, native DEF | -365172.277674 J/kg |
| s, native DEF | -993.782257318 J/(kg K) |
| Cp | 2196.745004 J/(kg K) |
| Cv | 1781.914274 J/(kg K) |
| Sound speed c | 1244.718107 m/s |
| Adiabatic Ks=rho*c² | 1.127028737 GPa |
| Isothermal KT=1/kappaT | 0.914201962 GPa |
| alphaP | 1.048939033e-3 1/K |
| kappaT | 1.093850201e-9 1/Pa |
| (dp/drho) at e | 1.546272174e6 m²/s² |
| (dp/de) at rho | 538.152781 kg/m3 |
| (de/dp) at rho | 1.858208366e-3 m3/kg |

Equilibrium PT flash is not phase-imposed. psat(300 K)=207.0885 Pa, Tc=617.698845 K, pc=2.101337 MPa. p>pc with T<Tc is a compressed-liquid state; it does not imply a fluid above both critical coordinates. Backend domain Tmin=243.5 K, Tmax=675 K, pmax=800 MPa. Full liquid-vapor phase context and melting-data limitation are in `LIQUID_PHASE_VALIDITY_MAP.md`.

A=pi*d²/4=7.06858347e-8 m2 and U_ref=mdot/(rho_ref*A)=**2.1316743005 m/s**, status DERIVED at the reference PT state. Nominal rho=730 and U=2.124178 remain historical sanity inputs. A mass-flow boundary at fixed TL recalculates rho and U when boundary pressure responds; U_ref must not be fixed independently.

## 8. Actual OF7 gas thermo audit

Read `300_2D/constant/thermophysicalProperties`, `thermal.dat` and fields `0/N2`, `0/O2`, `0/C10H22`. The existing case defines `hePsiThermo/reactingMixture/janaf/perfectGas/sensibleInternalEnergy`, mass fractions YN2=0.772, YO2=0.228, YC10H22=0. Source scaling was confirmed in local Foundation 7 `janafThermoI.H`; its dimensional polynomial coefficients are Ri times the input coefficients. `perfectGasI.H` gives rho=p/(RT) and CpMCv=R. Installed SI constants were read from `fundamentalConstants.C`, `physicoChemicalConstants.C`, `thermodynamicConstants.C` and `etc/controlDict`: RR=1000*(6.0221417930e23)*(1.38065e-23)=8314.4700665 J/(kmol K). The mixture R is 288.3749823 J/(kg K).

| T (K) | Cp (J/kg K) | Cv (J/kg K) | gamma |
|---:|---:|---:|---:|
| 350 | 1016.644 | 728.269 | 1.395973 |
| 400 | 1023.252 | 734.877 | 1.392413 |
| 450 | 1030.425 | 742.050 | 1.388619 |

At 400 K, gamma=1.4 is about 0.545% above the case value. The case thermo predicts rho=1.632685900 kg/m3, -0.06819% relative to the supplied density. At the same p,T and composition, rho is an EOS result, not a fourth independently fixed thermodynamic variable. Supplied rho is retained for user-state diagnostics; future runtime must use its actual gas thermo, with the small discrepancy explicitly recorded. Mach from actual case JANAF at 400 K is 5.022957. This is an offline evaluation of the local formulas, not a CFD run or a high-temperature shock calculation.

The separate constant-gamma/R287 screening gives M=5.021312, q=3.310345 MPa, normal-shock p2=5.508506 MPa and postshock stagnation p02=6.201421 MPa. A full variable-Cp shock calculation was not done; using gamma(400 K) as a constant throughout a shock would not solve that problem.

## 9. Expected pressure proposal

**Candidate 0.188330–6.201421 MPa**, containing ambient/interface loading, 3 MPa reference inlet, normal-shock compression and stagnation-like loading. Ambient is the nominal low-pressure environment; p02 is a gas-side loading scale. These are explained design coordinates, not simply table endpoints copied from a shock formula. Breakup rarefaction can fall below ambient; moving-interface work, wave interactions and focusing can exceed the stagnation-like scale. Thus both physical extremes remain provisional.

## 10. Analytical pressure construction

At the inlet reference state, qL=rhoL*U_ref²/2=1652.740534 Pa. An initial-speed Bernoulli screening extension gives **0.1866776–6.2030735 MPa**, using p_inf-qL and max(pL_ref,p02)+qL. This is a separate **analytical screening construction**, not a rigorous lower/upper theorem. Its assumptions are modest initial-speed variations, no strong focusing, and no large acceleration away from the reference state. A normal shock is not the actual bow-shock solution. A reversible release to ambient has an 88 m/s energy scale, so qL at injection cannot bound all subsequent rarefaction. The true conservative decompression bound remains unresolved.

## 11. Numerical safety proposal

**PROVISIONAL SAFETY RANGE: 0.180–6.250 MPa.** Round the analytical low endpoint outward to a 10 kPa increment and high endpoint outward to a 50 kPa increment. This gives 6.678 kPa lower and 46.926 kPa upper slack beyond that particular construction, for future interpolation/root-bracket guard space. This rounding is a transparent proposal, not a measured or proved KT reconstruction error allowance. It is not sufficient evidence to approve a global transient envelope. No x2/x10 multiplier is used and no runtime clipping is proposed.

## 12–13. Liquid isentropic compression and decompression

Query `T(P,s_in)` with s_in=-993.782257318 J/(kg K); verify phase at every resulting PT state. Along a reversible adiabatic path, dT/dp at s=alphaP*T/(rho*Cp). No gas temperature is substituted and TL is not held constant.

| p (MPa) | T along s_in (K) | rho (kg/m3) | c (m/s) |
|---:|---:|---:|---:|
| 0.180000 | 299.439 | 725.587 | 1228.72 |
| 0.188330 | 299.440696 | 725.592 | 1228.77 |
| 3.000000 | 300.000000 | 727.433 | 1244.72 |
| 5.508506 | 300.490 | 729.035 | 1258.62 |
| 6.201421 | 300.623440 | 729.471 | 1262.40 |
| 6.250000 | 300.633 | 729.502 | 1262.67 |

Rounded display is illustrative; exact states, phase flags and entropy residuals are in `fitting/M6A1b2A2_reference_queries.json`. Entropy-flash API was available, so numerical integration was not substituted.

## 14. Expected/analytical liquid temperature proposals

Adiabatic does not imply isentropic. Also evaluate a limiting dissipative decompression state with h_final=h_in+U_ref²/2 and negligible final kinetic energy. At ambient pressure it gives **301.200448 K**, whereas reversible decompression gives 299.440696 K. Neither is a predicted flow trajectory; together they show why using the reversible path alone as an upper bound is incomplete.

Candidate expected interval across these screening paths: **299.440696–301.200448 K**. Candidate analytical interval over the extended pressure coordinates: **299.440364–301.201149 K**. They are conditional on these paths and the inlet total-enthalpy allowance. Gas-driven mechanical work and entropy production are not bounded by merely declaring zero heat transfer. Their global maximum is unresolved.

## 15. Numerical temperature safety proposal

**PROVISIONAL SAFETY RANGE: 299–302 K**, rounded outward to whole kelvin from all queried reversible and limiting dissipative paths. TL_ref=300 K. It is suitable for phase/derivative spot checks and a future exploratory proposal, not a guarantee for all adiabatic shock/breakup dynamics. No thermal exposure data or gas temperature was used.

## 16. Phase validity

The 0.180–6.250 MPa × 299–302 K candidate rectangle excludes vapor coexistence: psat(T) increases across the eleven queried temperatures, and its largest value is approximately 237.229 Pa, well below the 180000 Pa lower corner. The lowest-pressure hottest corner has p-psat=179762.77 Pa. Twenty-five unconstrained PT flashes plus path states show only liquid/pressure-above-critical compressed-liquid flags and positive rho,c²,Cp,Cv,kappaT. No liquid-vapor MODEL-SCOPE CONFLICT found. Missing melting-line coverage is explicitly retained; backend liquid-vapor stability is not a full experimentally validated solid-phase map. See `LIQUID_PHASE_VALIDITY_MAP.md`.

## 17–18. Inlet BC audit and pressure mismatch

See `FIVE_EQ_LIQUID_INLET_BC_REQUIREMENTS.md`. Liquid Mach=0.001713, so one acoustic characteristic leaves the subsonic inlet. The user-selected future characteristic control prescribes mdot and TL and lets pressure respond. The 3 MPa reference state and gas 0.188330 MPa may initialize different pure-material regions; a common pressure belongs to each local mixed state and does not force a global uniform pressure. Their mismatch launches waves and induces acceleration/loading. No cell may carry two independent phase pressures in the selected model.

Existing 2D mesh has a wall and no resolved circular inlet. Circular full-hole area and a 300 micrometre × 50 micrometre 2D slit area differ. Future patch geometry and represented mass-flow convention must be agreed before case implementation; no automatic scaling was performed.

## 19–20. Reference-state flow diagnostics

Mass flux=1550.650147 kg/(m2 s); convective liquid momentum flux=rhoL*UL²=3305.481068 Pa; gas convective momentum flux=rhoG*UG²=6.620690244 MPa using supplied gas rho. Conventional crossflow J=4.99265325e-4. J excludes pressure traction and pressure work and is not a complete measure of the 3 MPa reference mismatch.

HEOS viscosity at inlet=8.54837846e-4 Pa s, based on the Huber–Laesecke–Xiang correlation cited in the [official fluid page](https://coolprop.org/fluid_properties/fluids/n-Decane.html). ReL=rhoL*UL*d/mu=544.190979. The nominal user mu=0.0024 Pa s is not used for this number.

The same backend's Mulero–Cachadina–Parra saturation surface-tension correlation gives sigma(300 K)=0.02321264072 N/m; this is not a measured compressed-air/n-decane interfacial value at 3 MPa. Under a saturation-based pressure-independent sigma approximation, crossflow WeG=rhoG*UG²*d/sigma=85565.75261. Its source/scope are retained; no guessed sigma or active force is introduced.

## 21. Future grid design (design only)

| Dataset | Proposed p/T domain | Spacing/phase policy |
|---|---|---|
| A exploratory | candidate expected 0.188330–6.201421 MPa; 299.440696–301.200448 K | Include ambient, 3 MPa reference, shock/stagnation screening and path nodes; pressure refinement near decompression; coarse T coverage |
| B calibration/production comparison | approved expected/analytical union, not yet approved | Refine by rho/c/Cp and derivative residuals; independent holdouts and measured validation; no node count selected |
| C safety/extrapolation | provisional 0.180–6.250 MPa; 299–302 K | Include corners and bracket extension; strict phase flags/errors; no clipping or interpolation across coexistence |

Store p,T,rho,e,h,s,Cp,Cv,c, phase and status; add dp/drho at e, dp/de at rho, de/dp at rho, Ks, KT, alphaP,kappaT, provenance/backend hashes. Grids are not approved or generated. Current 25 spot checks are envelope QA, not a production table or training dataset. No production EOS family is selected.

## 22. Energy reference

Native CoolProp DEF is retained without any `set_reference_state` call. Its zero is fixed by stored ideal Helmholtz integration terms, including lead a1=13.9361966549, a2=-10.5265128286; not assumed to be IIR/NBP/OF7 JANAF. A numerical reproducibility anchor is saturated liquid at 273.15 K: h=-425742.187419 J/kg and s=-1191.008351 J/(kg K). Inlet h/e are negative on that zero and must not be rejected merely for that sign. `h=e+p/rho` closes to about 2.4e-6 J/kg and the acoustic derivative identity to about 1.2e-12 relative at inlet.

A constant Delta shifts both liquid h and e, while rho,c,Cp,Cv and derivatives remain unchanged. Therefore an explicit native-to-ledger offset remains mathematically possible. No numeric Delta or q is chosen, and no final solver Et is formed. Align gas JANAF and DPM liquid reference conventions later using `ENERGY_REFERENCE_AUDIT.md`; phase-change formation/latent differences are not removed by an arbitrary offset.

## 23–25. Remaining gates and solver impact

**Active solver impact NONE.** Only offline query code/package, input metadata, query evidence and documents are changed. Protected equation/Make hashes are checked; no `wmake` was needed for these offline files. Tool execution passes. No CFD, production fitting, reference production table, pressure solver, cMix, phase-mass equation or KT activation is performed.

Final evidence: 10 protected main/equation/creation/Make files have identical before/after SHA-256, recorded in `fitting/active_solver_M6A1b2A2_hash_check.json`. Query QA covers 25 rectangle spots, 8 isentropic states, 11 saturation states and 4 limiting dissipative releases. Maximum path entropy residual is 4.45425e-10 J/(kg K); maximum path acoustic-identity relative error is 1.14309e-12. Both offline tools execute successfully with the updated operating input. These are reference-library/tool checks, not numerical CFD validation.

M6A1b-2B may start only after an approved pressure/temperature/margin policy replaces provisional bounds, including how rarefaction and irreversible mechanical work outside the queried paths are handled. The current 3 MPa PT reference is closed; boundary control is selected. Safety rounding alone does not remove unresolved physical extrema. Freeze reference backend/provenance and choose backend/experiment validation protocol; absolute energy offsets may remain a separate pre-M6A2 gate but must not be falsely called resolved. Actual VOF patch implementation and 2D mapping remain later-case tasks.

## 26. Milestone update

M0–M4 COMPLETE; M5A/M5B COMPLETE active reference/design; M6A1a COMPLETE; M6A1b-1 MODEL GATE COMPLETE, constant SG REJECTED; M6A1b-2A.1 INPUT CONSISTENCY GATE PASS; M6A1b-2A.2 and overall M6A1b-2A PARTIAL / PROVISIONAL ENVELOPE; M6A1b-2B and M6A2 NOT STARTED. Stop at this report.
