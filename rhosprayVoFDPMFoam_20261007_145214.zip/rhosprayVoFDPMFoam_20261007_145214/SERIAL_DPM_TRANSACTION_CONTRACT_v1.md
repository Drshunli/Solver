# Serial DPM transaction contract v1

R2-FINAL scope: passive serial selected `r2::BoundCloud` graph; Foundation OF7/GCC11.4/C++11/DPInt32/x86-64; fixed mesh. This records the frozen implementation, not a new API or active solver integration.

## Authoritative state and owners

`r2::Transaction` uniquely owns accepted and trial `r2::State` objects. Each cloud uniquely owns adopted parcels. I1/KH newborn guards own parcels before adoption. Accepted state includes Q/P2, ordered parcel physical fields and IDs, allocator, complete native RNG/cached normal, injector/model histories, native sources, time/index/dt, carrier generation, output sequence and pending tickets. Selected configuration/thermo/mesh identity is checked by the frozen codec.

`transactionState-v1` is canonical authority. Lazy support caches, object addresses, raw object padding and test counters are excluded. The selected P2 codec requires its audited payload convention (lo=0); this certificate does not expand its representable/configuration domain.

Trial-owned query providers and interpolation caches are derived, never committed as support authority. The published carrier view is a separate owner with checked generation. Trial output tickets belong to the trial until acceptance transfers that state; accepted pending tickets remain accepted-state-owned until successful flush.

## Operations mapped to actual implementation

| Contract operation | Actual frozen entry point | Guarantee |
|---|---|---|
| begin | `r2::Transaction::begin()` | Reject nested trials/pending-output conflicts; snapshot accepted canonical state and carrier; decode into opposite trial registry role; fresh trial ledger; accepted unchanged |
| evolve | `evolve(dt)` → `act(dt, action)` | Trial-local native model evolution; temporary native Time/allocator binding; lazy provider binding; no accepted mutation/publication |
| validate | Existing `unchanged()`, unique-ID/support/model/codec assertions and carrier `view.prepare` | No new public validate method implied; invalid support/model/ownership/state causes controlled trial rejection |
| prepareCommit | `Transaction::prepare()` plus `view.prepareCommit(view.prepare(...))` | Prepare next carrier generation and sequence, construct/stage output ticket, seal trial canonical state; accepted still unchanged |
| publish | `Transaction::publish()` | Verify seal/accepted sentinel, publish prepared carrier view and swap accepted/trial ownership, destroy old graph; no fallible model work after publication point |
| commit | Contract acceptance composed of prepare then publish | Accepted generation increments exactly once; there is no added standalone commit method |
| flush accepted output | `Transaction::flush()` → `Output::publish()` | Accepted pending tickets publish once; repeated identical ticket is idempotent; clear ticket only after successful publication |
| discard | `Transaction::discard()` | Accepted sentinel checked; remove trial staging/tickets, destroy trial graph/ledger/publication, restore accepted allocator, preserve accepted carrier generation/state |

Physics acceptance and filesystem output publication are distinct. A post-commit output failure is not a physics rollback; the accepted pending ticket remains for retry. This serial harness does not certify process-crash recovery or production restart.

## Support contract

Actual movement/tet update or rebound → invalidate authority → discover actual stencil → preflight → materialize properties → model update. Generation mismatch invalidates old cache. Scalar interpolation is cell; U uses the actual current-tet cellPoint contributor weights; All=255 is the audited requirement profile.

Invalid support rejects the whole trial before invalid rho/T/Y/Cp/mu/kappa evaluation. Never fill fictitious gas, extrapolate absent gas, mask/renormalize contributors or delete a parcel as a workaround. Exact pure liquid alphaG=mG=0 is a valid Eulerian state but cannot supply a DPM gas-carrier query. P2/EOS-valid trace alphaG=1e-20 remains supported; gas fraction is not reconstructed by subtracting alphaL from one.

K1 remains frozen: new KH identity cannot inherit parent support authority; independently validate the identical valid birth pose; adopted child uses ordinary generic movement/support checks. Immediate spatial-invalid newborn-at-identical-valid-pose gate remains retired by REACHABILITY-CONTRACT REVISION. Test-only KH rejection is transaction fault injection, not physical spatial invalidity.

## Ownership as transaction safety

At audited stable transaction boundaries:

constructed = destroyed + cloud-owned-live.

No unowned live parcel, double ownership or double delete is permitted. During newborn construction before adoption a scoped guard is the sole owner; transient accounting includes guard-owned newborns. That scoped ownership is not an ownership gap. Before returning/unwinding to an audited transaction boundary the newborn is either cloud-owned or destroyed exactly once.

I1 preserves native move(false) semantics, successful sole-ownership transfer and exception unwinding. No global new/delete interception is used. Discard restores parent/child populations, IDs/allocator, RNG/cached normal, histories, sources, carrier generation and pending/output state. Rejected cleanup is not physical parcel deletion and generates no committed dmG/dmYi/dM/dEt.

## Native source/model policy

The frozen source/energy adapter and ledger remain authoritative; no new C_L term enters DPM→gas transfer. Native rebound's boundary impulse/mechanical energy is not recast as gas recoil source. ORourke limitations are retained without gas compensation or thermalization. Collision transactional retry safety does not imply collision-level conservation.

## Binary and certification boundaries

C1 is historical PARTIAL/NONDETERMINISTIC_BINARY_BLOCKER. C2 is COMPLETE/NATIVE-COMPATIBLE/SEMANTIC-NONCANONICAL under the audited ABI; object-bounded IO, authoritative-field fidelity and semantic continuation are required. Fresh raw object hashes are not semantic equality authority. Archive/source hashes here serve artifact integrity only.

No MPI, AMR/dynamic mesh, cross-ABI migration/restart, production restart, active integration or CFD validation is certified. Final aggregate results and checkpoint integrity determine R2-FINAL/T3B/T3 closure separately.
