#include "fvCFD.H"
#include "carrierEpoch.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "SLGThermo.H"
#include "basicSprayCloud.H"
#include "carrierTransaction.H"
#include "serialTransaction.H"
#include "eventLedger.H"
#include <fstream>
using namespace fiveEq;
int main(int argc,char**argv){
 if(argc!=4)return 2;
 const std::string state(argv[2]);unsigned history=state=="A"?5:state=="B"?7:9;
 Foam::fileName root(argv[1]);setenv("FOAM_CASE",argv[1],1);
 Foam::Time time(Foam::Time::controlDictName,root.path(),Foam::fileName(root.name()));
 Foam::fvMesh mesh(Foam::IOobject(Foam::fvMesh::defaultRegion,time.timeName(),time,Foam::IOobject::MUST_READ));
 auto thermo=Foam::psiReactionThermo::New(mesh);Foam::SLGThermo slg(mesh,thermo());
 Foam::volScalarField rho(Foam::IOobject("rho",time.timeName(),mesh),thermo->rho());
 Foam::volVectorField U(Foam::IOobject("U",time.timeName(),mesh),mesh,Foam::dimensionedVector("U",Foam::dimVelocity,Foam::vector(47,0,0)),"zeroGradient");U.correctBoundaryConditions();
 Foam::surfaceScalarField phi("phi",Foam::fvc::flux(rho*U));auto turb=Foam::compressible::turbulenceModel::New(rho,U,phi,thermo());Foam::dimensionedVector gravity("g",Foam::dimAcceleration,Foam::vector::zero);
 fiveEqGasThermoEvaluator gas(argv[3]);fiveEqLiquidThermoEvaluator liquid;fiveEqPrecisionRecovery recovery(gas,liquid);
 const auto names=thermo->composition().species();std::array<unsigned,3>index;for(unsigned i=0;i<3;++i)index[names[i]=="C10H22"?0:names[i]=="O2"?1:2]=i;
 PrecisionOperator op(recovery,index);PrecisionReconstruction rec(gas,liquid,op,index);
 std::vector<double>hc(3);for(unsigned i=0;i<3;++i)hc[index[i]]=gas.speciesData()[i].Hc();fiveEqDPMSourceAdapter adapter(hc);
 t3a::StableCommittedCarrierView view(thermo(),rho,U,op,gas,argv[3]);t3a::epoch=&view.token;
 std::vector<PrecisionCell>q(mesh.nCells(),rec.generate(PrecisionFraction::liquid(0,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772}));
 auto boot=view.prepareCommit(view.prepare(q));view.publishCommitNoFail(boot);view.token.publishing=false;
 auto initial=std::unique_ptr<t3a::RoleState>(new t3a::RoleState);
 initial->cloud.reset(new m8a3a::Cloud("roleA",rho,U,gravity,slg,false));time.setDeltaT(1e-6);
 {m8a3a::TrialScope passive;for(unsigned i=0;i<history;++i){++time;initial->cloud->evolve();}}
 const auto seed=initial->cloud->size();const unsigned cell=mesh.nCells()-1;
 // Collision-kernel entry preflight. Positive, finite weighted parcel mass is
 // intentionally below the unmodified native cleanup threshold. This is NOT
 // claimed as a reachable full-cloud timestep or as a collision pair event.
 // It isolates whether this actual native deletion branch has a closed ledger.
 auto&cloud=*initial->cloud;auto*p=new Foam::basicSprayParcel(mesh,mesh.C()[cell],cell);
 cloud.setParcelThermoProperties(*p,1e-6);p->T()=300;p->Y()=Foam::scalarField(1,1);
 p->rho()=cloud.composition().liquids().rho(3e6,300,p->Y());p->d()=p->d0()=.0003;p->mass0()=p->mass();p->liquidCore()=0;p->U()=U[cell];
 const double threshold=cloud.constProps().minParcelMass();p->nParticle()=.5*threshold/p->mass();const auto origProc=p->origProc(),origId=p->origId();
 cloud.addParticle(p);initial->q=q;initial->allocator=Foam::particle::particleCount_;initial->time=time.value();initial->index=time.timeIndex();
 t3a::CarrierTransaction tx(std::move(initial),view,slg,time);
 const auto carrier=view.snapshot(),accepted=m8a3bt3::cloudDump(tx.cloud());const auto allocator=Foam::particle::particleCount_;const auto gen=view.token.generation;const auto registry=mesh.Foam::objectRegistry::size();
 unsigned checks=0,failures=0;std::ofstream bad("test_failures.txt");auto check=[&](bool ok,const char*name){++checks;if(!ok){++failures;bad<<name<<'\n';}};
 check(threshold>0&&p->nParticle()>0&&p->T()==300&&p->rho()>0,"nativePositiveFiniteParcelState");
 check(p->nParticle()*p->mass()>0&&p->nParticle()*p->mass()<threshold,"belowActualNativeThreshold");
 check(op.recover(q[cell]).gasPresence==PhasePresence::PRESENT,"legalGasPresentQ");
 tx.beginTrial();auto&trial=tx.trial();auto&c=*trial.cloud;c.resetSourceTerms();
 t3b::EventLedgerV1 ledger;ledger.event="ORourke.minimumMassCleanup.collisionKernelEntry";ledger.Qbefore=q[cell];
 ledger.before.carrierSpeciesKg.assign(3,0);ledger.after.carrierSpeciesKg.assign(3,0);
 bool found=false;for(auto it=c.begin();it!=c.end();++it)if(it().origProc()==origProc&&it().origId()==origId){ledger.before=parcelEnergyState(c,it(),c.p()[cell]);found=true;}
 check(found,"actualParcelDeepCopiedIntoTrial");const auto countBefore=c.size();const auto rngBefore=m8a3a::randomSequence(c.rndGen());
 ledger.UCoeffBefore=c.UCoeff()[cell];ledger.hsCoeffBefore=c.hsCoeff()[cell];
 {Foam::basicSprayParcel::trackingData td(c);m8a3a::TrialScope passive;c.stochasticCollision().update(td,1e-6);}
 const bool rngAdvanced=rngBefore!=m8a3a::randomSequence(c.rndGen());
 const auto countAfter=c.size();found=false;for(auto it=c.begin();it!=c.end();++it)if(it().origProc()==origProc&&it().origId()==origId){ledger.after=parcelEnergyState(c,it(),c.p()[cell]);found=true;}
 check(!found&&countAfter<countBefore,"actualNativeORourkeCleanupDeletesParcel");
 ledger.native=nativeCellTransfer(c,cell);ledger.UCoeffAfter=c.UCoeff()[cell];ledger.hsCoeffAfter=c.hsCoeff()[cell];
 check(ledger.native.massKg==0&&ledger.native.sensibleEnthalpyJ==0&&ledger.native.momentumKgMS==Foam::vector::zero,"nativeCleanupPublishesNoCarrierTransfer");
 std::string reason;try{DPMExchangeContext context;context.heldPressurePa=c.p()[cell];ledger.increment=adapter.convert(ledger.native,ledger.before,ledger.after,context);ledger.converted=true;}catch(const std::exception&x){reason=x.what();}
 const bool blocker=!ledger.converted&&reason=="PARCEL_SPECIES_LEDGER_MISMATCH";
 check(blocker,"frozenAdapterDetectsUnclosedDeletionSpeciesLedger");
 ledger.status=blocker?"EVENT_LEDGER_BLOCKER":"UNEXPECTED_RESULT";ledger.adapterResult=reason;ledger.write("EVENT_LEDGER_v1.txt");
 // No Q/source repair, admission of an invented external mass sink, or commit.
 check(view.snapshot()==carrier&&view.token.generation==gen,"failedEventCarrierUnchanged");
 tx.discard();check(m8a3bt3::cloudDump(tx.cloud())==accepted,"discardRestoresAggregateCloudSentinel");
 check(view.snapshot()==carrier&&view.token.generation==gen,"discardRestoresCarrierGeneration");
 check(Foam::particle::particleCount_==allocator&&mesh.Foam::objectRegistry::size()==registry,"discardRestoresAllocatorRegistry");
 for(unsigned i=0;i<q.size();++i)check(exactCellEqual(q[i],tx.accepted().q[i]),"discardQExact");
 std::ofstream result("test_results.json");result<<std::setprecision(17)<<"{\"state\":\""<<state<<"\",\"status\":\"PARTIAL / EVENT_LEDGER_BLOCKER\",\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"seedSteps\":"<<history<<",\"seedParcels\":"<<seed<<",\"countBefore\":"<<countBefore<<",\"countAfter\":"<<countAfter<<",\"thresholdKg\":"<<threshold<<",\"removedMassKg\":"<<ledger.before.massKg-ledger.after.massKg<<",\"nativeMassTransferKg\":"<<ledger.native.massKg<<",\"adapterReason\":\""<<reason<<"\",\"committedLedgerIncrement\":0,\"acceptedCommits\":0,\"carrierGenerationUnchanged\":true,\"rngAdvancedInTrial\":"<<(rngAdvanced?"true":"false")<<",\"fullCloudTimeStepProof\":false,\"collisionPairProof\":false,\"completeCodec\":false,\"noCFD\":true}\n";
 return failures?1:0;
}
