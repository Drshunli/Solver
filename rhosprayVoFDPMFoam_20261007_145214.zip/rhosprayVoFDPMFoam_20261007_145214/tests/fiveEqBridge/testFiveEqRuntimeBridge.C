#include "fiveEqRuntimeBridge.H"
#include "fiveEqRecoveryCounters.H"
#include "IFstream.H"
#include <functional>
#include <fstream>
#include <iostream>
#include <map>
using namespace fiveEq;
int main(int argc,char** argv){
    if(argc!=3)return 2;
    Foam::IFstream stream(argv[1]);Foam::dictionary data(stream);
    Foam::IFstream reactionStream(argv[2]);Foam::dictionary reaction(reactionStream);
    const Foam::wordList actualNames(reaction.lookup("species"));
    fiveEqGasThermoEvaluator gas(argv[1]);fiveEqLiquidThermoEvaluator liquid;fiveEqStateRecovery kernel(gas,liquid);
    fiveEqRuntimeBridge bridge(argv[1],actualNames,data);
    std::map<std::string,unsigned> counts,failures;std::ofstream log("test_failures.txt");
    auto demand=[](bool ok,const char* text){if(!ok)throw RecoveryError(text);};
    auto test=[&](std::string name,std::function<void()> call){++counts[name];try{call();}catch(const std::exception& e){++failures[name];log<<name<<": "<<e.what()<<'\n';}};
    auto makeInput=[&](double a,double p=3e6,double TG=800,double TL=300){
        auto q=kernel.generate(a,p,TG,TL,{{2013.039,-11,7}},{0,.228,.772});
        Foam::scalarField y(3,0);for(Foam::label j=0;j<actualNames.size();++j)y[j]=actualNames[j]=="N2"?.772:actualNames[j]=="O2"?.228:0;
        return fiveEqRuntimeInput(q.alphaL,q.mG,q.mL,Foam::vector(q.M[0],q.M[1],q.M[2]),q.Et,y);
    };
    for(double a:{0.,1e-12,.01,.5,.99,1.})test("phaseRecovery",[&]{
        auto q=makeInput(a);if(a==1)q.YG=Foam::scalarField();
        fiveEqRuntimeState s;fiveEqRecoveryDiagnostic d;demand(bridge.tryRecover(q,s,d),"valid recovery failed");
        demand(std::abs(s.thermo.p-3e6)<.02&&std::abs(s.U.x()-2013.039)<1e-10&&std::abs(s.U.y()+11)<1e-10,"scalar/vector conversion mismatch");
        demand(d.status==RecoveryStatus::SUCCESS&&d.code==RecoveryCode::OK,"success diagnostic");
        if(a==0)demand(s.thermo.calls.liquid==0,"pure gas liquid call");
        if(a==1)demand(s.thermo.calls.gas==0,"pure liquid gas call");
    });
    Foam::wordList permuted(3);permuted[0]="N2";permuted[1]="C10H22";permuted[2]="O2";
    test("speciesPermutation",[&]{fiveEqRuntimeBridge other(argv[1],permuted,data);auto q=makeInput(.5);q.YG[0]=.772;q.YG[1]=0;q.YG[2]=.228;
        auto s=other.recoverOrFail(q);demand(std::abs(s.thermo.p-3e6)<.02,"permuted recovery");});
    test("missingSpecies",[&]{auto names=actualNames;names[0]="WRONG";bool bad=false;try{fiveEqRuntimeBridge other(argv[1],names,data);}catch(const RecoveryError&){bad=true;}demand(bad,"missing species accepted");});
    test("duplicateSpecies",[&]{auto names=actualNames;names[0]=names[1];bool bad=false;try{fiveEqRuntimeBridge other(argv[1],names,data);}catch(const RecoveryError&){bad=true;}demand(bad,"duplicate species accepted");});
    test("molecularWeightMismatch",[&]{auto modified=data;modified.subDict("N2").subDict("specie").set("molWeight",29.);bool bad=false;try{fiveEqRuntimeBridge other(argv[1],actualNames,modified);}catch(const RecoveryError&){bad=true;}demand(bad,"MW mismatch accepted");});
    test("missingJANAF",[&]{auto modified=data;modified.subDict("N2").subDict("thermodynamics").remove("highCpCoeffs");bool bad=false;try{fiveEqRuntimeBridge other(argv[1],actualNames,modified);}catch(const RecoveryError&){bad=true;}demand(bad,"missing JANAF accepted");});
    test("JANAFMismatch",[&]{auto modified=data;modified.subDict("N2").subDict("thermodynamics").set("Tcommon",1001.);bool bad=false;try{fiveEqRuntimeBridge other(argv[1],actualNames,modified);}catch(const RecoveryError&){bad=true;}demand(bad,"JANAF mismatch accepted");});
    auto invalid=[&](const std::string& name,fiveEqRuntimeInput q,RecoveryCode expected){test(name,[&]{fiveEqRuntimeState s;fiveEqRecoveryDiagnostic d;demand(!bridge.tryRecover(q,s,d),"invalid accepted");demand(d.code==expected,"wrong reason code");demand(s.thermo.recoveryMode==RecoveryMode::INVALID,"failed output stale");demand(!formatDiagnostic(d).empty(),"diagnostic formatting empty");});};
    auto q=makeInput(.5);q.YG[0]=-.1;invalid("negativeY",q,RecoveryCode::INVALID_COMPOSITION);
    q=makeInput(.5);q.YG*=.5;invalid("weightedY",q,RecoveryCode::INVALID_COMPOSITION);
    q=makeInput(.5);q.YG[1]+=.01;invalid("sumY",q,RecoveryCode::INVALID_COMPOSITION);
    test("roundoffY",[&]{auto q=makeInput(.5);q.YG[0]+=4*std::numeric_limits<double>::epsilon();auto before=q.YG;auto s=bridge.recoverOrFail(q);demand(std::abs(s.thermo.p-3e6)<.02&&q.YG[0]==before[0],"roundoff sum/no mutation");});
    q=makeInput(.5);q.alphaL.value()=-.1;invalid("invalidAlpha",q,RecoveryCode::INVALID_ALPHA);
    q=makeInput(.5);q.mG.value()=-1;invalid("negativeMass",q,RecoveryCode::NEGATIVE_PARTIAL_MASS);
    q=makeInput(.5);q.mG.value()=q.mL.value()=0;invalid("zeroDensity",q,RecoveryCode::INVALID_TOTAL_DENSITY);
    q=makeInput(.5);q.Et.value()=std::numeric_limits<double>::quiet_NaN();invalid("nonfinite",q,RecoveryCode::NONFINITE_STATE);
    q=makeInput(.5);q.alphaL.value()=1e-16;invalid("phasePresence",q,RecoveryCode::PHASE_PRESENCE_INCONSISTENT);
    q=makeInput(.5);q.mG.value()=1e6;invalid("noInterval",q,RecoveryCode::NO_COMMON_PRESSURE_INTERVAL);
    q=makeInput(.5);q.Et.value()=-1e12;invalid("noRoot",q,RecoveryCode::NO_PRESSURE_ROOT);
    q=makeInput(.5);q.mL.value()=1e8;invalid("liquidInvalid",q,RecoveryCode::LIQUID_EOS_INVALID);
    test("noRootProgress",[&]{auto q=makeInput(.5);q.Et.value()=-1e12;fiveEqRuntimeState s;fiveEqRecoveryDiagnostic d;demand(!bridge.tryRecover(q,s,d),"no root accepted");demand(d.bracketAvailable&&d.residualAvailable&&d.pressureAvailable&&d.recoveryMode==RecoveryMode::MIXED,"lost failure progress");});
    test("invalidDimensions",[&]{auto q=makeInput(.5);q.Et.dimensions().reset(Foam::dimensionSet(0,0,0,0,0,0,0));fiveEqRuntimeState s;fiveEqRecoveryDiagnostic d;demand(!bridge.tryRecover(q,s,d)&&d.code==RecoveryCode::INVALID_DIMENSIONS,"dimension mismatch accepted");});
    for(double pguess:{3e6*1.02,-1.,1e20,std::numeric_limits<double>::quiet_NaN()})test("pressureGuess",[&]{auto q=makeInput(.5);fiveEqRuntimeState s;fiveEqRecoveryDiagnostic d;PressureGuess g;g.supplied=true;g.value=pguess;demand(bridge.tryRecover(q,s,d,g),"guess recovery");demand(std::abs(s.thermo.p-3e6)<.02,"guess changed root");if(!std::isfinite(pguess)||pguess<0||pguess>1e12)demand(d.guessIgnored,"bad guess not flagged");});
    test("cellFaceDeterminism",[&]{auto q=makeInput(.5);fiveEqRuntimeState a,b,c;fiveEqRecoveryDiagnostic da,db,dc;demand(bridge.recoverCellState(q,a,da)&&bridge.recoverFaceState(q,b,db)&&bridge.recoverCellState(q,c,dc),"wrapper failure");demand(a.thermo.p==b.thermo.p&&a.thermo.p==c.thermo.p&&da.iterations==dc.iterations&&da.context!=db.context,"wrapper mathematics diverged");});
    test("callerCounters",[&]{fiveEqRecoveryCounters a,b;for(double alpha:{0.,.5,1.}){fiveEqRuntimeState s;fiveEqRecoveryDiagnostic d;bridge.tryRecover(makeInput(alpha),s,d);a.record(d);}auto bad=makeInput(.5);bad.alphaL.value()=-1;fiveEqRuntimeState s;fiveEqRecoveryDiagnostic d;bridge.tryRecover(bad,s,d);b.record(d);a.merge(b);demand(a.nPureGas==1&&a.nMixed==1&&a.nPureLiquid==1&&a.nInvalid==1,"counter merge");});
    std::ofstream out("test_results.json");out<<"{\"groups\":{";bool first=true;unsigned nfail=0,total=0;for(auto item:counts){if(!first)out<<',';first=false;out<<'"'<<item.first<<"\":{\"count\":"<<item.second<<",\"failures\":"<<failures[item.first]<<'}';nfail+=failures[item.first];total+=item.second;}out<<"},\"total\":"<<total<<",\"failures\":"<<nfail<<"}\n";
    std::cout<<"Bridge checks="<<total<<" failures="<<nfail<<'\n';return nfail?1:0;
}
