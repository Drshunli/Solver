# M5C.2 R0 prerequisite assessment

This executable is a standalone periodic finite-volume algebra harness. It
constructs no fvMesh, cloud or CFD case. Load local Foundation OpenFOAM 7, then:

```sh
cd /mnt/d/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqAdmissibility
wmake
./testFiveEqAdmissibility /mnt/d/DATA/Solver/300_2D/constant/thermal.dat \
 /mnt/d/DATA/Solver/300_2D/constant/reactions
```

Exit code 0 requires all R0 update scenarios to pass; 1 records a failed
admissibility gate; 2 denotes an implementation assertion/exception. The present
result is **1, not PASS**. Compilation with -Werror passes.

All initial states use actual gas JANAF and frozen ndecane_gibbs_v1. MaterialCell
stores alpha,mG,mL,three momentum components,Et and the three gas species masses
in the supplied runtime order. There is no default air in the library, independent
pressure/temperature owner or Eint>0 surrogate. Fixed three-species size matches
the audited case; a future general species-count interface is not claimed.

405 uniform face/update cases span pure and near-pure phases; alpha includes
1e-12/1e-10/1e-8/1e-6 and complements. 42 periodic scenarios use 20/60/200 cells.
20-cell ordinary cases request 100 steps; 60/200-cell cases request 10. HARD edge
cases request one step. Trial states are committed only if ALL cells recover.
Failed trials are preserved in CSV and never repaired. All initial states and
all R0 faces in the evolving stencils are valid before the failed updates.

HARD scan fractions 1 through 1e-6 are diagnostics, not automatic timestep
backtracking. Thermodynamic tangents use derivatives at legally queried states
and do not extrapolate EOS. Trace witnesses compare actual failed contact states
against independently queried phase densities/energy. Root witnesses evaluate
both ends of the real legal common-pressure interval.

No R1/R2 code or coupled flux limiter is introduced: the user's section 3 requires
R0 to pass positivity/alpha/EOS-domain tests before high-order limiter work.
R0 fails that prerequisite. No M5C.3, M8A, M6B or active solver modification.
Artifacts retain failures instead of widening thresholds or removing stress tests.
