# M5C.2A versioned standalone regression

This is a v2 build/run directory. Original v1 sources and reports remain in the sibling directory and historical checkpoint. Load the local Foundation OF7 environment and run wmake here.

Executable arguments: recovery uses the absolute thermal.dat path only; bridge and flux use thermal.dat plus reactions; admissibility also uses the absolute historical_v1_replay/tests/fiveEqAdmissibility/original_paths.csv path. Inputs come from 300_2D/constant. Output CSV/JSON files stay here. No CFD is run.

Expected v2 exit code:0. The isolated historical-v1 admissibility replay intentionally exits1 because it reproduces the original21 update failures. Never run historical v1 executable objects against the current v2 shared-library ABI.

See ../../M5C2A_R0_ADMISSIBILITY_CLOSURE.md for scopes, counts and controlled EOS-domain stops. A controlled stop is distinct from completion of requested evolution steps.
