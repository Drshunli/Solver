#include "fiveEqThermodynamicTimeStep.H"
#include "IFstream.H"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <map>
#include <chrono>
#include <sstream>
using namespace fiveEq;
int main(int argc,char** argv){
    if(argc!=4)return 2;
    Foam::IFstream ds(argv[1]);Foam::dictionary data(ds);
    Foam::IFstream rs(argv[2]);Foam::dictionary reaction(rs);Foam::wordList names(reaction.lookup("species"));
    fiveEqRuntimeBridge bridge(argv[1],names,data);fiveEqKTFaceFluxKernel flux(bridge,names.size());
    fiveEqGasThermoEvaluator gas(argv[1]);fiveEqLiquidThermoEvaluator liquid;fiveEqStateRecovery eos(gas,liquid);
    std::array<unsigned,3> canonicalIndex;
    for(unsigned j=0;j<3;++j){unsigned k=names[j]=="C10H22"?0:names[j]=="O2"?1:2;canonicalIndex[k]=j;}
    unsigned checks=0,bugs=0,updateFailures=0,initialFailures=0,faceFailures=0,completed=0;
    unsigned faces=0,gasQueries=0,liquidQueries=0,thermoQueries=0,retries=0,controlledStops=0;
    double maxRhoG=0,maxRhoL=0,minThermoRatio=1;
    std::ofstream continuation("continuation.csv"),events("thermo_events.csv"),trace("trace_drift.csv");
    continuation<<"case,N,step,cell,lambda,valid,code,alpha,mG,mL,Et,Eint,pMin,pMax,Rmin,Rmax,p,TG,TL,cMix\n";
    events<<"case,N,step,cell,dtCandidate,lambdaValid,lambdaInvalid,dtThermo,queries,class\n";
    trace<<"case,N,step,cell,alpha,mL,rhoGrelative,rhoLrelative,pressureRelative\n";
    continuation<<std::setprecision(17);events<<std::setprecision(17);trace<<std::setprecision(17);
    std::map<std::string,unsigned> controls;
    std::ofstream log("test_failures.txt"),rows("r0_cases.csv"),dts("timestep_samples.csv"),fail("invalid_update_states.csv"),edges("hard_edge_dt_scan.csv");
    std::ofstream witnesses("trace_presence_witness.csv"),tangents("hard_edge_tangents.csv");
    std::ofstream roots("root_interval_witness.csv");
    roots<<"case,N,step,cell,p_min,p_max,internal_energy,mixture_energy_at_p_min,mixture_energy_at_p_max,residual_min,residual_max\n";
    witnesses<<"case,N,step,cell,alphaL,mL,alpha_tolerance,mass_tolerance,relative_rhoL_error,relative_rhoG_error,energy_residual_scaled\n";
    tangents<<"case,N,p,T,rho_dot,e_dot,p_dot,T_dot,outward_pressure,outward_temperature\n";
    rows<<"case,N,requested_steps,completed_steps,outcome,issue,recovery_code,dt,alpha_min,alpha_max,pressure_relative,conservation_scaled,alpha_balance,elapsed_seconds,accepted_integral_conservation,accepted_alpha_balance,face_pressure_relative,velocity_error\n";
    dts<<"case,step,cell,dtAcoustic,dtAlpha,dtMG,dtML,dtSpecies,dtVolume,joint,control\n";
    fail<<"case,cell,step,alpha,mG,mL,Mx,My,Mz,Et,mY0,mY1,mY2,issue,recovery_code,bracket_min,bracket_max,pressure,residual\n";
    edges<<"case,dt_fraction,dt,linear_admissible,thermo_admissible,issue,recovery_code\n";
    for(auto* s:{&rows,&dts,&fail,&edges,&witnesses,&tangents,&roots})*s<<std::setprecision(17);
    auto demand=[&](bool good,std::string why){++checks;if(!good){++bugs;log<<why<<'\n';}};
    auto generate=[&](double a,double p,double Tg,double Tl,double ux,double fuel=0){
        std::vector<double> Y={fuel,.228*(1-fuel),.772*(1-fuel)};
        auto q=eos.generate(a,p,Tg,Tl,{{ux,0,0}},Y);MaterialCell c={{q.alphaL,q.mG,q.mL,q.M[0],q.M[1],q.M[2],q.Et,0,0,0}};
        for(unsigned j=0;j<3;++j){unsigned k=names[j]=="C10H22"?0:names[j]=="O2"?1:2;c[7+j]=q.mG*Y[k];}return c;
    };
    {auto bad=generate(1,3e6,800,300,0);bad[7]=1;
        demand(checkMaterialCell(bad,bridge).issue==AdmissibilityIssue::SPECIES,"absent gas has species mass");
        bool rejected=false;try{runtimeInput(bad);}catch(const std::invalid_argument&){rejected=true;}
        demand(rejected,"conversion silently discarded species mass");}
    // Requested near-pure states without dropping a phase; uniform R0 update.
    unsigned uniformCases=0,uniformFailures=0;
    std::ofstream uniform("r0_uniform_faces.csv");uniform<<"alpha,p,TG,TL,cell_valid,face_valid,update_valid,code\n"<<std::setprecision(17);
    for(double a:{0.,1e-12,1e-10,1e-8,1e-6,.01,.1,.5,.9,.99,1-1e-6,1-1e-8,1-1e-10,1-1e-12,1.})
    for(double p:{1e5,3e6,8e6})for(double Tg:{400.,800.,1400.})for(double Tl:{295.,300.,305.}){
        auto q=generate(a,p,Tg,Tl,17,.01);auto c=checkMaterialCell(q,bridge);
        auto f=reconstructR0(q,q,flux,Foam::vector(1,0,0),5);
        bool u=false;unsigned code=unsigned(c.diagnostic.code);
        if(f.status==FaceFluxStatus::OK){auto b=explicitTimeStepBounds(q,1,f,f,5,5);auto trial=explicitTrial(q,1,b.joint,f,f,5,5);auto d=checkMaterialCell(trial.q,bridge);u=d.issue==AdmissibilityIssue::OK;code=unsigned(d.diagnostic.code);}
        ++uniformCases;if(c.issue!=AdmissibilityIssue::OK||f.status!=FaceFluxStatus::OK||!u)++uniformFailures;
        demand(c.issue==AdmissibilityIssue::OK&&f.status==FaceFluxStatus::OK&&u,"uniform R0 state");
        uniform<<a<<','<<p<<','<<Tg<<','<<Tl<<','<<(c.issue==AdmissibilityIssue::OK)<<','<<(f.status==FaceFluxStatus::OK)<<','<<u<<','<<code<<'\n';
    }
    std::vector<std::string> cases={"stationaryContact","movingContact","nearPureContact","smoothMaterial","compression","expansion","gasShock","mixedShock","ALEContact","ALEUniform","hardTUpperCompression","hardTLowerExpansion","hardPUpperCompression","hardPLowerExpansion"};
    for(const auto& name:cases)for(unsigned N:{20u,60u,200u}){
        auto started=std::chrono::steady_clock::now();unsigned maxSteps=N==20?100:10;
        const bool edge=name.find("hard")==0;
        if(edge)maxSteps=1;
        std::vector<MaterialCell> q;std::vector<double> V(N,1),mesh(N,0);bool initialOK=true;
        unsigned code=0,issue=0,steps=0;double dt=0,amin=1,amax=0,pErr=0,consErr=0,alphaErr=0;
        double facePErr=0,uErr=0,acceptedSources=0,integralErr=0,acceptedAlphaErr=0;
        std::array<double,10> initialSum={{0,0,0,0,0,0,0,0,0,0}},initialScale=initialSum;
        std::string outcome="PASS";
        const bool contact=name=="stationaryContact"||name=="movingContact"||name=="nearPureContact"||name=="smoothMaterial"||name=="ALEContact"||name=="ALEUniform";
        const double Ureference=name=="movingContact"||name=="ALEContact"?47:name=="ALEUniform"?29:0;
        try{
            for(unsigned i=0;i<N;++i){double x=double(i)/N,a=i<N/2?0.:1.,p=3e6,Tg=800,Tl=300,u=0;
                if(name=="movingContact"||name=="ALEContact")u=47;
                if(name=="nearPureContact")a=i<N/2?1e-12:1-1e-12;
                if(name=="smoothMaterial")a=.5+.45*std::sin(6.283185307179586*x);
                if(name=="compression"||name=="expansion"){a=.5;u=(name=="compression"?-1:1)*.1*std::sin(6.283185307179586*x);}
                if(name=="gasShock"){a=0;p=i<N/2?188330.307:5.5e6;Tg=i<N/2?400:2100;u=i<N/2?2013.039:450;}
                if(name=="mixedShock"){a=i<N/2?.01:.99;p=i<N/2?1e6:8e6;Tg=i<N/2?400:1400;Tl=i<N/2?295:305;u=i<N/2?20:-20;}
                if(name=="ALEUniform"){a=.37;u=29;}
                if(name.find("ALE")==0)mesh[i]=5*std::sin(6.283185307179586*(i+.3)/N);
                if(edge){a=1;u=0;if(name=="hardTUpperCompression")Tl=320;if(name=="hardTLowerExpansion")Tl=285;
                    if(name=="hardPUpperCompression")p=12e6;
                    if(name=="hardPLowerExpansion")p=50000;
                    if(i==N/2-1)u=name.find("Compression")!=std::string::npos?10:-10;
                    if(i==N/2+1)u=name.find("Compression")!=std::string::npos?-10:10;}
                q.push_back(generate(a,p,Tg,Tl,u,name=="gasShock"?.02:0));
                amin=std::min(amin,q.back()[0]);amax=std::max(amax,q.back()[0]);
                auto v=checkMaterialCell(q.back(),bridge);demand(v.issue==AdmissibilityIssue::OK,"initial state: "+name);
                if(v.issue!=AdmissibilityIssue::OK){initialOK=false;code=unsigned(v.diagnostic.code);issue=unsigned(v.issue);break;}
            }
            if(!initialOK){++initialFailures;outcome="INITIAL_INVALID";}
            if(initialOK)for(unsigned i=0;i<N;++i)for(unsigned j=0;j<10;++j){initialSum[j]+=V[i]*q[i][j];initialScale[j]+=std::abs(V[i]*q[i][j]);}
            for(unsigned step=0;initialOK&&step<maxSteps;++step){
                std::vector<fiveEqKTFaceFlux> f;bool facesOK=true;
                for(unsigned i=0;i<N;++i){f.push_back(reconstructR0(q[i],q[(i+1)%N],flux,Foam::vector(1,0,0),mesh[i]));
                    if(f.back().status!=FaceFluxStatus::OK){facesOK=false;break;}
                    ++faces;gasQueries+=f.back().left.thermo.calls.gas+f.back().right.thermo.calls.gas;
                    liquidQueries+=f.back().left.thermo.calls.liquid+f.back().right.thermo.calls.liquid;
                    if(contact){const auto& face=f.back();facePErr=std::max({facePErr,std::abs(face.left.thermo.p-3e6)/3e6,std::abs(face.right.thermo.p-3e6)/3e6});
                        demand(std::abs(face.left.thermo.p-3e6)/3e6<1e-8&&std::abs(face.right.thermo.p-3e6)/3e6<1e-8,"R0 contact face pressure");}}
                if(!facesOK){++faceFailures;outcome="FACE_INVALID";break;}
                std::vector<TimeStepBounds> bounds;dt=1e100;unsigned controller=0;
                for(unsigned i=0;i<N;++i){unsigned l=(i+N-1)%N;bounds.push_back(explicitTimeStepBounds(q[i],V[i],f[l],f[i],mesh[l],mesh[i]));
                    if(bounds.back().joint<dt){dt=bounds.back().joint;controller=i;}
                    if(step==0||step==maxSteps-1){auto b=bounds.back();dts<<name<<','<<step<<','<<i<<','<<b.acoustic<<','<<b.alpha<<','<<b.mG<<','<<b.mL<<','<<b.species<<','<<b.volume<<','<<b.joint<<','<<b.controlling<<'\n';}}
                ++controls[bounds[controller].controlling];
                if(!(dt>0&&std::isfinite(dt))){outcome="ZERO_TIMESTEP";++updateFailures;break;}
                const auto committedQ=q;const auto committedV=V;
                const double candidateDt=dt;double thermoDt=dt;bool domainStop=false;
                for(unsigned i=0;i<N;++i){unsigned l=(i+N-1)%N;
                    double seedP=std::numeric_limits<double>::quiet_NaN(),seedT=seedP;
                    if(edge&&step==0){seedP=name=="hardPUpperCompression"?12e6:name=="hardPLowerExpansion"?50000:3e6;
                        seedT=name=="hardTUpperCompression"?320:name=="hardTLowerExpansion"?285:300;}
                    if(pureLiquidOutwardBoundary(q[i],V[i],f[l],f[i],mesh[l],mesh[i],bridge,liquid,seedP,seedT)
                        ||mixedOutwardBoundary(q[i],V[i],f[l],f[i],mesh[l],mesh[i],bridge,gas,liquid,canonicalIndex)){
                        domainStop=true;events<<name<<','<<N<<','<<step<<','<<i<<','<<candidateDt<<",0,0,0,0,PHYSICAL_EOS_DOMAIN_ESCAPE\n";continue;
                    }
                    auto observer=[&](double lambda,const ExplicitCellTrial& t,const CellAdmissibility& v){
                        if(name!="mixedShock"||step!=8||(i!=N/2-3))return;
                        double lo=v.diagnostic.pBracketMin,hi=v.diagnostic.pBracketMax;
                        const double r=t.q[1]+t.q[2],internal=t.q[6]-(t.q[3]*t.q[3]+t.q[4]*t.q[4]+t.q[5]*t.q[5])/(2*r);
                        double fl=std::numeric_limits<double>::quiet_NaN(),fh=fl;
                        try{std::vector<double> Y(3);for(unsigned j=0;j<3;++j){unsigned k=names[j]=="C10H22"?0:names[j]=="O2"?1:2;Y[k]=t.q[7+j]/t.q[1];}
                            auto energy=[&](double p){return t.q[1]*gas.evaluateRhoP(t.q[1]/(1-t.q[0]),p,Y).e+t.q[2]*liquid.evaluateRhoP(t.q[2]/t.q[0],p).e;};
                            fl=energy(lo)-internal;fh=energy(hi)-internal;
                        }catch(const std::exception&){}
                        continuation<<name<<','<<N<<','<<step<<','<<i<<','<<lambda<<','<<(v.issue==AdmissibilityIssue::OK)<<','<<unsigned(v.diagnostic.code);
                        for(unsigned j=0;j<3;++j)continuation<<','<<t.q[j];
                        continuation<<','<<t.q[6]<<','<<internal<<','<<lo<<','<<hi<<','<<fl<<','<<fh<<','<<v.recovered.thermo.p<<','<<v.recovered.thermo.TG<<','<<v.recovered.thermo.TL<<','<<v.recovered.thermo.cMix<<'\n';
                    };
                    auto b=connectedThermodynamicStep(q[i],V[i],candidateDt,f[l],f[i],mesh[l],mesh[i],bridge,observer);
                    thermoQueries+=b.queries;
                    if(name=="mixedShock"&&step==8&&i==N/2-3){auto endpoint=explicitTrial(q[i],V[i],candidateDt,f[l],f[i],mesh[l],mesh[i]);observer(1,endpoint,checkMaterialCell(endpoint.q,bridge));}
                    if(b.exitFound){++retries;thermoDt=std::min(thermoDt,b.dtThermo);
                        events<<name<<','<<N<<','<<step<<','<<i<<','<<candidateDt<<','<<b.lambdaValid<<','<<b.lambdaInvalid<<','<<b.dtThermo<<','<<b.queries<<",NUMERICAL_THERMO_INADMISSIBILITY\n";}
                }
                demand(q==committedQ&&V==committedV,"continuation changed committed state");
                if(domainStop){outcome="CONTROLLED_EOS_STOP";++controlledStops;break;}
                dt=thermoDt;minThermoRatio=std::min(minThermoRatio,dt/bounds[controller].acoustic);
                if(!(dt>0&&std::isfinite(dt))){outcome="INTERIOR_ZERO_THERMO_STEP";++updateFailures;break;}
                std::vector<ExplicitCellTrial> trial;std::vector<CellAdmissibility> valid;bool updateOK=true;
                std::array<double,10> delta={{0,0,0,0,0,0,0,0,0,0}},scale={{0,0,0,0,0,0,0,0,0,0}};double sources=0;
                for(unsigned i=0;i<N;++i){unsigned l=(i+N-1)%N;trial.push_back(explicitTrial(q[i],V[i],dt,f[l],f[i],mesh[l],mesh[i]));
                    auto& s=trial.back();valid.push_back(checkMaterialCell(s.q,bridge));auto& v=valid.back();
                    for(unsigned j=0;j<10;++j){delta[j]+=s.volume*s.q[j]-V[i]*q[i][j];scale[j]+=std::abs(s.volume*s.q[j])+std::abs(V[i]*q[i][j]);}sources+=s.alphaSourceIntegral;
                    amin=std::min(amin,s.q[0]);amax=std::max(amax,s.q[0]);
                    demand(s.q[0]>=0&&s.q[0]<=1,"alpha bound: "+name);demand(s.q[1]>=0&&s.q[2]>=0,"mass bound: "+name);
                    for(unsigned j=0;j<3;++j)demand(s.q[7+j]>=0,"species positivity: "+name);
                    demand(std::abs(s.q[7]+s.q[8]+s.q[9]-s.q[1])/std::max(1.,s.q[1])<1e-12,"species closure: "+name);
                    if(v.issue!=AdmissibilityIssue::OK){updateOK=false;issue=unsigned(v.issue);code=unsigned(v.diagnostic.code);
                        fail<<name<<','<<i<<','<<step;for(double value:s.q)fail<<','<<value;
                        fail<<','<<issue<<','<<code<<','<<v.diagnostic.pBracketMin<<','<<v.diagnostic.pBracketMax<<','<<v.diagnostic.finalPressure<<','<<v.diagnostic.residual<<'\n';
                        if(v.diagnostic.code==RecoveryCode::PHASE_PRESENCE_INCONSISTENT&&s.q[0]>0&&s.q[0]<1){
                            const auto g=gas.evaluatePT(3e6,800,{0,.228,.772});const auto li=liquid.evaluatePT(3e6,300);
                            double rho=s.q[1]+s.q[2],kin=(s.q[3]*s.q[3]+s.q[4]*s.q[4]+s.q[5]*s.q[5])/(2*rho);
                            double internal=s.q[6]-kin,ref=s.q[1]*g.e+s.q[2]*li.e;
                            double eps=64*std::numeric_limits<double>::epsilon();
                            witnesses<<name<<','<<N<<','<<step<<','<<i<<','<<s.q[0]<<','<<s.q[2]<<','<<eps<<','<<eps*rho<<','
                                <<std::abs(s.q[2]/s.q[0]-li.rho)/li.rho<<','<<std::abs(s.q[1]/(1-s.q[0])-g.rho)/g.rho<<','
                                <<std::abs(ref-internal)/std::max(std::abs(internal),rho*1e5)<<'\n';
                        }
                        if(v.diagnostic.code==RecoveryCode::NO_PRESSURE_ROOT&&v.diagnostic.bracketAvailable&&s.q[0]>0&&s.q[0]<1){
                            std::vector<double> Y(3,0);for(unsigned j=0;j<3;++j){unsigned k=names[j]=="C10H22"?0:names[j]=="O2"?1:2;Y[k]=s.q[7+j]/s.q[1];}
                            const double rho=s.q[1]+s.q[2],internal=s.q[6]-(s.q[3]*s.q[3]+s.q[4]*s.q[4]+s.q[5]*s.q[5])/(2*rho);
                            const double lo=v.diagnostic.pBracketMin,hi=v.diagnostic.pBracketMax;
                            auto mixEnergy=[&](double p){return s.q[1]*gas.evaluateRhoP(s.q[1]/(1-s.q[0]),p,Y).e+s.q[2]*liquid.evaluateRhoP(s.q[2]/s.q[0],p).e;};
                            double low=mixEnergy(lo),high=mixEnergy(hi);
                            roots<<name<<','<<N<<','<<step<<','<<i<<','<<lo<<','<<hi<<','<<internal<<','<<low<<','<<high<<','<<low-internal<<','<<high-internal<<'\n';
                        }
                    }else if(contact){
                        const auto& th=v.recovered.thermo;
                        if(s.q[0]>0&&s.q[0]<1&&name!="ALEUniform"){
                            double eg=std::abs(th.rhoG/gas.evaluatePT(3e6,800,{0,.228,.772}).rho-1);
                            double el=std::abs(th.rhoL/liquid.evaluatePT(3e6,300).rho-1);
                            maxRhoG=std::max(maxRhoG,eg);maxRhoL=std::max(maxRhoL,el);
                            if(s.q[0]<1e-8||1-s.q[0]<1e-8)trace<<name<<','<<N<<','<<step<<','<<i<<','<<s.q[0]<<','<<s.q[2]<<','<<eg<<','<<el<<','<<std::abs(th.p-3e6)/3e6<<'\n';
                        }
                        pErr=std::max(pErr,std::abs(v.recovered.thermo.p-3e6)/3e6);demand(std::abs(v.recovered.thermo.p-3e6)/3e6<1e-8,"contact pressure: "+name);
                        uErr=std::max(uErr,Foam::mag(v.recovered.U-Foam::vector(Ureference,0,0)));demand(uErr<1e-7,"contact velocity: "+name);}
                }
                for(unsigned j=1;j<10;++j){double e=std::abs(delta[j])/std::max(1.,scale[j]);consErr=std::max(consErr,e);demand(e<5e-12,"conservation: "+name);}
                alphaErr=std::max(alphaErr,std::abs(delta[0]-sources));demand(std::abs(delta[0]-sources)<5e-12*N,"alpha source ledger: "+name);
                if(edge){unsigned i=N/2,l=i-1;
                    const auto base=liquid.recoverRhoE(q[i][2],q[i][6]/q[i][2]);
                    const double rhoDot=-(f[i].mLPhi-f[l].mLPhi)/V[i];
                    const double energyDot=-(f[i].energyPhi-f[l].energyPhi)/V[i];
                    const double eDot=(energyDot-base.e*rhoDot)/base.rho;
                    const double pDot=base.dpDrhoE*rhoDot+base.dpDeRho*eDot;
                    const double eRhoT=(base.p-base.T*base.Cv/base.beta)/(base.rho*base.rho);
                    const double TDot=(eDot-eRhoT*rhoDot)/base.Cv;
                    bool outwardP=(name=="hardPUpperCompression"&&pDot>0)||(name=="hardPLowerExpansion"&&pDot<0);
                    bool outwardT=(name=="hardTUpperCompression"&&TDot>0)||(name=="hardTLowerExpansion"&&TDot<0);
                    tangents<<name<<','<<N<<','<<base.p<<','<<base.T<<','<<rhoDot<<','<<eDot<<','<<pDot<<','<<TDot<<','<<outwardP<<','<<outwardT<<'\n';
                    for(double factor:{1.,.1,.01,.001,1e-4,1e-5,1e-6}){
                    auto small=explicitTrial(q[i],V[i],factor*dt,f[l],f[i],mesh[l],mesh[i]);auto v=checkMaterialCell(small.q,bridge);
                    bool linear=small.q[0]>=0&&small.q[0]<=1&&small.q[1]>=0&&small.q[2]>=0;
                    edges<<name<<','<<factor<<','<<factor*dt<<','<<linear<<','<<(v.issue==AdmissibilityIssue::OK)<<','<<unsigned(v.issue)<<','<<unsigned(v.diagnostic.code)<<'\n';}}
                if(!updateOK){demand(q==committedQ&&V==committedV,"rejected step changed committed state");outcome="UPDATE_RECOVERY_INVALID";++updateFailures;break;}
                // Transactional commit only after every real post-update recovery succeeds.
                for(unsigned i=0;i<N;++i){q[i]=trial[i].q;V[i]=trial[i].volume;}++steps;
                acceptedSources+=sources;
            }
            if(initialOK){std::array<double,10> finalSum={{0,0,0,0,0,0,0,0,0,0}},finalScale=finalSum;
                for(unsigned i=0;i<N;++i)for(unsigned j=0;j<10;++j){finalSum[j]+=V[i]*q[i][j];finalScale[j]+=std::abs(V[i]*q[i][j]);}
                for(unsigned j=1;j<10;++j)integralErr=std::max(integralErr,std::abs(finalSum[j]-initialSum[j])/std::max({1.,initialScale[j],finalScale[j]}));
                acceptedAlphaErr=std::abs(finalSum[0]-initialSum[0]-acceptedSources);
                demand(integralErr<5e-12,"accepted multi-step conserved integrals: "+name);
                demand(acceptedAlphaErr<5e-12*N,"accepted multi-step alpha ledger: "+name);
            }
        }catch(const std::exception& e){outcome="EXCEPTION";++bugs;log<<name<<": "<<e.what()<<'\n';}
        if(outcome=="PASS")++completed;
        double sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
        rows<<name<<','<<N<<','<<maxSteps<<','<<steps<<','<<outcome<<','<<issue<<','<<code<<','<<dt<<','<<amin<<','<<amax<<','<<pErr<<','<<consErr<<','<<alphaErr<<','<<sec<<','<<integralErr<<','<<acceptedAlphaErr<<','<<facePErr<<','<<uErr<<'\n';rows.flush();
        std::cout<<name<<" N="<<N<<" steps="<<steps<<" outcome="<<outcome<<'\n'<<std::flush;
    }
    // Replay EXACT historical accepted Qn and frozen left/right KT face fluxes.
    std::ifstream original(argv[3]);if(!original)throw std::runtime_error("Missing historical path input");
    std::ofstream originalRows("original_mixed_paths.csv"),originalRoot("original_mixed_continuation.csv");
    originalRows<<std::setprecision(17)<<"N,step,cell,dtCandidate,lambdaValid,lambdaInvalid,dtThermo,p,pMin,pMax,TG,TL,alpha,mG,mL,Et,Eint,queries,fixable,endpointValid,boundaryOutward\n";
    originalRoot<<std::setprecision(17)<<"N,lambda,valid,pMin,pMax,Rmin,Rmax,p,TG,TL,cMix,code\n";
    std::string line;std::getline(original,line);unsigned originalCases=0;
    while(std::getline(original,line)){
        std::vector<double> x;std::stringstream in(line);std::string item;while(std::getline(in,item,','))x.push_back(std::stod(item));
        if(x.size()!=41)throw std::runtime_error("Malformed historical path row");
        unsigned N=unsigned(x[0]),step=unsigned(x[1]),cell=unsigned(x[2]);double dt=x[3],V=x[4],ml=x[5],mr=x[6];
        MaterialCell q;for(unsigned j=0;j<10;++j)q[j]=x[7+j];
        fiveEqKTFaceFlux L,R;unsigned offset=17;
        for(auto* ff:{&L,&R}){ff->status=FaceFluxStatus::OK;ff->mGPhi=x[offset++];ff->mLPhi=x[offset++];
            for(unsigned j=0;j<3;++j)ff->momentumPhi[j]=x[offset++];
            ff->energyPhi=x[offset++];ff->alphaPhiCandidate=x[offset++];
            ff->speciesPhi.resize(3);for(unsigned j=0;j<3;++j)ff->speciesPhi[j]=x[offset++];
            ff->wave.phiRelStar=x[offset++];ff->wave.phiPhysStar=x[offset++];}
        auto observer=[&](double lambda,const ExplicitCellTrial& t,const CellAdmissibility& v){
            double lo=v.diagnostic.pBracketMin,hi=v.diagnostic.pBracketMax;
            double r=t.q[1]+t.q[2],internal=t.q[6]-(t.q[3]*t.q[3]+t.q[4]*t.q[4]+t.q[5]*t.q[5])/(2*r);
            double fl=std::numeric_limits<double>::quiet_NaN(),fh=fl;
            try{std::vector<double> Y(3);for(unsigned k=0;k<3;++k)Y[k]=t.q[7+canonicalIndex[k]]/t.q[1];
                auto energy=[&](double p){return t.q[1]*gas.evaluateRhoP(t.q[1]/(1-t.q[0]),p,Y).e+t.q[2]*liquid.evaluateRhoP(t.q[2]/t.q[0],p).e;};
                fl=energy(lo)-internal;fh=energy(hi)-internal;
            }catch(const std::exception&){}
            originalRoot<<N<<','<<lambda<<','<<(v.issue==AdmissibilityIssue::OK)<<','<<lo<<','<<hi<<','<<fl<<','<<fh<<','<<v.recovered.thermo.p<<','<<v.recovered.thermo.TG<<','<<v.recovered.thermo.TL<<','<<v.recovered.thermo.cMix<<','<<unsigned(v.diagnostic.code)<<'\n';
        };
        auto b=connectedThermodynamicStep(q,V,dt,L,R,ml,mr,bridge,observer,128);
        auto endpoint=explicitTrial(q,V,dt,L,R,ml,mr);auto ev=checkMaterialCell(endpoint.q,bridge);observer(1,endpoint,ev);
        auto last=explicitTrial(q,V,b.dtThermo,L,R,ml,mr);auto valid=checkMaterialCell(last.q,bridge);
        demand(b.initialValid&&b.exitFound&&b.dtThermo>0&&valid.issue==AdmissibilityIssue::OK&&ev.issue!=AdmissibilityIssue::OK,"original mixed path first-exit gate");
        // Repeat from a different continuation resolution to audit first-exit stability.
        auto repeat=connectedThermodynamicStep(q,V,dt,L,R,ml,mr,bridge,{},64);
        demand(std::abs(repeat.lambdaValid-b.lambdaValid)<1e-12,"first-exit continuation resolution disagreement");
        const auto& t=valid.recovered.thermo;double Eint=last.q[6]-(last.q[3]*last.q[3]+last.q[4]*last.q[4]+last.q[5]*last.q[5])/(2*(last.q[1]+last.q[2]));
        bool outward=mixedOutwardBoundary(last.q,last.volume,L,R,ml,mr,bridge,gas,liquid,canonicalIndex);
        originalRows<<N<<','<<step<<','<<cell<<','<<dt<<','<<b.lambdaValid<<','<<b.lambdaInvalid<<','<<b.dtThermo<<','<<t.p<<','<<valid.diagnostic.pBracketMin<<','<<valid.diagnostic.pBracketMax<<','<<t.TG<<','<<t.TL<<','<<last.q[0]<<','<<last.q[1]<<','<<last.q[2]<<','<<last.q[6]<<','<<Eint<<','<<b.queries<<",YES,"<<(ev.issue==AdmissibilityIssue::OK)<<','<<outward<<'\n';++originalCases;
    }
    demand(originalCases==3,"missing original mixed failure path");
    std::ofstream boundary("boundary_scaling.csv");boundary<<std::setprecision(17)<<"boundary,direction,distance,p,T,dtCandidate,lambdaValid,dtThermo,outwardDetected,accepted,pNew,TNew,queries\n";
    for(unsigned side=0;side<4;++side)for(bool inward:{false,true}){
        double previous=1e100;
        for(double dist:{1e-2,1e-4,1e-6,0.}){
            if(inward&&dist!=0)continue;
            double p=3e6,T=300;
            if(side==0)p=50000+dist*(12e6-50000);
            if(side==1)p=12e6-dist*(12e6-50000);
            if(side==2)T=285+35*dist;
            if(side==3)T=320-35*dist;
            // Upper edge: compression outward. Lower edge: expansion outward.
            double u=(side==1||side==3)?10:-10;if(inward)u=-u;
            const auto q=generate(1,p,800,T,0),left=generate(1,p,800,T,u),right=generate(1,p,800,T,-u);
            const auto L=reconstructR0(left,q,flux,Foam::vector(1,0,0),0);
            const auto R=reconstructR0(q,right,flux,Foam::vector(1,0,0),0);
            const double dt=explicitTimeStepBounds(q,1,L,R,0,0).joint;
            const bool outward=pureLiquidOutwardBoundary(q,1,L,R,0,0,bridge,liquid,
                dist==0?p:std::numeric_limits<double>::quiet_NaN(),dist==0?T:std::numeric_limits<double>::quiet_NaN());
            ThermodynamicStep b;
            if(!outward)b=connectedThermodynamicStep(q,1,dt,L,R,0,0,bridge);
            auto trial=explicitTrial(q,1,b.dtThermo,L,R,0,0);auto v=checkMaterialCell(trial.q,bridge);
            if(dist==0&&!inward)demand(outward&&b.dtThermo==0&&trial.q==q,"exact HARD outward semantics");
            else {demand(!outward&&b.dtThermo>0&&v.issue==AdmissibilityIssue::OK,"HARD inward/near-boundary positive step");
                if(!inward){demand(b.dtThermo<previous,"near-boundary dt must decrease");previous=b.dtThermo;}}
            boundary<<side<<','<<(inward?"INWARD":"OUTWARD")<<','<<dist<<','<<p<<','<<T<<','<<dt<<','<<b.lambdaValid<<','<<b.dtThermo<<','<<outward<<','<<(b.dtThermo>0&&v.issue==AdmissibilityIssue::OK)<<','<<v.recovered.thermo.p<<','<<v.recovered.thermo.TL<<','<<b.queries<<'\n';
        }
    }
    std::ofstream extra("closure_metrics.json");extra<<std::setprecision(17)<<"{\"thermoQueries\":"<<thermoQueries<<",\"retries\":"<<retries<<",\"controlledStops\":"<<controlledStops<<",\"maxRhoGRelative\":"<<maxRhoG<<",\"maxRhoLRelative\":"<<maxRhoL<<",\"minDtThermoOverAcoustic\":"<<minThermoRatio<<"}\n";
    std::ofstream out("test_results.json");out<<"{\"checks\":"<<checks<<",\"implementation_failures\":"<<bugs<<",\"uniform_face_cases\":"<<uniformCases<<",\"uniform_face_failures\":"<<uniformFailures<<",\"valid_stencil_faces\":"<<faces<<",\"face_gas_queries\":"<<gasQueries<<",\"face_liquid_queries\":"<<liquidQueries<<",\"update_failures\":"<<updateFailures<<",\"initial_failures\":"<<initialFailures<<",\"face_failures\":"<<faceFailures<<",\"completed_scenarios\":"<<completed<<",\"total_scenarios\":42,\"controlling_constraints\":{";
    bool first=true;for(auto v:controls){if(!first)out<<',';first=false;out<<'"'<<v.first<<"\":"<<v.second;}out<<"},\"baseline_gate\":\""<<(bugs||updateFailures||initialFailures||faceFailures?"FAIL":"PASS")<<"\"}\n";
    return bugs?2:updateFailures||initialFailures||faceFailures?1:0;
}
