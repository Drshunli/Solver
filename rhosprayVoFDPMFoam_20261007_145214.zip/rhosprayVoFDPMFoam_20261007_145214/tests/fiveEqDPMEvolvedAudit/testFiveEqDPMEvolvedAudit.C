#include "fvCFD.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "SLGThermo.H"
#include "basicSprayCloud.H"
#include "fiveEqNativeDPMExtraction.H"
#include <fstream>
#include <sstream>
// AUDIT ONLY: native clone is never treated as an eligible transactional cloud.
// Deliberate RNG mutation is demonstrated on an isolated evolved fixture and
// restored immediately. No active solver or CFD equation is executed.
static std::string parcels(const Foam::basicSprayCloud& cloud){
 Foam::OStringStream s;s.precision(17);for(auto it=cloud.begin();it!=cloud.end();++it)s<<it()<<Foam::nl;return s.str();
}
static std::string sources(Foam::basicSprayCloud& cloud){
 std::ostringstream s;s.precision(17);for(Foam::label cell=0;cell<cloud.mesh().nCells();++cell){auto tr=fiveEq::nativeCellTransfer(cloud,cell);s<<tr.massKg<<' '<<tr.sensibleEnthalpyJ;for(unsigned j=0;j<3;++j)s<<' '<<tr.momentumKgMS[j];for(auto v:tr.speciesKg)s<<' '<<v;s<<' '<<cloud.UCoeff()[cell]<<' '<<cloud.hsCoeff()[cell]<<'\n';}return s.str();
}
static std::string randomProbe(Foam::Random copy){std::ostringstream s;s.precision(17);for(unsigned j=0;j<32;++j)s<<copy.scalar01()<<' ';return s.str();}
int main(int argc,char** argv){
 if(argc!=2)return 2;
 Foam::fileName root(argv[1]);setenv("FOAM_CASE",argv[1],1);
 Foam::Time time(Foam::Time::controlDictName,root.path(),Foam::fileName(root.name()));Foam::fvMesh mesh(Foam::IOobject(Foam::fvMesh::defaultRegion,time.timeName(),time,Foam::IOobject::MUST_READ));
 auto thermo=Foam::psiReactionThermo::New(mesh);Foam::SLGThermo slg(mesh,thermo());Foam::volScalarField rho(Foam::IOobject("rho",time.timeName(),mesh),thermo->rho());
 Foam::volVectorField U(Foam::IOobject("U",time.timeName(),mesh),mesh,Foam::dimensionedVector("U",Foam::dimVelocity,Foam::vector(47,0,0)),"zeroGradient");U.correctBoundaryConditions();Foam::surfaceScalarField phi("phi",Foam::fvc::flux(rho*U));auto turb=Foam::compressible::turbulenceModel::New(rho,U,phi,thermo());
 Foam::dimensionedVector gravity("g",Foam::dimAcceleration,Foam::vector::zero);Foam::basicSprayCloud cloud("sprayCloud",rho,U,gravity,slg,false);
 unsigned checks=0,failures=0;std::ofstream errors("test_failures.txt"),ownerFile("evolved_owner_graph.csv"),states("evolved_states.csv");
 auto check=[&](bool ok,const char* name){++checks;if(!ok){++failures;errors<<name<<'\n';}};
 ownerFile<<"state,model,object,owner,committed,clone,ownerAliasesCommitted\n";states<<"state,acceptedSteps,time,parcels,injectedMass,allocator,committedRNGChangedByClone,cloneRNGUnchanged\n";
 time.setDeltaT(1e-6);
 for(unsigned step=1;step<=9;++step){++time;cloud.evolve();if(step!=5&&step!=7&&step!=9)continue;
  const std::string name=step==5?"A":step==7?"B":"C";
  check(cloud.size()>0&&cloud.injectors()[0].massInjected()>0,"evolvedNonzeroInjectionHistory");
  auto parcelBefore=parcels(cloud),sourceBefore=sources(cloud);Foam::Random originalRandom(cloud.rndGen());const Foam::label idBefore=Foam::particle::particleCount_;
  auto ownedClone=cloud.clone("evolvedClone"+name);auto& copy=static_cast<Foam::basicSprayCloud&>(ownedClone());
  check(parcels(copy)==parcelBefore,"nativeCloneParcelInitializationExact");check(sources(copy)==sourceBefore,"nativeCloneSourceInitializationExact");check(randomProbe(copy.rndGen())==randomProbe(originalRandom),"nativeCloneRNGInitialProbeExact");check(copy.injectors()[0].massInjected()==cloud.injectors()[0].massInjected(),"nativeCloneInjectedMassExact");
  auto owner=[&](const char* model,const void* object,const void* addr){bool aliases=addr==static_cast<const void*>(&cloud);ownerFile<<name<<','<<model<<','<<object<<','<<addr<<','<<&cloud<<','<<&copy<<','<<aliases<<'\n';check(aliases,"evolvedNativeCloneOwnerAliasCounterexample");};
  owner("coneInjection",&copy.injectors()[0],&copy.injectors()[0].owner());owner("sphereDrag",&copy.forces()[0],&copy.forces()[0].owner());owner("stochasticDispersionRAS",&copy.dispersion(),&copy.dispersion().owner());owner("blobsSheetAtomization",&copy.atomization(),&copy.atomization().owner());owner("ReitzKHRT",&copy.breakup(),&copy.breakup().owner());owner("ORourke",&copy.stochasticCollision(),&copy.stochasticCollision().owner());owner("rebound",&copy.patchInteraction(),&copy.patchInteraction().owner());owner("voidFraction",&copy.functions()[0],&copy.functions()[0].owner());
  check(&copy.injectors()[0].owner().outputProperties()==&cloud.outputProperties(),"clonedInjectorTargetsCommittedOutputProperties");
  const std::string beforeCloneRNG=randomProbe(copy.rndGen());
  {Foam::basicSprayParcel marker(mesh,Foam::vector(.5,.5,.5),0);marker.rho()=730;copy.injectors()[0].setProperties(0,1,time.value(),marker);}
  bool originalChanged=randomProbe(cloud.rndGen())!=randomProbe(originalRandom),cloneUnchanged=randomProbe(copy.rndGen())==beforeCloneRNG;
  check(originalChanged,"clonedInjectorMutatesCommittedRNG");check(cloneUnchanged,"clonedInjectorDoesNotUseIndependentCloneRNG");
  // Restore deliberate audit effects before the next accepted native step.
  cloud.rndGen()=originalRandom;Foam::particle::particleCount_=idBefore;
  check(parcels(cloud)==parcelBefore&&sources(cloud)==sourceBefore,"auditPreservesCommittedParcelsSources");
  states<<name<<','<<step<<','<<std::setprecision(17)<<time.value()<<','<<cloud.size()<<','<<cloud.injectors()[0].massInjected()<<','<<idBefore<<','<<originalChanged<<','<<cloneUnchanged<<'\n';
  std::ofstream(name+"_ordered_parcels.txt")<<parcelBefore;std::ofstream(name+"_native_sources.txt")<<sourceBefore;
  ownedClone.clear();check(Foam::particle::particleCount_==idBefore,"cloneDestructionAllocatorAudit");
 }
 std::ofstream result("test_results.json");result<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"evolvedAcceptedSteps\":[5,7,9],\"transactionSafe\":false,\"blocker\":\"MODEL_TRANSACTION_BLOCKER\",\"noCFD\":true}\n";
 std::cout<<checks<<" audit checks "<<failures<<" failures; MODEL_TRANSACTION_BLOCKER\n";return failures?1:0;
}
