#include "localCommittedView.H"
#include "localTypes.H"
#include "lazyTrialBinding.H"
#include "fvCFD.H"
#include "carrierEpoch.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "SLGThermo.H"
#include "basicSprayCloud.H"
#include "carrierTransaction.H"
#include "serialTransaction.H"
#include "nativeState.H"
#include "stateCodec.H"
#include "nativeObservedCalc.H"
#include "serialClosure.H"
#include "eventActions.H"
#include "stagedOutput.H"
#include <unistd.h>
#include <chrono>
#include <fstream>
using namespace fiveEq;
namespace r2c { const fiveEq::PrecisionOperator* op=nullptr; std::string thermal; }
int main(int argc,char**argv){
 if(argc!=4)return 2;
 const std::string state(argv[2]);unsigned history=state=="A"?5:state=="B"?7:9;
 Foam::fileName root(argv[1]);setenv("FOAM_CASE",argv[1],1);
 Foam::Time time(Foam::Time::controlDictName,root.path(),Foam::fileName(root.name()));
 Foam::fvMesh mesh(Foam::IOobject(Foam::fvMesh::defaultRegion,time.timeName(),time,Foam::IOobject::MUST_READ));
 auto thermo=Foam::psiReactionThermo::New(mesh);Foam::SLGThermo slg(mesh,thermo());
 Foam::volScalarField rho(Foam::IOobject("rho",time.timeName(),mesh),thermo->rho());
 Foam::volVectorField U(Foam::IOobject("U",time.timeName(),mesh),mesh,Foam::dimensionedVector("U",Foam::dimVelocity,Foam::vector(47,0,0)),"zeroGradient");U.correctBoundaryConditions();
 Foam::surfaceScalarField phi("phi",Foam::fvc::flux(rho*U));auto turb=Foam::compressible::turbulenceModel::New(rho,U,phi,thermo());Foam::dimensionedVector gravity("g",Foam::dimAcceleration,Foam::vector::zero);
 std::ifstream gasData(argv[3],std::ios::binary);r2::thermodynamicIdentity=std::string(std::istreambuf_iterator<char>(gasData),{});if(r2::thermodynamicIdentity.empty())return 2;
 fiveEqGasThermoEvaluator gas(argv[3]);fiveEqLiquidThermoEvaluator liquid;fiveEqPrecisionRecovery recovery(gas,liquid);
 const auto names=thermo->composition().species();std::array<unsigned,3>index;for(unsigned i=0;i<3;++i)index[names[i]=="C10H22"?0:names[i]=="O2"?1:2]=i;
 PrecisionOperator op(recovery,index);PrecisionReconstruction rec(gas,liquid,op,index);r2c::op=&op;r2c::thermal=argv[3];
 std::vector<double>hc(3);for(unsigned i=0;i<3;++i)hc[index[i]]=gas.speciesData()[i].Hc();fiveEqDPMSourceAdapter adapter(hc);
 r2c::LocalCommittedView view(thermo(),rho,U,op,gas,argv[3]);t3a::epoch=&view.token;
 std::vector<PrecisionCell>q(mesh.nCells(),rec.generate(PrecisionFraction::liquid(0,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772}));
 auto boot=view.prepareCommit(view.prepare(q));view.publishCommitNoFail(boot);view.token.publishing=false;



 unsigned checks=0,failures=0;std::ofstream bad("test_failures.txt");auto check=[&](bool ok,const char*n){++checks;if(!ok){++failures;bad<<n<<'\n';}};
 auto original=std::unique_ptr<r2::State>(new r2::State);{m8a3a::TrialScope passive;original->cloud.reset(new m8a3a::Cloud("roleA",rho,U,gravity,slg,false));}
 auto evolve=[&](r2::State&s,double dt){auto tv=time.value(),delta=time.deltaTValue();auto ti=time.timeIndex(),id=Foam::particle::particleCount_;time.setTime(s.time+dt,s.index+1);time.setDeltaT(dt);Foam::particle::particleCount_=s.allocator;{r2c::LazyTrialBinding binding(*s.cloud,s.q,s.generation);m8a3a::TrialScope passive;s.cloud->evolve();}s.allocator=Foam::particle::particleCount_;s.time=time.value();s.dt=dt;s.index=time.timeIndex();Foam::particle::particleCount_=id;time.setTime(tv,ti);time.setDeltaT(delta);};
 original->cloud->injectors().set(0,new r2::ConeState(original->cloud->injectors()[0].dict(),*original->cloud,original->cloud->injectors()[0].modelName()));
 original->q=q;original->allocator=Foam::particle::particleCount_;original->time=time.value();original->index=time.timeIndex();original->generation=view.token.generation;
 for(unsigned i=0;i<history;++i)evolve(*original,1e-6);
 const auto encoded=r2::encode(*original);std::ofstream("evolved_state.bin",std::ios::binary).write(encoded.data(),encoded.size());auto restored=r2::decode(encoded,"roleB",*original->cloud,slg);check(encoded==r2::encode(*restored),"completeSelectedGraphCodecRoundtrip");
 for(unsigned i=0;i<10;++i){evolve(*original,1e-6);evolve(*restored,1e-6);check(r2::encode(*original)==r2::encode(*restored),"tenNativeWholeCloudFutureStepsCodecEqual");}
 for(unsigned i=0;i<200;++i){check(original->cloud->rndGen().scalarNormal()==restored->cloud->rndGen().scalarNormal(),"codecRestoredNormalDraw");check(original->cloud->rndGen().scalar01()==restored->cloud->rndGen().scalar01(),"codecRestoredUniformDraw");}

 auto&edge=restored->cloud->begin()();for(auto f:r2::parcelScalars(edge))*f=(*f==0)?-0.0:std::nextafter(*f,std::numeric_limits<double>::infinity());auto edgeCode=r2::encode(*restored);auto edgeClone=r2::decode(edgeCode,"roleC",*restored->cloud,slg);check(edgeCode==r2::encode(*edgeClone),"allTypedParcelScalarBitsIncludingNegativeZeroRoundtrip");auto edgeFields=r2::parcelScalars(edge),cloneFields=r2::parcelScalars(edgeClone->cloud->begin()());for(unsigned i=0;i<edgeFields.size();++i)check(r1::bits(*edgeFields[i])==r1::bits(*cloneFields[i]),"everyAuthoritativeParcelScalarBitRetained");edgeClone.reset();
 for(unsigned cache=0;cache<2;++cache){Foam::Random a(713);if(cache)a.scalarNormal();Foam::Random b(0);r1::rngRead(b,r1::rng(a));check(r1::rng(a)==r1::rng(b),"normalCacheBothFlagsFullCodec");for(unsigned draw=0;draw<100;++draw){check(a.scalarNormal()==b.scalarNormal(),"bothCacheFlagsFutureNormalExact");check(a.scalar01()==b.scalar01(),"bothCacheFlagsFutureUniformExact");}}
 auto corrupt=encoded;corrupt.back()^=1;bool rejected=false;try{auto x=r2::decode(corrupt,"roleC",*original->cloud,slg);}catch(const std::logic_error&){rejected=true;}check(rejected,"corruptChecksumRejectedBeforeNativeParsing");

 r2::cloudFactory=r2::eventFactory;r2::birthHook=r2::observeBirth;
 restored.reset();auto trial=r2::decode(r2::encode(*original),"roleB",*original->cloud,slg);
 m8a3b::NativeSparsePointSupport points(U);r2::Ledger ledger(op,adapter,trial->q);ledger.points=&points;
 bool strictPassed=false;std::string strictReason;
 try{r2::Observe observing(&ledger);trial->cloud->resetSourceTerms();evolve(*trial,1e-6);strictPassed=true;}
 catch(const std::exception&e){strictReason=e.what();}
 ledger.dump("strict_event_probe.txt");
 std::ofstream("strict_event_probe_status.txt")<<"passed="<<strictPassed<<" events="<<ledger.events.size()<<" queries="<<ledger.supportQueries<<" reason="<<strictReason<<'\n';
 check(ledger.supportQueries>0,"realPreInterpolationHookObserved");
 std::ofstream("pretrial.bin",std::ios::binary).write(encoded.data(),encoded.size());

 trial.reset();auto deleted=r2::decode(r2::encode(*original),"roleB",*original->cloud,slg);auto&dc=*deleted->cloud;dc.clear();
 Foam::particle::particleCount_=deleted->allocator;auto*marker=new Foam::fiveEqDPM::LazyParcel(mesh,mesh.C()[0],0);dc.setParcelThermoProperties(*marker,1e-5);marker->T()=300;marker->Y()=Foam::scalarField(1,1);auto mx=dc.composition().liquids().X(marker->Y());marker->rho()=dc.composition().liquids().rho(3e6,300,mx);marker->Cp()=dc.composition().liquids().Cp(3e6,300,mx);marker->mu()=dc.composition().liquids().mu(3e6,300,mx);marker->sigma()=dc.composition().liquids().sigma(3e6,300,mx);marker->d()=marker->d0()=.0003;marker->mass0()=marker->mass();marker->position0()=marker->position();marker->nParticle()=1e-16/marker->mass();marker->U()=U[0];marker->liquidCore()=0;dc.addParticle(marker);dc.resetSourceTerms();
 r2::Ledger deletionLedger(op,adapter,deleted->q);deletionLedger.points=&points;bool deletionPassed=false;std::string deletionReason;
 try{r2c::LazyTrialBinding binding(dc,deleted->q,deleted->generation);m8a3a::TrialScope passive;r2::Observe observe(&deletionLedger);dc.dispersion().cacheFields(true);dc.forces().cacheFields(true);Foam::fiveEqDPM::LazyParcel::trackingData td(dc);td.keepParticle=true;marker->setCellValues(dc,td);marker->calc(dc,td,1e-5);dc.dispersion().cacheFields(false);dc.forces().cacheFields(false);if(!td.keepParticle)dc.deleteParticle(*marker);deletionPassed=dc.size()==0;}
 catch(const std::exception&e){deletionReason=e.what();dc.dispersion().cacheFields(false);dc.forces().cacheFields(false);}
 deletionLedger.dump("minimum_mass_deletion_ledger.txt");std::ofstream("minimum_mass_deletion_status.txt")<<"passed="<<deletionPassed<<" reason="<<deletionReason<<'\n';check(deletionPassed,"strictIndependentMinimumMassDeletion");

 Foam::particle::particleCount_=original->allocator;deleted.reset();auto working=r2::decode(r2::encode(*original),"roleB",*original->cloud,slg);original.reset();
 std::unique_ptr<r2::State>configuration;std::string master;{r2::Output output("coupled_output");r2::Transaction tx(std::move(working),view,slg,time,op,adapter,output);
 unsigned coupledAccepted=0;std::string coupledBlocker;
 for(unsigned step=0;step<12;++step){tx.begin();tx.ledger->points=&points;try{tx.evolve(1e-6);tx.ledger->dump("coupled_step_"+std::to_string(step)+".txt");check(tx.ledger->supportQueries>0,"coupledStepActualCarrierQueries");tx.prepare();tx.publish();tx.flush();++coupledAccepted;}catch(const std::exception&e){coupledBlocker=e.what();tx.ledger->dump("coupled_blocker.txt");tx.discard();break;}}
 std::ofstream("coupled_status.txt")<<"accepted="<<coupledAccepted<<" publications="<<output.publications<<" reason="<<coupledBlocker<<'\n';check(coupledAccepted==12,"twelveWholeCloudStrictSourceCarrierAndOutputCommits");master=r2::encode(tx.accepted());configuration=r2::decode(master,"roleC",*tx.accepted().cloud,slg);}

 std::ofstream matrix("event_transaction_matrix.csv");matrix<<"mode,rollbackExact,retryFutureExact,acceptedSteps,reason\n";
 unsigned pairsPassed=0;
 for(const std::string mode:{"coneInjection","stochasticDispersionRAS","sphereDrag","blobsSheetAtomization","ReitzKHRT","rebound","ThermoParcelDeletion","voidFraction","combined","ORourke_none","ORourke_grazing","ORourke_coalescence","ORourke_cleanup"}){
  if(std::getenv("R2_COLLISIONS_ONLY")&&mode.find("ORourke_")!=0)continue;auto seed=r2::decode(master,"roleA",*configuration->cloud,slg);r2::marker(*seed,mode);const auto focus=std::to_string(seed->cloud->begin()().origProc())+":"+std::to_string(seed->cloud->begin()().origId());auto seedCode=r2::encode(*seed);seed.reset();std::vector<std::string>directKeys,directCarrier,directQueries;bool rollback=false,equal=true;unsigned acceptedSteps=0;std::string reason;
  for(unsigned path=0;path<2&&reason.empty();++path){
   auto start=r2::decode(seedCode,"roleA",*configuration->cloud,slg);auto initialPublication=view.prepareForRestore(start->q,start->generation);view.publishCommitNoFail(initialPublication);view.token.publishing=false;
   r2::Output sink(mode+(path?"_retry":"_direct"));r2::Transaction tx(std::move(start),view,slg,time,op,adapter,sink);
   std::ofstream(mode+std::string(path?"_retry_pretrial.bin":"_direct_pretrial.bin"),std::ios::binary)<<r2::encode(tx.accepted());
   auto perform=[&](double dt,bool first){tx.begin();tx.ledger->points=&points;tx.act(dt,[&](r2::Cloud&c){if(!path&&mode.find("ORourke_")==0)dynamic_cast<r1::Cloud&>(c).useNativeCollisionReference();if(first)r2::action(c,mode,dt);else{if(mode=="stochasticDispersionRAS")for(auto it=c.begin();it!=c.end();++it)it().tTurb()=Foam::great;c.evolve();}});};
   try{
    if(path){auto before=r2::encode(tx.accepted());perform(1e-4,true);tx.ledger->dump(mode+"_rejected_events.txt");tx.discard();rollback=before==r2::encode(tx.accepted());check(rollback,"canonicalLargeRealEventDiscardExact");std::ofstream(mode+"_after_discard.bin",std::ios::binary)<<r2::encode(tx.accepted());}
    for(unsigned step=0;step<11;++step){perform(step==0?(mode.find("ORourke_")==0?1e-5:1e-5):(mode.find("ORourke_")==0?1e-8:step==1?1e-5:1e-8),step==0);auto query=tx.ledger->queryResults;
     if(step==0&&path&&std::getenv("R2_COLLISIONS_ONLY")){auto&collision=dynamic_cast<r1::Collision&>(tx.trial().cloud->stochasticCollision());bool merge=false;for(const auto&event:collision.events)merge=merge||event.merge;if(mode=="ORourke_none")check(collision.events.empty(),"actualNativeNoCollisionBranch");if(mode=="ORourke_grazing")check(!collision.events.empty()&&!merge,"actualNativeGrazingBranch");if(mode=="ORourke_coalescence")check(merge,"actualNativeCoalescenceBranch");if(mode=="ORourke_cleanup"){unsigned chamberCount=0;for(auto it=tx.trial().cloud->begin();it!=tx.trial().cloud->end();++it)if(it().cell()==mesh.nCells()-1)++chamberCount;check(merge&&chamberCount<2,"actualNativePositiveCleanupCountReduction");}}
     if(step==0){tx.ledger->dump(mode+(path?"_retry_events.txt":"_direct_events.txt"));if(mode=="ReitzKHRT")check(std::any_of(tx.ledger->events.begin(),tx.ledger->events.end(),[&](const r2::Event&e){return e.id==focus&&!e.childIds.empty();}),"actualNativeKHChildIdentifiedInParentCalcEvent");if(mode=="blobsSheetAtomization")check(std::any_of(tx.ledger->events.begin(),tx.ledger->events.end(),[&](const r2::Event&e){return e.id==focus&&e.coreBefore>.5&&e.coreAfter<.5;}),"actualBlobsCoreMutationIdentifiedInNativeCalcEvent");if(mode=="rebound")check(tx.trial().cloud->begin()().U().y()>0,"actualNativePatchRebound");if(mode=="voidFraction"){auto&vf=dynamic_cast<r2::TrajectoryVF&>(tx.trial().cloud->functions()[0]);check(vf.trajectoryVerified&&vf.observedMoves>0,"actualNativeTrajectoryTimeThetaVerified");check(vf.differsFromOccupancy,"nativeTrajectoryThetaDiffersFromFinalOccupancy");}if(mode=="sphereDrag")check(Foam::magSqr(tx.trial().cloud->UTrans()[0])>0,"actualNonzeroNativeDragTransfer");}
     tx.prepare();auto ticket=tx.trial().pending.front();tx.publish();tx.flush();sink.publish(ticket);check(sink.publications==step+1,"acceptedTicketRepeatedFlushIdempotent");auto key=r2::encode(tx.accepted()),carrier=view.snapshot();
     if(path){equal=equal&&key==directKeys[step]&&carrier==directCarrier[step]&&query==directQueries[step];check(equal,"canonicalRetryAndTenCommittedFutureStepsEqual");}else{directKeys.push_back(key);directCarrier.push_back(carrier);directQueries.push_back(query);}
     std::ofstream(mode+(path?"_retry_step_":"_direct_step_")+std::to_string(step)+".bin",std::ios::binary)<<key;++acceptedSteps;
    }
   }catch(const std::exception&e){reason=e.what();if(tx.ledger){tx.ledger->dump(mode+"_blocker_events.txt");try{tx.discard();}catch(...){}}}
  }
  matrix<<mode<<','<<rollback<<','<<equal<<','<<acceptedSteps<<','<<reason<<std::endl;if(reason.empty()&&rollback&&equal&&acceptedSteps==22)++pairsPassed;
  if(mode=="ThermoParcelDeletion"&&!reason.empty()){std::ofstream("NEW_EVENT_LEDGER_BLOCKER.txt")<<reason;break;}
 }
 check(pairsPassed==(std::getenv("R2_COLLISIONS_ONLY")?4:13),"allCoreDirectRetryTenStepTransactionPairs");

 {auto stress=r2::decode(master,"roleA",*configuration->cloud,slg);r2::marker(*stress,"sphereDrag");auto stressBoot=view.prepareForRestore(stress->q,stress->generation);view.publishCommitNoFail(stressBoot);view.token.publishing=false;
 r2::Output stressOutput("lifecycle_output");r2::Transaction lifecycle(std::move(stress),view,slg,time,op,adapter,stressOutput);
 unsigned nonzeroCommits=0,discards=0;std::ofstream lifecycleLog("lifecycle.csv");lifecycleLog<<"phase,index,registry,parcels,allocator,generation,residentPages\n";
 auto record=[&](const char*phase,unsigned step){std::ifstream memory("/proc/self/statm");unsigned long total=0,resident=0;memory>>total>>resident;lifecycleLog<<phase<<','<<step<<','<<static_cast<const Foam::objectRegistry&>(mesh).size()<<','<<lifecycle.accepted().cloud->size()<<','<<lifecycle.accepted().allocator<<','<<view.token.generation<<','<<resident<<std::endl;};
 for(unsigned step=0;step<100;++step){lifecycle.begin();lifecycle.ledger->points=&points;lifecycle.act(1e-8,[](r2::Cloud&c){r2::action(c,"sphereDrag",1e-8);});check(Foam::magSqr(lifecycle.trial().cloud->UTrans()[0])>0,"sequentialActualNonzeroNativeSource");auto keyBefore=r2::encode(lifecycle.accepted());lifecycle.prepare();auto ticket=lifecycle.trial().pending.front();lifecycle.publish();
  if(step==20){stressOutput.failPublish=true;bool ioFailed=false;auto physics=r2::encode(lifecycle.accepted());try{lifecycle.flush();}catch(const std::runtime_error&){ioFailed=true;}check(ioFailed&&physics==r2::encode(lifecycle.accepted())&&!lifecycle.accepted().pending.empty(),"postCommitIoFailureRetainsPhysicsAndPendingTicket");stressOutput.failPublish=false;
   auto replay=r2::decode(physics,lifecycle.accepted().cloud->name()=="roleA"?"roleB":"roleA",*lifecycle.accepted().cloud,slg);check(physics==r2::encode(*replay),"completePendingOutputTicketCodecRoundtrip");replay.reset();
   std::string blockedPath="lifecycle_output/accepted/step_"+std::to_string(ticket.sequence);std::ofstream(blockedPath)<<"fault-injection-existing-file";bool actualIoFailure=false;try{lifecycle.flush();}catch(const std::runtime_error&){actualIoFailure=true;}check(actualIoFailure&&physics==r2::encode(lifecycle.accepted()),"actualFilesystemPublicationFailureRetainsPhysicsAndPending");if(::unlink(blockedPath.c_str()))throw std::runtime_error("FAULT_FIXTURE_CLEANUP_IO");}
  lifecycle.flush();stressOutput.publish(ticket);check(stressOutput.publications==step+1,"hundredSequentialExactlyOnceOutputs");++nonzeroCommits;record("accept",step);
  auto rejectAnchor=r2::encode(lifecycle.accepted());auto sourceAnchor=view.snapshot();lifecycle.begin();lifecycle.ledger->points=&points;lifecycle.act(1e-7,[](r2::Cloud&c){r2::action(c,"sphereDrag",1e-7);});lifecycle.prepare();lifecycle.discard();check(rejectAnchor==r2::encode(lifecycle.accepted())&&sourceAnchor==view.snapshot(),"hundredAlternatingNonzeroSourcePreparedTrialDiscards");check(stressOutput.publications==step+1,"alternatingRejectedOutputZeroPermanentArtifacts");record("reject",step);
 }
 for(unsigned step=0;step<1000;++step){auto before=r2::encode(lifecycle.accepted());lifecycle.begin();lifecycle.trial().cloud->rndGen().scalarNormal();lifecycle.trial().cloud->begin()().U().x()+=1;auto changed=r2::encode(lifecycle.trial());check(changed!=before,"completeCodecDetectsDiscardedMutation");lifecycle.discard();check(before==r2::encode(lifecycle.accepted()),"thousandCompleteCodecDiscardCyclesExact");++discards;if(step%50==0)record("discard",step);}
 {auto before=r2::encode(lifecycle.accepted());lifecycle.begin();lifecycle.ledger->points=&points;lifecycle.act(1e-8,[](r2::Cloud&c){r2::action(c,"sphereDrag",1e-8);});stressOutput.failPrepare=true;bool ioFailed=false;try{lifecycle.prepare();}catch(const std::runtime_error&){ioFailed=true;}stressOutput.failPrepare=false;lifecycle.discard();check(ioFailed&&before==r2::encode(lifecycle.accepted()),"prepareIoFailureBeforePhysicsPublicationAndExactDiscard");}
 std::ofstream("lifecycle_status.txt")<<"nonzeroCommits="<<nonzeroCommits<<" discards="<<discards<<" publications="<<stressOutput.publications<<'\n';}

 {auto trace=r2::decode(master,"roleA",*configuration->cloud,slg);r2::marker(*trace,"stochasticDispersionRAS");for(auto&cell:trace->q)cell=rec.generate(PrecisionFraction::minority(1e-20,true,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772});auto publication=view.prepareForRestore(trace->q,trace->generation);view.publishCommitNoFail(publication);view.token.publishing=false;
  r2::Output out("trace_output");r2::Transaction tx(std::move(trace),view,slg,time,op,adapter,out);auto before=tx.accepted().q[0].fraction.payload();tx.begin();tx.ledger->points=&points;tx.act(1e-8,[](r2::Cloud&c){auto&p=c.begin()();Foam::fiveEqDPM::LazyParcel::trackingData td(c);p.setCellValues(c,td);auto snapshot=r2::beforeCalc(c,p,td.pc());p.tTurb()=Foam::great;c.dispersion().cacheFields(true);c.dispersion().update(1e-8,p.cell(),p.U(),c.U()[p.cell()],p.UTurb(),p.tTurb());c.dispersion().cacheFields(false);r2::afterCalc(snapshot,c,p,true);});tx.ledger->dump("trace_event_ledger.txt");auto queries=tx.ledger->queryResults;tx.prepare();tx.publish();tx.flush();check(before.hi==tx.accepted().q[0].fraction.payload().hi&&r1::bits(before.hi)==r1::bits(tx.accepted().q[0].fraction.payload().hi)&&!queries.empty(),"actualTraceGasQueryEventCommitRetainsSignedP2");std::ofstream("trace_accepted.bin",std::ios::binary)<<r2::encode(tx.accepted());
 }
 {auto pure=r2::decode(master,"roleA",*configuration->cloud,slg);r2::marker(*pure,"stochasticDispersionRAS");for(auto&cell:pure->q)cell=rec.generate(PrecisionFraction::minority(0,true,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772});r2::Ledger ledger(op,adapter,pure->q);ledger.points=&points;auto before=r2::encode(*pure);bool rejected=false;std::string reason;try{r2c::LazyTrialBinding binding(*pure->cloud,pure->q,pure->generation);r2::Observe observe(&ledger);Foam::fiveEqDPM::LazyParcel::trackingData td(*pure->cloud);pure->cloud->begin()().setCellValues(*pure->cloud,td);}catch(const std::exception&e){rejected=true;reason=e.what();}check(rejected&&ledger.queryResults.empty()&&r2::encode(*pure)==before,"pureLiquidRejectsBeforeActualGasPropertyQueryWithoutFakeGas");std::ofstream("pure_liquid_status.txt")<<"rejected="<<rejected<<" actualQueryBytes="<<ledger.queryResults.size()<<" reason="<<reason<<'\n';}

 std::ofstream result("test_results.json");result<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"nativeFutureSteps\":10,\"codecRoundtrip\":true,\"transactionClosure\":false,\"noCFD\":true}\n";return failures?1:0;
}
