#include "localTypes.H"
#include "QueryObserver.H"
#include "fiveEqPrecisionReconstruction.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "SLGThermo.H"
#include "stateCodec.H"
#include "serialClosure.H"
#include <fstream>
#include <iomanip>
namespace r2c {const fiveEq::PrecisionOperator* op=nullptr;std::string thermal;}
int main(int argc,char**argv){
 Foam::argList::addBoolOption("reverse","rank1 source to rank0 destination");
 Foam::argList::addBoolOption("localFailure","no-crossing invalid cell control");
 Foam::argList::addOption("cycles","n","number of independent failed trials");
 Foam::argList::addBoolOption("unknownControl","direct native parcel move unknown exception control");
 Foam::argList::addBoolOption("unlatchedControl","same native valid path with no failure latch bound");
 Foam::argList::addBoolOption("invalidDestination","legal pure-liquid destination cell support probe");
 Foam::argList::addOption("steps","n","consecutive native evolves in one disposable trial");
 Foam::argList::addOption("dt","seconds","native tracking step");
 Foam::argList::addOption("gasUx","velocity","uniform carrier velocity");
 Foam::argList::addOption("diameter","metres","seed diameter");
 Foam::argList::addBoolOption("core","coherent seeded core for native repeated trajectory");
 Foam::argList::addBoolOption("allowNativeBirths","observe actual native KH children");
 Foam::argList::addOption("startX","metres","seed position, no subsequent relocation");
 Foam::argList::addBoolOption("KHfixture","frozen K1 parent initial-history fixture, native event only");
 Foam::argList::addBoolOption("localAcceptLast","existing local transaction happy-path publication, no global MPI commit certification");
 Foam::argList::addBoolOption("rejectFirstBirthTrial","test-only normal rejection after valid native births");
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 using namespace Foam;namespace c1=fiveEqDPM::c1;using P=fiveEqDPM::LazyParcel;using C=fiveEqDPM::LazySprayCloud;
 auto thermo=psiReactionThermo::New(mesh);SLGThermo slg(mesh,thermo());
 volScalarField rho(IOobject("rho",runTime.timeName(),mesh),thermo->rho());
 volVectorField U(IOobject("U",runTime.timeName(),mesh),mesh,dimensionedVector("U",dimVelocity,vector(47,0,0)),"zeroGradient");U.correctBoundaryConditions();
 surfaceScalarField phi("phi",fvc::flux(rho*U));auto turbulence=compressible::turbulenceModel::New(rho,U,phi,thermo());
 std::string thermal="/mnt/d/DATA/Solver/300_2D/constant/thermal.dat";
 fiveEq::fiveEqGasThermoEvaluator gas(thermal);fiveEq::fiveEqLiquidThermoEvaluator liquid;fiveEq::fiveEqPrecisionRecovery recovery(gas,liquid);fiveEq::PrecisionOperator op(recovery,{0,1,2});fiveEq::PrecisionReconstruction rec(gas,liquid,op,{0,1,2});
 s1::DistributedSparsePointSupport stencil(mesh);s1::DistributedCarrierSupport owner(stencil,op,thermal);
 bool invalid=args.optionFound("invalidDestination"),reverse=args.optionFound("reverse"),local=args.optionFound("localFailure");
 label source=reverse?1:0,destination=local?source:1-source;
 label steps=1;scalar trackDt=.004,gasUx=47,diameter=.001;args.optionReadIfPresent("steps",steps);args.optionReadIfPresent("dt",trackDt);args.optionReadIfPresent("gasUx",gasUx);args.optionReadIfPresent("diameter",diameter);
 scalar startX=reverse?4.1:3.9;args.optionReadIfPresent("startX",startX);
 label cycles=1;args.optionReadIfPresent("cycles",cycles);
 std::vector<fiveEq::PrecisionCell>state;for(const auto&k:stencil.keys())if(k.rank==Pstream::myProcNo())state.push_back(rec.generate(fiveEq::PrecisionFraction::liquid(invalid&&k.rank==destination&&k.kind==0?1:0,fiveEq::FractionMode::P2),args.optionFound("KHfixture")?3e6:188330.307,args.optionFound("KHfixture")?800:400,300,vector(gasUx,0,0),{0,.228,.772}));
 owner.publish(owner.prepare(state,1));auto provider=std::make_shared<QueryObserver>(owner,stencil,runTime.path());
 unsigned failures=0;label logicalId=-1;
 std::ofstream phaseLog((runTime.path()/"C1_phases.csv").c_str());
 std::ofstream results((runTime.path()/"C1_cycles.csv").c_str());
 results<<"cycle,localFailed,globalFailed,owned,queries,rho,T,Y,Cp,mu,kappa,recoveries,quarantines,generation,registry,live\n";

 r2c::op=&op;r2c::thermal=thermal;std::ifstream data(thermal);r2::thermodynamicIdentity=std::string(std::istreambuf_iterator<char>(data),{});
 std::vector<double> hc;for(const auto&g:gas.speciesData())hc.push_back(g.Hc());fiveEq::fiveEqDPMSourceAdapter adapter(hc);
 t3a::StableCommittedCarrierView view(thermo(),rho,U,op,gas,thermal);view.token.generation=1;
 r2::Output output((runTime.path()/"N1_staged_output").c_str());
 auto initial=std::unique_ptr<r2::State>(new r2::State);initial->generation=1;
 for(unsigned i=0;i<stencil.keys().size();++i){const auto&k=stencil.keys()[i];if(k.rank==Pstream::myProcNo()&&k.kind==0)initial->q.push_back(owner.committed().states.at(i).q);}
 dimensionedVector gravity("g",dimAcceleration,vector::zero);
 {m8a3a::TrialScope passive;initial->cloud.reset(new C("roleA",rho,U,gravity,slg,false));}
 {m8a3a::TrialScope passive;auto configured=std::unique_ptr<C>(new m8a3a::ReconstructedCloud("roleB",*initial->cloud,slg));initial->cloud.swap(configured);}
 {
 C&cloud=*initial->cloud;vector start(startX,.5,.5);
   if(Pstream::myProcNo()==source){auto*p=new P(mesh,start,mesh.findCell(start));cloud.setParcelThermoProperties(*p,1e-6);p->Y()=scalarField(1,1);p->T()=300;auto X=cloud.composition().liquids().X(p->Y());p->rho()=cloud.composition().liquids().rho(188330.307,300,X);p->Cp()=cloud.composition().liquids().Cp(188330.307,300,X);p->mu()=cloud.composition().liquids().mu(188330.307,300,X);p->sigma()=cloud.composition().liquids().sigma(188330.307,300,X);p->U()=vector(source==0?47:-47,0,0);p->d()=diameter;p->d0()=diameter;p->nParticle()=1;p->liquidCore()=args.optionFound("core")?1:0;p->KHindex()=0;if(args.optionFound("KHfixture")){p->U()=vector(1000,0,0);p->nParticle()=1e6;p->KHindex()=1;p->tc()=-great;p->ms()=.21*cloud.averageParcelMass();p->mass0()=p->mass();p->position0()=p->position();p->tTurb()=1;}logicalId=p->origId();cloud.addParticle(p);}
 }
 reduce(logicalId,maxOp<label>());initial->allocator=particle::particleCount_;initial->time=runTime.value();initial->dt=runTime.deltaTValue();initial->index=runTime.timeIndex();
 r2::Transaction tx(std::move(initial),view,slg,runTime,op,adapter,output);
 auto committedBefore=r2::encode(tx.accepted()),viewBefore=view.snapshot();auto liveBase=i1::lifetime().live.size();const auto registry=mesh.Foam::objectRegistry::size();

 for(label cycle=0;cycle<cycles;++cycle){
 std::ofstream allocatorLog((runTime.path()/"ID1_allocator.csv").c_str(),std::ios::app);allocatorLog<<cycle<<",before,"<<particle::particleCount_<<std::endl;
 c1::MPIFailureLatch latch;latch.trace=&phaseLog;c1::Binding latchBinding(latch);
 auto counts=i1::lifetime();tx.begin();std::vector<uint64_t>atFailure;
 auto physical=[&](const fiveEqDPM::NativePose&pose){std::vector<uint64_t>v;auto*p=static_cast<P*>(const_cast<particle*>(pose.identity));auto fields=r2::parcelScalars(*p);for(size_t i=0;i<fields.size();++i)if(i!=4)v.push_back(r1::bits(*fields[i]));return v;};
 latch.capture=[&](const fiveEqDPM::NativePose&p){atFailure=physical(p);};
 owner.counters={};owner.recoveries=0;
 provider=std::make_shared<QueryObserver>(owner,stencil,runTime.path());

 std::ofstream events((runTime.path()/"native_crossing.csv").c_str());events<<std::setprecision(17)<<"phase,rank,origProc,origId,x,y,z,cell,tetFace,tetPt,face,Ux,d,T,nParticle\n";
 {
  dimensionedVector gravity("g",dimAcceleration,vector::zero);
  C&cloud=*tx.trial().cloud;
  std::ofstream boundary((runTime.path()/"R1_boundary.csv").c_str(),std::ios::app);
  boundary<<std::setprecision(17);
  fiveEqDPM::migrationR1::observer()=[&](const char*stage,const particle&base){
   const auto&p=dynamic_cast<const P&>(base);
   boundary<<cycle<<","<<stage<<","<<Pstream::myProcNo()<<","<<p.origProc()<<","<<p.origId()<<",";
   bool geometric=std::string(stage)=="SEND_BEFORE_PREPARE"||std::string(stage)=="RECEIVE_AFTER_CORRECT";
   if(geometric)boundary<<p.position().x()<<","<<p.position().y()<<","<<p.position().z();else boundary<<"NA,NA,NA";
   boundary<<","<<p.cell()<<","<<p.face()<<","<<p.tetFace()<<","<<p.tetPt()<<","<<r1::rng(cloud.rndGen())<<","<<p.active()<<","<<p.typeId();
   auto fields=r2::parcelScalars(const_cast<P&>(p));
   for(auto f:fields)boundary<<","<<r1::bits(*f);
   boundary<<","<<r2::ascii(static_cast<const particle&>(p))<<"\n";boundary.flush();
  };
  fiveEqDPM::CarrierBinding binding(&cloud,provider,&cloud.solution().interpolationSchemes());
  vector start(startX,.5,.5);

  reduce(logicalId,maxOp<label>());
  auto record=[&](const char*phase){label owned=0;for(auto it=cloud.begin();it!=cloud.end();++it){const auto&p=it();if(p.origProc()!=source||p.origId()!=logicalId)continue;++owned;events<<phase<<','<<Pstream::myProcNo()<<','<<p.origProc()<<','<<p.origId()<<','<<p.position().x()<<','<<p.position().y()<<','<<p.position().z()<<','<<p.cell()<<','<<p.tetFace()<<','<<p.tetPt()<<','<<p.face()<<','<<p.U().x()<<','<<p.d()<<','<<p.T()<<','<<p.nParticle()<<'\n';}label global=owned;reduce(global,sumOp<label>());if(global!=1)++failures;return owned;};
  label pre=record("before");if(pre!=(Pstream::myProcNo()==source?1:0))++failures;events.flush();
  runTime.setDeltaT(trackDt);runTime.setTime(trackDt,1);
  if(args.optionFound("unknownControl")){
   bool escaped=false;provider->unknownProbe=true;
   if(Pstream::myProcNo()==source){
    P::trackingData td(cloud);cloud.begin()().reset();
    try{cloud.begin()().move(cloud,td,.004);}
    catch(const std::logic_error&e){escaped=std::string(e.what())=="C1_TEST_PROGRAMMING_ERROR";}
    if(!escaped||latch.failed||latch.quarantines)++failures;
   }
   std::ofstream probe((runTime.path()/"C1_unknown.json").c_str());
   probe<<"{\"rank\":"<<Pstream::myProcNo()<<",\"escaped\":"<<escaped<<",\"latch\":"<<latch.failed<<",\"quarantines\":"<<latch.quarantines<<"}\n";
  }else{
  latch.phase("PRE_EVOLVE");
  if(args.optionFound("unlatchedControl"))c1::currentLatch()=nullptr;
  bool identityStop=false;label stableReg=mesh.Foam::objectRegistry::size();
  for(label step=0;step<steps;++step){
    runTime.setTime(trackDt*(step+1),step+1);runTime.setDeltaT(trackDt);
    {m8a3a::TrialScope passive;cloud.evolve();}
    label owned=cloud.size(),total=owned;reduce(total,sumOp<label>());if(!args.optionFound("allowNativeBirths")&&total!=1)++failures;
    Foam::List<Foam::labelList> identities(Pstream::nProcs());auto&ownIds=identities[Pstream::myProcNo()];ownIds.setSize(2*cloud.size());label idOffset=0;
    for(auto it=cloud.begin();it!=cloud.end();++it){ownIds[idOffset++]=it().origProc();ownIds[idOffset++]=it().origId();}
    Pstream::gatherList(identities);Pstream::scatterList(identities);
    std::set<std::pair<label,label>> uniqueIds;bool duplicate=false;
    for(const auto&rankIds:identities)for(label i=0;i<rankIds.size();i+=2)if(!uniqueIds.emplace(rankIds[i],rankIds[i+1]).second)duplicate=true;
    if(duplicate){identityStop=true;++failures;std::ofstream((runTime.path()/"MPI_OWNERSHIP_BLOCKER.txt").c_str(),std::ios::app)<<cycle<<','<<step<<",duplicate native origProc/origId\n";}
    if(!uniqueIds.count({source,logicalId}))++failures;
    const auto& lifeNow=i1::lifetime();if(lifeNow.constructed-lifeNow.destroyed!=lifeNow.live.size())++failures;
    if(step==0)stableReg=mesh.Foam::objectRegistry::size();else if(mesh.Foam::objectRegistry::size()!=stableReg)++failures;
    std::ofstream continuation((runTime.path()/"R1_continuation.csv").c_str(),std::ios::app);
    auto&drag=dynamic_cast<const m8a3a::DragAdapter&>(cloud.forces()[0]);
    auto&disp=dynamic_cast<m8a3a::DispersionAdapter&>(cloud.dispersion());
    auto&atom=dynamic_cast<const m8a3a::AtomizationAdapter&>(cloud.atomization());
    auto&kh=dynamic_cast<m8a3a::BreakupAdapter&>(cloud.breakup());
    auto&vf=dynamic_cast<m8a3a::VoidAdapter&>(cloud.functions()[0]);
    continuation<<cycle<<','<<step<<','<<Pstream::myProcNo()<<','<<owned<<','<<drag.calls<<','<<disp.calls<<','<<disp.randomCalls<<','<<atom.calls<<','<<kh.calls<<','<<vf.moves<<','<<r1::rng(cloud.rndGen())<<','<<lifeNow.constructed<<','<<lifeNow.destroyed<<','<<lifeNow.live.size()<<','<<mesh.Foam::objectRegistry::size();
    scalar sourceMag=0;for(const auto&v:cloud.UTrans())sourceMag+=mag(v);
    auto&theta=static_cast<r1::VF&>(vf).*r1::member(r1::VT{});scalar thetaV=0;if(theta.valid())forAll(theta->primitiveField(),c)thetaV+=theta->primitiveField()[c]*mesh.V()[c];
    continuation<<','<<std::setprecision(17)<<sourceMag<<','<<thetaV<<'\n';
    std::ofstream particles((runTime.path()/"R1_trajectory.csv").c_str(),std::ios::app);particles<<std::setprecision(17);
    for(auto it=cloud.begin();it!=cloud.end();++it){const auto&p=it();particles<<cycle<<','<<step<<','<<Pstream::myProcNo()<<','<<p.origProc()<<','<<p.origId()<<','<<p.position().x()<<','<<p.U().x()<<','<<p.d()<<','<<p.nParticle()<<','<<p.liquidCore()<<','<<p.tTurb()<<','<<p.UTurb().x()<<','<<p.UTurb().y()<<','<<p.UTurb().z()<<'\n';}
    if(identityStop)break;
  }
  c1::currentLatch()=&latch;
  latch.phase("NATIVE_MOVE_RETURNED");
  bool globalFailed=latch.failed;
  latch.phase("FAILURE_REDUCTION_ENTER");
  reduce(globalFailed,orOp<bool>());
  latch.phase("FAILURE_REDUCTION_EXIT");
  if(globalFailed!=invalid)++failures;
  label post=record("after");if(steps==1&&post!=(Pstream::myProcNo()==destination?1:0))++failures;
  if(latch.failed){
   if(latch.reason!="GAS_SUPPORT_INVALID:EXACT_GAS_ABSENT"||post!=1)++failures;
   if(physical(latch.pose)!=atFailure)++failures;
   if(owner.recoveries||owner.counters.rho||owner.counters.T||owner.counters.Y||owner.counters.Cp||owner.counters.mu||owner.counters.kappa)++failures;
  }
  if(owner.committed().generation!=1)++failures;
  std::ofstream failure((runTime.path()/"C1_latch.json").c_str());
  failure<<"{\"failed\":"<<latch.failed<<",\"trialRejected\":"<<globalFailed<<",\"reason\":\""<<latch.reason<<"\",\"origProc\":"<<latch.pose.origProc<<",\"origId\":"<<latch.pose.origId<<",\"cell\":"<<latch.pose.cell<<",\"tetFace\":"<<latch.pose.tetFace<<",\"tetPt\":"<<latch.pose.tetPt<<",\"generation\":1,\"acceptedSources\":0,\"acceptedOutputs\":0}\n";
  latch.phase("FIXTURE_DISCARD");
  if(!globalFailed){OStringStream wire;for(auto it=cloud.begin();it!=cloud.end();++it)wire<<it();
  std::ofstream stateOut((runTime.path()/"C1_valid_state.txt").c_str());stateOut<<wire.str();
  Random randomCopy(cloud.rndGen());
  std::ofstream rng((runTime.path()/"C1_rng_probe.txt").c_str());rng<<std::setprecision(17);
  for(unsigned j=0;j<32;++j)rng<<randomCopy.sample01<scalar>()<<'\n';}
  std::ofstream fullRng((runTime.path()/"N1_exact_rng.txt").c_str());fullRng<<r1::rng(cloud.rndGen());
  }
  tx.trial().allocator=particle::particleCount_;tx.trial().time=runTime.value();tx.trial().index=runTime.timeIndex();tx.trial().dt=trackDt;
  {const bool deliberate=args.optionFound("rejectFirstBirthTrial")&&cycle==0;
   const auto encoded=r2::encode(tx.trial());std::ofstream receipt((runTime.path()/("ID1_state_"+Foam::name(cycle)+".bin")).c_str(),std::ios::binary);receipt.write(encoded.data(),encoded.size());
   std::ofstream disposition((runTime.path()/"ID1_disposition.csv").c_str(),std::ios::app);disposition<<cycle<<','<<(deliberate?"REJECT_TEST_ONLY":"VALID_NATIVE_TRAJECTORY")<<','<<particle::particleCount_<<','<<tx.trial().cloud->size()<<std::endl;
   allocatorLog<<cycle<<",afterBirths,"<<particle::particleCount_<<std::endl;
   // Deliberate rejection is test-only, after native completion; existing discard below unchanged.
  }
  r2::Ticket pending;pending.sequence=cycle+1;pending.logicalTime="0.004";pending.files.emplace_back("trialDiagnostic","unaccepted / pending\n");output.prepare(pending);tx.trial().pending.push_back(pending);
 }
 fiveEqDPM::migrationR1::observer()={};
 if(args.optionFound("localAcceptLast")&&cycle==cycles-1&&!latch.failed&&!failures){
  tx.prepare();tx.publish();tx.flush();
  auto bytes=r2::encode(tx.accepted());std::ofstream accepted((runTime.path()/"ID1_local_accepted.bin").c_str(),std::ios::binary);accepted.write(bytes.data(),bytes.size());
  allocatorLog<<cycle<<",localAccepted,"<<particle::particleCount_<<std::endl;
  std::ofstream cert((runTime.path()/"ID1_local_acceptance.json").c_str());cert<<"{\"localPublication\":true,\"globalMPITransactionCertified\":false,\"publications\":"<<output.publications<<",\"allocator\":"<<particle::particleCount_<<",\"owned\":"<<tx.accepted().cloud->size()<<"}\n";
  liveBase=i1::lifetime().live.size();continue;
 }
 tx.discard();runTime.setTime(tx.accepted().time,tx.accepted().index);runTime.setDeltaT(tx.accepted().dt);
 allocatorLog<<cycle<<",afterDiscard,"<<particle::particleCount_<<std::endl;
 bool restored=committedBefore==r2::encode(tx.accepted())&&viewBefore==view.snapshot();
 if(!restored||output.publications||mesh.Foam::objectRegistry::size()!=registry||i1::lifetime().live.size()!=liveBase)++failures;
 if(i1::lifetime().constructed-counts.constructed!=i1::lifetime().destroyed-counts.destroyed)++failures;
 std::ofstream rollback((runTime.path()/"N1_discard.csv").c_str(),std::ios::app);rollback<<cycle<<','<<restored<<','<<output.publications<<','<<int(mesh.Foam::objectRegistry::size())-int(registry)<<','<<int(i1::lifetime().live.size())-int(liveBase)<<','<<tx.accepted().allocator<<','<<tx.accepted().generation<<'\n';

 if(!fiveEqDPM::carrierBindings().empty()||i1::lifetime().live.size()!=liveBase)++failures;
 results<<cycle<<','<<latch.failed<<','<<invalid<<",0,"<<provider->queries<<','<<owner.counters.rho<<','<<owner.counters.T<<','<<owner.counters.Y<<','<<owner.counters.Cp<<','<<owner.counters.mu<<','<<owner.counters.kappa<<','<<owner.recoveries<<','<<latch.quarantines<<",1,"<<fiveEqDPM::carrierBindings().size()<<','<<i1::lifetime().live.size()<<'\n';
 results.flush();latch.phase("FINALIZE");
 runTime.setTime(0,0);
 }
 const auto&life=i1::lifetime();label live=life.live.size();if(live!=liveBase||life.constructed-life.destroyed!=liveBase)++failures;
 label global=failures;reduce(global,sumOp<label>());
 std::ofstream out((runTime.path()/"native_crossing_result.json").c_str());out<<"{\"rank\":"<<Pstream::myProcNo()<<",\"failures\":"<<failures<<",\"globalFailures\":"<<global<<",\"queries\":"<<provider->queries<<",\"constructed\":"<<life.constructed<<",\"destroyed\":"<<life.destroyed<<",\"live\":"<<live<<",\"liveBaseline\":"<<liveBase<<",\"nativeCloudEvolve\":"<<(!args.optionFound("unknownControl"))<<",\"globalTransactionCertified\":false}\n";
 return global?1:0;
}
