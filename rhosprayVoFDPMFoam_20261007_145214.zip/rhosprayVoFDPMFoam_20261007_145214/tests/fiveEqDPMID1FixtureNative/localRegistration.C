/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2019 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "localTypes.H"
namespace Foam { typedef fiveEqDPM::LazySprayCloud r2bLocalSprayCloud; }

#include "makeParcelCloudFunctionObjects.H"

// Kinematic
#include "makeParcelForces.H"
#include "makeThermoParcelTurbulenceForces.H" // add turbulence variant
#include "makeParcelDispersionModels.H"
#include "makeParcelTurbulenceDispersionModels.H" // add turbulence variant
#include "makeSprayParcelInjectionModels.H" // Spray variant
#include "makeParcelPatchInteractionModels.H"
#include "makeSprayParcelStochasticCollisionModels.H" // Spray variant

// Thermodynamic
#include "makeParcelHeatTransferModels.H"

// Reacting
#include "makeReactingParcelCompositionModels.H"
#include "makeReactingParcelPhaseChangeModels.H"
#include "makeReactingParcelSurfaceFilmModels.H"

// Spray
#include "DistortedSphereDragForce.H"
#include "makeSprayParcelAtomizationModels.H"
#include "makeSprayParcelBreakupModels.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

makeParcelCloudFunctionObjects(r2bLocalSprayCloud);

// Kinematic sub-models
makeParcelForces(r2bLocalSprayCloud);
makeThermoParcelTurbulenceForces(r2bLocalSprayCloud);
makeParcelDispersionModels(r2bLocalSprayCloud);
makeParcelTurbulenceDispersionModels(r2bLocalSprayCloud);
makeSprayParcelInjectionModels(r2bLocalSprayCloud);
makeParcelPatchInteractionModels(r2bLocalSprayCloud);
makeSprayParcelStochasticCollisionModels(r2bLocalSprayCloud);

// Thermo sub-models
makeParcelHeatTransferModels(r2bLocalSprayCloud);

// Reacting sub-models
makeReactingParcelCompositionModels(r2bLocalSprayCloud);
makeReactingParcelPhaseChangeModels(r2bLocalSprayCloud);
makeReactingParcelSurfaceFilmModels(r2bLocalSprayCloud);

// Spray sub-models
makeParticleForceModelType(DistortedSphereDragForce, r2bLocalSprayCloud);
makeSprayParcelAtomizationModels(r2bLocalSprayCloud);
makeSprayParcelBreakupModels(r2bLocalSprayCloud);


// ************************************************************************* //
