#include "localTypes.H"
namespace Foam {
using R2CKinematic=fiveEqDPM::LazyKinematicParcel<particle>;
using R2CThermo=fiveEqDPM::LazyThermoParcel<R2CKinematic>;
using R2CReacting=fiveEqDPM::LazyReactingParcel<R2CThermo>;
defineNamedTemplateTypeNameAndDebug(R2CKinematic,0);
defineNamedTemplateTypeNameAndDebug(R2CThermo,0);
defineNamedTemplateTypeNameAndDebug(R2CReacting,0);
defineNamedTemplateTypeNameAndDebug(fiveEqDPM::LazyParcel,0);
defineNamedTemplateTypeNameAndDebug(Cloud<fiveEqDPM::LazyParcel>,0);
}
