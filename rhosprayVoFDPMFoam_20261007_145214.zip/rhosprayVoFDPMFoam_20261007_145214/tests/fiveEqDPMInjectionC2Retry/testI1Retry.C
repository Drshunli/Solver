#include "localTypes.H"
#include "lazyTrialBinding.H"
#include "fvCFD.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "SLGThermo.H"
#include "carrierTransaction.H"
#include "serialTransaction.H"
#include "nativeState.H"
#include "stateCodec.H"
#include "nativeObservedCalc.H"
#include "serialClosure.H"
#include <cstdlib>
#include <new>
namespace ownership {
const void*watched=nullptr;unsigned births=0;std::string fail;
void birth(r2::Cloud&,const Foam::fiveEqDPM::LazyParcel&p,double){watched=&p;++births;}
void hook(const char*phase,const void*p){watched=p;if(fail==phase)throw std::runtime_error("I1_FAILPOINT_"+fail);}
}
namespace r2c {const fiveEq::PrecisionOperator* op=nullptr;std::string thermal;}
int main(int argc,char**argv){
 if(argc!=4)return 2;
 using namespace Foam;using namespace fiveEq;
 i1::guarded()=true; i1::hook()=ownership::hook;
 fileName root(argv[1]);setenv("FOAM_CASE",argv[1],1);
 Time time(Time::controlDictName,root.path(),fileName(root.name()));
 fvMesh mesh(IOobject(fvMesh::defaultRegion,time.timeName(),time,IOobject::MUST_READ));
 auto thermo=psiReactionThermo::New(mesh);SLGThermo slg(mesh,thermo());
 volScalarField rho(IOobject("rho",time.timeName(),mesh),thermo->rho());
 volVectorField u(IOobject("U",time.timeName(),mesh),mesh,dimensionedVector("U",dimVelocity,vector(47,0,0)),"zeroGradient");u.correctBoundaryConditions();
 surfaceScalarField phi("phi",fvc::flux(rho*u));auto turbulence=compressible::turbulenceModel::New(rho,u,phi,thermo());
 dimensionedVector gravity("g",dimAcceleration,vector::zero);
 fiveEqGasThermoEvaluator gas(argv[2]);fiveEqLiquidThermoEvaluator liquid;fiveEqPrecisionRecovery recovery(gas,liquid);
 const auto names=thermo->composition().species();std::array<unsigned,3>index;
 for(unsigned i=0;i<3;++i)index[names[i]=="C10H22"?0:names[i]=="O2"?1:2]=i;
 PrecisionOperator op(recovery,index);PrecisionReconstruction rec(gas,liquid,op,index);
 r2c::op=&op;r2c::thermal=argv[2];std::ifstream data(argv[2],std::ios::binary);r2::thermodynamicIdentity=std::string(std::istreambuf_iterator<char>(data),{});
 std::vector<double> hc(3);for(unsigned i=0;i<3;++i)hc[index[i]]=gas.speciesData()[i].Hc();fiveEqDPMSourceAdapter adapter(hc);
 r2c::LocalCommittedView view(thermo(),rho,u,op,gas,argv[2]);t3a::epoch=&view.token;

 unsigned checks=0,failures=0;std::ofstream bad("failures.txt");
 auto check=[&](bool ok,const std::string&n){++checks;if(!ok){++failures;bad<<n<<'\n';}};
 const auto gasQ=rec.generate(PrecisionFraction::liquid(0,FractionMode::P2),3e6,800,300,vector(47,0,0),{0,.228,.772});
 const auto pureQ=rec.generate(PrecisionFraction::liquid(1,FractionMode::P2),3e6,800,300,vector(47,0,0),{0,.228,.772});
 auto fresh=[&](const std::vector<PrecisionCell>&q){
  auto s=std::unique_ptr<r2::State>(new r2::State);s->q=q;
  auto pub=view.prepareCommit(view.prepare(q));view.publishCommitNoFail(pub);view.token.publishing=false;
  {m8a3a::TrialScope passive;s->cloud.reset(new r2::Cloud("roleA",rho,u,gravity,slg,false));}
  s->allocator=particle::particleCount_;s->generation=view.token.generation;s->time=time.value();s->index=time.timeIndex();return s;
 };
 r2::birthHook=ownership::birth;
 std::ofstream csv("lifetime.csv");csv<<"scenario,ctor,dtor,guardAdopt,guardDelete,cloudAdopt,moveFalse,liveBefore,liveAfter,canonical,gasRecovery,thermo,output\n";

 std::vector<PrecisionCell>q(mesh.nCells(),gasQ);
 unsigned gasCells=0;
 for(Foam::label i=0;i<mesh.nCells();++i){if(mesh.C()[i].x()>1.5)q[i]=pureQ;else ++gasCells;}
 auto seed=fresh(q);auto initialGeneration=seed->generation;auto allocator=seed->allocator;
 const auto encoded=r2::encode(*seed);std::vector<std::string>keys,queries,carriers;bool equality=true,supportRejected=false;
 std::ofstream table("retry_lifetime.csv");table<<"path,step,ctor,dtor,live,cloudOwned,canonicalEqual\n";
 for(unsigned path=0;path<2;++path){
  auto start=r2::decode(encoded,"roleB",*seed->cloud,slg);
  auto pub=view.prepareForRestore(start->q,initialGeneration);view.publishCommitNoFail(pub);view.token.publishing=false;particle::particleCount_=allocator;
  r2::Output out(path?"retry_output":"direct_output");r2::Transaction trial(std::move(start),view,slg,time,op,adapter,out);
  if(path){
   auto before=r2::encode(trial.accepted()),snap=view.snapshot();auto counts=i1::lifetime();ownership::fail="";trial.begin();std::string reason;
   try{trial.evolve(0.1);}catch(const std::exception&e){supportRejected=std::string(e.what()).find("GAS_SUPPORT_INVALID")!=std::string::npos;reason=e.what();}
   check(supportRejected,"largeDtActualSupportException");check(i1::lifetime().guardDestroyed>counts.guardDestroyed,"largeDtGuardCleanup");
   trial.discard();check(before==r2::encode(trial.accepted())&&snap==view.snapshot(),"largeDtCanonicalRollback");check(i1::lifetime().live.size()==counts.live.size(),"largeDtLifetimeRollback");check(out.publications==0,"largeDtNoAcceptedOutput");std::ofstream("support_reason.txt")<<reason<<'\n';
  }
  for(unsigned step=0;step<11;++step){
   ownership::fail="";trial.begin();trial.evolve(5e-8);auto query=trial.ledger->queryResults;trial.prepare();trial.publish();trial.flush();
   auto code=r2::encode(trial.accepted()),snap=view.snapshot();
   check(i1::lifetime().live.size()==uint64_t(trial.accepted().cloud->size()),"futureAllLiveCloudOwned");
   check(i1::lifetime().constructed==i1::lifetime().destroyed+i1::lifetime().live.size(),"futureCtorDtorClosure");
   if(path){equality=code==keys[step]&&snap==carriers[step]&&query==queries[step];check(equality,"retryCanonicalCarrierQueryExact");}
   else{keys.push_back(code);carriers.push_back(snap);queries.push_back(query);}
   table<<path<<','<<step<<','<<i1::lifetime().constructed<<','<<i1::lifetime().destroyed<<','<<i1::lifetime().live.size()<<','<<trial.accepted().cloud->size()<<','<<equality<<'\n';
   std::ofstream("path_"+std::to_string(path)+"_step_"+std::to_string(step)+".bin",std::ios::binary)<<code;
  }
 }
 check(i1::lifetime().live.empty(),"allCloudsClosedAtEnd");
 std::ofstream("retry_result.json")<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"supportRejected\":"<<supportRejected<<",\"futureSteps\":10,\"gasCells\":"<<gasCells<<",\"constructed\":"<<i1::lifetime().constructed<<",\"destroyed\":"<<i1::lifetime().destroyed<<",\"live\":"<<i1::lifetime().live.size()<<",\"noCFD\":true}\n";
 return failures?1:0;
}
