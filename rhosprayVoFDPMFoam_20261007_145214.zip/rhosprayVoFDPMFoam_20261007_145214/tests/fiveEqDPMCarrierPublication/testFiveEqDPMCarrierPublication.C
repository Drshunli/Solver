#include "fvCFD.H"
#include "carrierEpoch.H"
#include "interpolationCellPoint.H"
#include "volPointInterpolation.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "SLGThermo.H"
#include "basicSprayCloud.H"
#include "carrierTransaction.H"
#include "serialTransaction.H"
#include <fstream>
#include <chrono>
using namespace fiveEq;
static void add(ParcelEnergyState&a,const ParcelEnergyState&b){a.massKg+=b.massKg;a.enthalpyJ+=b.enthalpyJ;a.volumeM3+=b.volumeM3;a.kineticJ+=b.kineticJ;a.momentumKgMS+=b.momentumKgMS;if(a.carrierSpeciesKg.empty())a.carrierSpeciesKg.assign(b.carrierSpeciesKg.size(),0);for(unsigned j=0;j<b.carrierSpeciesKg.size();++j)a.carrierSpeciesKg[j]+=b.carrierSpeciesKg[j];}
int main(int argc,char**argv){
 if(argc!=4)return 2;std::string state(argv[2]);unsigned history=state=="A"?5:state=="B"?7:9;
 Foam::fileName root(argv[1]);setenv("FOAM_CASE",argv[1],1);Foam::Time time(Foam::Time::controlDictName,root.path(),Foam::fileName(root.name()));Foam::fvMesh mesh(Foam::IOobject(Foam::fvMesh::defaultRegion,time.timeName(),time,Foam::IOobject::MUST_READ));
 auto thermo=Foam::psiReactionThermo::New(mesh);Foam::SLGThermo slg(mesh,thermo());Foam::volScalarField rho(Foam::IOobject("rho",time.timeName(),mesh),thermo->rho());Foam::volVectorField U(Foam::IOobject("U",time.timeName(),mesh),mesh,Foam::dimensionedVector("U",Foam::dimVelocity,Foam::vector(47,0,0)),"zeroGradient");U.correctBoundaryConditions();Foam::surfaceScalarField phi("phi",Foam::fvc::flux(rho*U));auto turb=Foam::compressible::turbulenceModel::New(rho,U,phi,thermo());Foam::dimensionedVector gravity("g",Foam::dimAcceleration,Foam::vector::zero);
 fiveEqGasThermoEvaluator gas(argv[3]);fiveEqLiquidThermoEvaluator liquid;fiveEqPrecisionRecovery recovery(gas,liquid);
 auto names=thermo->composition().species();std::array<unsigned,3> index;for(unsigned j=0;j<3;++j)index[names[j]=="C10H22"?0:names[j]=="O2"?1:2]=j;
 PrecisionOperator op(recovery,index);PrecisionReconstruction rec(gas,liquid,op,index);std::vector<double>hc(3);for(unsigned j=0;j<3;++j)hc[index[j]]=gas.speciesData()[j].Hc();fiveEqDPMSourceAdapter adapter(hc);
 t3a::StableCommittedCarrierView view(thermo(),rho,U,op,gas,argv[3]);t3a::epoch=&view.token;
 std::vector<PrecisionCell> anchor(mesh.nCells(),rec.generate(PrecisionFraction::liquid(0,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772}));
 auto boot=view.prepareCommit(view.prepare(anchor));view.publishCommitNoFail(boot);view.token.publishing=false;
 auto initial=std::unique_ptr<t3a::RoleState>(new t3a::RoleState);initial->cloud.reset(new m8a3a::Cloud("roleA",rho,U,gravity,slg,false));time.setDeltaT(1e-6);{m8a3a::TrialScope scope;for(unsigned i=0;i<history;++i){++time;initial->cloud->evolve();}}
 initial->q=anchor;initial->allocator=Foam::particle::particleCount_;initial->time=time.value();initial->index=time.timeIndex();const auto seed=initial->cloud->size();t3a::CarrierTransaction tx(std::move(initial),view,slg,time);
 unsigned checks=0,failures=0,swaps=0;std::ofstream bad("test_failures.txt"),rows("carrier_queries.csv"),cv("cases.csv");rows<<"case,cell,rho,p,T,Cp,mu,kappa,Ux,Uy,Uz,generation\n";cv<<"case,qChanged,p2Unchanged,liquidMassUnchanged,precommitUnchanged,queryPass\n";
 auto check=[&](bool b,const std::string&n){++checks;if(!b){++failures;bad<<n<<'\n';}};
 auto fails=[&](std::function<void()>f,const char*n){bool rejected=false;try{f();}catch(const std::exception&){rejected=true;}check(rejected,n);};
 auto close=[](double a,double b){return std::abs(a-b)<=2e-12*std::max({std::abs(a),std::abs(b),1e-300});};
 const void* rhoID=&rho;const void* uID=&U;const void* tID=&thermo->T();const void* pID=&thermo->p();const void* muID=&mesh.lookupObject<Foam::volScalarField>("thermo:mu");
 auto query=[&](m8a3a::Cloud&cloud,const std::vector<PrecisionCell>&q,const std::string&label){
  Foam::basicSprayParcel::trackingData td(cloud);
  check(dynamic_cast<const t3a::CheckedInterpolation<Foam::vector>*>(&td.UInterp())!=nullptr,"realNativeTrackingGenerationGuard");
  for(Foam::label i=0;i<mesh.nCells();++i){auto s=view.recover(q[i]);auto pos=mesh.C()[i];double R=td.rhoInterp().interpolate(pos,i),P=td.pInterp().interpolate(pos,i),T=td.TInterp().interpolate(pos,i),C=td.CpInterp().interpolate(pos,i),M=td.muInterp().interpolate(pos,i),K=td.kappaInterp().interpolate(pos,i);auto velocity=td.UInterp().interpolate(pos,i);
   check(R==s.rho&&P==s.p&&T==s.T,"nativeIntrinsicRhoPTExact");check(velocity==s.U,"nativeUFromAcceptedMExact");check(close(C,s.Cp)&&close(M,s.mu)&&close(K,s.kappa),"nativeTransportFromAcceptedGasState");for(unsigned j=0;j<3;++j)check(cloud.thermo().carrier().Y()[j][i]==s.Y[j],"nativeRuntimeSpeciesExact");rows<<std::setprecision(17)<<label<<','<<i<<','<<R<<','<<P<<','<<T<<','<<C<<','<<M<<','<<K<<','<<velocity.x()<<','<<velocity.y()<<','<<velocity.z()<<','<<view.token.generation<<'\n';
   // Off-centre native cellPoint values against a fresh, unguarded native object.
   Foam::interpolationCellPoint<Foam::vector> direct(U,Foam::volPointInterpolation::New(mesh).interpolate(U,"t3aUncachedU",false));auto off=.9*pos+.1*mesh.points()[mesh.cellPoints()[i][0]];
   check(td.UInterp().interpolate(off,i)==direct.interpolate(off,i),"freshNativePointCacheExact");
  }
  const auto&bound=U.boundaryField();for(Foam::label patch=0;patch<bound.size();++patch)for(Foam::label f=0;f<bound[patch].size();++f){auto s=view.recover(q[mesh.boundary()[patch].faceCells()[f]]);check(U.boundaryField()[patch][f]==s.U,"boundaryUOwnerQExact");check(rho.boundaryField()[patch][f]==s.rho&&thermo->T().boundaryField()[patch][f]==s.T&&thermo->p().boundaryField()[patch][f]==s.p,"boundaryGasOwnerQExact");}
  check(&cloud.rho()==rhoID&&&cloud.U()==uID&&&cloud.T()==tID&&&cloud.p()==pID&&&cloud.mu()==muID,"stableAllNativeDirectReferences");
  check(U.oldTime().primitiveField()==U.primitiveField(),"explicitFrozenCarrierOldTime");
 };
 query(tx.cloud(),tx.accepted().q,"initial");
 auto publish=[&](const std::vector<PrecisionCell>&q,const std::string&label){
  auto old=view.snapshot();auto gen=view.token.generation;tx.beginTrial();auto&trial=tx.trial();trial.q=q;
  std::unique_ptr<Foam::basicSprayParcel::trackingData> stale(new Foam::basicSprayParcel::trackingData(*trial.cloud));
  tx.prepareCommit();check(view.snapshot()==old&&view.token.generation==gen,"preparedCommittedCarrierUnchanged");tx.publishCommitNoFail();++swaps;check(view.token.generation==gen+1&&tx.accepted().expected==view.token.generation,"promotedGenerationMatches");fails([&](){stale->UInterp().interpolate(mesh.C()[0],0);},"oldTrackingDataGenerationRejected");stale.reset();query(tx.cloud(),tx.accepted().q,label);
 };
 // CV-1: reproduce actual legal tiny native evolution with the selected graph.
 auto old=view.snapshot();tx.beginTrial();auto&trial=tx.trial();std::vector<ParcelEnergyState>before(mesh.nCells()),after(mesh.nCells());
 for(auto it=trial.cloud->begin();it!=trial.cloud->end();++it)add(before[it().cell()],parcelEnergyState(*trial.cloud,it(),trial.cloud->p()[it().cell()]));
 tx.evolveTrial(1e-30);for(auto it=trial.cloud->begin();it!=trial.cloud->end();++it)add(after[it().cell()],parcelEnergyState(*trial.cloud,it(),trial.cloud->p()[it().cell()]));
 bool transverse=false;std::ofstream sources("CV1_native_source.csv");sources<<"cell,dMx,dMy,dMz,dEt,UyOld,UyStaged\n";
 for(Foam::label i=0;i<mesh.nCells();++i){if(before[i].carrierSpeciesKg.empty())before[i].carrierSpeciesKg.assign(3,0);if(after[i].carrierSpeciesKg.empty())after[i].carrierSpeciesKg.assign(3,0);DPMExchangeContext c;c.heldPressurePa=trial.cloud->p()[i];auto s=adapter.convert(nativeCellTransfer(*trial.cloud,i),before[i],after[i],c);auto q=adapter.trial(trial.q[i],mesh.V()[i],s,op);transverse=transverse||(q.q[4]!=trial.q[i].q[4]);sources<<std::setprecision(17)<<i<<','<<s.dM.x()<<','<<s.dM.y()<<','<<s.dM.z()<<','<<s.dEt<<','<<view.recover(trial.q[i]).U.y()<<','<<view.recover(q).U.y()<<'\n';trial.q[i]=q;}
 check(transverse,"CV1LegalNonzeroTransverseMomentum");tx.prepareCommit();check(view.snapshot()==old,"CV1PrecommitUUnchanged");tx.publishCommitNoFail();++swaps;query(tx.cloud(),tx.accepted().q,"CV1");cv<<"CV1,1,1,1,1,1\n";
 // Immediate next native step after the golden transverse publication, using
 // the accepted carrier in both a promoted and a direct reference cloud.
 {std::unique_ptr<m8a3a::Cloud> ref;{m8a3a::TrialScope passive;ref.reset(new m8a3a::ReconstructedCloud("referenceA",tx.cloud(),slg));}
  query(*ref,tx.accepted().q,"CV1_direct_reference");tx.beginTrial();const auto alloc=tx.trial().allocator,id=Foam::particle::particleCount_,ti=time.timeIndex();const auto tv=time.value(),dt=time.deltaTValue();time.setDeltaT(1e-30);time.setTime(tx.accepted().time+1e-30,tx.accepted().index+1);Foam::particle::particleCount_=alloc;{m8a3a::TrialScope passive;ref->evolve();}const auto refAllocator=Foam::particle::particleCount_;Foam::particle::particleCount_=id;time.setTime(tv,ti);time.setDeltaT(dt);tx.evolveTrial(1e-30);
  check(m8a3bt3::parcelDump(*ref)==m8a3bt3::parcelDump(*tx.trial().cloud),"CV1NextNativeParcelExact");check(m8a3bt3::sourceDump(*ref)==m8a3bt3::sourceDump(*tx.trial().cloud),"CV1NextNativeSourceExact");check(tx.trial().allocator==refAllocator,"CV1NextNativeAllocatorExact");tx.prepareCommit();tx.publishCommitNoFail();++swaps;query(tx.cloud(),tx.accepted().q,"CV1_next_step");}
 // Native single-parcel source probes, with original frozen fixture physics.
 auto nativeSource=[&](const std::string&mode,double multiplicity){
  const auto id=Foam::particle::particleCount_;fiveEqDPMSourceIncrement increment;
  {m8a3a::TrialScope passive;m8a3a::Cloud source("cvSource"+Foam::word(mode),rho,U,gravity,slg,false);source.resetSourceTerms();
   auto*p=new Foam::basicSprayParcel(mesh,mesh.C()[0],0);source.setParcelThermoProperties(*p,1e-5);p->T()=300;p->Y()=Foam::scalarField(1,1);p->rho()=source.composition().liquids().rho(thermo->p()[0],300,p->Y());p->d()=p->d0()=.0003;p->nParticle()=multiplicity;p->mass0()=p->mass();p->liquidCore()=0;p->U()=mode=="momentum"||mode=="combined"?Foam::vector(100,20,0):U[0];source.addParticle(p);
   auto b=parcelEnergyState(source,*p,source.p()[0]);Foam::basicSprayParcel::trackingData td(source);td.keepParticle=true;p->setCellValues(source,td);p->calc(source,td,1e-5);auto a=td.keepParticle?parcelEnergyState(source,*p,source.p()[0]):ParcelEnergyState();if(!td.keepParticle)a.carrierSpeciesKg.assign(3,0);DPMExchangeContext context;context.heldPressurePa=source.p()[0];context.clipped=td.keepParticle&&(p->T()<=source.constProps().TMin()||p->T()>=source.constProps().TMax());increment=adapter.convert(nativeCellTransfer(source,0),b,a,context);
  }Foam::particle::particleCount_=id;return increment;
 };
 auto runCV=[&](const std::string&label,const std::string&mode,double alpha,double n){
  // Initialize an explicit legal reference state, then apply a real native event.
  std::vector<PrecisionCell>q(mesh.nCells(),rec.generate(PrecisionFraction::liquid(alpha,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772}));publish(q,label+"_reference");auto s=nativeSource(mode,n);auto initial=q;for(Foam::label i=0;i<mesh.nCells();++i)q[i]=adapter.trial(q[i],mesh.V()[i],s,op);bool changed=!exactCellEqual(q[0],initial[0]);check(changed,label+"_QChanged");check(exactBits(q[0].fraction.payload().hi)==exactBits(initial[0].fraction.payload().hi)&&q[0].q[2]==initial[0].q[2],label+"_P2LiquidMassUnchanged");if(label=="CV2")check(q[0].q[1]!=initial[0].q[1],"CV2MassChanged");if(label=="CV3")check(view.recover(q[0]).T!=view.recover(initial[0]).T,"CV3TemperatureChanged");if(label=="CV4")check(view.recover(q[0]).Y!=view.recover(initial[0]).Y,"CV4SpeciesChanged");if(label=="CV5")check(q[0].q[1]!=initial[0].q[1]&&q[0].q[3]!=initial[0].q[3]&&q[0].q[4]!=initial[0].q[4]&&q[0].q[6]!=initial[0].q[6]&&q[0].q[7]!=initial[0].q[7],"CV5AllRequestedConservativesChanged");publish(q,label);cv<<label<<','<<changed<<",1,1,1,1\n";
 };
 runCV("CV2","mass",0,1e8);runCV("CV3","heat",0,1e8);runCV("CV4","mass",0,1e8);runCV("CV5","combined",0,1e8);
 for(double a:{.1,.5,.9})runCV("MIXED_"+std::to_string(a),"combined",a,1e8);
 // Trace source is generated natively at a small positive real multiplicity.
 std::vector<PrecisionCell>trace(mesh.nCells(),rec.generate(PrecisionFraction::minority(1e-20,true,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772}));publish(trace,"TRACE_reference");auto tiny=nativeSource("mass",1e-12);for(auto&q:trace)q=adapter.trial(q,1,tiny,op);check(op.recover(trace[0]).gasPresence==PhasePresence::TRACE_PRESENT,"tracePresenceRetained");publish(trace,"TRACE_accepted");
 auto snapshot=view.snapshot();auto pure=trace;for(auto&q:pure)q=rec.generate(PrecisionFraction::liquid(1,FractionMode::P2),3e6,800,300,Foam::vector(47,0,0),{0,.228,.772});fails([&](){view.prepare(pure);},"pureLiquidPublicationCannotManufactureGas");check(view.snapshot()==snapshot,"pureLiquidRefusalNoMutation");
 // Held mutable aliases cannot change a sealed Q and publish stale buffers.
 tx.beginTrial();auto&held=tx.trial();tx.prepareCommit();held.q[0].q[4]=1;fails([&](){tx.publishCommitNoFail();},"sealedQMutationRejectedBeforePublication");check(view.snapshot()==snapshot,"sealedQRefusalNoCarrierMutation");tx.discard();
 // Repeated A->B->A publication of gas-present recovered states.
 publish(anchor,"role_swap_reference");
 for(unsigned i=0;i<100;++i){auto q=tx.accepted().q;auto s=nativeSource("momentum",1e5);for(auto&c:q)c=adapter.trial(c,1,s,op);publish(q,"role_swap_"+std::to_string(i));}
 // Warm all native caches before registry-lifecycle measurement.
 query(tx.cloud(),tx.accepted().q,"lifecycle_warm");const auto registry=mesh.Foam::objectRegistry::size();snapshot=view.snapshot();auto currentGeneration=view.token.generation;for(unsigned i=0;i<1000;++i){tx.beginTrial();tx.prepareCommit();tx.discard();check(view.snapshot()==snapshot&&view.token.generation==currentGeneration,"preparedDiscardCarrierExact");check(mesh.Foam::objectRegistry::size()==registry,"stagedUnregisteredRegistryStable");check(&mesh.lookupObject<Foam::volScalarField>("rho")==rhoID&&&mesh.lookupObject<Foam::volVectorField>("U")==uID,"stableRegisteredObjectsAfterLifecycle");}
 // Future model equivalence on prescribed accepted carrier states. This is a
 // carrier architecture test, not T3 event-ledger or source/Q retry proof.
 std::unique_ptr<m8a3a::Cloud> reference;{m8a3a::TrialScope passive;reference.reset(new m8a3a::ReconstructedCloud("referenceA",tx.cloud(),slg));}
 auto refTime=tx.accepted().time;auto refIndex=tx.accepted().index;
 for(unsigned i=0;i<10;++i){
  tx.beginTrial();const auto ids=tx.trial().allocator,outerID=Foam::particle::particleCount_;const auto tv=time.value(),dt=time.deltaTValue();const auto ti=time.timeIndex();time.setTime(refTime+1e-6,refIndex+1);time.setDeltaT(1e-6);Foam::particle::particleCount_=ids;{m8a3a::TrialScope passive;reference->evolve();}const auto refID=Foam::particle::particleCount_;refTime=time.value();refIndex=time.timeIndex();Foam::particle::particleCount_=outerID;time.setTime(tv,ti);time.setDeltaT(dt);tx.evolveTrial(1e-6);auto&c=*tx.trial().cloud;
  check(m8a3bt3::parcelDump(*reference)==m8a3bt3::parcelDump(c),"futureNativeParcelExact");check(m8a3bt3::sourceDump(*reference)==m8a3bt3::sourceDump(c),"futureNativeSourcesExact");check(m8a3a::randomSequence(reference->rndGen())==m8a3a::randomSequence(c.rndGen()),"futureNativeRNGProbeExact");check(m8a3a::ConeAdapter::exportMutableState(reference->injectors()[0]).key()==m8a3a::ConeAdapter::exportMutableState(c.injectors()[0]).key(),"futureInjectorExact");check(tx.trial().allocator==refID,"futureAllocatorExact");tx.prepareCommit();tx.publishCommitNoFail();++swaps;query(tx.cloud(),tx.accepted().q,"future_role");query(*reference,tx.accepted().q,"future_reference");
 }
 view.token.publishing=true;fails([&](){tx.cloud();},"observerCannotSeePartialPublication");view.token.publishing=false;
 check(view.token.queries>0,"nativeCarrierQueriesGuarded");
 std::ofstream result("test_results.json");result<<"{\"state\":\""<<state<<"\",\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"seedSteps\":"<<history<<",\"seedParcels\":"<<seed<<",\"acceptedRoleSwaps\":"<<swaps<<",\"prepareDiscardCycles\":1000,\"futureSteps\":10,\"carrierGeneration\":"<<view.token.generation<<",\"guardedQueries\":"<<view.token.queries<<",\"CV1transverse\":"<<(transverse?"true":"false")<<",\"T3FullTransactionSafe\":false,\"noCFD\":true}\n";
 return failures?1:0;
}
