#include "DistributedCarrierSupport.H"
#include "fiveEqPrecisionReconstruction.H"
#include "processorPolyPatch.H"
#include <fstream>
#include <iomanip>
int main(int argc,char**argv){
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 unsigned checks=0,failures=0;
 std::ofstream bad((runTime.path()/"S1_audit_failures.txt").c_str());
 auto check=[&](bool ok,const std::string&name){++checks;if(!ok){++failures;bad<<name<<'\n';}};
 if(Foam::Pstream::parRun()){
  s1::DistributedSparsePointSupport support(mesh);
  std::ofstream csv((runTime.path()/"S1_pose_topology.csv").c_str());csv<<std::setprecision(17);
  csv<<"rank,cell,requestedFace,x,y,z,tetVertex0,tetVertex1,tetVertex2,bary0,bary1,bary2,bary3,processorPatch,neighbourRank,entityRank,entityKind,entityLocal,entityPhysicalPatch";
  for(unsigned j=0;j<9;++j)csv<<",w"<<j;
  csv<<'\n';
  Foam::label patch=-1,neighbour=-1;
  forAll(mesh.boundary(),p)if(Foam::isA<Foam::processorPolyPatch>(mesh.boundaryMesh()[p])){patch=p;neighbour=Foam::refCast<const Foam::processorPolyPatch>(mesh.boundaryMesh()[p]).neighbProcNo();}
  check(patch>=0&&neighbour==1-Foam::Pstream::myProcNo(),"actualProcessorRelation");
  unsigned remote=0;
  forAll(mesh.C(),c){
   Foam::vector pos=mesh.C()[c]+Foam::vector(Foam::Pstream::myProcNo()==0?.31:-.31,.07,.11);
   Foam::cellPointWeight cw(mesh,pos,c,-1);auto entries=support.build(pos,c,-1);
   for(const auto&e:entries){const auto&k=support.keys()[e.index];if(k.rank==Foam::Pstream::myProcNo())continue;++remote;
    csv<<Foam::Pstream::myProcNo()<<','<<c<<",-1,"<<pos.x()<<','<<pos.y()<<','<<pos.z();
    for(unsigned j=0;j<3;++j)csv<<','<<cw.faceVertices()[j];
    for(unsigned j=0;j<4;++j)csv<<','<<cw.weights()[j];
    csv<<','<<patch<<','<<neighbour<<','<<k.rank<<','<<k.kind<<','<<k.local<<','<<k.patch;
    for(unsigned j=0;j<9;++j)csv<<','<<e.weight[j];
    csv<<'\n';
    check(k.rank==neighbour&&s1::nonzero(e.weight),"remoteKeyAndWeight");
   }
  }
  check(remote>0,"actualRemoteTopologyRecorded");
 }else{
  std::string thermal="/mnt/d/DATA/Solver/300_2D/constant/thermal.dat";
  fiveEq::fiveEqGasThermoEvaluator gas(thermal);fiveEq::fiveEqLiquidThermoEvaluator liquid;fiveEq::fiveEqPrecisionRecovery recovery(gas,liquid);fiveEq::PrecisionOperator op(recovery,{0,1,2});fiveEq::PrecisionReconstruction rec(gas,liquid,op,{0,1,2});
  Foam::volVectorField geometry(Foam::IOobject("S1Audit:geometry",runTime.timeName(),mesh,Foam::IOobject::NO_READ,Foam::IOobject::NO_WRITE,false),mesh,Foam::dimensionedVector("zero",Foam::dimVelocity,Foam::vector::zero));
  r2a::CarrierQueryOwner owner(geometry,op,thermal);
  auto make=[&](const fiveEq::PrecisionFraction&f){return rec.generate(f,188330.307,400,300,Foam::vector(47,4,3),{0,.228,.772});};
  auto publish=[&](const fiveEq::PrecisionCell&q){std::vector<fiveEq::PrecisionCell>cells(mesh.nCells(),q),boundary(mesh.nFaces()-mesh.nInternalFaces(),q);std::vector<std::string>kinds(boundary.size(),"EXPLICIT_PHYSICAL_FACE_STATE");auto candidate=owner.prepareCommit(cells,boundary,kinds);owner.commit(candidate);};
  std::ofstream csv((runTime.path()/"serial_phase_regression.csv").c_str());csv<<std::setprecision(17)<<"phase,payload,mG,valid,rho,T,Cp,mu,kappa\n";
  for(double a:{0.,.1,.5,.9}){
   auto q=make(fiveEq::PrecisionFraction::liquid(a,fiveEq::FractionMode::P2));publish(q);auto reference=op.recover(q);owner.counters=r2a::Counters{};
   auto packet=owner.query(mesh.C()[0],0,r2a::All);
   check(packet.rho==reference.rhoG&&packet.T==reference.TG&&packet.p==reference.p,"serialMixedScalarNativeRecovery");
   check(packet.Cp>0&&packet.mu>0&&packet.kappa>0,"serialMixedTransportValid");check(owner.counters.materialize==1,"serialBackendUsed");
   csv<<a<<','<<q.fraction.payload().hi<<','<<q.q[1]<<",1,"<<packet.rho<<','<<packet.T<<','<<packet.Cp<<','<<packet.mu<<','<<packet.kappa<<'\n';
  }
  auto trace=make(fiveEq::PrecisionFraction::minority(1e-20,true,fiveEq::FractionMode::P2));publish(trace);owner.counters=r2a::Counters{};auto packet=owner.query(mesh.C()[0],0,r2a::All);auto reference=op.recover(trace);
  check(owner.map().cellSupport[0].phase==r2a::Presence::TRACE_PRESENT,"serialTracePresenceUnchanged");check(packet.rho==reference.rhoG&&packet.rho>0,"serialTraceIntrinsicDensity");check(owner.map().cells[0].fraction.payload().hi==trace.fraction.payload().hi,"serialTracePayloadUnchanged");
  csv<<"trace,"<<trace.fraction.payload().hi<<','<<trace.q[1]<<",1,"<<packet.rho<<','<<packet.T<<','<<packet.Cp<<','<<packet.mu<<','<<packet.kappa<<'\n';
  auto pure=make(fiveEq::PrecisionFraction::liquid(1,fiveEq::FractionMode::P2));publish(pure);owner.counters=r2a::Counters{};
  bool rejected=false;try{owner.query(mesh.C()[0],0,r2a::All);}catch(const std::exception&){rejected=true;}
  check(rejected&&owner.counters.thermoCalls()==0&&owner.counters.U==0,"serialAbsentSupportFirstZeroCalls");check(owner.map().gasRecoveryCalls==0&&!owner.map().cellSupport[0].gas,"serialAbsentNoFakeGas");
  csv<<"absent,"<<pure.fraction.payload().hi<<",0,0,nan,nan,nan,nan,nan\n";
 }
 Foam::label global=failures;Foam::reduce(global,Foam::sumOp<Foam::label>());
 std::ofstream result((runTime.path()/"S1_audit_result.json").c_str());result<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"globalFailures\":"<<global<<",\"parallel\":"<<(Foam::Pstream::parRun()?"true":"false")<<",\"parcelCrossing\":false}\n";
 return global?1:0;
}
