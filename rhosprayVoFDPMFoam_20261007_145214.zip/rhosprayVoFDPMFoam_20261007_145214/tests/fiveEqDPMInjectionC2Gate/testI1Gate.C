#include "localTypes.H"
#include "lazyTrialBinding.H"
#include "fvCFD.H"
#include "turbulentFluidThermoModel.H"
#include "psiReactionThermo.H"
#include "SLGThermo.H"
#include "carrierTransaction.H"
#include "serialTransaction.H"
#include "nativeState.H"
#include "stateCodec.H"
#include "nativeObservedCalc.H"
#include "serialClosure.H"
#include <cstdlib>
#include <new>
namespace ownership {
const void*watched=nullptr;unsigned births=0;std::string fail; r2::Cloud*cloud=nullptr;std::string cleanupSource;
void birth(r2::Cloud&,const Foam::fiveEqDPM::LazyParcel&p,double){watched=&p;++births;}
void hook(const char*phase,const void*p){watched=p;if(fail==phase){if(cloud)cleanupSource=m8a3bt3::sourceDump(*cloud);throw std::runtime_error("I1_FAILPOINT_"+fail);}}
}
namespace r2c {const fiveEq::PrecisionOperator* op=nullptr;std::string thermal;}
int main(int argc,char**argv){
 if(argc!=4)return 2;
 using namespace Foam;using namespace fiveEq;
 i1::guarded()=true; i1::hook()=ownership::hook;
 fileName root(argv[1]);setenv("FOAM_CASE",argv[1],1);
 Time time(Time::controlDictName,root.path(),fileName(root.name()));
 fvMesh mesh(IOobject(fvMesh::defaultRegion,time.timeName(),time,IOobject::MUST_READ));
 auto thermo=psiReactionThermo::New(mesh);SLGThermo slg(mesh,thermo());
 volScalarField rho(IOobject("rho",time.timeName(),mesh),thermo->rho());
 volVectorField u(IOobject("U",time.timeName(),mesh),mesh,dimensionedVector("U",dimVelocity,vector(47,0,0)),"zeroGradient");u.correctBoundaryConditions();
 surfaceScalarField phi("phi",fvc::flux(rho*u));auto turbulence=compressible::turbulenceModel::New(rho,u,phi,thermo());
 dimensionedVector gravity("g",dimAcceleration,vector::zero);
 fiveEqGasThermoEvaluator gas(argv[2]);fiveEqLiquidThermoEvaluator liquid;fiveEqPrecisionRecovery recovery(gas,liquid);
 const auto names=thermo->composition().species();std::array<unsigned,3>index;
 for(unsigned i=0;i<3;++i)index[names[i]=="C10H22"?0:names[i]=="O2"?1:2]=i;
 PrecisionOperator op(recovery,index);PrecisionReconstruction rec(gas,liquid,op,index);
 r2c::op=&op;r2c::thermal=argv[2];std::ifstream data(argv[2],std::ios::binary);r2::thermodynamicIdentity=std::string(std::istreambuf_iterator<char>(data),{});
 std::vector<double> hc(3);for(unsigned i=0;i<3;++i)hc[index[i]]=gas.speciesData()[i].Hc();fiveEqDPMSourceAdapter adapter(hc);
 r2c::LocalCommittedView view(thermo(),rho,u,op,gas,argv[2]);t3a::epoch=&view.token;

 unsigned checks=0,failures=0;std::ofstream bad("failures.txt");
 auto check=[&](bool ok,const std::string&n){++checks;if(!ok){++failures;bad<<n<<'\n';}};
 const auto gasQ=rec.generate(PrecisionFraction::liquid(0,FractionMode::P2),3e6,800,300,vector(47,0,0),{0,.228,.772});
 const auto pureQ=rec.generate(PrecisionFraction::liquid(1,FractionMode::P2),3e6,800,300,vector(47,0,0),{0,.228,.772});
 auto fresh=[&](const std::vector<PrecisionCell>&q){
  auto s=std::unique_ptr<r2::State>(new r2::State);s->q=q;
  auto pub=view.prepareCommit(view.prepare(q));view.publishCommitNoFail(pub);view.token.publishing=false;
  {m8a3a::TrialScope passive;s->cloud.reset(new r2::Cloud("roleA",rho,u,gravity,slg,false));}
  s->allocator=particle::particleCount_;s->generation=view.token.generation;s->time=time.value();s->index=time.timeIndex();return s;
 };
 r2::birthHook=ownership::birth;
 std::ofstream csv("lifetime.csv");csv<<"scenario,ctor,dtor,guardAdopt,guardDelete,cloudAdopt,moveFalse,liveBefore,liveAfter,canonical,gasRecovery,thermo,output\n";
 const bool falseMode=std::string(argv[3])=="false";
 std::vector<PrecisionCell>q(mesh.nCells(),falseMode?gasQ:pureQ);
 auto initial=fresh(q);r2::Output output("gate_output");r2::Transaction tx(std::move(initial),view,slg,time,op,adapter,output);
 auto scenario=[&](const std::string&name,const std::string&phase,bool rejectExpected,double dt){
  const auto before=r2::encode(tx.accepted()),carrier=view.snapshot();auto counts=i1::lifetime();const size_t base=counts.live.size();auto registry=static_cast<const Foam::objectRegistry&>(mesh).toc().size();
  auto registryBefore=static_cast<const Foam::objectRegistry&>(mesh).toc();
  ownership::fail=phase;ownership::watched=nullptr;ownership::births=0;
  tx.begin();ownership::cloud=tx.trial().cloud.get();ownership::cleanupSource.clear();bool rejected=false;std::string reason;
  try{tx.evolve(dt);}catch(const std::exception&e){rejected=true;reason=e.what();}
  if(phase!=""&&phase!="H")check(m8a3bt3::sourceDump(*tx.trial().cloud)==m8a3bt3::sourceDump(*tx.accepted().cloud),name+":failedTrialNativeSourcesZero");
  if(!ownership::cleanupSource.empty())check(ownership::cleanupSource==m8a3bt3::sourceDump(*tx.trial().cloud),name+":guardDoesNotGenerateSources");
  const auto owned=tx.trial().cloud->size();const auto liveDuring=i1::lifetime().live.size();
  check(rejected==rejectExpected,name+":outcome");
  check(liveDuring==base+owned,name+":allSurvivorsCloudOwned");
  if(phase=="H")check(owned==0&&i1::lifetime().cloudAdopted==counts.cloudAdopted,name+":preAdoption");
  if(falseMode)check(i1::lifetime().moveFalse>counts.moveFalse&&owned==0,name+":nativeMoveFalse");
  if(name=="adoption")check(owned>0&&i1::lifetime().guardDestroyed==counts.guardDestroyed,name+":soleCloudOwnership");
  tx.discard();auto&after=i1::lifetime();const bool canonical=before==r2::encode(tx.accepted())&&carrier==view.snapshot();
  check(canonical,name+":canonical");check(after.live.size()==base,name+":lifetimeBaseline");
  check(after.constructed-counts.constructed==after.destroyed-counts.destroyed,name+":exactCtorDtor");
  if(name.find("stress_")!=0)std::ofstream("registry_"+name+".txt")<<r2::ascii(registryBefore)<<"\nAFTER\n"<<r2::ascii(static_cast<const Foam::objectRegistry&>(mesh).toc())<<"\n";
  if(name=="warmup_native_false"){
   const auto afterNames=static_cast<const Foam::objectRegistry&>(mesh).toc();bool cache=false,allKept=true;
   for(const auto&n:afterNames)cache=cache||n=="volPointInterpolate(R2C:trialCommonU)";
   for(const auto&n:registryBefore)allKept=allKept&&std::find(afterNames.begin(),afterNames.end(),n)!=afterNames.end();
   check(afterNames.size()==registry+1&&cache&&allKept,name+":onlyDocumentedNativePointCacheWarmup");
  }else check(static_cast<const Foam::objectRegistry&>(mesh).toc().size()==registry,name+":registry");check(output.publications==0,name+":output");
  check(particle::particleCount_==tx.accepted().allocator,name+":allocator");
  if(phase=="G"){
   check(reason.find("GAS_SUPPORT_INVALID")!=std::string::npos,name+":realSupportException");
   check(r2c::lastQueryDiagnostics().gasRecovery==0&&r2c::lastQueryDiagnostics().thermoCalls==0,name+":supportBeforeThermo");
   check(after.guardDestroyed-counts.guardDestroyed==1,name+":exactOneGuardDelete");
  }
  csv<<name<<','<<after.constructed-counts.constructed<<','<<after.destroyed-counts.destroyed<<','<<after.guardAdopted-counts.guardAdopted<<','<<after.guardDestroyed-counts.guardDestroyed<<','<<after.cloudAdopted-counts.cloudAdopted<<','<<after.moveFalse-counts.moveFalse<<','<<base<<','<<after.live.size()<<','<<canonical<<','<<r2c::lastQueryDiagnostics().gasRecovery<<','<<r2c::lastQueryDiagnostics().thermoCalls<<','<<output.publications<<'\n';
 };
 if(falseMode){scenario("warmup_native_false","",false,5e-8);scenario("native_false","",false,5e-8);}
 else {
  for(const auto phase:{"A","B","C","D","E","F"})scenario(phase,phase,true,1e-5);
  scenario("G","G",true,1e-5);
  for(unsigned n=0;n<1000;++n){scenario("stress_"+std::to_string(n),"G",true,1e-5);if(n%100==0)std::cout<<"I1 stress progress "<<n<<std::endl;}
 }
 // Separate legal-domain transaction for H and adoption outcomes.
 if(!falseMode){
  std::vector<PrecisionCell>valid(mesh.nCells(),gasQ);auto legal=fresh(valid);
  r2::Output out2("legal_output");r2::Transaction legalTx(std::move(legal),view,slg,time,op,adapter,out2);
  for(const auto phase:{"H",""}){
   auto counts=i1::lifetime();auto before=r2::encode(legalTx.accepted());auto snap=view.snapshot();ownership::fail=phase;
   legalTx.begin();ownership::cloud=legalTx.trial().cloud.get();ownership::cleanupSource.clear();bool rejected=false;try{legalTx.evolve(5e-8);}catch(const std::exception&){rejected=true;}
   if(!ownership::cleanupSource.empty())check(ownership::cleanupSource==m8a3bt3::sourceDump(*legalTx.trial().cloud),"H:guardDoesNotGenerateSources");
   auto n=legalTx.trial().cloud->size();check(rejected==(*phase!='\0'),std::string(phase)+":outcome");
   if(*phase)check(n==0&&i1::lifetime().guardDestroyed-counts.guardDestroyed==1,"H:guardDelete");
   else check(n==1&&i1::lifetime().cloudAdopted-counts.cloudAdopted==1&&i1::lifetime().guardDestroyed==counts.guardDestroyed,"adoption:guardReleased");
   check(i1::lifetime().live.size()==counts.live.size()+n,"legal:lifetimeCloudOwned");
   legalTx.discard();check(before==r2::encode(legalTx.accepted())&&snap==view.snapshot(),"legal:canonical");check(i1::lifetime().live.size()==counts.live.size(),"legal:lifetimeBaseline");
   auto&after=i1::lifetime();csv<<(*phase?"H":"adoption")<<','<<after.constructed-counts.constructed<<','<<after.destroyed-counts.destroyed<<','<<after.guardAdopted-counts.guardAdopted<<','<<after.guardDestroyed-counts.guardDestroyed<<','<<after.cloudAdopted-counts.cloudAdopted<<','<<after.moveFalse-counts.moveFalse<<','<<counts.live.size()<<','<<after.live.size()<<",1,"<<r2c::lastQueryDiagnostics().gasRecovery<<','<<r2c::lastQueryDiagnostics().thermoCalls<<','<<out2.publications<<'\n';
  }
 }
 std::ofstream result("gate_result.json");result<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"constructed\":"<<i1::lifetime().constructed<<",\"destroyed\":"<<i1::lifetime().destroyed<<",\"live\":"<<i1::lifetime().live.size()<<",\"noCFD\":true}\n";
 return failures?1:0;
}
