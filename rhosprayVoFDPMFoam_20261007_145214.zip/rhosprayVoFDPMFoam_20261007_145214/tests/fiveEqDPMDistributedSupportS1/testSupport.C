#include "DistributedCarrierSupport.H"
#include "fiveEqPrecisionReconstruction.H"
#include <fstream>
#include <iomanip>
int main(int argc,char**argv){
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 std::string thermal="/mnt/d/DATA/Solver/300_2D/constant/thermal.dat";
 fiveEq::fiveEqGasThermoEvaluator gas(thermal);fiveEq::fiveEqLiquidThermoEvaluator liquid;
 fiveEq::fiveEqPrecisionRecovery recovery(gas,liquid);fiveEq::PrecisionOperator op(recovery,{0,1,2});fiveEq::PrecisionReconstruction rec(gas,liquid,op,{0,1,2});
 auto generate=[&](const fiveEq::PrecisionFraction&f,const Foam::vector&pos){return rec.generate(f,188330.307,400,300,Foam::vector(47+2*pos.x(),4,3),{0,.228,.772});};
 auto present=fiveEq::PrecisionFraction::liquid(0,fiveEq::FractionMode::P2);
 unsigned checks=0,failures=0;std::ofstream bad((runTime.path()/"support_failures.txt").c_str());
 auto check=[&](bool ok,const std::string&name){++checks;if(!ok){++failures;bad<<name<<'\n';}};
 std::ofstream packets((runTime.path()/"allgas_packets.csv").c_str());packets<<std::setprecision(17)<<"x,rho,p,T,Cp,mu,kappa,Y0,Y1,Y2,U0,U1,U2\n";
 auto record=[&](double x,const r2a::CarrierPacket&p){packets<<x<<','<<p.rho<<','<<p.p<<','<<p.T<<','<<p.Cp<<','<<p.mu<<','<<p.kappa;for(auto y:p.Y)packets<<','<<y;for(unsigned j=0;j<3;++j)packets<<','<<p.U[j];packets<<'\n';};
 if(!Foam::Pstream::parRun()){
  Foam::volVectorField geometry(Foam::IOobject("S1:serialGeometry",runTime.timeName(),mesh,Foam::IOobject::NO_READ,Foam::IOobject::NO_WRITE,false),mesh,Foam::dimensionedVector("zero",Foam::dimVelocity,Foam::vector::zero));
  r2a::CarrierQueryOwner serial(geometry,op,thermal);std::vector<fiveEq::PrecisionCell>cells,boundary;std::vector<std::string>kinds;
  forAll(mesh.C(),c)cells.push_back(generate(present,mesh.C()[c]));
  for(Foam::label f=mesh.nInternalFaces();f<mesh.nFaces();++f){boundary.push_back(generate(present,mesh.Cf()[f]));kinds.push_back("EXPLICIT_PHYSICAL_FACE_PRIMITIVE");}
  auto publication=serial.prepareCommit(cells,boundary,kinds);serial.commit(publication);
  forAll(mesh.C(),c){auto pos=mesh.C()[c]+Foam::vector(mesh.C()[c].x()<4?.31:-.31,.07,.11);record(pos.x(),serial.query(pos,c,r2a::All));}
  std::ofstream((runTime.path()/"serial_result.json").c_str())<<"{\"frozenBackendUsed\":true,\"queries\":"<<mesh.nCells()<<"}\n";return 0;
 }
 s1::DistributedSparsePointSupport stencil(mesh);s1::DistributedCarrierSupport owner(stencil,op,thermal);
 auto local=[&](const fiveEq::PrecisionFraction&remote){std::vector<fiveEq::PrecisionCell>v;for(const auto&k:stencil.keys())if(k.rank==Foam::Pstream::myProcNo()){
  Foam::vector pos=k.kind==0?mesh.C()[k.local]:mesh.Cf()[k.local];v.push_back(generate(k.rank==1?remote:present,pos));}return v;};
 uint64_t generation=0;
 auto publish=[&](const fiveEq::PrecisionFraction&remote){auto candidate=owner.prepare(local(remote),++generation);owner.publish(candidate);};
 publish(present);
 // Find a genuine remote-bearing synthetic destination pose, no source cache.
 s1::Pose pose{mesh.C()[0],0,-1,Foam::Pstream::myProcNo()};bool found=false;
 for(Foam::label c=0;c<mesh.nCells();++c){s1::Pose p{mesh.C()[c]+Foam::vector(Foam::Pstream::myProcNo()==0?.31:-.31,.07,.11),c,-1,Foam::Pstream::myProcNo()};auto entries=stencil.build(p.position,p.cell);bool remote=false;for(const auto&e:entries)remote|=stencil.keys()[e.index].rank!=Foam::Pstream::myProcNo();if(remote&&!found){pose=p;found=true;}record(p.position.x(),owner.query(p));}
 check(found,"actualRemotePose");
 {auto input=local(present);if(Foam::Pstream::myProcNo()==1)input.pop_back();bool refused=false;try{owner.prepare(input,generation+1);}catch(const std::exception&){refused=true;}check(refused&&owner.committed().generation==generation,"collectiveMalformedInputNoPublication");}
 for(double a:{.1,.5,.9}){publish(fiveEq::PrecisionFraction::liquid(a,fiveEq::FractionMode::P2));auto p=owner.query(pose);check(p.rho>0&&p.Cp>0&&p.kappa>0,"mixedRemoteValid");}
 auto trace=fiveEq::PrecisionFraction::minority(1e-20,true,fiveEq::FractionMode::P2);publish(trace);auto traceTicket=owner.preflight(pose,generation);check(traceTicket.valid,"traceRemoteValid");
 bool sawTrace=false;for(const auto&e:traceTicket.entries)if(stencil.keys()[e.index].rank==1){const auto&q=owner.committed().states[e.index].q;sawTrace|=q.fraction.gasValue()==1e-20;check(std::signbit(q.fraction.payload().hi)&&q.q[1]>0,"traceWireSignedMinorityAndMg");}
 check(sawTrace,"actualRemoteTraceAuthority");owner.materialize(traceTicket,pose);
 auto pure=fiveEq::PrecisionFraction::liquid(1,fiveEq::FractionMode::P2);
 unsigned invalid=0,stale=0,cycles=0;
 for(unsigned i=0;i<1000;++i){
  publish(present);auto t=owner.preflight(pose,generation);check(t.valid,"validCycle");owner.materialize(t,pose);
  // Preparing and discarding is support publication only, not parcel rollback.
  auto uncommitted=owner.prepare(local(pure),generation+1);check(owner.committed().generation==generation,"uncommittedDoesNotReplaceAuthority");uncommitted.reset();
  auto mixed=std::make_shared<s1::View>(owner.committed());for(auto&s:mixed->states)s.generation=stencil.keys()[&s-&mixed->states[0]].rank==1?generation-1:generation;
  auto calls=owner.counters.thermoCalls();auto recCalls=owner.recoveries;
  auto negative=owner.preflight(pose,generation,mixed);check(!negative.valid&&negative.reason=="DISTRIBUTED_GENERATION_MISMATCH","mixedGenerationReject");check(owner.counters.thermoCalls()==calls&&owner.recoveries==recCalls,"mixedGenerationZeroCalls");++stale;
  auto old=owner.preflight(pose,generation+1);check(!old.valid&&old.reason=="DISTRIBUTED_GENERATION_MISMATCH","staleGenerationReject");
  auto ticket=owner.preflight(pose,generation);owner.invalidateAfterMove();bool moved=false;try{owner.materialize(ticket,pose);}catch(const std::exception&){moved=true;}check(moved&&owner.counters.thermoCalls()==calls,"moveInvalidates");
  ticket=owner.preflight(pose,generation);owner.invalidateAfterRebound();bool bounced=false;try{owner.materialize(ticket,pose);}catch(const std::exception&){bounced=true;}check(bounced,"reboundInvalidates");
  auto otherPose=pose;otherPose.face=0;bool changed=false;ticket=owner.preflight(pose,generation);try{owner.materialize(ticket,otherPose);}catch(const std::exception&){changed=true;}check(changed,"facePoseChangeReject");
  publish(pure);calls=owner.counters.thermoCalls();recCalls=owner.recoveries;negative=owner.preflight(pose,generation);check(!negative.valid&&negative.reason=="EXACT_GAS_ABSENT","actualAbsentRemoteReject");bool refused=false;try{owner.materialize(negative,pose);}catch(const std::exception&){refused=true;}check(refused&&owner.counters.thermoCalls()==calls&&owner.recoveries==recCalls,"absentZeroDependentCalls");++invalid;++cycles;
 }
 publish(present);auto original=owner.preflight(pose,generation);
 for(unsigned kind=0;kind<3;++kind){auto changed=pose;if(kind==0)changed.cell=(pose.cell+1)%mesh.nCells();if(kind==1)changed.position.y()+=.01;if(kind==2)changed.owner=1-pose.owner;bool refused=false;try{owner.materialize(original,changed);}catch(const std::exception&){refused=true;}check(refused,"cellTetOrOwnerChangeInvalidates");}
 s1::DistributedSparsePointSupport rebuilt(mesh);check(rebuilt.keys()==stencil.keys(),"reconstructedLogicalKeysStable");auto before=stencil.build(pose.position,pose.cell),after=rebuilt.build(pose.position,pose.cell);check(before.size()==after.size(),"reconstructedMembershipStable");for(unsigned i=0;i<before.size()&&i<after.size();++i)check(before[i].index==after[i].index&&before[i].weight==after[i].weight,"reconstructedWeightsExact");
 Foam::label allFail=failures;Foam::reduce(allFail,Foam::sumOp<Foam::label>());
 std::ofstream result((runTime.path()/"support_result.json").c_str());result<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"globalFailures\":"<<allFail<<",\"cycles\":"<<cycles<<",\"invalidCycles\":"<<invalid<<",\"staleCycles\":"<<stale<<",\"generation\":"<<generation<<",\"recoveries\":"<<owner.recoveries<<",\"thermoCalls\":"<<owner.counters.thermoCalls()<<",\"remotePose\":"<<(found?"true":"false")<<"}\n";
 return allFail?1:0;
}
