#include "DistributedSparsePointSupport.H"
#include "interpolationCellPoint.H"
#include "nativeSparsePointSupport.H"
#include <fstream>
#include <iomanip>
int main(int argc,char**argv){
 #include "setRootCase.H"
 #include "createTime.H"
 #include "createMesh.H"
 s1::DistributedSparsePointSupport support(mesh);
 unsigned checks=0,failures=0,remote=0;double maxError=0;
 auto check=[&](bool ok){++checks;if(!ok)++failures;};
 auto geometry=support.field("S1:guard");bool guard=false;
 try{m8a3b::NativeSparsePointSupport serial(geometry);}catch(const std::exception&e){guard=std::string(e.what())=="MPI_SPARSE_SUPPORT_NOT_IMPLEMENTED";}
 check(guard);
 std::ofstream csv((runTime.path()/"topology.csv").c_str());csv<<std::setprecision(17)<<"cell,x,y,z,ownerRank,kind,localEntity,patch,w00,w11,w22\n";
 for(Foam::label c=0;c<mesh.nCells();++c){
  // Non-centre synthetic current-rank poses ensure actual point contributors.
  Foam::vector pos=mesh.C()[c]+Foam::vector(Foam::Pstream::myProcNo()==0?.31:-.31,.07,.11);
  auto entries=support.build(pos,c);std::map<unsigned,Foam::tensor>actual;
  for(const auto&e:entries){actual[e.index]=e.weight;const auto&k=support.keys()[e.index];if(k.rank!=Foam::Pstream::myProcNo())++remote;
   csv<<c<<','<<pos.x()<<','<<pos.y()<<','<<pos.z()<<','<<k.rank<<','<<k.kind<<','<<k.local<<','<<k.patch<<','<<e.weight[0]<<','<<e.weight[4]<<','<<e.weight[8]<<'\n';
  }
  // Independent query oracle: native interpolationCellPoint directly evaluates
  // every distributed impulse, rather than combining backend point weights.
  for(unsigned e=0;e<support.keys().size();++e){Foam::tensor oracle=Foam::tensor::zero;
   for(unsigned axis=0;axis<3;++axis){auto basis=support.field("S1:oracle");support.setImpulse(basis,support.keys()[e],axis);Foam::interpolationCellPoint<Foam::vector>native(basis);auto v=native.interpolate(pos,c);for(unsigned row=0;row<3;++row)oracle[3*row+axis]=v[row];}
   bool member=actual.count(e);check(member==(s1::nonzero(oracle)||e==support.ownCellIndex(c)));
   Foam::tensor got=member?actual[e]:Foam::tensor::zero;
   for(unsigned j=0;j<9;++j){double error=std::abs(got[j]-oracle[j]);maxError=std::max(maxError,error);check(error==0);}
  }
 }
 check(remote>0);
 Foam::label allFailures=failures;Foam::reduce(allFailures,Foam::sumOp<Foam::label>());
 std::ofstream out((runTime.path()/"topology_result.json").c_str());out<<std::setprecision(17)<<"{\"checks\":"<<checks<<",\"failures\":"<<failures<<",\"globalFailures\":"<<allFailures<<",\"remoteContributions\":"<<remote<<",\"maxWeightError\":"<<maxError<<",\"originalGuardReproduced\":"<<(guard?"true":"false")<<"}\n";
 return allFailures?1:0;
}
