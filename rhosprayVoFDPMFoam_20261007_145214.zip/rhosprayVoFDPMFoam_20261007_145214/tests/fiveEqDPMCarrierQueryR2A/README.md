# R2A support-first carrier query — offline candidate

Scope: serial, fixed mesh, scalar `cell`, velocity `cellPoint`, the existing
three-species JANAF/Sutherland profile and immutable five-equation recovery.
No active solver or native OF7 class is modified. No CFD is run.

## Ownership and order

`GasSupportMap` contains Q/P2 authority and support certificates. Exact absent
slots contain no gas state. Map preparation may recover **present** gas states
using the existing operator, and recovers liquid-only states with gas-call count
zero. Recovery during publication is distinct from parcel query materialization.

Each query performs native geometry/stencil discovery and metadata preflight
before accessing recovered gas scalars, composition or transport functions.
Rejected queries cannot construct gas Cp/mu/kappa fields or a native thermo
trackingData. Valid requests compute only required quantities and dependencies.
Native Sutherland kappa internally requires Cp; this call is counted.

The only full-field interpolation storage is **physical common velocity**
M/(mG+mL), defined also in pure liquid. It is not a fabricated gas field. Native
U interpolation is constructed only after the entire actual required gas stencil
is certified. Gas rho/T/Y/Cp/mu/kappa have no full-field candidate storage.

Future-nozzle metadata uses T2's bottom-face overlap predicate without creating
a patch. An actual nonzero pending boundary contributor invalidates the query;
unused pending contributors do not block a scalar or unrelated position query.
T2's CSV `wholeCell` union is a conservative feasibility map over all positions
in a cell. It is not identical to a `cellPointWeight` query at the cell centre.
The independent actual-position native support oracle is the exact comparison;
phase authority and old whole-cell-valid subset are also checked.

The support map and query context are immutable. Context identity includes owner,
map identity, generation, exact position bits, cell, face and requirement mask.
Every accepted publication invalidates the native point cache. Discarding a
prepared map leaves committed generation/cache intact. Mesh changes are rejected.
Publication is serial/quiescent, with allocation and validation staged first.

## What the tests actually execute

* 21000-cell native all-gas scalar/property/U equivalence, exact floating bits.
* Exact absent, mixed .1/.5/.9, signed P2 trace 1e-20 and invalid native U support.
* Actual OF7 `particle::trackToCell` and `SphereDragForce::calcCoupled` kernel.
* Prescribed geometric trajectory, rejected trial object discarded, small retry
  canonical equality and ten subsequent legal geometry/force queries.
* Exact absent geometry endpoint and born parcel's first carrier query rejection.
* QTrial source map publication using frozen source adapter, without alpha change.
* Actual native boundary contributors and independent absent boundary authority.
* 100 generation/cache rebuild cycles and registry/RSS measurements.

The trajectory velocity is prescribed. This is **not** a full native spray
velocity integrator, cloud.evolve transaction or native parcel source generation.
The source-map test uses an explicit adapter increment and does not label it a
native drag source. The native all-gas reference builds full thermo fields only
in the certified all-gas reference domain.

## Remaining gate

The packet shim does not yet provide the complete native Thermo/Reacting/Spray
trackingData interface (`calcSurfaceValues`, carrier source corrections, pc,
interpolation.psi, thermal/radiation paths). Native full trackingData still has
its original eager Cp/kappa constructor. Full model dispatch, born injection
initialization and post-native-rebound first-query instrumentation remain open.
The geometry-only absent endpoint is not a permitted physical evolution through
liquid; streaming queries reject earlier at the support exclusion band.

Existing R2 regressions replay the immutable old executable in legal carrier
fixtures. They prove non-regression, **not** mixed-domain full-cloud closure.
Future liquid nozzle patch is FUTURE_PATCH_DEPENDENT. Current boundary Q values
are the documented T2 diagnostic owner-equality oracle; production BCs are not
redefined.

Therefore R2A is PARTIAL even when all implemented tests pass; R2/T3B/T3 remain
PARTIAL, T4 and M6B permissions remain NO. Do not restore R2 final closure here.

Evidence: `fitting/dpm/m8a3b_t3br2a_v1`, including initial failed compile/trajectory
attempts, successful versioned runs and independent immutable-file audits.
