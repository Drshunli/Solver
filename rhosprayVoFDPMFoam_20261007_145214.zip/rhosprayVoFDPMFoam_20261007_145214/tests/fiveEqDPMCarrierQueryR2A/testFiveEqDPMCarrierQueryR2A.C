#include "carrierQuery.H"
#include <fstream>
int main(int argc,char**argv){
 if(argc!=3)return 2;using namespace Foam;using namespace fiveEq;
 fileName root(argv[1]);setenv("FOAM_CASE",argv[1],1);Time time(Time::controlDictName,root.path(),fileName(root.name()));fvMesh mesh(IOobject(fvMesh::defaultRegion,time.timeName(),time,IOobject::MUST_READ));
 volVectorField geometry(IOobject("U",time.timeName(),mesh,IOobject::MUST_READ,IOobject::NO_WRITE),mesh);
 fiveEqGasThermoEvaluator gas(argv[2]);fiveEqLiquidThermoEvaluator liquid;fiveEqPrecisionRecovery recovery(gas,liquid);PrecisionOperator op(recovery,{0,1,2});PrecisionReconstruction rec(gas,liquid,op,{0,1,2});
 auto pure=rec.generate(PrecisionFraction::liquid(1,FractionMode::P2),3e6,800,300,vector(47,0,0),{0,.228,.772});
 r2a::CarrierQueryOwner owner(geometry,op,argv[2]);std::vector<PrecisionCell>q(mesh.nCells(),pure),b(mesh.nFaces()-mesh.nInternalFaces(),pure);std::vector<std::string>kind(b.size());for(label f=mesh.nInternalFaces();f<mesh.nFaces();++f)kind[f-mesh.nInternalFaces()]=mesh.boundaryMesh()[mesh.boundaryMesh().whichPatch(f)].type();
 auto pub=owner.prepareCommit(q,b,kind);owner.commit(pub);auto c=owner.preflightSupport(mesh.C()[0],0,r2a::All);bool rejected=false;try{owner.materializeCarrier(c,mesh.C()[0],0);}catch(const std::exception&){rejected=true;}
 bool pass=rejected&&owner.counters.thermoCalls()==0&&owner.counters.U==0&&owner.map().gasRecoveryCalls==0;
 std::ofstream("test_results.json")<<"{\"checks\":1,\"failures\":"<<!pass<<",\"pureLiquidGasRecovery\":"<<owner.map().gasRecoveryCalls<<",\"queryThermoCalls\":"<<owner.counters.thermoCalls()<<",\"noCFD\":true}\n";return !pass;
}
