# P2 numerical representation — v1, M5C.2D

## Physical and numerical ownership

There is ONE physical volume-fraction degree of freedom: alphaL, with
alphaG=1-alphaL mathematically. The P2 coordinate is authoritative numerical
storage. Decoded double alphaL is an output/view, not a unique recovery source
when its complement falls below resolution. No independent alphaG PDE exists.
No P2 core source or phase-presence rule is changed in this milestone.

## Exact mapping

Let s be a finite signed IEEE binary64 coordinate with |s|<=0.5.

| Branch, including sign of zero | physical alphaL | physical alphaG |
|---|---|---|
| signbit(s)=false | s | 1-s |
| signbit(s)=true | 1+s | -s |

Dominant values are decoded using the accepted twoSum/DD machinery. Recovery
obtains each supported fraction through the coordinate getters; it never
recomputes the small complement as 1-decodedDominantAlpha.

Pure gas is +0; pure liquid is -0. Both +0.5 and -0.5 are legal encodings of
the same physical half state. The conventional physical-alpha constructor
chooses +0.5; the minority constructor may retain either branch at a tie.
This redundancy is representation metadata, not a second physical DOF.

Inverse from a resolved physical scalar a: if a<=0.5 set s=a; otherwise set
s=-(1-a). This scalar inverse cannot recover information already lost in a.
For precision-bearing input, provide the known minority phase and minority
value x directly: s=x for liquid minority, s=-x for gas minority, including
signed zero. An input pair must originate from ONE physical state, not two
independent evolution equations. Near pure phase, use the minority input;
do not create a rounded dominant alpha before constructing P2.

## Update and branch switch

With gas-minority branch b=true and m=|s|, compute mNew=m-deltaAlphaL;
otherwise mNew=m+deltaAlphaL. The accepted DD update delays cancellation.
Reject out-of-range/nonfinite mNew. If mNew>0.5, set mNew=1-mNew and flip b.
At exactly 0.5 retain the incoming branch. This switch changes representation
only; it never adjusts mG, mL, M, Et or species.

P2 preserves increments sub-ULP relative to a dominant fraction, provided
they remain representable relative to its stored minority. It is not arbitrary
precision; the C.1 normal/subnormal support contract remains unchanged.

## R1 reconstruction

For each owner cell choose the owner minority branch. Evaluate the physical
liquid or gas fraction of ALL four stencil cells in that common branch;
never interpolate signed s directly across its branch discontinuity.
Call actual OF7 Minmod on these physical fractions. Subtract the owner value;
negate this increment when gas is the owner minority to obtain deltaAlphaL.
All material components use the audited OF7 Minmod/MinmodV path. Independent
species slopes determine the dependent residual-species slope.

One thetaCell bounds both faces of alpha, mG, mL, M, Et and species. P2 is the
representation of that SAME limited physical increment. theta=0 returns the
unchanged P2 cell; theta=1 is the intended branch-aware physical-alpha face.
The internal at(0) implementation returns the original object directly.
Linear positivity bounds precede the frozen 32-sample/52-bisection thermo test.
Finite continuation is tested evidence, not an arbitrary-path proof.

## Flux, source and cell update

Use one KT Aplus/Aminus family. Algebraically Falpha=Aplus*aL+Aminus*aR;
physical phiStar=Aplus+Aminus+meshPhi. Near the precision-degenerate limit,
the authoritative combined alpha increment is evaluated as

Nalpha=sumLeft A±*(aface-aCell)-sumRight A±*(aface-aCell),
alphaNew=alphaOld+dt*Nalpha/Vnew, Vnew=Vold+dt*div(meshPhi).

This is the frozen physical alpha flux/source/GCL equation, with rounding
postponed; an ordinary projected Falpha alone is not authoritative for trace
updates. Its nonconservative source ledger is physical alpha, not integral(s).
No mass/energy correction, floor, normalization or trace deletion is allowed.

## Future integration format — contract only

Future storage name: phaseFractionCoordinate, dimensionless signed scalar.
Decoded alphaL/alphaG are read-only physical diagnostics/BC views. This is a
future M5C.3/M6B ownership requirement; no active field is created now.

Restart schema P2-v1 stores the EXACT 64-bit coordinate pattern per cell and
patch, preferably canonical 16-hex-digit uint64 payload, with declared byte
order for binary exchange, schema/version/checksum, EOS version and the
conservative state. This preserves -0 and tiny minority values. A restart
containing only decoded alphaL=1 is insufficient and must not be silently
accepted as a precision-complete restart. Implementation remains M5C.3.

MPI exchanges the same payload, not independently recomputed complements.
Boundary construction accepts minorityPhase/minorityValue, or a safely
resolved physical alpha input. Signed coordinates must not be passed as
ordinary [0,1] alpha values to existing BCs. Mapping/AMR acts on the physical
one-DOF state and re-encodes it, not on the discontinuous signed coordinate.
No BC/MPI/restart/AMR implementation is supplied in M5C.2D.
