# M8A.3B-T3B-R2C — serial transaction gate

2026-10-03. **PARTIAL / MODEL_TRANSACTION_BLOCKER / STOP.**

## Decisive failure

Actual native InjectionModel allocates pPtr (copied source line474), calls pPtr->move at507, and only then transfers ownership to cloud at509. A support exception bypasses both addParticle and the normal delete at513. The local cloud transaction restores all authoritative bytes but cannot destroy this unowned object. The diagnostic replacement delete confirms no release until explicit post-failure cleanup; it is test instrumentation, not production recovery.

See fitting/dpm/m8a3b_t3br2c_v1/ownership_reproducer_v1/ownership_result.json and InjectionModel.reference.C. No native model body was copied into the test implementation or modified.

## Scope

Serial fixed mesh passive tests only. Independent actual-native oracle and frozen project-local lazy type chain. Scalar cell/U cellPoint, current three-species recipe, heat/phase-change/radiation disabled. New local publication adapter is a harness consumer of frozen Q/P2/recovery; it publishes physical common p/U and optional support slots, not global gas Cp/kappa. Full production startup/MPI/restart are not certified.

# 1. R2C status

PARTIAL / MODEL_TRANSACTION_BLOCKER / STOP. Actual native ConeInjection newborn survives support rejection and discard outside cloud ownership.

# 2. Local lazy chain used

The tested path is Foam::fiveEqDPM::LazyParcel/LazySprayCloud, using frozen R2B sources. Foundation native chain is a separate numerical oracle. Passive serial fixed mesh only.

# 3. transactionState-v1 result

All-gas A codec/retry PASS: P2/Q, generation, parcel identities/scalars/Y/breakup, injection history, RNG cached normal, allocator, model configuration/state, sources and pending tickets. Lazy caches excluded. This codec does not own the orphan newborn; numerical equality alone is insufficient.

# 4. RNG result

Both cached-normal flags and future draws PASS; accepted all-gas replay and rejected canonical state match. Injection rejection restores visible RNG state.

# 5. Allocator result

All-gas replay PASS; rejected injection restores the accepted allocator. Restoring particleCount does not release a heap object.

# 6. ConeInjection

All-gas real injection direct/retry and ten future steps PASS. Full capability BLOCKER due invalid-support ownership failure.

# 7. Injection invalid-support

CONFIRMED FAIL: one real newborn, unowned before discard, still alive after discard; canonical authority restored; zero publications; gasRecovery=0, gas thermo property calls=0, provider samples=0, one preflight. Diagnostic deletion only after recording failure verified release; it is not a transaction fix.

# 8. Stochastic

Real all-gas update, rollback/retry and ten future steps PASS. Mixed/full graph capability remains BLOCKER.

# 9. SphereDrag

Nonzero UTrans, frozen strict source/energy conversion, Q publication, direct/retry and ten future steps PASS on all-gas A. No ledger modifications.

# 10. BlobsSheet

Actual liquidCore mutation assertion PASS; direct/retry and ten future steps PASS on all-gas A.

# 11. ReitzKHRT

Real child creation assertion PASS; discard/retry/future PASS on all-gas A. Child uses frozen R2B independent support preflight and parent restore. Mixed invalid child scenarios not completed.

# 12. ORourke accepted

All-gas A accepted state equals native reference, including the four named collision scenarios. This core fixture is not the separate branch-fixture proof for all required outcomes/count reduction.

# 13. ORourke rollback

All-gas A canonical discard PASS for four named scenarios; branch completeness remains pending.

# 14. ORourke retry

All-gas A retry plus ten future steps PASS; no compensation or new physics.

# 15. ORourke limitation diagnostics

Native no-source collision semantics and known mass/momentum/KE limitations retained. No thermalization or conservation correction. FULL-CONSERVATION-SAFE is not claimed.

# 16. Rebound

Actual Foundation Rebound replaces the old StandardWallInteraction wrapper in the new harness only. Real wall Cloud.evolve, patchData/rebound assertion, rollback/retry/future PASS on all-gas A. UFactor=1 from test dictionary; mixed/invalid next-query full transaction not completed.

# 17. VoidFraction

Actual trajectory-time theta assertion PASS; accepted exactly-once output and rejected staging discard PASS on all-gas A. No occupancy substitution.

# 18. ThermoParcel deletion

Independent minimum-mass deletion PASS with frozen strict source/energy ledger; no NEW_EVENT_LEDGER_BLOCKER observed.

# 19. Runtime support retry

NOT COMPLETED. Mandatory STOP occurred while extending support-failure cases; R2B crossing spot tests are not promoted.

# 20. Pure-liquid crossing

Real invalid-support injection reproduced exact gas absence and rejection before thermo; full movement-crossing/direct-small retry matrix NOT COMPLETED. Numerical state/output restore succeeds, but heap ownership fails.

# 21. Trace-gas

All-gas-suite trace case: actual local query/stochastic event/QTrial commit retained signed P2 alphaG=1e-20 and native-equivalent state. Full trace reject/retry matrix NOT COMPLETED.

# 22. Mixed topology

R2C mixed 0.1/0.5/0.9 full event transaction matrix NOT COMPLETED. Publication adapter accepts optional gas slots; this is not a completed mixed numerical gate. Frozen R2B mixed spot PASS remains separate.

# 23. Combined event

All-gas A real Cloud.evolve with ongoing injection, stochastic, drag, model updates, movement and output staging; large reject/discard/small retry/future PASS. No claim every breakup/collision branch is triggered in this combined case.

# 24. Canonical equality

13 named event scenarios: rollbackExact=1, retryFutureExact=1, 22 accepted path steps each. 100 alternating prepared-trial discards and 1000 mutation/discard cycles PASS. Orphan demonstrates canonical bytes do not prove ownership closure.

# 25. Native-reference equality

328 canonical state files SHA-256 equal between local v2 and separate actual-Rebound native v2 oracle; 3728 checks/0 failures each. First migration v1 also 3729 checks/0 failures, 143 accepted-event states equal; v1 used historical wall/publication scheme and is not the final profile.

# 26. Future equivalence

Ten future accepted steps after each named core event PASS on all-gas A, with carrier query and output equality. Not a mixed/branch/MPI certification.

# 27. Persistent output

Trial staging, accept publish once, repeated-ticket idempotence, prepare/publish fault injection and retained pending ticket roundtrip PASS. Invalid injection publishes zero output. No production crash-safe restart claim.

# 28. iNew/read-write

Evolved serial stream/typed-bit codec roundtrip PASS, including mutated scalar states and pending tickets. Full event population native field-write/read/continue matrix NOT COMPLETED; R2B iNew basics remain frozen.

# 29. Sequential commits

100 actual nonzero-source accepted commits PASS, with movement/query materialization and 100 exactly-once publications.

# 30. Alternating lifecycle

100 accept/reject cycles PASS for the supported all-gas drag lifecycle. Does not cover invalid-support injection lifetime failure.

# 31. Discard stress

1000 authoritative mutation/discard cycles PASS; these cycles did not execute invalid-support newborn injection. They cannot certify the failing lifetime path.

# 32. Registry

All-gas lifecycle registry counts: [61]; stable in tested profile. Registry stability does not detect an unregistered heap orphan.

# 33. RNG lifecycle

All-gas repeated lifecycle PASS; invalid injection canonical restoration includes RNG. Not a complete full-graph lifetime closure.

# 34. Allocator lifecycle

All-gas accepted/rejected/discard checks PASS; ownership and ID allocator are distinct responsibilities.

# 35. Carrier generation

Accepted +1; rejected unchanged in tested paths. Local common pressure/U publication uses frozen optional-gas support owner; no gas object for absent slots. Restore prepares a matching immutable support generation.

# 36. Lazy cache lifecycle

Derived trial-local query contexts rebuilt; full all-gas replay PASS. No cache bytes in codec. Invalid injection: zero gas sampling; dangling newborn blocks overall lifecycle safety.

# 37. Eight-model capability matrix

All eight remain BLOCKER for full R2C capability. All-gas subsets PASS is recorded separately. ORourke retains NATIVE-PHYSICS-LIMITATION; no FULL-SERIAL-TRANSACTION-SAFE promotion before graph closure.

# 38. Source/energy regression

9288 PASS / FROZEN from prior checkpoint; protected source/ledger hashes unchanged. Not rerun after mandatory STOP. Fresh local strict drag/deletion/source core subset PASS.

# 39. M8A.3A regression

6375 PASS / FROZEN; hashes unchanged; not newly replayed after STOP.

# 40. T2 regression

1725880 PASS and 21000/21000 FROZEN; unchanged; not newly replayed after STOP.

# 41. T3A regression

64395 PASS / FROZEN; unchanged; not newly replayed after STOP.

# 42. P2/R1 regression

105775 PASS / FROZEN; unchanged; not newly replayed after STOP.

# 43. temporal/restart regression

9663 PASS / FROZEN; unchanged; not newly replayed after STOP.

# 44. R2/R2A/R2B regressions

21432 / 273263 / 252194 PASS / FROZEN; no upgrade based on historical native tests. Fresh historical native A replay3729 PASS; fresh local v1/v2 3729/3728 PASS. R2B 30 source/executable hashes unchanged.

# 45. Performance/memory

Harness-only local v2: 2:25.66 wall, 73.68 user seconds, peakRSS161936KiB. Native v2:2:28.67 wall,80.36 user seconds, peakRSS164228KiB. Separate concurrent runs, not a controlled benchmark. Tracking/materialization/event costs and cache hit/miss were not fully separated before STOP. Ownership reproducer:0.64s wall,102188KiB peak; one surviving orphan means no global no-leak claim.

# 46. Foundation hashes

6717 installed source/Make files match frozen R2B closing baseline; 19 native parcel files and native ORourke C/H unchanged. No installed source writes; native InjectionModel/Rebound copies are read-only provenance artifacts.

# 47. Active solver impact

NONE. 145 protected project files and 30 frozen R2B source/executable files match baseline. Production mesh/BC/nozzle, adapter/ledger, thermo/recovery/P2/R1 unchanged. Only independent test targets, test fixtures, evidence and documentation added.

# 48. Whether R2C COMPLETE

NO. PARTIAL / MODEL_TRANSACTION_BLOCKER. Canonical numerical restore succeeds but native InjectionModel raw pPtr escapes cloud ownership before move completes, and discard cannot delete it.

# 49. Whether R2-FINAL may start NEXT ROUND ONLY

NO until R2C ownership repair and all remaining gates pass. Suggested next authorized scope: a project-local exception-safe newborn ownership guard, preserving native physics and installed source; then repeat birth/move(false)/support rejection/retry/lifecycle/native equivalence. No repair implemented this round.

# 50. Updated milestone matrix

R2B COMPLETE/FROZEN; R2C PARTIAL/MODEL_TRANSACTION_BLOCKER; R2-FINAL NOT AUTHORIZED; T3B/T3 PARTIAL; T4 NO; M8A PARTIAL; M6B.0/1 NO. No CFD. STOP.

## Capability and next repair scope

| Model | Full R2C capability | Evidence/remaining scope |
|---|---|---|
| coneInjection | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete |
| stochasticDispersionRAS | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete |
| sphereDrag | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete |
| blobsSheetAtomization | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete |
| ReitzKHRT | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete |
| ORourke | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete; native physics limitations retained |
| rebound | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete |
| voidFraction | BLOCKER | All-gas subset PASS; full support/lifetime gate incomplete |

A candidate next-round ownership guard must capture newborn allocations until native cloud adoption, release normally deleted parcels exactly once, and clean unadopted living parcels on exception. Birth failure before setProperties and native move(false) must be covered. Global allocation interception used by this diagnostic must not be promoted into the solver. No guard or native model replacement has been implemented.

## Retained repairs

Initial standalone link needed local type symbols. Publication repair preserved immutable support certificates and corrected std-stream vector formatting. First actual-Rebound fixtures placed reboundCoeffs outside subModels; both failing logs retained, coefficient placement corrected. Initial v1 suite intentionally retains the old owner/blocker semantics and does not establish R2C COMPLETE. Historical one-time generators refuse overwrite.

STOP: no further events, R2-FINAL, T4, M6B or CFD this round.
