#include "fiveEqThetaAdmissibility.H"
#include <cmath>
#include <algorithm>
namespace fiveEq {
MaterialCell sharedThetaFace(const MaterialCell& q,const MaterialCell& delta,double t){
    if(t==0)return q; // exact R0 identity, including trace and stored species values
    MaterialCell f;for(unsigned j=0;j<10;++j)f[j]=std::fma(t,delta[j],q[j]);
    // N-1 independent runtime-ordered species. Dependent face closure, not normalization.
    f[9]=f[1]-(f[7]+f[8]);return f;
}
double thetaLinearBound(const MaterialCell& q,const MaterialCell& d,std::string& why){
    double t=1;auto bound=[&](double x,double dx,const char* name){if(dx<0){double b=-x/dx;if(b<t){t=std::max(0.,b);why=name;}}};
    bound(q[0],d[0],"alpha");bound(1-q[0],-d[0],"alpha");
    bound(q[1],d[1],"partial_mass");bound(q[2],d[2],"partial_mass");
    for(unsigned j=7;j<10;++j){bound(q[j],d[j],"species");}
    return t;
}
ThetaResult connectedFaceTheta(const MaterialCell& q,const MaterialCell& d,const fiveEqRuntimeBridge& bridge){
    ThetaResult r;r.linear=thetaLinearBound(q,d,r.reason);
    auto check=[&](double t){auto f=sharedThetaFace(q,d,t);++r.queries;
        // Nonzero cell phases must not be extinguished by a reconstruction limiter.
        if((q[0]>0&&(f[0]==0||f[2]==0))||(q[0]<1&&(f[0]==1||f[1]==0))){r.reason="phase_presence";return false;}
        auto v=checkMaterialCell(f,bridge,true);
        if(v.issue!=AdmissibilityIssue::OK){r.reason=v.issue==AdmissibilityIssue::RECOVERY?recoveryCodeName(v.diagnostic.code):"linear_or_species";return false;}return true;
    };
    if(!check(0))throw std::invalid_argument("R1 anchor invalid");
    double lo=0,hi=r.linear;bool exit=false;
    for(unsigned j=1;j<=32;++j){double t=r.linear*double(j)/32;if(!check(t)){hi=t;exit=true;break;}lo=t;}
    if(exit)for(unsigned j=0;j<52;++j){double t=lo+(hi-lo)/2;if(t==lo||t==hi)break;if(check(t))lo=t;else hi=t;}
    r.valid=lo;r.invalid=hi;return r;
}
}
