#include "fiveEqR2ThermoReconstruction.H"
namespace fiveEq {
R2Face r2ThermoFace(const std::array<MaterialCell,4>& cells,bool pos,const MaterialCell& fallback,
 const fiveEqRuntimeBridge& bridge,const fiveEqStateRecovery& eos,const Foam::wordList& names){
    R2Face r;r.q=fallback;std::array<fiveEqRecoveredState,4> s;
    bool gas=cells[pos?1:2][1]>0,liquid=cells[pos?1:2][2]>0;
    for(unsigned i=0;i<4;++i){auto v=checkMaterialCell(cells[i],bridge);if(v.issue!=AdmissibilityIssue::OK){r.route="INVALID_CELL";return r;}s[i]=v.recovered.thermo;
        if((cells[i][1]>0)!=gas||(cells[i][2]>0)!=liquid)return r;
    }
    auto scalar=[&](const std::array<double,4>& a){return of7MinmodFace(a[0],a[1],a[2],a[3],pos);};
    double alpha=scalar({{cells[0][0],cells[1][0],cells[2][0],cells[3][0]}});
    if((gas&&alpha==1)||(liquid&&alpha==0))return r;
    double p=scalar({{s[0].p,s[1].p,s[2].p,s[3].p}}),tg=0,tl=0;
    if(gas)tg=scalar({{s[0].TG,s[1].TG,s[2].TG,s[3].TG}});
    if(liquid)tl=scalar({{s[0].TL,s[1].TL,s[2].TL,s[3].TL}});
    auto U=of7MinmodVFace(Foam::vector(s[0].U[0],s[0].U[1],s[0].U[2]),Foam::vector(s[1].U[0],s[1].U[1],s[1].U[2]),Foam::vector(s[2].U[0],s[2].U[1],s[2].U[2]),Foam::vector(s[3].U[0],s[3].U[1],s[3].U[2]),pos);
    std::vector<double> Y(3,0);std::array<unsigned,3> index;
    for(unsigned j=0;j<3;++j){unsigned k=names[j]=="C10H22"?0:names[j]=="O2"?1:2;index[k]=j;}
    if(gas){for(unsigned k=0;k<2;++k){unsigned j=index[k];Y[k]=scalar({{cells[0][7+j]/cells[0][1],cells[1][7+j]/cells[1][1],cells[2][7+j]/cells[2][1],cells[3][7+j]/cells[3][1]}});}Y[2]=1-Y[0]-Y[1];}
    try{auto q=eos.generate(alpha,p,tg,tl,{{U.x(),U.y(),U.z()}},Y);
        MaterialCell f={{q.alphaL,q.mG,q.mL,q.M[0],q.M[1],q.M[2],q.Et,0,0,0}};
        if(gas)for(unsigned k=0;k<3;++k)f[7+index[k]]=q.mG*Y[k];
        if(checkMaterialCell(f,bridge,true).issue!=AdmissibilityIssue::OK){r.route="INVALID_CONSTRUCTION_FALLBACK_R1";return r;}
        r.q=f;r.route="DIRECT";return r;
    }catch(const std::exception&){r.route="INVALID_CONSTRUCTION_FALLBACK_R1";return r;}
}
}
