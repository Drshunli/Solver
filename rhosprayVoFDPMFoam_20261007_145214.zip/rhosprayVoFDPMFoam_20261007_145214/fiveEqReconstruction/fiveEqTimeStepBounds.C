#include "fiveEqTimeStepBounds.H"
#include "fiveEqAlphaDiscrete.H"
#include "../fiveEqPrecision/fiveEqScaledRatio.H"
#include <cmath>
#include <limits>
#include <algorithm>
namespace fiveEq {
namespace {
double positiveBound(double integral,double outgoing){return positivePhaseTimeRatio(integral,outgoing);}
void requireFace(const fiveEqKTFaceFlux& f){if(f.status!=FaceFluxStatus::OK)throw std::invalid_argument("Invalid flux passed to update");}
}
TimeStepBounds explicitTimeStepBounds(const MaterialCell& q,double V,
    const fiveEqKTFaceFlux& L,const fiveEqKTFaceFlux& R,double meshL,double meshR,double cfl,double safety){
    requireFace(L);requireFace(R);
    if(!(V>0&&cfl>0&&cfl<=1&&safety>0&&safety<=1))throw std::invalid_argument("Invalid timestep settings");
    const double D=meshR-meshL;
    const double N=-(R.alphaPhiCandidate-L.alphaPhiCandidate)+q[0]*(R.wave.phiRelStar-L.wave.phiRelStar);
    TimeStepBounds b;
    const double waveL=std::max(std::abs(L.wave.ap),std::abs(L.wave.am));
    const double waveR=std::max(std::abs(R.wave.ap),std::abs(R.wave.am));
    b.acoustic=cfl*2*V/(waveL+waveR);
    // alpha lower: a V+dt(a D+N)>=0; upper: (1-a)V+dt((1-a)D-N)>=0.
    b.alpha=std::min(positiveBound(q[0]*V,-q[0]*D-N),positiveBound((1-q[0])*V,N-(1-q[0])*D));
    b.mG=positiveBound(V*q[1],R.mGPhi-L.mGPhi);b.mL=positiveBound(V*q[2],R.mLPhi-L.mLPhi);
    b.species=std::numeric_limits<double>::infinity();
    for(unsigned j=0;j<3;++j)b.species=std::min(b.species,positiveBound(V*q[7+j],R.speciesPhi[j]-L.speciesPhi[j]));
    b.volume=D<0?V/(-D):std::numeric_limits<double>::infinity();
    b.joint=b.acoustic;b.controlling="acoustic";
    for(auto v:{std::make_pair(b.alpha,"alpha"),std::make_pair(b.mG,"mG"),std::make_pair(b.mL,"mL"),std::make_pair(b.species,"species"),std::make_pair(b.volume,"volume")}){
        if(safety*v.first<b.joint){b.joint=safety*v.first;b.controlling=v.second;}
    }
    return b;
}
ExplicitCellTrial explicitTrial(const MaterialCell& q,double V,double dt,
    const fiveEqKTFaceFlux& L,const fiveEqKTFaceFlux& R,double meshL,double meshR){
    requireFace(L);requireFace(R);
    auto a=alphaEulerStep(q[0],V,dt,L.alphaPhiCandidate,R.alphaPhiCandidate,L.wave,R.wave,meshL,meshR);
    ExplicitCellTrial s;s.volume=a.volume;s.alphaSourceIntegral=a.sourceIntegral;s.q=q;s.q[0]=a.alpha;
    s.q[1]=(V*q[1]-dt*(R.mGPhi-L.mGPhi))/s.volume;
    s.q[2]=(V*q[2]-dt*(R.mLPhi-L.mLPhi))/s.volume;
    for(unsigned j=0;j<3;++j){s.q[3+j]=(V*q[3+j]-dt*(R.momentumPhi[j]-L.momentumPhi[j]))/s.volume;
        s.q[7+j]=(V*q[7+j]-dt*(R.speciesPhi[j]-L.speciesPhi[j]))/s.volume;}
    s.q[6]=(V*q[6]-dt*(R.energyPhi-L.energyPhi))/s.volume;
    // Fixed-volume representation-safe evaluation of the same conservative
    // Euler update. Forming V*q first can quantize a coherent subnormal phase
    // even with zero net flux. FMA retains the stored mass without that loss.
    if(meshL==0&&meshR==0){
        const double rate=dt/V;
        s.q[1]=std::fma(-rate,R.mGPhi-L.mGPhi,q[1]);
        s.q[2]=std::fma(-rate,R.mLPhi-L.mLPhi,q[2]);
        for(unsigned j=0;j<3;++j){
            s.q[3+j]=std::fma(-rate,R.momentumPhi[j]-L.momentumPhi[j],q[3+j]);
            s.q[7+j]=std::fma(-rate,R.speciesPhi[j]-L.speciesPhi[j],q[7+j]);
        }
        s.q[6]=std::fma(-rate,R.energyPhi-L.energyPhi,q[6]);
    }
    // No repair, species normalization, energy positivity surrogate or EOS extrapolation.
    return s;
}
}
