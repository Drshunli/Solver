#include "fiveEqReconstruction.H"
#include <cmath>
namespace fiveEq {
fiveEqRuntimeInput runtimeInput(const MaterialCell& q){
    const double sum=q[7]+q[8]+q[9];
    for(unsigned j=0;j<3;++j)if(!std::isfinite(q[7+j])||q[7+j]<0)
        throw std::invalid_argument("Invalid conservative species mass");
    if((q[1]==0&&sum!=0)||(q[1]>0&&std::abs(sum-q[1])/q[1]>1e-12))
        throw std::invalid_argument("Species masses do not close to mG");
    Foam::scalarField Y;
    if(q[1]>0){Y=Foam::scalarField(3,0);for(unsigned j=0;j<3;++j)Y[j]=q[7+j]/q[1];}
    return fiveEqRuntimeInput(q[0],q[1],q[2],Foam::vector(q[3],q[4],q[5]),q[6],Y);
}
CellAdmissibility checkMaterialCell(const MaterialCell& q,const fiveEqRuntimeBridge& bridge,bool face){
    CellAdmissibility d;
    for(double x:q)if(!std::isfinite(x)){d.issue=AdmissibilityIssue::NONFINITE;return d;}
    if(q[0]<0||q[0]>1){d.issue=AdmissibilityIssue::ALPHA;return d;}
    if(q[1]<0||q[2]<0||q[1]+q[2]<=0){d.issue=AdmissibilityIssue::MASS;return d;}
    for(unsigned j=0;j<3;++j)if(q[7+j]<0){d.issue=AdmissibilityIssue::SPECIES;return d;}
    const double sum=q[7]+q[8]+q[9];
    if((q[1]==0&&sum!=0)||(q[1]>0&&std::abs(sum-q[1])/q[1]>1e-12)){
        d.issue=AdmissibilityIssue::SPECIES;return d;
    }
    if((q[0]==0&&q[2]!=0)||(q[0]==1&&q[1]!=0)){
        d.issue=AdmissibilityIssue::PRESENCE;return d;
    }
    const auto in=runtimeInput(q);
    const bool ok=face?bridge.recoverFaceState(in,d.recovered,d.diagnostic):bridge.recoverCellState(in,d.recovered,d.diagnostic);
    d.issue=ok?AdmissibilityIssue::OK:AdmissibilityIssue::RECOVERY;return d;
}
fiveEqKTFaceFlux reconstructR0(const MaterialCell& L,const MaterialCell& R,
    const fiveEqKTFaceFluxKernel& flux,const Foam::vector& S,double meshPhi){
    // Caller validates cell-level species-mass closure; bridge validates Yi.
    return flux.evaluate(runtimeInput(L),runtimeInput(R),S,meshPhi);
}
}
