#include "fiveEqOF7Directional.H"
#include "Minmod.H"
#include "NVDTVD.H"
#include "NVDVTVDV.H"
#include "vanLeer.H"
#include "Limited01.H"
#include "IStringStream.H"
#include "tensor.H"
namespace fiveEq {
double of7MinmodFace(double a,double b,double c,double d,bool pos){
    Foam::IStringStream is("");Foam::MinmodLimiter<Foam::NVDTVD> limiter(is());
    double l=limiter.limiter(.5,pos?1:-1,b,c,Foam::vector(.5*(c-a),0,0),Foam::vector(.5*(d-b),0,0),Foam::vector(1,0,0));
    double w=.5*l+(1-l)*(pos?1:0);return w*b+(1-w)*c;
}
Foam::vector of7MinmodVFace(const Foam::vector& a,const Foam::vector& b,const Foam::vector& c,const Foam::vector& d,bool pos){
    Foam::IStringStream is("");Foam::MinmodLimiter<Foam::NVDVTVDV> limiter(is());
    Foam::vector gp=.5*(c-a),gn=.5*(d-b);
    Foam::tensor P(gp.x(),gp.y(),gp.z(),0,0,0,0,0,0),N(gn.x(),gn.y(),gn.z(),0,0,0,0,0,0);
    double l=limiter.limiter(.5,pos?1:-1,b,c,P,N,Foam::vector(1,0,0));
    double w=.5*l+(1-l)*(pos?1:0);return w*b+(1-w)*c;
}
double of7VanLeerLimiter(double a,double b,double c,double d,double f){
    Foam::IStringStream is("");Foam::vanLeerLimiter<Foam::NVDTVD> limiter(is());
    return limiter.limiter(.5,f,b,c,Foam::vector(.5*(c-a),0,0),Foam::vector(.5*(d-b),0,0),Foam::vector(1,0,0));
}
double of7VanLeerFace(double a,double b,double c,double d,double f){
    double l=of7VanLeerLimiter(a,b,c,d,f);
    double w=.5*l+(1-l)*(f>=0?1:0);return w*b+(1-w)*c;
}
MaterialCell materialRawFace(const MaterialCell& a,const MaterialCell& b,const MaterialCell& c,const MaterialCell& d,bool pos){
    MaterialCell f;for(unsigned j=0;j<10;++j)f[j]=of7MinmodFace(a[j],b[j],c[j],d[j],pos);
    auto v=of7MinmodVFace(Foam::vector(a[3],a[4],a[5]),Foam::vector(b[3],b[4],b[5]),Foam::vector(c[3],c[4],c[5]),Foam::vector(d[3],d[4],d[5]),pos);
    for(unsigned j=0;j<3;++j){f[3+j]=v[j];}
    return f;
}
}
