#include "fiveEqThermodynamicTimeStep.H"
#include <cmath>
#include <algorithm>
namespace fiveEq {
ThermodynamicStep connectedThermodynamicStep(const MaterialCell& q,double V,double dt,
 const fiveEqKTFaceFlux& L,const fiveEqKTFaceFlux& R,double ml,double mr,
 const fiveEqRuntimeBridge& bridge,
 const std::function<void(double,const ExplicitCellTrial&,const CellAdmissibility&)>& observer,unsigned subdivisions){
    ThermodynamicStep b;
    if(!(V>0&&dt>0&&std::isfinite(dt)&&subdivisions>0))throw std::invalid_argument("Invalid thermodynamic continuation configuration");
    auto test=[&](double x){auto t=explicitTrial(q,V,x*dt,L,R,ml,mr);auto a=checkMaterialCell(t.q,bridge);++b.queries;
        if(observer)observer(x,t,a);
        return a.issue==AdmissibilityIssue::OK;
    };
    b.initialValid=test(0);if(!b.initialValid){b.failure=R0FailureClass::NUMERICAL_THERMO_INADMISSIBILITY;return b;}
    double lo=0,hi=1;
    // Deterministic continuation, stop at FIRST sampled exit. Never search re-entry.
    // Finite sampling is not a mathematical certification between sample points.
    for(unsigned j=1;j<=subdivisions;++j){double x=double(j)/subdivisions;
        if(!test(x)){hi=x;b.exitFound=true;break;}lo=x;
    }
    if(b.exitFound){b.failure=R0FailureClass::NUMERICAL_THERMO_INADMISSIBILITY;
        for(unsigned j=0;j<52;++j){double mid=lo+(hi-lo)/2;if(mid==lo||mid==hi)break;
            if(test(mid))lo=mid;else hi=mid;
        }
    }
    b.lambdaValid=lo;b.lambdaInvalid=b.exitFound?hi:1;b.dtThermo=lo*dt;
    return b;
}
bool mixedOutwardBoundary(const MaterialCell& q,double V,const fiveEqKTFaceFlux& L,const fiveEqKTFaceFlux& R,
 double ml,double mr,const fiveEqRuntimeBridge& bridge,const fiveEqGasThermoEvaluator& gas,
 const fiveEqLiquidThermoEvaluator& eos,const std::array<unsigned,3>& index){
    if(!(q[0]>0&&q[0]<1&&q[1]>0&&q[2]>0))return false;
    auto v=checkMaterialCell(q,bridge);if(v.issue!=AdmissibilityIssue::OK)return false;
    const auto& s=v.recovered.thermo;
    const auto li=eos.evaluateRhoP(s.rhoL,s.p);
    const double D=mr-ml;
    const double ad=(-(R.alphaPhiCandidate-L.alphaPhiCandidate)+q[0]*(R.wave.phiRelStar-L.wave.phiRelStar))/V;
    const double gd=(-(R.mGPhi-L.mGPhi)-q[1]*D)/V,ld=(-(R.mLPhi-L.mLPhi)-q[2]*D)/V;
    const double rgd=(gd+s.rhoG*ad)/(1-q[0]),rld=(ld-s.rhoL*ad)/q[0];
    const double Ed=(-(R.energyPhi-L.energyPhi)-q[6]*D)/V,r=s.rhoMix,rd=gd+ld;
    double kd=0;for(unsigned j=0;j<3;++j){const double Md=(-(R.momentumPhi[j]-L.momentumPhi[j])-q[3+j]*D)/V;
        kd+=q[3+j]*Md/r-.5*q[3+j]*q[3+j]*rd/(r*r);}
    std::vector<double> Y(3);double Rdot=0,eYdot=0;
    for(unsigned k=0;k<3;++k){unsigned j=index[k];Y[k]=q[7+j]/q[1];
        const double myd=(-(R.speciesPhi[j]-L.speciesPhi[j])-q[7+j]*D)/V;
        const double yd=(myd-Y[k]*gd)/q[1];
        Rdot+=yd*gas.speciesData()[k].R();eYdot+=yd*gas.speciesData()[k].Es(s.p,s.TG);
    }
    const auto g=gas.evaluateRhoP(s.rhoG,s.p,Y);eYdot-=g.Cv*s.TG*Rdot/g.R;
    const double egRho=-g.beta*s.p/s.rhoG,elRho=-li.beta*li.dpDrhoE;
    const double pd=(Ed-kd-gd*s.eG-ld*s.eL-q[1]*(egRho*rgd+eYdot)-q[2]*elRho*rld)/(q[1]*g.beta+q[2]*li.beta);
    const double eRT=(li.p-li.T*li.Cv/li.beta)/(li.rho*li.rho);
    const double td=(li.beta*pd+(elRho-eRT)*rld)/li.Cv;
    const double tgd=g.T*(pd/g.p-rgd/g.rho-Rdot/g.R);
    // Mixed recovery returns exact EOS endpoint temperature on root-boundary exhaustion.
    return (li.T==285&&td<0)||(li.T==320&&td>0)||(li.p==50000&&pd<0)||(li.p==12e6&&pd>0)
        ||(g.T==100&&tgd<0)||(g.T==6000&&tgd>0);
}
bool pureLiquidOutwardBoundary(const MaterialCell& q,double V,const fiveEqKTFaceFlux& L,
 const fiveEqKTFaceFlux& R,double ml,double mr,const fiveEqRuntimeBridge& bridge,const fiveEqLiquidThermoEvaluator& eos,double seedP,double seedT){
    if(q[0]!=1||q[1]!=0)return false;
    auto v=checkMaterialCell(q,bridge);if(v.issue!=AdmissibilityIssue::OK)return false;
    const auto s=eos.evaluateRhoP(q[2],v.recovered.thermo.p);
    const double D=mr-ml,rho=s.rho;
    const double rd=(-(R.mLPhi-L.mLPhi)-q[2]*D)/V;
    const double Ed=(-(R.energyPhi-L.energyPhi)-q[6]*D)/V;
    double kd=0;
    for(unsigned j=0;j<3;++j){const double Md=(-(R.momentumPhi[j]-L.momentumPhi[j])-q[3+j]*D)/V;
        kd+=q[3+j]*Md/rho-.5*q[3+j]*q[3+j]*rd/(rho*rho);}
    const double ed=(Ed-kd-s.e*rd)/rho;
    const double pd=s.dpDrhoE*rd+s.dpDeRho*ed;
    const double eRT=(s.p-s.T*s.Cv/s.beta)/(rho*rho),td=(ed-eRT*rd)/s.Cv;
    // Exact seed metadata is available only for user-defined synthetic boundary states.
    // Without such metadata, a merely near-boundary interior state is NOT domain escape.
    if(std::isfinite(seedP)&&std::abs(seedP-s.p)>1e-3)throw std::invalid_argument("Certified pressure seed mismatch");
    if(std::isfinite(seedT)&&std::abs(seedT-s.T)>1e-8)throw std::invalid_argument("Certified temperature seed mismatch");
    const double p=std::isfinite(seedP)?seedP:s.p,T=std::isfinite(seedT)?seedT:s.T;
    return (p==50000&&pd<0)||(p==12e6&&pd>0)||(T==285&&td<0)||(T==320&&td>0);
}
}
