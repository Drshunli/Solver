#include "fiveEqR1SharedTheta.H"
#include <algorithm>
namespace fiveEq {
R1Cell r1SharedCell(const MaterialCell& q,std::vector<MaterialCell> increments,const fiveEqRuntimeBridge& b){
    R1Cell r;r.theta=1;double linear=1;
    for(auto& d:increments){d[9]=d[1]-(d[7]+d[8]);ThetaResult bound;bound.linear=thetaLinearBound(q,d,bound.reason);linear=std::min(linear,bound.linear);r.bounds.push_back(bound);}
    // Continue the intersection at a COMMON theta. Independent face intervals
    // cannot safely be intersected by taking their last valid endpoints alone.
    auto valid=[&](double theta){bool all=true;for(unsigned i=0;i<increments.size();++i){auto f=sharedThetaFace(q,increments[i],theta);auto& bound=r.bounds[i];++bound.queries;
        bool present=!((q[0]>0&&(f[0]==0||f[2]==0))||(q[0]<1&&(f[0]==1||f[1]==0)));
        auto v=checkMaterialCell(f,b,true);bool ok=present&&v.issue==AdmissibilityIssue::OK;
        if(!ok){bound.reason=!present?"phase_presence":v.issue==AdmissibilityIssue::RECOVERY?recoveryCodeName(v.diagnostic.code):"linear_or_species";}all=all&&ok;}return all;
    };
    if(!valid(0))throw std::invalid_argument("R1 anchor invalid");
    double lo=0,hi=linear;bool exit=false;
    for(unsigned j=1;j<=32;++j){double t=linear*double(j)/32;if(!valid(t)){hi=t;exit=true;break;}lo=t;}
    if(exit)for(unsigned j=0;j<52;++j){double t=lo+(hi-lo)/2;if(t==lo||t==hi)break;if(valid(t))lo=t;else hi=t;}
    r.theta=lo;
    for(auto& bound:r.bounds){bound.valid=lo;bound.invalid=hi;}
    for(auto& d:increments){auto f=sharedThetaFace(q,d,r.theta);if(checkMaterialCell(f,b,true).issue!=AdmissibilityIssue::OK)throw std::runtime_error("Final shared theta face invalid");r.faces.push_back(f);}
    return r;
}
}
