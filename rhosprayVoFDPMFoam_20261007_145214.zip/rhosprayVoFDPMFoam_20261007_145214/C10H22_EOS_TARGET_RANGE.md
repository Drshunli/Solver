# C10H22 Eulerian-liquid EOS target range — M6A1b

**Superseded by the [M6A1b-2A operating-condition ledger](OPERATING_ENVELOPE_M6A1B2A.md).** This earlier record is retained as historical evidence from `300_2D`; the user has since supplied a different, partially locked gas freestream. Liquid inlet p/T and final Mach remain open.

## Values actually present in the current workspace

| Item | Evidence | Meaning for this calibration |
|---|---|---|
| Species `C10H22` | `300_2D/constant/thermophysicalProperties`, `sprayCloudProperties` | Identifies n-decane in this one-liquid case. |
| Jet/column diameter `0.3 mm` | User clarification in this M6A1b turn | Geometry only; it determines no liquid EOS temperature or pressure bound. |
| Parcel `T0=300 K`, `rho0=730 kg/m3`, `Cp0=2090 J/(kg K)` | `300_2D/constant/sprayCloudProperties` | DPM initialization constants. `rho0`/`Cp0` have no independent measurement provenance in the case and are not accepted as calibration observations. |
| Gas `0/p` initial/inlet `102243 Pa`, outlet placeholder `101325 Pa` | `300_2D/0/p` | Gas boundary/initial settings, not a specified liquid-inlet pressure. |
| `setFieldsDict` base `101325 Pa, 300 K`; hot region `4053000 Pa, 2000 K` | `300_2D/system/setFieldsDict` | Gas field setup. The hot-gas temperature is **not** a liquid target temperature. The high gas pressure suggests a pressure exposure to examine but does not establish liquid post-shock pressure. |
| Gas `0/T` initial/inlet `166.67 K` | `300_2D/0/T` | Gas boundary/initial setting, not a liquid EOS temperature. |
| Injection model `flowRateAndDischarge` | `300_2D/constant/sprayCloudProperties` | No explicit nominal liquid injection pressure is specified. |

The historical `300_2D` case points `controlDict.application` at `rhosprayVoFFoam` and has no production `alphaL` initial field. Its gas and parcel settings must not silently become VOF liquid bounds.

## Target range status

`p_min`, `p_max`, `T_min`, `T_max`, nominal liquid pressure, liquid-temperature range after shock, expected post-shock liquid pressure, and expected liquid-density range: **USER INPUT REQUIRED / UNDETERMINED**. Only the DPM parcel nominal initial temperature of 300 K is evidenced. No accepted fitting range is declared here. The offline fitter requires explicit target and nominal values rather than borrowing gas-shock bounds.

Once supplied, include low, nominal and high pressure levels, multiple liquid temperatures, and phase-stability checks. A candidate data source covering a wide range does not itself define this project's required range.
