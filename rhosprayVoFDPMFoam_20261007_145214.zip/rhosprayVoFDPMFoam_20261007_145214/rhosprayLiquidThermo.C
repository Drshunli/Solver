#include "rhosprayLiquidThermo.H"
#include "error.H"
#include "dimensionSets.H"
#include <cmath>

Foam::rhosprayLiquidThermo::rhosprayLiquidThermo(const dictionary& dict)
:
    component_(dict.lookup("component")),
    gamma_(readScalar(dict.lookup("gamma"))),
    pInf_
    (
        dimensionedScalar("pInf", dimPressure, dict).value()
    ),
    Cv_
    (
        dimensionedScalar("Cv", dimSpecificHeatCapacity, dict).value()
    ),
    q_
    (
        dimensionedScalar("q", dimEnergy/dimMass, dict).value()
    )
{
    if
    (
        !std::isfinite(gamma_) || gamma_ <= 1
     || !std::isfinite(pInf_) || pInf_ < 0
     || !std::isfinite(Cv_) || Cv_ <= 0
     || !std::isfinite(q_)
    )
    {
        FatalErrorInFunction
            << "Invalid stiffened-gas Eulerian liquid parameters"
            << exit(FatalError);
    }
}


void Foam::rhosprayLiquidThermo::checkPT
(
    const scalar p,
    const scalar T
) const
{
    if
    (
        !std::isfinite(p) || !std::isfinite(T)
     || p + pInf_ <= 0 || T <= 0
    )
    {
        FatalErrorInFunction
            << "Invalid Eulerian liquid state: p=" << p << ", T=" << T
            << exit(FatalError);
    }
}


void Foam::rhosprayLiquidThermo::checkRhoP
(
    const scalar rho,
    const scalar p
) const
{
    if
    (
        !std::isfinite(rho) || !std::isfinite(p)
     || rho <= 0 || p + pInf_ <= 0
    )
    {
        FatalErrorInFunction
            << "Invalid Eulerian liquid state: rho=" << rho << ", p=" << p
            << exit(FatalError);
    }
}


Foam::scalar Foam::rhosprayLiquidThermo::rho
(
    const scalar p,
    const scalar T
) const
{
    checkPT(p, T);
    return (p + pInf_)/((gamma_ - 1)*Cv_*T);
}


Foam::scalar Foam::rhosprayLiquidThermo::e
(
    const scalar p,
    const scalar T
) const
{
    return q_ + Cv_*T + pInf_/rho(p, T);
}


Foam::scalar Foam::rhosprayLiquidThermo::h
(
    const scalar p,
    const scalar T
) const
{
    return e(p, T) + p/rho(p, T);
}


Foam::scalar Foam::rhosprayLiquidThermo::T
(
    const scalar rho,
    const scalar p
) const
{
    checkRhoP(rho, p);
    return (p + pInf_)/((gamma_ - 1)*rho*Cv_);
}


Foam::scalar Foam::rhosprayLiquidThermo::eFromRhoP
(
    const scalar rho,
    const scalar p
) const
{
    checkRhoP(rho, p);
    return q_ + (p + gamma_*pInf_)/((gamma_ - 1)*rho);
}


Foam::scalar Foam::rhosprayLiquidThermo::c
(
    const scalar rho,
    const scalar p
) const
{
    checkRhoP(rho, p);
    return std::sqrt(gamma_*(p + pInf_)/rho);
}


Foam::scalar Foam::rhosprayLiquidThermo::deDpConstRho
(
    const scalar rho,
    const scalar p
) const
{
    checkRhoP(rho, p);
    return 1/((gamma_ - 1)*rho);
}


Foam::scalar Foam::rhosprayLiquidThermo::drhoDpConstT
(
    const scalar p,
    const scalar T
) const
{
    checkPT(p, T);
    return 1/((gamma_ - 1)*Cv_*T);
}


Foam::scalar Foam::rhosprayLiquidThermo::xi
(
    const scalar rho,
    const scalar p
) const
{
    checkRhoP(rho, p);
    return 1/(gamma_ - 1);
}
