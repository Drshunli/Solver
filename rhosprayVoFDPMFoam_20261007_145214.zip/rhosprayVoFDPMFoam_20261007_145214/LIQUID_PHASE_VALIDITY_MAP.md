# M6A1b-2A.2 liquid phase-validity audit

## Current authority — M6A1b-2A.3 (2026-09-30)

Overall **M6A1b-2A COMPLETE as a project domain/policy design gate**. Expected
physical screening is 0.188330–6.201421 MPa / 299.440696–301.200448 K;
approved PRODUCTION is **0.10–8 MPa / 295–305 K**; project HARD is
**0.05–12 MPa / 285–320 K**, absolute pressure and inclusive boundaries.
These design support limits do not predict guaranteed CFD extrema.
The former 0.180–6.250 MPa / 299–302 K proposal is historical and superseded.
See [current assessment](M6A1B2A3_ENVELOPE_HARDENING.md) and
[domain/failure policy](EOS_OUT_OF_DOMAIN_POLICY.md); the machine-readable
authority is `fitting/liquid_eos_domain_contract.json`.
M6A1b-2B is NEXT / NOT STARTED. Production model selection, final reference
training/holdout generation and solver energy-offset alignment remain open.
No active solver or CFD case changes were made.

All 6384 assessment states passed liquid-vapor scope and numerical-property gates. Exact backend labels are `liquid` and `supercritical_liquid`; the latter is dense/compressed liquid below Tc, not a conventional above-Tc supercritical fluid. At the HARD hot/low-pressure corner, p/psat is 68.11, with a 49.266 kPa gap. Verified solid/liquid melting-line provenance remains unavailable.

## Historical audit (superseded status statements below)


**Result: candidate mechanical rectangle passes liquid-vapor phase checks; its engineering bounds are PROVISIONAL.** Backend checks do not approve the operating envelope or supply a solid-liquid melting diagram.

Backend: CoolProp 8.0.0 HEOS, n-Decane (CAS 124-18-5), Lemmon–Span 2006 reference EOS, DOI [10.1021/je050186n](https://doi.org/10.1021/je050186n). Data are **REFERENCE-EOS GENERATED**, not experimental measurements. Version, git revision, native ideal Helmholtz terms and fluid-definition hash are retained in `fitting/M6A1b2A2_reference_queries.json` and `fitting/n-Decane_backend_definition.json`. [Official n-Decane model and limits](https://coolprop.org/fluid_properties/fluids/n-Decane.html).

## Inlet classification

At p=3 MPa and T=300 K, unconstrained equilibrium flash returns `supercritical_liquid`: p>pc=2.101337 MPa while T<Tc=617.698845 K. This label denotes the compressed-liquid side below Tc; the state is not above both critical coordinates. It is not vapor or equilibrium two-phase. At 300 K, psat=207.0885 Pa, approximately 2.999793 MPa below inlet pressure. No liquid phase was forced in the queries.

## Proposed rectangle and checks

The candidate safety rectangle is **0.180–6.250 MPa, 299–302 K**. It contains the reversible paths and an additional limiting dissipative decompression path. Eleven saturation queries over 299–302 K give increasing psat; the highest is approximately 237.229 Pa. At the hottest/lowest-pressure corner, p-psat is approximately **179762.77 Pa**. This is the corner closest to vapor coexistence. All temperatures are at least 315.699 K below Tc. A pressure crossing pc at T far below Tc does not cross the liquid-vapor coexistence line.

Twenty-five equilibrium PT spot queries (5 pressure levels × 5 temperatures) return only `liquid` or `supercritical_liquid`, with positive rho, c², Cp, Cv and isothermal compressibility. Along eight entropy-path states and four limiting dissipative-release states the same phase and positivity checks pass. The rectangular liquid-vapor exclusion argument is p_min>psat(T_max) plus increasing saturation pressure throughout this temperature interval; the 25 spots support liquid-branch numerical consistency, not a mathematical proof of every derivative at every point.

| Pressure region | T=299–302 K backend phase | Intended interpretation |
|---|---|---|
| 0.180 MPa to below pc | liquid | stable compressed liquid in liquid-vapor model |
| above pc to 6.250 MPa | supercritical_liquid | compressed liquid below Tc |
| p near or below psat(T) | outside proposed rectangle | vapor/two-phase risk; no extrapolation or masking allowed |

Backend declared fluid limits are Tmin=243.5 K, Tmax=675 K and pmax=800 MPa; proposed points are inside them. Those are implementation/model limits, not a guarantee of uniform experimental uncertainty. No pressure-dependent melting correlation for decane is available in the selected fluid definition. The candidate is far above the triple-point temperature, but this audit does not prove solid-phase exclusion using a measured melting boundary. Treat this as an explicit provenance limitation rather than relabeling HEOS phase outputs as full phase-diagram measurements.

No liquid-vapor MODEL-SCOPE CONFLICT was found. If later rarefaction falls toward coexistence, or mechanical dissipation/work heats above the candidate range, stop and revisit the model scope/envelope; do not mask invalid states and continue production grid generation. Full reference-table generation and M6A1b-2B remain deferred.
