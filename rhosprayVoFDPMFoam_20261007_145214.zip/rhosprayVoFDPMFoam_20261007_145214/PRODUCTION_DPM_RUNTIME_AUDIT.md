# M8A.1 actual production DPM runtime audit

Audited dictionary: `D:/DATA/Solver/300_2D/constant/sprayCloudProperties`.
Audited Foundation version: local OpenFOAM Foundation7, not OpenFOAM.com.
Complete copied source/hash provenance: `fitting/dpm/m8a1_v1/source_audit`.
The native harness copies this DPM dictionary byte-for-byte and instantiates
basicSprayCloud using its actual runtime selectors. Geometry/carrier fields are
manufactured for a non-CFD unit harness; no Eulerian equation is solved.

## Enabled selections (confirmed in native runtime log)

| Family | Actual selection | Relevant state/path |
|---|---|---|
| Injection | coneInjection, fuelInjector, point, flowRateAndDischarge | RosinRammler sampling; time0/timeStep0, injected mass/parcel counts, cached cell/tet, RNG reference |
| Drag | sphereDrag | force caches and coupled-force switch |
| Heat transfer | none | RanzMarshallCoeffs exists but is INACTIVE |
| Phase change | none | liquidEvaporationBoilCoeffs exists but is INACTIVE |
| Composition | singlePhaseMixture, C10H22 liquid | carrier species C10H22/O2/N2; thermo references |
| Atomization | blobsSheetAtomization | parcel liquidCore and diameter/multiplicity; owner injector properties |
| Breakup | ReitzKHRT | parcel d, nParticle, tc, ms, KHindex, y/yDot, child creation |
| Collision | ORourke, coalescence yes | occupancy/parcel pairs, RNG, merging/deletion |
| Patch interaction | standardWallInteraction, rebound | native patchData, active/U; escape/stick counters exist but modes not selected |
| Dispersion | stochasticDispersionRAS | parcel UTurb/tTurb; RNG normal cache; k/epsilon caches |
| Carrier turbulence | compressible RAS kOmegaSST | immutable manufactured k/omega for this particle unit probe |
| Surface film / radiation | none / off | no active film/radiation exchange |
| Cloud function | voidFraction | private thetaPtr, accumulation, normalization, writes |
| Cell source correction | ON | native rho*V denominator, not future partial gas mass mG*V |

Transient/coupled=true; source rho/U/Yi/h/e schemes explicit1; U integration
Euler, T analytical; maxCo=.3. Coefficients were not modified in the harness.
Existing dictionary uses effective dOuter=138.1976598um (2D area convention),
massTotal=.0005262723452 kg and duration1s. It is NOT silently reinterpreted as
the separately locked future 300um/1.09609e-4 kg/s injector. Existing 300_2D
carrier files are historical (e.g. U=517.6 m/s); no final operating-condition
or five-equation case update is performed by this model audit.

## Actual carrier query path

| Quantity | Actual scheme/access | Required support |
|---|---|---|
| rho | cell; KinematicParcel::setCellValues | containing cell, intrinsic gas rhoG |
| U | cellPoint | containing cell + contributing point reconstruction + physical patch states |
| thermo:mu | cell | containing gas cell |
| T / Cp / kappa | cell; ThermoParcel::setCellValues | TG/gas caloric and transport data |
| p | cell; ReactingParcel::setCellValues | common p in gas-supported cell |
| carrier species | direct Y(i)[cell], component thermo at local p/T | YG consistency in containing gas cell |
| source correction | source arrays/current cell | gas partial mass and coherent Q; future replacement unresolved |

KinematicParcel::move tracks first, then calls p.setCellValues, dispersion,
source correction and p.calc, then function/face/patch callbacks. A guard
must intercept before the first query of each new cell/tet/patch segment.
InjectionModel::inject obtains position/cell/tet, then constructs parcel,
sets thermo/properties and moves it. Required injection interception is after
position/cell resolution and BEFORE `new parcelType`; a post-creation check
does not meet the contract. Native legacy path has no installed P2 hook.

## Real stencil and weights

OF7 UcellPoint is `Uc*b0 + Up0*b1 + Up1*b2 + Up2*b3` with native particle
barycentric coordinates/currentTetIndices. Up is volPointInterpolation:
interior points use normalized inverse distances to pointCells; physical
boundary points use boundary faces; empty/coupled faces and constraints have
special handling and synchronization. It is not just a containing-cell read.

`fiveEqDPMNativeStencilProbe.H` uses actual OF7 interpolation objects and vector
basis impulses to measure tensor coefficients, including component constraints.
Basis fields are operator diagnostics, NOT dummy gas thermo. All nonzero real
contributors require authoritative patch/cell P2+Q. The containing cell is also
mandatory for scalar thermo queries even if its U coefficient is zero.
No coefficient threshold, masking or renormalization is used. Injection rows
are saved in actual_stencil.csv; native tracking uses the exact particle
coordinates/tet overload. The serial probe is bounded to <=256 entities and
is deliberately NOT advertised as a scalable production/MPI stencil builder.
Unknown boundary/coupled contributors fail closed rather than borrowing gas.

## Mutable-state inventory / snapshot limitations

| Owner | State to preserve | Native result / remaining work |
|---|---|---|
| Cloud particle list | full serialized parcel properties, IDs, cell/tet, tracking fractions | list clone/restore works in deletion/rebound probes |
| Global particle allocator | particleCount_ | Cloud::cloudReset sets ZERO, not saved value; nonzero retry IDs drift |
| Injection model/list | time0/timeStep0, nParcelsAdded/massInjected, cached address, distribution state | count/mass retry matches in one probe; ID drift prevents full equivalence |
| Cloud RNG | generator and cached normal state | scalar stream/cumulative source repeat observed; full forced stochastic-event coverage not proven |
| Model owners | owner reference and subModel properties reference | copied CloudSubModelBase and function list retain original owner; native clone is not isolated trial ownership |
| Parcel atomization/breakup | liquidCore, diameter/age/oscillation/KH/child state | clone paths audited; forced child creation rollback NOT tested |
| ORourke | coalescence decisions, pair occupancy, creation/deletion, RNG | actual model selected/run; forced merge/deletion rollback NOT proven |
| Rebound model | U/active/patch state, model properties | actual rebound full parcel serialization restore/retry passes |
| Phase change | mass-transfer counters / model properties | none selected; production minMass deletion tested; M8A evaporation regression unchanged |
| Sources | rhoTrans[], UTrans, UCoeff, hsTrans, hsCoeff | native restore omits arrays; explicit frozen source snapshot available/tested |
| Cloud solution | iter, tracking time/state/flags | cloudReset does not copy entire solution_ back; exact wrapper needed |
| Statistics/properties | outputProperties, info/setModelProperty mutations | clone has copy, reset does not restore entire dictionary; shared references need audit |
| Occupancy/caches | parcel pointer lists, force/dispersion caches | clone occupancy empty; reset/rebuild validity needs explicit ownership |
| VoidFraction | private thetaPtr and registered field, values/boundary values | copy constructor sets thetaPtr=null; native restore loses field; NOT exact rollback |
| Pending output | theta and outputProperties files | native postEvolve writes at writeTime before caller acceptance; files survive restore |
| Caller | coherent Q/oldTime, support generation, mesh/time, MPI transfers | separate caller-owned transaction required; not part of native cloudReset |

## Architecture decision

Direct native `clone()->evolve()` is rejected as an isolated trial: real probe
shows clone injector owner aliases production cloud. Raw storeState/restoreState
plus source snapshot is also insufficient: private theta, properties/solution,
nonzero allocator and irreversible output remain. Trial-cloud ownership
rebinding plus commit-deferred output is the preferred future architecture;
exact snapshot is acceptable only after ALL states above have tested restoration.

The capability gate refuses unsupported production transactions BEFORE mutation.
It is a fail-closed readiness interface, NOT the complete cloud transaction.
No silent output disablement, interpolation change, model removal or active
cloud/source placement change was made. M8A.1 and M8A remain PARTIAL.
