# M6B.1-MC5-NONZERO-K-SERIAL-QUALIFICATION

日期：2026-10-06（Asia/Shanghai）。

1. **MC5 status** — COMPLETE / NONZERO-K SERIAL OPERATIONALLY QUALIFIED。2026-10-06；冻结模型 NONZERO_K_PE_v1、strategy0、fixed mesh、serial。27项 COMPLETE 门槛通过，限定于本轮算例与原冻结输入。

2. **Binary/source identity** — main fresh wclean/wmake，SHA 43facf56b8137bf658bb7c960718d186665160a3eb028b6f913204f3dfef2cd3 与 MC4_VALIDATED 相同；111-source manifest差异0、自定义库差异0。0 errors，3条既有TD1 warning原样，unexpected warnings=0；最终所有5组独立工具日志0 error/0 warning。

3. **Model tag** — 全部十micro和shock配置显式 mechanicalModel NONZERO_K_PE_v1；默认HISTORICAL_K0保持，未参与新模型资格。所有原生日志及restart-v2核验模型标签。

4. **Ten new-model microcases** — 原gas/liquid/mixed01/05/09/traceLiquid/Gas/contact/speciesContact/smooth全部fresh达到各自原定endTime，accepted R1 failure0、P2/species/conservation PASS。每case20cells，9×4步+smooth5步，共820accepted cell states/native+strict全通过、tolerance-only0。pure K0且缺相EOS query0。原TD1 growth减少总步数，不能套用旧脚本的>=10步假设；初次 verifier失败保留为测试工具条件错误，非solver失败。

| case | accepted steps | accepted cell states | native / strict | max source (1/s) |
|---|---:|---:|---|---:|
| gas | 4 | 80 | 80/80 | 0 |
| liquid | 4 | 80 | 80/80 | 0 |
| mixed01 | 4 | 80 | 80/80 | 0 |
| mixed05 | 4 | 80 | 80/80 | 0 |
| mixed09 | 4 | 80 | 80/80 | 0 |
| traceLiquid | 4 | 80 | 80/80 | 0 |
| traceGas | 4 | 80 | 80/80 | 0 |
| contact | 4 | 80 | 80/80 | 9.60478e-14 |
| speciesContact | 4 | 80 | 80/80 | 2.83167e-15 |
| smooth | 5 | 100 | 100/100 | 2.16581e-14 |

5. **Fresh TD1 A-I** — A–I 9/9、64-evaluation exhaustion、determinism fresh PASS。策略测试的非单调口袋/强制拒绝仍是原设计的synthetic predicates，nativePolicy每个回调同时执行新模型混合相source-active native raw/post trial，共112次；新cPE/source bound来自活动源码，没有把历史K0 PASS复用。另actual driver pure-gas新模型31步growth验证：22增长/8 capped、factor2/time monotone。source-active compression控制K=-.099600043580469144，theta=-1.0000216410531948、Ktheta=.099602199030310479；alpha/rhoG/rhoL/p/TG/TL/cPE均按设计上升，见compression_direction.json。strategy tests、native trial伴随验证、actual driver/fixture验证三者分别记录，不宣称synthetic口袋是物理EOS口袋。

6. **Temporal historical fixtures** — 234/235/236/SR1/EOS2/EOS3_pre分别用原Q/P2、新cPE/K源重新advance，两次运行verdict、dt、time、committed/old bits deterministic，合法time advance PASS。失败保持exact rollback的harness合同保留；几组旧Q仍接受microstep，不要求dt等于K0，也不据孤立旧fixture推断fresh动态轨迹效率失败。

| fixture | accepted dt (s) | rejected candidates | contract |
|---|---:|---:|---|
| 234 | 1.2054350545350129e-06 | 0 | PASS / deterministic / rollback exact |
| 235 | 1.2054427043809506e-06 | 0 | PASS / deterministic / rollback exact |
| 236 | 3.9704575563720455e-18 | 0 | PASS / deterministic / rollback exact |
| sr1 | 3.4541297952698358e-20 | 0 | PASS / deterministic / rollback exact |
| eos2 | 1.1887441605610328e-19 | 0 | PASS / deterministic / rollback exact |
| eos3_pre | 1.6684241909487512e-19 | 0 | PASS / deterministic / rollback exact |

7. **Shock input hashes** — 原shockInterface_100的mesh/initial fields/initial exact Q/P2/numerics/controlDict/endTime逐文件fresh SHA一致；仅constant/fiveEqBootstrap中K 0;替换为显式新模型选择。没有更改snapshotEvery10、startup deltaT、endTime、CFL或driver；shock_input_hash_gate.json给出每个before/after SHA及唯一授权delta。

8. **Shock replay status** — 原生 MC4 SHA binary从原exact freshInitial(time0/step0/lastDt0)开始，normal exit0；不是从K0 step32252 restart。initial-v1历史EOS标签仅按已冻结fresh-fixture读取合同使用，active EOS仍v3。完整原生journal/result/温度诊断和所有快照位于cases/shockInterface_100。

9. **Reached endTime?** — YES。最后t=0.00055000000000000003 s，原配置endTime=.00055000000000000003 s，same binary64。serial shock prerequisite CLOSED；不升级多维/正式high-Mach/ALE/shock convergence资格。

10. **Accepted steps** — 431。原生每步td1_steps和accepted_steps完整；只读重放每步dt/time与原生位级相同，全部原生43份中间快照4300单元Q1..Q9/P2位级相同，最终restart committed/old/time/dt/step位级相同。每步完整状态由冻结相同driver确定性重放审计，未声称原生每一步都直接存了独立全量快照。

11. **Requested rejects** — 0。当前shock从初始到endTime全程requested valid；旧fixture有recoverable rejection的单独记录，未将它们当作模型fatal。

12. **Retry count** — 0（shock）。

13. **Rescue count** — 0（shock）。fresh策略nonmonotone rescue及预算耗尽unit separately PASS。

14. **Candidate evaluations** — 431（shock），每accepted step一个request candidate。policy/native工具额外评估不混入原生shock统计。

15. **Median accepted dt** — 1.2310470277178835e-06 s；旧K0 fixed final10000 baseline约2.6532922558e-19 s。

16. **Median freshCap** — 1.2310470277178835e-06 s；每步physicalJoint/acoustic/endCap/growth/requested/selected均保留。K0 baseline median freshCap约1.2050935080e-6 s，只用于历史比较。

17. **Accepted/fresh ratio** — median=1；所有shock selected使用fresh cPE wave和原source positivity合同，没有dt floor。

18. **Physical advance/1000** — 全程实际431步推进0.00055000000000000003 s；按实际431步平均换算1000-step equivalent=0.0012761020881670534 s。因为431步已到endTime，没有再运行额外步数；此值是归一化效率率，不是观察到的额外1000步轨迹。

19. **Efficiency vs K0** — 对固定baseline 3.7506347854e-16 s/1000，换算改善3402362963022.9619倍，超过100×要求。MICROSTEP COLLAPSE ELIMINATED；accepted均O(1e-6)。不改growthFactor/rescue budget/CFL/EOS/R1/source bound。

20. **Minimum dt** — 1.2050921343033297e-06 s；没有persistent 1e-18 trap。

21. **Minimum dt/ULP** — 12836140285043；t=0的subnormal ULP比例更大，不决定minimum。每步selectedOverULP原生long-double诊断保存；ULP仅指导搜索，无force-nextafter commit。

22. **Time monotonicity** — 431/431 tNew>tOld，strict binary64检查通过，无相等时间、无限微步强制提交或时钟repair。

23. **Strict-root statistics** — 接受trajectory 43100/43100 native、43100/43100 strict；mixed strict按独立EOS共同压力端点Flo<=0/Fhi>=0，pure按对应native Euler恢复（不存在mixed root bracket）。最小mixed raw energy root margin=3530739.3283463521，各步limiting cell记录。纯相不存在的mixed margin以inf/NA标记，不制造缺相查询。

24. **Tolerance-only statistics** — 0/43100。没有persistent tolerance-only committed region、dynamic boundary pinning或ROOT_BOUNDARY_RECURRENCE_BLOCKER。MC4 exact-Tmin contact表示区别仍是历史事实，此次原shock液体约300K，并不授予所有exact-Tmin contact strict资格。

25. **Min/max TL** — accepted液体TL=[299.98521928650257,300.39445274719304] K，HARD265–400内。low/high-temperature原生监视保留，无域拓展或clamp。

26. **K/source statistics** — K=[-0.88677731619142053,0]；responseL/G各在[0,1]。source KdivU=[-0.10818662601153305,95.247767846118379] 1/s，实际动态活动明确；最小.95 alpha total-DD bound=1.5264500367842193e-05 s，alpha-bound limiting hits=0。source按anchor K^n/cPE记录，无clip/false guard reject。constant-U contact source数值残余最大9.604780971919689e-14 1/s（speciesContact2.8316735048838283e-15），是原binary64波速舍入残余；不称其位级等于零，也未新增容差。其积分贡献与path identity已在原冻结path预算核验。smooth也是constant-U transported profile，source极小；显著compression方向另由native source-active控制验证。

27. **cPE/acoustic statistics** — active faces cPE=[148.91796037104547,1244.7181068584089] m/s；read-only old cA=[558.65594894602043,1244.7181068584089]，仅独立audit old-recovery诊断，未参与driver。每步acoustic limiting cell/cap记录，KT_ap/am波速在RH ledger保存。

28. **P2** — exact Q0/fraction authority、payload、signed minority和PRESENT preservation逐cell检查，mismatch=0、unexpected PRESENT->ABSENT=0。ABSENT允许正常transport成PRESENT，trace未阈值删除。诊断traceFaces使用只读1e-12分类标签，不用于模型/更新/phase删除。

29. **Species** — N-1 independent+dependent residual closure不变；max closure=1.7114656090540555e-16，无normalize；所有accepted species非负。

30. **Conservation** — 原periodic unit-area integral gate max=1.2471400989692542e-15<原1e-11；mG/mL/Mx/My/Mz/Et/independent species均通过，原生result分量完整。K只fraction；raw Q1..Q8逐位=原conservative flux trial，Q9只用原N-1闭合；无repair。alpha是nonconservative：累计transport=-0.00069961349439395261，K-source=0.00069479673168525873，实际积分变化=-4.8167627086835319e-06，每步分解residual max=1.0304989899835253e-17。不误报alpha积分守恒。

31. **Runtime path guards** — 原生driver431步×100faces推导43100 guard calls，每face17路径节点位置，合计732700（节点某相ABSENT时依合同不查询该EOS）。这些是由已核验driver loop/接受步数推导，不是添加runtime计数器。模型/域/branch guard rejects0；pure-face=1364、absent-coordinate inheritance-face=100、trace-face=5125；audited guarded faces另在gate标记，不混入原生derived count。guard处理的missing-coordinate只路径继承，不制造committed缺相状态。

32. **Runtime path/RH ledger** — 每步最大|Δp|的face（明确确定性major-wave selector）记录+ x/unit-area/fixed mesh、IK/IaK、alpha残差、RH1..9、局部K/cPE与KT_ap/am。RH中speed是冻结路径uStar=phiPhysStar单位面积值，是ledger参考界面速度，不宣称它是拟合实际shock propagation speed；残差非零保留，不按任意两态RH=0判PASS。actual frozen path/source身份K max error=1.1102230246251565e-16，response max=8.6736173798840355e-19，冻结rel1e-10/abs1e-14内。未要求grid-converged shock path或entropy资格。

33. **First blocker** — NONE。最初micro >=10步 verifier、harness目标名称/环境路径及独立工具编译缺项已修正，仅涉及MC5测试工具；没有活动源码修改、solver blocker或现场模型修复。旧fixture microdt合法且不是freshshock recurrence。

34. **Executable/library hashes** — exe 43facf56b8137bf658bb7c960718d186665160a3eb028b6f913204f3dfef2cd3；LiquidEOS.so 1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888；FiveEqThermo.so f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896。所有115 installed libraries与MC4 validated baseline完全一致。

35. **Source hashes** — 111-source manifest SHA=8c663c6566205fe4e7eb3e9b0c0a0e661173b212c27e9cac07a1fab8b9feab4b；全部逐文件零delta，MC4 validated ZIP hash仍28ddcca296a27d508d0a2ec65c18f6eb4f16845fe659d0bca9b15b3431429009。模型SHA=be2e3d414dcfffd7a9ae498fa14f4a4f8de934b60c5c87f78a696bdf041b5270；frozen budget SHA=c6377d653599a24903440b119a8d5e9ea0541ea88db96d0bc40ad8803309d12b。测试工具属于独立fitting证据目录，未更改active算法。

36. **EOS/R1 hashes** — 111 manifest证明R1数学/source不改；v3 GibbsPotentialLiquidEOS.H 421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d；coefficients 610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac；energy_reference ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef；metadata 9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6。HARD p.05–12MPa/T265–400、81coefficients、CL369229.9537234281冻结。

37. **TD1 hashes** — contract d415b10f2b1eb67e77e1c0062950b2afeaf7033ca9491592edc1d0ec0af1fba1；policy a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062；growth/search/budget/rescue/rollback算法不变。

38. **Foundation hashes** — 6717 Foundation source和19 native parcel source逐SHA -c全OK；exact hash lists/closing baseline SHA保留，115 libraries unchanged，所有旧K0 evidence保持原样。

39. **MC5 COMPLETE?** — YES，27/27 COMPLETE gate PASS。NONZERO-K SERIAL OPERATIONALLY QUALIFIED，范围为本轮serial输入/strategy0模型合同。

40. **TD1 COMPLETE?** — YES。fresh A-I+budget64、historical fixtures、full original new-model shock到endTime、accepted time monotone、efficiency及无temporal blocker全部通过；SERIAL TEMPORAL ROBUSTNESS QUALIFIED FOR NONZERO_K_PE_v1。历史K0 TD1停止日志/报告不覆盖。

41. **DYN-CLOSURE authorized?** — MC5/TD1前置门槛已满足；NEXT ROUND ONLY / NOT EXECUTED。本轮无DYN-CLOSURE动作。

42. **Restart status** — 新模型restart-v2 fresh100-cell state write/read bit-exact、new under K0 REJECT、K0-tag under new REJECT。K0-tag artifact仅故意构造的模型拒绝control，不是K0 dynamic qualification。production restart remains NOT CERTIFIED。

43. **M6B.1/M6B status** — 均PARTIAL；仍需将来独立授权的DYN-CLOSURE完整wave/high-Mach等门槛；未自动启用high-order new K、ALE、正式high-Mach、MPI active、M6B.2/DPM/T4-S3/production。

44. **Milestone matrix** — MC3 COMPLETE/DESIGN FROZEN；MC4A COMPLETE；MC4 COMPLETE/MICRO-QUALIFIED；MC5 COMPLETE/NONZERO-K SERIAL OPERATIONALLY QUALIFIED；TD1 COMPLETE/FOR NONZERO_K_PE_v1；serial shock prerequisite CLOSED；EOS3 COMPLETE/FROZEN；DYN-CLOSURE NEXT ROUND ONLY/NOT EXECUTED；M6B.1/M6B PARTIAL；production restart NOT CERTIFIED。STOP。

证据目录：fitting/integration/m6b1_mc5_nonzero_k_serial_qualification_v1/。

验证检查点：D:/DATA/Solver/checkpoints/M6B1_MC5_VALIDATED_v1.zip（封存后seal_validated.json与SHA侧文件记录最终哈希）。
