# OF7 newborn identity audit v1

Date: 2026-10-04. Scope: selected isolated C2/K1/N1 parcel graph; no active solver integration.

## Native source authority

Local Foundation root: `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7`.

| Source | Verified semantics |
|---|---|
| src/lagrangian/basic/particle/particle.C:511–560 | Ordinary component/position construction sets origProc to Pstream::myProcNo() and origId to getNewParticleID(). |
| particle.C:563–592 | Both copy constructors preserve origProc/origId; no allocation. |
| particleI.H:111–121 | getNewParticleID() returns rank-local particleCount_++ (overflow warning); no global allocator. |
| particleIO.C stream constructor | Reads existing identity from native stream; does not allocate a newborn identity. |
| src/lagrangian/intermediate/parcels/Templates/SprayParcel/SprayParcel.C KH child branch | Copies parent, then assigns only child origId from native allocator. Inherited origProc remains the parent's birth rank. |
| Cloud::move and particle prepare/correctAfterParallelTransfer | Native ownership transfer/stream/iNew/coupled geometry remains authoritative; migration does not mean birth. |

## Mechanism

After a rank0-born parent migrates to rank1, copying it for a physical KH child retains origProc=0. Native rank1 allocation starts at local ID 0. Assigning only origId produces (0,0), colliding with the migrated parent. The complete pair is the identity: equal origId on distinct origProc is legal.

## Selected creation-site classification

| Site | Meaning | Action |
|---|---|---|
| C2 ExceptionSafeConeInjection.H:104 new parcelType(mesh,pos,celli) | Injection birth, ordinary native constructor | Unchanged. |
| C2 parcel/LazySprayParcel.C:295–298 | Real KH child, guarded before adoption | Invoke versioned native birth identity adapter once. |
| Lazy*Parcel.H clone/copy overloads | Snapshot/reference copy | Preserve identity, unchanged. |
| Lazy*Parcel.H iNew(stream), C2 semantic read | Migration/semantic reconstruction | Preserve streamed identity, unchanged. |
| ReconstructedCloud and transactionState-v1 reconstruction | Trial/rollback/reference reconstruction | No birth adapter; unchanged. |
| Native ORourke | Collision mutation/coalescence/deletion | Unchanged; no redesign. |
| Selected surface-film model none | No additional configured physical birth path | No speculative change. |

## Minimal authorized patch

`dpmFiveEq/KHNewbornIdentityV1.H` assigns only:

```cpp
child.origProc() = Pstream::myProcNo();
child.origId() = child.getNewParticleID();
```

The existing guarded KH child-before-adoption site includes this header and replaces the old origId-only line with one call. No full calcBreakup or ReitzKHRT implementation was newly copied. Physical equations, support guard/order, child ownership, native transport, stream, Random and native allocator bodies remain unchanged. Existing migrating parent is never passed to this adapter. No global service, synchronization, packet, UUID, or renumber pass exists.

Shared source SHA delta is explicit in `shared_source_delta.json` and `shared_source.diff`. Frozen checkpoints and binaries are immutable. This source change is not presented as an unchanged historical hash.

## Evidence and limits

Single rank: 22 complete transaction-state encodings byte identical before/after;108 checks zero failures;92 births/92 identity negative checks and5694 later child queries; constructed/destroyed11562/live0. This covers direct/retry state, physical/history/source/RNG/allocator/output under the serial contract. It does not certify distributed accepted commit or allocator rollback.

Exact MPI input:69 dictionary/initial files byte identical. First completed stable boundary contains six unique pairs (0,0),(0,1),(1,0),(1,1),(1,2),(1,3). Parent migration and source-child transfer preserve their pair; destination children use rank1. Two native boundary events pass full stream/physical/history/geometry and prepare/correct RNG checks. These are first-step trial observations, not an accepted distributed transaction certificate.

Next native evolve still raises SIGFPE, exit136; address-to-symbol inspection identifies native ReitzKHRT::update, but optimized code does not resolve the arithmetic line. Old duplicate-to-SIGFPE causality is not proven. No clamp, parameter adjustment, signal catch, model change or further physical run follows. Status: PARTIAL / KH_SIGFPE_BLOCKER.
