# 1. M6A2.1 status

COMPLETE / STANDALONE / NOT ACTIVE. All22 required gates pass. User-approved exact singleton rule is recorded. No M6A2.2 or transport activation.

# 2. Gas thermo implementation audited

Actual Foundation OF7 hePsiThermo/reactingMixture/perfectGas/JANAF/sensibleInternalEnergy and actual dictionaries verified. Species order C10H22,O2,N2; Y=[0,0.228,0.772]. See FIVE_EQ_GAS_ENERGY_AUDIT.md.

# 3. Gas energy convention

eG=HE=Es=Hs-p/rho=Ha-Hc-Rmix*T; existing gas offset0. rhoE=rho*(e+|U|^2/2) preserved. At298.15K Hs=0 but Es=-Rmix*Tstd. No reaction/formation/source changes.

# 4. Gas evaluator API

evaluatePT,evaluateRhoP,recoverRhoE,pressureInterval,mixture. Queries use local OF7 value objects; no global psiReactionThermo/mixture field mutation.220 OF7 mixture-versus-species queries pass; maxabs energy discrepancy 1.862645149230957e-09 J/kg.

# 5. Gas beta derivation/check

betaG=Cv/(rho*Rmix). Frozen-composition finite-difference max relative 3.7895575566437856e-11. Cv(T,Y) uses actual JANAF coefficients, not a constant.

# 6. Gas sound-speed check

cG=sqrt((Cp/Cv)/psi), identical to actual active cc formula. Independent Cp/R mass-sum acoustic checks pass. gamma is not fixed1.4.

# 7. Liquid production EOS version/hash

ndecane_gibbs_v1 remains byte-identical. metadata SHA256 d76f2085d1d22b45f8ddfd9a44501bdb0a0b6fc9fbb475d6446420d02412fd7e. Coefficient SHA256 610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac. Domain and energy-reference files unchanged.

# 8. Liquid energy offset

C_L=369229.9537234281 J/kg, default frozen EOS inside adapter. Et liquid contribution always uses solver-shifted e. Native offset0 used only paired validation.

# 9. Liquid evaluator API

evaluatePT,evaluateRhoP,eL_solver,TL,cL,betaL,pFromRhoE,recoverRhoE,classifyRhoP,pressureInterval. All use frozen EOS; no CoolProp runtime.

# 10. Phase-presence policy

64epsilon alpha/relative-density diagnostics, absolute density tolerance0; exact absent branches only. Consistent nonzero traces remain MIXED, without mass deletion. Detection precedes m/alpha. See fiveEqThermo/README.md.

# 11. Conservative-state validity policy

Finite alpha in[0,1], finite nonnegative masses, finite positive total density, finite M/Et; zero-volume mass and significant disappearing-phase mass rejected. EOS energy intervals decide validity; negative sensible internal energy is not automatically invalid. tryRecover returns INVALID plus reason.

# 12. Pure-gas recovery

112 primary tests plus7 JANAF branch tests pass. Safeguarded variable-Cv energy inversion, strict100–6000K bounds; no liquid query. JANAF discontinuity gaps are not treated as roots.

# 13. Pure-liquid recovery

112 primary tests pass. Frozen rho/e inversion with production C_L; no gas query; cMix=cL.

# 14. Mixed pressure residual

R(p)=mG*eG(mG/alphaG,p,Y)+mL*eL_solver(mL/alphaL,p)-Eint, Eint=Et-|M|^2/(2*rhoMix). One p/U with independently varied TG/TL.

# 15. Pressure derivative

R'=mG*betaG+mL*betaL must be positive finite. Invalid derivative returns failure, never a Newton step.

# 16. Legal pressure interval

Intersection of own liquid HARD rho-p interval and gas JANAF interval. Negative width fails. Exact singleton accepted only by explicit user authorization, valid EOS and passing energy residual; wrong singleton energy is tested rejected. No expanded domain.

# 17. Root algorithm

Safeguarded Newton+bisection,100-iteration limit; endpoint checks and strict sign bracket. Default midpoint requires no history; provided1.02p and phase-energy-secant strategies compared. Invalid-domain trials use bracket fallback; invalid thermodynamic derivatives fail.

# 18. Root convergence statistics

Energy relative tolerance2e-12 with rhoMix*1e5 J/kg scale; pressure increment1e-4Pa+2e-11|p|. Maximum primary pressure error 7.931752770673484e-05 Pa; maximum normalized Et reconstruction 1.6830155430984055e-12. Primary roundtrips exercised 240 bisection steps.

# 19. Allaire cMix implementation

xi=rho*beta, w=m/rhoMix; cMix^2=(wG*xiG*cG^2+wL*xiL*cL^2)/(alphaG*xiG+alphaL*xiL). Positive finite numerator/denominator checked; K=0.

# 20. Pure-phase acoustic limits

PASS, direct cMix=cG or cL; absent EOS not queried, absent validity explicitly ABSENT.

# 21. Mixed roundtrip results

1456 primary mixed states PASS, all15 requested alpha values covered across pure/mixed groups;14 liquid PT states including inlet, NORMAL/BUFFER, four HARD corners/faces; TG400/800/1200/2000; Ux0/2013.039 with nonzero lateral components.9 additional mixed JANAF branch states pass.1680 primary total states; no CFD.

# 22. Contact-equilibrium recovery test

6 left/right algebraic recovery pairs PASS. Same p/U, changed alpha and intrinsic densities, unequal phase temperatures. This does not validate KT contact-flux preservation.

# 23. Alpha-pressure perturbation test

5 centered alpha perturbations at fixed conservative variables PASS; analytical dp/dalpha=-R_alpha/Rp using phase e_rho|p=-beta*dp_drho|e. Max relative discrepancy 1.600063714857214e-08. Alpha transport untouched.

# 24. Invalid-state tests

22 conservative rejection cases plus2 direct EOS-domain probes and structured INVALID-mode check PASS. Includes no common interval, no energy bracket, bad phase presence/composition, NaN/infinite data, singleton wrong energy, and invalid gas/liquid states.

# 25. Energy-offset invariance

PASS: production shifted versus native-zero convention tested with consistently adjusted Et. Pure phases do not call absent EOS.

# 26. Mixed reference-offset invariance

PASS: shifts -C_L and +123456.789 J/kg with Et+=mL*DeltaC at6 alpha values;12 paired tests. Maxabs dp 1.5972182154655457e-07 Pa. p,TG,TL,cMix invariant within frozen budgets.

# 27. C++ unit-test status

PASS; two standalone targets compile with Foundation OF7 wmake, C++11/O3/Wall/Wextra/Werror. Final logs clean. Tests report0 failures; extra120 stress states and initial-guess agreement pass.

# 28. Performance benchmark

| Group | N | Mean us | Median | P95 | P99 | Max | Mean iterations | P99 iterations | Fallback query fraction | Mean gas calls | Mean liquid calls | Mean residual calls |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| PURE_GAS | 180 | 0.798206 | 0.792 | 0.899 | 0.917 | 1.043 | 5.6 | 6 | 0 | 1 | 0 | 0 |
| MIXED_MIDPOINT | 972 | 5.90512 | 5.511 | 6.793 | 17.993 | 71.594 | 4.5 | 6 | 0.111111 | 8.5 | 11.5 | 7.5 |
| MIXED_PROVIDED_1.02p | 972 | 4.91983 | 4.798 | 5.658 | 6.135 | 79.661 | 3.61111 | 4 | 0 | 7.61111 | 10.6111 | 6.61111 |
| MIXED_ENERGY_SECANT | 972 | 5.41165 | 5.111 | 6.006 | 6.348 | 163.538 | 3.72222 | 5 | 0 | 7.72222 | 10.7222 | 6.72222 |
| PURE_LIQUID | 180 | 2.75025 | 2.9 | 4.495 | 4.529 | 5.361 | 0.733333 | 4 | 0 | 0 | 1 | 0 |

Warm standalone measurements include legal interval construction; no cold-cache/MPI/CFD cost claim. Mixed benchmark uses interior liquid PT states so endpoint roots do not dominate. Public-call counters include liquid bracket PT queries, not private polynomial calls. Exact samples and initial broad-envelope benchmark retained.

# 29. Thread/MPI safety

Readonly species/EOS and local value mixtures/counters; no global field writes or mutable static caches. Repeated identical inputs produce identical states/iteration policy. No native multithread/MPI execution test; architecture is prepared, distributed integration remains future work.

# 30. Added files

fiveEqThermo: fiveEqState.H, fiveEqStateRecovery.H/.C, fiveEqGasThermoEvaluator.H/.C, fiveEqLiquidThermoEvaluator.H/.C, fiveEqAcoustics.H, README.md. Standalone test/benchmark C++ and independent Make targets, logs/CSV/JSON, FIVE_EQ_GAS_ENERGY_AUDIT.md, this report and recordM6A21.py. Existing frozen liquid EOS untouched.

# 31. Active solver impact

NONE. All10 protected file hashes equal the previous baseline. No mG/mL transport, rho/rhoU/rhoE replacement, face flux, Kapila K, capillary force, DPM energy transfer or CFD. Accepted EOS remains NOT ACTIVE in solver.

# 32. Remaining blockers

No blocker for completed standalone M6A2.1. DPM state-dependent caloric discrepancy still blocks future DPM energy coupling/transfer ledger. Runtime recovery mapping, face-state admissibility/contact conservation and transport activation remain unimplemented. Thread/MPI integration and CFD are not validated.

# 33. M6A2.2 start condition

A separate user-authorized next-stage scope is required. Reuse frozen kernel contract, legal domains, gas energy convention and singleton policy; define its mapping/tests before runtime changes. This turn stops at M6A2.1.

# 34. Updated milestone matrix

| Stage | Status |
|---|---|
| M0–M4 | COMPLETE |
| M5A/M5B/M5B.1 | COMPLETE / REFERENCE AND DESIGN |
| M6A1a | COMPLETE |
| M6A1b-1 | SG REJECTED |
| M6A1b-2A/2B | COMPLETE |
| M6A2.1 | COMPLETE / STANDALONE / NOT ACTIVE |
| M6A2.2 | NOT EXECUTED |
| M5C/M6B | NOT STARTED |
| M7 | NOT STARTED |
| M8 | PARTIAL / EXISTING DPM |
| M9–M15 | NOT STARTED |

STOP. No M6A2.2/transport/CFD execution.
