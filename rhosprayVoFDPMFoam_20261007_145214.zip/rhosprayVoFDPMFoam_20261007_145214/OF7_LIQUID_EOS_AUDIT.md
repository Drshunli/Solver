# Foundation OpenFOAM 7 liquid EOS audit — M6A1

Local source root: `/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src/thermophysicalModels` (Ubuntu-22.04 WSL). This audit concerns **Foundation 7**, not OpenFOAM.com. No active solver equation was changed.

## Available equation-of-state implementations

The actual `specie/equationOfState` directories are `linear`, `Boussinesq`, `PengRobinsonGas`, `icoPolynomial`, `rhoConst`, `perfectGas`, `perfectFluid`, `adiabaticPerfectFluid`, and `incompressiblePerfectGas`. No `stiffenedGas` implementation is present there. Thermo policies under `specie/thermo` include `janaf`, `eConst`, `eRefConst`, `hConst`, `hRefConst`, `hPolynomial`, `hPower`, `sensibleInternalEnergy`, and related energy mappings. Those thermo policies do not supply a missing liquid pressure law by themselves.

| Class / local source | Density and derivative | Caloric / sound-speed assessment |
|---|---|---|
| `rhoConst`, `specie/equationOfState/rhoConst/rhoConstI.H` | `rho=rho_`; `psi=0` | `E=Cp=Cv=0` EOS contributions; no finite density-based acoustic speed. |
| `linear`, `.../linear/linearI.H` | `rho=rho0+psi*p`; `psi=psi_` | `H=log(rho)/psi`, `E=H-p/rho`, `Cp=Cv=0` EOS contributions. A separate thermal model and carefully defined energy reference would be needed. It has no stand-alone total-energy liquid closure or direct sound-speed API. |
| `adiabaticPerfectFluid`, `.../adiabaticPerfectFluid/adiabaticPerfectFluidI.H` | `rho=rho0*((p+B)/(p0+B))^(1/gamma)`; finite pressure derivative | `H` and `E` explicitly return zero with source comments that they still need implementation; `Cp=Cv=0`. This pressure law cannot close the requested total energy. |
| `perfectFluid`, `.../perfectFluid/perfectFluidI.H` | `rho=rho0+p/(R*T)`; `psi=1/(R*T)` | EOS `E=Cv=0`; `H`, `Cp`, `CpMCv` exist, but this class is not a calibrated C10H22 liquid acoustic/caloric model. |
| `Boussinesq`, `icoPolynomial`, `incompressiblePerfectGas` | Incompressible or temperature-only density closures | No suitable finite compressible-liquid `p-rho-e` relation for the selected five-equation total-energy model. |
| `perfectGas`, `PengRobinsonGas` | Gas-oriented EOS | Neither is a validated dense C10H22 liquid model for this case. |

The local `barotropicCompressibilityModel/{linear,Wallis,Chung}` classes are pressure-based mixture-compressibility models, not independent phase caloric EOSs. A Tait or other `p(rho)` relation without `e(rho,p)` cannot recover pressure from conserved energy.

## Current C10H22 spray properties

`thermophysicalProperties/liquidProperties/C10H22/C10H22I.H` delegates `rho`, `Cp`, `h`, `hl`, `mu`, `kappa`, and `sigma` to correlations. `C10H22.C` constructs the density correlation as `NSRDSfunc5`; `thermophysicalFunctions/NSRDSfunctions/NSRDSfunc5/NSRDSfunc5.H::f(scalar,scalar T)` ignores pressure. `liquidProperties/liquidProperties/liquidPropertiesI.H::psi` and `CpMCv` both return zero. Thus the database supports parcel/VOF transport and interfacial property queries, but contains no finite bulk modulus, liquid sound speed, `e(rho,p)` or pressure inversion. `hl` is the latent-heat correlation; it is not a caloric EOS.

The target M4 `rhosprayVoFMixture::correct()` still computes `rhoL` with `SLGThermo.liquids().rho(p,T,X)` using the **gas** temperature. This is a transitional property diagnostic, not the selected two-material liquid thermo. The separate experimental `src/rhosprayVoF/barotropicLiquidThermo` and stage3 `vofLiquidProperties` files have provisional values without a validated provenance for this target and were not promoted.

## Decision

Compile a local stiffened-gas *candidate interface* with complete analytic caloric and acoustic formulas. It is inactive until a calibrated C10H22 parameter set and energy reference are supplied. This avoids altering the Foundation installation or treating the existing spray database as a compressible EOS.
