# M8A.3A model dependency graph — Foundation 7 / adapter v1

Scope: selected serial `basicSprayCloud` at an accepted step boundary. The
carrier, mesh and global time epoch remain fixed during each trial call.
This graph is not a cloud/Q commit or MPI contract.

## Reconstruction graph

```mermaid
flowchart TD
  S[Native evolved cloud S] --> E[Read-only explicit state export]
  C[Same immutable configuration] --> T[Fresh trial basicSprayCloud]
  E --> I[Import counters, times, parcels, sources and properties]
  T --> I
  I --> R[Independent root Random value]
  R --> D[Fresh RosinRammler distribution]
  R --> X[Trial dispersion and collision]
  I --> P[Trial ordered parcel container]
  P --> O[Rebuilt trial occupancy]
  I --> F[Trial source fields and outputProperties]
  T --> M[Shared fixed mesh and carrier snapshot]
  T --> L[Shared read-only SLGThermo liquid tables]
  T --> V[Trial-local trajectory-integrated Theta]
```

## Immutable sharing whitelist

| Object | Allowed sharing and lifetime proof |
|---|---|
| fvMesh geometry, topology, patches, static constraints | Fixed mesh, constructed before either cloud and destroyed after both; no AMR/motion in this gate. |
| Carrier rho/U/T/p and turbulence inputs | Read-only during a trial epoch; no PDE solve or turbulence correction. Native interpolation objects are freshly constructed for trial tracking. |
| SLGThermo and its liquidMixtureProperties | Registry object constructed before clouds, outlives them; liquid constitutive functions are const/read-only. ORourke fresh constructor resolves registry `SLGThermo`, not a committed parcel/composition object. |
| Mathematical/model constants | Read-only; configuration dictionaries/Function1 objects are freshly constructed, not retained from evolved mutable outputProperties. |
| Time/registry reference | Shared environment, read-only within each call; only the harness advances time between accepted steps. Not an independent asynchronous time/mesh contract. |

Unknown references are not whitelisted. A changed carrier/configuration/model
set requires a new audit. Trial operation is serial and exclusive because OF7
particleCount_ is process-global; this gate does not make it thread-local.

## Member ownership inventory

Every group below includes inherited members. `IMMUTABLE_SHARED` also denotes
read-only model configuration which this implementation conservatively creates
as separate values. No mutable properties dictionary is whitelisted.

| Model/base | Members / nested object | Classification | Resolution |
|---|---|---|---|
| CloudSubModelBase | owner_ | TRIAL_REBOUND_REFERENCE | Fresh configuration constructor receives trial owner. |
| subModelBase | properties_ | TRIAL_REBOUND_REFERENCE | Fresh base constructor binds trial outputProperties dictionary subobject. IOdictionary object address and dictionary subobject address must not be confused. |
| subModelBase | modelName_, baseName_, modelType_, dict_, coeffDict_ | IMMUTABLE_SHARED | Configuration value construction; no evolved-reference clone used in trial graph. |
| cone / InjectionModel | SOI_, volumeTotal_, massTotal_, massFlowRate_, parcelBasis_, nParticleFixed_ | IMMUTABLE_SHARED | Same config and time conversion, fresh TimeFunction1 objects. |
| cone / InjectionModel | massInjected_, nInjections_, parcelsAddedTotal_, time0_, timeStep0_ | MUTABLE_COPIED_STATE | Exact export/import using a real derived read-only copy bridge, including hidden timing state. |
| cone | injectionMethod_, flowType_, position_, positionIsConstant_, direction_, duration_, parcelsPerSecond_, flowRateProfile_, thetaInner_, thetaOuter_, dInner_, dOuter_, Umag_, Cd_, Pinj_ | IMMUTABLE_SHARED | Rebuilt from the selected configuration; no physics formula change. |
| cone | injectorCell_, injectorTetFace_, injectorTetPt_ | DERIVED_REBUILDABLE | Native constructor/updateMesh finds same position/tet on fixed mesh. Native future-path position/velocity equality verifies this. |
| cone | sizeDistribution_ -> RosinRammler | TRIAL_REBOUND_REFERENCE | Fresh distribution constructed by native cone config constructor. Distribution rndGen_ refers to trial root RNG. |
| RosinRammler | minValue_, maxValue_, d_, n_, distributionModelDict_ | IMMUTABLE_SHARED | Read-only coefficients, no sample history apart from root RNG. |
| distributionModel | rndGen_ | TRIAL_REBOUND_REFERENCE | Sampling advances trial RNG; historical injector counterexample is repeated on reconstructed trial. |
| sphere / ParticleForce | owner_, mesh_ | TRIAL_REBOUND_REFERENCE / IMMUTABLE_SHARED | Fresh force with trial owner and fixed mesh. |
| sphere / ParticleForce | coeffs_ | IMMUTABLE_SHARED | Native sphere constructor uses readCoeffs=false; no model history exists. Formula receives parcel and tracking inputs, writes trial parcel/source through caller. |
| dispersion / DispersionRASModel | kPtr_, epsilonPtr_, ownK_, ownEpsilon_ | DERIVED_REBUILDABLE | Reacquire from fixed turbulence input; native cacheFields owns/deletes temporary fields independently. Non-owning pointers refer only to whitelisted read-only carrier fields. |
| stochasticDispersionRAS | owner().rndGen(), UTurb/tTurb parameters | TRIAL_REBOUND_REFERENCE / MUTABLE_COPIED_STATE | Root RNG copied completely; parcel UTurb/tTurb copied with full parcel state. No separate model random history. |
| blobsSheetAtomization | B_, angle_; AtomizationModel base has no state members beyond CloudSubModelBase | IMMUTABLE_SHARED | Fresh values; d/liquidCore/tc history lives in copied parcels; Random& argument is trial root RNG. |
| ReitzKHRT | b0_, b1_, cTau_, cRT_, msLimit_, weberLimit_ | IMMUTABLE_SHARED | Fresh config. |
| BreakupModel | solveOscillationEq_, y0_, yDot0_, TABComega_, TABCmu_, TABtwoWeCrit_ | IMMUTABLE_SHARED | Fresh config; d/tc/ms/nParticle/KHindex/y/yDot and child history live in parcels. Child commit/discard remains outside this gate. |
| ORourke | liquids_, coalescence_ | IMMUTABLE_SHARED | Fresh model resolves long-lived registry SLGThermo; switch from config. |
| ORourke | local occupancy / pInCell pair list | DERIVED_REBUILDABLE | Native collide builds ordered lists from trial owner container every call; never references committed parcels. |
| ORourke | owner RNG / mutable pair parcels | TRIAL_REBOUND_REFERENCE | Fresh owner, independent parcel container, independent RNG. |
| rebound / StandardWallInteraction | interactionType_, e_, mu_; PatchInteraction base model identity | IMMUTABLE_SHARED | Same rebound config, fresh constructor. |
| rebound | nEscape_, massEscape_, nStick_, massStick_ | MUTABLE_COPIED_STATE | Protected counters exported/imported using a real derived value bridge. OutputProperties dictionary imported independently as well. |
| rebound | patchData -> p/mesh/carrier boundary | TRIAL_REBOUND_REFERENCE / IMMUTABLE_SHARED | Trial disposable parcel actual tracking to wall; native patchData/rebound path exercised, fixed mesh/velocity boundary shared. |
| voidFraction | thetaPtr_ | OUTPUT_ONLY | Fresh trial-local registered trialCloudTheta; preEvolve reset, postMove residence integral, postEvolve normalization remain native. Previous-step diagnostic is not imported as physics history. |
| CloudFunctionObject | outputDir_ | OUTPUT_ONLY | Fresh namespaced path value; actual VoidFraction virtual write is suppressed while trial scope is active. |
| adapter instrumentation | calls/moves/randomCalls | OUTPUT_ONLY | Trial-local evidence counters, no effect on physics; not authoritative state imported from reference. |

## Cloud-level dependencies

| Object | Classification / handling |
|---|---|
| root Random x_, scalarNormalStored_, scalarNormalValue_ | MUTABLE_COPIED_STATE: whole C++ value assignment. Sequence tests alternate uniform and normal on value copies; no seed reconstruction. |
| ordered full basicSprayParcel state | MUTABLE_COPIED_STATE: native parcel copy per element, no shallow container; serialization equality includes IDs and turbulence/breakup state. |
| cloudSolution | MUTABLE_COPIED_STATE: public value-copy constructor carries all private counters, switches and schemes. Assignment is deleted, so the derived trial cloud uses typed destructor + placement construction of its protected member, before any trial evolve. No raw bytes, offsets, const-casts or ref patching. Reconstruction failure destroys the trial; no commit occurs. |
| outputProperties | MUTABLE_COPIED_STATE: assign dictionary value only; trial IOobject name/registration remains independent. |
| pAmbient | MUTABLE_COPIED_STATE: explicit public value import; averageParcelMass is deterministic config-derived. |
| UTrans/UCoeff/hsTrans/hsCoeff/rhoTrans | MUTABLE_COPIED_STATE: frozen NativeDPMSourceSnapshot imports values into separately allocated namespaced fields. Radiation unsupported. |
| cloud occupancy | DERIVED_REBUILDABLE: ordered native rebuild; pointers differ, identities/order agree. |
| interpolation / integration objects | DERIVED_REBUILDABLE: fresh native constructors; no retained evolved cloud reference. Euler/analytical integration has no hidden mutable history here. |
| heat none / phase none / surfaceFilm none / singlePhaseMixture composition | Fresh trial-owned models; no enabled heat/phase/film physics history. Config and immutable SLG tables remain read-only. This audit does not add support for new enabled models. |
| private cloudCopyPtr_ at each template layer | Empty fresh trial; not a live storeState/restoreState transaction snapshot. |
| particleCount_ | Shared process-level allocator, explicitly checkpointed/restored by harness around trial calls. Shared mutable allocator is not claimed independent; exclusive serial control required. |

## Export bridge boundary

ConeAdapter/WallAdapter temporary export readers are actual derived instances
constructed by their native base public copy constructors. Their shallow
references are deliberately **not** eligible trial model graphs. They only
read protected values, never sample, evolve, info/write, or mutate properties.
The bridge dies before trial evolution. Fresh config construction and explicit
value import follow. No fake downcast to a derived layout is performed.

## Versioned API and capability

`ModelTransactionAdapter<Model>` has no generic fallback. Eight explicit v1
records expose constructTrial/exportMutableState/importMutableState/
verifyBindings/compareMutableState. Four physics stateless records return
NoModelHistory after this member audit; sphere does likewise. VoidFraction
exports no physical history under its frozen diagnostic-only classification.
Cone and wall export structured authoritative history. Parcel/root RNG/source/
properties/cloudSolution transfer is a separate cloud-level contract.

Unknown model types/counts or enabled radiation reject construction. These
adapters are compiled only in the passive harness. Ordinary model methods
forward to Foundation 7 implementations unchanged; additional counters are
output-only. Capability verdict is recorded after A/B/C and frozen regressions
in M8A3A_EVOLVED_INDEPENDENCE_GATE.md. No FULL TRANSACTION-SAFE claim is made.

Native source provenance: fitting/dpm/m8a3a_v1/native_sources; the same
installed Foundation 7 headers/libraries compile the harness.
