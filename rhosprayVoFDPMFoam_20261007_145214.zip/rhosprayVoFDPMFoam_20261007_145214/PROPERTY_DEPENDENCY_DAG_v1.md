# PROPERTY_DEPENDENCY_DAG_v1 — audit, not runtime activation

```mermaid
flowchart TD
  Q[Committed Q/P2 + boundary authority + generation] --> S[Actual native cell/tet/barycentric stencil]
  S --> G[Requirement-aware gas support preflight]
  G --> B[rhoG TG YG common p/common U as required]
  B --> C[Native Cp mu kappa]
  C --> Ts[Surface Ts TRatio rhoS muS kappaS Pr]
  Ts --> R[Re / drag / heat transfer / phase change]
  B --> SC[Carrier source corrections]
  C --> SC
  SC --> R
  PL[Parcel local T Y rho d U and revisions] --> L[Liquid Cp rho mu sigma pv]
  B --> L
  PL --> Ts
  L --> R
  Geo[Geometry patch data] --> W[Native rebound]
  W --> I[Invalidate pose/tet/stencil-dependent token]
  I --> S
```

Actual current native constructor has the forbidden bypass `cloud thermo -> global Cp/kappa -> trackingData` before S/G. This document specifies the dependency contract, does not claim it is implemented. Native sources: [ThermoParcelTrackingDataI.H:35](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/lagrangian/intermediate/parcels/Templates/ThermoParcel/ThermoParcelTrackingDataI.H:35), [heThermo.C:315](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/thermophysicalModels/basic/heThermo/heThermo.C:315), [heThermo.C:730](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t3br2a_final_v1/native_sources/thermophysicalModels/basic/heThermo/heThermo.C:730).

## Property and correction equations from native code

`Ts=(2 Tp+Tc)/3`, `TRatio=Tc/Ts`, `rhoS=rhoc TRatio`, `muS=muInterp/TRatio`, `kappaS=kappaInterp/TRatio`, `Pr=max(rootVSmall,Cpc muS/kappaS)`. Native TMin/Pr limiting remains native physics and is not a way to repair absent gas.

Thermo correction: `Uc += UTrans/massCell`, `Tc += hsTrans/(CpMean massCell)` with `CpMean=CpInterp.psi()[cell]`. Reacting correction: accumulated rhoTrans gives addedMass; changes rhoc and Uc, obtains species CpEff at pc/Tc, reads raw cell Cpc, updates Cpc/Tc. When accumulated transfer is negligible it returns without those corrections. Bird surface correction, if active, reads carrier Y/Wi and species mu/kappa/Cp; this bypasses a simple interpolation-only guard.

## Classification

* Parcel-local independent inputs: its stored T/Y/d/U, liquid material coefficients, geometry, liquid-only property evaluation when all p/T inputs are parcel-local and valid.
* Liquid properties in native Spray.calc are evaluated at `td.pc()` and parcel T/Y: liquid category, with carrier-dependent input acquisition. Do not relabel liquid rhoL as rhoG.
* Ts/Tav and derived gas surface properties depend on Tc/pc and must be behind support.
* Re requires carrier rho/U/mu; full Thermo/Reacting/Spray path requires more than isolated force kernel.
* Geometry-only native wall handling and voidFraction do not need Cp/kappa/Y. After movement/rebound the next carrier query must preflight native current topology again.
* Source correction is a carrier-dependent scratch TD operation before source/model updates. It is not a license to create alphaG in pure liquid.

The born SprayCloud initialization accesses common pressure directly before parcel setCellValues. Thermo T0/Cp0 and Reacting parcel YMixture0 are local population initialization, not gas carrier Y. Liquid Cp/rho/sigma/mu at physically valid common p and parcel-local T/Y can use a separate common-state interface; they do not intrinsically require gas presence. The current stock field/accessor ownership provides no support-aware common-state interface, and this round does not invent one.
* Carrier packet cache depends on generation/cell/tet/stencil/requirements. Surface-derived cache also depends on parcel local T/Y/U/d revisions; collision and child events may invalidate it even if gas packet support is unchanged.

## Eight-model stage requirements (static audit only)

| Event | Independent stage | Support/materialization stage | Mutation stage |
|---|---|---|---|
| coneInjection | geometry/time/RNG/bookkeeping | before carrier-dependent born initialization; pAmbient/parcel.rho dependencies also audited | parcel properties/allocator/injection counters: trial-local |
| sphereDrag | parcel mass/rho/d | isolated force rho/U/mu; full chain additionally surface T/Cp/kappa and p | velocity/source integrator |
| stochasticDispersionRAS | RAS k/epsilon metadata, native RNG state | current Uc, topology, valid RAS context | UTurb/tTurb/RNG |
| blobsSheetAtomization | liquid properties/age/core/diameter | rho/T/p average carrier quantities | atomization state |
| ReitzKHRT | local breakup state/child allocation | rho/T/p/mu/U; child first native force/dispersion requires its own token | child/diameter/mass/source state |
| ORourke | pair parcels/liquid composition/RNG | shared pressure and liquid properties; no fabricated gas required for pair bookkeeping | native collision survivor/local state; next carrier query freshly validated |
| rebound | patch geometry/velocity | no eager gas thermal properties; gate next segment | native velocity; invalidate topology token |
| voidFraction | volume/cell/trajectory/time | carrier-independent | output/function trajectory accumulator |

All eight full-chain bridge results remain NOT RUN/BLOCKED. Original native ORourke behavior and known cleanup limitations are unchanged.
