# M6B0_ACTIVE_AUTHORITY_AUDIT_v1

## Scope and exclusive dispatch

实际 rhosprayVoFDPMFoam executable，实际 fvMesh 和 Time，入口 `-serialFiveEq`。只认证固定、等距、单位截面积一维周期 chain。主入口在 createTime/createDynamicFvMesh 后直接 return runSerialFiveEq；return 位于旧 createControls/createFields/cloud/interface 创建之前。未选择该选项时 legacy reference 分支仍存在，但本轮没有运行，绝不在同一 active step 与 fiveEq 同时执行。

Active不调用旧 rhoEqn/rhoUEqn/rhoEEqn/rhoYEqn/alphaEqn、fvm/fvc second conservation、PIMPLE/PISO/pEqn，也不创建旧 global thermo/cloud/turbulence/interface。DPM/ST 字典 guard 必须 false，K 必须0，verificationOnly 必须 true。所有测试不包含 sprayCloudProperties/global thermophysicalProperties/interfaceProperties 而能正常运行，佐证没有这些对象依赖。

## Sole Q/P2 authority and transaction

TemporalState.committed 的 P2、q[1:10] 是唯一 accepted authority。20个 registered volFields 是 accepted mirror，不被第二套 PDE 更新。driver 在候选 copy 上执行原封冻结 reconstruction→face R1→Allaire→shared KT waves/flux→joint dt→trial→recovery→accept。N2=mG-mY_C10H22-mY_O2 residual 后整批复核，随后 active commit、Time 更新、整批 primitive publication。无部分 field publication，无 normalize/clip。

冻结 explicitTrial 内普通 q[0] 的中间 alpha 运算结果会被 PrecisionOperator::trial 的 P2 authoritative 更新覆盖；它不是另一个可提交的 alpha PDE。P2 从 DD fraction difference 经 advanced() 更新，不从 rounded alpha 重建。fresh 初始化用精确位串，保留 -0。

## Geometry/ALE

对实际 mesh 验证 N−1 内部 x 向单位面积面、相邻拓扑、等距 cells、V=dx、两个 cyclic 端面相互配对、横向 empty，然后才用冻结 periodic driver 的 Sf=(1,0,0)。因此真实物理 volume 与冻结 driver volume 一致，没有隐藏缩放。横向空方向在1D reduction中消去。其他几何拒绝，非通用2D/3D认证。

冻结 face(meshPhi)/KT ALE API 未改；本轮 fixed mesh默认 Umesh=0。质量/动量仍是相对对流，energy保留 absolute p-work，alpha保留physical divU。移动网格/GCL没有运行或认证。

## Read-only R1 counting and pure/trace state

GNU linker --wrap 观察原 fiveEqPrecisionRecovery::recover，调用 __real_，不改 options/Q/P2/root/EOS。原有可选 progress Snapshot 只用于失败计数；返回结果/异常原样传回。所有跨 translation-unit R1 调用含 initial/limiter probes/face/candidate/accepted 被计数；publication另外计数。本轮所有失败含 probes=0。没有故意执行新的 failed candidate replay，拒绝算法沿用冻结M5C.3。

生成器仅查询真实存在相；纯气liquidQueries=0，纯液gasQueries=0，两种1e-20trace正质量/signedP2均保留。没有fake相。restart输出用原fiveEqRestart-v1/P2-v1；本轮active adapter拒绝startTime!=0，不读alpha-only restart；production restart未认证。

## Ownership

| Field / state | Owner | Created / updated | Meaning |
|---|---|---|---|
| P2 | TemporalState.committed[i].fraction | exact P2Bits fresh input; frozen advanced() | signed binary64 minority; +0 pure gas / -0 pure liquid |
| mG / mL | q[1/2] | frozen shared KT candidate and whole commit | phase partial densities |
| M | q[3:6] | same transaction | mixture momentum density |
| Et | q[6] | same transaction | mG eG+mL eL+0.5 rhoMix U² |
| mY_C10H22 / mY_O2 | q[7/8] | shared species flux | N-1 independent species |
| mY_N2 | q[9] | algebraic residual, then revalidate | mG-mY_C10H22-mY_O2; no normalization |
| q[0] / alphaL | P2 decoded mirror | frozen P2 trial / accepted publication | not a second alpha authority |
| alphaG | P2.gasValue() | accepted publication | not 1-rounded alphaL; preserves trace gas |
| rhoG / rhoL | frozen R1 | whole accepted-state recovery | absent phase output=0, no fake phase |
| rhoMix / U / p / TG / TL / YG_* | accepted Q/recovery | publish only after all recoveries succeed | derived, no independent PDE |
| 20 volScalar/VectorFields | runSerialFiveEq | register once, lookup owner checks | OpenFOAM output mirrors of accepted Q |
| old rho / rhoU / rhoE / phi | isolated legacy branch | not created by serialFiveEq | frozen historical reference |

## Source impact

30,618个前序冻结条目已核对。仅授权主入口、Make/files/options、5项root target生成编译文件及本轮milestone追加允许变化，逐项before/after SHA记录在frozen_delta_audit.json；不是对冻结library源码的例外。恢复/EOS/P2/KT/reconstruction/integration/DPM C/H源文件全部unchanged。compiled_project_source_manifest.json记录72个当前编译project依赖并保留源文件副本；Foundation6717/nativeparcel19哈希重新通过。300/300_2D/原rhosprayFoam共132文件unchanged。

同一binary仍链接legacy DPM/ST依赖，不声称未链接；前置return与active源码和无cloud配置成功运行，证明本轮不执行、不发布其源项。不运行production、MPI、restart、喷口或T4-S3。
