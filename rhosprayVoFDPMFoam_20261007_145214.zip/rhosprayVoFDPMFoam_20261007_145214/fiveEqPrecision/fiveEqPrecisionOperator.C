#include "fiveEqPrecisionOperator.H"
#include "fiveEqScaledRatio.H"
#include "fiveEqScaledAcoustics.H"
#include <algorithm>
namespace fiveEq {
fiveEqRecoveredState PrecisionOperator::recover(const PrecisionCell& c)const {
 if(c.representationV2){
  using namespace scaledV2;for(unsigned j:{3u,4u,5u,6u})if(!std::isfinite(c.q[j]))throw RecoveryError("NONFINITE_MATERIAL");
  if(c.fraction.mode()!=FractionMode::P2Scaled||c.mass(1).sign()<0||c.mass(2).sign()<0)throw RecoveryError("INVALID_SCALED_MASS");
  for(unsigned j:{7u,8u,9u})if(c.mass(j).sign()<0)throw RecoveryError("NEGATIVE_SCALED_SPECIES");
  if(c.mass(1).exactZero()&&(!c.mass(7).exactZero()||!c.mass(8).exactZero()))throw RecoveryError("SCALED_SPECIES_WITHOUT_GAS");
  fiveEqConservativeState s;s.alphaL=c.fraction.liquidValue();s.mG=rationalDoubleView(c.mass(1),power(0)).value;s.mL=rationalDoubleView(c.mass(2),power(0)).value;s.M={{c.q[3],c.q[4],c.q[5]}};s.Et=c.q[6];
  if(c.fraction.gasPresent()){s.YG.resize(3);for(unsigned k=0;k<3;++k)s.YG[k]=rationalDoubleView(c.mass(7+canonical_[k]),c.mass(1)).value;}
  RecoveryAuthority a{c.mass(1),c.mass(2)};return recovery_.recoverWithAuthority(s,c.fraction,{},nullptr,&a);
 }
 const auto& q=c.q;for(double v:q)if(!std::isfinite(v))throw RecoveryError("NONFINITE_MATERIAL");
 if(q[1]<0||q[2]<0||q[1]+q[2]<=0){throw RecoveryError("INVALID_MASS");}double sum=0;for(unsigned i=7;i<10;++i){if(q[i]<0)throw RecoveryError("NEGATIVE_SPECIES");sum+=q[i];}
 if((q[1]==0&&sum!=0)||(q[1]>0&&std::abs(sum-q[1])/q[1]>1e-12))throw RecoveryError("SPECIES_CLOSURE");
 fiveEqConservativeState s;s.alphaL=c.fraction.liquidValue();s.mG=q[1];s.mL=q[2];s.M={{q[3],q[4],q[5]}};s.Et=q[6];
 if(q[1]>0){s.YG.resize(3);for(unsigned k=0;k<3;++k)s.YG[k]=q[7+canonical_[k]]/q[1];}
 return recovery_.recover(s,c.fraction);
}
PrecisionFace PrecisionOperator::face(const PrecisionCell& L,const PrecisionCell& R,double mesh,KTScheme scheme)const {
 if(L.representationV2!=R.representationV2)throw RecoveryError("MIXED_REPRESENTATION_FACE");
 PrecisionFace z;z.left=L.fraction;z.right=R.fraction;auto& f=z.flux;auto ls=recover(L),rs=recover(R);f.left.thermo=ls;f.right.thermo=rs;
 f.left.U=Foam::vector(ls.U[0],ls.U[1],ls.U[2]);f.right.U=Foam::vector(rs.U[0],rs.U[1],rs.U[2]);
 f.wave=ktWaveSpeeds(f.left.U,f.right.U,ls.cMix,rs.cMix,Foam::vector(1,0,0),mesh,scheme);const auto& w=f.wave;double ps=w.aPos*ls.p+w.aNeg*rs.p;
 if(usesNonzeroK(model())){
  if(mesh!=0||scheme!=KTScheme::Kurganov)throw RecoveryError("MC4_FIXED_MESH_KURGANOV_ONLY");
  auto state=[&](const PrecisionCell& c){fiveEqConservativeState q;q.alphaL=c.fraction.liquidValue();q.mG=c.q[1];q.mL=c.q[2];if(c.fraction.gasPresent()){q.YG.resize(3);for(unsigned k=0;k<3;++k)q.YG[k]=c.representationV2?scaledV2::rationalDoubleView(c.mass(7+canonical_[k]),c.mass(1)).value:c.q[7+canonical_[k]]/q.mG;}return q;};
  recovery_.guardPath(state(L),ls,L.fraction,state(R),rs,R.fraction);
  if(!L.representationV2)z.path=threeLegPath(ls,rs,w.phiPhysStar);
  else {using namespace scaledV2;z.path.uStar=w.phiPhysStar;auto rhoL=L.mass(1);rhoL.add(L.mass(2));auto rhoR=R.mass(1);rhoR.add(R.mass(2));auto kl=scaledAcoustics(ls,L.fraction,rhoL).K,kr=scaledAcoustics(rs,R.fraction,rhoR).K;
   auto left=kl.exact(),right=kr.exact(),al=L.fraction.liquidExact(),ar=R.fraction.liquidExact();al.add(left);ar.add(right);SparseExponentAccumulator dl,dr;dl.add(w.phiPhysStar-ls.U[0]);dr.add(rs.U[0]-w.phiPhysStar);left=left.multiplied(dl);right=right.multiplied(dr);al=al.multiplied(dl);ar=ar.multiplied(dr);
   z.path.leftK=rationalDoubleView(left,power(0)).value;z.path.rightK=rationalDoubleView(right,power(0)).value;z.path.leftAK=rationalDoubleView(al,power(0)).value;z.path.rightAK=rationalDoubleView(ar,power(0)).value;left.add(right);al.add(ar);z.path.IK=rationalDoubleView(left,power(0)).value;z.path.IaK=rationalDoubleView(al,power(0)).value;
  }
 }
 f.mGPhi=w.Aplus*L.q[1]+w.Aminus*R.q[1];f.mLPhi=w.Aplus*L.q[2]+w.Aminus*R.q[2];f.momentumPhi=w.Aplus*Foam::vector(L.q[3],L.q[4],L.q[5])+w.Aminus*Foam::vector(R.q[3],R.q[4],R.q[5])+ps*Foam::vector(1,0,0);
 f.energyPhi=w.Aplus*(L.q[6]+ls.p)+w.Aminus*(R.q[6]+rs.p)+w.aSf*ls.p-w.aSf*rs.p+mesh*ps;
 f.alphaPhiCandidate=w.Aplus*L.fraction.liquidValue()+w.Aminus*R.fraction.liquidValue();f.speciesPhi=Foam::scalarField(3,0);
 for(unsigned j=0;j<2;++j){f.speciesPhi[j]=w.Aplus*L.q[7+j]+w.Aminus*R.q[7+j];}f.speciesPhi[2]=f.mGPhi-(f.speciesPhi[0]+f.speciesPhi[1]);
 if(L.representationV2){using namespace scaledV2;z.representationV2=true;SparseExponentAccumulator ap,am;ap.add(w.Aplus);am.add(w.Aminus);for(unsigned k=0;k<4;++k){unsigned j=k<2?k+1:k+5;auto n=L.mass(j).multiplied(ap);n.add(R.mass(j).multiplied(am));z.authorityFlux[k]=ScaledDD::rounded(n);}f.mGPhi=z.authorityFlux[0].toDoubleView().value;f.mLPhi=z.authorityFlux[1].toDoubleView().value;f.speciesPhi[0]=z.authorityFlux[2].toDoubleView().value;f.speciesPhi[1]=z.authorityFlux[3].toDoubleView().value;auto dep=z.authorityFlux[0].exact();dep.add(z.authorityFlux[2].exact(),-1);dep.add(z.authorityFlux[3].exact(),-1);f.speciesPhi[2]=rationalDoubleView(dep,power(0)).value;}
 f.status=FaceFluxStatus::OK;return z;
}
static DD fractionNumerator(const PrecisionCell& c,const PrecisionFace& L,const PrecisionFace& R){
 auto n=ddAdd(ddScale(fractionDifference(L.left,c.fraction),L.flux.wave.Aplus),ddScale(fractionDifference(L.right,c.fraction),L.flux.wave.Aminus));
 n=ddSub(n,ddScale(fractionDifference(R.left,c.fraction),R.flux.wave.Aplus));return ddSub(n,ddScale(fractionDifference(R.right,c.fraction),R.flux.wave.Aminus));
}
PrecisionCell PrecisionOperator::trial(const PrecisionCell& c,double V,double dt,const PrecisionFace& L,const PrecisionFace& R,double ml,double mr)const {
 if(c.representationV2){using namespace scaledV2;if(ml!=0||mr!=0||!L.representationV2||!R.representationV2)throw RecoveryError("SCALED_STRATEGY0_FIXED_MESH_ONLY");if(dt==0)return c;auto t=c;SparseExponentAccumulator factor;factor.add(dt/V);
  for(unsigned j:{3u,4u,5u,6u}){double net=j==6?R.flux.energyPhi-L.flux.energyPhi:R.flux.momentumPhi[j-3]-L.flux.momentumPhi[j-3];t.q[j]=std::fma(-dt/V,net,c.q[j]);}
  for(unsigned k=0;k<4;++k){auto n=L.authorityFlux[k].exact();n.add(R.authorityFlux[k].exact(),-1);t.authority[k]=c.authority[k].updated(n.multiplied(factor));}
  t.fraction=c.fraction.advancedScaled(totalFractionNumeratorScaled(c,L,R).multiplied(factor));t.refreshViews();return t;
 }
 if(dt==0){return c;}auto q=explicitTrial(c.q,V,dt,L.flux,R.flux,ml,mr);PrecisionCell t=c;t.q=q.q;
 auto n=totalFractionNumerator(c,L,R);t.fraction=c.fraction.advanced(ddScale(n,dt/q.volume));t.q[0]=t.fraction.liquidValue();return t;
}
DD PrecisionOperator::totalFractionNumerator(const PrecisionCell& c,const PrecisionFace& L,const PrecisionFace& R)const {
 if(c.representationV2)throw RecoveryError("SCALED_AUTHORITY_INVALID_DD_NUMERATOR_CONSUMER");
 auto n=fractionNumerator(c,L,R);
 if(usesNonzeroK(model())){const double K=pressureEquilibriumAcoustics(recover(c)).K;
  n=ddAdd(n,ddScale(ddSub({R.flux.wave.phiPhysStar,0},{L.flux.wave.phiPhysStar,0}),K));}
 return n;
}
scaledV2::SparseExponentAccumulator PrecisionOperator::totalFractionNumeratorScaled(const PrecisionCell& c,const PrecisionFace& L,const PrecisionFace& R)const {
 using namespace scaledV2;if(!c.representationV2)throw RecoveryError("NOT_P2_SCALED_V2");SparseExponentAccumulator n;
 auto add=[&](const PrecisionFraction& f,double w,int sign){auto d=f.liquidExact();d.add(c.fraction.liquidExact(),-1);SparseExponentAccumulator a;a.add(w);n.add(d.multiplied(a),sign);};
 add(L.left,L.flux.wave.Aplus,1);add(L.right,L.flux.wave.Aminus,1);add(R.left,R.flux.wave.Aplus,-1);add(R.right,R.flux.wave.Aminus,-1);
 if(usesNonzeroK(model())){auto rho=c.mass(1);rho.add(c.mass(2));auto K=scaledAcoustics(recover(c),c.fraction,rho).K;SparseExponentAccumulator div;div.add(R.flux.wave.phiPhysStar);div.add(-L.flux.wave.phiPhysStar);n.add(K.exact().multiplied(div));}return n;
}
double PrecisionOperator::jointBound(const PrecisionCell& c,double V,const PrecisionFace& L,const PrecisionFace& R,double ml,double mr)const {
 if(c.representationV2){using namespace scaledV2;if(ml!=0||mr!=0)throw RecoveryError("SCALED_STRATEGY0_FIXED_MESH_ONLY");auto n=totalFractionNumeratorScaled(c,L,R);SparseExponentAccumulator vol;vol.add(V);double cap=acousticBound(c,V,L,R);
  auto bound=[&](const SparseExponentAccumulator& amount,const SparseExponentAccumulator& outgoing){if(outgoing.sign()<=0)return;double d=rationalDoubleView(amount.multiplied(vol),outgoing).value;cap=std::min(cap,.95*d);};
  bound(c.fraction.liquidExact(),n.negated());bound(c.fraction.gasExact(),n);
  for(unsigned k=0;k<4;++k){unsigned j=k<2?k+1:k+5;auto out=R.authorityFlux[k].exact();out.add(L.authorityFlux[k].exact(),-1);bound(c.mass(j),out);}
  auto out=R.authorityFlux[0].exact();out.add(L.authorityFlux[0].exact(),-1);for(unsigned k=2;k<4;++k){out.add(R.authorityFlux[k].exact(),-1);out.add(L.authorityFlux[k].exact());}bound(c.mass(9),out);return cap;
 }
 auto b=explicitTimeStepBounds(c.q,V,L.flux,R.flux,ml,mr);double n=ddValue(totalFractionNumerator(c,L,R)),D=mr-ml;
 auto bound=[](double x,double out){return positivePhaseTimeRatio(x,out);};
 double a=std::min(bound(c.fraction.liquidValue()*V,-c.fraction.liquidValue()*D-n),bound(c.fraction.gasValue()*V,n-c.fraction.gasValue()*D));
 return std::min({b.acoustic,.95*a,.95*b.mG,.95*b.mL,.95*b.species,.95*b.volume});
}
double PrecisionOperator::connectedDt(const PrecisionCell& c,double V,double dt,const PrecisionFace& L,const PrecisionFace& R,double ml,double mr)const {
 if(!(dt>0)){return 0;}auto valid=[&](double x){try{recover(trial(c,V,x*dt,L,R,ml,mr));return true;}catch(const std::exception&){return false;}};
 if(!valid(0)){return 0;}double lo=0,hi=1;bool exit=false;for(unsigned j=1;j<=32;++j){double x=double(j)/32;if(!valid(x)){hi=x;exit=true;break;}lo=x;}
 if(exit){for(unsigned j=0;j<52;++j){double x=lo+(hi-lo)/2;if(x==lo||x==hi)break;if(valid(x))lo=x;else hi=x;}}return lo*dt;
}
}
