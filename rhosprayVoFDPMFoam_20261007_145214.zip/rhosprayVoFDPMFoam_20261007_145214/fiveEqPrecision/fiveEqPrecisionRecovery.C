#include "fiveEqPrecisionRecovery.H"
#include "fiveEqScaledRatio.H"
#include "fiveEqScaledAcoustics.H"
#include <algorithm>
#include <cmath>
namespace fiveEq {
fiveEqConservativeState fiveEqPrecisionRecovery::generate(double a,double p,double TG,double TL,const std::array<double,3>& U,const std::vector<double>& Y) const {
    if(!std::isfinite(a)||a<0||a>1)throw RecoveryError("INVALID_GENERATOR_ALPHA");
    fiveEqConservativeState q;q.alphaL=a;q.YG=Y;double internal=0;
    if(a<1){auto g=gas_.evaluatePT(p,TG,Y);q.mG=(1-a)*g.rho;internal+=q.mG*g.e;}
    if(a>0){auto l=liquid_.evaluatePT(p,TL);q.mL=a*l.rho;internal+=q.mL*l.e;}
    const double r=q.mG+q.mL;double v2=0;
    for(unsigned j=0;j<3;++j){if(!std::isfinite(U[j]))throw RecoveryError("INVALID_GENERATOR_U");q.M[j]=r*U[j];v2+=U[j]*U[j];}
    q.Et=internal+0.5*r*v2;return q;
}
fiveEqRecoveredState fiveEqPrecisionRecovery::recover(const fiveEqConservativeState& q,const PrecisionFraction& fraction,const RecoveryOptions& o,fiveEqRecoveredState* progress) const {return recoverWithAuthority(q,fraction,o,progress,nullptr);}
fiveEqRecoveredState fiveEqPrecisionRecovery::recoverWithAuthority(const fiveEqConservativeState& q,const PrecisionFraction& fraction,const RecoveryOptions& o,fiveEqRecoveredState* progress,const RecoveryAuthority* authority) const {
    if(!std::isfinite(q.alphaL)||q.alphaL<0||q.alphaL>1||!std::isfinite(q.mG)||!std::isfinite(q.mL)||q.mG<0||q.mL<0||!std::isfinite(q.Et))throw RecoveryError("INVALID_CONSERVATIVE_STATE");
    fiveEqRecoveredState s;s.alphaL=fraction.liquidValue();s.alphaG=fraction.gasValue();s.mG=q.mG;s.mL=q.mL;s.rhoMix=q.mG+q.mL;
    scaledV2::SparseExponentAccumulator totalMass;
    if(authority){totalMass=authority->gasMass;totalMass.add(authority->liquidMass);s.rhoMix=scaledV2::rationalDoubleView(totalMass,scaledV2::power(0)).value;}
    auto intrinsic=[&](bool gas){if(authority)return scaledV2::rationalDoubleView(gas?authority->gasMass:authority->liquidMass,gas?fraction.gasExact():fraction.liquidExact()).value;return phaseIntrinsicRatio(gas?q.mG:q.mL,gas?s.alphaG:s.alphaL);};
    auto weighted=[&](double g,double l,double subtract=0){if(!authority)return q.mG*g+q.mL*l-subtract;scaledV2::SparseExponentAccumulator G,L;G.add(g);L.add(l);auto n=authority->gasMass.multiplied(G);n.add(authority->liquidMass.multiplied(L));n.add(-subtract);return scaledV2::rationalDoubleView(n,scaledV2::power(0)).value;};
    // Query-local snapshot on success or exception; does not alter root mathematics.
    struct Snapshot { fiveEqRecoveredState* dst; fiveEqRecoveredState& src;
        ~Snapshot(){if(dst)*dst=src;}
    } snapshot={progress,s};
    if(!(s.rhoMix>0&&std::isfinite(s.rhoMix)))throw RecoveryError("INVALID_TOTAL_DENSITY");
    if(!(o.pressureAbsTol>0&&o.pressureRelTol>0&&o.energyRelativeTol>0&&o.energyScalePerMass>0&&o.maxIterations>0))throw RecoveryError("INVALID_RECOVERY_OPTIONS");
    double kin=0;for(unsigned j=0;j<3;++j){if(!std::isfinite(q.M[j]))throw RecoveryError("INVALID_MOMENTUM");s.U[j]=q.M[j]/s.rhoMix;kin+=0.5*q.M[j]*s.U[j];}
    const double internal=q.Et-kin,scale=std::max(std::abs(internal),s.rhoMix*o.energyScalePerMass);
    if(!std::isfinite(internal)||!std::isfinite(scale))throw RecoveryError("INVALID_INTERNAL_ENERGY");
    // Presence BEFORE intrinsic-density divisions. Never discard trace mass.
    if(!(presence_.alphaPresenceTol>=0&&presence_.alphaPresenceTol<1&&presence_.massPresenceRelativeTol>=0&&presence_.massPresenceAbsoluteTol>=0))throw RecoveryError("INVALID_PHASE_PRESENCE_POLICY");
    // Contract v2: magnitude is diagnostic only; no phase deletion.
    auto presence=[&](bool gas,bool authoritativePresent,double alpha,double m,PhasePresence& state){
        state=PhasePresence::INCONSISTENT;
        if(authority){const auto& mass=gas?authority->gasMass:authority->liquidMass;if(!authoritativePresent){if(!mass.exactZero())throw RecoveryError("ABSENT_PHASE_HAS_MASS");state=PhasePresence::ABSENT;return false;}if(mass.sign()<=0)throw RecoveryError("PRESENT_PHASE_HAS_ZERO_OR_NEGATIVE_MASS");double rho=intrinsic(gas);if(!(std::isfinite(rho)&&rho>0))throw RecoveryError("PRESENT_PHASE_INVALID_INTRINSIC_DENSITY");state=alpha<=presence_.alphaPresenceTol?PhasePresence::TRACE_PRESENT:PhasePresence::PRESENT;return true;}
        if(!authoritativePresent){if(m!=0)throw RecoveryError("ABSENT_PHASE_HAS_MASS");state=PhasePresence::ABSENT;return false;}
        if(m==0)throw RecoveryError("PRESENT_PHASE_HAS_ZERO_MASS");
        const double rho=phaseIntrinsicRatio(m,alpha);
        if(!(std::isfinite(rho)&&rho>0))throw RecoveryError("PRESENT_PHASE_INVALID_INTRINSIC_DENSITY");
        state=alpha<=presence_.alphaPresenceTol?PhasePresence::TRACE_PRESENT:PhasePresence::PRESENT;
        return true;
    };
    bool pg=presence(true,fraction.gasPresent(),s.alphaG,q.mG,s.gasPresence),pl=presence(false,fraction.liquidPresent(),s.alphaL,q.mL,s.liquidPresence);
    auto putGas=[&](const GasState& g){s.p=g.p;s.rhoG=g.rho;s.TG=g.T;s.eG=g.e;s.cG=g.c;s.betaG=g.beta;s.gasValidity="VALID_JANAF";};
    auto putLiquid=[&](const liquidEOS::LiquidEOSState& l){s.p=l.p;s.rhoL=l.rho;s.TL=l.T;s.eL=l.e;s.cL=l.c;s.betaL=l.beta;s.liquidValidity=l.validity==liquidEOS::EOSValidity::NORMAL?"NORMAL":"BUFFER";};
    if(pg&&!pl){
        s.recoveryMode=RecoveryMode::PURE_GAS;++s.calls.gas;
        auto g=gas_.recoverRhoE(q.mG,internal/q.mG,q.YG);putGas(g);s.rhoG=q.mG;s.iterations=g.iterations;
        auto bracket=gas_.pressureInterval(q.mG,q.YG);s.bracketMin=bracket[0];s.bracketMax=bracket[1];
    }else if(pl&&!pg){
        s.recoveryMode=RecoveryMode::PURE_LIQUID;++s.calls.liquid;
        auto l=liquid_.recoverRhoE(q.mL,internal/q.mL);putLiquid(l);s.rhoL=q.mL;s.iterations=l.pressureIterations;
        // Pure liquid adapter performs its own strict bracket search.
        s.diagnosticFlags="PURE_LIQUID_FROZEN_EOS_BRACKET";
    }else{
        s.recoveryMode=RecoveryMode::MIXED;s.rhoG=intrinsic(true);s.rhoL=intrinsic(false);
        const double rg=s.rhoG,rl=s.rhoL;
        ++s.calls.gas;
        std::array<double,2> bg,bl;
        try{bg=gas_.pressureInterval(rg,q.YG);}catch(...){s.gasPresence=PhasePresence::INCONSISTENT;throw;}
        try{bl=liquid_.pressureInterval(rl,&s.calls.liquid);}catch(...){s.liquidPresence=PhasePresence::INCONSISTENT;throw;}
        double lo=std::max(bg[0],bl[0]),hi=std::min(bg[1],bl[1]);
        s.bracketMin=lo;s.bracketMax=hi;
        if(lo>hi)throw RecoveryError("NO_COMMON_VALID_PRESSURE_INTERVAL");
        // User-authorized exception: exact legal singleton, never a fuzzy interval.
        if(lo==hi)s.diagnosticFlags="EXACT_LEGAL_SINGLETON";
        auto residual=[&](double p){
            ++s.calls.residual;++s.calls.gas;++s.calls.liquid;
            const auto g=gas_.evaluateRhoP(rg,p,q.YG);const auto l=liquid_.evaluateRhoP(rl,p);
            putGas(g);putLiquid(l);s.rhoG=rg;s.rhoL=rl;
            const double f=weighted(g.e,l.e,internal),df=weighted(g.beta,l.beta);
            s.energyResidual=f;s.normalizedEnergyResidual=std::abs(f)/scale;
            if(!std::isfinite(f)||!std::isfinite(df)||df<=0)throw RecoveryError("INVALID_THERMODYNAMIC_ROOT_DERIVATIVE");
            return std::array<double,2>{{f,df}};
        };
        auto left=residual(lo),right=residual(hi);const double etol=o.energyRelativeTol*scale;
        bool done=false;double p=(lo+hi)/2,last=hi-lo;
        if(std::abs(left[0])<=etol){p=lo;done=true;}
        else if(std::abs(right[0])<=etol){p=hi;done=true;}
        else if(!(left[0]<0&&right[0]>0))throw RecoveryError("NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN");
        if(!done){
            if(o.initialGuess==InitialGuess::PROVIDED&&std::isfinite(o.knownPressure)&&o.knownPressure>lo&&o.knownPressure<hi)p=o.knownPressure;
            if(o.initialGuess==InitialGuess::ENERGY_SECANT){
                // Energy-weighted endpoint estimate, not a gas/liquid pressure average.
                p=lo+(hi-lo)*(-left[0])/(right[0]-left[0]);
                if(!(p>lo&&p<hi))p=(lo+hi)/2;
            }
            for(unsigned n=1;n<=o.maxIterations;++n){
                std::array<double,2> f;
                try{f=residual(p);}catch(const liquidEOS::EOSQueryError& e){
                    if(std::string(e.what()).find("INVALID")==std::string::npos)throw;
                    p=(lo+hi)/2;++s.calls.fallback;f=residual(p);
                }catch(const RecoveryError& e){
                    if(std::string(e.what())!="INVALID_GAS_PT")throw;
                    p=(lo+hi)/2;++s.calls.fallback;f=residual(p);
                }
                s.iterations=n;double correction=f[0]/f[1];
                const double ptol=o.pressureAbsTol+o.pressureRelTol*std::abs(p);
                // Both energy and the implied Newton pressure increment must pass.
                if(std::abs(f[0])<=etol&&(std::abs(last)<=ptol||std::abs(correction)<=ptol)){done=true;s.pressureIncrement=std::abs(correction);break;}
                if(f[0]<0)lo=p;else hi=p;
                double next=p-correction;
                // Also safeguard excessive steps to exercise/bracket contraction.
                if(!(next>lo&&next<hi)||!std::isfinite(next)||std::abs(next-p)>.75*(hi-lo)){next=(lo+hi)/2;++s.calls.fallback;}
                last=next-p;p=next;
            }
        }
        if(!done)throw RecoveryError("PRESSURE_ROOT_NOT_CONVERGED_OR_JANAF_GAP");
        residual(p); // fresh state, never reuse stale endpoint/iterate properties.
    }
    s.cMix=authority?scaledAcoustics(s,fraction,totalMass).c:(usesNonzeroK(model_)?pressureEquilibriumAcoustics(s).c:allaireSoundSpeed(s));
    const double reconstructed=q.mG*s.eG+q.mL*s.eL+kin;
    s.energyResidual=authority?weighted(s.eG,s.eL,q.Et-kin):reconstructed-q.Et;s.normalizedEnergyResidual=std::abs(s.energyResidual)/scale;
    if(!(std::isfinite(s.p)&&s.p>0&&std::isfinite(s.cMix)&&s.cMix>0&&s.normalizedEnergyResidual<=4*o.energyRelativeTol))throw RecoveryError("RECOVERED_STATE_VALIDATION_FAILED");
    return s;
}
void fiveEqPrecisionRecovery::guardPath(const fiveEqConservativeState& qL,const fiveEqRecoveredState& L,const PrecisionFraction& fL,const fiveEqConservativeState& qR,const fiveEqRecoveredState& R,const PrecisionFraction& fR) const {
    const bool pg=fL.gasPresent()||fR.gasPresent(),pl=fL.liquidPresent()||fR.liquidPresent();
    const double TGL=fL.gasPresent()?L.TG:R.TG,TGR=fR.gasPresent()?R.TG:L.TG;
    const double TLL=fL.liquidPresent()?L.TL:R.TL,TLR=fR.liquidPresent()?R.TL:L.TL;
    const auto& YL=fL.gasPresent()?qL.YG:qR.YG;const auto& YR=fR.gasPresent()?qR.YG:qL.YG;
    if(pg){const auto ml=gas_.mixture(YL),mr=gas_.mixture(YR);
        if((TGL<ml.Tcommon())!=(TGR<mr.Tcommon()))throw RecoveryError("PATH_THERMO_BRANCH_OR_DOMAIN_BLOCKER");
        for(unsigned k=0;k<YL.size();++k)if(YL[k]>0||YR[k]>0){const double split=gas_.speciesData()[k].Tcommon();
            if((TGL<split)!=(TGR<split))throw RecoveryError("PATH_THERMO_BRANCH_OR_DOMAIN_BLOCKER");}}
    // Convex p/T/composition path, with inherited missing coordinates only here.
    // Native evaluations certify queried path nodes; no endpoint state is reset.
    for(unsigned i=0;i<=16;++i){const double t=double(i)/16,p=(1-t)*L.p+t*R.p;
        auto f=fL;
        if(i==16)f=fR;else if(fL.mode()==FractionMode::P2Scaled){auto d=fR.liquidExact();d.add(fL.liquidExact(),-1);scaledV2::SparseExponentAccumulator T;T.add(t);f=fL.advancedScaled(d.multiplied(T));}else f=fL.advanced(ddScale(fractionDifference(fR,fL),t));
        if(pg&&f.gasPresent()){std::vector<double> Y(YL.size());for(unsigned k=0;k<Y.size();++k)Y[k]=(1-t)*YL[k]+t*YR[k];gas_.evaluatePT(p,(1-t)*TGL+t*TGR,Y);}
        if(pl&&f.liquidPresent())liquid_.evaluatePT(p,(1-t)*TLL+t*TLR);
    }
}
double fiveEqPrecisionRecovery::dpDalpha(const fiveEqRecoveredState& s) const {
    if(s.recoveryMode!=RecoveryMode::MIXED)throw RecoveryError("ALPHA_DERIVATIVE_REQUIRES_TWO_PHASES");
    const double egRho=-s.betaG*s.p/s.rhoG;
    const double elRho=-s.betaL*(s.cL*s.cL-s.p/(s.rhoL*s.rhoL*s.betaL));
    const double ra=s.mG*egRho*s.rhoG/s.alphaG-s.mL*elRho*s.rhoL/s.alphaL;
    return -ra/(s.mG*s.betaG+s.mL*s.betaL);
}
}
