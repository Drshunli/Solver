# M6A1b-2A alternative C10H22 EOS architecture decision

## Current authority — M6A1b-2A.3 (2026-09-30)

Overall **M6A1b-2A COMPLETE as a project domain/policy design gate**. Expected
physical screening is 0.188330–6.201421 MPa / 299.440696–301.200448 K;
approved PRODUCTION is **0.10–8 MPa / 295–305 K**; project HARD is
**0.05–12 MPa / 285–320 K**, absolute pressure and inclusive boundaries.
These design support limits do not predict guaranteed CFD extrema.
The former 0.180–6.250 MPa / 299–302 K proposal is historical and superseded.
See [current assessment](M6A1B2A3_ENVELOPE_HARDENING.md) and
[domain/failure policy](EOS_OUT_OF_DOMAIN_POLICY.md); the machine-readable
authority is `fitting/liquid_eos_domain_contract.json`.
M6A1b-2B is NEXT / NOT STARTED. Production model selection, final reference
training/holdout generation and solver energy-offset alignment remain open.
No active solver or CFD case changes were made.

## Historical audit (superseded status statements below)


## Decision state

**Reference layer selected:** versioned, single-phase n-decane Helmholtz/reference-EOS data plus independent experiment ledger. **Runtime production EOS not selected:** the supplied gas condition gives approximately Ma 5.02, the earlier Ma>7 objective remains unconfirmed, and liquid inlet p/T/U are missing; numerical adequacy and table size/cost cannot yet be judged. Keep a two-layer gate: first reference truth/calibration, then compare reduced NASG and Mie–Grüneisen against it and independent data; use a runtime table only if no reduced model passes all properties and derivatives. Constant-parameter SG is **REJECTED FINAL EOS**.

## Reference/Helmholtz table coordinates

The future cell state supplies `rhoL`; M6A2 tries `p`. Three layouts were compared:

| Coordinates | Access and inversion | Derivatives/monotonicity | Memory, MPI, phase and extrapolation |
|---|---|---|---|
| A1 `(rho,T)` | Natural for a Helmholtz potential and consistent `p,e,c`; `stateRhoP` solves a scalar `p(rho,T)=pTry` for T, repeated during pressure root. | Derivatives come most cleanly from the underlying Helmholtz potential; safeguarded monotone T brackets needed. | Rectangular sample array possible only with phase mask; each MPI rank can load the same immutable table. No out-of-domain extrapolation. |
| A2 `(rho,p)` | Direct hot-path `e,T,c,de/dp` interpolation for M6A2; `stateRhoE` solves for p. | Store or interpolate potential-consistent derivatives; naïve independent interpolation of e/c can violate Maxwell/acoustic identities. Verify `de/dp>0`, `dp/de>0` and pressure-root monotonicity. | Likely most convenient runtime cache/locality, but phase boundary is curved in `(rho,p)` and the valid mask may be sparse. Immutable replication per rank costs memory, not communication per lookup. |
| A3 `(p,T)` | Natural for reference-EOS export, inlet checks and plots; each M6A2 trial has known p but must invert `rho(p,T)=rhoL` for T. | Need monotone liquid rho–T branches and derivative transformation; near saturation/critical states may be ill-conditioned. | Convenient dense data generation, but a rectangular p–T grid must be masked for liquid validity. Per-rank immutable table; no silent out-of-range lookup. |

**Provisional design:** retain the native Helmholtz evaluator or `(rho,T)` as the thermodynamic truth; export a derivative-consistent, phase-masked `(rho,p)` **runtime candidate** only after envelope lock. Benchmark all three at the same error and call budget. Do not assume A2 is already the winner.

## Analytic candidates

| Model | Mechanical/acoustic capacity | Caloric/energy capacity | Runtime and adequacy risk |
|---|---|---|---|
| NASG | Co-volume `b` changes liquid density expansion and `c²=gamma(p+pInf)/[rho(1-rho b)]`, so it can give pressure-dependent sound speed at fixed T. Require `1-rho*b>0` and fit to rho/c/bulk modulus, including derivatives. | Constant-coefficient NASG retains constant `Cp` (its enthalpy is linear in T at fixed p); it likely fails the observed C10H22 Cp trend unless extended. An extension is a *new model* requiring full consistency. | Very cheap analytic `p(rho,e)`, `e(rho,p)`, T,c and derivatives; no automatic acceptance from extra `b`. [Primary NASG derivation](https://www.rs2n.eu/_files/ugd/67506f_e9f9e12c95b44daeada63dd11f01afb0.pdf). |
| Mie–Grüneisen type | Choose measured/reference cold curve `p_ref(rho),e_ref(rho)` and `Gamma(rho)`; `p=p_ref+Gamma*rho*(e-e_ref)` gives explicit `e(rho,p)` for nonzero Gamma. c follows the thermodynamic derivative formula in the interface contract. | Requires caloric reference `T(rho,e)`, heat-capacity curve and consistent `e_ref`; density/acoustic match alone is insufficient. | Moderate evaluation cost, but several empirical curves and derivative/phase limits need provenance. Prefer a liquid-relevant *reference isentrope/isotherm*, not an unjustified solid cold curve. |
| Tait pressure–density relation | Useful fit for `rho(p,T)`/bulk modulus. | **Disqualified alone**: no `e(rho,p)`, `de/dp`, T or unique energy reference. A thermodynamic potential or integrable caloric extension must be supplied and tested. | Extended Tait may be viable but then complexity and derivative cost must be measured against Mie–Grüneisen/table. |

The production comparison must report rho, c, `Ks=rho*c²`, e and h **differences on a common reference**, Cp/Cv, `de/dp|rho`, pressure monotonicity and acoustic derivative identity. It must include pure-liquid limit, M6A2 root convergence, `cMix` admissibility, total-energy consistency, inversion failures, evaluation cost, memory and interpolation error. Reference-grid fit residuals and independent experimental validation errors are separate reports; fitting a reduced EOS to a generated table and checking against the same table is *not independent validation*.

## Runtime frequency estimate for future 3D design

For `N` cells, `I` safeguarded pressure trials per cell and `F` faces, baseline `stateRhoP` evaluations are about `N*I` liquid calls per time step for pressure recovery (plus gas calls), followed by `O(N)` final-state/cMix calls and about `2F` reconstructed face-state/cMix calls; predictor/Runge–Kutta stages multiply these counts. A structured hexahedral mesh has roughly `F≈3N` interior faces, giving **`N(I+6+O(1))` liquid EOS calls per stage**, before any gradient/limiter reevaluation. Example `I=6` is a *cost illustration*, not a measured iteration count. If runtime table chosen: cache the cell's `(rho,p)` bracket, use local contiguous interpolation cells, precompute/store consistent first derivatives, use a bounded low-order monotone interpolant first, and benchmark cache/memory per MPI rank. Immutable replicated table requires no per-query MPI messages; initialization/reload still must be coordinated. No performance benchmark was run here.
