# M6B1-CRV3-1-ACTIVE-INTEGRATION-AND-JOINT-DT REPORT v1

2026-10-06。状态：**CRV3-1 COMPLETE，范围限均匀周期一维串行基础集成及联合时间步资格**。M6B.1 仍 PARTIAL；CRV3-2 已授权并立即继续。生产 CFD 未认证。

## 1. 依据与身份

本轮依据用户附件 0aee1c6b-0414-4e82-a760-6d29ca3971b3 的明确新要求，采用物理/守恒/热力学优先级；工程量 <=5%，目标 <=2%。旧 three-leg 是诊断参考，不再作为 CRV3 主线阻塞。

冻结推导：SP3 `KE_WORK_REGULARIZATION_DESIGN_v1.md` SHA256 `8360b37fb78063b72eb7aa16206d76f654a86f622b0ff19cdc4babd6009f709f`。此前 CRV1/CRV2 拒绝结论与封存记录不改写。

新模型 `NONZERO_K_PE_CRV3_v1`；定义见根目录 `NONZERO_K_PE_CRV3_MODEL_v1.md`。旧 `NONZERO_K_PE_v1` 可选，并已由新可执行文件运行 legacyMixed 验证。新旧 restart tag 双向交叉拒绝，P2 精确 round-trip 通过；生产重启仍未认证。

## 2. 源码变化

用户新授权允许修改 project-local 源码。本轮明确修改 6 个已有文件：model enum/tag、precision recovery 声速分支、operator 的非零 K 分支及 strategy、reconstruction 的 strategy 检查、serial caller。新增 `fiveEqCRV3Viscosity.H`、`fiveEqCRV3Temporal.H`。

`source_before/` 保存六文件原文；`source_before.json`、`source_after.json`、`baseline_delta.json` 保存哈希。旧冻结 111 项清单仅六个授权源文件变化，其余全部相同。没有修改 EOS、K 公式、原 TD1 policy/contract、历史预算及封存阶段。

## 3. 黏性动量、能量功与热力学

mu 为显式配置的动态黏性系数。隐式中点应力 tau=mu D(uMid)，总能量面通量采用同一 tau 与面中点速度乘积；没有额外经验热源。质量、alpha/P2、species 无黏性扩散。

离散恒等式 DeltaEt−DeltaKE=h mu/(2dx²)[(uMidR−uMidI)²+(uMidI−uMidL)²]>=0。周期面功及应力通量成对对消。每个黏性子步在运行时检查能量功恒等式、非负加热及固定分量不变。

J=sum_present(m beta)>0，熵生产 heat sum_present(m beta/T)/J>=0，允许 TG!=TL；缺失相不参与求和。已有 1344 个原生严格恢复与 30 个 90 位独立 phase-energy/work/heating 检查保留。原 30 项归一化残差最大 2.795e-12，满足原 1e-8 门槛；弱激波小全局熵跳的相对消减误差不被错误当作该局部预算。

扩展检查 336 组，N16/64、pureGas/pureLiquid/traceLiquid/traceGas/mixed01/05/09、TG800 与 TL300（热接触 TL290/310）、压缩与膨胀速度梯度、U=0/±3000、mu=0/.001/3/1000。原生/严格检查 53760/53760；ToleranceOnly=0。

局部熵生产最小 0，黏性加热最小 0；守恒最大 3.108624468950438e-14。P2、相质量、组分黏性子步按位保持；双曲更新保留 N−1 保守闭合。不 clip、不删除 trace、不 normalize species、不改 EOS、不 repair energy。

## 4. 联合时间步及 TD1

hyperbolic dt 来自原 cPE 面波界；alpha-source dt 采用实际 alpha+K 分子及两相空间；同时保留原质量、species、volume 上界。

L=diag(rho)^−1 mu/dx²(2I−S−Sᵀ)，lambdaMax<=4mu/(minrho dx²)。中点半步放大率 (1−dt lambda/4)/(1+dt lambda/4)，据此 dtCRV3=4/lambdaUpper；mu=0 时无限大。此界用于避免高频翻转，中点能量稳定性本身无条件成立，未用经验黏性 CFL 替代推导。

dt=min(原联合界,dtCRV3,dtEnd,原增长界)。预黏性改变状态后重新检查联合界。整步 const anchor 回退；同一 dt 用于两次黏性半步及原 TD1 双曲步。原 selectTemporalCandidate 的 connected/retry/rescue/representable-time 逻辑复用。不可表示时间故障注入完整回退通过，时钟与两层状态未改变。最小实际 dt 5.521438157082191e-07。

整体仍一阶；不因使用对称黏性分裂而宣称二阶。

## 5. 声学、接触、固定黏性激波与完整可执行文件

声学 N32/64/128 × mu0/3/1000，共9项全部完成。参考为独立离散 Fourier 演化，使用实际 accepted dt；pressure/velocity 对该参考误差均 <=2e-6。该检查验证离散与时间步集成，广泛 cPE 长波相速、相位/阻尼分离将由 CRV3-3 继续认证。

接触扩展短程压力误差最大 0.087144%，低于1%目标；其中包含 TL290/310 的 alpha 热接触。完整 solver 原纯相接触、speciesContact 与光滑输运回归正常结束。更长时间及组合/高速度接触收敛仍由 CRV3-3 负责，不以短程结果代替全面接触资格。

完整可执行文件覆盖10个 CRV3 基础算例以及1个旧模型算例；全部 endTime 正常结束，acceptedRecoveryFailures=0，守恒硬门通过。完整 executable 由当前 project-local 源码重新编译到独立 bin；未覆盖旧 executable。

固定 mu=3、pressureRatio=1.05 的原生 CRV3 行波 PDE 回归：

|N|frame|pressure L1/jump|alpha L1/jump|velocity L1/jump|conservation|
|---:|---|---:|---:|---:|---:|
|128|lab|5.567898%|5.614914%|5.549556%|1.48e-16|
|128|stationary|0.321433%|0.335025%|0.332753%|9.2e-17|
|256|lab|3.642771%|3.675984%|3.640663%|1.48e-16|
|256|stationary|0.111279%|0.119020%|0.118808%|2.67e-16|
|512|lab|2.225770%|2.246651%|2.225038%|1.64e-16|
|512|stationary|0.043639%|0.047510%|0.046856%|1.9e-16|

两参考系关键误差随 N128→256→512 降低，最细工程量 <5%。粗网格 lab 压力误差 >5% 不属于稳定加密后仍 >5% 的硬阻塞。旧 endpoint 路径不强制匹配；最终快照 path residual 不是 accepted-anchor 守恒账本。固定 mu 收敛不能替代黏性趋零资格。

严格 root 统计见各 JSON；所有检查均严格。EOS 液体仍 v3 HARD p=0.05–12MPa/TL=265–400K；本轮生成基态 p3MPa、TL290–310K，激波参考 p3–3.15MPa/TL300–300.02954K。所有实际候选和接受态由原原生 EOS 范围守卫检查；完整运行 min/max 轨迹尚未汇总为单独范围表，不宣称已覆盖全部 EOS 边界。

## 6. 哈希、阻塞与里程碑

新 executable SHA256 `babe1ab85796c6c97f05ce53c854e8b20874e5913968bc3b08a1a1ff5dcd4d7b`。原 executable 与两 EOS 库哈希见 `frozen_runtime_before.sha256`，与既有冻结记录一致。逐项源哈希见 source_after.json，工程数据见 qualification_summary.json。

当前硬阻塞：无。工程误差：扩展热接触约0.08714%；最细固定黏性 lab 激波压力 L1约2.22577%，stationary约0.04364%。这些不是整个 production 流场误差认证。

|Milestone|status|
|---|---|
|历史 MC5 / TD1|COMPLETE；历史结果保留|
|SP1|PARTIAL 历史诊断；降为档案|
|SP2|两候选已拒绝；封存|
|CRV3-1|COMPLETE，基础一维串行集成/联合 dt 范围|
|CRV3-2|AUTHORIZED / ACTIVE，黏性趋零|
|CRV3-3～6|待完整覆盖，不继承资格|
|M6B.1|PARTIAL|
|M6B.2 / surface tension / DPM / MPI / production restart|未进入|

CRV3-2 下一步：至少弱/中等/原始 shock 的四级黏性阶梯与匹配网格，检查宏观跳跃、平台、位置、厚度、加热/熵积分和保守 RH；建立两参数收敛证据后再判定，不用旧 endpoint 指标代替物理门。
