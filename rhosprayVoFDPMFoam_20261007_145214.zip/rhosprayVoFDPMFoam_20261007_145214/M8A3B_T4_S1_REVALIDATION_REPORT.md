# M8A.3B-T4-S1 — revalidation and serial subset/topology evidence v2

2026-10-04. **T4-S1 COMPLETE / REVALIDATED within isolated two-rank fixed-mesh support scope.** This request remains S1; no S2 or parcel migration is executed. Original S1 checkpoint/live manifests independently verified SHA/CRC/per-file SHA PASS, unchanged. Frozen distributed implementations and prior evidence are not overwritten. New standalone audit tools and copied output fixture supplement the certificate.

## Required 35-item report

| # | Item | Result |
|---|---|---|
| 1 | T4-S1 | COMPLETE / REVALIDATED, isolated two-rank scope |
| 2 | Original blocker | Fresh both ranks reproduce unchanged serial `MPI_SPARSE_SUPPORT_NOT_IMPLEMENTED` |
| 3 | Architecture | Existing project-local distributed impulse stencil + immutable conservative support view, unchanged |
| 4 | Backend separation | Serial source unchanged; fresh serial phase subset directly uses frozen CarrierQueryOwner |
| 5 | Contributor identity | Rank/kind/local entity/physical patch key; no pointer authority |
| 6 | Processor topology | Fresh cell/position/tet-vertex/barycentric/processor-patch/neighbour-rank/full-tensor records on both ranks |
| 7 | Native membership | Fresh exact impulse-oracle equality, real nonzero remote contributors |
| 8 | Coupled weights | Fresh nine tensor components exact; maximum difference 0 |
| 9 | Remote state | Frozen P2 signed payload + q[0..9] + generation protocol; no fabricated gas |
| 10 | Generation | Fresh accepted support publication/discard/reconstruction tests PASS; no parcel transaction claim |
| 11 | All gas | Fresh scalar/Y bit exact vs one-rank frozen reference; U within unchanged original gamma32 bound |
| 12 | Mixed0.1 | Fresh distributed and serial subset PASS |
| 13 | Mixed0.5 | Fresh distributed and serial subset PASS |
| 14 | Mixed0.9 | Fresh distributed and serial subset PASS |
| 15 | Trace 1e-20 | Fresh signed P2/gas presence/intrinsic density tests PASS, including serial subset |
| 16 | Remote absent | Fresh rank0 remote rank1 alphaG=0,mG=0 controlled reject PASS |
| 17 | Support first | Actual complete contributor/generation/phase prerequisites checked before dependent query recovery/properties in legal fixture domain |
| 18 | Counters | Fresh absent/stale tests have zero property/recovery increments; rho/T/Y/Cp/mu/kappa increments each zero; no whole-field Cp/kappa code path |
| 19 | Stale generation | Fresh 1000 cycles per rank PASS |
| 20 | Mixed generation | Fresh injected rank1 stale authority tests PASS |
| 21 | Destination rebuild | Fresh current-mesh stencil rebuild/stable logical key tests PASS; synthetic pose only |
| 22 | Invalidation | Fresh position/cell/face/owner/session, move/rebound/generation tests PASS |
| 23 | Communication | Explicit support exchange/publication phases, query performs no communication; malformed-input collective rejection PASS |
| 24 | Stress | Fresh1000cycles perrank, each with valid/absent/stale/discard/invalidation paths;23444total assertions/0failures |
| 25 | Deadlock | Both ranks completed; no hang/unmatched communication observed in tested scope |
| 26 | Serial regression | Fresh17checks/0failures: gas/mixed0.1/0.5/0.9/trace/absent support-first subset; eight allgas equality queries additionally PASS |
| 27 | Hashes | Fresh6717Foundation/19nativeparcel; 2618project/evidence hashes PASS before authorized milestone append |
| 28 | Active solver impact | NONE |
| 29 | Production mesh/BC | NONE |
| 30 | S1 COMPLETE? | YES within the original bounded support fixture certificate |
| 31 | S2 permission | NEXT ROUND ONLY / NOT EXECUTED |
| 32 | T4 | PARTIAL; isolated support backend exists, parcel migration/global transaction/model gates remain open |
| 33 | M8A | PARTIAL |
| 34 | M6B/CFD | NO; production restart NOT CERTIFIED |
| 35 | Matrix | R2-FINAL/T3A/T3B/T3 frozen serial COMPLETE; S1 COMPLETE; S2 NOT STARTED; T4/M8A PARTIAL |

## Evidence details

Fresh checks: topology3364, distributed support20051, serial phase subset17, additional topology-context audit12; total23444/0failures. Weight oracle and existing support stress executables are the frozen hash-verified binaries, rerun against the new copied fixture. Only the new standalone audit executable is freshly compiled; final compiler log has no test-source indentation warnings. Process exit status alone is never a PASS authority; every local/global result failure count is checked explicitly.

`fixture/processor0/S1_pose_topology.csv` and rank1 counterpart record the actual native `cellPointWeight` three face vertices and four barycentric weights, requested face=-1, local cell/position, current processor patch ID and neighbour rank, each remote logical key and all nine tensor components. The tet is identified by current cell centre and its three recorded native face vertices. Remote key/weight rows are verified nonzero and coupled to the actual neighbour; native membership/full-weight equality is independently exercised by the unchanged native interpolation impulse oracle. The copied processor boundary files preserve the physical patch relationship.

Fresh serial `serial_phase_regression.csv` covers allgas, mixed0.1/0.5/0.9, trace and pure-liquid absence. Pure-liquid serial publication has zero gas EOS calls and no gas object; query refuses before properties. Trace support retains the signed P2 payload and native TRACE_PRESENT classification. These are support-first subset regressions, not a relabeling of all historical serial/model suites as rerun.

Allgas rho,p,T,Cp,mu,kappa,Y have exact double equality. U0 max absolute difference is7.105427357601002e-15 m/s, U1 exact, U2 4.440892098500626e-16 m/s. The original S1 component gamma32 floating evaluation bounds are reused unchanged; no tolerance was widened. `equivalence.json` stores actual errors and prior bounds.

Publication includes conservative phase/mass/momentum/energy/species state and generation, not gas Cp/kappa fields. On invalid/stale query, the frozen implementation's monotonic per-property counters have zero sum increment and zero recovery increment; therefore each rho,T,Y,Cp,mu,kappa increment is zero. No query-time MPI collective is introduced. This remains **support publication/query safety**, not global parcel commit/reject, source accounting or output exactly-once certification.

## Scope and limitations preserved

The eight-cell fixture has four cells and one direct processor patch per rank. The global impulse discovery is a passive reference backend, not production-scalable communication. Keys are stable only within the fixed decomposition; no AMR/repartition/restart certificate. Physical-face authority is explicitly prescribed, never substituted for processor neighbours. Arbitrary production boundary models, corrupt raw EOS-domain input certificates and concurrency with native parcel-transfer collectives are not newly certified. Recovery continues to use frozen P2/EOS and can fail for invalid thermodynamic input. No serial rewrite, new serializer, C1 reopening, native model change, active integration, parcel crossing, source/output ledger, M6B or CFD.

Added: `tests/fiveEqDPMDistributedSupportS1Audit/testS1Audit.C`, its isolated Make files, `prepare_t4_s1_revalidation.py`, the new evidence directory and this report. Existing distributed/serial/backend/C2/R2/K1/active sources remain hash-identical. The previous S1 seal remains immutable. A new v2 revalidation checkpoint contains new evidence and dependency metadata; it does not replace v1.

Next permitted work: separately authorized T4-S2 real processor-crossing gate. **STOP; S2 is not executed this round.**
