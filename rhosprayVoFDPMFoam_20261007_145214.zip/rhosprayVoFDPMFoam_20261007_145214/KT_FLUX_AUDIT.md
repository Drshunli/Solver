# M5A audit of the active Foundation OF7 KT flux

This is the active `rhosprayVoFDPMFoam.C`, not the separate experimental
solver. Conservative fields are `rho`, `rhoU`, `rhoE`; legacy `rho` remains
the gas/carrier density and `rhoMix` is only an M4 property diagnostic.

On each face the solver directionally interpolates `rho` to `rho+`, `rho-`,
`rhoU` to `(rhoU)+`, `(rhoU)-`, inverse compressibility `1/psi` to
`rPsi+`, `rPsi-`, and internal energy `e` to `e+`, `e-`. It recovers
`U+ = (rhoU)+/rho+`, `U- = (rhoU)-/rho-` and uses
`p+ = rho+*rPsi+`, `p- = rho-*rPsi-`. Relative face volume velocities are
`q+ = U+·Sf - mesh.phi()` and `q- = U-·Sf - mesh.phi()` on moving meshes.
The gas sound speed is `c = sqrt((Cp/Cv)/psi)`; its directed face values
times `|Sf|` are `cSf+`, `cSf-`.

The one-sided wave bounds are
`ap=max(q+ + cSf+, q- + cSf-, 0)` and
`am=min(q+ - cSf+, q- - cSf-, 0)`.
For Kurganov, `a+=ap/(ap-am)`, `a-=1-a+`, `aSf=am*a+`.
For Tadmor, `a+=a-=1/2` and
`aSf=-max(|am|,|ap|)/2`.
After `phiv_pos *= a+` and `phiv_neg *= a-`, the code defines
`A+ = a+*q+ - aSf` and `A- = a-*q- + aSf` (`aphiv_pos/neg`).

The active mass flux is

```
phi = A+*rho+ + A-*rho-
    = a+*q+*rho+ + a-*q-*rho- + aSf*(rho- - rho+).
```

The final term is KT/Tadmor density-jump dissipation. The active momentum
flux is

```
phiUp = A+*(rhoU)+ + A-*(rhoU)-
      + (a+*p+ + a-*p-)*Sf.
```

Its `aSf*((rhoU)- - (rhoU)+)` is momentum-state dissipation. With
`E+ = rho+*(e+ + |U+|^2/2)`, `E-` analogously, the energy flux is

```
phiEp = A+*(E+ + p+) + A-*(E- + p-)
      + aSf*(p+ - p-).
```

The pressure correction cancels pressure from its `aSf` difference, leaving
`aSf*(E- - E+)` as total-energy-state dissipation. For moving meshes the
code also adds `mesh.phi()*(a+*p+ + a-*p-)` to pressure work. The existing
`rhoEqn.H`, `rhoUEqn.H`, `rhoEEqn.H` consume `phi`, `phiUp`, `phiEp`
respectively. Their non-flux DPM, viscosity, reaction and thermo steps are
outside M5A and remain unchanged.

The M2 VOF volume flux is
`phiV=A+ + A-=a+*q+ + a-*q-`: the `aSf` terms cancel. Therefore
`phiV` does **not** carry the KT density-jump dissipation contained in `phi`.
M2 forms a raw advective alpha flux `fvc::flux(phiV,alphaL,scheme)` plus
the nested `phir=cAlpha*|phiV/Sf|*nHatf` compression flux. It passes the
sum through `MULES::explicitSolve`; this mutates `alphaPhi` to its limited
flux. `alphaSubCycle.H` time-weights final substep fluxes. The exact final
`alphaPhi` is not simply raw advection plus raw compression: MULES limiter
corrections (and possible repeated alpha correctors) are also present.

In local Foundation OF7 `VoF/alphaEqn.H`, `alphaPhi10` similarly receives
advection and compression and is MULES-corrected. The compressibleInterFoam
alpha subcycle uses `rhoPhi=alphaPhi10*(rho1f-rho2f)+phiCN*rho2f` for Euler
or its off-centered counterpart; subcycles time-average `rhoPhi`. Its
`pEqn.H` then pressure-corrects volumetric `phi` and updates phase densities.
This is a pressure-based PIMPLE system. The present solver instead advances
`rho`, `rhoU`, `rhoE` with a single density-based KT flux family.
