# Subnormal representation contract v1 — implementation closure remains PARTIAL

This is a representation addendum for NONZERO_K_PE_CRV3_v1, not a physical model change.
P2-v1 remains the sole phase-presence authority: +0 is pure gas, -0 pure liquid,
and every nonzero signed minority payload represents two present phases.
Diagnostic TRACE_PRESENT classification does not delete, floor or normalize a phase.

Positive finite subnormal fractions and phase masses are permitted when their
scaled intrinsic density is finite and their frozen EOS/R1 state is admissible.
Recovery uses frexp/scalbn for subnormal operands, without changing Q or P2.
Normal intrinsic-density quotients retain the original division operation.
EOS, K/cPE formulas, R1 residual and derivative, species closure, and CRV3
stress/heating/work equations remain unchanged.

Two additional numerical implementation defects were found after enabling this range:
noncontrolling time bounds could overflow under OpenFOAM floating-point traps;
fixed-volume Euler updates could quantize V*m and then divide it back, losing
mass even for zero net flux. Bounds above binary64 range explicitly return the
existing +infinity semantics; fixed-volume conservative increments use FMA.
These changes do not introduce phase diffusion or a physical state repair.

The original step208 state now recovers with its exact frozen Q/P2 bits.
Fresh CRV3-1 regressions and 300-step strict audits pass. Nevertheless scalar
P2 cannot encode every positive fraction produced by the conservative update.
The independently certified step300 full-cap trial creates alphaL≈3.1318e-325,
while mL≈2.1998e-322 remains positive. P2 rounds to +0 and native recovery must
reject ABSENT_PHASE_HAS_MASS. This is a representation-range blocker, not an
EOS or CRV3 physical-model failure. Legal microsteps still exist, but the new
temporal-collapse gate is not satisfied. CRV3-2A is INCOMPLETE.

Do not suppress the exact-zero guard, promote the fraction to denorm_min,
modify the phase mass, or treat this failure as production qualification.
Representation-V2 is design only; no P2-v2 storage or restart migration is implemented.
