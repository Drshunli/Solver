# M6B1 MC4 NONZERO-K SERIAL IMPLEMENTATION REPORT v1

2026-10-05。**PARTIAL / MODEL_IMPLEMENTATION_BLOCKER / STOP**。

冻结稳定公式的1 ULP外向舍入被新实现的严格K边界guard拒绝。按本轮§51停止，没有修改公式、冻结模型、EOS/R1/temporal预算或guard以绕过失败。当前安装的是未qualified候选，NONZERO_K_PE_v1需显式选择；默认historical K0仍隔离保留。

1. **MC4 status** — PARTIAL / MODEL_IMPLEMENTATION_BLOCKER / STOP。候选实现已安装、资格测试未完成。

2. **MC3 model hash verification** — be2e3d414dcfffd7a9ae498fa14f4a4f8de934b60c5c87f78a696bdf041b5270；逐字节未改。

3. **source delta** — 原110个文件中改8个，新增fiveEqNonzeroKModel.H，共111个；9个delta均在授权逻辑范围。完整before/after SHA见source_delta.json和active_source.patch。

4. **model/runtime tag** — NONZERO_K_PE_v1 显式mechanicalModel选择；未指定时HISTORICAL_K0。新restart-v2写model tag，默认读拒绝不匹配；production restart未认证。旧exactInitial只作为显式历史fresh fixture且必须step/time/lastDt=0。元数据运行测试在STOP前未执行。

5. **K implementation** — 严格按(a*b)*(((AG-AL)/S)/D)。纯相K=0且不访问缺相EOS；双方痕量保持P2双分数。严格K>=-a检查拒绝1 ULP外向舍入：a=.1,b=.9,AL=1.0000000000000002e100,AG=1e-100,K=-.10000000000000002。公式误差1.3877787807814457e-17在冻结预算内，拒绝来自实现守卫。按失败规则STOP；没有clip、预算调整或后续源码修复。

6. **cPE implementation** — 使用冻结stable bulk及sqrt(bulk/rhoMix)，pure phase返回phase c。7实际EOS native控制已导出；极端代数集在上述守卫处中止，不能整体PASS。

7. **old-cA exclusion audit** — sound_callsites.json逐处分类：new precision recovery只选cPE；PrecisionOperator面、jointBound、connectedDt经同一model recovery/waves。Allaire留在明确historical dispatch、旧R0/R2/RuntimeBridge；new reconstruction strategy0，strategy!=0直接拒绝。该项为源码审计，不代替运行资格。

8. **KT wave update** — KTWaveSpeeds公式原文件不改；new分支从左右recovery.cPE输入，保留原面积/符号/物理phi；仅fixed mesh/Kurganov允许。

9. **CFL update** — fresh acoustic使用实际new KT waves；joint和connected检查同一new recovery与source trial。数值CFL控制值、representable time、rollback/growth/rescue算法不变。

10. **physical-divU implementation** — theta=(phiPhysStar_R-phiPhysStar_L)/V，原KT同组committed states及cPE wave weights；没有独立div(U)。runtime meshPhi!=0拒绝，ALE未启用。

11. **alpha/P2 source implementation** — total DD=original transport DD+ddScale(ddSub(phiPhysR,phiPhysL),K^n)，dt/Vnew缩放后advanced一次，Q0从P2解码。保守trial原公式逐项保持。

12. **source quadrature** — committed cell time-n K，explicit forward Euler；没有trial/face-averaged/midpoint K。

13. **source-aware bounds** — jointBound使用total numerator和原Dmesh结构，aV+dt(aD+N)、bV+dt(bD-N)；无clip。独立P2 source完整单测尚未执行。

14. **R1 preservation** — 压力恢复数学部分在s.cMix赋值前与PRE字节相同；R=mGeG+mLeL-I，Rprime=mGbetaG+mLbetaL。2500冻结states开发诊断p/TG/TL/cL位级相同；184/lower130未执行。

15. **Et preservation** — explicitTrial/KT conservative flux form原文件SHA不变；没有pKtheta、latent heat、phase-work或Et修正。

16. **species preservation** — 原species flux和N-1 post q9=mG-(q7+q8)保留，无normalize或独立species limiter。

17. **path implementation** — ThreeLegPath记录uStar、左右IK/IaK legs及总积分，middle du=0；首版只strategy0。中段P2凸插值及继承缺相温度/组分仅用于路径守卫，不改committed mass。

18. **path/source identity** — 首轮25×100开发诊断max scaled absolute error=6.9388939039072284e-18，K/full(a+K) cell legs相加与source一致。最终guard补齐后的mandatory rerun因STOP未执行，不能记最终资格PASS。

19. **path guards** — 端点及17个native中段节点EOS域/有效性检查；JANAF端点mix及有权重species分支crossing显式拒绝；不外推/clamp。连续路径全域正性证明未新增，节点检查不冒充连续证明；fresh guard单测未执行。

20. **pure/trace tests** — gas/liquid、mixed .1/.5/.9、traceLiquid/traceGas=1e-20共7实际native控制运行；p/TG/TL/cL与K0相同，pure缺相query counters=0。源、路径及完整limit资格未完成。

21. **K/cPE algebra tests** — FAIL / MODEL_IMPLEMENTATION_BLOCKER。63个冻结同类control计划，执行到mixed01/extreme AL≫AG组合的K硬边界guard失败。异常日志及独立Decimal90-digit失败复核见blocker.json；没有改冻结MC3预算。

22. **hyperbolicity tests** — NOT RUN AFTER STOP。MC3 14个数值Jacobian仍是冻结设计证据，不能复用为MC4 fresh PASS。

23. **P2 source tests** — P1–P10 harness已编写但在algebra STOP前未到达；不记PASS，未裁剪/制造或删除相。

24. **exact-contact regression** — NOT RUN AFTER STOP。MC2/MC3 Tmin历史strict sign问题继续保留，无新PASS/FAIL断言。

25. **compression regression** — NOT RUN AFTER STOP。TL300/265×kappa .001/.01/.1/1 harness已编写，未到达。

26. **expansion regression** — NOT RUN AFTER STOP。sign reversal及strict/root未取得fresh结果。

27. **25-anchor active test** — 首轮development diagnostic为25×100 current-project active C++ sources、strategy0/newcPE/newK；all100 raw/post native+strict通过。该轮早于最终P2 middle-path refinement；后续full-gate rerun因STOP未做，明确不计MC4 completion。

28. **strict/native root statistics** — 首轮raw 2500/2500 native、2500/2500 strict；post同数。24旧micro baseline tolerance-only事实未改。这是developing candidate结果，非最终轨迹/动态资格。

29. **new freshCap statistics** — 首轮新计算freshCap [1.2053951913444919e-06,1.2054427043871449e-06] s；不是硬编码旧1.205e-6。全部positive且timeAdvance=1；旧/新acoustic逐anchor见anchors.csv。

30. **conservation audit** — 首轮22500个Q1..9试值与同一new conservative faces的原explicitTrial位级一致，mismatch=0。flux文件/energy公式未改；无repair。未完成最终fresh conservation资格。

31. **P2/species audit** — 首轮2500 P2 total-DD authority mismatch=0，raw/post species closure/native recovery通过。完整source/source-bound/presence micro suite未执行，不升级资格。

32. **local Galilean control** — NOT RUN AFTER STOP。-3000/+300/+10000控制已编写；没有high-Mach、frame或ALE资格声明。

33. **path/RH micro ledger** — NOT RUN AFTER STOP。smooth compression/contact/two-state ledger程序已编写，但没有fresh输出；不使用conservative alpha RH作PASS。

34. **executable/library hashes** — 当前exe a4da5bdc3b975bbd536c0321ca40bcef6e21ac4fae2bd10d085d2fcd456f3945；LiquidEOS 1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888；FiveEqThermo f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896。fresh wclean/wmake 0 errors，3条与TD1完全相同既有告警，0 unexpected warnings。

35. **source hashes** — source_implemented.json保存111个逐文件SHA，source_delta.json保存9项delta。实现checkpoint之后active源码未改。

36. **EOS hashes** — v3 potential/coeff/energy_reference/metadata与PRE manifest相同，HARD p0.05–12 MPa/T265–400 K未改。以下列出4个SHA。

37. **Foundation hashes** — 6717 Foundation和19 native-parcel文件sha256 -c全OK；115 installed library hashes全部不变，逐文件记录见foundation_after.txt/native_parcel_after.txt/all_libraries_after.sha256。

38. **MC4 COMPLETE?** — NO。MC4_COMPLETE=false，MC4_VALIDATED=false；没有生成VALIDATED checkpoint。

39. **MC5 authorized?** — NO。因MC4未COMPLETE，MC5 NOT AUTHORIZED，本轮未执行。

40. **TD1 status** — PARTIAL。历史算法证据保留，new model future fresh TD1仍需要单独授权/完成。

41. **DYN-CLOSURE status** — NOT AUTHORIZED。

42. **M6B.1/M6B status** — 均PARTIAL；新模型不是production CFD/production restart，不具备动态或shock收敛资格。

43. **milestone matrix** — MC2 COMPLETE/M1；MC3 COMPLETE/DESIGN FROZEN；MC4 PARTIAL/MODEL_IMPLEMENTATION_BLOCKER/STOP；MC5 NOT AUTHORIZED；EOS3 COMPLETE/DOMAIN FROZEN；TD1 PARTIAL；M6B.1/M6B PARTIAL；DYN NOT AUTHORIZED。

EOS frozen SHA256:

- `liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H`: `421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d`
- `liquidEOS/ndecane_gibbs_v3/coefficients.json`: `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`
- `liquidEOS/ndecane_gibbs_v3/energy_reference.json`: `ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef`
- `liquidEOS/ndecane_gibbs_v3/metadata.json`: `9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6`

Checkpoint PRE: 4192d40c3c0c8cfe2dec7305bdd17b64de5f57f83e857f0b94b7bd4db53f573e

Checkpoint IMPLEMENTED: a3e2b54011f13d290967aaa227ede09784e68001a45b9711cac858999b12bf11

STOP archive hash is recorded separately in seal_blocker_stop.json after sealing this report. No VALIDATED archive.
