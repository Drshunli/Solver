#include "rhosprayVoFMixture.H"

Foam::rhosprayVoFMixture::rhosprayVoFMixture
(
    const fvMesh& mesh,
    const volScalarField& alphaL,
    const volScalarField& alphaG,
    const volScalarField& rhoGas,
    const psiReactionThermo& gasThermo,
    const SLGThermo& slgThermo
)
:
    alphaL_(alphaL),
    alphaG_(alphaG),
    rhoG_(rhoGas),
    gasThermo_(gasThermo),
    liquids_(slgThermo.liquids()),
    liquidX_(1, scalar(1)),
    rhoL_
    (
        IOobject("rhoL", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar("rhoL", dimDensity, 0)
    ),
    rhoMix_
    (
        IOobject("rhoMix", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar("rhoMix", dimDensity, 0)
    ),
    muL_
    (
        IOobject("muL", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar("muL", dimDynamicViscosity, 0)
    ),
    muMix_
    (
        IOobject("muMix", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar("muMix", dimDynamicViscosity, 0)
    ),
    CpL_
    (
        IOobject("CpL", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar("CpL", dimSpecificHeatCapacity, 0)
    ),
    CpMix_
    (
        IOobject("CpMix", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar("CpMix", dimSpecificHeatCapacity, 0)
    ),
    kappaL_
    (
        IOobject("kappaL", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar
        (
            "kappaL", dimPower/dimLength/dimTemperature, 0
        )
    ),
    kappaMix_
    (
        IOobject("kappaMix", mesh.time().timeName(), mesh,
            IOobject::NO_READ, IOobject::AUTO_WRITE),
        mesh, dimensionedScalar
        (
            "kappaMix", dimPower/dimLength/dimTemperature, 0
        )
    )
{
    if (liquids_.size() != 1)
    {
        FatalErrorInFunction
            << "M4 single-liquid closure requires exactly one SLGThermo "
            << "liquid; found " << liquids_.size()
            << exit(FatalError);
    }

    Info<< "M4 diagnostic VOF liquid uses the DPM SLGThermo component "
        << liquids_.components()[0] << endl;

    correct();
}


void Foam::rhosprayVoFMixture::updateLiquid
(
    volScalarField& field,
    liquidPropertyFunction property
)
{
    // Diagnostic property estimate only: gas p/T are query coordinates,
    // not the future five-equation liquid pressure/temperature ownership.
    const volScalarField& p = gasThermo_.p();
    const volScalarField& T = gasThermo_.T();

    forAll(field, celli)
    {
        field[celli] = (liquids_.*property)(p[celli], T[celli], liquidX_);
    }

    forAll(field.boundaryField(), patchi)
    {
        forAll(field.boundaryField()[patchi], facei)
        {
            field.boundaryFieldRef()[patchi][facei] =
                (liquids_.*property)
                (
                    p.boundaryField()[patchi][facei],
                    T.boundaryField()[patchi][facei],
                    liquidX_
                );
        }
    }
}


void Foam::rhosprayVoFMixture::correct()
{
    updateLiquid(rhoL_, &liquidMixtureProperties::rho);
    rhoMix_ = alphaL_*rhoL_ + alphaG_*rhoG_;
    updateLiquid(muL_, &liquidMixtureProperties::mu);
    muMix_ = alphaL_*muL_ + alphaG_*gasThermo_.mu();
    updateLiquid(CpL_, &liquidMixtureProperties::Cp);
    CpMix_ =
        (alphaL_*rhoL_*CpL_ + alphaG_*rhoG_*gasThermo_.Cp())
       /max(rhoMix_, dimensionedScalar("rhoMixFloor", dimDensity, SMALL));
    updateLiquid(kappaL_, &liquidMixtureProperties::kappa);
    kappaMix_ = alphaL_*kappaL_ + alphaG_*gasThermo_.kappa();

    if
    (
        rhoG_.dimensions() != dimDensity
     || rhoL_.dimensions() != dimDensity
     || rhoMix_.dimensions() != dimDensity
     || gasThermo_.mu().ref().dimensions() != dimDynamicViscosity
     || muL_.dimensions() != dimDynamicViscosity
     || muMix_.dimensions() != dimDynamicViscosity
     || gasThermo_.Cp().ref().dimensions() != dimSpecificHeatCapacity
     || CpL_.dimensions() != dimSpecificHeatCapacity
     || CpMix_.dimensions() != dimSpecificHeatCapacity
     || gasThermo_.kappa().ref().dimensions()
        != dimPower/dimLength/dimTemperature
     || kappaL_.dimensions() != dimPower/dimLength/dimTemperature
     || kappaMix_.dimensions() != dimPower/dimLength/dimTemperature
    )
    {
        FatalErrorInFunction << "M4 phase-property dimensions invalid"
            << exit(FatalError);
    }
}
