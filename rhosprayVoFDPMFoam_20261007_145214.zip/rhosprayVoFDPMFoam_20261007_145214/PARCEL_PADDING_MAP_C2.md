# C2 parcel binary semantic padding map

Status: COMPLETE in current passive serial test scope. First-activation contract selected by user: NATIVE-COMPATIBLE / SEMANTIC-NONCANONICAL. C1 stays historical PARTIAL under its original strict byte-canonical gate.

## Provenance and method

Foundation OF7, GCC11.4, C++11, DPInt32, x86-64 little-endian current ABI. Local headers retain native IO expressions. Test-only OSstream virtual raw-write tracing measures actual source address, byte count and stream start before delegating to unmodified native OSstream::write. That native write wraps each raw block in '(' and ')'; tracing checks observed framing and length. A typed member catalog pins every particle tracking/identity member and every local/native Kinematic/Thermo/Reacting/Spray persisted field, including dynamic Y elements. No byte ranges are guessed.

Field-level comparison uses exact bytes of each typed field, including labels/bools/scalars/vectors and Y elements; derived position is also checked. Complete transactionState-v1 stays the authority for Q/P2, IDs, allocator, RNG/cached normal, model histories, source arrays, time, generation and pending output. Native raw parcel stream bytes never replace that codec.

## Raw block map for measured single-component parcel

| Block | Object offset | Stream start | Length | Scope |
|---|---:|---:|---:|---|
| native block | 32 | 1 | 80 | object-bounded |
| native block | 108 | 83 | 108 | object-bounded |
| native block | 216 | 193 | 16 | object-bounded |
| native block | 232 | 211 | 8 | object-bounded |
| Y composition | Y_HEAP | 224 | 8 | explicit Y allocation |
| native block | 264 | 234 | 120 | object-bounded |

All offsets are zero-based. Particle block is32..112; Kinematic108..216; Thermo216..232; Reacting mass0 is232..240 followed by explicit Y list IO; Spray264..384. Local/native sizes and raw spans match. Y's pointer/list metadata in object240..264 is not raw dumped. Total stream355 bytes applies to this measured Y-size1 state, not a hard-coded serializer length.

## Exact padding positions

| Stream offsets | Object offsets | Explanation |
|---|---|---|
| 78,79,80 | 109,110,111 | base-tail bytes encountered in particle raw block |
| 84,85,86 | 109,110,111 | same memory bytes encountered again in Kinematic block after bool |
| 91,92,93,94 | 116,117,118,119 | label-to-scalar alignment gap |

Object108 is active in the most-derived parcel due to base-tail reuse. It is retained as a field byte, including its duplicate occurrence in the particle raw block; it is NOT masked as padding. Thus the semantic comparison is conservative with respect to native overlap, and masks only the measured ten padding stream positions.

## Authoritative/native-persisted byte map

Measured regions: 37 typed fields; stream categories: authoritativeField=266, nativeFraming=15, nativePersistedField=64, padding=10.

| Field | Object offset | Size | Category |
|---|---:|---:|---|
| Co | 32 | 32 | authoritative |
| Cell | 64 | 4 | authoritative |
| TF | 68 | 4 | authoritative |
| TP | 72 | 4 | authoritative |
| Face | 76 | 4 | authoritative |
| Step | 80 | 8 | authoritative |
| Behind | 88 | 8 | authoritative |
| NBehind | 96 | 4 | authoritative |
| Proc | 100 | 4 | authoritative |
| Id | 104 | 4 | authoritative |
| active | 108 | 1 | authoritative |
| typeId | 112 | 4 | authoritative |
| nParticle | 120 | 8 | authoritative |
| d | 128 | 8 | authoritative |
| dTarget | 136 | 8 | authoritative |
| U | 144 | 24 | authoritative |
| rho | 168 | 8 | authoritative |
| age | 176 | 8 | authoritative |
| tTurb | 184 | 8 | native-persisted derived/history |
| UTurb | 192 | 24 | native-persisted derived/history |
| T | 216 | 8 | authoritative |
| Cp | 224 | 8 | native-persisted derived/history |
| mass0 | 232 | 8 | authoritative |
| d0 | 264 | 8 | authoritative |
| position0 | 272 | 24 | authoritative |
| sigma | 296 | 8 | native-persisted derived/history |
| mu | 304 | 8 | native-persisted derived/history |
| liquidCore | 312 | 8 | authoritative |
| KHindex | 320 | 8 | authoritative |
| y | 328 | 8 | authoritative |
| yDot | 336 | 8 | authoritative |
| tc | 344 | 8 | authoritative |
| ms | 352 | 8 | authoritative |
| injector | 360 | 8 | authoritative |
| tMom | 368 | 8 | native-persisted derived/history |
| user | 376 | 8 | authoritative |
| Y[0] | HEAP | 8 | authoritative |

Every stream byte and its category/field is exported in fitting/dpm/m8a3b_t3br2c_c2_v1/semantic_byte_map.csv. Native framing/list length is compared as defined format metadata, not ignored. Non-padding differences fail semantic comparison.

## Controlled challenges

Fresh different-address copy objects, original/copy/clone, iNew and reconstructed objects must retain fields and semantic bytes. The fixture initializes ONLY fences, never parcel storage/padding. It does not memset objects, force constructor storage patterns, adjust ABI, shorten lengths or canonicalize memory. Padding challenge mutates only proven positions in an already-produced stream. Local and unmodified native readers restore identical physical fields. A separate temperature-field low-byte mutation is detected by both byte-mask and explicit field comparisons.

Writer/reader32-byte leading/trailing fences PASS. Same-object repeated write is recorded stable. Actual whole population roundtrips and copy/clone/padding-read variants each continue10 accepted steps with exact full transaction/carrier/query equality.

## Boundaries

Not a canonical raw-file hash format, cross-ABI/compiler format, MPI format or production restart certification. C1's strict criterion remains failed. The ORourke native physical limitation is neither compensated nor relabeled conservation-safe. This gate validates serial semantic IO of the tested populations and environment.
