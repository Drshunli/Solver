# M6B.1-TD2-MICROSTEP-EFFICIENCY REPORT v1

2026-10-05。用户本轮粘贴文本为指令（request_TD2.txt），旧开发文档只作为证据。本轮按section33的具体停止分支结束；第14条E4实施许可没有被误写为条件不成立。

## 1. TD2 status

PARTIAL / DIAGNOSIS CLOSED / MICROSTEP ADMISSIBILITY LIMIT / STOP。25 frozen-anchor 的诊断、重复确定性与保护审计完成；未声称效率修复完成。用户第33条的多数 late 样本无≥16x合法见证条件成立，按该分支停止。

## 2. Late-anchor sample

25 anchors：1 healthy/onset前对照、24 microstep 状态；其中10个在最终10000-step区间。exact onset235、最小 accepted-dt anchor32219、highest reject/rescue1309、early/mid/late median651/10852/27659、final32252均包含。每个100-cell。原每10步snapshot中的17位小数可精确重建binary64 Q/P2；非snapshot点仅重放已记录TD1历史至目标（seed→下一snapshot至多10步），逐步time/dt/9 observer积分bit一致，下一完整100-cell snapshot全部Q/P2 bits一致。扫描不提交新authoritative PDE状态。

| Anchor | TD1 selected dt (s) | Largest tested legal dt (s) | Escape ratio | Tested legal runs | Class |
|---|---:|---:|---:|---:|---|
| 230 | 1.2050933280466008e-06 | 1.2050933280466008e-06 | 1 | 1 | healthy control |
| 235 | 1.0660483333231622e-18 | 1.9180457811724616e-18 | 1.7992109 | 3 | E1 |
| 240 | 8.0546372072300053e-20 | 1.6440392410049675e-18 | 20.4110899 | 8 | E3 |
| 260 | 2.4637713810346072e-19 | 1.9710171048276862e-18 | 8 | 2 | E1 |
| 330 | 5.2118240752610611e-20 | 1.918045781172462e-18 | 36.8018136 | 11 | E3 |
| 530 | 6.0646680148380391e-19 | 9.5902289058623082e-19 | 1.58132793 | 8 | E1 |
| 651 | 2.65329225648902e-19 | 1.9180457811724616e-18 | 7.22892767 | 1 | E1 |
| 1000 | 1.0613169025920739e-18 | 2.192052321339956e-18 | 2.06540791 | 5 | E1 |
| 1309 | 6.0646680147945247e-19 | 6.0646680147945247e-19 | 1 | 8 | E1 |
| 3000 | 4.5485010110253342e-19 | 9.5902289058623024e-19 | 2.10843724 | 10 | E1 |
| 6000 | 2.4637713809044182e-19 | 1.971017104723535e-18 | 8 | 2 | E1 |
| 10000 | 9.8550855232496643e-19 | 1.9710171046499332e-18 | 2 | 4 | E1 |
| 10852 | 2.653292256238911e-19 | 1.9180457811724597e-18 | 7.22892767 | 1 | E1 |
| 15000 | 2.6532922561383404e-19 | 1.9180457811724593e-18 | 7.22892767 | 1 | E1 |
| 20000 | 5.969907576035661e-19 | 2.1920523213399521e-18 | 3.67183628 | 3 | E1 |
| 22260 | 3.0323340068122062e-19 | 9.5902289058622909e-19 | 3.16265586 | 9 | E1 |
| 24000 | 3.1270944444748494e-19 | 1.9180457811724582e-18 | 6.1336356 | 6 | E1 |
| 26000 | 9.8550855217969951e-19 | 1.9180457811724555e-18 | 1.94624976 | 9 | E1 |
| 27659 | 2.6532922558280321e-19 | 1.9180457811724566e-18 | 7.22892767 | 1 | E1 |
| 28000 | 1.0423648147862857e-19 | 2.1920523213399502e-18 | 21.0296078 | 4 | E3 |
| 30000 | 1.1371252524733677e-19 | 1.9180457811724566e-18 | 16.8674979 | 11 | E3 |
| 31000 | 8.0546372049452873e-19 | 2.1920523213399494e-18 | 2.72147865 | 3 | E1 |
| 32000 | 7.4860745786453309e-19 | 2.1920523213399494e-18 | 2.92817323 | 1 | E1 |
| 32219 | 3.3166153196462089e-20 | 1.9180457811724559e-18 | 57.8314214 | 8 | E3 |
| 32252 | 3.3166153196446513e-20 | 1.9180457811724559e-18 | 57.8314214 | 9 | E3 |

## 3. Multiscale scan method

每个const anchor先原R1全100 PASS，再一次性冻结原 reconstruction/KT faces 与 volume。freshCap由原jointBound与end cap重算。向下：freshCap/2^k，加.625/.75/.875子尺度，覆盖至accepted scale以下和half time ULP。向上：incoming accepted dt及TD1 selected dt分别2^k至freshCap，FAIL后继续。增加half/above-half/timeULP与合法witness附近1e-9相对下邻、nextafter邻点。所有点完整all100 raw R1、原dependent species closure后R1、P2/PRESENT/invariants、actual t+dt>t。无EOS shadow/域扩展。有限采样覆盖各尺度，不穷举全部binary64；不能从未发现见证推导全局无解。

## 4. E1-E4 classification

E4 mixed。24 micro samples：E1-tested-scale=18，E3 sparse/nonmonotone=6，E2=0。后期10样本中6个无≥16x见证，4个有见证，满足section33的多数规则。A只有tiny合法dt：在已测尺度上占主导，非全区间不存在更大dt证明；B错过更大dt：部分成立；C sparse pockets/反复fallback：部分成立。不是纯E1，也不是能够恢复宏尺度的纯搜索缺陷。

## 5. Accepted/fresh ratios

micro median fresh/TD1 selected=4258012516695.3252，min/max=1130430460171.2791/36335040149680.047。final10000 baseline median selected=2.6532922558267278e-19，freshCap=1.2050935080033238e-06。两种accepted基准分别报告incoming lastDt与original TD1 selected dt；escapeRatio以同anchor旧策略selected为分母。final32252没有已记录下一步，故通过原TD1候选查询得到baseline3.3166153196446515e-20附近值，未提交该状态；不把上一accepted dt冒充下一selected。以summary.json精确数值为准。

## 6. Larger legal pocket statistics

微步长样本largest tested legal=2.192052321339956e-18s；max escape ratio=57.831421383471117；max robustness lower1e-9 validated ratio=57.83142138347111。有≥16x见证的6/24，所有样本未找到≥256x或≥1e6x见证。

| Ratio threshold | Micro anchors with legal advancing witness | Fraction |
|---|---:|---:|
| 2x | 20 / 24 | 0.833333 |
| 4x | 13 / 24 | 0.541667 |
| 16x | 6 / 24 | 0.25 |
| 256x | 0 / 24 | 0 |
| 1000000.0x | 0 / 24 | 0 |

anchor_comparison.json逐anchor记录每个ratio threshold的eligible candidate数、legal advancing数与比率；分母为该anchor满足ratio阈值的unique tested candidates。候选日记包含原几何ladder和witness邻域，邻域会对legal附近加密，比例不是随机抽样概率。tested legal runs计数只表示排序已测点中PASS/FAIL分段，不能当作连续合法区间个数证明。

## 7. Connected-policy audit

10个micro样本实际调用connected；best/connected最大=202.40997482346214。原first-connected可能选很近的tiny legal pocket，部分更大legal witness仍存在；没有把connected结果误称global envelope。18/24个micro样本的best超过2x incoming：LOCAL_GROWTH_TRAP在已测候选意义上存在，但多数收益不足16x，不能因此推导搜索逃逸可恢复宏尺度。每个原策略选择与既有TD1账本逐位一致；最终状态基准为只读原策略查询。

## 8. Reject-loop audit

final10000：request rejects=3690/10000 (36.90%)；connected retries=3690/10000；rescue=1729/10000 (17.29%)；tiny selected=10000/10000；next requests grow=10000/10000。log2 selected-dt bin回落到前6步曾出现较低bin的事件=1420，这是可复核的scale-return metric。reject-collapse-regrow循环明确存在，但不是zero-time commit。

## 9. Source delta

active project110 frozen source entries全unchanged；active source_delta.json={}，temporal_source.patch为空。新增文件仅在独立TD2诊断目录，调用冻结physical operator，没有active policy/EOS/R1/P2/KT/flux/reconstruction/species/PDE改动。离线trial原volume=.01；observer历史核对使用原mesh dx=.010000000000000002，两者来源不同，初始单ULP积分核对问题已按原量来源修正，未放宽bit parity或物理容差；见diagnostic_setup_notes.md。

## 10. Escape trigger

NOT DEPLOYED：section33停止分支触发。未将fresh/last>=1024 + repeated microstep条件加入运行中的driver，也未改变normal growthFactor2。若后续另行部署，该trigger及recent rejection/rescue/history必须单独验证。

## 11. Escape search

NOT DEPLOYED。E4使第14条实施许可成立，但第33条针对多数late无≥16x见证的更具体停止分支同样成立，本轮采用该分支，不继续调policy来掩盖已测尺度上的限制。global/multiscale只读扫描完成，未把scan候选提交到active trajectory。

## 12. Robustness-neighborhood rule

每个≥2x合法witness额外检查candidate*(1-1e-9)、nextafter下/上邻。按真正raw/post/time PASS记录，未强行给孤立platform附robust标签。largestRobustLower1e9LegalDt与ratio在每anchor JSON中，重复扫描逐位一致。runtime选择规则未修改。

## 13. Evaluation budget

offline total full candidate evaluations=6699，unique=6694，单anchor full eval范围192–333。每个候选200次raw/post recovery调用尝试；失败后仍检查其余cell。96建议针对未来runtime connected/rescue/escape统一预算，不伪称本轮offline scan受96限制；未部署runtime search，所以runtime budget保持TD1 rescue64，全部历史fixture一致。

## 14. Unit J-Q

NOT RUN / NOT IMPLEMENTED，不能记PASS。J–Q是multiscale escape implementation的测试；本轮在section33诊断STOP分支没有该implementation。原TD1 A-I与native regrowth已在新隔离目录重新执行PASS。若后续明确选择实现E3口袋逃逸，J-Q仍是强制门槛，不能复用本次诊断当作实现测试。

## 15. Frozen-anchor before/after

before为原TD1 policy selected，after列为const-anchor最大的已测全100合法推进witness，见第2项表；after是扫描对照，不是已部署策略。所有candidate evaluations、legal rates、escape ratios、首个大于selected合法点与log2距离均在anchor_comparison.json。25/25完整扫描重复，候选账本、100-cell legal witness Q/P2bits、anchor、历史重建时间/积分全部逐字节相同。

## 16. Anchor236 regression

fresh native driver replay两次，原TD1 selected9.4760438617458992e-20s、actual time推进、all100 raw/post PASS、旧nonprogress candidate不提交；结果与TD1历史输出逐字节一致。

## 17. Historical fixtures

234/235/236/SR1 anchor137/EOS2 anchor118/EOS3_pre156全重新执行PASS，deterministic/rollback/budget无回归。另保留旧EOS3 already-nonprogress157：2x cap低于可推进尺度，预期SEARCH_BLOCKER/精确rollback，未强迫推进，不把该guard PASS说成成功恢复。全部新隔离输出与原TD1历史结果一致。

## 18. Shock replay

本轮未重启shockInterface_100。section33多数late无≥16x witness分支先触发；没有implemented escape，所以不执行其之后的unit/frozen gates→new shock progression阶段。原TD1终止仍为用户主动STOP/exit143，不捏造新的自然solver blocker。

## 19. Accepted steps

TD2新增production accepted steps=0；TD1既有32252。离线有限历史重建仅恢复已有accepted状态，不能计作TD2生产推进。

## 20. Physical time reached

新trajectory无；保存的TD1 t=0.00028286341471286345s；endTime=.00055s未达到。

## 21. Median selected dt

原final10000=2.6532922558267278e-19s；TD2 runtime after值N/A。micro frozen扫描largest tested legal median=1.9180457811724593e-18s，不能冒充runtime median。

## 22. Median freshCap

原final10000=1.2050935080033238e-06s；frozen micro sample median=1.2050935080033257e-06s。

## 23. Physical advance / 1000 steps

修复前final10000 aggregate physical advance=3.7506347853877298e-15s，除以10得到per1000=3.7506347853877297e-16s。修复后runtime N/A，未报告100x改善；扫描最大单anchor倍率57.8314仍低于100x，但这也不是未来轨迹改善的数学上界。

## 24. Requested rejects

原全程11798，final10000=3690；TD2 production requests=0。离线FAIL只是候选拒绝，不是新authoritative failure。

## 25. Rescue / escape counts

原全程rescue=5556，final10000=1729；TD2 runtime rescue/escape=0。offline原TD1 baseline查询与multiscale point probe不计作runtime escape invocation。

## 26. Candidate evaluations

首轮canonical诊断full=6699/unique=6694，完整第二轮相同（determinism验证），共13398次full候选评估。前期仅用于修正observer诊断设置的尝试单独记录、不混入最终统计。original TD1 existing candidate eval=94012，不是本轮production次数。

## 27. Time monotonicity

冻结TD1全32252 accepted transactions actual tNew>tOld；candidate另记state legal与timeProgress，不接受t+dt==t。TD2无新增authoritative commit；historical回放/fixture全部保留actual-clock gate与精确rollback。

## 28. Conservation

既有TD1最大relative=4.0158614338351795e-13<1e-12，PASS。本轮const-anchor扫描不改变权威总量；历史重建逐步9 observer总量bit match。无clipping/state correction。没有新增production trajectory，不能新增全程conservation qualification。

## 29. P2 / species

全部legal witnesses raw/post全100 PASS、P2/PRESENT检查；原TD1 species closure max=1.7118919942167416e-16，PASS。无phase deletion、threshold、normalization。native species residual原式q9=q1-(q7+q8)冻结。

## 30. First new blocker

没有新的runtime solver failure。本轮诊断停止条件为MICROSTEP ADMISSIBILITY LIMIT（用户section33多数样本无≥16x见证），不是TIME_RESOLUTION_BLOCKER，不是无positive/advancing合法dt证明。稀疏更大pockets确实存在，不能称pure A。

## 31. Microstep efficiency PASS?

NO / NOT QUALIFIED。未部署修复、未测到runtime median/per1000≥100x改善、未恢复宏尺度。诊断通过不替代效率通过。

## 32. TD1 COMPLETE?

FALSE。局部正确性保持；microstep efficiency和endTime/无unresolved temporal blocker总门槛未满足。TD1、M6B1、M6B均PARTIAL。

## 33. IDP1 required?

IDP1 scheme/admissibility review NEXT ROUND ONLY，按用户section33的sample-rule建议进入；本轮不改IDP源。该建议基于material-scale witness缺乏，不能混同为ADM1已排除的无positive dt或硬EOS域阻塞证明。

## 34. DYN-CLOSURE permitted?

FALSE / NOT AUTHORIZED。TD1尚未COMPLETE；不执行wave ladders/RH/high-Mach/Galilean。

## 35. Hashes

active source110/115 libraries/Foundation6717/nativeparcel19全unchanged；TD1 protected evidence=3787全SHA PASS。TD1 archive SHA cc984d7dd1decdce41e80eade910c4dc17446bca2be5ec9cc1ce1bc2cafd5a41/CRC PASS。active installed：

```text
4981c4bfc7f395e096f1296d3a51a1b08f725a57758bb3270c438da97c9edcd9  /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/bin/rhosprayVoFDPMFoam
1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888  /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayLiquidEOS.so
f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896  /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayFiveEqThermo.so
```

EOS v3 coefficients SHA610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac，energy reference SHAed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef，C_L369229.9537234281不变。before/after source manifest与空patch独立保存。MILESTONE_STATUS只在保护审计完成后追加。本轮archive/seal独立保存，避免报告与archive SHA循环依赖。

## 36. Milestone matrix

| Milestone | Status |
|---|---|
| PHASE-DEFER | COMPLETE / POLICY FROZEN / 历史CLASS D保留 |
| EOS3-NUMERICAL | COMPLETE / OPERATIONAL DOMAIN FROZEN 265–400 K |
| ADM1 | COMPLETE / OUTCOME C |
| TD1 | PARTIAL / LOCAL CORRECTNESS PASS / EFFICIENCY UNRESOLVED |
| TD2 | PARTIAL / DIAGNOSIS CLOSED / MICROSTEP ADMISSIBILITY LIMIT / STOP |
| IDP1 review | NEXT ROUND ONLY；本轮无source change |
| M6B1 / M6B | PARTIAL |
| DYN-CLOSURE | NOT AUTHORIZED |
| M6B2 / DPM / production | NOT AUTHORIZED / NOT EXECUTED |
| T4-S1/S2 | FROZEN |
| T4-S3 | DEFERRED |
| T4 / M8A | PARTIAL |

STOP。未自动执行DYN-CLOSURE、IDP1 source changes、EOS changes/v4、M6B2、DPM、T4-S3或production CFD。
