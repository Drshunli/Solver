# Gas-energy dependency audit for the five-equation KT path

Current legacy total-energy storage is `rhoE=rho*(e+|U|²/2)` from
`createFields.H`. Directed gas KT `phiEp` uses gas `rho,e,p,U`, with an
absolute pressure-work correction on moving meshes. `rhoEEqn.H` advances
`rhoE`, recovers gas `e`, calls `thermo.correct()`, then sets `p=rho/psi`
and reconciles density at boundaries. The non-inviscid auxiliary branch also
uses turbulent heat diffusion, gravity and `parcels.Sh(e)`. The visible
`parcels.Sh(e)` calls are not unconditional: one is commented and one is
inside `if (!inviscid)`.

Future `Et` is **mixture total energy**, transported by `F_E` from the same
two-material KT state as `F_mG/F_mL/F_M`. It contains phase internal energies
`mG*eG+mL*eL` plus common kinetic energy. The legacy gas `rhoE` cannot be
renamed `Et`. The common pressure, separate `TG/TL`, liquid EOS and shared
energy reference must be recovered consistently before the switch.
`ENERGY_REFERENCE_AUDIT.md` remains a blocker for phase change and later
VOF-to-DPM transfer. This audit changes no active equation.
