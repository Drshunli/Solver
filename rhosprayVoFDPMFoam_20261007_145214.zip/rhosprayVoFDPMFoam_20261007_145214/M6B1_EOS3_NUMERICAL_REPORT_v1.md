# M6B.1-EOS3-NUMERICAL — 最终报告

日期：2026-10-05。证据目录：`fitting/integration/m6b1_eos3_numerical_v1/`。

## 1. Combined PHASE-DEFER/EOS3 status

**PHASE-DEFER = FROZEN；EOS3-NUMERICAL = PARTIAL / EOS3_NEW_DOMAIN_BLOCKER / STOP。** v3 已安装，属性回归通过；原 shock 重放发现新的合法域内公共压力根失败，不能将本阶段标为 COMPLETE。

## 2. Phase-certification scope

固液相认证明确 DEFERRED / NOT CLOSED。HARD 仅指 numerical EOS admissibility。没有熔化、冻结或相平衡模型，不宣称完整矩形为稳定液体。

## 3. Preserved CLASS D

LB2B/LB2C 的历史 CLASS D / UNRESOLVED 保留，原目录、metadata、证据及封存包未覆盖。5% 仅为未来 Tmelt 证据精度要求，不进入 EOS/R1/守恒/时间推进容差。

## 4. Active EOS version

`ndecane_gibbs_v3` 已 active。资格为 **ACTIVE / PROPERTY-REGRESSION NUMERICALLY QUALIFIED / SINGLE-LIQUID CONTINUATION / NOT SOLID-LIQUID PHASE CERTIFIED**。这是属性资格，不代表整个 shock 或本 milestone 完成。

## 5. v1 preservation

`liquidEOS/ndecane_gibbs_v1/` 全部既有文件与保护清单逐项 SHA 一致。HISTORICAL / PRESERVED。

## 6. v2 preservation

`liquidEOS/ndecane_gibbs_v2/` 全部既有文件与保护清单逐项 SHA 一致。PRESERVED / PREVIOUS ACTIVE。原安装 executable 和两个自定义库另存 `runtime_before/`。

## 7. v3 source delta

新建独立 `ndecane_gibbs_v3/`；复制冻结的 degree8×8 Gibbs potential，仅改版本符号。`potential_identity_gate.json` 确认正规化后 header 相同、81 系数相同、energy_reference 字节相同。没有 refit、运行时 CoolProp 或外推。

三个既有源文件变化：factory 绑定 v3；liquid evaluator 必要 legal Tmin 285→275；dynamicObservation 增加只读 low-T 输出。最后一项不改变状态、拒绝判据、方程或时间步。

## 8. Factory/versioning

`productionLiquidEOSVersion()` 返回 v3。冻结 P2IO 的 write 动态写入版本，read 默认要求 production 版本；原 v1/v2 accepted restart 不被静默解释为 v3。十个微算例输出均使用 v3 tag。冻结 v1 freshInitial 仅用于显式 step0/time0 初值，不是生产 restart 认证。

**补充 fresh restart read/write 测试未闭合**：独立工具两次链接失败，已补足 PrecisionRecovery 源依赖，但其后执行被自动审批系统因 usage-limit review failure 拒绝。未绕过审批，未声称运行 PASS。生产 restart 始终 NOT CERTIFIED。

## 9. HARD/NORMAL domains

| 域 | p / MPa | T / K | 含义 |
|---|---|---|---|
| HARD | 0.05–12 | 275–330 | 数值 EOS 合法域 |
| NORMAL | 0.1–8 | 295–305 | 冻结正常资格域 |

压力范围不变。不延伸到 <275 K 或 >330 K。

## 10. Coefficients SHA

v1/v2/v3 均为：

`610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`

## 11. C_L

`C_L_production = 369229.9537234281 J/kg`。`e_solver=e_native+C_L`、`h_solver=h_native+C_L`。gas JANAF 和 DPM 参考未改；未来相间转移账本仍需单独认证。

## 12. Compile result

EOS library、thermo library、active main 均执行 fresh wclean/wmake，PASS。追加只读监测后主程序再次 fresh 编译 PASS。0 errors；恰好三条既有 dynamicObservation misleading-indentation warnings，无新增意外 warning。隔离 capture 程序编译 PASS；独立 restart 辅助程序未编译成功，分开记录。

## 13. Lower EOS regression

active factory fresh LOWER 275–285 K：9,801 点 PASS。rho/e/h/Cp/Cv/beta/c/dpDe/dpDrho 全部满足冻结预算。参考为冻结 HEOS reference-EOS 输出，不能当作实验或固液相证据。

## 14. Old-domain regression

285–320 K：3,721 点 PASS。九属性与 frozen v2 原 PT 输出 direct bit mismatch = 0。

## 15. Upper EOS regression

320–330 K：3,721 点 PASS。合计 17,243 点；inverse invalid=0；max inverse T error 1.8189894e-12 K、p error 4.1928142e-6 Pa。域外严格拒绝 PASS；未降低预算。

## 16. 130 active R1 result

130/130 PASS；每个 5 iterations；maximum normalized residual 8.570596875729471e-16。p/TL/cL/cA 明细在 `v3_recovery.csv`，没有 phase deletion、压力/温度 clamp 或容差变更。

## 17. old184 result

184/184 PASS。与冻结既有结果的 p/TG/TL/cL/cA 最大差均为 0。先前 320 K 上界问题保持消除。

## 18. Accepted-state neutrality

6,200 个 fresh accepted states 均 PASS。5,500 prior 状态 max |Δp|=1.862645149230957e-9 Pa；700 lower 邻近状态 max |Δp|=3.039836883544922e-6 Pa。分别报告误差，未因源码相同自动认定 PASS。

## 19. Corner representation contract

冻结 280 controls：279 合法 PASS、1 非法预期 REJECT；额外 12 controls：7 合法 PASS、5 预期 REJECT；unexpected failures=0。primitive endpoint PASS。alpha=.9/12MPa/275K outward one-ULP 状态继续严格拒绝。nextafter 仅用于离线测试构造，未用于 runtime time advance 或容差放宽。

## 20. M6B.0 rerun

最终 active executable 完整重跑 gas/liquid/mixed01/mixed05/mixed09/traceLiquid/traceGas/contact/speciesContact/smooth：全部正常退出，314 项原 physical checks PASS；accepted R1 failures=0；P2 exact、species closure、trace invariant PASS，无 normalization/clipping。

最大 conservation relative：contact 1.513712421516094e-16，smooth 8.986962667900404e-17；uniform 为 0。`M6B0_rerun_gate.json` 保存原阈值及结果。先前报告的 326 含额外 authority audits；本轮 314 是原微算例 physical checks 数量，权限与保护审核另行报告。

## 21. Shock replay

原 shockInterface_100 的 17 个输入文件哈希一致，包括 mesh、初值、CFL、时间/重试策略、endTime=0.00055 s。active replay 执行后被外部观察器停止：不是正常达到 endTime，不是 CFD 生产验证。

隔离只读 SR1 capture 使用同一 active v3 库，未安装为 active executable；没有内部时间推进 guard。与 active 完整 dynamic history 共 159 行（step0–158）逐字段文本相同，捕获证据可信。外部 SIGTERM 是观察停止，不是求解器内的修复。

## 22. Old anchor114/cell45 result

冻结原 v2 candidate Q 使用 active factory fresh 恢复：p=3286242.7933805487 Pa，TL=284.87337272286942 K，normalized residual=0，iterations=5，cL=1306.7005967541158 m/s，cA=564.90551172964535 m/s。原 285 K 下界阻塞消除。

这是原 candidate 的离线恢复证据；新轨迹越过原阻塞，但不假设新 trajectory 的 anchor114 Q 与原轨迹完全相同。

## 23. First new rejection

**anchor153 / cell27**，time=0.00018437909654840973 s，trial dt=1.2050921343033288e-6 s：`NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN`，iterations=0。

| 量 | 值 |
|---|---:|
| alphaL | 1.8383391125689919e-21 |
| mL | 1.2953725683309386e-18 kg/m³ |
| intrinsic rhoL | 704.6428808886717 kg/m³ |
| common p interval | 398112.29210756649–3117392.9514925238 Pa |
| F(lo) | −7411003.344995616 J/m³ |
| F(hi) | −383776.35526529886 J/m³ |
| F′(lo), F′(hi) | 2.3879862840061099, 2.8189811654658032 |
| TL(lo), TL(hi) | 326.63461942591283, 329.99999999999989 K |

合法公共区间没有能量根，上端点被 liquid 330 K 限制。**EOS3_NEW_DOMAIN_BLOCKER**，不能归为纯 temporal blocker。未计算域外 root、未外推或生成 v4。gas-only pressure 是只读诊断，不冒充 candidate common root。

## 24. dt history

step154 accepted dt=6.977512364266908e-8 s；step155=2.2372049818605705e-18；step156=8.3421209547437562e-20；step157=4.9071299733786278e-21。四次 main 拒绝及 129 个 probe candidate 捕获均同一 common-root-domain 原因。

probe stream 因外部停止只完整发布72行；129来自完整 capture events及独立 Q文件，二者不混报。`dt_history.csv` 保存 accepted/retry/fresh-bound/ULP。

## 25. Time-progress behavior

first nonprogress step157，time 停在 0.00018444887167205475 s；ULP=2.7105054312137611e-20 s，dt/ULP≈0.18104114。fresh joint/acoustic bound≈1.2050921782030604e-6 s。time inherited collapsed dt，说明时间策略技术债仍在；本轮不修。

active 外部停止后完整记录到 step159；这不是额外授权的继续推进。终止观察延迟产生尾部记录，所有不完整行明确剔除。

## 26. TL<285K diagnostics

160 accepted summaries、380 low-T cell records；首次 step115；最多13 cells。最低 TL=278.59992814822976 K（cell48）；最大积分 low-T 液体质量=5.661080900029999e-8 kg（本单位面积周期微算例）。

alphaL 范围 3.9843573172921314e-21–6.59741915156695e-9，mL 范围 2.9449853051470472e-18–4.88638527554869e-6 kg/m³。质量按 Σ volume×mL 只读计算并逐步复核。没有基于285K阈值修改任何解。

## 27. Remaining blocker

首要 blocker：**新 common-root 合法域失败，liquid upper 330 K**。另有 temporal-policy collapse、补充 fresh restart 工具未闭合。不能把 EOS blocker 消失的 OUTCOME B 用于当前情况。

## 28. TD1 status

REQUIRED / SEPARATE STAGE / NOT EXECUTED。没有 dt growth/reseed/floor、nextafter advance、t+dt guard 或 connectedDt redesign。

## 29. Physical-phase limitation

TL<285K 使用 numerical single-liquid continuation。全 HARD 不具备 experimentally certified stable-liquid、melting、freezing 或 phase-equilibrium 资格。历史 CLASS D 永久保留；本轮没有认证当前 trace low-T states 为稳定液体。

## 30. Executable/library SHA

| 构建产物 | SHA-256 |
|---|---|
| active executable | 50c19e1be182bec08cee0a91d77ab44dee5e654ddf143ef86fc5082e617fcecd |
| libRhosprayLiquidEOS.so | a0e6595610b4b296a1da3f678ef5b6403c59891662a8100128a158a07d4773ca |
| libRhosprayFiveEqThermo.so | d92f7e2af8da03e87fdf4a76ef3e4e62a01e556b58540f53e73a2af24b578512 |

55个运行依赖中53个原哈希不变，仅上述两个自定义库更新。installed before/after tests 一致；runtime copies保留。production restart NOT CERTIFIED。

## 31. Foundation hashes

Foundation 6,717 / native parcel19 全部 SHA PASS；只读重新读取8个 gas/patch 文件并保存 source manifest。本轮没有修改系统 OF7。

## 32. Project hashes

37,020项历史保护基线核对。仅允许三个已声明 source 文件、对应生成 runSerialFiveEq.o 及 milestone append；其余必须原 SHA。不允许修改冻结 P2/R1/KT/reconstruction/Allaire/K=0 alpha/species/temporal/retry/Time。新增 source manifest、before副本、patch、exclusive checkpoint及封存结果另存证据目录。

## 33. Production impact

production inputs不变；active DPM=NO；MPI production=NO；production crossflow/atomization/CFD/restart=NO。active serial factory确实已经换为v3，不报告“active无影响”。三个文件和两个库更新范围已明示。

## 34. Whether EOS3 COMPLETE

**NO：PARTIAL / EOS3_NEW_DOMAIN_BLOCKER / STOP。** 安装、属性回归、旧域问题闭合均不替代新 blocker gate。没有因 temporal failure 反算 EOS3 failure；这里有独立 EOS 公共根域证据。

## 35. Next permitted milestone

本轮没有任何进一步执行授权。建议下一轮单独授权 **anchor153/cell27 exact-Q upper-bound reference/domain classification**：先解释新状态和合法域，再决定候选模型/域策略。不自动扩 v4，不先改 TD1，不删除 trace phase。

## 36. M6B.1 status

M6B.1 = PARTIAL；M6B=PARTIAL。PHASE-DEFER政策冻结完成；EOS3本阶段未完成。剩余 wave ladder、RH、high-Mach、M6B.2、active DPM、T4-S3和production 均未执行。

## 37. Milestone matrix

| 阶段/对象 | 最终状态 |
|---|---|
| M6B.0 | COMPLETE / FROZEN / active v3 fresh rerun PASS |
| SR1 | COMPLETE / DIAGNOSIS ONLY |
| EOS1 | COMPLETE / FROZEN |
| LB2 Part A | COMPLETE / FROZEN |
| LB2B / LB2C | PHYSICAL CERTIFICATE DEFERRED / NOT CLOSED |
| historical phase class | CLASS D / PRESERVED |
| PHASE-DEFER | FROZEN |
| ndecane_gibbs_v1 | HISTORICAL / PRESERVED |
| ndecane_gibbs_v2 | PRESERVED / PREVIOUS ACTIVE |
| ndecane_gibbs_v3 | ACTIVE / PROPERTY REGRESSION QUALIFIED / SINGLE-LIQUID CONTINUATION / NOT PHASE CERTIFIED |
| EOS3-NUMERICAL | PARTIAL / NEW DOMAIN BLOCKER / STOP |
| TD1 | REQUIRED / NOT EXECUTED |
| M6B.1 / M6B | PARTIAL |
| M6B.2 | NOT AUTHORIZED |
| active DPM / production CFD | NO |
| T4-S3 | DEFERRED / NOT EXECUTED |

**STOP。**
