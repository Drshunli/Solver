# M6A1b-2B — production liquid EOS competition (2026-09-30)

## 1. Status

**PARTIAL / NO PRODUCTION EOS ACCEPTED.** 2B.1 reference dataset is COMPLETE;
2B.2 four implementations compared; 2B.3 cannot accept a model because all
have required failures. No M6A2, active EOS/phase-mass/KT changes or CFD run.
Results do not assert that every possible NASG/MG extension is inadequate.

## 2–7. Reference and sampling freeze

CoolProp 8.0.0, HEOS n-Decane, native DEF; exact revision/fluid hash and
Lemmon–Span 2006 source in dataset metadata. All state rows are
**REFERENCE-EOS GENERATED**, never experimental. New dataset path:
`fitting/referenceEOS/ndecane_m6a1b2b_v1`, not the 2A assessment CSV.

NORMAL 0.10–8 MPa / 295–305 K and HARD 0.05–12 MPa / 285–320 K unchanged.
916 NORMAL training points (31x21 backbone, Halton, inlet cluster); 924 NORMAL
holdout points (staggered, separate Halton, independent edges); 413 explicitly
tagged low-weight BUFFER calibration support plus 1245 separate BUFFER
robustness points; 196 inlet/isentropic/dissipative screening path points.
Training and holdout PT intersections are zero. Path anchors may repeat training
and are not misrepresented as independent holdout. Buffer support is weighted
0.1 only for surrogate calibration and never scored as holdout.

Store p,T,phase,rho,e,h,s,Cp,Cv,c,kappaT,alphaP,Ks, pressure/energy derivatives
and Gibbs-potential values/derivatives. Dataset CSV hashes, metadata self-hash,
generator hash, max/P50/P95/P99 identity residuals and finite-difference QA are
retained. Maximum acoustic identity residual is 1.269e-12; other identities
pass the 1e-8 reference gate. Analytic derivatives use documented fixed
rho/e coordinates; matching-pair perturbations are retained in README.

Independent experiment CSV contains 14 Prak 2024 rho/c measurements and ten
Regueira 2017 Cp measurements imported from prior sourced transcription.
These are not fitted as reference-generated rows. Cp measurement points lie
outside the project range and are compared to HEOS only: **no in-domain
independent Cp certification claimed**. Rho/c uncertainty not available in the
existing transcription; Cp expanded uncertainty 0.4%. Source DOIs, pressure,
temperature, kind and coverage are explicit. Indep. here means not used in
this fit, not proven excluded from historical reference-EOS construction.

## 8–11. Reduced models and conventions

NASG uses v=1/rho, a=(gamma-1)*Cv:

    p+pInf=a*T/(v-b)
    e=q+Cv*T+pInf*(v-b)
    h=q+gamma*Cv*T+b*p
    c^2=gamma*(p+pInf)/(rho*(1-b*rho))
    Cp=gamma*Cv; beta=(v-b)/(gamma-1).

Derive p(rho,e)=(gamma-1)*(e-q)/(v-b)-gamma*pInf. Parameters are constrained
and fitted to NORMAL rho/c/Cp; q is a native energy anchor, not an accepted
solver parameter or a density/sound-speed fitting knob. Its constant caloric
structure and poor energy slope/inversion fail current gates. Numeric fit is
recorded, but no dictionary is written.

MG uses a thermodynamically closed Helmholtz potential:

    a(rho,T)=A(rho)+T*B(rho)+Cv*T*(1-log(T/300))
    e=A(rho)+Cv*T; p=rho^2*(A'+T*B')
    Gamma(rho)=rho*B'/Cv
    T(rho,p)=(p/rho^2-A')/B'; beta=Cv/(rho^2*B')
    p_rho|T=2p/rho+rho^2*(A''+T*B'')
    Cp=Cv+T*p_T^2/(rho^2*p_rho|T)
    c^2=p_rho|T+T*p_T^2/(rho^2*Cv).

A/B are cubic density Chebyshev polynomials, Cv constant. All formulas come
from one potential; the model is not only a mechanical p-rho fit. The entropy
constant B0 does not affect state properties (a null fit column). Positive
derivatives/inversion/domain checks are required. It still misses beta/Cv and
pressure inversion targets. Initial higher-degree/root-bracket assessment was
repaired before the final cubic competition; thresholds were not changed.

## 12–13. Two surrogate/table strategies

TABLE-B: one degree-(8,8) Chebyshev **Gibbs potential g(p,T)**, constrained by
g and analytic first/second derivative observations with one coefficient vector:

    v=g_p; rho=1/v; s=-g_T; h=g-T*g_T; e=h-p*v
    Cp=-T*g_TT; Cv=Cp+T*g_pT^2/g_pp
    c^2=-v^2/(g_pp-g_pT^2/g_TT)
    beta=T*(-g_pT+g_TT*g_pp/g_pT).

Only derivatives of this potential determine properties: no unrelated c/Cp
splines. Runtime rho,p calls invert v(p,T)=1/rho inside HARD; pure-liquid
rho,e inversion requires both valid pressure and recovered-temperature bounds.

TABLE-A: direct degree-(8,8) e(rho,p) representation, e and beta derivatives
from the same polynomial; T comes from the common Gibbs source, and Cp/Cv/c
are derived via T derivatives, not independent property splines. The additional
integrability identity e_rho|T=(p-T*p_T)/rho^2 is explicitly scored. This pilot
is an assessed approximation, not guaranteed thermodynamic-potential closure.
It retains Gibbs inversion cost and fails boundary robustness despite excellent
interior interpolation. TABLE-B is the cleaner consistency architecture.

Both use NORMAL plus separated low-weight support. These coefficients are
offline candidates; their existence does not signify a production acceptance.

## 14–22. Per-property errors

Full MARE/RMS/MAX/P95/P99 for training, independent validation, BUFFER and
physics paths, plus separate experiment comparisons, are in competition_results.json.
Absolute e/h metrics are scored because native-relative energy errors alone can
hide defects. Statistics for failed domains are conditional on evaluable points;
failure counts are mandatory and prevent acceptance.

NORMAL holdout maximum relative errors (%):

| Candidate | rho | e | h | c | Cp | Cv | beta | dp/drho at fixed e | dp/de at fixed rho | max pressure error Pa |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NASG | 0.320032 | 3.40798 | 3.41158 | 0.533585 | 0.998301 | 17.4049 | 96.5128 | 1.17949 | 49.1127 | 3.36741e+06 |
| MG_closed | 0.000966244 | 0.0145991 | 0.0150414 | 0.301931 | 0.81669 | 1.21148 | 1.73815 | 0.599167 | 1.74664 | 28277.4 |
| TABLE_A_directEnergy | 8.70815e-10 | 6.72662e-10 | 1.04311e-09 | 3.39335e-09 | 5.64284e-08 | 5.54285e-08 | 2.96674e-09 | 6.73757e-09 | 2.96676e-09 | 0.00139185 |
| TABLE_B_GibbsPotential | 8.70815e-10 | 4.54871e-09 | 5.01083e-09 | 3.30582e-08 | 2.8894e-09 | 1.29885e-08 | 6.83141e-08 | 6.61162e-08 | 6.83141e-08 | 0.00933155 |

Synthetic inversion uses REFERENCE rho and native e, not candidate-generated
energy, so it measures modeling pressure errors instead of merely self round
trip. Reference-energy shifts are tested with corresponding inverse translation.
Beta and the two pressure derivatives have separate hard gates. Allaire cMix
is tested at alphaL=0,.01,.1,.5,.9,.99,1 with a frozen air 400 K state at each
shared pressure. This is one representative gas thermodynamic family, not a
shock-state survey; broader gas-state testing remains necessary before M6A2.

## 23–24. Acceptance and boundary failures

Gates were stored before competition in m6a1b2b_config.json. NORMAL max budgets:
rho 0.2%, c 0.5%, Cp/Cv/each thermodynamic derivative 1%, e/h absolute 100 J/kg,
pressure both 500 Pa and 0.5%. BUFFER budgets and integrability/cost limits are
separate and were not loosened after results.

| Candidate | NORMAL | BUFFER | Reference-state evaluation/inversion failures in BUFFER |
|---|---|---|---:|
| NASG | FAIL | FAIL | 753 |
| MG_closed | FAIL | FAIL | 87 |
| TABLE_A_directEnergy | PASS_NORMAL | FAIL | 59 |
| TABLE_B_GibbsPotential | PASS_NORMAL | FAIL | 99 |

Reduced candidates have genuine accuracy/derivative failures. TABLE-A/B pass
NORMAL and paths, but inclusive HARD boundary reference inputs can have no
root inside the candidate's valid pressure/temperature interval. Approximation
error near a boundary is not cured by silent endpoint pressure clipping or
thermodynamic extrapolation. Current prototype also lacks a complete accepted
endpoint-root policy: own-EOS NORMAL round trips do not certify HARD endpoints.
This is a candidate inversion/coverage gate failure, not a newly found reference
EOS inconsistency, so no approved envelope was changed and 2A remains COMPLETE.

## 25–26. Performance, coordinates and memory

Python timing is diagnostic and cannot fairly be compared with native C++.
First pass, warm calls and a 64 MiB eviction proxy are recorded for every model.
This proxy is not privileged hardware cold-cache control. Analytic candidates
already fail correctness; their native cost gate is not certified. TABLE-B has
a true NumPy vectorized rho,p batch; other Python batches are scalar loops.
Native prototype timings below use g++ -O3 -std=c++11 in WSL, normal states.

TABLE-B native warm 0.314042 us/state, first 0.308258, eviction proxy 0.318719; batch is a native scalar loop, no SIMD claim. For N cell calls, F face calls and k root iterations estimate (N+F)*k*0.314042 microseconds as arithmetic-only cost, not measured CFD overhead.

| Coordinate | Python measured us/query | Inversion/conditioning |
|---|---:|---|
| p,T | 70.31 | direct potential; runtime fixed rho needs additional T solve |
| rho,p | 158.1 | bounded T inversion; beta available from same potential |
| rho,T | 65.37 | pressure inversion (benchmark excludes full property evaluation); low compressibility amplifies density error |

Coordinate timings are operation-specific, not identical workloads. rho,p is
the solver access pattern but not automatically the fastest potential layout.
Numeric coefficient memory: TABLE-B 648 base bytes or 3888 padded native
derivative bytes; TABLE-A adds 1800 bytes and still needs the potential. Reference
CSV rows are not runtime table nodes. Each MPI rank would replicate these arrays;
no per-cell/per-face cache is included. JSON/source/executable file sizes are
separate from numeric coefficient memory. Native prototype speed/memory pass
the provisional budgets but cannot override BUFFER failure.

## 27–28. Selection

**Selected production EOS: NONE.** NASG and this closed MG instance rejected
by current accuracy/inversion gates. TABLE-A/B not accepted due BUFFER/domain
inversion failures. TABLE-B is a promising next candidate, not a runtime choice.
No dictionary or final rhosprayLiquidEOS class was generated.

## 29. Energy mapping

Freeze a canonical SENSIBLE ledger at pRef=3 MPa, Tstd=298.15 K:

    hL_solver=hL_native+C_L; eL_solver=eL_native+C_L
    C_L=-hL_native(pRef,Tstd)
    gas stays Es=Ha-Hc-p/rho; DeltaGas=0
    DPM stays Hs=hOF7(T)-hOF7(298.15).

For HEOS native DEF C_L=369229.953724952764 J/kg; raw OF7 h-to-DPM sensible offset=2110760.371415720787 J/kg. Each candidate's explicit anchor translation is stored separately. Since no model is accepted, no production-specific C_L is promoted.


This aligns a declared sensible ledger, not absolute formation/latent physics.
Gas Hc remains separately represented. Liquid EOS and DPM caloric functions
differ beyond a constant offset: at 300 K their sensible enthalpies differ by
about 44.067 J/kg. Transfers must conserve actual donor/receiver energy and
pressure/kinetic work, possibly recover a receiver temperature; equal T is not
an automatic conservative transfer. Phase change/reaction Ha/hl reconciliation
and source implementation remain later gates. No latent/formation value guessed.

## 30–32. API, tests and compilation

Frozen M5B.1 API remains stateRhoP / statePT / pure-liquid pFromRhoE, beta,
c,Cp,Cv and diagnostic validity. No final production API/class accepted.
Each model passes 19 basic interior round-trip, invalid, offset and finite-
difference checks, but full suite remains FAIL because BUFFER is mandatory.
Native TABLE-B evaluator prototype compiled and passed 128 NORMAL golden
states and four INVALID rejections. It is not a complete final EOS library,
does not implement common-pressure recovery and is not solver-linked.

## 33. Active solver impact

**NONE**: ten protected main/equation/initialization/Make files unchanged.
No wmake of the solver needed; standalone g++ PASS only. Existing gas thermo,
KT fluxes, DPM, alpha equation and all approved operating inputs preserved.

## 34–35. Next gate and milestones

M6A1b-2B overall PARTIAL / NO PRODUCTION EOS ACCEPTED. 2B.1 COMPLETE;
2B.2 comparison performed; 2B.3 NOT ACCEPTED. M0–M4, M5A/M5B/M5B.1,
M6A1a and 2A remain complete. Constant SG remains rejected. M6A2 and two-phase
KT remain NOT STARTED. Before M6A2: repair/certify inclusive domain inversion,
accept one EOS under unchanged per-property gates, finalize candidate-specific
C_L and complete standalone NORMAL/BUFFER/INVALID/API tests. No common-pressure,
flux or CFD work starts here. STOP.
