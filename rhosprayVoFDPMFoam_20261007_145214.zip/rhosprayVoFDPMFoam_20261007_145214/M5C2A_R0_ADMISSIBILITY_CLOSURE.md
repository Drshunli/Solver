# 1. M5C.2A status

**COMPLETE / STANDALONE TESTED DOMAIN.** All 24 requested engineering gates pass under the controlled EOS-stop semantics below. No CFD. This closes the tested R0 prerequisite, not the entire reconstruction milestone or an arbitrary-state mathematical invariant-domain proof.

# 2. Original R0 failure preservation

Original reports, CSVs, logs, manifests and checkpoint remain unchanged: 21/42 old failures = 6 TRACE_PHASE_POLICY_CONFLICT + 3 NUMERICAL_THERMO_INADMISSIBILITY + 12 PHYSICAL_EOS_DOMAIN_ESCAPE. Additional historical_v1.zip contains pre-change recovery/bridge/test sources and evidence. An isolated historical-v1 library replay records accepted Qn and actual KT left/right face fluxes into original_paths.csv; those are replay evidence, not replacements for old results.

# 3. Phase-presence v1 problem

The v1 predicate rejected alpha<=64epsilon when mass exceeded a mixture-relative tolerance. A physically consistent dense liquid trace violated that predicate even though mL/alphaL and energy were correct. No phase deletion was present in v1; the defect was a magnitude-based rejection.

# 4. Phase-presence v2 definition

See FIVE_EQ_PHASE_PRESENCE_CONTRACT_V2.md and hashed phase_presence_contract_v2.json. Nonzero phases require finite positive intrinsic density and legal EOS/common-energy recovery. 64epsilon is only a diagnostic marker. Absolute/relative mass marker settings do not select or delete phases.

# 5. ABSENT definition

Exact alpha=0 AND partial mass=0 AND associated conservative species masses=0. Pure routing is permitted only then. MaterialCell checks conservative gas species masses before the bridge; intrinsic YG is undefined/unused for absent gas.

# 6. TRACE_PRESENT definition

alpha>0 and m>0 with finite thermodynamically legal m/alpha. Same EOS/root/acoustics as PRESENT; no mass, alpha or Et mutation. An invalid common-energy root still rejects the state.

# 7. PRESENT definition

Ordinary consistent nonzero phase. It differs from TRACE_PRESENT only in the roundoff diagnostic label, not in physical recovery or flux.

# 8. INCONSISTENT definition

Absence with mass, presence with zero mass, nonfinite/nonpositive ratio, density with no legal EOS state, or inconsistent species masses reject. Subnormal precision is separately reported as PHASE_PRECISION_UNRESOLVED, not passed off as the original threshold conflict. No silent extinction.

# 9. Trace-phase regression

The exact old witness alphaL=6.9241358403509355e-15, mL=5.0368446335644225e-12 recovers rhoL=727.43296054531777 kg/m3, p=2999999.9999999995 Pa, TL=300 K. Relative pressure error=1.5522e-16. Both mass and alpha are unchanged. See tests/fiveEqRecoveryV2/v2_trace_states.csv.

# 10. Near-zero matrix

Required 1e-4,1e-8,1e-12,1e-14,1e-16 matrix passes; impossible intrinsic liquid density at each alpha rejects. Additional 1e-300 and minimum-normal alpha=2.2250738585072014e-308 pass. Subnormal alpha/mass fails with controlled precision diagnostics. No claim of infinite trace tracking; future conservative phase extinction is unresolved.

# 11. M6A2.1 regression result

2096 tests PASS / zero failures: all original 2087 checks plus nine v2 trace/precision checks. Original tests/outputs remain frozen.

# 12. M6A2.2 regression result

38 tests PASS / zero failures: original 32 checks (one v1-specific rejection reason versioned to the actual EOS reason) plus six trace/precision checks. The v1 test is retained; the invalid state still rejects. Diagnostic enum additions preserve all old code values.

# 13. M5C.1 regression result

34902 assertions PASS: legacy pure gas, pure liquid, mass/species identities, contact, pressure work, ALE/GCL. All fiveEqFlux source hashes unchanged. No KT coefficient or equation modifications.

# 14. Contact-tail result

Stationary/moving/ALE contacts: N=20 completes 100 steps; N=60/200 complete 10 each. All six old tail rejections disappear. No deletion/normalization/forced pure branch. 405 uniform matrix cases also pass.

# 15. Trace intrinsic-density result

All contact-state maximum relative rhoL drift=5.762057498e-14; maximum rhoG drift=1.681625815e-05. The gas maximum occurs in ALEContact N=60, step 9, cell 50, alphaG=2.4870e-12: cancellation in 1-alphaL amplifies roundoff. Its normalized volume/mass compatibility defect alphaG*relative drift=4.182221223e-17, below binary64 epsilon. This is conditioned floating-point error, NOT machine-epsilon relative accuracy of every intrinsic-density ratio. Liquid tail-only drift is below 9e-16. No density repair.

# 16. Trace pressure result

Maximum contact pressure relative error=2.473918721e-11; recorded near-zero tail pressure maximum=1.603427033e-13. The exact frozen trace witness has 1.5522e-16 relative pressure error. No pressure spikes or EOS tail failures in this suite.

# 17. Mixed-shock continuation method

Use the EXACT historical accepted Qn and face fluxes, not interpolation between unrelated primitive states. V(lambda)=Vn+lambda*dtCandidate*D; every conservative field follows (Vn*Qn-lambda*dtCandidate*deltaF)/V(lambda). Alpha follows the frozen alphaEulerStep expression alpha_n+lambda*dtCandidate*Nalpha/V(lambda). All scalar/species constraints and real bridge EOS recovery are checked. Original paths use 128 subdivisions with 64-subdivision crosscheck; global stepping uses 32.

# 18. Mixed-shock failure root cause

All three original failures occur at zero-based step 8 (ninth proposal), cells 7/27/97. Legal common-pressure intervals remain nonempty, but R(pMin) becomes positive: minimum legal mixture energy exceeds the proposed internal energy. The first exit reaches liquid TL=285 K, not a JANAF boundary or derivative failure. First overshoot is fixable by dtThermo (YES); continued outward evolution AFTER landing on the boundary is certified-domain exhaustion, not fixable by shrinking CFL.

# 19. dtThermo definition

dtThermo=lambdaValid*dtCandidate, where lambdaValid is the last actually recovered legal point. No 0.1 or empirical thermal factor. Exact certified outward boundary has dtEOS=0. Historical 0.95 scalar-bound safety remains separate.

# 20. dtThermo numerical algorithm

Validate lambda=0; increase deterministically from zero; stop at the FIRST sampled invalid transition; bisect its valid/invalid bracket for up to 52 iterations, or floating-point stagnation; retain last verified valid point; never search later re-entry. Pressure initial guesses are unnecessary here. 64/128 original-path searches agree within 1e-12 in lambda. Finite sampling does not certify arbitrary unsampled intervals: this is an engineering regression gate, not a formal interval-arithmetic proof. Configuration bounds, invalid start and zero positive interior margin remain explicit failure conditions.

# 21. Common-pressure bracket evolution

Original_mixed_continuation.csv tracks lambda, bracket endpoints, both energy residuals, root p, TG/TL, cMix and recovery code. Original lambda=1 residual minima are +960817.9296 J/m3 (N20), +960441.4497 (N60/200), while residual maxima remain about +36.023 MJ/m3. At the last legal point p=pMin≈1.183532 MPa, TL=285 K, TG≈467.448 K and cMix≈748.943 m/s. Endpoint residual acceptance uses existing energy tolerance, never a manual pressure assignment.

# 22. Mixed-shock rerun

Rerun: all three profiles accept nine global steps. The ninth proposal is shortened by approximately 0.75, then next proposal correctly stops before commit at outward TL=285 K. They do NOT complete the originally requested 10/100 steps. Outcome is CONTROLLED_EOS_STOP, separate from 27 fully advancing PASS profiles. Global minimum dtThermo/dtAcoustic=0.750041995; three retries. 1494792 extra cell continuation recoveries; per-profile wall times in r0_cases.csv. Aggregate measured profile time=9.66115 s versus historical 0.908686 s; this is a standalone timing observation, not a production-speed comparison.

# 23. Joint timestep formula

dtCandidate=min(dtAcoustic,0.95*dtAlpha,0.95*dtMG,0.95*dtML,0.95*dtSpecies,0.95*dtVolume). dtAccepted=min(dtCandidate,min_cells dtThermo). Scan cell paths with frozen low-order faces, compute global admissible bound, retry real trial update of ALL cells, then commit atomically only after all recoveries pass. Controlled boundary stop precedes commit.

# 24. HARD-domain semantic distinction

HARD p=[0.05,12] MPa, TL=[285,320] K certifies the production EOS; it is not an invariant set of the five-equation PDE. Outward derivative at a certified boundary gives zero admissible future margin. Pure-state tests supply exact original boundary seed metadata, crosschecked against recovered p/T; near-boundary proximity alone is not declared physical escape. Mixed boundary checks use exact recovered EOS endpoints and the actual gas/liquid thermodynamic derivatives, including species-composition and ALE terms. Boundary inversion residuals retain frozen tolerances. A truly unresolved interior-zero-step remains numerical failure.

# 25. HARD-inward result

Four isolated boundary-cell KT stencils (pMin,pMax,TMin,TMax) with inward tangents accept a positive real update: pMin→1.389275 MPa; pMax→10.596426 MPa; Tmin→285.272582 K; Tmax→319.742516 K. These are one-cell synthetic stencil tests with frozen neighboring states, not a multidimensional CFD case or global multi-step boundary-condition validation.

# 26. HARD-outward controlled-stop result

All original 12 N=20/60/200 exact outward profiles stop with zero committed steps and PHYSICAL_EOS_DOMAIN_ESCAPE. Four supplemental outward boundary stencils also have dtEOS=0, accepted=false and unchanged state. No clipping, EOS extrapolation or invalid commit. These are controlled-stop passes, not advancing multi-step passes.

# 27. Near-boundary scaling result

Four boundaries × normalized interior distances 1e-2,1e-4,1e-6: all have positive accepted dtThermo, monotonically decreasing toward the boundary. pMin: 1.103962e-5,1.104940e-7,1.104950e-9 s; pMax: 9.577546e-6,9.570380e-8,9.570310e-10 s; Tmin: 1.142386e-4 (acoustic-limited),1.523271e-6,1.523276e-8 s; Tmax: 1.271367e-4 (acoustic-limited),1.665137e-6,1.665139e-8 s. Distances use delta-p/(12MPa-0.05MPa) or delta-T/35K. No zero-step classification for these interior points.

# 28. ALE result

ALEContact and ALEUniform pass all requested sizes/steps. All continuation and trial paths call actual explicitTrial with Vnew=Vold+dt*(meshPhiRight-meshPhiLeft); no fixed-volume linearization substitutes for ALE. GCL remains covered by unchanged M5C.1 regression.

# 29. Rejected-step state integrity

Before continuation, copy committed conservative arrays and volumes. Assert exact equality after every continuation scan and before controlled stop; rejected proposals never write them. Full trial recovery precedes assignment. An unexpected failed retry remains a diagnosed test failure; it is not repaired.

# 30. Conservation ledger

Accepted-step invariant-integral maximum relative drift=4.601029489e-15. Accepted cumulative alpha-source balance maximum absolute discrepancy=8.526512829e-14, within unchanged 5e-12*N gate. Ledger accumulates only committed source increments. 1107 accepted global steps; no rejected/certified-stop increments added.

# 31. Whether R0 is now an admissible low-order anchor

YES within the tested standalone certified-domain protocol: every observed interior failure admits a positive shortened step, and boundary escape is detected before commit. Not a proof for arbitrary unsampled paths, future EOS versions, CFD geometry, active DPM or high-order reconstruction. A guaranteed arbitrary-state anchor would additionally require continuous/interval admissibility certification; this is explicitly outside the acceptance claim here.

# 32. Whether M5C.2B may start

Eligible for a separately authorized M5C.2B engineering assessment using this tested R0 fallback and domain-stop contract. This turn stops here. R1/R2 remain NOT STARTED, and no production/high-order guarantee is being promoted.

# 33. Whether coupled limiter design is now meaningful

A low/high conservative-flux limiter assessment now has a meaningful tested low-order state at lambda=0 when dt obeys this contract. No limiter or FCT is implemented. Arbitrary-path interval certification remains a limitation to be addressed if a universal guarantee is required.

# 34. Active solver impact

Active solver PHYSICS/SOURCE impact: NONE. All 33 top-level/flux source hashes and the previous protected Make/flow/cloud/timestep hashes are unchanged. Permitted standalone recovery headers/kernel and bridge precision diagnostics were versioned. Passive solver linking was rebuilt ONLY for ABI consistency after all regression suites passed. Factory library SHA remains 79ac28be52ed5aac02745d2ae81a2841508e00ee3eecb725dc8068f3fb503efe. No runtime recovery call, new mesh field, two-phase KT, surface tension coupling or CFD run.

# 35. Updated milestone matrix

| Milestone | Status |
|---|---|
| M0–M4 | COMPLETE |
| M5A / M5B / M5B.1 | COMPLETE / reference and design |
| M6A1a / production liquid EOS | COMPLETE / standalone |
| M6A2.1 | COMPLETE / v2 regression / not active |
| M6A2.2 | COMPLETE / v2 passive ABI / not active |
| M5C.1 | COMPLETE / standalone regression |
| M5C.2A | COMPLETE / standalone tested-domain R0 closure |
| M5C.2 | PARTIAL / high-order work pending |
| M5C.2B / R1 / R2 | NOT STARTED |
| M5C.3 / M8A / M6B | BLOCKED / NOT STARTED |
| M7 / VOF→DPM | NOT STARTED |

STOP: no M5C.2B, M5C.3 or M6B execution.

## M5C.2A gate matrix

| Gate | Result |
|---|---|
| old failures preserved/documented | PASS |
| phase-presence contract v2 frozen | PASS |
| trace phase not rejected by magnitude | PASS |
| impossible tiny phases rejected | PASS |
| M6A2.1 regression PASS | PASS |
| M6A2.2 bridge regression PASS | PASS |
| M5C.1 regression PASS | PASS |
| six contact-tail failures resolved | PASS |
| no trace mass deletion | PASS |
| intrinsic density preserved within conditioned floating-point error | PASS |
| trace pressure physical | PASS |
| three original mixed paths continuation-analyzed | PASS |
| dtThermo implemented | PASS |
| all tested interior failures have positive dt | PASS |
| mixed rerun accepts shortened step then correctly stops at HARD boundary | PASS |
| HARD inward PASS | PASS |
| HARD outward controlled-stop PASS | PASS |
| near-boundary scaling PASS | PASS |
| no EOS extrapolation | PASS |
| no pressure/alpha/mass clipping | PASS |
| rejected proposals leave committed state intact | PASS |
| accepted conservation ledger PASS | PASS |
| ALE PASS | PASS |
| active solver source unchanged | PASS |

## Exact historical failure continuations

| N | zero-based step/cell | lambdaValid | dtThermo (s) | p (Pa) | bracket (Pa) | TG/TL (K) | alphaL | mG/mL (kg/m3) | Et/Eint (J/m3) | fixable |
|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 8/7 | 0.75004199505396252 | 8.8683862772659147e-05 | 1183532.0552613819 | [1183532.0552613819,12000000] | 467.44762162927634/285 | 0.018205189471584136 | 8.620058674950247/13.427311226314281 | -98996.251057764326/-99019.455260567294 | YES: one shortened step; then domain stop |
| 60 | 8/27 | 0.75012346403865138 | 8.8687264996521715e-05 | 1183531.9591382444 | [1183531.9591382444,12000000] | 467.44758538634568/285 | 0.018205182094528316 | 8.6200587079679796/13.42730578403534 | -98996.309324550835/-99019.512979073334 | YES: one shortened step; then domain stop |
| 200 | 8/97 | 0.75012346403865138 | 8.8687264996521715e-05 | 1183531.9591382444 | [1183531.9591382444,12000000] | 467.44758538634568/285 | 0.018205182094528316 | 8.6200587079679796/13.42730578403534 | -98996.309324550835/-99019.512979073334 | YES: one shortened step; then domain stop |

## Modified and added files

Versioned existing: fiveEqThermo/fiveEqState.H, fiveEqStateRecovery.C; fiveEqIntegration/fiveEqRecoveryDiagnostic.H and fiveEqRuntimeBridge.C. Added: fiveEqReconstruction/fiveEqThermodynamicTimeStep.H/.C, tests/fiveEqRecoveryV2, fiveEqBridgeV2, fiveEqFluxV2, fiveEqAdmissibilityV2; v2 contract/report, fitting/reconstruction/m5c2a_v2 manifest/evidence, checkpoint. Updated: MILESTONE_STATUS.md. Make changes are confined to new standalone test directories; solver Make files unchanged.

Offline reproduction: source Foundation OF7 environment, wmake the standalone recovery library; build/run each *V2 test using 300_2D/constant/thermal.dat and reactions. Recovery test needs thermal.dat only. Admissibility test additionally requires historical_v1_replay/tests/fiveEqAdmissibility/original_paths.csv. Rebuild passive solver after header ABI changes; do not run it.
