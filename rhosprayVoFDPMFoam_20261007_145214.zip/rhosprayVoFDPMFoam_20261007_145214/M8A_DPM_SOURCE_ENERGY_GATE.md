# M8A conservative DPM source and energy ledger gate

# 1. M8A status

**PARTIAL.** Standalone conservative adapter and real OF7 API harness pass. Two production viability gates remain incomplete. This report does not grant M6B activation.

# 2. OF7 cloud/source audit

Actual Foundation7 sources copied and inspected. See docs/OF7_DPM_SOURCE_AUDIT.md; basicSprayCloud/basicSprayParcel layers, phase/heat/velocity/deletion and matrix paths audited.

# 3. Native mass-source semantics

rhoTrans is cell/time-step integrated mass kg, with nParticle. Srho() divides dt*V; explicit matrix Srho(rho) stores -transfer/dt.

# 4. Native species-source semantics

Actual localToCarrierId mapping; each runtime rhoTrans[i] maps to gas mYi. Actual reordered N2/C10H22/O2 fixture passes.

# 5. Native momentum-source semantics

UTrans is integrated coupled impulse plus mass-carried momentum. ReactingParcel U0 aliases new U; candidate exposes endpoint correction rather than double-counting mass momentum.

# 6. Native energy-source semantics

hsTrans is sensible enthalpy, not Et. Frozen-Cp heat integration, mass gas Hs and deletion branch require explicit reference/caloric/kinetic/pV conversion.

# 7. Units/sign conventions

Adapter outputs kg, kg m/s, J and kg per event. Divide by coherent event V only. Real Srho/SYi/SU/Sh dimensions and explicit RHS signs tested.

# 8. fiveEq source adapter API

dpmFiveEq/fiveEqDPMSourceAdapter.H: gasCarrier(), convert(), trial(). TrialSource: beginTrial(), accumulateSources() with validation, commit(), discard(). Native extraction and source snapshot use actual APIs.

# 9. Mass mapping

mG*=mG+dmG/V; Eulerian mL and signed P2 unchanged. No DPM liquid volume is inserted into alphaL.

# 10. Species mapping

mYi*=mYi+dmYi/V in actual runtime order. Frozen Q supports precisely three species; extension is explicit future work.

# 11. Species-source closure

All source/species and endpoint mass checks pass. Max extensive mass difference 1.0698451e-23 kg, within frozen endpoint roundoff budget.

# 12. Momentum ledger

dM=Pparcel_before-Pparcel_after+externalImpulse. Combined mass+drag alias defect is exposed as momentumCorrection. Common-velocity M update affects both material velocities through the model constraint; no post-accumulation alpha weighting.

# 13. Kinetic-energy ledger

dK=Kparcel_before-Kparcel_after+externalWork. Et and M updated coherently; no extra Ugas dot impulse source added afterward.

# 14. Heat-transfer ledger

Actual RanzMarshall tested. Nonlinear raw liquid h and H-pV endpoints are exactified explicitly relative to native frozen-mCp integration. Temperature clipping causes rejection.

# 15. Evaporation ledger

Actual liquidEvaporation with enthalpyDifference tested. dEt=HB-HA-chi+KB-KA+p(VA-VB)+Qext+Wext. All unit external terms are zero. The heat-none mass fixture is diagnostic, not production latent-cooling approval.

# 16. JANAF energy-reference compatibility

Actual Hs=Ha-Hc and Es=Ha-Hc-p/rho inspected. chi=sum(Hc_i dmYi) is subtracted ONCE. Gas energy remains original sensibleInternalEnergy.

# 17. Eulerian-liquid C_L status

Frozen 369229.9537234281 J/kg remains solely Eulerian Gibbs EOS coordinate offset. No C_L is added to DPM->gas source and no frozen EOS file is changed.

# 18. DPM caloric-reference status

Use real CompositionModel::H raw liquid h; liquid Hs=h(p,T)-h(p,298.15), Hc=h(p,298.15). Full native-reference comparison is in golden_energy.csv; no invented enthalpy offset.

# 19. Pure-gas legacy regression

Real source matrices and equivalent mass/species updates agree. Zero-source bit identity passes. Momentum/energy differences are explicit conservative upgrades (alias, caloric, KE and pV), not claimed equality to legacy full CFD.

# 20. Mixed-cell source result

alphaL=.1/.5/.9 source trials recover; mL and P2 untouched. This is local source admissibility, not a CFD coexistence validation.

# 21. Trace-gas result

alphaG=1e-20 intrinsic gas carrier and gas-volume-scaled event pass. Signed P2 remains exact. Finite arbitrary source into vanishing gas is not certified; source/Et resolution can require rejection.

# 22. Pure-liquid/gas-absent analysis

gasCarrier rejects before tracking even with zero source. Nonzero trial also rejects exact pure liquid. No alphaG=tiny or gas-volume creation source.

# 23. DPM applicability contract

Domain A frozen: DPM only in already present/trace gas. Injection and every trajectory/interpolation/source segment must check mask. Production path guard not yet implemented/verified: PRE-M6B HARD BLOCKER.

# 24. Parcel disappearance result

Real minParcelMass deletion branch and full single-C10H22 mass/energy ledger pass. Multi-component depletion/deletion is not covered.

# 25. Trial-source/recovery result

Full coherent Q recovery after increment; invalid-energy trial rejected, no partial commit; paired mock commit/discard tested. Recovery tolerances unchanged.

# 26. Rollback/transaction design

Real cloud clone restores parcel but not transfer arrays. Explicit reset gives identical replay; separate nonzero rhoTrans/UTrans/UCoeff/hsTrans/hsCoeff snapshot restore passes. Production injector/functions/IDs/output/occupancy/time/mesh rollback is NOT proven: PRE-M6B HARD BLOCKER.

# 27. Real OF7 source API harness result

| Native fixture | Checks | Failures |
|---|---:|---:|
| zero | 1168 | 0 |
| heat | 1160 | 0 |
| momentum | 1160 | 0 |
| mass | 1160 | 0 |
| evaporation | 1160 | 0 |
| combined | 1160 | 0 |
| disappearance | 1160 | 0 |
| permuted | 1160 | 0 |

9288 checks, 0 failures. Two actual parcels with unequal multiplicities, real source matrices, clone/restore and source snapshots included. Direct native parcel calc, not a CFD run.

# 28. DPM/chemistry source separation

Vapor dmYi and Et reference conversion are separate from chemical RR_i/Qdot. M8A does not integrate/rewrite chemistry.

# 29. DPM/chemistry energy-reference test

Actual Hc-based hypothetical mass-conserving algebra verifies Qdot=-sum(Hc_i RR_i) cancels chemical-reference change. Current three-species case lacks products/active reactions; synthetic RR direction is NOT a physical reaction test. Reaction-enabled adapter remains a distinct future gate.

# 30. Conservation matrix

Zero, heat, drag, mass, evaporation, combined, disappearance, real multiple-parcel, pure-gas, trace, mixed, ALE and rejected trial checks pass in supported standalone scope. Max extensive momentum defect 0 kg m/s; max energy defect 3.9183814e-18 J. Frozen tolerances in FROZEN_TOLERANCES.json.

# 31. ALE/source result

Event-volume normalization tested at V=.7; source increment never depends on meshPhi or a second dt. ALE flux/temporal frozen regressions rerun separately.

# 32. Golden energy-reference cases

Native property values at p=3MPa and TL285/300/305/320 K retained. These are actual OF7 property outputs, not experimental measurements or new reference-EOS grids.

# 33. Performance

| API | N | Mean ns | P95 ns | P99 ns | Max ns |
|---|---:|---:|---:|---:|---:|
| conversionNs | 8032 | 51.1 | 57.0 | 99.0 | 2540.0 |
| trialRecoveryNs | 8032 | 1415.0 | 1570.0 | 1674.0 | 114621.0 |

Nearest-rank percentiles, warmed repeated conversions; separate per-event source conversion and source-trial recovery. Not full cloud/CFD timing.

# 34. Added files

dpmFiveEq/*.H; tests/fiveEqDPMNative source/Make/manufactured fixtures; four docs; tools/m8a_*.py; fitting/dpm/m8a_v1 immutable evidence. Only ENERGY_REFERENCE_AUDIT.md and MILESTONE_STATUS.md are authorized existing document updates.

# 35. Compile status

Foundation7 wmake PASS for isolated native harness. No system library rebuild or active solver change; frozen library hashes unchanged. Frozen temporal test 9663/0; all 11 D regressions exit0/failure0 and their result JSON exactly matches the frozen M5C.3 result. Initial full-build transient clock-skew warning is retained; final wmake exits0 without warnings, unchanged binary verified by hash.

# 36. Active solver impact

**NONE.** Hash audit of all protected old sources/case/EOS/contracts: only the two authorized document updates may differ. No runtime include/field/equation/source activation.

# 37. Remaining blockers

1. Actual production injection/path/interpolation gas applicability guard and coherent cellValueSourceCorrection ownership. 2. Full current production cloud rollback/preview isolation beyond the minimal unit cloud, including mutable metadata and side effects. Varying-pressure/radiation/multi-fuel cases lie outside candidate contract.

# 38. Whether M8A is COMPLETE

**NO.** All 28 gates must pass; applicability and complete real-cloud transaction viability remain PARTIAL.

| Gate | Status |
|---|---|
| 1. real OF7 parcel source path audited | PASS |
| 2. source dimensions/signs frozen | PASS |
| 3. mass -> mG mapping proven | PASS |
| 4. species -> mYi mapping proven | PASS |
| 5. sum species source = mG source PASS | PASS |
| 6. momentum ledger proven | PASS |
| 7. parcel kinetic-energy accounting closed | PASS |
| 8. heat-transfer energy ledger closed | PASS |
| 9. evaporation energy ledger closed | PASS |
| 10. gas JANAF energy-reference compatibility proven | PASS |
| 11. no C_L misuse | PASS |
| 12. parcel disappearance ledger PASS | PASS |
| 13. pure-gas legacy DPM regression PASS | PASS |
| 14. mixed-cell source recovery PASS | PASS |
| 15. trace-gas source test PASS | PASS |
| 16. exact pure-liquid/gas-absent DPM policy frozen | PASS |
| 17. source applicability mask frozen and viable | PARTIAL |
| 18. source-stage thermo validation PASS | PASS |
| 19. rollback/transaction contract frozen and real-cloud mapping proven | PARTIAL |
| 20. real OF7 source API harness PASS | PASS |
| 21. chemistry source family kept separate | PASS |
| 22. DPM+chemistry energy-reference compatibility test PASS | PASS |
| 23. conservation matrix PASS | PASS |
| 24. no clipping / silent repair | PASS |
| 25. no CoolProp runtime dependency | PASS |
| 26. standalone compile PASS | PASS |
| 27. active solver physics unchanged | PASS |
| 28. no CFD run | PASS |


# 39. M6B.0 start permission

**NO.** Close M8A blockers first. M6B.0 is not executed here.

# 40. M6B.1 permission

**NO.** No atomic equation switch.

# 41. Updated milestone matrix

| Stage | Status |
|---|---|
| M0-M4 | COMPLETE; diagnostics only where previously stated |
| M5A/M5B | COMPLETE / reference/design |
| M6A1a / accepted EOS / M6A2 | Existing COMPLETE / passive scopes unchanged |
| M5C.1/M5C.2/M5C.3 | COMPLETE / standalone / not active |
| M8A | PARTIAL / standalone source tests PASS; two hard blockers |
| M6B.0 | NOT STARTED / blocked |
| M6B.1 | NOT STARTED / NO |
| VOF-DPM conversion, CFD | NOT EXECUTED |

STOP. No M6B.0/M6B.1 or CFD performed.

