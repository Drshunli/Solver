# Gas species ownership and runtime mapping

Future Yi are intrinsic Eulerian gas mass fractions; conserved mYi=mG*Yi,
not rhoMix*Yi. Current rhoYEqn.H remains untouched. YG must be local runtime
data; no default air remains in the production kernel. Air is test data only.

Bridge startup receives actual composition species names and a copied JANAF
metadata dictionary. No mesh/composition field is retained. It maps each
supported evaluator species name to runtime position, checks required unique
names, exact supported mechanism size, molecular weights, JANAF ranges and
all coefficients. Weight/metadata comparison uses explicit relative/absolute
1e-12 arithmetic tolerance. Missing/extra/duplicate names or mismatches fail
startup. Mechanism extension needs a separate evaluator extension, never
silently ignores extra species.

Canonical evaluator order is published by its API, not assumed from runtime
index. The mapper handles permuted runtime orders. Synthetic tests read actual
names from reactions and actual metadata from thermal.dat. Future callers must
supply snapshots from their loaded composition, not unrelated reference metadata.

Queries require finite Yi>=0, matching size and abs(sumY-1)<=1e-12 (the existing
M6A2.1 contract). Accepted tiny sum error is passed unchanged; there is no
explicit normalization or negative-Y clipping. The OF7 local mixture value
operations retain their native mass-basis arithmetic. Clearly invalid and
alpha-weighted sums are rejected. No composition mutation occurs.

Exact pure-liquid recovery skips YG mapping and gas evaluation; Y may be empty.
Invalid presence is decided by the kernel. At future boundaries provide gas Yi
only when gas is present. Injection mass/T boundary design remains future work.
