# M8A.3B-T4 — MPI admission and parcel migration gate

Date: 2026-10-04. **PARTIAL / MPI SUPPORT BACKEND UNAVAILABLE.**

## Verified prerequisite

The replay-v2 R2-FINAL checkpoint was independently opened and verified: archive SHA-256 `0ea829f4c0fa2bc7f45b349f23a68bae8b6cab1ae289840fa43c4d224a2773fa`, CRC PASS, every manifest file SHA PASS, 121 unique entries, live checkpoint files unchanged. R2-FINAL/T3B/T3 remain COMPLETE and frozen within the existing serial/passive/fixed-mesh scope.

## Actual blocking evidence

`tests/fiveEqDPMSupportScan/nativeSparsePointSupport.H:22` throws `MPI_SPARSE_SUPPORT_NOT_IMPLEMENTED` when `Pstream::parRun()` is true. Line 23 independently prohibits coupled patches. `tests/fiveEqDPMCarrierQueryR2A/carrierQuery.H:89` unconditionally creates this stencil in the query owner constructor. `tests/fiveEqDPMTransactionR2CR1Events/lazyTrialBinding.H` uses that owner and assigns serial `OWNER_CELL_FIXED_MESH_HARNESS` boundary metadata. Such metadata is not a certified remote processor support publication.

The isolated new probe invokes the **unchanged** stencil class. It does not instantiate the full carrier owner/cloud or a transaction. The original eight-cell fixed mesh is copied to a new fixture and decomposed with Foundation OF7 `decomposePar -noFields` into two ranks with four cells and one processor patch each. Standard OF7 `argList` with `-parallel` initializes real MPI. Both ranks reproduce the exact guard exception. Both per-rank JSON files record `parRun=true`, `coupledPatches=1`, `rejectedRanks=2`, no parcel creation, no migration and no gas thermo materialization.

`wmake` PASS; decomposition PASS; diagnostic probe exits zero because the expected unsupported-backend diagnostic was reproduced. **Exit zero is not T4 PASS.** The collective sum in this probe only counts diagnostic outcomes; it is not a global transaction reject test.

This is classified as an **MPI support admission prerequisite blocker**. No stale destination token, lost/duplicate parcel, partial commit, source loss or native physical divergence was observed: none of those paths ran. Four-rank and subsequent migration/physics/stress runs are stopped at this prerequisite. The guard was not removed, bypassed or substituted by a serial stencil.

## Required 32-item report

| # | Item | Result |
|---|---|---|
| 1 | T4 status | PARTIAL / MPI SUPPORT BACKEND UNAVAILABLE |
| 2 | Rank counts tested | Real 2-rank admission probe; 4 ranks NOT RUN; serial certificate inherited |
| 3 | Processor crossing | NOT RUN; processor mesh exists, parcel crossing does not |
| 4 | Parcel migration fields | NOT TESTED; C2 semantic field contract unchanged |
| 5 | Ownership | MPI parcel ownership NOT TESTED; no parcel created |
| 6 | Duplicate/loss checks | NOT TESTED; no observed duplicate/loss is not evidence of PASS |
| 7 | RNG | MPI rollback/cached normal/draw counts NOT TESTED; serial evidence retained |
| 8 | Allocator/IDs | MPI migration uniqueness/rollback NOT TESTED; historical allocator-only test does not certify migration |
| 9 | Destination support-first | BLOCKED before cloud initialization by frozen MPI guard; no stale destination support observed |
| 10 | Carrier generation | MPI accept+1/reject unchanged NOT TESTED |
| 11 | Global reject | NOT TESTED; probe diagnostic reduction is not transaction rejection |
| 12 | Crossing+reject rollback | NOT TESTED |
| 13 | Source ownership | NOT TESTED; no source contributions generated |
| 14 | Output semantics | Accepted transaction output NOT TESTED; per-rank diagnostic JSON only |
| 15 | Cone injection | MPI native injection NOT TESTED |
| 16 | Stochastic dispersion | MPI continuation/retry NOT TESTED |
| 17 | SphereDrag | MPI nonzero drag/source NOT TESTED |
| 18 | ReitzKHRT child | MPI child migration/destination token NOT TESTED; frozen KH contract retained |
| 19 | ORourke | MPI semantics NOT TESTED; serial NATIVE-PHYSICS-LIMITATION retained |
| 20 | Rebound | MPI rebound/support invalidation NOT TESTED |
| 21 | VoidFraction | MPI trajectory-time ownership NOT TESTED |
| 22 | Combined event | NOT TESTED |
| 23 | Conservation diagnostics | MPI mass/species/momentum/energy NOT TESTED |
| 24 | Lifecycle stress | Required MPI 100/100/1000 stress NOT RUN; serial stress is not relabeled MPI |
| 25 | Registry | Transaction accept/reject/migration registry stability NOT TESTED |
| 26 | 1/2/4-rank equivalence | NOT TESTED |
| 27 | Foundation hashes | 6717 installed source entries and 19 native parcel entries PASS |
| 28 | Active solver impact | NONE; frozen equation/Make/source manifests unchanged |
| 29 | Production mesh/BC impact | NONE; 96 protected 300_2D files unchanged; only new isolated fixture decomposed |
| 30 | T4 COMPLETE? | NO; MPI admission is unavailable, certification checklist remains open |
| 31 | Next permitted milestone | Passive MPI support prerequisite gate, followed by resumed T4; no active integration/M6B/CFD |
| 32 | Milestone matrix | See matrix below; T3 remains serial COMPLETE, T4 PARTIAL, M8A PARTIAL |

## Native MPI path audit and next prerequisite

Actual installed Foundation OF7 `src/lagrangian/basic/Cloud/Cloud.C` removes outgoing parcels into transfer lists after `prepareForParallelTransfer()`, streams those lists through `UOPstream`/`PstreamBuffers`, reconstructs through `ParticleType::iNew`, then calls `correctAfterParallelTransfer()` and adds the received object to the destination cloud. This source audit identifies where future destination binding/invalidations must be tested; it is not execution evidence. Source excerpts are preserved in the evidence directory.

The next passive prerequisite needs an MPI-capable support backend preserving the existing support-first contract, while retaining the serial implementation as a reference. Its gate must establish actual coupled-point contributor identities/weights with remote rank ownership, generation-consistent remote conservative-state publication, destination-local pose/token rebuilding after native transfer, and collective support-failure reporting safe for native communications. It must reject unsupported remote states before per-state gas thermo evaluation. It must not treat processor faces as the serial owner's fixed-boundary state, or weaken All-property preflight. Only after that backend passes should T4 resume with real 2-rank crossing, globally coordinated prepare/publish/discard, crossing+reject, source ownership, native models and stress, then 4-rank/decomposition comparisons. No alternative serializer or renumbering is justified by this admission failure.

This round adds only `prepare_t4_admission.py`, `tests/fiveEqDPMMPIAdmissionT4/testMPIAdmission.C` and its Make files, a copied/decomposed test fixture, audit scripts/evidence, this report and an append to the milestone history. Foundation, frozen R1/P2/source adapter, lazy semantics, KH/ORourke physics, C2 serializer, EOS/recovery, active solver and production mesh/BC remain unchanged. No CFD, production nozzle activation, M6B or active integration was run.

## Updated milestone matrix

| Gate | Status / scope |
|---|---|
| Earlier milestones | Inherited without promotion; see original append-only history |
| R2B / R2C-I1 / R2C | COMPLETE / FROZEN |
| C1 | HISTORICAL PARTIAL / NONDETERMINISTIC_BINARY_BLOCKER |
| C2 | COMPLETE / FROZEN / NATIVE-COMPATIBLE / SEMANTIC-NONCANONICAL |
| K1 | COMPLETE under frozen revised KH contract |
| R2-FINAL / T3A | COMPLETE / FROZEN; T3A inherited |
| T3B | COMPLETE / SERIAL TRANSACTION SAFE / NATIVE ORourke PHYSICS LIMITATIONS |
| T3 | COMPLETE / passive serial fixed-mesh scope only |
| T4 | PARTIAL / MPI support admission prerequisite blocked |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NOT STARTED |
| Active integration / CFD | NOT RUN |
| Production restart / AMR | NOT CERTIFIED |

**STOP.** No MPI physical safety or transaction certificate is issued by this probe.
