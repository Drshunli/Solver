# M6B1-CRV3-2-PHYSICAL-QUALIFICATION REPORT v2

本轮按新请求先冻结、独立推导与参考求解，再重放既有阻塞。未改 active physics，未执行 CRV3-3。

## 1. status

CRV3-2 INCOMPLETE / STOP。分类 F：PRESENT_PHASE_SUBNORMAL_PRECISION_UNRESOLVED。不是已证明的模型误差、热力学违例或 VV 非唯一性。

## 2. source/binary identity

CRV3_2_PRE 冻结 114 个基线文件；当前源码逐项匹配上一轮 sealed source_after.json。本轮无 active 源码修改。CRV3-1 合格 binary 与当前 journal binary 分开保存，未混称为同一 executable。

## 3. traveling-wave derivation

CRV3_TRAVELING_WAVE_v1.md 已完成实际 stress/work 正号核对。j*u+p−tau、Et*(u−s)+(p−tau)*u 为不变量；e=eR+(u−uR)^2/2−pR*(u−uR)/j；dalpha/du=K/(u−s)。μ 从状态轨道中消去。

## 4. traveling-wave reference

独立 90 位 JANAF 纯气 ORIGINAL 主波 BVP 已解；速度 582.207376791 m/s，参考残差最大 8.738e-10 <1e-8。另有端点 RH/熵通量核对和空间 profile。WEAK/MODERATE 混相独立 BVP 未运行，整个 reference suite 不计 COMPLETE。

## 5. shock families

冻结 weak=1.05、moderate=1.25、original=1.10 主纯气波与完整 shockInterface case。新重放仅为既有 hard blocker 复核，不计新 grid ladder 样本。

## 6. fixed-mu grids

新计划 μ=3，N256/512/1024；按 10–90 分辨率自动加密。硬阻塞复现后未运行，不能沿用旧对角线代替 fixed-mu 收敛。

## 7. mu ladders

计划 3/1.5/.75/.375；本轮未执行新的 μ ladder。旧结果保留，仅诊断。

## 8. coupled dx-mu ladders

已冻结两路线 N256/512/1024/2048 与 N512/1024/2048/4096，仍须自适应厚度审核；未执行。

## 9. shock thickness/cells

独立原始参考 δp/μ=0.00706796485887，δu/μ=0.00707663433586。alpha 无跳跃，厚度 undefined。旧原始对角线上四点参考 nShock≈2.12039，均<8，不得用于 VV fit。该数是参考厚度预审，不是 PDE 测得厚度。

## 10. thickness scaling

理论参考 δ∝μ（q=1）；未获得分辨率合格的 PDE μ 序列，未拟合 PDE q。

## 11. shock speeds

仅独立 ORIGINAL 参考 582.207376791 m/s。PDE 收敛速度未测，不用初始速度宣称动态 PASS。

## 12. pressure jumps

ORIGINAL 参考 p: 3000000 → 3300000 Pa；Δp≈300000 Pa。无新的 PDE 跳跃误差资格。

## 13. velocity jumps

ORIGINAL 参考 u: 0 → 39.6250537204 m/s。

## 14. alpha jumps

ORIGINAL 主纯气波 alpha=0→0；relative jump error undefined。混相 WEAK/MODERATE 未解，不能借纯气结果通过 alpha gate。

## 15. phase-mass plateaus

ORIGINAL 参考 mG: 13.0039019698 → 13.9535833218 kg/m³，mL=0→0。K=0；cPE: 558.656825165 → 565.166144799 m/s。完整算例包含材料界面，不能视为该单一 BVP。

## 16. Et plateaus

ORIGINAL 参考 Et: 3859313.11142 → 4382161.26658 J/m³。

## 17. traveling-wave errors

独立 reference 数学 gate PASS；PDE vs reference 对齐比较未运行。不用旧 native trajectory 当独立参考。

## 18. two-path limit comparison

未形成两条合格序列，O0 差异 undefined；不宣称 unique 或 nonunique。

## 19. vanishing-viscosity fits

没有至少 3 个 spatially qualified μ 点，未拟合 O0+C*μ^p。

## 20. entropy production

独立主波 Σ=200.691435439>0；与熵生产 quadrature 相对残差 1.961e-15。重放累计 trapezoid 指标 0.00531802596786≥0，含周期其他结构/瞬态，不等于孤立主 shock Σμ。

## 21. viscous heating/work

重放已接受步 heating 累计 4.30802819968，局部最小 0；active driver 保留每候选 work/KE/internal-energy identity。参考孤立 shock ∫heat dx=162543.983208；机械应力功为其负值，端点 tau*u 功通量差为零。未做跨 μ 累计身份误差资格。

## 22. conservation

新重放 208 个已接受步 global conservation 最大 1.37305e-16；保留原硬预算，不以 5% 判 conservation。阻塞 trial 未提交。

## 23. strict-root/EOS

新 probe 对完整锚点 800/800 native recovery PASS。独立纯气参考严格 JANAF 温域与压力域 PASS。新重放全步独立 strict recovery/root margin 未测，最后 snapshot p/TG/TL 范围见 qualification_result.json，不冒充全步极值。坏 trial 在 presence guard 拒绝，尚未进入 EOS，不能声称 EOS 域外根。

## 24. P2

新 probe 79 个 pre-viscous 候选的 P2/phase mass/species 固定分量 mismatch=0；没有 clipping、阈值删除、归一化或修改 presence guard。P2 正 trace 的不支持亚正常表示阻塞仍在。

## 25. species

已接受步 N−1 closure 最大 1.71142e-16；viscous species 位级 mismatch=0。

## 26. contact regressions

源码未修改，保留 CRV3-1 原 regression 336 组、53760 native/strict checks、热 alpha contact 最大 pressure error 0.0871438%。本轮未重跑；不声称新增 contact suite。

## 27. joint timestep

新 replay 记录 hyperbolic/alpha/viscous/joint/actual dt；TD1 journal 保留 nested end/growth 候选记录。outer end/growth 全步独立 ledger 未补齐。锚点 joint cap=1.5063651678791615e-07，液相 fraction 要成为 normal 所需 dt=3.5598332394001347e-07，超过 cap；dtVisc 公式仍为 minrho*dx²/μ。

## 28. temporal statistics

208 accepted steps，t=3.1332395491886647e-05 < endTime。重放 native selector 失败，独立 79 候选 validProgress=0。exact thermo calls、all-trial CRV3 solves、精确 wall time 未仪表化，标为 unavailable。不是只有 expensive physics PASS 的性能问题。

## 29. old path diagnostic only

旧 three-leg endpoint residual 未重新求值；旧 SP1/SP2 保持只读诊断，不作为 CRV3 hard gate，也不调 CRV3 去匹配旧 path。

## 30. hard blockers

锚点 step208，timeBits=3f006d5ce95af15f。cap 候选 cell311：alphaL=9.4155358720636813e-309、mL=6.849171134535951e-306，拒绝原因 PRESENT_PHASE_SUBNORMAL_PRECISION_UNRESOLVED。前一步两量均为0；hyperbolic trace 尾产生正亚正常 alpha。viscous 固定分量检查零差异。重放与历史锚点一致。冻结 guard 明确拒绝该表示，尚无证据将其归类为本轮可直接修正的真实 implementation bug。

## 31. engineering error table

见下表。所有未运行项明确 NOT QUALIFIED，不用物理压幅或 bit mismatch 替代工程误差。

## 32. CRV3-2 COMPLETE?

NO。全 family independent reference、fixed-μ convergence、双路线 VV、resolved thickness、PDE reference agreement 等 gate 未完成。

## 33. CRV3-3 authorized?

NO。本轮要求 NEXT ROUND ONLY；已 STOP，不自动进入 CRV3-3。

## 34. M6B.1 status

PARTIAL。历史 MC5/TD1、CRV3-1 原资格保留；CRV3-2 未通过。

## 35. hashes

CRV3_2_PRE/manifest.json 记录 source/binary/EOS/K/cPE/TD1/viscosity/joint contract。最终 artifact_manifest.json 与 checkpoint_seal.json 提供新证据 hashes。

## 36. milestone matrix

见 milestone_matrix.json：CRV3-1 preserved COMPLETE；CRV3-2 hard blocker INCOMPLETE；CRV3-3 NOT AUTHORIZED；M6B.1 PARTIAL。

| 项目 | 独立参考 | 新 PDE 工程资格 |
|---|---|---|
| ORIGINAL 主波 | BVP 数学 gate PASS | NOT QUALIFIED：full case hard block |
| WEAK 1.05 | 未运行混相独立 BVP | NOT RUN |
| MODERATE 1.25 | 未运行混相独立 BVP | NOT RUN |
| 两路线 O0 | 无合格样本 | UNDEFINED |

