# M5C.1 standalone KT/ALE and Allaire gate

## 1. M5C.1 status

**COMPLETE / STANDALONE / NOT ACTIVE**, 2026-09-30. All 29 requested stage
gates pass. This stage assesses the first-order flux/discrete contract; full
reconstruction and coupled high-order limiting remain subsequent blockers.
No CFD run. No M5C.2 or M6B work was executed.

## 2. Legacy KT audited files

Current main C, directionInterpolate.H, readFluxScheme.H, createFields.H,
rhoEqn.H, rhoUEqn.H, rhoEEqn.H, rhoYEqn.H and actual 300_2D fvSchemes.
Foundation 7 rhoCentralFoam interpolation/scheme headers and MULES implementation
were read locally. Detailed actual locations: `LEGACY_KT_DISCRETE_AUDIT.md`.

## 3. Legacy KT coefficient definitions

`q±=U±·Sf-meshPhi`; `ap=max(qPlus+cPlus|Sf|,qMinus+cMinus|Sf|,0)`;
`am=min(qPlus-cPlus|Sf|,qMinus-cMinus|Sf|,0)`;
`aPos=ap/(ap-am)`, `aNeg=1-aPos`, `aSf=am*aPos`;
`Aplus=aPos*qPlus-aSf`, `Aminus=aNeg*qMinus+aSf`.
Tadmor branch retained exactly: aPos=aNeg=0.5, aSf=-max(|ap|,|am|)/2.

## 4. Symbol/dimension mapping

Normalized aPos/aNeg are dimensionless. q/ap/am/aSf/Aplus/Aminus and relative/
physical volumetric flux are m3/s. Legacy phiv changes meaning after multiplication
by a_pos/a_neg; the standalone distinguishes it. Phase mass/species flux kg/s;
momentum N; energy W. Full mapping table is in the audit.

## 5. Fixed-grid five-equation PDE contract

`dt(mk)+div(mk U)=0`; `dt(M)+div(M tensor U+pI)=0`;
`dt(Et)+div((Et+p)U)=0`;
`dt(alpha)+div(alpha U)=alpha div U`; `dt(mG Yi)+div(mG Yi U)=0`.
Common p/U, separate TG/TL; K=0; cAlpha OFF; no source coupling in test transport.

## 6. ALE PDE contract

Moving face: mk*(U-Umesh)·Sf; M*(U-Umesh)·Sf+pSf;
Et*(U-Umesh)·Sf+pU·Sf. Alpha integral uses relative face transport,
physical alpha*divU volume source and matching GCL volume update.

## 7. Reconstructed face-state contract

Authority: alpha,mG,mL,M,Et,mYi or intrinsic Yi. p/rhoG/rhoL/TG/TL are recovered
outputs, not independently authoritative interpolants. Presupplied faces only
in this stage. Runtime species labels/order are supplied through the bridge.

## 8. Face recovery sequence

Call recoverFaceState on both sides, retain separate diagnostic records;
then construct cMix-based KT coefficients and fluxes. Reuse real frozen
ndecane_gibbs_v1 and actual OF7 JANAF gas evaluator. No EOS duplication.

## 9. KT wave-speed formula

All acoustic estimates use `(U·Sf-meshPhi)±cMix|Sf|`. Common velocity/mesh-speed
shift regression PASS. Fixed-mesh zero meshPhi reduction PASS.

## 10. Phase-mass fluxes

FmG=Aplus*mGPlus+Aminus*mGMinus; FmL=Aplus*mLPlus+Aminus*mLMinus.
One common family of coefficients; no independent rhoPhiVoF.

## 11. Total-mass identity result

FmG+FmL=KT(mG+mL). Maximum scaled roundoff error **1.91345e-16**; tolerance
5e-12. Tested 96 pure/mixed/material-side combinations across both schemes/ALE.

## 12. Momentum flux

FM=Aplus*MPlus+Aminus*MMinus+(aPos*pPlus+aNeg*pMinus)*Sf.
Actual legacy pressure weighting retained; no alternate Riemann solver.

## 13. Total-energy flux

FE=Aplus*(EtPlus+pPlus)+Aminus*(EtMinus+pMinus)
+aSf*pPlus-aSf*pMinus+meshPhi*(aPos*pPlus+aNeg*pMinus).
Transported Et is the conservative input, not reconstructed gas-only energy.

## 14. Moving-mesh pressure-work treatment

Uniform state reduces to Et*(U·Sf-meshPhi)+pU·Sf. Maximum normalized formula
error **8.17656e-16**. The deliberate p*(U-Umesh) counterfactual is detected for
gas, liquid and mixed states; missing work equals p*meshPhi for uniform states.

## 15. Species flux

F_mYi=Aplus*(mG Yi)Plus+Aminus*(mG Yi)Minus. Absent gas contributes exact zero.
Runtime species order preserved. Chemistry stays outside the flux. This is a
future KT species contract, not current mvConvection/vanLeer equivalence.

## 16. Species-sum result

Maximum face sum error **2.79927e-16** across every tested valid face, including
nonzero C10H22 gas compositions. Periodic post-update species sum equals
mG within 5e-12 without sources; no species normalization in flux code.

## 17. Pure-gas legacy regression

**3456 supplied EOS-consistent face pairs, both schemes**, varying p,T,U,Y,Sf
and mesh motion. Independent legacy oracle; CSV saves each case.

| Quantity | Recovered-state algebra maximum scaled error | Original-primitive end-to-end maximum |
|---|---:|---:|
| Mass | 0 | 1.68355e-16 |
| Momentum | 0 | 3.31714e-16 |
| Energy | 1.29039e-16 | 7.37292e-16 |
| Wave coefficients | 0 | 6.32597e-16 |

Frozen tolerances: 5e-12 algebra, 5e-9 end-to-end. Recovered-pressure relative
error <=3.49246e-15. No systematic discretization difference on equivalent
representations. Independently reconstructed legacy rPsi/e/c may be off-manifold;
no equivalence claim for those general face states or full Minmod reconstruction.

## 18. Pure-liquid limit

cMix=cL, zero gas evaluator calls, finite phase mass/momentum/energy, PASS.
Uniform liquid and liquid discontinuity states tested with the production EOS;
no gas psi or gas acoustic query used.

## 19. Alpha flux candidate

Falpha=Aplus*alphaPlus+Aminus*alphaMinus; same diffusion as phase masses.
No cAlpha/MULES call or post-update clipping.

## 20. divU discretization

phiRelStar=Aplus+Aminus; phiPhysStar=phiRelStar+meshPhi.
Source uses old-time cell alpha*div(phiPhysStar). Increment form analytically
cancels GCL volume change; it exactly preserves pure-alpha plateaus without
changing any conservative state. See `FIVE_EQ_CONTACT_PRESERVATION.md` proof.

## 21. Stationary contact result

Full U=0, p0=3 MPa, TG=800 K, TL=300 K, differing alpha and phase masses.
3/8/20 cells, both schemes, one Euler step. Maximum pressure relative error
**4.48897e-13**, below frozen 1e-8; recovered velocity error <=4.69421e-13 m/s.

## 22. Moving-contact result

U=47 or 2013.039 m/s; same intrinsic states. Maximum fixed-mesh contact pressure
relative error **1.33300e-11**, moving-mesh contact **1.22571e-11**; both below
1e-8. Velocity errors <=6.82122e-13 m/s. Diffusion permitted, pressure drift bounded.

## 23. Alpha/phase-mass compatibility derivation

At constant intrinsic states: FmL=rhoL Falpha,
FmG=rhoG*(phiRel-Falpha), FM=U0 Fmass+p0 Sf,
FE=eG FmG+eL FmL+|U0|2 Fmass/2+p0 phiPhys. Closed-cell constant-U divergence
vanishes. Shared flux/volume update preserves phase affine relations and p/U.
Maximum independently checked phase-alpha compatibility error **1.56285e-16**.

## 24. Alpha boundedness result

48 periodic stencils, including sharp jumps, moving contacts, strong velocity
gradients and ALE uniform states. 496 cell boundedness checks PASS at joint
alpha/mass/GCL timestep. First-order convex-weight derivation provided.

Unsafe counterexample: dt=1.077964338e-4, alpha bound=9.799675801e-5,
mass bound=4.916471656e-4; raw alpha=-0.1 despite satisfying the mass bound.
Thus a mass-only timestep condition is insufficient. No EOS-validity assertion
for post-step strong-gradient states and no higher-order boundedness claim.

## 25. MULES/limiter conclusion

Scalar MULES machinery is a possible ingredient, not a coupled five-equation
solution. Halving only alpha diffusion halves rhoL*alpha while leaving mL fixed;
actual EOS recovery rejects it. Coupled limiter = **OPEN ISSUE / M5C.2**.
Clipping is forbidden and absent. No active M2 alpha machinery was altered.

## 26. ALE/GCL result

Prescribed mesh-face motion and matching moving volumes, uniform primitives,
both schemes and 3/8/20 cells. Maximum errors:

| Quantity | Scaled uniform-state error |
|---|---:|
| mG | 2.16828e-16 |
| mL | 2.11196e-16 |
| M | 1.13080e-16 |
| Et | 1.84048e-16 |
| alpha | 0 |
| Recovered p (relative) | 2.32831e-14 |

These are algebraic GCL results, not a dynamic-mesh CFD validation.

## 27. Fixed-mesh reduction

meshPhi=0 removes the mesh-work correction and yields the actual fixed-grid
KT formulas. Gas/mixed/liquid uniform tests and the zero-mesh members of the
3456-case legacy matrix PASS.

## 28. Invalid face-state fallback

LEFT_INVALID/RIGHT_INVALID/BOTH_INVALID tested; separate bridge reason records.
Caller lower-order retry PASS using newly supplied valid conservative inputs.
No state edit, alpha clamp, EOS floor or implicit retry in flux code. Invalid
geometry/species layout also have explicit non-OK statuses; outputs usable only
when status==OK. Geometry zero-area rejection tested.

## 29. Conservation ledger

Periodic shared flux integrals telescope independently for mG,mL,M,Et,mYi.
Maximum normalized conserved-integral drift **3.87068e-17**. Alpha integral change
minus physical source integral <=**2.22045e-16**. Total density, intrinsic phase
densities, U, p and alphaG are derived outputs, not independent transport owners.

## 30. Reconstruction-variable conclusion

Conservative face authority frozen; future slopes remain unresolved. Conservative
versus hybrid choices must jointly demonstrate EOS-validity, p/U contact balance,
pure-gas legacy compatibility and positivity. Current tests accept supplied faces
only. **M5C.2 reconstruction gate required**, no slope/limiter redesign executed.

## 31. DPM pre-activation dependency

Parcel mass->mG, momentum->M, energy->Et, species->mG Yi. Adapter must reconcile
gas carrier view, implicit source matrices and energy reference. Either validated
adapter or explicit disabled-DPM-source checkpoint mode is required before M6B.
This turn documents the dependency only; existing source placement untouched.

## 32. Surface-tension status

M3 geometry/force remains diagnostic, uncoupled. No added force/energy source.
M7 retains momentum, total-energy and surface-energy consistency responsibility.

## 33. Added files

Six standalone H/C files under `fiveEqFlux/`; `tests/fiveEqFlux/` contains one
combined face/contact/ALE/FV test executable source, independent oracle, standalone
Make files, README, logs and CSV/JSON. Added this report, legacy audit, contact
derivation, frozen tolerances/hash/results and checkpoint tooling. No new solver
dictionary entries. Existing MILESTONE_STATUS.md updated after gate closure.

## 34. C++ compile status

Foundation 7 wmake PASS with -Werror. Smoke build/run and incremental matrix/
contact/final builds recorded. Links libRhosprayFiveEqThermo,
libRhosprayLiquidEOS, specie, OpenFOAM; bridge compiled locally into test objects.
Final independent run: **34,902 assertions / 0 failures**. Initial two roundoff
failures retained; regrouped algebra fixes them without changing tolerances.

## 35. Active solver impact

**NONE.** All 14 protected source/build headers match pre-change SHA-256, including
the main flux assembly, five equation headers, cloud creation and solver Make.
New source is absent from active Make/files/main includes. No runtime activation,
CFD execution, EOS fitting/table change, cL/cMix fields, mG/mL fields or transfer.

## 36. Remaining blockers

Full reconstruction, coupled boundedness/positivity/EOS-domain strategy,
integration/time discretization, characteristic boundaries, DPM source adapter
or disabled-source mode and atomic ownership switch remain gates. Offline
first-order results do not establish shock/interface CFD accuracy or stability.

## 37. Whether M5C.2 is required

**YES**: Conservative reconstruction and coupled alpha-boundedness design.
Raw first-order joint timestep proof is available; high-order path is unapproved.
This document recommends the next stage; it does not execute it.

## 38. Whether M6B.1 may start

**NO.** M5C.2 blockers and the DPM pre-activation source dependency must be
resolved before atomic activation preparation. No field/equation activation now.

## 39. Updated milestone matrix

| Milestone | Status |
|---|---|
| M0–M4 | COMPLETE |
| M5A / M5B / M5B.1 | COMPLETE / reference or design |
| M6A1a / M6A1b-2A / M6A1b-2B | COMPLETE / standalone accepted EOS |
| M6A2.1 | COMPLETE / STANDALONE |
| M6A2.2 | COMPLETE / PASSIVE / NOT ACTIVE |
| M5C.1 | COMPLETE / STANDALONE / NOT ACTIVE |
| M5C.2 | REQUIRED / NOT STARTED |
| M6B activation | BLOCKED / NOT STARTED |
| M7 | NOT STARTED |
| M8 | PARTIAL: existing DPM; new source adapter absent |
| M9–M15 | NOT STARTED |

**STOP at M5C.1.** Evidence paths and the full historical matrix are preserved
in MILESTONE_STATUS.md and fitting/flux/m5c1_v1/completion_manifest.json.
