# Active roadmap — isobaric common-velocity five-equation KT + VOF + DPM

## Final model contract

```text
alphaG = 1-alphaL
mG = alphaG*rhoG
mL = alphaL*rhoL
rhoMix = mG+mL
M = rhoMix*U
Et = mG*eG + mL*eL + 0.5*rhoMix*|U|^2
Qc = [mG,mL,Mx,My,Mz,Et], with material field alphaL
pG = pL = p; UG = UL = U; TG and TL may differ.
```

Future `p` is recovered from the conserved state and accepted phase EOSs;
there is no pressure-correction flow core. `rhoG=mG/alphaG` and
`rhoL=mL/alphaL` require admissible pure-phase limits. The same two-material
left/right states, common pressure/velocity, `cMix` and KT wave speeds must
generate `F_mG`, `F_mL`, `F_M` and `F_E`. Alpha transport/compression must
be designed consistently with those material fluxes.

## Sequence and gates

| Stage | Objective | Gate |
|---|---|---|
| M0–M4 | Legacy gas solver, VOF transport, interface geometry and diagnostic mixture properties | COMPLETE infrastructure; active flow remains gas KT |
| M5A | Compare current VOF-derived and gas-wave KT candidate mass fluxes | COMPLETE / ACTIVE REFERENCE; diagnostic file retained, not runtime |
| M5B | Define isobaric two-material conserved/primitive/flux states | COMPLETE / ACTIVE DESIGN; no active state fields |
| M6A1a | Compile liquid EOS interface; audit OF7 EOS and energy reference | COMPLETE; candidate uninstantiated |
| **M6A1b** | Test C10H22 EOS adequacy, provenance, multi-state calibration and energy-reference alignment | **NEXT**; reject constant-parameter stiffened gas if target-domain errors/structure fail |
| M6A2 | Implement admissible common-pressure recovery | Accepted EOS, reference energy and pure-phase limits |
| M5C/M6B | Build and atomically activate unified two-material KT flux/continuity/momentum/energy family | Same reconstructed state and waves for all conservative fluxes; compile and conservation validation |
| M7 | Consistent surface-tension momentum/energy coupling | Laplace pressure, parasitic-current and conservation checks |
| M8 | VOF+DPM coexistence and gas-material source restructuring | Carrier `rhoG`, source/overlap and mass/species/energy ledgers |
| M9 | Connected liquid components | Mesh/MPI-aware connectivity to injector |
| M10 | Lump metrics and conversion criteria | Mass, center, velocity, temperature, shape, resolution and age |
| M11 | VOF-to-DPM conversion | One conservative removal/parcel-creation transaction |
| M12 | Conversion ledger | Mass, momentum and energy event closure |
| M13 | MPI transfer | Deterministic component/parcel ownership |
| M14 | AMR | Conservative fields and component identity under refinement |
| M15 | Optional DPM-to-VOF | Reverse-transfer physical and numerical criteria |

## M6A1b adequacy gate

First determine the case/project pressure and temperature domain; a 0.3 mm
liquid-column diameter alone does not specify it. Collect sourced C10H22
`rho`, sound speed or bulk modulus, `Cp/Cv` and `h/e` data. For the current
candidate constant-parameter stiffened gas,

```text
p = (gamma-1)*rho*(e-q) - gamma*pInf
e = q + Cv*T + pInf/rho
rho(p,T) = (p+pInf)/((gamma-1)*Cv*T)
c^2 = gamma*(p+pInf)/rho = gamma*(gamma-1)*Cv*T.
```

At fixed `T`, its predicted `c` is independent of `p`. Test that structural
restriction before fitting. Then fit multiple states and report mean,
maximum and reference-state errors with full data provenance. If the target
domain cannot be represented acceptably, reject this EOS and compare NASG,
Tait with consistent caloric closure, Mie–Gruneisen, or a tabulated/Helmholtz
model. Do not invent parameters or set `q` merely to force a pressure fit.
`ENERGY_REFERENCE_AUDIT.md` is a required companion gate: gas JANAF,
Eulerian liquid and DPM liquid energy zeros must be related explicitly.
