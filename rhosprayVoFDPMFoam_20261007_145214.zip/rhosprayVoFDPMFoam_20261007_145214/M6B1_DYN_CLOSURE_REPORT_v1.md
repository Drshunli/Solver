# M6B.1-DYN-CLOSURE REPORT v1

2026-10-06；NONZERO_K_PE_v1；serial/fixed mesh/strategy0。

## 1. DYN status

**PARTIAL / BLOCKER_STOP — SHOCK_PATH_DYNAMIC_BLOCKER**。冻结 alpha 路径 RH 收敛门未通过，按请求第 50 条停止。不能将最细网格低于绝对阈值等同于通过收敛门，也不能据四级数据声称已证明模型发散。

## 2. Source / binary identity

fresh wclean/wmake 完成，与 MC5 executable/custom libraries 一致；111 项冻结 manifest 零 delta。MC3 模型预算 SHA `c6377d653599a24903440b119a8d5e9ea0541ea88db96d0bc40ad8803309d12b`；本轮运行前冻结 DYN 预算 SHA `23f11df196517e2bf684b65283ffa56ec880ad145f71c692a499302db4a4c371`。旧 build_identity_gate.budgetSHA 字段指 DYN 预算，preservation_gate 明确补充 MC3 预算，未改原文件。

## 3. Acoustic matrix

七族 gas/liquid/mixed01/mixed05/mixed09/traceLiquid/traceGas，各 ±，四网格，总 56 个实际 PDE 算例。全部显式 NONZERO_K_PE_v1、serial/fixed mesh/strategy0。

## 4. Acoustic ladders

N=100/200/400/800，L=1，dx 逐级减半，固定相态与扰动 εp=1e-6、基准 p=3 MPa/TG=800 K/TL=300 K；startup CFL=.15，冻结 TD1 策略。初始 eigenvector 与各级 phase/amplitude/error 见 cases/*/initial_eigenvector.csv、wave_reference.json 与 metrics。

## 5. Measured cPE speeds

| family | direction | N | cPE | measured speed | relative speed error | L1 | Linf | p L1 | P2 L1 | centre error |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gas | -1 | 100 | 558.6568252 | -558.4375681 | 0.00039247174 | 0.0026712076 | 0.0041953198 | 0.0026711615 | 0 | 9.870591e-06 |
| gas | -1 | 200 | 558.6568252 | -558.6021461 | 9.787588e-05 | 0.0013205411 | 0.0020740996 | 0.0013204954 | 0 | 2.4224286e-06 |
| gas | -1 | 400 | 558.6568252 | -558.6431532 | 2.447289e-05 | 0.00066768089 | 0.0010487285 | 0.00066763448 | 0 | 6.1300139e-07 |
| gas | -1 | 800 | 558.6568252 | -558.6534078 | 6.1171105e-06 | 0.00033291946 | 0.00052289661 | 0.00033287312 | 0 | 1.5254566e-07 |
| gas | 1 | 100 | 558.6568252 | 558.437568 | 0.00039247196 | 0.0026712076 | 0.0041953198 | 0.0026711615 | 0 | 9.8705898e-06 |
| gas | 1 | 200 | 558.6568252 | 558.6021461 | 9.7875914e-05 | 0.0013205412 | 0.0020740996 | 0.0013204954 | 0 | 2.4224279e-06 |
| gas | 1 | 400 | 558.6568252 | 558.6431533 | 2.4472819e-05 | 0.00066768091 | 0.0010487285 | 0.00066763448 | 0 | 6.1299676e-07 |
| gas | 1 | 800 | 558.6568252 | 558.6534079 | 6.1168489e-06 | 0.00033291945 | 0.00052289634 | 0.00033287311 | 0 | 1.5253418e-07 |
| liquid | -1 | 100 | 1244.718107 | -1244.229524 | 0.00039252462 | 0.0026931389 | 0.0042359537 | 0.0026711282 | 0 | 9.8725585e-06 |
| liquid | -1 | 200 | 1244.718107 | -1244.596145 | 9.798326e-05 | 0.0013410818 | 0.0021632321 | 0.0013204851 | 0 | 2.4249479e-06 |
| liquid | -1 | 400 | 1244.718107 | -1244.68758 | 2.4524919e-05 | 0.00068574661 | 0.0011477141 | 0.00066763462 | 0 | 6.1416176e-07 |
| liquid | -1 | 800 | 1244.718107 | -1244.710364 | 6.2208694e-06 | 0.00035413774 | 0.00062344237 | 0.00033286426 | 0 | 1.5653568e-07 |
| liquid | 1 | 100 | 1244.718107 | 1244.229534 | 0.00039251658 | 0.0026931374 | 0.0042359602 | 0.0026711261 | 0 | 9.8721709e-06 |
| liquid | 1 | 200 | 1244.718107 | 1244.596333 | 9.7832115e-05 | 0.0013410826 | 0.0021632386 | 0.0013204897 | 0 | 2.4219292e-06 |
| liquid | 1 | 400 | 1244.718107 | 1244.687694 | 2.4433683e-05 | 0.00068574249 | 0.0011477076 | 0.00066763403 | 0 | 6.1291601e-07 |
| liquid | 1 | 800 | 1244.718107 | 1244.710262 | 6.3025719e-06 | 0.00035414118 | 0.00062344978 | 0.00033286699 | 0 | 1.568229e-07 |
| mixed01 | -1 | 100 | 231.0373594 | -230.9466849 | 0.00039246643 | 0.0026712082 | 0.0041953226 | 0.0026711596 | 1.7706522e-10 | 9.8705528e-06 |
| mixed01 | -1 | 200 | 231.0373594 | -231.0147457 | 9.7878994e-05 | 0.0013205421 | 0.0020741115 | 0.0013204952 | 8.7532639e-11 | 2.4225115e-06 |
| mixed01 | -1 | 400 | 231.0373594 | -231.0317049 | 2.4474294e-05 | 0.00066768218 | 0.0010487483 | 0.0006676358 | 4.4255989e-11 | 6.13044e-07 |
| mixed01 | -1 | 800 | 231.0373594 | -231.0359493 | 6.1029822e-06 | 0.00033292031 | 0.0005229076 | 0.00033287414 | 2.2065418e-11 | 1.5221784e-07 |
| mixed01 | 1 | 100 | 231.0373594 | 230.9466839 | 0.0003924709 | 0.0026712081 | 0.0041953206 | 0.0026711581 | 1.7706522e-10 | 9.870629e-06 |
| mixed01 | 1 | 200 | 231.0373594 | 231.0147455 | 9.7879565e-05 | 0.0013205422 | 0.0020741099 | 0.0013204948 | 8.7532633e-11 | 2.4225958e-06 |
| mixed01 | 1 | 400 | 231.0373594 | 231.0317035 | 2.4480356e-05 | 0.00066768215 | 0.0010487434 | 0.00066763532 | 4.4255996e-11 | 6.1306917e-07 |
| mixed01 | 1 | 800 | 231.0373594 | 231.0359475 | 6.1107608e-06 | 0.00033292018 | 0.00052291929 | 0.00033287378 | 2.2065404e-11 | 1.5234717e-07 |
| mixed05 | -1 | 100 | 147.8044055 | -147.7463813 | 0.00039257458 | 0.0026712417 | 0.0041953332 | 0.0026711489 | 4.9184786e-10 | 9.8731714e-06 |
| mixed05 | -1 | 200 | 147.8044055 | -147.7899353 | 9.7901227e-05 | 0.0013205799 | 0.0020742142 | 0.0013204922 | 2.4314623e-10 | 2.4220972e-06 |
| mixed05 | -1 | 400 | 147.8044055 | -147.8007858 | 2.4489886e-05 | 0.00066771923 | 0.0010489006 | 0.00066763723 | 1.2293343e-10 | 6.1349743e-07 |
| mixed05 | -1 | 800 | 147.8044055 | -147.8035033 | 6.1039228e-06 | 0.00033295882 | 0.00052304053 | 0.00033287265 | 6.1293006e-11 | 1.5207152e-07 |
| mixed05 | 1 | 100 | 147.8044055 | 147.7463952 | 0.00039248017 | 0.0026712414 | 0.0041953341 | 0.0026711477 | 4.9184783e-10 | 9.8707887e-06 |
| mixed05 | 1 | 200 | 147.8044055 | 147.7899363 | 9.7894563e-05 | 0.0013205796 | 0.0020742078 | 0.0013204915 | 2.4314624e-10 | 2.4223773e-06 |
| mixed05 | 1 | 400 | 147.8044055 | 147.8007796 | 2.4531624e-05 | 0.00066772028 | 0.0010488891 | 0.00066763434 | 1.2293338e-10 | 6.1441157e-07 |
| mixed05 | 1 | 800 | 147.8044055 | 147.8035094 | 6.0631203e-06 | 0.00033295965 | 0.00052313048 | 0.00033287261 | 6.1292889e-11 | 1.5161656e-07 |
| mixed09 | -1 | 100 | 244.7977056 | -244.7016162 | 0.0003925255 | 0.0026719876 | 0.0041965583 | 0.0026711298 | 1.7706528e-10 | 9.8759141e-06 |
| mixed09 | -1 | 200 | 244.7977056 | -244.7737051 | 9.8041916e-05 | 0.0013211782 | 0.0020756659 | 0.0013204969 | 8.7532718e-11 | 2.4233408e-06 |
| mixed09 | -1 | 400 | 244.7977056 | -244.7917235 | 2.4436927e-05 | 0.00066836967 | 0.0010514066 | 0.00066762667 | 4.4256153e-11 | 6.1208389e-07 |
| mixed09 | -1 | 800 | 244.7977056 | -244.7962196 | 6.0699925e-06 | 0.00033360106 | 0.00052528937 | 0.00033287326 | 2.2065657e-11 | 1.508911e-07 |
| mixed09 | 1 | 100 | 244.7977056 | 244.7016046 | 0.00039257318 | 0.0026719866 | 0.0041965412 | 0.002671149 | 1.7706528e-10 | 9.8755223e-06 |
| mixed09 | 1 | 200 | 244.7977056 | 244.7737276 | 9.7950116e-05 | 0.0013211785 | 0.002075638 | 0.0013205077 | 8.7532779e-11 | 2.4212144e-06 |
| mixed09 | 1 | 400 | 244.7977056 | 244.7916971 | 2.4544631e-05 | 0.00066836734 | 0.0010514349 | 0.00066763856 | 4.4256198e-11 | 6.1544742e-07 |
| mixed09 | 1 | 800 | 244.7977056 | 244.7961813 | 6.2264433e-06 | 0.00033360145 | 0.00052547877 | 0.00033287502 | 2.2065662e-11 | 1.5572731e-07 |
| traceGas | -1 | 100 | 1244.718107 | -1244.229757 | 0.00039233733 | 0.0026968121 | 0.0042402296 | 0.00267112 | 1.967392e-29 | 9.8694418e-06 |
| traceGas | -1 | 200 | 1244.718107 | -1244.596373 | 9.7799962e-05 | 0.0013476814 | 0.0021449629 | 0.001320506 | 9.7258597e-30 | 2.422042e-06 |
| traceGas | -1 | 400 | 1244.718107 | -1244.687651 | 2.4468148e-05 | 0.00069240111 | 0.0011347116 | 0.00066762157 | 4.9173405e-30 | 6.124286e-07 |
| traceGas | -1 | 800 | 1244.718107 | -1244.71036 | 6.2237086e-06 | 0.00035925373 | 0.00062799597 | 0.00033287994 | 2.4517326e-30 | 1.5630496e-07 |
| traceGas | 1 | 100 | 1244.718107 | 1244.22976 | 0.00039233563 | 0.0026968082 | 0.0042402398 | 0.0026711248 | 1.967392e-29 | 9.8694042e-06 |
| traceGas | 1 | 200 | 1244.718107 | 1244.596227 | 9.7917582e-05 | 0.0013476851 | 0.0021449842 | 0.001320497 | 9.7258604e-30 | 2.4240047e-06 |
| traceGas | 1 | 400 | 1244.718107 | 1244.687698 | 2.4429963e-05 | 0.00069240889 | 0.0011347505 | 0.00066761612 | 4.9173452e-30 | 6.1156141e-07 |
| traceGas | 1 | 800 | 1244.718107 | 1244.710552 | 6.0698025e-06 | 0.00035925292 | 0.00062804875 | 0.0003328681 | 2.4517273e-30 | 1.5177158e-07 |
| traceLiquid | -1 | 100 | 558.6568252 | -558.437568 | 0.00039247206 | 0.0026712076 | 0.0041953197 | 0.0026711614 | 1.9673913e-29 | 9.8706012e-06 |
| traceLiquid | -1 | 200 | 558.6568252 | -558.602146 | 9.7876035e-05 | 0.0013205412 | 0.0020740996 | 0.0013204953 | 9.7258483e-30 | 2.4224292e-06 |
| traceLiquid | -1 | 400 | 558.6568252 | -558.6431533 | 2.4472825e-05 | 0.00066768091 | 0.001048728 | 0.00066763447 | 4.9173303e-30 | 6.1299781e-07 |
| traceLiquid | -1 | 800 | 558.6568252 | -558.6534078 | 6.1170278e-06 | 0.00033291947 | 0.00052289671 | 0.0003328731 | 2.4517112e-30 | 1.5253922e-07 |
| traceLiquid | 1 | 100 | 558.6568252 | 558.4375682 | 0.00039247169 | 0.0026712076 | 0.0041953196 | 0.0026711614 | 1.9673913e-29 | 9.870592e-06 |
| traceLiquid | 1 | 200 | 558.6568252 | 558.602146 | 9.7876101e-05 | 0.0013205412 | 0.0020740996 | 0.0013204953 | 9.725848e-30 | 2.4224354e-06 |
| traceLiquid | 1 | 400 | 558.6568252 | 558.6431532 | 2.4472942e-05 | 0.00066768089 | 0.001048728 | 0.00066763447 | 4.9173304e-30 | 6.1299661e-07 |
| traceLiquid | 1 | 800 | 558.6568252 | 558.6534078 | 6.1171767e-06 | 0.00033291948 | 0.00052289689 | 0.00033287316 | 2.4517113e-30 | 1.5254658e-07 |

## 6. Acoustic convergence

14 个四级 ladder 全 PASS：波速方向正确，趋向 U±cPE，速度/状态/p 误差满足冻结下降门。详见 acoustic_complete_gate.json 与 ladder_gates；误差按 strategy0 资格解释。

## 7. Pure limits

gas/liquid 动态回到 K=0 的相应 Euler 极限，严格根与 absent-phase query 门通过。pure-liquid 冻结能量参考可给出合法负 Eint，因此基准框架只检查有限性与 native EOS 恢复；早期把高马赫正能量要求套到基准液体的工具错误记录于 assessment_guard_misapplication.json，不改变 EOS/预算。

## 8. Trace limits

traceLiquid/traceGas 的 P2 minority magnitude=1e-20；保持 TRACE_PRESENT，不阈值删除，不转 pure；± 四级波速收敛，K/cPE 有限，presenceLoss=0。

## 9. Mixed dynamics

mixed01/05/09 ± 声学全部 PASS，按 MC3 eigenstructure 构造相密度/alpha/U 响应；逐步 K/source/cPE/response/p/T 见 trajectory。全部执行案例 K 范围 [-0.8709522132172088,0.0]、source 范围 [-316.09364160134317,306.49778287615254]。弱混合激波同时有限激活 p/U/alpha/两相质量，严格状态及保守耦合通过，路径动态门失败。

## 10. Contact cases

| kind | N | measured speed | centre error | trajectory p error | rho error | alpha L1 smearing |
| --- | --- | --- | --- | --- | --- | --- |
| combined | 100 | 46.9768364 | 4.9131328e-06 | 1.9939606e-13 | 6.750156e-14 | 0.023701421 |
| combined | 200 | 46.99419962 | 1.2359609e-06 | 2.6401104e-13 | 1.1157741e-13 | 0.016798555 |
| combined | 400 | 46.99853003 | 3.1241635e-07 | 3.3661962e-13 | 1.5198953e-13 | 0.011855598 |
| combined | 800 | 46.99962745 | 7.915244e-08 | 5.2047255e-13 | 3.8302694e-13 | 0.0083641623 |
| moving | 100 | 46.97660228 | 4.9232198e-06 | 2.1888713e-11 | 6.0983441e-12 | 0.023734917 |
| moving | 200 | 46.99414143 | 1.2512739e-06 | 2.1888713e-11 | 7.048917e-12 | 0.016891819 |
| moving | 400 | 46.99851499 | 3.1627101e-07 | 2.1888713e-11 | 9.2886809e-12 | 0.01191783 |
| moving | 800 | 46.99962361 | 7.9919081e-08 | 2.1888713e-11 | 8.4867668e-12 | 0.0083983586 |
| species | 100 | 46.97975223 | 3.7254635e-06 | 2.1094237e-14 | 6.4392935e-15 | 5.6343818e-17 |
| species | 200 | 46.99486819 | 8.4899719e-07 | 3.2085445e-14 | 1.8207658e-14 | 1.5688839e-16 |
| species | 400 | 46.99870702 | 1.6368257e-07 | 3.5083048e-14 | 3.4305891e-14 | 2.7280261e-16 |
| species | 800 | 46.9996765 | 1.6360908e-08 | 4.4964032e-14 | 4.8627768e-14 | 2.393398e-16 |
| stationary | 100 | 2.106581337e-28 | 0 | 2.1176838e-11 | 4.4063642e-12 | 0.023715664 |
| stationary | 200 | 1.57119917e-27 | 0 | 2.1176838e-11 | 6.7014172e-12 | 0.016829493 |
| stationary | 400 | 1.713885201e-27 | 0 | 2.1176838e-11 | 7.5927042e-12 | 0.011937198 |
| stationary | 800 | 1.04368546e-26 | 0 | 2.1176838e-11 | 7.6790796e-12 | 0.0084215937 |

stationary/material、moving、species、combined 各四网格，共16实际PDE算例，contact_complete_gate PASS。

## 11. Moving contact

基准 U=47 m/s，测得速度 46.97660228→46.99414143→46.99851499→46.99962361，趋于 U；位移误差随网格下降。common p/U，source 仅 roundoff 数值活动，逐步数值保留。

## 12. Species contact

独立 N−1 原始组分输运、dependent residual closure，species 与 combined 接触四级 PASS；max closure 见第36项。没有归一化校正。局部 intrinsic gas density 相对于同 Y 的原生 EOS 参考比较。

## 13. Pressure oscillation audit

接触 full trajectory pressure gate≤1e-8、U/rho≤1e-8 全 PASS。alphaL1 衡量数值扩散；最细 moving 接触 p 漂移≈2.19e-11，与可见一阶 smearing 分开报告。

## 14. Weak shock

mixed01，p ratio=1.05，pre p=3MPa/TG=800K/TL=300K，post 由保守 energy Hugoniot+冻结三腿 alpha 路径联合生成；reference s=235.95479291662429 m/s，alpha_post=.1032818472411322，rho_post=87.22982188606139，U_post=7.527993199021949。reference energy residual≈9.74e-12、alpha path≈−4.43e-11；四级 PDE 都正常完成，动态路径收敛门失败。

## 15. Moderate shock

NOT_EXECUTED / FIRST_BLOCKER_STOP。ratio=1.25 的程序设计已保存，弱激波门失败后未运行。

## 16. Original shock

本轮 DYN 原始激波位置/平台/RH 加密 NOT_EXECUTED / FIRST_BLOCKER_STOP。MC5 原始100网格到 .00055 的431步资格保持 COMPLETE，历史运行不冒充本轮动态加密证据。

## 17. Shock mesh ladder

| N | steps | measured s | speed relative error | plateau error | conservative RH max | alpha RH raw | alpha RH scaled |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 100 | 54 | 236.314803243 | 0.0015257598 | 0.0034456789 | 0.0038690855 | 0.00017941512 | 0.00024945084 |
| 200 | 109 | 236.20167741 | 0.0010463212 | 0.00084342282 | 0.0020437055 | -0.00030467908 | 0.00039896152 |
| 400 | 218 | 236.125837337 | 0.00072490335 | 0.00012894271 | 0.0011926199 | -0.00032212947 | 0.0004153908 |
| 800 | 435 | 236.073406058 | 0.00050269435 | 2.7680354e-05 | 0.00076624309 | -0.00021824972 | 0.00028072964 |

同一物理初态、同一模型/冻结路径/CFL策略/strategy0。shock_programme_before_runs.json 固定 locator [.35,.62] 正压降 centroid、post plateau [.425,.455] 与 pre [.54,.60]。

## 18. Shock speed convergence

PASS：相对速度误差 .00152576→.00104632→0.000724903353→.000502694；采用确定性 compression-gradient centroid，使用实际 final t，不凭视觉取波前。

## 19. Plateau convergence

PASS：最大相对平台误差 .00344568→.000843423→.000128943→.0000276804。窗口运行前由初始几何固定；均匀体积 Q/P2 平台均值仅只读诊断，不修改任何 committed state。

## 20. Conservative RH

PASS：mG/mL/momentum/Et/independent species 与 residual species 的 s[Q]=[F] scaled maximum 逐级下降 .00386909→.00204371→.00119262→.000766243。逐分量原始/归一化项保存在 cases/mixedShock_weak_*/shock_RH.csv。

## 21. Alpha path RH

用冻结 −s[a]+[au]−IaK；不是普通保守 RH。各级 u*/KL/KR/IK/IaK/plateau metadata 在 shock_metrics 与 cases shock_metrics.json；最细 u*=3.8415558469583146，KL=−.1028447092160856，KR=−.09960004358049482，IK=.7617037840939922，IaK=−.003137203872160565，raw residual=−.00021824972471404854。

## 22. Path convergence

**FAIL / SHOCK_PATH_DYNAMIC_BLOCKER**：scaled .0002494508426561688→.0003989615236989006→.00041539079908587756→.0002807296424675319，非逐级下降，均高于 already-resolved floor 1e-8。最细<.05 绝对阈值不足以通过 trend。local K divU 微观 algebra identity 通过不能认证端点路径的非线性平台 RH；可能涉及数值粘性/有限平台与端点路径的关系，本轮不作唯一因果归因、不修 source、不调整路径或预算。

## 23. Entropy diagnostic

EOS 一致代理 ∫Cp/T dT−v_T dp，64段 Simpson，逐相以及 mass-weighted mixture 报告。混合 entropy jump .00907577→.00662659→.00455022→.00309666 均为正；液相代理分别有小负值（最细−.00129101），明确保留，不能把混合正值称完整两相 entropy proof。reference 两相代理均正。runner 原负值容差以2500作Cp近似归一；因所有混合值严格为正，符号结论不依赖近似阈值，本轮没有熵符号阻塞。

## 24. High-Mach matrix

NOT_EXECUTED / FIRST_BLOCKER_STOP。预冻结 gas/mixed/trace，offset 0/+3000/−3000 与 moving contact 设计；不得用代数或旧 local controls 冒充本轮 PDE。

## 25. Eint cancellation

独立逐步 energy.csv 已记录执行案例 Et/kinetic/Eint/Eint-over-Et/lost-bit estimate/p/T；高马赫大动能相减压力漂移门未执行，未获资格。signed EOS energy reference 的基准液体合法负值不称 spurious negative。

## 26. High-Mach recovery

NOT_EXECUTED，不能宣布 high-Mach/R1 cancellation 稳定。

## 27. Galilean pairs

设计 baseline 与 ±3000 offsets；transform back thermo fields/species/relative wave positions。NOT_EXECUTED。

## 28. Galilean refinement

预冻结 N100/200/400、transformed L1下降且 finest≤.15；NOT_EXECUTED。

## 29. K/cPE frame invariance

代数预算继承 MC3；本轮 frame-paired actual PDE 未运行，未独立获得动态不变性资格。

## 30. Strict / native roots

76实际案例，accepted steps=6651，native=3767100，strict=3767100，toleranceOnly=0，acceptedRecoveryFailures=0。全部 selected dt/time/state 与冻结 operator deterministic replay 精确匹配，最终 restart committed/old bits 精确；不是任意状态 native instrumentation counter。

## 31. TL envelope

有液体 accepted states TL=[299.99932171175413,300.0295394802436] K，均在265–400K；mixed min root margin=3530735.7068524067。纯气体 missing-liquid ±inf 哨兵不参与 envelope。没有持续 boundary pinning。

## 32. Temporal regression

执行案例 PASS，TD1未改；minimum dt=1.506365143536153e-07，minimum accepted/fresh=1.0，median ratio=1.0。无 collapse，本轮严格结果不扩大到尚未执行的高马赫。

## 33. Reject / retry / rescue

requested rejects=0；rejected candidates=0；retries=0；rescues=0。每case td1_steps/candidates 原始证据保留。

## 34. Conservation

全为周期算例，Q1..9 integral ledger max=1.042230751227864e-15 <1e-10；实际 conservative updates 原始位匹配，无state correction。非周期 boundary-flux programme未执行。

## 35. P2

sole authority，mismatches=0，presenceLoss=0，无clip/threshold。alpha=.5 signed-minority编码分支不是物理jump；assessment使用冻结 DD fractionDifference。旧错误metric与重新评估日志保留 metrics_initial_encoding/log.P2_metric_reassessment，修正测试工具未改 PDE/state/budget。fresh initial v1 envelope只适配冻结IO header，原始Q/P2未改，新EOS/model生成及主程序显式v3/newmodel；不是历史K0 fallback，也不是production restart。

## 36. Species

max residual closure=1.713521157366094e-16 <1e-12；N−1输运原始独立species，dependent原始残量，无归一化。

## 37. Path guard runtime

driver guard calls derived=3767100，17 nodes/face；independent audit face calls=3780402；pure faces=566000，inheritance faces=0，trace faces=566000；reject=0由无trial/failure与精确replay推导，没有新增native计数器。K identity max=5.551115123125783e-17，a+K max=2.168404344971009e-19；没有branch/domain异常或fallback，但微观恒等式PASS不补偿动态path门FAIL。

## 38. cPE-only audit

执行案例 PASS：显式新model配置，冻结 recovery.cMix 新分支=cPE，KT取恢复cMix，joint CFL沿用该wave；binary/source identity、全状态replay与mixed实测声速提供证据。old-cA active decision count=0 是冻结dispatch派生结论，不是新插桩计数；cA仅独立audit诊断，cPE_only_audit.json记明证据边界。

## 39. Executable / libraries

| installed path | SHA256 |
| --- | --- |
| /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/bin/rhosprayVoFDPMFoam | 43facf56b8137bf658bb7c960718d186665160a3eb028b6f913204f3dfef2cd3 |
| /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayLiquidEOS.so | 1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888 |
| /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayFiveEqThermo.so | f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896 |

115 libraries全hash与MC5相同；fresh build记录和runtime_after保存。

## 40. Source hashes

111项manifest SHA `faa51fb1175308183f3760f097dd26b0bf3b288550f8a5b874e93c51e71e6885`，source_before=source_after，source_delta={}。harness/runner/报告为本轮新证据文件，不是active solver源。MC4/MC5 ZIP与MC5所有封存证据保护通过。

## 41. EOS hashes

| v3 artifact | SHA |
| --- | --- |
| liquidEOS/ndecane_gibbs_v3/coefficients.json | 610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac |
| liquidEOS/ndecane_gibbs_v3/energy_reference.json | ed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef |
| liquidEOS/ndecane_gibbs_v3/GibbsPotentialLiquidEOSV3.H | 421c5be26ac0aedd4c1ec8554cbb4f10591d7b126cae312fb4f7bccfcff3733d |
| liquidEOS/ndecane_gibbs_v3/metadata.json | 9204877ded9c220ff5a309eb2cbedccc7ea36263a78dd46fa83be2d11961e1f6 |

EOS operational domain与coefficients/energy reference不改。

## 42. TD1 hashes

contract `d415b10f2b1eb67e77e1c0062950b2afeaf7033ca9491592edc1d0ec0af1fba1`；policy `a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062`。与MC5一致。R1/species/strategy0亦在111冻结manifest。

## 43. Foundation hashes

Foundation6717、native parcel19、installed libs115全PASS；原始逐文件 sha256sum -c 输出 foundation_after.txt/native_parcel_after.txt，保留历史K0证据。

## 44. DYN COMPLETE?

NO。acoustic PASS/contact PASS，shock alpha path trend FAIL；high-Mach/Galilean NOT_EXECUTED。未把未运行项目标PASS。

## 45. M6B.1 COMPLETE?

NO / PARTIAL。MC3、MC4、MC4A、MC5与TD1历史资格不撤销，本轮动态闭合未取得。

## 46. M6B.2 authorized?

NO；本轮禁止自动进入，不执行。

## 47. Restart status

fresh initial envelope与final deterministic bits仅验证本轮IO/replay，production restart certification未授权/未执行。

## 48. M6B / M6B.1 status

M6B=PARTIAL，M6B.1=PARTIAL，DYN=BLOCKER_STOP；禁止本轮模型/path/TD1/EOS补丁。

## 49. Milestone matrix

| stage | state |
| --- | --- |
| MC3 | COMPLETE / frozen |
| MC4 / MC4A | COMPLETE / preserved |
| MC5 | COMPLETE / preserved |
| TD1 | COMPLETE / preserved; executed DYN regression PASS |
| EOS3 | COMPLETE / frozen 265–400K |
| DYN acoustic | PASS / 56 cases |
| DYN contact | PASS / 16 cases |
| DYN weak shock | 4 cases completed; alpha path trend FAIL |
| DYN remaining shock / high-Mach / Galilean | NOT_EXECUTED / FIRST_BLOCKER_STOP |
| DYN-CLOSURE | PARTIAL / SHOCK_PATH_DYNAMIC_BLOCKER |
| M6B.1 / M6B | PARTIAL |
| M6B.2 / highorder / ALE / active DPM / MPI / T4-S3 / production | NOT_EXECUTED |

**STOP**。本报告不授权下一轮修模或新阶段。
