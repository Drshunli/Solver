# Final future five-equation field ownership — DESIGN ONLY

## Current runtime (unchanged)

rho,rhoU,rhoE belong to legacy gas KT; thermo.he() is gas sensible e.
alphaL is an independent provisional MULES/interface field; alphaG=1-alphaL.
phi/phiUp/phiEp retain legacy mass/momentum/energy flux semantics. No actual
mG/mL/mixture Et exists. Never construct a shadow Q from these fields or from
rhoLdiagnostic. No bridge instance or recovery call exists in the main loop.

## Future atomic activation: single writers

| Field | Owner/writer | Meaning | Dimensions [M L t Theta n I J] |
|---|---|---|---|
| alphaL | material equation | resolved liquid volume fraction | [0 0 0 0 0 0 0] |
| alphaG | derived alpha module | 1-alphaL | [0 0 0 0 0 0 0] |
| mG | gas partial-mass equation | alphaG*rhoG | [1 -3 0 0 0 0 0] |
| mL | liquid partial-mass equation | alphaL*rhoL | [1 -3 0 0 0 0 0] |
| rhoMix | state derivation only | mG+mL | [1 -3 0 0 0 0 0] |
| M / rhoU | mixture momentum equation | rhoMix*U | [1 -2 -1 0 0 0 0] |
| Et / rhoE | mixture energy equation | mG*eG+mL*eL+rhoMix*U^2/2 | [1 -1 -2 0 0 0 0] |
| U | recovery | M/rhoMix | [0 1 -1 0 0 0 0] |
| p | recovery | local common mechanical pressure | [1 -1 -2 0 0 0 0] |
| rhoG | recovery | mG/alphaG when gas present; pure limit mG | [1 -3 0 0 0 0 0] |
| rhoL | recovery | mL/alphaL when liquid present; pure limit mL | [1 -3 0 0 0 0 0] |
| TG / T | recovery | gas temperature | [0 0 0 1 0 0 0] |
| TL | recovery | liquid temperature | [0 0 0 1 0 0 0] |
| eG / gas thermo.he() | recovery gas projection | OF7 JANAF Es | [0 2 -2 0 0 0 0] |
| eL | production liquid EOS/recovery | native e+C_L | [0 2 -2 0 0 0 0] |
| cG / cc | gas evaluator | gas acoustic speed | [0 1 -1 0 0 0 0] |
| cL | liquid evaluator | liquid acoustic speed | [0 1 -1 0 0 0 0] |
| cMix | recovery Allaire closure | future authoritative model wave/CFL speed | [0 1 -1 0 0 0 0] |
| betaG,betaL | phase evaluators | de/dp at fixed rho,Y | [-1 3 0 0 0 0 0] |
| psi | gas thermo projection | gas-only d(rhoG)/dp at fixed TG,Y | [0 -2 2 0 0 0 0] |
| Yi | gas species recovery/transport | intrinsic gas mass fraction | dimensionless |
| mYi | gas species equation | mG*Yi | [1 -3 0 0 0 0 0] |

The phase-presence decision precedes m/alpha. Absent phase outputs are tagged
ABSENT and are not valid intrinsic thermodynamic states.

## Naming decision

Choose B: eliminate ambiguous rho from the new core; use explicit rhoMix.
A compatibility reference/view to rhoMix may be supplied only where a mixture
subsystem requires rho; it must have no independent evolution/update authority.
DPM is explicitly excluded from that mixture view and always receives rhoG.
Retain rhoU/rhoE names only at an eventual atomic switch to M/Et semantics.
p retains its name; T is the gas TG compatibility name; TL is explicit.
psi and cc remain gas quantities, never mixture compressibility or model wave
speed. There is no mixture temperature. No pEqn or independently solved phase
pressures: common pressure varies spatially and is common only locally.

Gas thermo becomes a one-way compatibility/property projection from recovered
p,TG,Y,eG. Its correction must not become a second writer of common p, rhoMix,
Et or TL. Never assign mixture specific energy to thermo.he(), or replace
rhoMix by thermo.rho(). The eventual projection/cache-refresh implementation
requires its own audit before activation; no such projection is active now.

## DPM and sources

Hard carrier contract: density rhoG, temperature TG, common mechanical p.
Parcels do not enter alphaG+alphaL=1. Gas-only source placement and DPM versus
Eulerian-liquid energy ledger remain future gates. No DPM density switch to
rhoMix is permitted. Turbulence/transport projections also require explicit
phase semantics; linking the library does not choose or activate them.
