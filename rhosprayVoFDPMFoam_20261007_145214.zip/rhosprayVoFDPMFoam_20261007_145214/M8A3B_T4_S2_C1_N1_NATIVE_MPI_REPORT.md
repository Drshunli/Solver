# M8A.3B-T4-S2-C1-N1 — OF7-native MPI path consolidation

2026-10-04. **COMPLETE**, only within the isolated two-rank, fixed decomposition, one seeded parcel per trial, passive fixture. T4-S2/T4/M8A remain PARTIAL. No S3, active integration, production restart or CFD.

## Architecture and actual implementation

The supported N1 path is native Foundation7 `cloud.evolve()` → unchanged `Cloud::move()` → project C2 parcel `move()` → native tracking/processor patch crossing → inherited native prepare/correct transfer methods → native PstreamBuffers/UOPstream/UIPstream/transfer lists/ParticleType::iNew loop. The frozen C2 parcel family supplies its existing native-compatible field IO. No new packet format, serializer, migration queue, rank-owner layer or Foundation copy was created. S1 exchanges conservative carrier state only at explicit publication; query/preflight/materialize do not communicate.

The one modified C2 header in the isolated N1 target adds an outer `move` wrapper. Other parcel bodies and field IO are included directly from frozen C2; the previous experimental18 companion copies do not enter N1. Two redundant transfer diagnostic delegates were removed after the consolidation manifest was written; native methods are now inherited directly. The original interrupted C1 and timeout sources/logs remain immutable historical material and are absent from the N1 build graph. No separate production MPI transport existed to delete. No source file was deleted.

`MPIFailureLatch` is external/trial-local: failed/reason/failureType/failingRank/orig identity/current pose/cell/tet/generation/query-stage plus a diagnostic capture callback. It is not a parcel member, migration field, restart field or carrier publication. The catch examines known rejection categories only (`GAS_SUPPORT_INVALID` and its colon reason, `STALE_GENERATION`, `DISTRIBUTED_GENERATION_MISMATCH`); other standard exceptions are rethrown, and non-standard exceptions are not caught. The direct unknown-exception control resets the parcel before native `move`, verifies the programming exception escapes and leaves latch/quarantine false. It is not a full MPI unknown-fatal job certificate.

On known rejection: keepParticle stays true; switchProcessor=false and stepFraction=1 are **COMMUNICATION QUARANTINE**, restricted to the dirty trial. No gas value is returned, no contributor removed, no weights changed, no physical deletion triggered. The parcel remains owned by its native trial cloud. All scalar/history fields collected by the existing C2 parcelScalars helper, excluding only the authorized stepFraction marker, are compared before/after quarantine/native evolve. They remain bit-identical. This one-parcel fixture executes no ORourke pair physics after rejection; generalized multi-parcel model suppression and eight-model MPI closure are not certified.

After every rank's native evolve returns, all execute the same Foundation `reduce(globalFailed,orOp<bool>())`. No barrier and no query collective is added. Exactly-one identity ownership is checked at stable boundaries. There is no outside-evolve rank-local catch/return rejection strategy in N1.

Rollback uses the frozen C2 `transactionState-v1` codec/state, output staging and the existing R2 transaction `discard()` body unchanged. The isolated transaction class only changes its owner-view type/include to the existing StableCommittedCarrierView as an immutable rollback sentinel. This sentinel never supplies MPI carrier queries; S1 is the authority. N1 does not call serial LazyTrialBinding/evolve, prepare/publish/flush or certify a distributed commit. The fixture binds S1 to the disposable trial cloud, invokes native evolve and, at the safe rejection boundary, calls existing discard. A real pending output ticket is staged each trial and removed by that existing discard. All accepted Q/P2, parcel fields/order/IDs, allocator, complete OF7 RNG/cached-normal, sources, histories, generation, pending output and time/index are checked by exact pre/post existing state encoding; the carrier-view sentinel and external Time/deltaT are restored as well. No new rollback schema or migration serializer is introduced.

## Evidence and retained attempts

The old outside-evolve strategy was freshly reproduced in the interrupted C1 evidence directory: exit124 after25s. It is an old-path failure, not a supported rejection. N1's final positive/forward-negative/reverse-negative/local-negative/unknown controls all exit0 with zero result assertions. The valid current identity/pose/U/T/d/nParticle CSV is byte-identical to the earlier successful S2 fixture. Valid latch/no-latch native stream, full OF7 RNG state including cached-normal and32 copied-RNG probes perrank match exactly. This is a latch non-interference check; it does not replace future sender/receiver boundary codec/RNG certification.

Final stress:500 forward +500 reverse failed native crossing trials, normal exit0, all1000 complete. Every rank records500 native-return, reduction-enter/exit, discard and finalize phases. Destination local latch=true, peer=false, globalFailed=true. Destination rho/T/Y/Cp/mu/kappa/recovery counters all zero each cycle. Existing encoded state restores exactly; registry/live delta0; pending and accepted output directories empty. Source-rank ctor1001/dtor1000/live1 includes its untouched committed parcel baseline; destination ctor500/dtor500/live0. Per-trial ctor/dtor increments balance and live returns to pretrial baseline; do not misread the intentionally retained committed parcel as a trial leak.

First long attempt hit a55s watchdog after480 completed discards and was retained as INCOMPLETE, never PASS. Final batches removed this short watchdog and terminated normally. Timeout/kill is not a transaction rejection path. No surviving test process remains. A final metadata-only correction marks the direct unknown move control as nativeCloudEvolve=false; final six controls were recompiled/replayed after that correction. The1000-cycle stress code was unchanged apart from this diagnostic JSON flag; executed-binary SHA and diff are retained.

## Required37-item report

| # | Item | Result |
|---|---|---|
|1|N1 status|COMPLETE in the stated isolated fixture scope|
|2|OF7-native architecture|Foundation owns parcel transport; fiveEq owns support/rejection/rollback|
|3|Consolidation manifest|OF7_NATIVE_MPI_CONSOLIDATION_v1.md + per-file classification/build graph|
|4|Kept local components|P2/R1/recovery, lazy C2 support, frozen S1, I1, v1 transaction, source/output adapters|
|5|Removed components|Two redundant diagnostic transfer delegate functions; duplicate companion code excluded from N1|
|6|Removed files|None; no independent obsolete transport was found; history/frozen sources retained|
|7|Test-only files|N1 fixture/latch/bridge/owner binding; all historical targets outside supported graph|
|8|Foundation components|Native tracking, processor patch, Cloud::move, transfer lists, buffers/streams/iNew, reduce and native model algorithms|
|9|Cloud::move authority|Sole migration authority; no copy or modification|
|10|Stream/iNew authority|Foundation transfer protocol + unchanged C2 native-compatible field IO; no new serializer|
|11|Failure latch|External, trial-local; complete identity/pose/reason/rank/generation diagnostic record|
|12|Exception boundary|Outer project parcel move; known rejection only; unknown propagates|
|13|Valid crossing|rank0 owner1→0, rank1 owner0→1; identity/pose/selected fields unchanged; latchfalse; exit0|
|14|Forward invalid|Real crossing→rank1 EXACT_GAS_ABSENT→quarantine→global reject→discard; exit0|
|15|Reverse invalid|Real rank1→rank0 crossing, same clean behavior; exit0|
|16|Local invalid|No processor crossing; same local latch/reduction/discard; exit0|
|17|Post-evolve reduce|Both ranks normal return and same native OR; no barrier|
|18|Support-first counters|Destination rho/T/Y/Cp/mu/kappa/recovery all0 each failed cycle|
|19|Ownership|Native cloud sole owner; one tracked identity at stable boundaries; no support-deletion/orphan/duplicate|
|20|Lifetime|Per-trial ctor/dtor balanced; live restored to committed baseline1 at source /0 at destination|
|21|Source publication|Zero accepted dmG/dmYi/dM/dEt; accepted Q and native source state exact; no publish call|
|22|Output publication|Zero; real pending ticket prepared then existing discard removes it|
|23|Generation|Committed and S1 generation1 unchanged; latch publishes nothing|
|24|Discard restoration|Existing v1 encoded state and sentinel exact; allocator and Time/deltaT restored|
|25|100-failure stress|Exceeded:1000 total,500 consecutive per direction; normal exit0|
|26|Registry/deadlock|Registry/live/binding baseline restored every cycle; no final-batch deadlock; no remaining process|
|27|Serial regressions|R2B252194/I112083/C217 checks, all0failure; frozen serial phase17 checks PASS|
|28|S1 regressions|3364 topology +20051 support +12MPI audit +17serial phase checks, all0failure;1000valid/invalid/stale cycles perrank; weights exact|
|29|Foundation hashes|6717 source checks and19 native parcel checks PASS|
|30|Project hashes|2730 protected source/evidence files unchanged before authorized milestone append; selected N1 hashes retained|
|31|Active solver|NONE; N1 is not linked/instantiated there|
|32|Production mesh/BC|NONE; tests use fresh copied fixtures|
|33|N1 COMPLETE?|Yes, bounded C1-N1 failure-disposition/consolidation gate only|
|34|Resume T4-S2?|NEXT ROUND ONLY after new instruction; remaining migration certification not executed|
|35|T4 status|PARTIAL; S3 not authorized|
|36|M8A/M6B/CFD|PARTIAL /NO /NO; production restart NOT CERTIFIED|
|37|Milestone matrix|See below and append-only MILESTONE_STATUS.md|

## Milestone matrix

| Milestone | Status / scope |
|---|---|
|R2-FINAL/T3|COMPLETE/FROZEN — serial passive fixed-mesh contract; native ORourke limitations retained|
|T4-S1|COMPLETE/FROZEN — two-rank distributed support only; freshly regressed|
|T4-S2-C1-N1|COMPLETE — scoped native communication-safe rejection and existing discard|
|T4-S2|PARTIAL — boundary snapshots, authoritative migration field/RNG semantics and remaining model gates not executed|
|T4-S3|NOT AUTHORIZED|
|T4/M8A|PARTIAL/PARTIAL|
|M6B/CFD|NO/NO|
|Production restart|NOT CERTIFIED|

STOP. Next round may resume S2 certification; no S3 or active integration is implied.
