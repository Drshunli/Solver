# M8A.3B-T3B-R2C-C1 — Parcel binary extent and instrumentation separation gate

## 1. C1 status

PARTIAL / NONDETERMINISTIC_BINARY_BLOCKER / STOP.

## 2. Original codec blocker

Outer LifetimeToken layout pollution removed only in isolated C1. Original128-versus120 overrun no longer reproduced there; frozen I1 retained for provenance. Full PARCEL_CODEC_BLOCKER closure not certified because byte determinism fails.

## 3. Instrumentation relocation

Five instrumentation files changed in tests/fiveEqDPMParcelC1: remove member; constructor hooks after successful completion; virtual destructor hook; external registry. No native physical formulas or injection guard changes.

## 4. Lifetime evidence mechanism

External address-keyed map increments construction/destruction and rejects duplicate/unknown addresses. The executed probe closes4 constructions=4 destructions/live0; native oracle excluded from local counters. Guard/adoption counters remain available. This is not the full1000-cycle recertification.

## 5. Native/local layout map

Four layers and native counterparts measured in layout.csv; see PARCEL_LAYOUT_AUDIT_v1.md. Kinematic first108 within112-byte base tail is handled by native offsetof expression.

## 6. sizeof/alignof table

| Type | Base size | Size | Align | First | End | Raw extent | Physical span |
|---|---:|---:|---:|---:|---:|---:|---:|
| localKinematic | 112 | 216 | 8 | 108 | 216 | 108 | 108 |
| localThermo | 216 | 232 | 8 | 216 | 232 | 16 | 16 |
| localReacting | 232 | 264 | 8 | 232 | 240 | 8 | 8 |
| localSpray | 264 | 384 | 8 | 264 | 384 | 120 | 120 |
| nativeKinematic | 112 | 216 | 8 | 108 | 216 | 108 | 108 |
| nativeThermo | 216 | 232 | 8 | 216 | 232 | 16 | 16 |
| nativeReacting | 232 | 264 | 8 | 232 | 240 | 8 | 8 |
| nativeSpray | 264 | 384 | 8 | 264 | 384 | 120 | 120 |

Actual Gcc11.4, C++11, DPInt32, x86-64 ABI. Intel2021 NOT certified.

## 7. Physical payload definition

Authoritative physical members, native-persisted derived/history members, transient state and external diagnostics separated in the layout audit. Reacting Y list uses explicit list IO; list pointers never raw serialized.

## 8. Binary extent

All four local/native raw extents match their native-defined contiguous spans and remain object-bounded. Outer120 bytes starts264/ends384; total355 bytes local=native.

## 9. Writer fence

PASS: both copies preserve32-byte leading/trailing fences on write.

## 10. Reader fence

PASS: binary constructor preserves32-byte leading/trailing fences.

## 11. Sentinel independence

PASS for changing reserved leading/trailing fences only. Construction-time in-object padding challenge separately FAILS; these results must not be conflated.

## 12. Address independence

NOT CERTIFIED: identical physical parcels at separate placement addresses have differing bytes. Cause evidenced as retained padding, not demonstrated address-pointer serialization. Fresh ordinary-heap matrix NOT RUN after STOP.

## 13. Deterministic write

Same live object repeated write PASS. Across fresh same-state copy objects FAIL:10 bytes differ with A5/5A storage. Unmodified native control also fails this strict canonical-byte requirement.

## 14. Copy result

Physical ASCII equality PASS; copy binary equality FAIL. Source fields not changed to compensate.

## 15. Clone result

NOT RUN after STOP.

## 16. iNew result

Direct stream-constructor basic readback physical ASCII PASS. Formal iNew/write-again matrix NOT RUN after STOP; not promoted.

## 17. Evolved parcel result

NOT RUN after STOP. Probe uses physically initialized parcel, not a claim of evolved injection/stochastic/drag/breakup coverage.

## 18. KH parent/child

NOT RUN after STOP.

## 19. ORourke-mutated result

NOT RUN after STOP; native collision physics unchanged.

## 20. Rebound-mutated result

NOT RUN after STOP.

## 21. Lazy-cache exclusion

No cache/support/interpolation members added to parcel; native IO expressions unchanged. Transient cache owners remain separate. Read-rebuild evolved matrix NOT RUN.

## 22. Test-counter exclusion

LifetimeToken member removed; external hooks no storage, no RNG changes, no global allocation interception. Same local/native sizeof384; external map addresses absent from parcel fields. Padding still prevents canonical-byte certification.

## 23. Transaction codec impact

NONE. Existing transactionState-v1 ASCII+typed scalar-bit path retained unchanged; no swap to parcel binary codec. Pending tickets remain transaction-owned.

## 24. I1 regression

Frozen ownership sources/binaries hash-identical. Fresh external-instrumentation orphan/A-H/move/adoption suite NOT RUN after mandatory STOP, so external relocation not fully I1-certified.

## 25. 1000-birth stress

NOT RUN with relocated instrumentation; original frozen12083/0 I1 evidence remains valid within its old scope, not transplanted into C1.

## 26. R2B regression

Fresh numerical252194 replay NOT RUN after STOP. Frozen30-file and240-file manifests unchanged; support-first framework untouched.

## 27. Native equality

Native/local ASCII physical oracle matches and stream lengths355 agree in the probe. Full evolved accepted all-gas canonical replay NOT RUN. Native padding sensitivity recorded as control, not native physical loss.

## 28. Source/energy regression

Fresh9288+8goldens NOT RUN after STOP; frozen pass evidence retained. M8A.3A6375 likewise not freshly replayed.

## 29. T2 regression

Fresh1725880 and21000/21000 NOT RUN after STOP; frozen evidence retained.

## 30. T3A regression

Fresh64395 NOT RUN after STOP; frozen evidence retained.

## 31. P2/R1 regression

Fresh105775 NOT RUN after STOP; recovery unchanged.

## 32. Temporal/restart regression

Fresh9663 NOT RUN after STOP; production restart remains uncertified. R2C-R1 movement62 replay also NOT RUN after STOP.

## 33. Foundation hashes

FRESH6717 source/Make and19native parcel baseline checks PASS; ORourke unchanged. Native codec source provenance saved. No Foundation source edits.

## 34. Active solver impact

NONE:145protected files unchanged;240I1/R2B frozen entries unchanged;30R2B entries unchanged; frozen R1 checkpoint files except append-only milestone checked unchanged. Production mesh/BC unchanged; no CFD. Only passive C1 copies, tools/reports/evidence. OF7 wmake final PASS; initial helper used C++14 lambdas and was corrected to C++11 templates before running.

## 35. Whether C1 COMPLETE

NO. Deterministic fresh-object bytes and mandatory evolved/ownership/regression gates unmet. No padding zeroing, magic-length repair, serializer fallback or new binary version introduced.

## 36. Whether R2C-R1 may resume NEXT ROUND ONLY

NO while C1 remains PARTIAL. Recommend separate authorized decision on native raw padding contract versus explicit field-wise deterministic local serializer; preserve physical fields and external instrumentation. Do not resume remaining R2C-R1 or start R2-FINAL in this round.

## 37. Updated milestone matrix

| Milestone | Status |
|---|---|
| R2B | COMPLETE / FROZEN |
| R2C-I1 | COMPLETE / FROZEN / original passive ownership scope |
| R2C-C1 | PARTIAL / NONDETERMINISTIC_BINARY_BLOCKER / STOP |
| R2C-R1 | PARTIAL |
| R2C | PARTIAL |
| R2-FINAL | NOT AUTHORIZED |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NO |
| CFD | NO |

## Evidence

Evidence directory: fitting/dpm/m8a3b_t3br2c_c1_v1. Runtime exit3 intentionally records STOP. Source probe tests/fiveEqDPMParcelCodecC1/testParcelCodec.C. External hook family tests/fiveEqDPMParcelC1 remains an isolated candidate; its original injection executable has not been rebuilt/replayed. No failure is hidden or treated as a PASS.
