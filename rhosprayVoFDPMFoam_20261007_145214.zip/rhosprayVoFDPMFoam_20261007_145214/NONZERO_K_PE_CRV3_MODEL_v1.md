# NONZERO_K_PE_CRV3_v1

2026-10-06；当前范围：固定网格、单位截面积、均匀周期一维串行验证入口 `-serialFiveEq`。

`fiveEqBootstrap` 显式设置 `mechanicalModel NONZERO_K_PE_CRV3_v1; CRV3mu 3;`。`CRV3mu` 是非负、有限的动态黏性系数，单位 Pa·s；首版将其作为受控正则化参数，尚未标定为真实材料输运系数。mu=0 保留新模型身份并关闭黏性。旧 `NONZERO_K_PE_v1`、`HISTORICAL_K0` 继续独立可选。

非零 K、cPE、EOS、物种顺序及 P2 表示沿用已验证定义。新增项严格为

\[
M_t+F_M{}_x=(\mu u_x)_x,\qquad E_t+F_E{}_x=(\mu u u_x)_x.
\]

没有直接扩散 mG、mL、alpha、P2、species；没有额外经验加热或能量修复。横向动量保持原值；本版未实现多维黏性应力。

黏性步采用隐式中点、共享面应力及面中点速度的功通量。每个黏性子步满足

\[
\Delta E_i-\Delta\left(M_i^2/(2\rho_i)\right)
=\frac{h\mu}{2\Delta x^2}\big[(u^m_{i+1}-u^m_i)^2+(u^m_i-u^m_{i-1})^2\big]\ge0.
\]

仅接受浮点运算误差预算内的残差。周期面通量对消使总动量及总能量守恒。P2、相质量、组分在黏性子步中按位保持。总步组分仍按已有 N−1 保守闭合。

令 J=sum_present(mk beta_k)>0，则压力热响应为 heat/J，物理局部熵生产为 heat sum_present(mk beta_k/Tk)/J>=0；缺失相不参与求和，允许 TG!=TL。此结论针对 CRV3 黏性项，不能替代整个双曲通量的熵稳定性证明。

时间推进为黏性半步、原 TD1 双曲步、黏性半步；双曲步为一阶，整体不能宣称二阶。每次候选从完整 const anchor 开始；三部分使用同一 dt，全部恢复及时间检查通过后原子提交。

离散黏性矩阵 L=diag(rho)^−1 mu/dx²(2I−S−Sᵀ) 与半正定矩阵相似。lambdaMax<=4mu/(minrho dx²)。中点半步模态放大率 g=(1−dt lambda/4)/(1+dt lambda/4)。虽然能量稳定无条件成立，首版使用 dtCRV3=4/lambdaUpper，确保所有模态不发生符号翻转。mu=0 时 dtCRV3=∞。

联合上界保留原双曲、alpha/K、相质量、物种和体积界，并加入 dtCRV3、剩余时间以及原增长限制。预黏性步后重新计算界，候选回退/救援继续使用 `selectTemporalCandidate` 的原逻辑。不可表示的时间推进不得修改时钟以绕过检查。

重启数据编码新 model tag；新旧模型交叉读取拒绝。当前仍是 fresh-start 验证入口，完整生产重启及黏性参数元数据持久化尚未认证。

CRV3 路径由黏性行波选择。旧 three-leg endpoint 仅作 `REGULARIZED PATH SELECTION DIFFERENCE` 诊断，不作为强制匹配门。

工程观测门槛 <=5%，目标 <=2%；不放宽守恒、有限性、EOS、P2、组分或熵符号约束。CRV3-1 的基础串行资格不能代替 CRV3-2 黏性趋零、多波覆盖、长期串行、2D、DPM、MPI 等后续资格。
