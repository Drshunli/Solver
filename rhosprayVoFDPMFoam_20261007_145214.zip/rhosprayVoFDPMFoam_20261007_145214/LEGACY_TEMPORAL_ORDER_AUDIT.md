# M5C.3 — actual legacy temporal order (Foundation 7)

Audit date: 2026-10-01. Scope: current `rhosprayVoFDPMFoam.C`, its included equation/control files, `300_2D` dictionaries, and the installed Foundation 7 source. No equation changed. Source copies are under `fitting/integration/m5c3_v1/source_audit/`.

## Startup

`createTime` → dynamic mesh → controls → `createFields` → field references → alpha controls → OF7 interface object → diagnostic M4 mixture → fvOptions object → flux scheme. `createFields` constructs gas psiReactionThermo/SLGThermo, U (MUST_READ), rho from thermo (NO_READ), `rhoG` const alias of rho, alphaL (MUST_READ), alphaG=1-alphaL, rhoU=rho U, rhoE=rho(e+U²/2), flux storage, turbulence, reaction, multivariate Y/e table, Qdot, cloud and radiation. rhoU/rhoE are NO_READ/NO_WRITE; legacy restart is not a conservative fiveEq restart.

## Actual loop order

1. Read controls. Compute pressure-gradient diagnostic and `cc=sqrt((Cp/Cv)/psi)`.
2. `parcels.storeGlobalPositions()`. After the first step, `mesh.update()` **before** advancing Time. No explicit new fiveEq state remap exists.
3. Non-LTS: `setDeltaT.H`, then `runTime++`. Co values used here come from the preceding iteration; startup Co values are zero. This is not a same-proposal trial-admissibility gate.
4. Directed interpolation: rho, rhoU, rPsi, e; compute U±, p±, relative phiv±, cSf±, ap/am and KT weights. Tadmor selection replaces aSf/a_pos.
5. `CourantNo.H`: central Co from final amaxSf. Its separate acoustic estimate uses `1/sqrt(psi)`, **not** the Cp/Cv acoustic speed used by KT.
6. LTS branch: `setRDeltaT.H`, then `runTime++`. It uses amaxSf; optional reaction temperature timescale uses stored Qdot. The current case selects Euler, hence no LTS.
7. Set `phi` (gas mass), `phiV` (relative volume); alpha Co; MULES alpha/subcycles; interface geometry; diagnostic mixture correct. alphaG=1-alphaL. No rhoPhi.
8. Construct phiUp with pressure and phiEp with pressure work, including absolute mesh pressure work. muEff/tauMC are computed before new flow solves.
9. **`parcels.evolve()` before density and all carrier equation solves.** It samples legacy carrier fields and accumulates transfer ledgers.
10. rhoEqn: ddt(rho)+div(phi)=parcel mass source.
11. rhoUEqn: conservative convection/pressure solve, decode U and update boundary rhoU. If !inviscid, solve U correction with viscosity/tauMC, gravity and parcels.SU(U), then rhoU=rho U.
12. rhoYEqn: reaction.correct; Qdot snapshot; implicit ddt(rho,Yi), multivariate phi convection, parcel SYi, reaction R and (if viscous) species diffusion. Each solved Yi is clipped at zero; N2 is residual and separately clipped. This clipping is legacy only and is forbidden in the future conservative gate.
13. rhoEEqn: conservative Et convection, viscous work and reaction.Qdot. Decode e; boundary e; thermo.correct; boundary rhoE. If !inviscid: separate e correction with alphaEff diffusion, gravity work, parcel Sh and radiation Sh; thermo.correct again; rhoE=rho(e+U²/2). Finally p=rho/psi and boundary rho=psi p.
14. Diagnostic mixture correct; turbulence.correct; runTime.write. There is no pressure equation/PIMPLE loop in this path.

## Case vs engineering operating definition

`300_2D/system/fvSchemes`: default Euler; Kurganov; Minmod rho/T and MinmodV U; multivariate vanLeer. controlDict: ASCII/writePrecision 6, adjustTimeStep yes, maxCo .1, maxAcousticCo .2. Its application still names rhosprayVoFFoam. Actual stored inlet p/T/U are 102243 Pa /166.67 K /(517.6,0,0) m/s, **not** the later engineering locked 188330.307 Pa/400 K/2013.039 m/s. No case files were rewritten to conceal that discrepancy. The current case also lacks alphaL in its `0/` directory; it is not activation-ready.

Gas thermo: hePsiThermo/reactingMixture/JANAF/perfectGas/sensibleInternalEnergy. Combustion `none`; three runtime species C10H22/O2/N2; reactions dictionary has only commented reactions. RAS kOmegaSST; radiation none; spray heatTransfer/phaseChange none. `inviscid` actually depends on max thermo mu in `createFieldRefs.H`, **not** on the separate additionalProperties switch. Current air viscosity means the viscous branch is selected.

## oldTime and thermo ownership, verified in installed code

Foundation `EulerDdtScheme.C` uses field.oldTime(), and Vsc0/Vsc on a moving mesh. `GeometricField.C` ref/primitiveFieldRef/boundaryFieldRef call storeOldTimes; oldTime storage is allocated lazily, copied on timeIndex transition before mutation. `subCycle<volScalarField>` owns legacy alpha sub-time levels. Current source has no P2 field/time storage.

`hePsiThermo.C::calculate` obtains T via mixture.THE(he,p,T) and updates psi/mu/alpha; `correct()` calls calculate. Legacy p is later assigned from separate rho/psi. This is a sequential gas-thermo path, not a coherent mixed-Q common-pressure recovery.

New standalone oldTime test reads an existing eight-cell manufactured mesh fixture, allocates a passive signed scalar, advances Time indices and checks actual OF7 oldTime bits. It does not solve PDEs, run a case, generate a mesh or change the fixture.

## Consequence

Future fiveEq uses a transactional Euler stage with one Q/P2 authority, current-state dt bounds, and whole-state recovery. It cannot inherit independent legacy alpha, rho, species clipping, e correction, pressure overwrite, or source order. Dynamic remap, LTS, higher temporal order and source solvers need their own coherent contracts before enabling them.
