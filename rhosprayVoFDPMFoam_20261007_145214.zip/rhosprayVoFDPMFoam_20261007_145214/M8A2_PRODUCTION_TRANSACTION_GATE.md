# M8A.2 production transaction gate

Date: 2026-10-01. Status: **PARTIAL**. This report explicitly separates
tested components from the unimplemented evolved-cloud transaction.

## 1. M8A.2 status

PARTIAL. The fresh initial-state prototype is compiled/tested; it does not
meet the whole-cloud continuation, production stencil or full MPI gates.

## 2. Transaction architecture

Independent fresh native cloud + exclusive rank-local allocator scope +
immutable P2/Q support snapshot + trial-local native transfer fields +
local support/output method specializations. Discard destroys the cloud
and restores the counter. Combined cloud/Q/allocator/output commit is absent.
Fresh model initialization is not a substitute for exact continued state.

## 3. Trial-cloud ownership graph

All eight selected top-level model owners equal the fresh trial address;
runtime addresses are in fitting/dpm/m8a2_v1/owner_graph.csv. Carrier fields
are shared read-only inputs. Native sources have the trialCloud prefix.
Distribution RNG binding is established by fresh native constructors;
dependent private RNG/reference addresses have not all been exposed/tested.
This ownership result must not be generalized to native clone().

## 4. Production model capability table

| Model | State requiring coverage | Owner check | Exact continued transaction / retry |
|---|---|---|---|
| coneInjection | timing, counters, massInjected, distribution RNG reference | PASS fresh | PARTIAL: initial injection only |
| sphereDrag | switches/cache and parcel/source state | PASS fresh | PARTIAL: native drag executes, no unmodified native golden |
| stochasticDispersionRAS | cloud RNG incl normal cache, parcel UTurb/tTurb, k/epsilon cache | PASS fresh | PARTIAL: full stochastic event state unproven |
| blobsSheetAtomization | parcel liquidCore/d/nParticle and injector-dependent inputs | PASS fresh | NOT PROVEN forced transformation |
| ReitzKHRT | parent breakup variables, child fields/IDs, RNG where used | PASS fresh | NOT PROVEN child creation retry |
| ORourke | ordered pairs, RNG, mutation/coalescence/deletion | PASS fresh | NOT PROVEN forced collision retry |
| standardWallInteraction/rebound | parcel U/active and model statistics | PASS fresh | prior local rebound proof retained; full transaction unproven |
| voidFraction | trajectory residence integral; diagnostic output | PASS fresh | trial write suppression PASS; commit release NOT CONNECTED |

No model is promoted to full transaction capability on owner checks alone.

## 5. Particle-ID transaction

fiveEqParticleIDTransaction saves the actual public OF7 particleCount_.
Discard/destructor restores exactly; commit retains advancement; nested
transactions reject. IDs are (origProc,origId), counter is process-local
and shared by all clouds. Exclusive serial use, not thread-safe interleaving.

Additional native defect confirmed: CloudIO.C::readCloudUniformProperties
sets the allocator to zero if restart metadata is absent, even on fresh
trial construction. Local trial-scoped specialization suppresses this
restart read/reset. Initial nonzero IDs are checked, not only empty-zero IDs.

## 6. RNG transaction

Initial native injection replay matches serialized parcel/source outcomes
and a subsequent scalar RNG probe. Native distributionModel copy preserves
the old RNG reference; fresh construction binds to its new owner RNG.
Exact evolved RNG/normal-cache copying and all dependent addresses remain
unproven. A scalar probe is not claimed as complete RNG coverage.

## 7. Injector transaction

Real coneInjection creates 21 parcels at 1e-6 s and 42 at 2e-6 s in the
manufactured fixture. Initial small/large-discard/small replay is byte-exact
for the exported state. Continued injector timing/counters need adapters.

## 8. Breakup transaction

Native ReitzKHRT/blobsSheet models are constructed with correct owners.
No forced child/transformation test completed; gate remains open.

## 9. Collision transaction

Native ORourke owns the trial's KinematicCloud subobject. Its property-query
call form has a local guard specialization. No forced mutation/coalescence/
deletion retry completed; gate remains open.

## 10. Rebound transaction

M8A.1 local native rebound serialization proof is retained unchanged.
Whole owned-cloud retry and statistics equality are not yet established.

## 11. Source-accumulator transaction

Fresh trial rhoTrans/UTrans/UCoeff/hsTrans/hsCoeff are independent. Exported
small-step replay includes every cell/species and both coefficients.
Committed sources remain zero and unmodified. Deposit/conversion/Q combined
commit is not installed in production evolution.

## 12. Output transaction

Local KinematicCloud::postEvolve and actual VoidFraction::write suppress
trial writes. The forced writeTime fixture produces zero permanent trial
artifacts after the repair. The first failed experiment is preserved in
failed_attempt_1 and the old fixture: it wrote trialCloudTheta. It was not
treated as a valid transaction or erased as a rollback strategy.
Accepted once-only output release is not implemented/tested.

## 13. VoidFraction classification

Selected solver/model paths do not use the function's cloudNameTheta field
as a physics input. It is diagnostic. Other dense force models may use the
separate instantaneous cloud.theta() API; that does not establish a reader
of this selected diagnostic. No general claim is made about all OF7 models.
Native theta is sum(dtSub*nParticle*volume)/(dtCarrier*Vcell), so endpoint
parcel occupancy cannot replace it. fiveEqDeferredVoidFraction preserves
this formula and one-commit semantics but is not wired to native postMove.

## 14. ObjectRegistry result

1000 fresh begin/destroy/discard cycles preserve names/count after native
cache initialization. Initial native interpolation adds volPointInterpolate(U)
once; diagnostic probing also owns volPointInterpolate(dpmStencilBasis).
Names before/after warmup are recorded, not hidden. Trial source/model/Theta
objects disappear. Arbitrary continued-cloud registry rollback is unproven.

## 15. Gas-support region definition

Cell: consistent P2/mG with PRESENT or TRACE_PRESENT recovered gas. DPM:
every actual nonzero queried carrier contributor valid. Mandatory scalar
cell reads are checked independently. Region is stricter than alphaG>0.

## 16. Actual interpolation stencil result

Uses the actual OF7 vector cellPoint operator via tensor basis expansion,
including boundary values/constraints and parcel tet coordinates. Scalars
use cell. Exact nonzero test was repaired from magSqr!=0 to component !=0:
1e-200 coefficient must not disappear by squared-norm underflow. Exact zero
is ignored unless mandatory nativeRead. This is not a scalable extractor.

## 17. Strict-support feasibility scan

Actual 300_2D mesh census: 21000 cells, 42622 points, 84310 faces,
41690 internal faces, 42620 boundary faces. Probe would require 63620 basis
entities; supported limit is 256, serial only. Production maps/fractions/
bands for sharp/trace/buffer scenarios have NOT been computed. Fail-closed
unsupported behavior remains; no neighbour proxy or invented count is used.

## 18. Injection hook

Local native InjectionModel<kinematicCloudType>::inject<basicSprayCloud>:
after constrained setPositionAndCell and before parcel thermo initialization.
Provisional allocation is RAII-owned until cloud insertion, so query failure
does not leak it. Actual injection hook executes on every injected parcel.
This is an isolated executable override, not an active cloud replacement.

## 19. Tracking hook

KinematicParcel<particle>::setCellValues specializations for basicSprayCloud
and kinematicCloudType validate before rho/U/mu reads; upper parcel layers
then query T/Cp/p only after this validation. A real face crossing followed
by this installed hook rejects an absent receiving cell. MPI exception-safe
collective cancellation is not implemented.

## 20. Deposition hook

Existing sourceTrial/deposit classifier and frozen adapter are retained.
Per-event extraction/conversion/coherent Q recovery is not installed in the
native production evolution; this gate remains open.

## 21. Trace-gas result

P2 alphaG=1e-20 support passes the actual prototype hook without thresholds
or fabricated gas. The supplied intrinsic carrier fields equal the gas
fixture fields; the trace run has byte-equal native outcomes. There is no
active runtime five-equation carrier-field provider in this round.

## 22. Gas-absent result

Injection into exact absent state rejects on its first support check before
carrier interpolation. A real crossed parcel rejects at first setCellValues.
No bounce/delete/freeze/relocation physics is substituted.

## 23. Normal accepted-event regression

Native evolve runs, source/parcel deterministic initial replay passes.
Separate unmodified-native versus transactional accepted-event golden has
not been completed, so this required gate remains open.

## 24. Oversized-step retry

Initial-state 2e-6 trial generates 42 parcels and is explicitly discarded;
the subsequent 1e-6 trial matches direct initial 1e-6. This is a component
test, not automatic oversized-step admissibility rejection.

## 25. Direct-small-step equivalence

direct_initial_state.txt and retry_initial_state.txt are byte-equal, including
ordered serialized parcel fields/IDs, transfers, coefficients, injected mass
and scalar RNG probe. No final committed cloud/Q/output or evolved-model
private-state comparison exists; full golden gate remains open.

## 26. Injection retry

Nonzero initial injection component PASS. Continued-injection transaction
is PARTIAL; factory is deliberately not presented as a restart adapter.

## 27. Breakup retry

NOT PROVEN.

## 28. Collision retry

NOT PROVEN.

## 29. Support-failure retry

Installed crossing hook rejection PASS component. Crossing-induced rejected
whole-step plus smaller accepted step golden equivalence NOT PROVEN.

## 30. Combined-event retry

Native selected models execute in the fixture. Forced injection+random
dispersion+drag+breakup/collision golden event NOT PROVEN.

## 31. Parcel deletion retry

Prior native local minimum-mass deletion proof retained. Exact deletion
transaction from an evolved owned cloud NOT PROVEN.

## 32. Source/energy frozen regression

9288 checks, zero failures. Eight modes' ledger.csv, golden_energy.csv,
test_results.json and test_failures.txt are byte-identical to M8A baseline.
frozen_regression_comparison.json provides per-file evidence.

## 33. Conservation ledger

Frozen mass/species/momentum/Et/JANAF/mixed/trace/deletion results unchanged.
New trial transfers are not yet combined with trial Eulerian Q; do not claim
a new whole-production coupled conservation proof.

## 34. No-alpha-source confirmation

No DPM alpha source added. P2, R1, fiveEq thermo and frozen source equations
unchanged. Allaire K=0 design retained; active alpha equation unchanged.

## 35. MPI transaction design

See docs/M8A2_MPI_TRANSACTION_PROTOCOL.md: full parcel identity transfer,
trial sender/receiver sources/Q, synchronized cancellation/draining, all-rank
AND accept or discard, exact rank-local counter restore, deferred output.
Current serial exception hooks must not escape MPI collective loops.

## 36. 2-rank MPI result

Open MPI 4.1.2 available. Actual allocator/all-rank protocol test: 2002 checks,
zero failures. No real processor parcel crossing or distributed source/
retry golden test completed. MPI blocker is implementation/test coverage,
NOT an unavailable environment. PRE-M6B MPI HARD BLOCKER remains.

## 37. Project-local OF7 overrides

Original files/functions/SHAs in override_manifest.json; method diff in
project_local_overrides.diff. Includes CloudIO readUniform, InjectionModel
inject, KinematicParcel setCellValues (two call forms), KinematicCloud
postEvolve, CloudFunctionObject postEvolve, VoidFraction write. Installed
OF7 files unchanged. Specializations link only into the isolated test exe.
Symbols must be checked individually: the first noWrite experiment proved
that an inlined base call alone does not reliably intercept VoidFraction.

## 38. Performance/memory

1000 actual fresh-cloud construction/destruction cycles tested with stable
warmed registry. /usr/bin/time resource log measures the standalone harness.
Measured wall time 54.00 s, maximum RSS 101744 KiB (about 99.4 MiB), exit 0.
No full allocator/leak instrumentation; stable registry and RSS high-water
are not claimed as proof of every model allocation. Basis probing is far
too expensive/unbounded for the production mesh and explicitly rejects it.

## 39. Active solver impact

NONE. No active declaration/evolve/source/equation/timestep replacement.
No CFD, mesh generation or case validation. Protected hashes in evidence.
Existing 300_2D injection settings remain historical model provenance;
locked future injector inputs are not silently written into that case.

## 40. Remaining blockers

Exact evolved-state owner-rebinding adapters; all hidden RNG refs/cache;
forced breakup/collision/deletion/rebound statistics; scalable native stencil
and real mesh scan; event deposition/Q logical commit; accepted output
release; full direct/retry golden; processor crossing/global transaction;
memory ownership instrumentation. These are required work, not optional.

## 41. M8A.2 COMPLETE?

NO — PARTIAL.

## 42. M8A COMPLETE?

NO — PARTIAL; original source/energy core PASS/FROZEN.

## 43. M6B.0 permission

BLOCKED. Next work must continue the missing M8A.2 gates, not switch runtime.

## 44. M6B.1 permission

NO. No activation or CFD.

## 45. Updated milestone matrix

| Milestone | Status |
|---|---|
| M0–M4 | existing COMPLETE retained |
| M5A/M5B | existing COMPLETE references/design retained |
| M6A family | prior recorded status unchanged |
| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE |
| M8A source/energy | PASS / FROZEN |
| M8A.1 | PARTIAL, concepts retained |
| M8A.2 | PARTIAL, initial-state prototype only |
| M8A overall | PARTIAL |
| M6B.0 | BLOCKED / NOT EXECUTED |
| M6B.1 | NO / NOT EXECUTED |

Stop at this round. Full serial production contract is not closed.
