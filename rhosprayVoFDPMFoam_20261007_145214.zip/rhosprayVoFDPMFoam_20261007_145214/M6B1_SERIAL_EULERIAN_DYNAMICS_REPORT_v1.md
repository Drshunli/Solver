# M6B.1 — SERIAL EULERIAN DYNAMICS

## 1. M6B.1 status

**PARTIAL / STOP — SHOCK_STABILITY_BLOCKER / NUMERICAL_CORE_FIX_REQUIRED.**

2026-10-05 封存；实际串行 Eulerian 动态微算例，不是生产 CFD 认证。15 个算例正常退出；shockInterface_100 因已接受步的时间不再前进而主动 SIGTERM，exit 143。不得以中断现场当作通过。

## 2. Source delta

只增加 fresh exactInitial 初始化、只读 accepted-state 诊断与 R1 最大迭代数计数。现有变化为 serialFiveEq/runSerialFiveEq.C、recoveryObservation.C/H 及两个对应 .o；新增 dynamicObservation.H、离线初始化/快照工具和案例生成/后处理工具。源码逐行差异：fitting/integration/m6b1_serial_dynamics_v1/allowed_adapter_delta.patch。

目的：输入动态初态、记录物理/守恒证据；依据：Q 是唯一演化状态，诊断只读 Q 和冻结 recovery 结果。未新增 PDE、未改 KT/P2/R1/thermo/Allaire/K=0/N−1 物种/advance/retry。active adapter 有上述初始化/诊断变化，不能称 active-source impact NONE；数值核心变化为 NONE。

## 3. Mesh ladder

固定均匀 unit-area、L=1 m、1D cyclic-x / transverse empty，N=100/200/400。gasPlus/gasMinus 三层均完成；其余完成的家庭只有 N100。所有后续 N200/400 与 boost 输入已生成但未执行；N800 未执行。早期 deltaT=1 s 导致短时段 Time.run 不进入循环的 6 次启动尝试保留在 startup_dt_attempt，steps=0，完全排除认证。有效运行初始 dt=.15 Δx/(|U|+c)，driver 原有 jointBound 和时间步继承未改。

## 4. Gas acoustic

± waves：以每个 accepted step 的压力基波复 Fourier 系数，展开相位后线性拟合 speed=−phaseSlope/k；理论值来自冻结初态 acoustic closure。两个方向均正确；N100→200→400 相速误差单调下降，约 2.84478e−4→7.30529e−5→1.79938e−5。

| Case | N | Frozen c/speed (m/s) | Measured | Relative speed error | Amplitude ratio | Steps |
|---|---:|---:|---:|---:|---:|---:|
| gasMinus_100 | 100 | -558.656825 | -558.815751 | 0.000284478 | 1.00282525 | 74 |
| gasMinus_200 | 200 | -558.656825 | -558.697637 | 7.30529e-05 | 1.00154146 | 149 |
| gasMinus_400 | 400 | -558.656825 | -558.666878 | 1.79938e-05 | 1.00079906 | 298 |
| gasPlus_100 | 100 | 558.656825 | 558.815751 | 0.000284478 | 1.00282525 | 74 |
| gasPlus_200 | 200 | 558.656825 | 558.697637 | 7.30528e-05 | 1.00154146 | 149 |
| gasPlus_400 | 400 | 558.656825 | 558.666878 | 1.79938e-05 | 1.00079906 | 298 |
| liquidPlus_100 | 100 | 1244.71811 | 1245.06816 | 0.000281234 | 1.00631425 | 166 |
| mixed01_100 | 100 | 846.923019 | 847.163725 | 0.000284213 | 1.0043056 | 113 |
| mixed05_100 | 100 | 995.217314 | 995.499613 | 0.000283656 | 1.00504936 | 133 |
| mixed09_100 | 100 | 1180.92976 | 1181.26292 | 0.000282112 | 1.0059776 | 157 |
| traceLiquid_100 | 100 | 558.656825 | 558.815751 | 0.000284478 | 1.00282525 | 74 |


## 5. Liquid acoustic

liquidPlus_100 正常完成，方向/相速/合法性有局部证据；完整三层收敛未验证。数值见第 4 节，不以缺失 N200/400 判定物理失败。

## 6. Mixed acoustic

alphaL=.1/.5/.9：三个 N100 正常完成，测得相速与冻结理论值一致至约 2.82–2.84e−4 相对误差；细网格未执行，完整 gate 未闭合。

## 7. Trace dynamics

traceLiquid_100 使用 P2 正 trace 1e−20；正常退出，未改 trace floor、未用 alpha roundoff 替代 P2。零违规、零 recovery failures；细网格未执行。

## 8. Material contact

contact_100：U=47 m/s，alphaL .1/.9，common p=3 MPa、TG=800 K、TL=300 K；41 accepted steps、无重试。接触传播与守恒局部证据保留；未完成三层解析平移误差/界面宽度认证。

## 9. Contact pressure error

最大 |p/p0−1| = 2.1355139878664886e-11。p范围 [2999999.9999465225, 3000000.0000640657] Pa；只限 N100。

## 10. Species contact

speciesContact_100：alphaL=.1、U=47 m/s、common p，YG 从 (0,.228,.772) 到 (.1,.2,.7)。30 steps、无重试；最大压力相对误差约 1.01e−14，物种闭合残差 ≤1.518e−16。依赖 N2 仍为代数残差，不做归一化；细网格未执行。

## 11. Gas shock/Riemann

gasShock_100 的周期双 Riemann 初态 pL=1 MPa/TLgas=600 K、pR=.1 MPa/TRgas=300 K，实际求解正常退出、50 steps、无重试；不将单网格有限运行等同双 Riemann 验证完成。

## 12. RH residual

NOT CERTIFIED。N200/400 被 STOP 阻断，N100 downstream plateau 仅有少量网格且邻近 contact，尚无可靠 plateau/RH 网格收敛结论；未伪造精确 Riemann 解或 RH PASS。后续应比较 S[ρ]=[ρU]、S[ρU]=[ρU²+p]、S[Et]=[(Et+p)U] 的分项归一残差并记录 plateau 与 shock-speed 采样误差。

## 13. Legacy gas reduction

未执行独立 legacy Eulerian 对照，不引用带 DPM 的历史气体结果作为 fresh reduction PASS。

## 14. Two-material Riemann

materialRiemann_100：alphaL=.1/.9、p=3.1/3 MPa、TG=800/600 K、TL=300/302 K，63 steps 正常完成、无重试。只证明本次短窗口运行有限；不同网格波结构与独立参考尚未认证。

## 15. Shock-interface

shockInterface_100：离线 frozen-JANAF Hugoniot 初态估计 S=582.207376790991 m/s、postshock TG=820.107170290211 K、U=39.6250537203701 m/s。shock x=.4、interface x=.65，估计相遇 t≈.25/S=4.2940e−4 s；不是 CFD 结果。

实际停滞 t=1.2745457792667973e−4 s，早于相遇。最后 100 个监测 accepted 时间只有一个值，dt≈5.57117708914e−22 s，time ULP≈2.71050543121e−20 s。主动终止而非 timeout；本 gate FAIL/BLOCKED，interaction 未发生，不能宣称 shock-interface PASS。

## 16. Refinement trends

仅气相双向声波完整相速收敛已证实；其余趋势 OPEN。acoustic_analysis.json 的 full_ladder/speed_converges=false 对 N100-only 家庭表示缺少运行，不是已经测得反收敛。

## 17. High-Mach acoustic

NOT EXECUTED。不得把 U=0 声波或预生成 boost 初态称为 U=2013.039 m/s 验证；未完成最终 gas scenario M≈5.02 的动态认证。

## 18. High-Mach contact

contactBoost_100/200/400 NOT EXECUTED due STOP。

## 19. Galilean comparison

NOT EXECUTED；没有普通/boost 成对动态数据，不作 Galilean PASS。

## 20. Minimum pressure

15 个正常退出运行：p_min=99999.999999999971 Pa。停滞段尾部 p_min≈2.999723 MPa（局部已保存证据，非完整 shock case 认证）。

## 21. Minimum phase density

正常退出集合 active rho_min=1.1559023973141809 kg/m³。只检查存在相；absent-phase 输出 marker 不当作物理密度。停滞尾部约13.00033 kg/m³。

## 22. Temperature ranges

正常退出集合 TG=[299.99999999999994,800.00079698462469] K，TL=[299.99929877005064,302.00111887472229] K。phase inactive 时的诊断数值/marker 不纳入有效热力学状态推论；各 case 明细见 completed_runs.json。被中断 case 不具最终热力学认证。

## 23. P2 invariant

正常退出集合 diagnostics violations=0；acoustics/gas shock/species contact 设置 constantP2 并做 payload 检查；material/contact 以冻结 P2 演化，未改模式、floor 或 clipping。中断 shock 仅有已保存 accepted-state 局部证据。

## 24. Species invariant

正常退出集合 max closure=1.7131692695360097e-16；非负与闭合只读检查零违规。禁止 normalization；Q7/Q8 演化，Q9=mG−(Q7+Q8)。

## 25. mG conservation

正常退出 15 runs 的最大 scaled integral drift：Q1=7.2728136312978958e-16。缩放定义沿用只读诊断（max(abs(initial integral),1)），绝对误差和逐运行数值保存在 dynamic_summary.json/completed_runs.json。无周期边界外部通量；未包括中断 case 最终认证。

## 26. mL conservation

正常退出 15 runs 的最大 scaled integral drift：Q2=6.6421111844404443e-16。缩放定义沿用只读诊断（max(abs(initial integral),1)），绝对误差和逐运行数值保存在 dynamic_summary.json/completed_runs.json。无周期边界外部通量；未包括中断 case 最终认证。

## 27. Momentum conservation

正常退出 15 runs 的最大 scaled integral drift：Q3=1.0338084555083782e-14, Q4=0, Q5=0。缩放定义沿用只读诊断（max(abs(initial integral),1)），绝对误差和逐运行数值保存在 dynamic_summary.json/completed_runs.json。无周期边界外部通量；未包括中断 case 最终认证。

## 28. Et conservation

正常退出 15 runs 的最大 scaled integral drift：Q6=7.3506403065768016e-16。缩放定义沿用只读诊断（max(abs(initial integral),1)），绝对误差和逐运行数值保存在 dynamic_summary.json/completed_runs.json。无周期边界外部通量；未包括中断 case 最终认证。

## 29. Species conservation

正常退出 15 runs 的最大 scaled integral drift：Q7=2.4177708446426749e-17, Q8=1.1618399165223453e-15, Q9=7.1203667202166131e-16。缩放定义沿用只读诊断（max(abs(initial integral),1)），绝对误差和逐运行数值保存在 dynamic_summary.json/completed_runs.json。无周期边界外部通量；未包括中断 case 最终认证。

## 30. R1 calls/iterations/failures

| Case | Steps | R1 calls | Iterations | max iterations | failures | violations |
|---|---:|---:|---:|---:|---:|---:|
| contact_100 | 41 | 295600 | 1338301 | 5 | 0 | 0 |
| gasMinus_100 | 74 | 533200 | 3069096 | 6 | 0 | 0 |
| gasMinus_200 | 149 | 2146400 | 12354543 | 6 | 0 | 0 |
| gasMinus_400 | 298 | 8584000 | 49409421 | 6 | 0 | 0 |
| gasPlus_100 | 74 | 533200 | 3068932 | 6 | 0 | 0 |
| gasPlus_200 | 149 | 2146400 | 12354070 | 6 | 0 | 0 |
| gasPlus_400 | 298 | 8584000 | 49412131 | 6 | 0 | 0 |
| gasShock_100 | 50 | 360400 | 1682598 | 5 | 0 | 0 |
| liquidPlus_100 | 166 | 1195600 | 4782400 | 4 | 0 | 0 |
| materialRiemann_100 | 63 | 454000 | 2056339 | 5 | 0 | 0 |
| mixed01_100 | 113 | 814000 | 4070000 | 5 | 0 | 0 |
| mixed05_100 | 133 | 958000 | 4790000 | 5 | 0 | 0 |
| mixed09_100 | 157 | 1130800 | 4523200 | 4 | 0 | 0 |
| speciesContact_100 | 30 | 216400 | 1082000 | 5 | 0 | 0 |
| traceLiquid_100 | 74 | 533200 | 2666000 | 5 | 0 | 0 |

本轮 wrapper 包含实际 frozen R1 全部调用；不只统计最终 publish。被 SIGTERM 的 shock case 未运行析构汇总，所以其总 R1 failures/iterations/max iterations **UNAVAILABLE**；不能外推为零。

## 31. Retry statistics

15 个正常退出案例均零 rejected trials。中断 shock accepted_steps.csv 有6702个完整行和1个不完整尾行；完整记录累计3227 rejected trials。异常理由未记录，不能区分 trial 或 recovery 异常，不宣称全部是 R1 失败。现场日志/不完整文件原样保留。

## 32. Timestep/CFL

正常退出集合 CFL_max=0.16031614932201302（冻结 .15）。停滞尾部 CFL≈6.93454e−17。只读 snapshot_6750（100行完整）重新计算 frozen rec/face/jointBound：minimum bound=1.2050921353055126e−6 s，limiting cell82/x=.825/acoustic。

因此该保存状态的线性 joint cap 不要求已继承的5.57e−22 s。adapter 原有 setDeltaT(step.dt) 持续保留 accepted dt，但导致 rejection 的根因未闭合；不得把解除继承当作已验证修复。snapshot_6760只有50行，latest可能部分写入，不用于完整状态判断；检查工具不调用 trial/advance。

## 33. Numerical dissipation

气相声波 amplitudeRatio约1.00283/1.00154/1.00080，随细化趋近1；这是轻微增长，不是衰减。N100液相/混合声波约1.0043–1.0063。相速收敛不等于振幅稳定长期认证；未做后验 tuning，也没有 shock dissipation 完整判定。

## 34. DPM disabled proof

actual main -serialFiveEq 分支提前 return，位于 legacy createFields/createClouds 之前；serialFiveEq 未建 cloud、未调用 evolve/SU/Sh/Srho/source ledger。所有有效运行日志 authority 行记录 DPM=0。production 132 文件 SHA 无变化；本轮不是被动 DPM 运行。

## 35. Surface tension disabled proof

serial adapter 未实例化 interfaceProperties、未调用 surfaceTensionForce，actual authority 行 surfaceTension=0；没有 MULES alpha 或 legacy momentum/energy 方程参与。

## 36. Serial-only proof

仅 rhosprayVoFDPMFoam -serialFiveEq，未使用 mpirun/-parallel。adapter 拒绝 parallel、moving/topology mesh，限制固定均匀单位截面周期1D。LD库含 MPI 不等于 MPI运行认证；不存在 global transaction/production restart。

## 37. Executable SHA

实际编译/运行并在停止后复制的 binary SHA-256：`ebb2a5e1f59a3431bea8795098b9a6c190b30b7cdd4dedc57cca9b78cdc05f87`。保存于 fitting/integration/m6b1_serial_dynamics_v1/runtime/rhosprayVoFDPMFoam；ldd 和55个实际链接库SHA一并保存。active solver/initializer/snapshot inspector 三目标 wmake PASS；停止后只编译只读 snapshot inspector，没有继续求解。

## 38. Foundation/project hashes

本机 Foundation7 6717项及native parcel19项 fresh verification PASS。protected_before 31640项中，变化恰为3个允许adapter源码和2个重编译.o；旧M6B0证据、冻结数值库、gas/liquid EOS均无变化。production132项无变化。allowed_adapter_delta.patch、protected_delta.json、local_source_manifest.json、runtime/linked_libraries.json 提供分项溯源；历史冻结包SHA另记封存清单。

## 39. Whether M6B.1 COMPLETE

**NO.** shock time-progress blocker +未完成 mesh/refinement/RH/boost/Galilean gates，必须 PARTIAL。不得以15个正常退出案例替代全gate，也不回退宣称M6B0证书失效。

## 40. Next permitted milestone

本轮 STOP。建议下一轮另行授权 **serial shock non-progress / first-rejection diagnosis gate**：记录第一拒绝异常、candidate合法性、floating-point time progress、时间步继承与重试链；如需改变冻结core，先提供数学理由/范围与新冻结版本/回归计划。本轮未执行该修复。M6B.2前置条件不满足；禁止进入multidimensional/production BC/active DPM/T4-S3/productionrestart/crossflow/atomization。

## 41. T4/M8A/M6B matrix

| Milestone | Status |
|---|---|
| T4-S1 / T4-S2 | COMPLETE / FROZEN，证据未改 |
| T4-S3 | DEFERRED / NOT EXECUTED / NOT CERTIFIED |
| T4 / M8A overall | PARTIAL |
| M6B.0 | COMPLETE / FROZEN（限定串行bootstrap） |
| M6B.1 | PARTIAL / STOP / numerical-core-fix-required |
| M6B.2 | NOT EXECUTED / prerequisite unmet |
| M6B overall | PARTIAL |
| production restart / MPI / active DPM / production CFD | NOT CERTIFIED |

**STOP.**
