# WORK LOG — 2026-10-05 — ADM1

用户本轮改用committed/requested-trial/no-positive-dt/temporal四类判据，禁止继续EOS扩展或修改EOS/R1/P2/KT/species/temporal/retry/Time/metadata。

Exact frozen anchor234 all100 committed PASS；request bits及200rec/100face bits/独立Q1Q2Q3Q6flux构造PASS。原request FAIL、原8.7185434459499146e−7 retry raw/post-dependent-species全100 PASS；connectedDt相同。105/114/153/174原committed/request/retry在current v3全部PASS，历史verdict原样保留。

发现binary64 native接受不单调。初始32scan/52bisection给局部边界，不足以求最大legal envelope；原235已接受retry反而可大于某二分边界。本轮继续枚举候选component平台而非假设PASS前缀：234 ±1e−11窗口3739平台，235/236窗口1800/1361；每平台lo/mid/hi均all100authority。最大legal234=8.7185434459650744e−7/bits3ead412bfaae4719，235=3.4350658998830625e−18，236=2.0610395399297343e−18。峰值邻位与±1e−12/±1e−9全部记录，较小微扰亦可FAIL；保留非单调限制，不宣称所有dt<=max合法。扩大窗口及32外侧controls均确认最大值不变；独立原species residual后最大候选均all100PASS并可推进时间。

Current active exe与既有LR1只读diag exe均不修改，从原fresh initial运行直到step237第一time nonprogress，238historyrows逐字段一致。237requests/240attempts/3mainrejects/3positivelegalretry/0unrecoverable；73probe rejects另计。原actual236->237dt2.3690109654364757e−20=0.437ULP，time不增；冻结236更大legal/post-species候选38.019ULP，能增time。因此Outcome C/TEMPORAL_POLICY_BLOCKER，非true EOS hard/no-positive-dt blocker。主因包含first-connected搜索与舍入口袋的交互；不将no-regrowth独立声称为唯一原因。

保护：109source全不变，115libs全不变，installedexe同SHA，6717Foundation/19nativeparcelPASS，历史证据全不变，原17inputsPASS；PRESENT逐步无丢失，23800cell exactbits，species1.710142157e−16，conservation1.098754595e−15。metadata保持LR1旧字节；新EOS3 operational COMPLETE/FROZEN通过ADM1 gate与追加milestone表示，不回写历史/不做phase研究。

工程记录：历史174诊断run曾在firstreject外停，无dt_history175，首次helper参数解析失败stod；从原UB1 active continuation已保存record补齐原retry，不修改历史。helper初始Make/options单行格式有wmakeLnInclude非fatal消息，保留log，规范为标准多行后最终compile clean、audit二进制SHA相同。所有改动仅新隔离审查/构建工具，不改变共享/active代码。

ADM1 COMPLETE / TRIAL REJECTION SEMANTICS CLOSED / OUTCOME C / STOP。EOS3-NUMERICAL COMPLETE / OPERATIONAL DOMAIN FROZEN（仅本轮observed accepted trajectory gate，不是endTime/production/phase证明）；M6B1/M6B仍PARTIAL。NEXT M6B1-TD1下一轮独立授权；本轮未执行TD1/IDP/CFD。详见37项报告、ADM1_complete_gate.json、REJECTION_LEDGER与封存。
