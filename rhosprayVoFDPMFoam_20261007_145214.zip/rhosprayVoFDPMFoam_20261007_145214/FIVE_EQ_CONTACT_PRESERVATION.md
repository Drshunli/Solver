# M5C.1 Allaire alpha, contact equilibrium and ALE contract

## Frozen continuous model

K=0, common p and U, separate TG/TL, no chemistry/parcel/capillary source in this
standalone transport assessment. Fixed-grid equations:

```
dt(mk) + div(mk U) = 0, k=G,L
dt(M)  + div(M tensor U + p I) = 0
dt(Et) + div((Et+p)U) = 0
dt(alpha) + div(alpha U) = alpha div(U)
dt(mG Yi) + div(mG Yi U) = 0
rhoMix=mG+mL; M=rhoMix U; Et=mG eG+mL eL+rhoMix |U|2/2
```

Reynolds transport theorem gives moving-volume fluxes:
`mk(U-Umesh)·S`, `M(U-Umesh)·S+pS`,
`Et(U-Umesh)·S+pU·S`, and `alpha(U-Umesh)·S`.
The alpha volume source is the physical `alpha div U`, not relative divergence.

## Face authority and coefficient family

Face-side authoritative input is alpha,mG,mL,M,Et and gas intrinsic Yi (or the
equivalent mYi/mG supplied by the caller). p/rhoG/rhoL/TG/TL/cMix are recovered
by `recoverFaceState`, independently on each side. No EOS is reimplemented in
the KT layer. Use the exact legacy coefficients documented in
`LEGACY_KT_DISCRETE_AUDIT.md`.

```
Falpha=Aplus*alphaPlus+Aminus*alphaMinus
phiRelStar=Aplus+Aminus
phiPhysStar=phiRelStar+meshPhi
divUStar_i=sum_outward(phiPhysStar)/V_i
alphaHat_i=alpha_i^n
```

Old-time cell alpha is frozen for the source of the explicit Euler assessment.
No predictor alpha, cAlpha, independent sharpening, K source or MULES invocation.
This is a first-order FV assessment, not a selected higher-order integrator.

## Discrete ALE step and constant-state preservation

For a 1D cell, both faces globally oriented left-to-right:

```
Vnew=V+dt*(meshPhiR-meshPhiL)
Vnew*alphaNew=V*alphaOld-dt*(FalphaR-FalphaL)
                +dt*alphaOld*(phiPhysR-phiPhysL)
```

Implementation cancels the GCL term analytically before floating-point arithmetic:

```
alphaNew=alphaOld+dt/Vnew *
   [-(FalphaR-FalphaL)+alphaOld*(phiRelR-phiRelL)]
```

The relative divergence appearing in this last **increment** is not a relative
source: it results from cancelling old alpha times the moving-volume increment
from the physical source. `sourceIntegral` remains the physical expression.
For a constant exact 0 or 1 plateau, Falpha is exactly 0 or phiRel; the increment
is exactly zero. There is no conditional snap/clamp or change of mass/energy.

Initial ungrouped implementation produced alpha=1-1.11e-16 with mG=0 in two
pure-liquid plateau cells; strict recovery correctly refused them. That failure
and the original thresholds are retained under `fitting/flux/m5c1_v1/initial_*`.
The algebraic regrouping fixes it without weakening recovery/presence policy.

## Contact compatibility proof

For constant intrinsic rhoL,rhoG,eL,eG,p0,U0 and a closed cell geometry:

```
mL=rhoL*alpha; mG=rhoG*(1-alpha)
FmL=rhoL*Falpha
FmG=rhoG*(phiRelStar-Falpha)
FM=U0*(FmG+FmL)+p0*S
FE=eG*FmG+eL*FmL+|U0|2/2*(FmG+FmL)+p0*phiPhysStar
```

Uniform physical U0 implies `sum_outward phiPhysStar=U0·sum_outward S=0`;
the alpha source and net pressure work therefore vanish. Updating the common
moving cell volume preserves mLNew=rhoL*alphaNew and
mGNew=rhoG*(1-alphaNew). The momentum/energy identities preserve U0 and the
same intrinsic thermal states, so recovery yields p0. KT contact diffusion is
allowed; its affine mixture redistribution creates no physical pressure error.
This proof is specific to constant intrinsic states and divergence-free contact
velocity. It does not assert constant intrinsic density for compressive flows.

In tests, rhoL and rhoG are independently queried at p0=3 MPa, TL=300 K and
TG=800 K. Stationary contacts have the complete vector U=0. Moving contacts use
U=(47,0,0) and (2013.039,0,0). 3/8/20 periodic cells, both KT schemes, stationary
and moving mesh, one explicit step, no clipping. Pressure tolerance fixed BEFORE
execution: max|p-p0|/p0<=1e-8. Affine truncation error is zero; allowance covers
roundoff and the existing 1e-4 Pa+2e-11 relative pressure / 2e-12 energy root stop.

## First-order alpha boundedness: explicit joint timestep condition

With first-order cell faces, A>=0 and B=Aminus<=0, alpha numerator is:

```
dt*A_left*alpha_leftNeighbor
+ [V+dt*(-A_left+B_right+meshPhiR-meshPhiL)]*alpha_cell
- dt*B_right*alpha_rightNeighbor
```

These weights sum to Vnew. Thus 0<=alphaNew<=1 if every weight is nonnegative
and Vnew>0. Sufficient alpha timestep bound is:

```
dt <= V/(A_left-B_right-(meshPhiR-meshPhiL))   if denominator>0
```

Independently, nonnegative phase-mass weights require:
`dt <= V/(A_right-B_left)` if denominator>0. Also enforce Vnew>0. The harness
uses 0.15 times the joint alpha/mass bound and a moving-volume bound. This is
not a guarantee of EOS-domain preservation or high-order boundedness.

Strong velocity-gradient tests are bounded at that joint dt. A separate valid
face stencil with converging 5000/-5000 m/s neighbors deliberately uses
1.1 times the alpha bound while staying within the mass bound: raw alpha=-0.1.
This counterexample PASS means the overshoot was detected, not accepted for use.
No CFD velocity scenario or feasible injector speed is inferred from this stencil.

## MULES conclusion and coupled limiter OPEN ISSUE

Actual Foundation 7 `src/finiteVolume/fvMatrices/solvers/MULES/MULESTemplates.C`
was inspected: scalar `explicitSolve` and `limit` manipulate psi/phiPsi and
Sp/Su, including moving volumes. They do not by themselves update the other
five-equation conserved fluxes or enforce their EOS consistency.

A. Scalar limiter machinery could be investigated as a component, but direct
plug-in acceptance is NOT established for this Allaire alpha and coupled state.

B. Alpha-only limiting generally destroys `FmL=rhoL Falpha` and
`FmG=rhoG(phiRel-Falpha)` at a material contact. The offline counterfactual halves
one alpha diffusion flux only; mL remains 10.041716 kg/m3 while rhoL*alpha halves
from 10.041716 to 5.020858. Real recovery refuses the resulting liquid state.

C. A compatible limiter must coordinate phase masses, gas species, momentum
and energy as needed, retaining contact balance, positivity and EOS-validity.
No general coupled limiter is implemented or approved here. **COUPLED LIMITER
= OPEN ISSUE / M5C.2 blocker.** The first-order joint bound is proved and tested;
it is not authorization to activate high-order equations.

## ALE, conservation and reconstruction limits

Moving-mesh uniform-state tests use prescribed periodic face motion and exactly
the same meshPhi in flux and Vnew. Separate mG,mL,M,Et,alpha errors are recorded.
Uniform-state energy has physical pressure work; a wrong relative-work oracle
is explicitly rejected. Fixed-mesh and common U/mesh-speed shift tests verify
coefficient semantics only; no full Galilean invariance or CFD claim is made.

Shared face fluxes telescope mG,mL,M,Et,mYi over the periodic domain. Alpha is
nonconservative: track its integral change minus its physical source integral.
rhoMix, alphaG and intrinsic densities are derived, not independently advanced.

Conservative reconstruction of alpha,mG,mL,M,Et,mYi aligns with flux authority,
but independent slopes may create EOS-invalid faces or lose contact equilibrium.
Hybrid material/primitive reconstruction could preserve p/U at contacts, but must
regenerate conservative faces consistently and justify pure-gas compatibility.
Neither has passed a cell-to-face test; **future input ownership is frozen,
the reconstruction algorithm is unresolved / M5C.2 required**. Caller retries a
new lower-order conservative state after LEFT_INVALID/RIGHT_INVALID/BOTH_INVALID;
the flux/recovery kernels never edit the rejected state.
