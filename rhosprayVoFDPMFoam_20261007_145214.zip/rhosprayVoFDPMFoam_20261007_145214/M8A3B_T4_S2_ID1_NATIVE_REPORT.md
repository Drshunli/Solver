# M8A.3B-T4-S2-ID1-NATIVE report

2026-10-04. Evidence: fitting/dpm/m8a3b_t4_s2_id1_native_v1. STOP condition observed.

## 1. ID1 status

**PARTIAL / KH_SIGFPE_BLOCKER.** The first-step identity collision is resolved in the exact fixture; the full ID1 closure is not achieved.

## 2. OF7 v7 identity audit

See OF7_NEWBORN_IDENTITY_AUDIT_v1.md: local Foundation ordinary construction, copy, stream, native allocator and actual KH site audited. Full pair (origProc,origId) remains the sole identity.

## 3. Current blocker mechanism

Old destination KH children inherited parent origProc=0 while using rank1-local IDs, creating duplicate pairs. The new first step eliminates that collision. An independent surviving native arithmetic failure now blocks continuation; causality of the old failure remains unproven.

## 4. Minimal local change

Added dpmFiveEq/KHNewbornIdentityV1.H; shared C2 LazySprayParcel.C adds one include and replaces one identity assignment at the existing guarded physical child site. No new full breakup implementation. Two isolated test targets reuse selected frozen model code. MPI harness adds stable-boundary duplicate fail-fast only.

## 5. Why OF7 transport remains unchanged

Cloud::move/processor buffers/native stream/iNew/tracking/prepare/correct are untouched. S1 support, N1 latch/quarantine/reduce, C2 stream and transactionState-v1 are unchanged.

## 6. Newborn identity rule

Only actual KH newborn: origProc=Pstream::myProcNo(); origId=child.getNewParticleID(). Native local allocator advances exactly once at the prior allocation site; no MPI allocator or counter synchronization.

## 7. Existing parcel identity rule

Migration, copies/clones, stream decode, snapshots and rollback retain both identity components. No receive-time reassignment.

## 8. Injection identity

Ordinary native position constructor already assigns birth-rank/native-local identity. Injection source unchanged; fresh frozen I1 run12083 checks/0 failures.

## 9. KH child identity

First MPI boundary rank1 owns parent(0,0), source child(0,1), and destination newborns(1,0),(1,1),(1,2),(1,3). Source/destination native IDs can overlap numerically without pair collision.

## 10. Single-rank control

Frozen baseline versus new compiled target:22 full accepted-state files byte identical (11 direct+11 retry).108 checks/0 failures;92 birth checks; all physical d/nParticle/U/T/history/source/RNG/allocator encodings unchanged; constructed=destroyed=11562,live0. See serial_equivalence.json.

## 11. Migrated-parent case

Exact replay first step PASS for identity rule; parent(0,0) migrates rank0→rank1 unchanged. Subsequent physical continuation blocked by SIGFPE, not certified complete.

## 12. Sibling uniqueness

Multiple naturally produced destination newborns are unique in first-step population. CSV alone does not establish all parentage/lineage, so full sibling gate is not closed.

## 13. Multi-generation birth

Not certified. No artificial copies were counted as descendants. Further evolution prohibited after STOP.

## 14. Both-rank births

Actual source child(0,1) and four destination birth identities observed; simultaneous same-local-ID accepted-birth stress gate not completed.

## 15. Child re-migration

Source-born child transfers0→1 with identity preserved. Required rank1-born child later1→0 not tested after STOP.

## 16. Allocator accepted behavior

Native allocator body unchanged; serial full-state equality PASS. MPI first-step local IDs0–3 observed on rank1. No clean accepted distributed commit certificate for fatal replay.

## 17. Allocator reject restore

Serial K1 contract exercised and full state unchanged. MPI newborn-then-reject allocator rollback not certified; SIGFPE was not caught as transaction rejection.

## 18. Direct/retry identity

Serial direct/retry test PASS and before/after22 states equal. Distributed newborn direct/retry remains untested.

## 19. K1 support revalidation

Child identity assignment precedes existing independent child preflight; parent/child authority invalidation order preserved. New serial target92 negative identity checks and5694 later child queries PASS. Real spatial invalid support at birth remains unclosed; historical test-only refusal is not physical proof.

## 20. Native stream identity

Two real0→1 native events: sender/receiver pair, raw native stream scalars/flags/particle history, physical history, position/barycentric correction and same-rank prepare/correct RNG all PASS. Existing oracle only, no new serializer.

## 21. Duplicate-pair audit

First stable boundary6 parcels/6 unique pairs. Test-only global diagnostic has fail-fast/break on any duplicate before next evolve; no production authority. Duplicate branch not dynamically triggered by repaired fixture, so clean rejection branch execution is not claimed.

## 22. Old blocker replay

69 input files byte identical to kh_boundary_k1; same d=.0003,dt=.00001,steps4,startX3.9999,KHfixture/native births options. First completed step unique; second evolve fatal. See exact_replay_input_hashes.json and log.kh_exact_replay.

## 23. SIGFPE outcome

**Persists with unique identities; exit136, rank1, native ReitzKHRT::update. KH_SIGFPE_BLOCKER, STOP.** Exact arithmetic expression/state not localized. No parameter tuning, clamping, signal recovery or KH/ORourke redesign. Old duplicate→SIGFPE causality not proven.

## 24. >=100 birth stress

NOT COMPLETED. Serial92 birth checks are below100 and do not meet MPI accepted-birth scope. Fatal MPI trial births are not certified accepted births. No100/1000 claim.

## 25. Migration/birth stress

NOT COMPLETED; only2 native transfer events in exact replay. Prior38 crossings remain historical valid evidence, not newborn stress certification.

## 26. Serial regressions

Fresh frozen executable runs: R2B252194/I112083/C217 checks all0 failures. Recompiled changed-site serial K1:108/0 plus byte equality. Frozen binaries test retained historical behavior and do not by themselves certify the newly edited shared source; changed-source evidence is the separately built K1 target and its C2 state encoding. No standalone C2 rebuild after STOP.

## 27. S1/N1 regressions

Fresh frozen S1 topology3364 total/support20051 total/audit12 parallel checks zero failures; serial support/phase controls PASS. N1 valid, forward-invalid, reverse-invalid both ranks globalFailures0. Exact replay boundary semantic2 events PASS. These tests ran before STOP and retain their original isolated scopes.

## 28. Foundation hashes

Fresh6717 installed-source and19 native-parcel SHA checks allPASS. No Foundation modifications.

## 29. Project hashes

2753 protected entries inspected before closing:2752 unchanged; exactly one authorized shared C2 source delta, old SHA07e721b42a5c5e1cace076018f38eabd914b565a7a075ce9676b892408588147 →487efe1c7b329dad9bcb24a80f6b37d20e88f5ded085b7ba74ad4e08ce1ea94f. Milestone receives append-only closing entry. Prior source saved byte exact; old checkpoints untouched. See protected_preclosing_audit.json and closing manifest.

## 30. Active solver impact

**NONE.** Protected active equations/solver/thermo/flux sources unchanged. New adapter belongs only to isolated selected parcel tests; no active integration.

## 31. Production mesh/BC impact

**NONE.** All new cases are isolated fixture copies. No production geometry, field or boundary modification.

## 32. Whether ID1 COMPLETE

NO. Required accepted births, child remigration, distributed allocator rollback/direct-retry, stress and physical continuation gates incomplete.

## 33. Whether R1-NATIVE may resume NEXT ROUND ONLY

NO automatic resume. First prerequisite is a separately authorized native ReitzKHRT arithmetic/state diagnosis of this unchanged failing fixture. ID1 completion must precede remaining R1 gates. No such next stage executed here.

## 34. T4-S2 status

PARTIAL; N1 frozen COMPLETE scoped evidence remains valid. ID1 PARTIAL; R1 remaining gates unclosed.

## 35. T4/M8A status

PARTIAL / PARTIAL. Production restart NOT CERTIFIED.

## 36. M6B/CFD permissions

M6B NO; CFD NO; S3 NOT AUTHORIZED; global MPI transaction and active integration not executed.

## 37. Updated milestone matrix

| Milestone | Status |
|---|---|
| R2-FINAL/T3 | COMPLETE / FROZEN |
| T4-S1 | COMPLETE / FROZEN |
| T4-S2-C1-N1 | COMPLETE / FROZEN, isolated scope |
| T4-S2-R1-NATIVE | PARTIAL, remaining gates blocked |
| T4-S2-ID1-NATIVE | PARTIAL / KH_SIGFPE_BLOCKER |
| T4-S2 | PARTIAL |
| T4-S3 | NOT AUTHORIZED |
| T4 / M8A | PARTIAL / PARTIAL |
| M6B / CFD | NO / NO |
| Production restart | NOT CERTIFIED |

Both isolated targets wmake PASS. STOP after unique-identity SIGFPE; no further physical tests or tuning.
