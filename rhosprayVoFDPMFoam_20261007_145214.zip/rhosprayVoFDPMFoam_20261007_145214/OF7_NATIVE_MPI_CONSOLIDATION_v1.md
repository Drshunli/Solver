# OF7 native MPI consolidation v1

Scope: isolated T4-S2-C1-N1. Foundation, frozen S1/C2/I1/R2 and active solver remain unchanged. The attached `file_classification.json` lists each audited project test source. Historical sources/records are not deleted or rebuilt.

## Dependency decisions BEFORE cleanup

| Files | Classification | Old purpose | Replacement / dependency result |
|---|---|---|---|
| tests/fiveEqDPMNativeMPIN1/parcel/LazySprayParcel.H | KEEP | C1 outer rejection hook | Thin outer move hook; all base code resolved from frozen C2. Native transfer methods will be directly inherited; phase hooks delegate only. No stream fields. |
| tests/fiveEqDPMMigrationS2C1/parcel, except LazySprayParcel.H | HISTORICAL_EVIDENCE_ONLY | Earlier experimental duplicate family | No copies in the N1 build; original frozen C2 remains sole base implementation. All old files retained as interrupted-attempt evidence. |
| tests/fiveEqDPMNativeMPIN1/localTypes.H, localRegistration.C, localTypeSymbols.C | KEEP | Instantiate same C2 family with local outer move hook | Needed for coherent template instantiation and native model selection tables. No transport implementation. |
| tests/fiveEqDPMNativeMPIN1/MPIFailureLatch.H, S1CarrierBridge.H | KEEP | Trial rejection and binding | Necessary fiveEq layer; no parcel send/recv and no query collective. |
| tests/fiveEqDPMMigrationS2/testNativeCrossing.C | HISTORICAL_EVIDENCE_ONLY | Old outside-evolve rank-local return | Absent from N1 Make/files. Preserved solely as immutable timeout reproduction; never a supported rejection path. |
| fitting/dpm/m8a3b_t4_s2_v1 and m8a3b_t4_s2_c1_v1 | HISTORICAL_EVIDENCE_ONLY | Logs/checkpoints/interrupted attempt | Retain unchanged. Timeout exit is old blocker evidence, never accepted trial rejection. |
| tests/fiveEqDPMDistributedSupportS1/*.H | KEEP_AND_FREEZE | Contributor topology/state exchange | Exchange only in construction/prepare/publish; preflight/materialize are local. Not parcel transport. |
| tests/fiveEqDPMParcelC2, InjectionI1, KHSupportK1 and frozen lazy R2 | KEEP_AND_FREEZE | Carrier, ownership, state, model adapters | Necessary contracts, not redundant MPI transport. |
| active Make/files/options, dpmFiveEq, fiveEqPrecision, fiveEqThermo | KEEP_AND_FREEZE | Active and conservative physical model | No N1 target or latch linked into active solver. |

No independent production parcel transport queue, MPI migration codec, query-time collective, migrated carrier token, duplicate owner authority or gas fallback was found in the selected dependency graph. `addParticle` in N1 only initializes a fixture seed; actual migration uses native transfer. S1 owner rank IDs identify contributor data, not parcel ownership. Lifetime maps are diagnostic only. No fake fallback deletion is warranted.

## Cleanup operations

N1 never copies the 18 unchanged companion parcel sources from the interrupted C1 target. Delete only the new redundant N1 transfer hook overrides after this manifest: `prepareForParallelTransfer` and `correctAfterParallelTransfer` delegate to unchanged Foundation and exist solely for earlier phase tracing. They are replaced by inherited native methods. Receive phase is observed on first destination move, after native correction. No packet or codec modification. No frozen/history files deleted.

## Transaction binding

Reuse frozen C2 stateCodec/state/model adapters and frozen R2 transaction discard body. The test owner view binding is changed to the existing `StableCommittedCarrierView` for immutable snapshot comparison only. N1 does not invoke the serial query/evolve, prepare/publish/flush methods. S1 is the sole MPI query authority. Existing transaction state format and discard implementation remain unchanged; no global MPI commit certification.
