# Five-equation liquid exit-plane inlet: boundary requirements

## Scope and user-selected control (30 September 2026)

Design/audit only. The user selected **mass flow 1.09609e-4 kg/s and TL=300 K control, with pressure responding to domain waves**. The user also restricted this envelope task to adiabatic mechanical processes. No boundary class, active equation or case dictionary is changed.

The reference physical state remains C10H22, p=3 MPa absolute, TL=300 K, one 0.3 mm circular hole, no internal nozzle. CoolProp 8.0.0 HEOS gives rho=727.432961 kg/m3, c=1244.718107 m/s and reference U=2.1316743 m/s. That speed is DERIVED at the reference pressure; it is **not an additional prescribed velocity**. At a responding boundary pressure pb, require rho_b=rho_refEOS(pb,300 K) and U_n,in=mdot/(rho_b A), with future positive-inward convention and actual patch area defined explicitly.

## Characteristic count and compatible specification

For the pure-liquid limit of compressible Euler, in an outward-normal coordinate, the acoustic characteristic speeds are u_n-cL and u_n+cL. For subsonic inflow -cL<u_n<0, one acoustic characteristic leaves the domain; it supplies the pressure/wave compatibility information. Entropy and transverse-velocity characteristics enter. In the five-equation extension, injected material composition/volume fraction is also incoming advected information. Its exact degeneracy treatment and mixture sound speed must be audited against the accepted five-equation closure before runtime implementation.

For the 1D pure-liquid Euler core, two independent incoming conditions can be specified; independently fixing mdot, T and p would prescribe three. In 3D, also specify the inlet direction/transverse-velocity policy and material identity. The accepted design is:

1. Prescribe liquid mass flow, TL=300 K, liquid material identity and inward direction at the injection patch; no gas inflow and no parcel-volume double counting.
2. Obtain the outgoing acoustic information from the interior reconstructed liquid state.
3. Solve a **future boundary-only** compatibility problem for pb, rho_b and U_n while preserving mdot, TL and liquid EOS validity. This is an interface requirement, not an implemented pressure recovery solver.
4. Form mL, mG, momentum, total energy and all KT boundary fluxes from that single boundary state. Use the declared liquid energy offset consistently. Do not overwrite pressure independently afterward.

No fixed-p=3 MPa Dirichlet boundary is added. 3 MPa is the reference state for initialization and property/inlet diagnostics. A maintained 3 MPa liquid reservoir boundary would be a different control choice and cannot simultaneously guarantee the selected mass flow. Backflow, vanishing liquid fraction, sonic transitions and pressure falling outside the accepted EOS domain require explicit future branches; they must not silently preserve subsonic inflow data during outflow. Future boundary pressure should not be clipped to freestream or reference pressure.

## Common pressure and the initial mismatch

The liquid reference pressure exceeds the supplied freestream by 2.811669693 MPa (3 MPa versus 0.188330307 MPa). A common mechanical pressure means one pressure **per local mixed state**, not one global pressure. Pure-liquid boundary cells and pure-gas exterior cells may initially differ; the interface Riemann dynamics send acoustic waves, drive acceleration/compression/expansion and evolve the local common pressure. One mixed cell cannot hold simultaneously independent pL=3 MPa and pG=0.188 MPa. The selected characteristic control allows boundary pressure to respond rather than artificially enforcing pressure equilibrium or a persistent independent liquid pressure.

An illustrative reversible liquid release from the reference state to ambient, converting the enthalpy drop into speed, gives approximately 88.004 m/s, compared with the reference 2.132 m/s. This is an analytic energy scale, not the selected boundary velocity or a solved nozzle. It shows why the reference dynamic head (1.653 kPa) is not a global bound on later jet velocity/decompression. The low reference convective momentum ratio does not include the large pressure traction/work.

## Circular area versus existing 2D case

Physical circular-hole area is 7.06858347e-8 m2. The existing `300_2D` slice is 50 micrometres deep; a 0.3 mm-wide planar exit would have area 1.5e-8 m2, not the circular area. Applying the full circular-hole mass flow to that slit would change the mean speed. Maintaining the same flux density instead would scale the represented slice mass flow by A_slice/A_circle; this is a **possible dimensional-reduction mapping**, not an approved case change. The old DPM equivalent-area diameter is not a VOF liquid inlet patch.

Current mesh files still have `bottomWall`, not a resolved circular liquid inlet. Future patch geometry, physical-versus-slice mass-flow units, direction and 2D mapping must be settled when a case is designed. No area or flux scaling is applied in this stage.

## Runtime acceptance gate reserved for later stages

The eventual boundary must recover pure-liquid and absent-gas limits without divisions by zero, preserve mass flux and energy-reference accounting, obey characteristic count, and use consistent material/alpha and conservative KT fluxes. Gas-pressure response and interface dynamics must not be replaced by a fixed nominal rho. None of those runtime capabilities is asserted or implemented here.
