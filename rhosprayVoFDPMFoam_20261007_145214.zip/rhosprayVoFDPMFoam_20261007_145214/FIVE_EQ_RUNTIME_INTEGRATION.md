# Passive OpenFOAM integration — M6A2.2

BUILD INTEGRATION only. PHYSICS ACTIVATION absent. No bridge object/query in
main solver or cell loop. No current legacy-field shadow mixed state.

Build order: liquidEOS/library wmake libso -> fiveEqThermo wmake libso ->
standalone bridge tests wmake -> solver wmake. New libs are
libRhosprayLiquidEOS.so and libRhosprayFiveEqThermo.so in FOAM_USER_LIBBIN.
Only user code/build outputs modified; no FOAM_SRC edits. Frozen ndecane_gibbs_v1
files unchanged. Real out-of-line factory constructs the frozen EOS; actual
state-recovery symbols link through the kernel library. No fake/stub recovery.

Solver Make/files compiles fiveEqSpeciesMap.C and fiveEqRuntimeBridge.C.
Make/options adds include paths, user library path and the two libraries.
Existing physics sources and main loop are byte-identical.

Bridge owns immutable phase evaluators, species mapping and kernel. It holds
no fvMesh, vol fields or mutable composition. Input uses dimensionedScalar
alphaL,mG,mL,Et; dimensionedVector M; scalarField YG. Dimensions are checked
against the field-ownership table before scalar extraction. Output contains
kernel state and converted Foam::vector U. Error diagnostics are enum/numeric.

tryRecover is the default entry. recoverCellState and recoverFaceState differ
only in context; both use identical EOS mathematics and phase routing.
Optional PressureGuess uses supplied bool+scalar; absent/NaN/outside-bracket
values use deterministic midpoint fallback. The guess never becomes/clamps a
physical state. No history is needed. recoverOrFail throws, leaves final fatal
policy with caller. Formatting/counter aggregation are opt-in.

Future face caller supplies reconstructed alpha,mG,mL,M,Et,YG plus/minus;
recovery supplies local p,U,cMix. No thermo-side interpolation/reconstruction.
The conservative lower-order fallback contract is documented separately.

Future liquid inlet: prescribed mass flux and TL, pressure responds acoustically;
caller must first build consistent boundary Q. No BC implementation in this
stage. Pure-liquid gas Y may be empty. Future pure-gas atomic-switch regression
must compare p,TG,rhoG,cG to legacy gas thermo for equivalent rho/rhoE/Y.
Only algebraic synthetic tests ran now, not CFD or atomic transport regression.

Current M2 MULES/cAlpha alpha remains provisional and unchanged, not promoted
to final Allaire transport. Its eventual compatible flux/nonconservative
switch (cAlpha OFF, K=0) must pass M5C.1 design before atomic activation.
M5C.1 is NOT EXECUTED here. The next gate must freeze reconstructed Q, face
recovery order, cMix waves, material/momentum/energy/ALE fluxes, Allaire alpha,
contact-equilibrium and positivity/fallback. No transport activation authorized.

Kernel adapter uses shared factory; default-air removal requires explicit test
composition. Optional progress snapshot reports failed bracket/iterations
without changing root mathematics. M6A2.1 2087-check regression rerun passes.
Library/bridge tests use Werror. Solver retains existing warning settings.
See fitting/recovery/m6a2_2_v1 for dependencies, symbols, Make diff and hashes.
