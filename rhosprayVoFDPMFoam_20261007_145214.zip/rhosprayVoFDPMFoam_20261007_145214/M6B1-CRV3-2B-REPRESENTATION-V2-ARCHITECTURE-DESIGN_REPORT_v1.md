# M6B1-CRV3-2B REPRESENTATION-V2 ARCHITECTURE DESIGN REPORT v1

DESIGN ONLY / COMPLETE / ACTIVE IMPLEMENTATION UNCHANGED

## 1. CRV3-2B status

COMPLETE / REPRESENTATION-V2 DESIGN FROZEN。仅设计与独立oracle，不是active implementation或runtime qualification。

## 2. range-closure forecast

step208/cell311与step300/cell300从冻结源码副本导出精确face/source方向；4组affine frozen-direction shadows延伸至endTime=.00055并含1/100尺度压力测试。8组fresh liquid/gas frozen-KT outflow tails附边界守恒账本，至endTime最多额外约749.67个十进制数量级。K、K divU、phase energy、mMinor与gas species均覆盖。此为范围forecast/counterexample，不是完整耦合PDE轨迹，也未证明所有qualified trajectory均避开mass floor；因此按用户规则必须选择C，不能声称已完成实际trajectory rerun。

## 3. fraction floor

binary64最小正数2^-1074；新authority为ScaledDD+int64 exponent，支持远低于该值。检查1e-325/350/500/1000、2^-3322与2^-10000；double view可为0但presence不得改变。

## 4. mass floor

liquid rho≈727.433的nearest-rounding zero边界为alpha≈3.39595311622166459359374993609960002135068031287088673496126055260604553100930600180005706E-327；step300方向缩小100x即可触及该mass floor。fraction-only不能关闭下一限制。边界是半DBL_TRUE_MIN阈值的算术预报，不是删相政策。

## 5. species floor

gas mass边界alpha≈1.89968229147390596975509743139726713219186014268983712972351000214296582699237409773168117E-325；O2 independent mass边界≈8.33193987488555219869645795442285009165887600918403904956315318934525095400324464179560784E-325，dependent N2≈2.46072835683148444296836955538160491137150395241977605566198465692090100211342929047263287E-325。gas trace必须连同N−1 independent masses及dependent residual扩展；exact-zero species保持零。

## 6. schema A

fraction-only ScaledDD：FRACTION_ONLY_REJECTED。无法证明全部当前serial horizon内mass/species均不触底；已有100x counterexample。

## 7. schema B

paired fraction+mass能覆盖liquid，但gas independent species留下已知指数墙；单独B对全scope不充分。

## 8. schema C

paired fraction+phase conservative masses+gas N−1 trace bundle；统一authority API；selected minimum完整架构。dominant normal fields保留fast path，trace保守通量/ledger均扩展。

## 9. selected architecture

P2-SCALED-v2 + TRACE-CONSERVATIVE-v2 + gas trace species bundle。没有ghost phase，没有recovery-only shadow，也没有两套physical code。

## 10. authority semantics

每个physical fraction/mass/species恰好一个authoritative slot；double是variant payload或明确VIEW。phase presence由Side enum判定，绝不由toDoubleView或epsilon判定。

## 11. P2-v2 layout

Side=PURE_GAS/PURE_LIQUID/LIQUID_MINORITY/GAS_MINORITY，加minority ScaledDD q。mixed 0<q≤.5；dominant是ComplementExpr(q)，不是竞争authority。

## 12. ScaledDD layout

(hi+lo)*2^exp2；IEEE binary64 normalized hi/nonoverlapping lo，signed int64 exponent，24-byte big-endian wire。canonical zero hi=lo=+0, exp=0。int64 range显式checked，不能称无限指数。

## 13. exact-zero semantics

+0 legacy→PURE_GAS，-0→PURE_LIQUID；pure q exact0，mixed任意小positive q为PRESENT。subrange double zero view不是ABSENT。

## 14. minority-switch semantics

before-rounding比较q；负值/out-of-[0,1]拒绝，exact0/1转换pure需mass/species一致，q>.5才切侧并用complement；q=.5保留原side以exact迁移合法±.5。16个oracle切换/拒绝例通过。

## 15. arithmetic API

normalize/compare/add/subtract/multiply/divide/ratio/oneMinus/sign/exactZero/fromDouble/toDouble/ulp audit。54个exact-dyadic arithmetic检查；temporary sparse exponent accumulator避免大项先舍入再抵消。oneMinus返回保留q的ComplementExpr，dependent species返回ResidualExpr。portable wire3例通过；均为design oracle，非C++ runtime certification。

## 16. alpha transport design

strategy0 scaled alpha face products及fraction differences、transport increment均不decode-to-zero；原KT wave directions与totalFractionNumerator形式保持。recovered-state和path-guard消费者必须读authority；既有p/T/composition path的scaled节点仍执行所有present相EOS检查。

## 17. K/source design

冻结K=a*b*(AG−AL)/(b*AL+a*AG)。liq minority K/q=(1−q)*(AG−AL)/(AL+q*(AG−AL))；gas minority K/q=(1−q)*(AG−AL)/(AG+q*(AL−AG))，q source为−K divU。K与minor response是scaled量，dominant response为complement；数学模型与bounds未改。

## 18. phase-mass design

phase masses tagged unions为sole conservative authority，face flux和Euler increment scaled；不能把extended值只用于recovery。normal↔extended转换不得丢presence；缩窄要求精确可表示或遵循明确冻结normal fast-path算术，不能以阈值删trace。

## 19. gas-species design

N−1 independent authoritative masses具备同一指数范围；dependent cell/face/global quantities作为mass减独立项的exact residual expression；scaled ratio恢复Yi，禁止normalize(Y)。

## 20. R1 design

R=mG eG+mL eL−Eint、Rprime=mG betaG+mL betaL不变。每present相必须EOS query；scaled product/accumulation，保留原pressure intersection/root tolerance。phase energy不是新独立Q或hidden repair。

## 21. cPE design

Wood weighted bulk/mixture density公式不变；exponent-aware weighted sum或带误差 enclosure 的correct rounding dominant view。phase仍mixed；normal formula4例通过原MC3 K algebra budget。完整normal runtime equivalence留给2C。

## 22. positivity/joint-dt design

数学positive/admissible trial的dtRepresentation=infinity；物理fraction/mass/species positivity、hyperbolic、CRV3、endTime、growth控制项不变。算术符号不确定时提升临时精度；EOS-invalid仍拒绝。

## 23. conservation design

extended authority fluxes/reductions为准；periodic/boundary ledger都保留scaled contributions。N−1 exact residual共享authority身份；不能一边ledger positive一边solver zero。fresh shadow边界mass账本和species identities exact PASS。

## 24. CRV3 preservation

无fraction/mass/species viscous diffusion；原stress、tau*u、heating/work identity与hard budget冻结。CRV3必须逐位保留新增authority payload；rho normal view需误差certification。

## 25. restart-v3

五EqRestart-v3/P2-scaled-v2/TRACE-conservative-v2：model/EOS/species/schema hash、Side、hi/lo/exp、union tags、normal Q authority、时间/lastDt/step、volumes、old/committed levels；dependent expr derived。16hex mantissa、int64 exponent、canonical LF、SHA256。production restart STILL NOT CERTIFIED。

## 26. legacy migration

explicit v1→v2 exact迁移所有合法binary64 P2的理论映射；8个fixtures含±0、±.5、±denorm_min位级逆向检查。v2→v1必须exact representable并保留身份，否则REJECT。禁止silent downgrade；生产迁移未实施。

## 27. output/view fields

alphaL_view/alphaG_view明确lossy，minority hi/lo/exponent/side/presence、mass/species representation tags、view exact/underflow/overflow flags；科学导出使用authority records。

## 28. portability

restart无long-double/MXCSR/ABI依赖；normalized mantissa及int64显式wire layout。FTZ-proof tiny low-part primitives是2C mandatory gate；独立Python oracle不能代替异平台runtime测试。

## 29. MPI compatibility

canonical byte buffers、唯一processor-face flux owner、共享scaled flux、指数bin exact reduction/round-once、非阻塞buffer lifetime与versioncheck契约；未实施或qualification MPI。

## 30. 2D compatibility

结构不含一维方向限制；fields/volumes/normals/BC共享authority API。2D与movingmesh高阶重构均是future qualification，不在本轮实现。

## 31. step300 witness

oracle编码alpha≈3.1317757203e-325与mL≈2.1997747462e-322，ratio≈702.404942966，EOS合法；K/source/energy贡献scaled保持，view虽0不改变mixed。full-cap可表示是design proof，不是active v2 step PASS。

## 32. deep-exponent synthetic cases

1e-325/350/500/1000两种minority共8个EOS/scaled range cases，另有binary exponent API到-10000；positive authorities、K、response、phase-energy和Rprime贡献保留。

## 33. performance implications

normal binary64/DD fast path与trace ScaledDD path共享数学API；没有第二PDE。trace flux/accumulator与wire/ledger增加cost，MPI reduction需exponent bins。尚无runtime benchmark，不编造速度或内存数字。

## 34. unresolved risks

DD low part boundary normalization、cancellation、EOS uncertainty、normal/extended tag transitions、correct-rounding enclosure、FTZ primitives、dependent residual cost、MPI determinism、lossy view consumers。均明确列入2C验证；本轮只冻结契约。

## 35. frozen representation document hash

b89c06acbf72a46690e31710aea5c97c4dcc2ead6eb59f404944a8f2de502c51

## 36. active source delta

ZERO：active_before/after manifest逐项一致；2A active与CRV3-1 qualified executable hashes一致。诊断export只编译offline source copy，未修改EOS、K或CRV3physics。

## 37. CRV3-2B COMPLETE?

YES / DESIGN FROZEN。range audit是规定的frozen-direction forecast/counterexample，足以按决策规则排除A并选择C；不冒充当前全case的完整高精度PDE预测。runtime implementation及所有future qualification仍未完成。

## 38. CRV3-2C authorized?

NO / NEXT ROUND ONLY；没有实施P2-v2、scaled transport、restart-v3或重跑active trajectory。

## 39. CRV3-2 status

INCOMPLETE。只有V2 runtime完整实现与qualification后才恢复VV；本轮未增加physical VV PASS。

## 40. M6B.1 status

PARTIAL。历史MC5/TD1、CRV3-1及2A封存证据保留。

## 41. milestone matrix

见milestone_matrix.json：2B DESIGN COMPLETE；2A/2仍INCOMPLETE；2C/3 NOT AUTHORIZED；M6B.1 PARTIAL。
