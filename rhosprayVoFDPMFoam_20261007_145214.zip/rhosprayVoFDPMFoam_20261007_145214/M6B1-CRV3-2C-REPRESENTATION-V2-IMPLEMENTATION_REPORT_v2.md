# M6B1-CRV3-2C Representation-V2 implementation report v2

Status: **COMPLETE / REPRESENTATION-V2 RUNTIME QUALIFIED**. Updated 2026-10-07T03:37:03.
CRV3-2B stays COMPLETE / DESIGN FROZEN, with migration subsection superseded by M1. CRV3-2A stays historical INCOMPLETE. Physical CRV3-2 remains NOT QUALIFIED; CRV3-3 is not authorized.

## 1. Migration-contract decision

The user's explicit 2026-10-06 authorization separates LOSSLESS ARCHIVAL COMPATIBILITY from EXACT ACTIVE MIGRATION. All old-contract-legal artifacts retain original bytes; activation additionally requires exact V3 authority invariants. No further contract approval is pending.

## 2. Impossibility counterexample

mY0=mG, mY1=mG*2^-54, legacy dependent +0. Rounded addition hides positive mY1; the exact dependent is negative. The actual frozen old executable accepted it. Evidence remains in `frozen_legacy_probe/result.json`, `legacy_migration_hard_gate.json`, and `LEGACY_MIGRATION_BLOCKER_v1.md`. Those historical conclusions and the sealed blocker snapshot have not been rewritten. The separate M1 evidence snapshot has 121 files, CRC and every artifact SHA verified: `legacy_migration_M1_snapshot_seal.json`; it does not claim 2C COMPLETE.

## 3. Erratum SHA

Original design SHA256: `b89c06acbf72a46690e31710aea5c97c4dcc2ead6eb59f404944a8f2de502c51`. Erratum SHA256: `700a03ca4b707838e8846c77a3835c98b6ce08a6d32d56d6b45904a9f1ed5704`. Active schema `clocks-v1 mesh-v1 migration-M1` and model metadata reference both. Frozen physics, EOS, PDE, TD1 selection and budgets are unchanged.

## 4. Archival compatibility

Fresh v2 matrix archive status: PASS. Raw source copies and SHA manifests preserve every byte, including original dependent field bits and clocks. An optional `fiveEqLegacyArchive-v1 LEGACY_ARCHIVE_ONLY` container carries original bytes and is rejected by the active runtime reader. Historical v1 model identity is preserved separately.

## 5. Active migration compatibility

Explicit migration reads the legacy source, retains signed P2 zero and independent binary64 payload bits, checks phase authority, exact independent sum/residual, identity and native recovery on both levels, then writes active V3. A metadata-free state conversion is disabled. Absent historical clocks remain unknown.

## 6. Incompatible-state rejection

M5 and M7 reject deterministically with `LEGACY_SPECIES_EXACT_CLOSURE_INCOMPATIBLE`; their original source hashes match raw archives. No projection, clipping, normalization, mG/Et edit, trace removal or 5% migration allowance exists. A legacy rounding-only state remains valid historical evidence.

## 7. Migration fixture matrix

| Case | exact audit | archive | active | source |
| --- | --- | --- | --- | --- |
| M1 | EXACT_COMPATIBLE | PASS | PASS | unchanged |
| M2 | EXACT_COMPATIBLE | PASS | PASS | unchanged |
| M3 | EXACT_COMPATIBLE | PASS | PASS | unchanged |
| M4 | EXACT_COMPATIBLE | PASS | PASS | unchanged |
| M5 | LEGACY_ROUNDING_ONLY_COMPATIBLE | PASS | REJECT | unchanged |
| M6 | EXACT_COMPATIBLE | PASS | PASS | unchanged |
| M7 | LEGACY_ROUNDING_ONLY_COMPATIBLE | PASS | REJECT | unchanged |
| M8 | EXACT_COMPATIBLE | PASS | PASS | unchanged |
| M9 | EXACT_COMPATIBLE | PASS | PASS | unchanged |

M10: native scaled trace gas at exponent −3322; V3 native both-level round trip passes and binary64 downgrade rejects. It is not presented as a nonexistent binary64 legacy source. M3 has exact dependent `1*2^-1074`; M4 retains a subnormal independent amount. Per-cell, both-level dyadic records are in `erratum_release_erratumMigration/species_audit.tsv`; INVALID_LEGACY_DATA is reserved for the additional old-invalid negative-species fixture. A second fresh matrix additionally verifies old native recovery and exact old field bits on both levels for all nine legacy fixtures; its M5 full field bits match the original frozen counterexample. See `legacy_migration_M1_native_fixture_gate_v2.json`.

## 8. Reverse migration

Six compatible binary64 cases reverse with exact field/P2 bits. M4 rejects because its exact dependent is not binary64 representable; M10 rejects because its scaled trace cannot be represented. Independent signed-zero payloads are preserved during reverse conversion.

## 9. Exact real-entry endTime status

Original running actual entry remains authoritative: `final_bin/rhosprayVoFDPMFoam`, original controlDict startup deltaT 2.6850114997842445e-6, configured endTime 0.00055. Current actual checkpoint qualification: PASS. Original binary, case, source snapshot and old completion validator remain untouched. Current time observation: 0.00055000000000000003.

## 10. Real-entry temporal stats

```json
{
  "acceptedStepsObserved": 3652,
  "lastTimeObserved": 0.00055,
  "rejectedCandidates": 0,
  "retryAttempts": 0,
  "rescues": 0,
  "minimumSelectedDt": 2.5968034202128454e-08,
  "minimumSelectedOverFresh": 1.0
}
```

These are observed actual-entry rows. The supplementary replay uses the same original request schedule/core, and must match every selected dt/time plus both endpoint levels before its measurements qualify this trajectory. Replay physical-joint ratio is distinguished from the actual TD1 fresh-cap ratio above.

## 11. Authority conservation

Actual entry calls the exact volume-weighted authority guard at every accepted step. Earlier completed driver and deep dynamic runs also pass. Final actual-entry result and replay confirmation: PASS every accepted step. Published binary64 integral views do not replace that guard.

## 12. P2/species

Final expanded exact phase/momentum/Et/species ledger (binary64 conservation remains auxiliary): {
  "status": "PASS",
  "order": [
    "mG",
    "mL",
    "Mx",
    "My",
    "Mz",
    "Et",
    "mY0",
    "mY1",
    "dependent"
  ],
  "finalSignedExactDyadicResiduals": [
    "-437765486749712418956238948790*2^-203",
    "-8052271195170020644488563793276277626808521655434414728912544890769883913880225*2^-360",
    "1423599890241536956785525*2^-122",
    "0*2^0",
    "0*2^0",
    "-352154322265116734181695*2^-104",
    "0*2^0",
    "-108554227665872489681728958220*2^-203",
    "-329211259083839929274509990570*2^-203"
  ],
  "phaseIndependentSpeciesBudget": "sum of frozen per-step 2^-103 rounding bounds",
  "momentumEtBudget": 1e-10,
  "binary64DiagnosticIsAuxiliary": true
}.

Migration both-level fixtures pass canonical Side/q and exact residual checks. Real entry uses Side for phase presence and residual-expression species authority. Final strict replay validation: PASS exact authorities.

## 13. Representation extrema

Expanded Side/presence/threshold/exact-closure/normalization checks: {"SideCanonical": "PASS", "presenceLoss": 0, "thresholdTransitions": 0, "exactDependentNonnegative": "PASS", "exactNMinusOneClosure": "PASS", "normalizationCount": 0}.

Actual-trajectory extrema and promotion counts (raw replay cumulative heating/entropy totals are superseded by the diagnostic erratum): {"status": "PASS", "scope": "deterministic supplementary replay, exact both-level endpoint match to actual entry", "steps": 3652, "endTime": 0.00055, "strictNativeChecks": 2921600, "strictRootMarginMin": 3529594.3820091384, "rejects": 0, "minSelectedDt": 2.5968034202128454e-08, "minSelectedOverFresh": 0.17238817742253637, "minQExponent": -1277, "minPhaseMassExponent": -1267, "minSpeciesExponent": -521, "extendedCells": 800, "promotions": 2400, "pRange": [2998831.9733150885, 3766847.799041381], "TGRange": [799.9079726892446, 843.2271945192196], "TLRange": [299.9992928998884, 300.4813577486416], "rhoGRange": [12.99922859874281, 15.525277399757796], "rhoLRange": [727.2908525776962, 727.88481865648], "heatingMin": 0, "entropyProductionMin": 3.597295992530602e-07, "integratedHeating": 2.7791664709054064e-06, "integratedEntropyProduction": 3.471232102430609e-09, "viscousLinearResidualMax": 1.1973417402187913e-19, "authorityConservation": "PASS every accepted step", "P2Species": "PASS exact authorities"}. Earlier different-startup coupled driver reached q exponent −1277, phase mass −1268 and independent species −522; these earlier figures are not substituted for actual-entry statistics.

Corrected cumulative CRV3 work/entropy increments: {"status": "PASS", "scope": "cumulative native CRV3 time-integrated increments on exactly matched actual/replay trajectory", "rows": 3652, "selectedClocksAndDt": "bit-identical", "integratedHeating": 18.44970125802174, "integratedEntropyProduction": 0.023044058310723606, "units": "time-integrated increments per unit cross-sectional area; no additional dt factor", "sourceLedgerSHA256": "77e9159482b5d9add21cc1d3618a61a8e5f97f8ef316d668ba0c2c244f418ecb", "rawReplayResultSHA256": "43b33a663cf069607b07b93e13a525c7d58a05064e4dbfd9b7c51bfb133a3e30", "supersededDiagnostics": {"dtWeightedIntegratedHeating": 2.7791664709054064e-06, "dtWeightedIntegratedEntropyProduction": 3.471232102430609e-09}, "PDEOrStateChanged": false, "diagnosticErratum": "REPLAY_WORK_TOTAL_DIAGNOSTIC_ERRATUM_v1.md"}. This bookkeeping correction changes no PDE/state or positive-heating/strict-root checks.

## 14. Performance

Expanded full-trajectory strict/native counts, separate phase/species exponents, transition counts and all native envelopes:

```json
{
  "status": "PASS",
  "steps": 3652,
  "endTime": 0.00055,
  "proofMode": "frozen deterministic transition induction plus per-step paired original-entry candidate/copy versus in-place strict replay; actual original has clocks each step and both-level final checkpoint, not historic per-step authority snapshots",
  "historicalPerStepAuthoritySnapshotsAvailable": false,
  "originalEndpointCanonicalBothLevels": "PASS direct comparison",
  "perStepCanonicalTwoLevelComparisons": 3652,
  "totalAcceptedCellStates": 2921600,
  "nativeCount": 2921600,
  "strictCount": 2921600,
  "initialNativeStrictCount": 800,
  "oldLevelCertificate": "per-step canonical equality to previously certified accepted level, including initial level",
  "toleranceOnly": 0,
  "recoveryFailures": 0,
  "minimumRootMargin": 3529594.3820091384,
  "pRange": [
    2998831.9733150885,
    3766847.799041381
  ],
  "TGRange": [
    799.9079726892446,
    843.2271945192196
  ],
  "TLRange": [
    299.9992928998884,
    300.4813577486416
  ],
  "rhoGRange": [
    12.99922859874281,
    15.525277399757796
  ],
  "rhoLRange": [
    727.2908525776962,
    727.88481865648
  ],
  "minimumQExponent": -1277,
  "minimumMGExponent": -519,
  "minimumMLExponent": -1267,
  "minimumIndependentSpeciesExponent": -521,
  "maximumExtendedCells": 800,
  "totalPromotions": 2400,
  "pureToTraceTransitions": 800,
  "minoritySwitches": 0,
  "SideCanonical": "PASS",
  "presenceLoss": 0,
  "thresholdTransitions": 0,
  "exactDependentNonnegative": "PASS",
  "exactNMinusOneClosure": "PASS",
  "normalizationCount": 0,
  "chainedAuthoritySHA256": "f4e5b929ede38e0364f611d2ff2d7572c187f8b4a90c7df8f59e14eb739f7000",
  "productionRestartCertified": false
}
```

The expanded per-step authority proof uses frozen-transition induction checked by paired candidate/copy and in-place replay, tied to every historical actual selected clock/dt and direct final both-level equality. The original entry did not write per-step authority snapshots; that observational limitation remains explicit. Lossy publications are excluded from canonical comparisons and use the preserved rounding certificate.

Isolated scaled arithmetic microbenchmark ≈516× binary64 is PERFORMANCE ISSUE, not a correctness blocker. Stored operation counters are in `performance/profile_results.txt`. Actual extended fraction, replay runtime and full-entry wall cost remain separately reported; no threshold, demotion or performance-driven state alteration was introduced. Actual process wall/CPU/peak-memory observations are in `real_entry_performance_observations.csv`; a completed matching legacy full-trajectory baseline is unavailable because that representation failed before endTime, so no full-trajectory overhead ratio is invented.

## 15. Remaining blocker

Legacy migration: CLOSED BY EXPLICIT ACTIVE-MIGRATION COMPATIBILITY CONTRACT. New endpoint/audit blocker: NONE OBSERVED. Actual endTime, canonical new-schema conversion, final both-level native validation, strict endpoint audit and current-release smoke must all finish. Any failure receives its own runtime/restart/strict classification rather than being attributed to the closed legacy semantic incompatibility.

## 16. 2C COMPLETE?

**TRUE**. Existing arithmetic/FTZ, deep dynamics, rollback, normal-budget regressions, native EOS and frozen-integrity evidence remain inherited only within their documented scope. Actual-entry and strict-audit status cannot be replaced by the earlier driver run. The latest FINAL STRICT-REPLAY CLOSURE request adds a mandatory separate `final_strict_closure_gate.json`: PASS. It requires the expanded per-step two-level authority equivalence proof, separate phase exponents and transition counts, final exact-ledger residuals, restart short-continuation proof, M1 final regression, consumer D=0 and unchanged release identity. Original executable/source/case/schema are not rebuilt or overwritten; any supplementary verification executable is identified separately. Production restart remains NOT CERTIFIED. Once every gate passes, CRV3-2 physical qualification resumes automatically and receives its own report v3. Stop after CRV3-2 COMPLETE; do not enter CRV3-3.
