# M5B.1 completion record — 2026-09-30

**COMPLETE / DESIGN ONLY. Stop before M6A1b-2B and M6A2.**

| Required design/audit gate | Status | Evidence |
|---|---|---|
| pinned MFC repository/branch/commit | COMPLETE | MFC_FIVE_EQ_SOURCE_AUDIT.md; source manifest |
| actual MFC state / conversion | COMPLETE | common parameters and conversion source audit |
| Allaire, Kapila, K sign and limits | COMPLETE | source audit; FIVE_EQ_ALPHA_MODEL.md |
| MFC acoustics / arbitrary-EOS comparison | COMPLETE | source audit; FIVE_EQ_ACOUSTICS.md |
| positivity / mixture protection | COMPLETE | source audit; FIVE_EQ_POSITIVITY_POLICY.md |
| THINC reconstruction role | COMPLETE | THINC, WENO/MUSCL call-site audit; crosswalk |
| project Qc / one alpha / energy | FROZEN | FIVE_EQ_GOVERNING_CONTRACT.md |
| alpha finite-volume/ALE forms | FROZEN | FIVE_EQ_ALPHA_MODEL.md |
| first Allaire K=0 / later Kapila | FROZEN | alpha/acoustic contracts |
| MULES infrastructure vs compression | FROZEN | alpha contract; first activation cAlpha OFF |
| generic root / gas and liquid EOS APIs | FROZEN | FIVE_EQ_STATE_RECOVERY_CONTRACT.md |
| acoustic API / eigenstructure | FROZEN | FIVE_EQ_ACOUSTICS.md; beta inputs mandatory |
| common conservative KT flux family | FROZEN DESIGN | governing contract; numerical NC/contact gate remains |
| pure gas / liquid / vanishing phases | FROZEN | recovery/positivity contracts; no silent residual deletion |
| positivity / correction policy | FROZEN | seven separate validity checks; ledger/failure policy |
| contact recovery / alpha-pressure tests | DEFINED, NOT RUN | FIVE_EQ_UNIT_TEST_CONTRACT.md |
| CFL / capillary / DPM placement | FROZEN DESIGN | governing contract; no activation |
| adopted vs excluded MFC details | COMPLETE | MFC_TO_RHOSPRAY_FIVEEQ_CROSSWALK.md |
| active solver unchanged | PASS | 10 protected files match pre-change SHA-256 |

## Material findings

1. Arbitrary-EOS Allaire acoustics require betaG,betaL; six primitive inputs
   alone are insufficient. These derivatives are shared with pressure recovery.
2. MFC's density-dependent/non-alt arithmetic acoustic branch is not borrowed
   as the project's arbitrary-EOS eigenvalue. Constant SG analytic recovery and
   mixture temperature also remain excluded.
3. In this pinned version alt_soundspeed accepts HLL/HLLC and constrained hypo
   HLLD; nonconservative quantities are solver-mode dependent. K cannot be copied
   independently into KT.
4. MFC mpp_lim/mixture_err include clipping/floors; project detection concepts
   are adopted, but those state modifications are not accepted automatically.
5. Generic reconstruction may differ from legacy gas face rho*(1/psi).
   Pure-gas flux equivalence requires identical recovered/reconstructed states,
   not merely the same PDE or alpha=0. No automatic numerical equivalence claim.
6. A two-sided pressure-equilibrium recovery test is not a proof of discrete
   KT contact preservation. No root/flux implementation or numerical unit test
   has been executed in this design milestone.

## Changes and result

Added the seven requested architecture documents, a separate unit-test contract,
this gate record, a source-integrity manifest and offline provenance recorder.
Updated M5B_TWO_PHASE_MODEL.md and MILESTONE_STATUS.md. No C++ skeleton needed:
existing twoPhaseKTState.H remains unchanged and uncalled. No Make changes or
new library. No wmake was needed for documentation/provenance-only edits.
No CFD, production fitting/table construction, state/root recovery activation,
two-phase KT, surface-tension coupling or transfer occurred. Existing DPM is
preserved; later source restructuring remains M8.

Next M6A1b-2B: freeze versioned reference training/holdout contracts inside the
approved liquid domains; certify phase energy, beta, acoustics and inversions,
with separate BUFFER and independent experimental checks. Energy-reference
alignment remains a separate prerequisite to M6A2. No work on 2B begins here.
