# fiveEqAlphaModel — frozen design, no runtime switch

## Phase convention

Project independent variable alpha=alphaL; alphaG=1-alphaL. In the MFC crosswalk
set fluid1=L and fluid2=G. Let B_L=rhoL*cL^2 and B_G=rhoG*cG^2 > 0.

    K_L=alphaL*alphaG*(B_G-B_L)/(alphaL*B_G+alphaG*B_L)
    K_G=-K_L

The denominator stays positive for a valid two-phase state. Branch before
absent-phase evaluation. For finite present-phase moduli K_L tends to zero
in either pure limit, and is zero for equal phase bulk moduli. In an interface
cell it is finite, dimensionless and may have either sign. No universal small-K
assumption is allowed at large impedance ratios.

## API design

`fiveEqAlphaModel` has design enum {allaire,kapila}; future evaluation receives
validated recovered phase thermodynamics and phase-presence flags and returns
K_L, model-consistent acoustics identifier and status. The baseline selects
allaire: K_L=0. Kapila is retained for a separately assessed later upgrade.
No dictionary or runtime switch is introduced in M5B.1.

## Finite-volume forms

Product rule on a fixed mesh gives

    Allaire: dt(alphaL)+div(alphaL*U)=alphaL*div(U)
    Kapila:  dt(alphaL)+div(alphaL*U)=(alphaL+K_L)*div(U).

On ALE meshes the extensive balance is

    d(V*alphaL)/dt + sum_f(F_alpha_relative)
      = V*(alphaL+K_L)*div(U_absolute).

The RHS uses physical divergence, not relative divergence alone: geometric
conservation must be respected. Divide by V only with the matching time/mesh
volume update. The nonconservative source, alpha flux and conservative KT
states must share a verified numerical velocity/time-level contract.

## M2 role after future activation

M2 currently is a one-way marker using gas KT phiV, bounded MULES alphaPhi,
artificial cAlpha compression and alpha subcycling. It remains unchanged now.
Future MULES can supply limiter/boundedness and subcycling infrastructure;
its existing flux/source logic is not certified as the five-equation algorithm.
Subcycling requires consistent phase-mass, energy and face-state time levels;
an alpha-only subcycle against unrelated conservative states is not accepted.

**First five-equation activation: cAlpha contribution OFF; no artificial
sharpening.** Changing alpha at fixed mG,mL,Et changes intrinsic densities and
generally pressure. THINC changes face reconstruction and associated phase
partial densities in MFC; cAlpha introduces a PDE compression flux. One does
not justify the other. Later sharpening requires its own conservative,
pressure-compatible material-state design and milestone.
