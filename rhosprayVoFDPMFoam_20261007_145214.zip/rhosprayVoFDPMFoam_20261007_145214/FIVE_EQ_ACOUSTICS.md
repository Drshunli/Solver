# fiveEqAcoustics — arbitrary-EOS characteristic contract

## Derivation for Allaire, K=0

Assume valid isobaric states, frozen gas composition, common U and source-free
inviscid flow. Define theta=div(U), I=sum(m_k*e_k), beta_k=(de_k/dp)|rho,Y
and xi_k=rho_k*beta_k. The thermodynamic phase identity is

    c_k^2 = (p/rho_k^2 - (de_k/drho_k)|p,Y)/beta_k.

From the phase mass laws and Dt(alpha_k)=0,
Dt(rho_k)=-rho_k*theta and Dt(m_k)=-m_k*theta. The energy law gives
Dt(I)=-(I+p)*theta. Differentiating I yields

    D*Dt(p) = [sum(alpha_k*rho_k^2*e_rho_k)-p]*theta
    D=sum(m_k*beta_k)=sum(alpha_k*xi_k).

Using sum(alpha)=1 and the phase identity:

    Dt(p)=-rho*c_A^2*theta
    c_A^2=sum(m_k*xi_k*c_k^2)/(rho*sum(alpha_k*xi_k))
         =(wG*xiG*cG^2+wL*xiL*cL^2)/(alphaG*xiG+alphaL*xiL).

Here w_k=m_k/rho are material mass fractions, not gas species. Linearizing the
normal momentum equation together with this pressure equation gives acoustic
eigenvalues U_n +/- c_A; material/species/shear modes advect with U_n. Thus c_A
is the baseline KT characteristic speed. This agrees with the isobaric
[Allaire–Clerc–Kokh model](https://www.cmap.polytechnique.fr/~allaire/ack.pdf),
Eq. 29; formula above is independently derived rather than copied SG mixing.
It is positive for positive rho,beta,phase sound speeds and admissible alpha.

## Why the requested six-input interface must be extended

alphaG,alphaL,rhoG,rhoL,cG,cL alone do **not** determine arbitrary-EOS Allaire
acoustics. They do not identify betaG,betaL. Equal phase density/sound-speed
inputs can have different caloric pressure derivatives and different c_A.
Freeze the expanded API:

    fiveEqAcoustics(mode,phaseFlags,alphaG,alphaL,
        rhoG,rhoL,cG,cL,deGdpConstRhoY,deLdpConstRho)
      -> {cMix,K_L,validity,status}

Absent phases are represented with explicit flags/optional records, not guessed
rho/c/beta values. Allaire uses beta and returns K_L=0. Both beta values are
already necessary for pressure recovery, so this does not add a separate EOS.

## Kapila and Wood, kept as later extension

    B_W=1/(alphaG/B_G+alphaL/B_L)
    c_W^2=B_W/rho
    K_L=alphaL*(B_W/B_L-1)

Then Dt(rhoL)=-rhoL*(1+K_L/alphaL)*theta
=-rhoL*B_W/B_L*theta; similarly for gas. With Dt(p)=-B_W*theta these phase
trajectories are isentropic. The phase energy differentials sum to the
mixture pressure work, so this is a matched Kapila closure. Swapping in c_W
while retaining Dt(alpha)=0 generally changes the PDE eigenstructure.
For general K, differentiating the energy also contains
K_L*(rhoL^2*e_rhoL-rhoG^2*e_rhoG); omitting it mixes incompatible models.

## MFC correspondence and pure/interface limits

The pinned MFC alt_soundspeed path uses Wood and its matching K. Constant SG
non-alt coefficient mixing agrees with c_A because xi=1/(gamma-1). Its
state-dependent/non-alt arithmetic bulk-modulus branch is not adopted as a
generic caloric-eigenstructure formula. No MFC Riemann-average enthalpy formula
or SG parameters are used in the project.

Both project modes return the present phase's c in exact pure gas/liquid;
K=0 there, without evaluating absent-phase thermodynamics. For admissible
interface states require finite cMix^2>0 and finite K. A very small valid Wood
speed is not a justification to replace it with gas/liquid c. INVALID states
fail; no mixture_err-style synthetic acoustic floor. Near-pure thresholds
follow FIVE_EQ_POSITIVITY_POLICY.md and are not numeric constants here.
