# M6B.1-TD1-TEMPORAL-ROBUSTNESS REPORT v1

2026-10-05；项目局部 representable-time/admissibility-aware temporal driver。权威请求为用户本轮粘贴要求，后续“继续等待原定终止条件”“停止”，及最新“目前可以判定给出结论”。本次封存现有证据、完成报告，不重新启动长跑。历史文档仅用于证据，不将旧 NEXT ROUND ONLY 限制误当本轮用户禁令。

## 1. TD1 status

PARTIAL / LOCAL TEMPORAL GATES PASS / MICROSTEP EFFICIENCY UNRESOLVED / STOP. 按用户要求持续等待后，由用户明确“停止”中止实际运行；本次按后续“目前可以判定给出结论”完成现有证据审计。局部修复有效，但未到 endTime，不能授予完整 serial robustness qualification。微步长效率问题是观察结论，不伪造自动 solver blocker。

## 2. Temporal source delta

仅修改两个既有项目文件，并新增一个时间策略头文件。dependent species 的原表达式从 serial caller 移到 trial 验证阶段，公式不变。逐文件 SHA 与完整差异见 source_delta.json、temporal_source.patch。

| File | Before SHA256 | After SHA256 |
|---|---|---|
| serialFiveEq/runSerialFiveEq.C | 903a0af0f540256e4077c6ea922ac890c49a7aaf18685ab83406837820c2d1b5 | 3327f1988bcca53a459d01f9cb2db0fd7624d946b6da378477c679fbcec7907a |
| fiveEqIntegration/fiveEqTemporalContract.H | d31c88e9e1a876e91b44bc4a7acfc27ab2418d066093d1db6ac773f5ec2c3896 | e47e6466de56e82856ebc66281acf40061dd121ae917144a1343cf6f9019ba89 |
| fiveEqIntegration/fiveEqTemporalPolicy.H | NEW | a4e80681afdeb5fedfc2c628170e0e30dd1aacd171f4011b90199cad6985d062 |

## 3. Commit contract

从同一 const committed anchor 重建每次 trial；全部 100 cell 的原始 R1、P2、PRESENT/invariants 与原始 N-1 species residual closure 后 R1 均通过，且实际 binary64 tOld+dt>tOld，才原子提交。失败不更新 Q/P2/old/time/lastDt/step。没有 conservative correction 或 normalize。

## 4. FreshCap policy

每个 committed anchor 重算原 jointBound（mass/species/alpha/P2/acoustic）及 end-time cap。freshCap=min(current end cap, original jointBound)，不以 lastDt 截断。startup 保留原 deltaT 上界。

## 5. Growth policy

固定内部 growthFactor=2.0；普通请求 min(freshCap,2*lastAcceptedDt)，无自动调参。active trajectory 中 32219 个非 startup 请求大于 incoming dt；合法微步长仍可因下一次 reject 回落，未声称全程单调增长。

## 6. Connected search policy

原 connectedDt 的物理算法和容差逐字不变，用作首个 retry 候选；必要时原 anchor 上至多 16 个 connected/halving 候选。首个结果不作为全区间合法性或最大 dt 的证明。

## 7. Progress-rescue algorithm

state-valid/nonprogress 不可提交。从已知非推进合法 dt 开始 2 倍 ladder，upper=min(freshCap,current requested cap)。每个点完整 all-cell/raw/post-species/time 验证；到 upper 或预算后选最大已测 legal advancing witness，并至多两个 nextafter 邻点。nextafter 只指导搜索。

## 8. Nonmonotone handling

ladder 在 FAIL 后继续测试更大点。CASE F 与 anchor236 的 FAIL→later PASS 已证实此路径；不以单调二分为唯一搜索，不要求证明数学最大 dt。

## 9. Search budget

每次 progress-rescue 上限 64 次完整候选评估（不含 request/connected）；预算单元测试通过。无 witness 抛 TEMPORAL_RESOLUTION_SEARCH_BLOCKER；不自动命名为 TIME_RESOLUTION_BLOCKER。

## 10. Representable-time rule

唯一提交判据为有限且 tOld+dt>tOld；无 dt floor，无强制 setTime(nextafter)。time ULP 仅用于日志/搜索指导。startup 的 dt/ULP 诊断采用 long double，避免 t=0 的双精度比值溢出。

## 11. Anchor234 replay

request FAIL 可恢复；selected=8.7185434459543499e-07 s；raw/post 全100 PASS、时间推进、重复 bit-deterministic，无 rescue。

## 12. Anchor235 replay

selected=1.0186691506879807e-18 s；时间推进、全100 PASS、重复确定；connected retry 工作时不调用不必要 rescue。

## 13. Anchor236 replay

旧 nonprogress witness 被丢弃。connected=2.3690109654364745e-20 s；rescue 10 evaluations，存在中间 FAIL 后 later PASS；所有选中状态 raw/post 全100 PASS、Q/P2/time/dt 两次一致。

## 14. Anchor236 selected advancing dt

9.4760438617458992e-20 s = 1.7480215594887294 time ULP；tOld=0.00028286341377157669；tNew=0.00028286341377157679。更高已测 FAIL 均保留，未声称此为全区间最大 dt。

## 15. Historical collapse replay

SR1/CAP1 anchor137、EOS2 anchor118、EOS3 pre-collapse156 以及 mandatory234/235/236 均推进。旧 EOS3 anchor157 已携带不可推进 lastDt；2x request cap 仍小于 half ULP，故预期 SEARCH_BLOCKER、零 commit、精确 rollback。该 guard regression PASS 不等于坏历史状态成功恢复，更未越过授权增长上界。

| Fixture | Native result | dt or unchanged historical lastDt | Time progress |
|---|---|---|---|
| 234 | PASS | 8.7185434459543499e-07 | True |
| 235 | PASS | 1.0186691506879807e-18 | True |
| 236 | PASS | 9.4760438617458992e-20 | True |
| sr1 | PASS | 3.4541297952698358e-20 | True |
| eos2 | PASS | 1.1887441605610328e-19 | True |
| eos3 | TEMPORAL_RESOLUTION_SEARCH_BLOCKER | 4.9071299733786278e-21 | False |
| eos3_pre | PASS | 1.6684241909487512e-19 | True |

## 16. Unit tests A-I

A ordinary；B request FAIL/retry PASS；C bounded regrowth；D legal nonprogress rejected；E larger legal pocket；F FAIL→larger PASS；G no witness in bounded search；H end cap；I repeated retries/exact immutable rollback。9/9 deterministic PASS，另有 64-evaluation exhaustion PASS。

## 17. Regrowth test

真实 current-v3/original R1 的 uniform pure-gas 100-cell driver：从 accepted1e-12 s 连续22个增长步（2x 上界），随后8个 fresh-cap 步；100-cell recovery、时间严格递增 PASS。

## 18. Shock replay

最终 active v3 265–400 K/new TD1，原 shockInterface_100 的17个 fresh IC/mesh/config 文件 SHA 不变；实际接受 32252 步。最初启动在 step0 的新日志 dt/ULP 双精度溢出触发 SIGFPE；修正诊断后重跑全部 harness 与 fresh build，原启动失败日志保留。最终运行由用户“停止”明确中止（exit143），并非自然 solver blocker 或未经授权的效率中止。最后10000步：{"steps": 10000, "tStart": 0.0002828634147091128, "tEnd": 0.00028286341471286345, "elapsedPhysicalTime": 3.75063478538773e-15, "medianSelectedDt": 2.653292255826728e-19, "medianFreshCap": 1.2050935080033238e-06, "maxSelectedDt": 2.5774839057061503e-18, "minSelectedDt": 3.316615319646209e-20, "requestedRejects": 3690, "rescueInvocations": 1729, "growthRequests": 10000}。这证明观察区间效率严重不足，不证明未来永远无法到 endTime。

## 19. Reached endTime?

False；configured=.00055 s；last published accepted time=0.00028286341471286345 s。

## 20. First new blocker

NO NEW AUTOMATIC SOLVER BLOCKER OBSERVED；termination=USER_REQUESTED_STOP。 精确监视器/driver blocker 证据：

```json
null
```

user_stop_snapshot 保存明确停止时的 raw Q/P2/time/dt、完整动态历史与候选账本。accepted_steps.csv 有32231完整行，21行末尾缓冲未写出；dynamic_history.csv 每步 flush，0–32252共32253完整行，且与32252个 SELECTED diary逐步time完全一致，作为accepted计数权威。td1_last_anchor 是step32252的完整100-cell状态。首次日志溢出单独保存为已修正的实现诊断缺陷，不与最终 solver blocker 混算。

## 21. Total requested trials

32252；request/connected/rescue 不混同。总已测 candidate evaluations=94012。

## 22. Recoverable rejects

11798 个 accepted transaction 的 requested state reject；全部 request state rejects=11798；所有候选 state rejects=36390；legal-but-nonprogress discarded=6618。这些计数均区别于 observer 原 R1 bracketing probes。

## 23. Rescue invocation count

5556

## 24. Rescue candidate count

49962；每次 <=64。

## 25. Minimum accepted dt

3.3166153196462089e-20 s。

## 26. Minimum accepted dt/ULP

0.61180753992458015；排除 t=0 的 subnormal ULP startup 巨大比值。小于1 ULP 不自动判不推进，实际加法始终严格增长。

## 27. Time monotonicity

所有完整 published accepted states 严格递增；driver selected ledger 同样实际 tNew>tOld；Foundation Time 的实际递增在 serial caller 独立检查。无 tNew==tOld commit。

## 28. Conservation

原 9 个分量（mG/mL/Mx/My/Mz/Et/3species）总体积分误差最大 4.0158614338351795e-13；门槛1e-12；PASS=True。不改变 conserved state，不修补漂移。失败时按照用户 physics-core blocker STOP，不能用 temporal 调参掩盖。

## 29. P2/species

原 P2 payload/sign/lo/exact alpha 语义与 PRESENT-preservation gates 执行；全 accepted raw/post recovery PASS，无 phase deletion/threshold/normalize。species closure max=1.7118919942167416e-16；PASS=True。

## 30. EOS hash preservation

active ndecane_gibbs_v3 HARD p=.05–12 MPa/T=265–400 K。81 coefficients SHA610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac；energy reference SHAed59db0b117a87a3155ca3636c334da8a8b3631afe39dd3ad9dcfd95099bc1ef；C_L369229.9537234281 不变。v1/v2/v3 evaluator/factory/metadata 全 unchanged。历史 LR1 metadata verdict 原字节保留，新 EOS3 operational authority 仍为 ADM1，不代表物理固液相证书。

## 31. Temporal source hashes

见第2项 source table 与 exact patch。PRE/IMPLEMENTED 是独立、不可覆盖的早期快照；IMPLEMENTED 后的 braces/ledger 字段与启动比值诊断修正全部在 final VALIDATED patch 中反映，未将早期快照冒充最终源。

## 32. Executable/library SHA

最终实际安装与 runtime copies/test-closing hashes 一致：

```text
4981c4bfc7f395e096f1296d3a51a1b08f725a57758bb3270c438da97c9edcd9  /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/bin/rhosprayVoFDPMFoam
1d80d36f8cead6d8bd2f614af2d9bc3b43427b346ed7cae6a8ead6dae6309888  /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayLiquidEOS.so
f5a494fcfff66e555f6f3df9813fb6b4079626f60ef9e2272e12bfec47817896  /home/zsl/OpenFOAM/zsl-7/platforms/linux64GccDPInt32Opt/lib/libRhosprayFiveEqThermo.so
```

## 33. Foundation/project hashes

6717 Foundation、19 native parcel、115 libraries unchanged；project baseline109中107 unchanged/2 authorized existing deltas/+1 helper。ADM1 evidence/docs 931 条 before hashes 全 PASS（milestone 在验证后仅追加）；旧 ADM1 checkpoint SHA932016243589d00d7eaa9aa7cbf9cd5180ab913561fa8de067c1d61046401dbe 完好。无 Foam::Time/Foundation timestep delta。

## 34. TD1 COMPLETE?

False；局部 temporal gates PASS 不能替代完整 shock/physics gates。23项完整 gate 在 TD1_stop_gate.json；endTime/new blocker 是独立总判据。

## 35. IDP1 required?

FALSE / NOT ESTABLISHED。未证明所有推进合法 dt 不存在；当前 advancing legal witnesses 仍有。有限搜索 miss 或守恒漂移不能自动证明 true admissibility blocker。

## 36. Next permitted milestone

MICROSTEP REGROW/REJECT EFFICIENCY REVIEW / SEPARATE NEXT-ROUND AUTHORIZATION; DYN-CLOSURE prerequisite unmet; IDP1 not established。本轮 STOP；不执行下一里程碑或 source repair。

## 37. M6B.1/M6B status

M6B.1 PARTIAL / STOP；M6B PARTIAL。未认证 remaining wave ladders/RH/high-Mach/Galilean/production restart。

## 38. Milestone matrix

| Milestone | Status |
|---|---|
| PHASE-DEFER | COMPLETE / POLICY FROZEN；历史 CLASS D 保留 |
| EOS3-NUMERICAL | COMPLETE / OPERATIONAL DOMAIN FROZEN on observed accepted trajectories |
| ADM1 | COMPLETE / OUTCOME C / TRIAL REJECTION SEMANTICS CLOSED |
| TD1 | PARTIAL / LOCAL TEMPORAL GATES PASS / MICROSTEP EFFICIENCY UNRESOLVED / STOP |
| M6B0 | COMPLETE / FROZEN |
| M6B.1 / M6B | PARTIAL |
| M6B.2 / active DPM / MPI active / production | NOT AUTHORIZED / NOT EXECUTED |
| T4-S1/S2 | FROZEN |
| T4-S3 | DEFERRED |
| T4 / M8A | PARTIAL |

## Checkpoints / STOP

PRE SHA 3f6cf2c836a0c56868157ff4bf6dc9351979774de9ea9c0834ed5072f823c764；IMPLEMENTED SHA ab973d92a1fd618a5a9246fd4278cb74aa791cec0d3ba04ebe13474b1a0d102d。最终 M6B1_TD1_VALIDATED_v1.zip 是本轮验证结果快照，其 VALIDATED 名称不意味着 TD1 COMPLETE；seal/CRC/per-file SHA 另存 TD1_VALIDATED_seal.json，避免报告与 archive SHA 循环依赖。

STOP。未自动启动 DYN-CLOSURE、IDP1、EOS extension/v4、M6B.2、active DPM、MPI active、T4-S3 或 production CFD。
