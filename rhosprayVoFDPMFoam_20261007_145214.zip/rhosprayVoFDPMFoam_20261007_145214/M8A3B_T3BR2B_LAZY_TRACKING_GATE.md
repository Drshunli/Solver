# M8A.3B-T3B-R2B — local lazy tracking architecture gate

2026-10-03. Foundation OF7 actual-source development.

## Supported profile and limits

Passive serial fixed mesh; scalar `cell`, U `cellPoint`; C10H22/O2/N2 JANAF/Sutherland; current heat/phase change and radiation disabled. Unsupported scalar/U interpolation configurations reject. No radiation sampling implementation. Native reference thermo/cloud field handles are reference/catalogue infrastructure, **not** the candidate gas view; all candidate gas sampling uses Q/P2 support owner. Common-pressure liquid initialization is checked in the spatially constant-pressure fixture only. This gate does not certify full solve/preEvolve/output/transactions or production startup on arbitrary mixed fields.

# 1. R2B status

COMPLETE for the passive serial fixed-mesh profile below. This is an architecture gate, not CFD or full transaction closure. Final local test: 252194 checks, 0 failures; Foundation OF7 wmake PASS.

# 2. Native blocker recap

Installed Thermo TD constructs full Cp/kappa before per-parcel support. Installed Kinematic TD also fixes its concrete nested type/interpolators. Both remain unchanged; the candidate uses a distinct local family.

# 3. Local type hierarchy

Foam::fiveEqDPM::LazySprayParcel<LazyReactingParcel<LazyThermoParcel<LazyKinematicParcel<particle>>>>. LazySprayCloud aliases installed SprayCloud<ReactingCloud<ThermoCloud<KinematicCloud<Cloud<LazyParcel>>>>>.

# 4. Native-to-local type mapping

Kinematic/Thermo/Reacting/Spray parcel declarations and definitions receive distinct names and namespace. particle geometry and all cloud templates/models remain installed types.

# 5. Files copied/overridden

19 parcel files: Kinematic, Thermo, Reacting each H/I.H/TrackingDataI.H/C/IO.C; Spray H/I.H/C/IO.C. Native registration include/macro file adapted locally. No model implementation or cloud implementation files copied. copy_manifest.json and semantic_changes.diff record the budget.

# 6. trackingData architecture

Only opaque provider/configuration handles, generation, native pose and scalar caches. No installed Kinematic/Thermo/Reacting TD base. TD copying is deleted to prevent sampler/session aliasing; physical parcel copy remains native-equivalent.

# 7. Lazy property architecture

R2ACarrierProvider reuses frozen R2A intrinsic-gas scalar/transport evaluation. Native barycentric U interpolation is sampled separately over physically defined common U. No default air, epsilon, mixture-density substitution or fake gas field.

# 8. Support preflight entry

setCellValues and carrier-dependent calc/source entry guards; samplers and cached physical getters also require current support. Actual native coordinates, cell, tetFace, tetPt, face, particle identity/IDs, requirements and generation are checked. Point contributors derive from currentTetIndices and sparse native coefficients.

# 9. Cp construction behavior

Local whole-field Cp call sites/storage: zero. Structural constructor is compiled and executed with a cloud facade having no thermo/Cp API, and with the actual local cloud after gas becomes absent. Query counters verify zero materialization on rejection. Whole-field zero in result JSON is an architectural count, not an instrumented interceptor inside installed heThermo.

# 10. kappa construction behavior

Local whole-field kappa call sites/storage: zero. No full field is filled in liquid cells. Native control deliberately retains its own eager Cp/kappa path as the legal numerical oracle.

# 11. mu behavior

Sampled only after valid support, with actual native Sutherland transport through frozen evaluator. No invalid-support mu evaluation; no whole-field fake mu created by local tracking.

# 12. T/Y/rho behavior

Intrinsic gas rho/T and q-based species are obtained from the committed support certificate after preflight. Gas-absent slots contain no gas object. Reacting surface Y reads are redirected to the certified local sampler.

# 13. Generation semantics

Stale generation rejects before properties. Fresh preflight clears packet validity and native point cache is rebuilt for the new generation. Q/P2 remain authoritative; no TD state is serialized.

# 14. Movement invalidation

Native trackToFace followed by explicit invalidation; every sampler verifies native coordinates/tet/face/identity. An actual native geometry move invalidates the previous query token.

# 15. Rebound invalidation

Local hitPatch invalidates before installed wall handling. Native Rebound kernel test explicitly invalidates then requires a fresh query; valid next query succeeds and absent next query rejects before thermo.

# 16. Injection child semantics

Actual coneInjection setPositionAndCell and setProperties plus native cloud parcel-thermo initialization precede the first independent query. Born parcel in synthetic core rejects without gas materialization. This is the birth protocol spot test, not the full transient injection/event matrix.

# 17. KH child semantics

Actual native KH update creates a child. Independent child preflight occurs before coupled/noncoupled force calls and dispersion, then parent token is restored. RAII prevents leaking the new child on rejection. Physical fields/arithmetic are otherwise native.

# 18. Reacting layer compatibility

Concrete TD identity replaced. Native phase-change, parcel composition and source arithmetic retained; field-only Cp read maps to a certified own-cell Cp sample; Bird surface composition uses local Y. Current fixture heat/phase change are disabled.

# 19. Spray layer compatibility

Native liquid Cp/rho/mu/sigma, atomization, breakup, child physical fields and native ORourke model preserved. The change is carrier availability timing, not a new spray model.

# 20. Runtime-selection compatibility

Project-local registration uses actual native macros and their Kinematic/Thermo/Reacting/Spray aliases. Native and local tables coexist. Local cloud construction selects production models; test fixture selects the actual rebound model, with UFactor=1.

# 21. Eight-model instantiation result

PASS: coneInjection, sphereDrag, stochasticDispersionRAS, blobsSheetAtomization, ReitzKHRT, ORourke, rebound, voidFraction. Explicit full-cloud member instantiations and native alias-based registration compile/link; this is not eight-model full evolution closure.

# 22. Clone/copy result

PASS: serial physical parcel copy, clone and clone(mesh) serialize identically. Track cache excluded from physical fields. MPI behavior is not certified.

# 23. iNew result

PASS: local stream constructor and iNew serial round trip. Native IO and read/write templates retained and compiled. No processor migration run.

# 24. Pure-liquid structural construction

PASS: local TD structurally constructs with exact absence, without gas property calls. Also tested using actual local cloud type after a pure slot publication.

# 25. Pure-liquid rejection

PASS: first required carrier query rejects GAS_SUPPORT_INVALID before gas thermo/point materialization. Frozen pure gas-recovery count remains zero.

# 26. Mixed-cell result

PASS: alphaL 0.1/0.5/0.9, native scalar/U/species bit comparisons. Native oracle is populated only for legal gas-present reference states.

# 27. Trace result

PASS: alphaG=1e-20 remains TRACE_PRESENT, query succeeds and signed P2/Q bytes remain unchanged. No complement decoding or cutoff.

# 28. All-gas 21000 result

PASS: local TD 21000 cells, 252000 scalar/vector/species component comparisons; zero bit differences. Frozen R2A also rerun separately: 273263 checks/0 failures.

# 29. rho comparison

Zero bit differences in all-gas and mixed reference comparisons; rho is intrinsic gas density, not rhoMix.

# 30. U comparison

Zero bit differences using native barycentric/tet interpolation, not a position-to-tet replacement. Common U is defined in both phases; gas support is still required for DPM queries.

# 31. T comparison

Zero bit differences; gas T sampled separately from parcel/liquid T. No gas post-shock temperature substituted for liquid temperature.

# 32. p comparison

Zero bit differences. Pressure is common/isobaric. In this passive fixture common p is spatially constant and native liquid-birth pressure handle has the same value; nonuniform production pressure binding must be audited before active integration.

# 33. Cp comparison

Zero bit differences. Native transport/thermo formulas, no Cp=Cv substitution.

# 34. mu comparison

Zero bit differences. Actual native transport API/order retained through frozen query core.

# 35. kappa comparison

Zero bit differences in tested all-gas/mixed profile. No generic claim for other transport/interpolation packages.

# 36. species comparison

Zero bit differences for current C10H22/O2/N2 recipe and ordering. Three-species frozen map is the supported profile.

# 37. Surface-value comparison

PASS: actual local/native calcSurfaceValues Ts/rhos/mus/kappas/Pr and Re, exact order and bit comparisons. No surface force or VOF surface-tension activation.

# 38. Source-correction comparison

PASS: nonzero native/local mass/momentum/heat source correction equality, including raw cell Cp. Invalid support rejects with source/parcel/cache values unchanged. Native full-cell mass convention remains unchanged; no phase weighting added.

# 39. Native trajectory comparison

PASS: actual native and local Cloud.move, 10 consecutive steps, complete parcel serialization equality. This is particle/model testing, no Eulerian solve.

# 40. Mixed-topology move

PASS: actual local Cloud.move near synthetic T2 rectangular liquid core. The rectangle is a test geometry, not a production nozzle or validated liquid column.

# 41. Support crossing

PASS: native movement into exclusion rejects. Q/P2 bytes unchanged. Prior legal segments can mutate trial-local parcel/sources; rejection is not a universal zero-mutation transaction claim.

# 42. Rebound first query

PASS: actual OF7 Rebound correct() followed by independent valid/invalid next queries. No wall physics changes.

# 43. Registry result

PASS: 100 explicit query invalidation/rebuild cycles, stable registry. Samplers are not registered gas fields; binding lifetime is scoped.

# 44. Performance/memory

Final full harness 3.72 s wall time, peak RSS 281020 KiB on this run. Includes native oracle, sparse geometry, two clouds and all tests; not isolated lazy-path memory/performance or a scalability result.

# 45. Frozen regressions

Fresh PASS: source/energy9288, M8A.3A6375, T2native1725880, frozen allgas21000, T3A64395, P2/R1105775, temporal9663, old R2core11187+collision10245=21432. Eight energy goldens byte-identical. These old-native replays are separate from R2C.

# 46. Foundation source hash

19 parcel files verified against copy-before hashes; native ORourke C/H match prior hashes. 6717 installed source/Make files have a closing baseline and verification. The full-tree baseline is a closing audit, not a claimed full-tree pre-turn snapshot. No installed files written.

# 47. Active solver impact

NONE: 145 protected files match frozen pre-change manifest. Active solver/equations/cloud creation/evolve, source adapter, energy ledger, Q/P2 implementation and production mesh/BC unchanged.

# 48. Whether R2B COMPLETE

YES for the documented passive fixed-mesh serial profile. All required bridge gate tests pass. Not a production-ready switch, MPI proof, CFD validation, universal model/interpolation support or full transaction closure.

# 49. Whether R2C may start NEXT ROUND ONLY

YES, next round only after user continuation. Not executed here. R2C must cover full eight-model events, output staging, support retry, lifecycle and transactions on local bridge.

# 50. Updated milestone matrix

T3A COMPLETE; historical R2/R2A/R2A-FINAL PARTIAL; R2B COMPLETE; R2C NOT STARTED; T3B/T3 PARTIAL; T4 NO; M8A PARTIAL; M6B.0/1 NO. STOP. No CFD.

## Retained repair evidence

Initial compile corrections: missing native type include/static symbols, barycentric zero symbol, radiation sampler interface. Rebound unit fixture initially lacked reboundCoeffs and was fixed using actual OF7 UFactor API. Regression runner attempt 1 wrongly redirected rebinding fixture path; original failure retained and separate v2 runner PASS. Initial OR hash path was wrong; actual directory found, final hashes match. No model failure is hidden as a PASS.

## Artifacts

- TYPE_GRAPH_AUDIT.md (written before local implementation copy)
- tests/fiveEqDPMLazyTrackingR2B: localTypes.H, lazyCarrierSession.H, r2aCarrierProvider.H, localRegistration.C, 19 parcel files, passive gates
- fitting/dpm/m8a3b_t3br2b_v1: final_audit.json, copy_manifest.json, semantic_changes.diff, native hashes, build logs, carrier_v1–v7 results, frozen replay results

STOP: R2C/T4/M6B/CFD not executed.
