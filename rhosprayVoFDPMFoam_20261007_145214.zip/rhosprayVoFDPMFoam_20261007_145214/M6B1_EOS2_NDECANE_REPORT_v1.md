# M6B.1-EOS2-NDECANE — 活动安装、回归及新阻塞报告

2026-10-05。原320K上限问题已消除；285K下端新阻塞未修。

## 1. EOS2 status

**PARTIAL / STOP — EOS2_NEW_BLOCKER**。v2已安装，standalone/冻结R1/M6B.0回归资格通过；新shock轨迹出现液体HARD下限共同压力无根阻塞。本轮遵守STOP，不修EOS域、R1或temporal。不标整个EOS2 COMPLETE。

## 2. Active EOS version

**ndecane_gibbs_v2**。实际factory调用、已安装库和solver、micro-case输出version tag均确认。不自动回退到v1，不声称active impact NONE。活动产物完整保存，v1备份独立保存。

## 3. v1 preservation

v1独立目录六份文件保留。原metadata.sha256核验metadata SHA；metadata内API/coefficients/energy_reference/Gibbs header四份原SHA全部PASS。原活动binary SHA ebb2a5e1f59a3431bea8795098b9a6c190b30b7cdd4dedc57cca9b78cdc05f87，两个原库均在runtime_before保留并与前序已加载库SHA相等。见 [v1_preservation.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/v1_preservation.json)。

## 4. Source delta

新增liquidEOS/ndecane_gibbs_v2/，仅相同潜能的符号/头文件路径命名与320→330K合法域改变。现有源码四项：liquidEOSFactory.C选v2及version；fiveEqLiquidThermoEvaluator.C合法压力区间的温度端点320→330；fiveEqP2IO.H仅EOS标签写入/版本匹配参数；runSerialFiveEq.C明确旧v1 fresh初始fixture读取并记录。没有改变P2数值编码、R1/KT/重构/Allaire/K=0/species/temporal/connectedDt/retry/Time。完整 [active_source.patch](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/active_source.patch)。

## 5. Factory/versioning and restart

makeProductionLiquidEOS构造GibbsPotentialLiquidEOSV2；productionLiquidEOSVersion返回ndecane_gibbs_v2。序列化继续fiveEqRestart-v1/P2-v1，EOS标签独立升级v2；默认读取v1 accepted restart报RESTART_METADATA_MISMATCH。原shock v1文件只在explicit fresh fixture路径读取，随后强制step=0/time=0/lastDt=0/old==current；17原始文件不变。离线版本门槛PASS，微型v2读写通过。**production restart NOT CERTIFIED**，没有进行生产restart。见 [restart_version_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/restart_version_gate.json)。

## 6. HARD/NORMAL domains

HARD p=0.05–12MPa、T=285–330K；NORMAL p=0.1–8MPa、T=295–305K。330.001K query正确拒绝。没有扩压域、350/400K重新选择、运行时无界外推或CoolProp链接。

## 7. Coefficients SHA

degree8×8的一份Gibbs potential、81系数及原导数实现。v2与v1 coefficients.json SHA均为 `610a90571a575ed3e1d3bd250e46868b36f98778de5213e359830290da192cac`。v2 C++ header经符号/包含路径规范化与冻结330K候选完全一致；无refit。

## 8. C_L

**369229.9537234281 J/kg**，binary64不变。e_solver=e_native+C_L、h_solver=h_native+C_L；v1 energy_reference.json原样复制，gas JANAF参考未改。

## 9. Standalone EOS regression

实际安装factory构造的v2执行**6222点**：3721旧域+2501扩展域。九性质rho/e/h/Cp/Cv/beta/c/dpDe/dpDrho逐点与离线HEOS比较，沿用NORMAL/BUFFER预算逐点选择，失败0。参考是CoolProp8.0.0 HEOS n-Decane参考EOS生成数据，不是实验测量；CoolProp未进入运行时。

## 10. Old-domain regression

3721点，全部九性质 directPT v1/v2逐位相等，mismatch=0、新非法=0。inverseT最大1.5347723092418164e-12K、inverseP最大3.6144629120826721e-06Pa，与EOS1资格范围一致。见 [native_eos_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/native_eos_gate.json)。

## 11. Extension regression

2501点p.05–12MPa、T320–330K全部通过冻结预算，稳定液相及正物性。实际native C++输出与HEOS比较；e/h relative使用native DEF参考（扣除不变C_L），SI绝对误差对应各性质单位。代理误差不代表实验不确定度。

| Property | max abs | RMS abs | max rel | RMS rel |
|---|---:|---:|---:|---:|
| rho | 1.40947918e-07 | 2.49275543e-08 | 1.98268925e-10 | 3.51429966e-11 |
| e | 0.000205572462 | 5.46059944e-05 | 6.71603702e-10 | 1.78677794e-10 |
| h | 0.00020401529 | 5.47080472e-05 | 7.05319628e-10 | 1.84468165e-10 |
| c | 0.000161374679 | 2.26338039e-05 | 1.35294075e-07 | 1.95637818e-08 |
| Cp | 7.73452675e-05 | 2.35225769e-05 | 3.35976578e-08 | 1.02117889e-08 |
| Cv | 0.000184886482 | 3.0678849e-05 | 9.70194091e-08 | 1.61533263e-08 |
| beta | 7.55747014e-10 | 1.04836538e-10 | 3.36144509e-07 | 4.58582133e-08 |
| dpDe | 0.000149511796 | 2.00804213e-05 | 3.36144396e-07 | 4.58582087e-08 |
| dpDrho | 0.38143056 | 0.0521925527 | 2.70098826e-07 | 3.91042537e-08 |

[EOS_accuracy_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/EOS_accuracy_gate.json)

## 12. 184 R1 result

**184/184恢复成功**，全部数值字段p/TG/TL/rhoG/rhoL/eL/betaL/cL/cA/residual/iterations与CAP1 shadow文本相等。最大184归一化残差1.0766039734535505e−15，小于冻结2e−12门槛。无P2、phase presence、tolerance或方程变更。

## 13. Accepted-state neutrality

**5500/5500合法**，新失败0，数值记录与CAP1 shadow相等。对冻结v1 maxΔp=3.0114315450191498e-06Pa、maxrelativeΔp=9.1993079820440471e-13、maxΔTG=7.5283423939254135e-10K、maxΔTL=3.922195901395753e-12K。见 [R1_regression_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/R1_regression_gate.json)。

## 14. Pure controls

pure gas +0、pure liquid −0各16，共32项PASS。纯气相无液体cL=0为不存在相标记；只对存在相要求cL>0，cA始终正finite。

## 15. Mixed controls

alphaL .1/.5/.9共48项PASS；p.1/3/8/12MPa×TL300/320/325/330K，TG800K，原速度/组分/能量构造保持。

## 16. Trace controls

traceL +1e−20、traceG −1e−20共32项PASS。112控制记录与CAP1逐文本相等；无删相、alpha floor或归一化。

## 17. Sound-speed result

| Matrix | cL (m/s), when present | cA (m/s) |
|---|---|---|
| rejected184 | 1170.00303534–1170.40802373 | 564.598379933–564.621513297 |
| frozen accepted neighbors300 | 1170.40802373–1300.28577725 | 558.656275147–1244.71810582 |
| controls112 | 1110.62575767–1299.63765845 | 558.656825165–1299.63765845 |

以上实际active回归输出与原shadow相同；所有存在相声速正finite。新shock accepted-state由未改R1/Allaire逐步检查，未产生accepted非法声速。

## 18. M6B.0 full rerun

实际安装active v2、相同binary，gas/liquid/mixed01/mixed05/mixed09/traceLiquid/traceGas/contact/speciesContact/smooth十个原输入/原网格完整重跑，全部exit0/no timeout。未重生成网格或初始条件。326检查PASS，包含原316物理/authority门槛及额外对比；历史no-warning条件按本轮zero unexpected warning要求映射，3条冻结SR1 diagnostic indentation警告显式记录，不伪称总warning=0。见 [M6B0_rerun_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/M6B0_rerun_gate.json)。

## 19. M6B.0 deltas

| Case | Steps | max p rel | max conservation scaled | R1 calls | R1 calls delta | failures |
|---|---:|---:|---:|---:|---:|---:|
| gas | 10 | 4.4408921e-16 | 0 | 14460 | 0 | 0 |
| liquid | 10 | 1.7286172e-13 | 0 | 14460 | 0 | 0 |
| mixed01 | 10 | 3.9968029e-15 | 0 | 14460 | 0 | 0 |
| mixed05 | 10 | 3.7525538e-14 | 0 | 14460 | 0 | 0 |
| mixed09 | 10 | 1.8600677e-12 | 0 | 14460 | 0 | 0 |
| traceLiquid | 10 | 2.220446e-16 | 0 | 14460 | 0 | 0 |
| traceGas | 10 | 8.4598994e-14 | 0 | 14460 | 0 | 0 |
| contact | 10 | 2.1560531e-13 | 1.5137124e-16 | 14460 | 0 | 0 |
| speciesContact | 10 | 8.2156504e-15 | 3.9626576e-17 | 14460 | 0 | 0 |
| smooth | 20 | 9.15934e-14 | 8.9869627e-17 | 28860 | 0 | 0 |

均匀守恒/primitive drift=0、trace/P2位保持；contact/species/smooth p误差远低于原1e−8门槛。species closure均<1e−12；smooth解析输运误差相对原结果未增加到1e−12以上。完整component/R1/query/iteration差异逐项记录于M6B0_rerun_gate.json；不声称每个原生计数必须完全相同。

## 20. Shock exact replay

安装active v2运行原shockInterface_100：17输入逐文件SHA不变，mesh/IC/CFL/endTime/dt/retry保持。外部进程观察程序发现已发表step119时间重复后SIGTERM自身子进程，exit−15（shell等效143），5.65s；不是timeout/正常完成。它不写入solver time/dt/state。冻结SR1/CAP1只读诊断companion单独重放，driver本地accept119后既有诊断异常exit1；active与companion published0–118完整dynamic_history及13快照逐字节相等。诊断既有nextafter仅度量ULP，不在active添加guard/forced progress。

## 21. Old anchor105 result

原captured anchor105/cell24候选在active v2：p=3273273.8951882557Pa、TL=320.04723502284918K、iterations=5、normalized residual=1.0766039734535505e-15。动态v2 anchor105无拒绝，step106直接接受原首试dt=1.2050921343033288e−6，旧320K阻塞消失。新trajectory cell24不是逐位相同的旧候选，早期roundoff状态已存在差异，不把offline原候选与新动态状态混为一项。见 [old_anchor105_v2_recovery.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/old_anchor105_v2_recovery.json)。

## 22. Old 184-site behavior

全部184冻结原候选active恢复成功；动态重放未出现旧TL=320上限原因。新路径在anchor114/cell45产生不同下限阻塞；旧轨迹后续anchor132/137不再对应当前119即停的路径，因此不把未走到的动态站点标作现场PASS。旧184证书是完整离线逐状态证据。

## 23. First v1/v2 divergence

time/dt/retry序列首个分歧：**accepted106**。v1时间0.00012745457792667531、dt9.1990382482555322e−7、retry1；v2时间0.00012773976623615309、dt1.2050921343033288e−6、retry0。首次accepted conservative/P2位差异为step64（旧域合法root的小舍入差）；不能声称Q轨迹前105全部位同。v1/v2 time序列前105相等。

## 24. Rejection statistics

**4 main +126 connected probes**，全部NO_PHYSICAL_ENERGY_ROOT_IN_VALID_DOMAIN，分类EOS root/domain。main anchors114/115/117/118、cell45；positivity/P2/species/nonfinite/other类别均0。每事件完整reason/cell/dt及候选Q/P2已捕获，first candidate、committed100 cells/面/重构状态独立保留。见 [v2_rejection_classification.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/v2_rejection_classification.csv)。

## 25. dt history

生成 [v1_vs_v2_dt_history.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/v1_vs_v2_dt_history.csv)，含step/time/requested dt/first trial/retries/connectedDt/accepted dt/reason。v2首个114拒绝→accepted115 dt2.4645706092801419e−7；accepted116 dt1.0087086223088674e−18；accepted118 dt5.9437208028051639e−20；accepted119 dt8.6140881200075052e−22。无growth/reseed/reset。

## 26. Time-progress behavior

step119 tOld=time=**0.00013762696037150982 s**，accepted dt=8.6140881200075052e−22 s，ULP=2.7105054312137611e−20 s，dt/ULP=.03178037579563206。fresh joint/acoustic bound仍1.205092136652026e−6 s。原inherited accepted dt及connectedDt在下限root阻塞附近再次缩至不可表示进展。没有time floor、growth、nextafter forced step或active guard。

## 27. Remaining blocker

**EOS2_NEW_BLOCKER：新液体285K HARD下端共同root阻塞 + 冻结时间策略停滞**。首笔anchor114、cell45、dt1.2050921343033288e−6，alphaL2.152515651152602e−15、mL1.5911360398631835e−12kg/m³、rhoL=739.19836030515364kg/m³、Eint=4348018.6178385196J/m³。共同合法p区间[3419191.1230748333,12000000]Pa；TL_lo=285K，fLo=381082.59926334675>0、fHi=28763051.280841887>0，iterations0。单调原R1域内不能括根。gas-only diagnostic pressure3.286242793MPa不是可提交的共同root，不用它替代液态查询。

新状态是否仍有域外真实液态root或物理模型不可容纳，**未独立参考认证，保持UNRESOLVED**。不得直接扩低温或称纯temporal defect已隔离。此结果不符合OUTCOME A；也不是“EOS failures全部消失”的纯B，且C原定义是non-EOS blocker，本次仍是新的EOS-domain原因，如实另列EOS2_NEW_BLOCKER，不硬套C。见 [first_v2_rejection.query.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/integration/m6b1_eos2_ndecane_v1/first_v2_rejection.query.json)。

## 28. TD1 still required

**YES**，独立缺口仍为accepted-dt继承、无合法growth政策、无可表示进展保护。TD1本轮NOT AUTHORIZED/NOT EXECUTED。当前尚有新的EOS lower-domain阻塞，不能用时间修补绕过；未来先独立分类新状态，再决定EOS2关闭与TD1顺序。

## 29. Foundation hashes

新核验6717 Foundation源码/Make、19 native parcel文件全部PASS。8个gas/patch源码重新读取并保存SHA。55 loaded libraries中53不变，仅授权libRhosprayLiquidEOS.so和libRhosprayFiveEqThermo.so变化，两个旧库已保存。active binary SHA：`99053c2f1837e3e524b2385a2004d8649d7fc0430a762dfd5cd5bddb01bf9a3d`，运行前后同SHA。没有改FOAM_SRC。

## 30. Project hashes

35271此前保护文件核验，4项授权source binding变化及1项generated clean-build object变化，无其他变化；v1文件由原metadata/seal另行完整核验。80当前编译项目source/Make依赖及快照保存；metadata状态从pending更新为部分停止，最终v2 source SHA单独列明。根temporal/PrecisionOperator/R1/KT/重构/species/原方程及T4/DPM旧证据保持原SHA；只新增本轮报告、stage并追加milestone历史。

## 31. Production impact

**Production INPUT impact NONE**：300/300_2D/原rhosprayFoam132文件不变；mesh/BC/injection未改。**Active impact EXISTS**：已切换factory/合法域/版本绑定，并安装新binary和两个EOS相关库。未运行production CFD/MPI/restart、未激活DPM、未进入T4-S3或M6B.2。

## 32. Whether EOS2 COMPLETE

**NO — PARTIAL / STOP**。已完成安装和回归部分；原320K失效修复有完整证据。由于新动态EOS下限阻塞，按用户EOS2_NEW_BLOCKER停止，不能把本轮标为整体完成或默认下一轮只需TD1。active v2仍保留，范围仅按已经通过的回归证书描述。

## 33. Next permitted action

当前仅封存/报告并STOP。建议下轮另行授权新的cell45/285K域下限root独立参考分类和design-envelope审计；不先扩域或调时间。EOS2关闭后TD1仍需独立数学设计/认证。本轮未执行这些下一步。

## 34. M6B.1 status

**PARTIAL / STOP**。shock未到endTime .00055s；新停点 .00013762696037150982s。不能升级shock稳定、全wave ladder/RH/Galilean/high-Mach或多维/生产认证。

## 35. Milestone matrix

| Milestone | Status |
|---|---|
| M6B.0 | COMPLETE / FROZEN；本轮active v2十例rerun PASS |
| M6B.1-SR1 | COMPLETE / FROZEN / DIAGNOSIS ONLY |
| M6B.1-EOS1 / CAP1 | COMPLETE / FROZEN / DESIGN QUALIFIED for old184 |
| ndecane_gibbs_v1 | HISTORICAL / PRESERVED |
| ndecane_gibbs_v2 | ACTIVE / standalone & frozen R1 regression QUALIFIED |
| M6B.1-EOS2 | PARTIAL / STOP / NEW LOWER-DOMAIN BLOCKER |
| M6B.1 / M6B | PARTIAL / STOP |
| TD1 | REQUIRED / NOT AUTHORIZED / NOT EXECUTED |
| M6B.2 | NOT AUTHORIZED / NOT EXECUTED |
| T4-S1/S2 | COMPLETE / FROZEN |
| T4-S3 | DEFERRED |
| T4 / M8A | PARTIAL |
| active DPM / production CFD | NO |
| production restart | NOT CERTIFIED |

**STOP。**
