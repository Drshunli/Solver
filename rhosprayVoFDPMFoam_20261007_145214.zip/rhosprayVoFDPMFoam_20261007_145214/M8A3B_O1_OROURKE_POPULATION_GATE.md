# M8A.3B-O1 ORourke complete-event audit

Date2026-10-02. Final evidence: fitting/dpm/m8a3b_o1_v1.

## 1. O1 status

**COMPLETE / NATIVE CONSERVATION BLOCKER.** Final classification B. Conservation does not pass; the classification gate is complete. No conservation repair is implemented.

## 2. Native ORourke caller graph

Actual local Foundation7 source was recopied this turn. `SprayCloud::evolve()` (SprayCloud.C:218–225) → `KinematicCloud::solve()` (KinematicCloud.C:92–135) → `preEvolve()` → `evolveCloud()` (180–224): reset sources when coupled, surfaceFilm inject, injectors.inject, **cloud.motion**, then **stochasticCollision().update(td, solution_.trackTime())** at line212 → `StochasticCollisionModel::update()` active guard (C:79–89) → virtual `ORourkeCollision<KinematicCloudType>::collide()` → collideParcels → collideSorted → update positive participant rho/Cp/sigma/mu/d → cleanup sweep. After evolveCloud, scaleSources when coupled, info, postEvolve. Tests enter cloud.evolve, not update, for ordinary proof.

## 3. Cleanup entry function

`ORourkeCollision<CloudType>::collide(trackingData&, scalar dt)`, actual ORourkeCollision.C:108–119. The sweep is inline inside collide, not a distinct cleanup API. Predicate: `p.nParticle()*p.mass() < owner.constProps().minParcelMass()`; effect: owner.deleteParticle(p). No native rhoTrans, UTrans, hsTrans update or residual reservoir.

## 4. Cleanup callers

Direct caller is the end of ORourke::collide, reached by active StochasticCollisionModel::update from transient KinematicCloud::evolveCloud after motion. Every active transient collision update reaches the sweep even with no pairs. The ordinary pre-motion ReactingParcel threshold path is separate; it cannot protect remnants newly produced by post-motion coalescence.

## 5. Delete-condition taxonomy

| Category | Actual OF7 branch |
|---|---|
| Coalescence bookkeeping | No separate unconditional coalescence delete; only the common represented-mass threshold. Positive remainder is not already transferred. |
| Zero/negative multiplicity | No dedicated predicate. With positive droplet mass, zero/negative nParticle falls under common mass threshold. |
| Minimum mass | Sole ORourke delete predicate; strict <, equality retained. Default dictionary-backed threshold1e-15kg in KinematicParcelI.H:68. |
| Invalid parcel | No independent ORourke invalid-state delete or validation. NaN comparison does not satisfy <; do not claim such cleanup. |
| Other ORourke branch | None found. Grazing mutates U but returns massChanged=false. |
| ReactingParcel minimum mass | Separate calc path C:492–515, keepParticle=false, coupled mapped species/hs/momentum absorption. This is DPM_CARRIER_TRANSFER, not ORourke semantics. |

## 6. Current production reachability

**REACHABLE_NORMAL_PATH** for this active transient ORourke/coalescence configuration. All 12 roleA/B dictionaries in original/branch fixtures are byte-identical to 300_2D/constant/sprayCloudProperties (SHA256 ae45431edeb410929227087fd7a3c1dc3f7318dc8ff4a77cbb085e16f8ce406c). Native defaults retain minParcelMass1e-15kg. Analytical proof: for initial b>=threshold, coalescence leaves r=(1-f)b, 0<=f<1; any f>1-threshold/b leaves a positive sub-threshold remnant. Coalescence yes and nonzero relative speed allow this event on the ordinary path. Three complete ordinary tests realize it. Unaltered-mesh observations alone do not certify impossibility. Geometry/timestep/seed distribution are BRANCH-REACHABILITY TEST ONLY: final cell20µm cube, precursor core/drop history KHindex1, d1µm/50nm, masses1e-12/1.05e-15kg, TL300K, dt1e-8s. Seeded volume fraction≈0.173. No injected production size/frequency or CFD application conclusion is inferred.

## 7. Represented parcel-mass definition

KinematicParcelI.H:343–360: mass()=rho*volume(), volume()=pi*d^3/6, both refer to a single droplet. Physical computational-parcel mass is **nParticle()*mass()**. Multiplicity may be fractional. Every population and pair mass uses both factors; native serialization is also preserved.

## 8. Represented species-mass definition

M_i=sum_parcels[nParticle*mass()*Y_local], mapped using actual composition.localToCarrierId(0,localId). Diagnostics allocate the species vector from runtime rhoTrans.size(); no normalization or guessed species source. Current carrier ordering C10H22/O2/N2; liquidY=[1], so all parcel mass maps to fuel and zero to the other species.

## 9. Original 5e-16 case

Relabelled **CLEANUP_ENTRY_BEHAVIOR**. Previous A/B/C evidence copied verbatim to original_cleanup_entry_evidence; original files remain unchanged. New replay preserves all native parcel fields in results/entry/{A,B,C}/native_parcel_states.txt before/preCleanup/after. A deleted ID0:106: nParticle4.8768347711933546e-8, dropletMass1.0252551572044561e-8kg, represented5.0000000000000004e-16kg, rho725.21967199798883kg/m³, TL300K,d0.3mm,U(47,0,0),Y=[1]. No earlier coalescence participant or receiving survivor exists in this test. It is not an ordinary timestep proof.

## 10. Event lineage

Final A: seed IDs0:106/0:107 are explicitly inserted above minParcelMass after five normal history steps (106 parcels). 24 ordinary evolve steps execute native injection/motion before event24/pair139368. The last modifying collision is that pair; ID0:107 falls to 2.398778791772198E-16kg, ID0:106 survives. Its mass gain is b-r, not b. Cleanup then deletes the residual r. B/C lineage uses the same origProc/origId and per-update pair IDs in JSONL; final cleanup occurs at update26/48. Source matrices are sampled at collision begin/end, excluding preceding drag/injection contributions.

## 11. Participants before event

| ID | nParticle | droplet mass kg | represented mass kg | d m | T K | U m/s | Y |
|---|---:|---:|---:|---:|---:|---|---|
| 0:106 | 2633.4907764444097 | 3.7972413229794455E-16 | 9.9999999999999372E-13 | 9.9999999999999805E-7 | 300 | [Decimal('-40.963036163453033'), 0, 0] | [1] |
| 0:107 | 26238.100986512658 | 4.0018140052884823E-20 | 1.0499999999999989E-15 | 4.7234889147379683E-8 | 300 | [Decimal('29.976523222669918'), Decimal('1.0099748659810805E-18'), 0] | [1] |

## 12. Participants after event

After coalescence, before cleanup:

| ID | nParticle | droplet mass kg | represented mass kg | d m | T K | U m/s | Y |
|---|---:|---:|---:|---:|---:|---|---|
| 0:106 | 2633.4907764444097 | 3.8003175521732912E-16 | 1.0008101221208158E-12 | 0.0000010002699678177576 | 300.00000000000006 | [Decimal('-40.957492702870638'), Decimal('1.8677135494272381E-22'), 0] | [1] |
| 0:107 | 5994.2285888403658 | 4.0018140052884805E-20 | 2.398778791772198E-16 | 4.7234889147379676E-8 | 300 | [Decimal('29.976523222669918'), Decimal('1.0099748659810805E-18'), 0] | [1] |

After cleanup only the survivor ID0:106 remains. Whole-cloud native snapshots include every other parcel; no hidden participant gain is omitted.

## 13. Deleted parcel state

| ID | nParticle | droplet mass kg | represented mass kg | d m | T K | U m/s | Y |
|---|---:|---:|---:|---:|---:|---|---|
| 0:107 | 5994.2285888403658 | 4.0018140052884805E-20 | 2.398778791772198E-16 | 4.7234889147379676E-8 | 300 | [Decimal('29.976523222669918'), Decimal('1.0099748659810805E-18'), 0] | [1] |

Delete reason: representedMassLessThanMinParcelMass; positivity is recorded, never waived by small mass.

## 14. Survivor state

Before/after matched by stable native ID:

| ID | nParticle | droplet mass kg | represented mass kg | d m | T K | U m/s | Y |
|---|---:|---:|---:|---:|---:|---|---|
| 0:106 | 2633.4907764444097 | 3.7972413229794455E-16 | 9.9999999999999372E-13 | 9.9999999999999805E-7 | 300 | [Decimal('-40.963036163453033'), 0, 0] | [1] |
| 0:106 | 2633.4907764444097 | 3.8003175521732912E-16 | 1.0008101221208158E-12 | 0.0000010002699678177576 | 300.00000000000006 | [Decimal('-40.957492702870638'), Decimal('1.8677135494272381E-22'), 0] | [1] |

Survivor gain=8.1012212082208E-16kg; donor initial mass is larger. The residual is still physically represented before deletion.

## 15. Population mass before

| Seed | before kg | pre-cleanup kg | after kg | deleted kg | Rm kg |
|---|---:|---:|---:|---:|---:|
| A | 2.75866813888626662508E-9 | 2.75866813888626662427E-9 | 2.75866789900838744713E-9 | 2.398778791772198E-16 | -2.3987787917795E-16 |
| B | 3.82173827609806101293E-9 | 3.82173827609806101293E-9 | 3.82173746956367155949E-9 | 8.06534389453008E-16 | -8.0653438945344E-16 |
| C | 4.99006288252799100783E-9 | 4.99006288252799100823E-9 | 4.99006265361565666804E-9 | 2.2891233433999418E-16 | -2.2891233433979E-16 |

Totals are over **all parcels at collision entry after motion**, not all-timestep before injection. A affected pair before=1.0010499999999937189E-12kg.

## 16. Population mass after

A full population after=2.75866789900838744713E-9kg; affected survivor=1.0008101221208158E-12kg. All post-collision pair updates and cleanup complete before measurement. Full-cloud and pair-ledger residuals agree within unchanged endpoint arithmetic scaling.

## 17. Native carrier mass transfer

**ΔMcarrier=0** and every ΔrhoTrans_i=0 across each collision update. Previously accumulated drag momentum in native matrices may be nonzero at entry; subtracting before from after gives collision-only native ΔUTrans=0 and ΔhsTrans=0. No receiving parcel/reservoir stores the discarded positive residual.

## 18. Mass residual

Rm=(MDPM_after−MDPM_before)+ΔMcarrier−Mexternal, Mexternal=0 for collision. A=-2.3987787917795E-16kg; B=-8.0653438945344E-16kg; C=-2.2891233433979E-16kg. Negative in all three. The positive lost masses are **not** arithmetic exemptions. Pair-local residual=-r independently excludes masking by historical cloud mass.

## 19. Species before/after

A fuel mass [Decimal('2.75866813888626662508E-9'), 0, 0] → [Decimal('2.75866789900838744713E-9'), 0, 0]kg. Runtime-mapped species endpoints retained for every event and whole cloud; O2/N2 parcel masses remain zero.

## 20. Species residual

RY_i=ΔMDPM_i+ΔMcarrier_i. A=[Decimal('-2.3987787917795E-16'), 0, 0]kg; B=[Decimal('-8.0653438945344E-16'), 0, 0]kg; C=[Decimal('-2.2891233433979E-16'), 0, 0]kg. Fuel residual equals Rm; no source patch or normalization.

## 21. Momentum before/after

A PDPM_before=[Decimal('8.93444091566334270708E-10'), Decimal('1.47165775297537029273E-7'), 0]; preCleanup=[Decimal('8.93392169811496616426E-10'), Decimal('1.47165775297537029273E-7'), 0]; after=[Decimal('8.93384979106680855675E-10'), Decimal('1.47165775297537029273E-7'), 0]kg·m/s. Complete collision scope excludes the motion forces that preceded it; ΔPcarrier=0 across collision.

## 22. Momentum-model semantics

Actual sorted coalescence stores U1/U2 references, sets a_new=a_old+dm, r=b_old−dm, dm=f*b_old; then U1_new=(a_new*U1_old+f*r*U2_old)/a_new, leaves donorU unchanged and reduces donor multiplicity. This differs from conservative U1_new=(a_old*U1_old+dm*U2_old)/a_new. Before cleanup ΔP=dm*(U1_old−f*U2_old); deleting r subtracts r*U2_old. The source comment claims conservation, but the implemented expression and measured result do not close momentum. Grazing gf mixes subset velocities and generally dissipates relative KE; it does not create carrier sources. No coefficient/formula is modified.

## 23. Momentum residual

RP=PDPM_after−PDPM_before+ΔPcarrier−Iexternal. Iexternal=0 inside collision; any earlier wall/drag impulse precedes the event snapshot. A=[Decimal('-5.911245965341503300E-14'), Decimal('0E-32'), 0]kg·m/s; B=[Decimal('-3.910295364233189000E-14'), Decimal('0E-32'), 0]; C=[Decimal('-1.693606686977553000E-14'), Decimal('0E-32'), 0]. The native velocity formula is independently evaluated against each observed surviving U, with only frozen floating arithmetic tolerance.

## 24. Energy before/after

A raw-liquid caloric H: -0.00581157203742275583634→-0.00581157153208195192613J; raw internal E=H−pV: -0.00582298375822434199533→-0.00582298325189124062641J; translational KE: 0.00000392793574878666038311→0.00000392793572946077245481J. Diagnostics use native composition.H at each parcel p/T/Y; this is not carrier JANAF sensible energy or an activation of the frozen evaporation ledger. Full numeric tables for A/B/C are population_ledgers.json.

## 25. Collision energy semantics

Coalescence sets T1=(Tave*(a+b)−r*T2)/(a+dm), mixes Y by mass, updates native liquid rho/Cp/sigma/mu and d. It does not explicitly add KE loss/gain to thermal energy, track surface energy, or update hsTrans. At equal300K, thermal/caloric sum before cleanup is unchanged up to arithmetic; the residual carries its H/E/KE away when deleted. Grazing collision relative-velocity damping is MODELLED_DISSIPATION of resolved translational KE; no native carrierheat destination exists. No grazing branch was needed for the decisive final coalescence cases.

## 26. Energy classification

For the actual decisive coalescence/cleanup events: **UNACCOUNTED_ENERGY**, not an evaporation exchange. A coalescence ΔKE=8.845027702038E-14J (positive); cleanup ΔKE=-1.0777616494868E-13J. B/C coalescence KE can decrease, still no native caloric/surface reservoir closes it. Raw H/E zero includes a negative reference; deleting negative caloric energy can increase the recorded total. Therefore no sign alone is interpreted as carrier heat. Collision thermal and kinetic records remain separate; no gas Et or Eulerian C_L correction.

## 27. Ordinary coalescence result

PASS as observed native reachability; not a conservation PASS. Final A/B each one, C two coalescences. All affected pair states logged before mutation and after native property reconstruction. Mass redistribution **before** cleanup closes; this validates the event scope and shows the survivor already accounts for b-r only.

## 28. Ordinary cleanup result

Final A/B/C each have one positive-mass native deletion **after** ordinary evolve→motion→coalescence. Both initial participants exceed minParcelMass at the decisive pair entry. No direct cleanup/update call is used for the proof. Removing the instrumentation hooks recovers the actual native collide body; native pair probabilities and RNG kernels are called unchanged. Independently evolving the same initial cloud through uninstrumented ORourke gives exact aggregate serialized state/native source and finite RNG-future probe equality. This is not a complete RNG transaction codec.

## 29. Production-config event counts

| Mode / seed | updates | pair attempts | collisions | coalescence | cleanup deletions | positive deletions |
|---|---:|---:|---:|---:|---:|---:|
| production/A | 20 | 1225003 | 0 | 0 | 0 | 0 |
| production/B | 20 | 1520955 | 0 | 0 | 0 | 0 |
| production/C | 20 | 1853730 | 0 | 0 | 0 | 0 |
| branch/A | 24 | 139368 | 1 | 1 | 1 | 1 |
| branch/B | 26 | 294211 | 1 | 1 | 1 | 1 |
| branch/C | 48 | 914604 | 2 | 2 | 1 | 1 |
| entry/A | 1 | 5565 | 0 | 0 | 1 | 1 |
| entry/B | 1 | 10878 | 0 | 0 | 1 | 1 |
| entry/C | 1 | 17955 | 0 | 0 | 1 | 1 |

Production rows use unchanged original8-cell fixture geometry and no inserted parcels. Branch rows use the same byte-identical production dictionaries, with labelled test-only geometry/time/initial population. Entry rows are isolated behavior only. All observed counts are finite test counts, never production event-frequency estimates. Initial overly small-cell and aborted expensive serialization attempts are retained but superseded by final20µm-cell evidence.

## 30. Whether positive-mass cleanup is normally reachable

**Yes, the ordinary caller path allows and realizes it with the current collision configuration.** On the unaltered large-cell fixture, 60 normal updates and the reported pair attempts yielded zero collisions/deletions; that is non-observation, not static unreachability. No probability, active flag, coalescence coefficient or threshold was altered. No CFD production occurrence claim is made.

## 31. Final classification A/B/C/D

**B — NATIVE_OROURKE_POSITIVE_MASS_TRUNCATION.** Internal coalescence transfers b-r and conserves represented mass until cleanup. Cleanup discards r>0, with no receiving parcel/nativecarrier/reservoir. Thus A is not the complete-event classification; C is contradicted by source and ordinary-path tests; D is resolved by complete population records. STOP: no conservative-cleanup design or implementation this turn.

## 32. Whether current ledger checker was false-positive

A disappearance-only DPM→gas check cannot prove production loss and would incorrectly classify an otherwise conservative internal merge. The previous isolated assertion is therefore re-scoped to CLEANUP_ENTRY_BEHAVIOR, not retroactively treated as a complete ordinary event. This new **population ledger independently confirms a real native truncation**, so the O1 blocker is not removed by correcting scope. Frozen carrier-transfer adapter remains correct for actual carrier exchange; it is not invoked to force internal collision into gas.

## 33. Ledger checker changes

Added a separate offline/passive four-level population audit: individual parcel observations; all affected pair/mutation/deletion endpoints; complete cloud safeguard; DPM+carrier increments. Existing EventLedgerV1 and frozen adapter are unchanged. ClassA-specific production/checker API migration is not performed because final classification is B. Added numeric checks confirm pre-cleanup transfer, leftover deletion, lineage, dynamic species map and native momentum algebra.

## 34. Source-adapter changes

**NONE.** No dmG/dmYi/dM/dEt, pressure work, JANAF energy mapping, P2/recovery or existing deletion adapter is modified. No source is fabricated from disappearance; no mL source, C_L repair or mass clipping.

## 35. Frozen source/energy regression

PASS: 9288 source/energy,6375 rebinding,1725880 native interpolation (max error3.84593e-16; all-gas21000/21000),64395 T3A,105775 critical P2/recovery/R1,9663 temporal/restart. All eight energy golden CSVs are byte-identical to frozen prior evidence. Sub-ULP1000steps/scheme preserved. New native harness349checks plus offline population36checks, zero assertion failures. Assertions confirm the diagnosed conservation blocker, not a physical conservation PASS.

## 36. Transaction rollback spot-check

ClassA optional merge rollback is not applicable. No further T3B transaction matrix is executed. Each diagnostic role is independently reconstructed from committed state and destroyed after observing events; before/after committed cloud/carrier/generation sentinels remain exact, allocator/time restored. Frozen T3A begin/discard regressions replay unchanged. No accepted event commit or complete transaction-state codec is claimed.

## 37. Active solver impact

**NONE.** SHA256 audit verifies active files against T1 frozen active manifest, every pre-existing file against O1 pre-change snapshot except the permitted appended milestone document, and actual300_2D all96files unchanged. No $FOAM_SRC edits. New independent test wmake PASS; no solver/CFD/blockMesh/checkMesh execution.

## 38. Remaining blocker

Positive represented-mass truncation in native ORourke cleanup; additional actual coalescence momentum and unaccounted-energy discrepancies recorded. A later independently authorized conservation-policy design must review native semantics before any repair. This turn does not choose preserve/merge/reservoir or automatic gas absorption. Full codec, accepted-event retry, persistent output and production coupling gates also remain pending.

## 39. Whether O1 COMPLETE

**YES: classification gate COMPLETE / NATIVE CONSERVATION BLOCKER.** Caller audit, actual config, represented mass/species, originalcase lineage, all participants/survivor, wholepopulation mass/species, collision momentum/energy semantics, native source deltas, ordinary-path reachability, classificationB, no exemptions/fake sources, frozen/active byte audit and noCFD are documented. Completion does not mean conservation passed.

## 40. Whether T3B may resume NEXT ROUND ONLY

**NO automatic resume.** ClassificationB keeps T3B blocked. Next independent stage must be authorized as native conservation-policy review/design. No coneInjection/KH/rebound/output/combined-event T3B matrix is resumed this turn.

## 41. T3 status

PARTIAL / BLOCKED; T3A remains COMPLETE, full serial coupled event gate is not complete.

## 42. T4 permission

NO.

## 43. M8A status

PARTIAL; frozen source/energy PASS remains intact, production coupling activation not granted.

## 44. M6B.0 permission

NO.

## 45. M6B.1 permission

NO.

## 46. Updated milestone matrix

| Milestone | Status | Scope |
|---|---|---|
| M8A source/energy | PASS / FROZEN | unchanged |
| M8A.3A | COMPLETE | evolved-cloud independence |
| T1 | COMPLETE / DESIGN ONLY | unchanged |
| T2 | COMPLETE / STRICT-SUPPORT FEASIBLE | unchanged |
| T3A | COMPLETE | passive carrier publication |
| O1 | COMPLETE / NATIVE CONSERVATION BLOCKER | classification B; ordinary event proof |
| T3B | PARTIAL / BLOCKED | native cleanup truncation, coalescence momentum/energy discrepancies |
| T3 | PARTIAL | full codec/event/retry/output closure pending |
| T4 | NO | not authorized |
| M8A | PARTIAL | production coupling not activated |
| M6B.0 / M6B.1 | NO / NO | not authorized |

**STOP. No T3B continuation, no T4, no M6B, no CFD.**
