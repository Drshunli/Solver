# Field ownership — active gas KT and future five-equation state (OF7)

The sole future architecture is density-based KT with an isobaric,
common-velocity two-material five-equation model. Current M0–M4 equations
remain the only active flow equations. `rhosprayVoFFoam` and other
experimental directories are separate work.

## Current active and diagnostic fields

| Field | Current creator/writer | Current meaning and readers |
|---|---|---|
| `p` | Gas `psiReactionThermo`; `rhoEEqn.H` assigns `rho/psi` | Legacy gas pressure for KT flux, thermo and cloud; future common pressure must be recovered from two-material state, not this assignment |
| `T`, `e`, `psi` | Gas `psiReactionThermo`; `e` recovered in `rhoEEqn.H`, followed by `thermo.correct()` | Gas-only temperature, sensible internal energy and compressibility |
| `rho` | `createFields.H` from `thermo.rho()`; `rhoEqn.H` interior, `rhoEEqn.H` boundary | Sole solved legacy **gas** density, not mixture density |
| `rhoG` | `createFields.H`: `const volScalarField& rhoG=rho` | Transitional read-only gas-density view; same object, no second equation. `rhosprayVoFMixture` and spray cloud receive it |
| `U` | `createFields.H`; `rhoUEqn.H` | Current legacy carrier velocity; future one common velocity of both materials |
| `rhoU` | `createFields.H`; `rhoUEqn.H` | Legacy gas KT conservative momentum, not future mixture `M` |
| `rhoE` | `createFields.H`; `rhoEEqn.H` | Legacy gas KT total energy, not future mixture `Et` |
| `phi` | `createFields.H`; main `.C` KT face reconstruction | Active gas mass flux; `rhoEqn.H`, species and turbulence read it |
| `phiUp`, `phiEp` | Main `.C` directed KT reconstruction | Active gas momentum and total-energy face fluxes |
| `phiV` | `createFields.H`; main `.C` KT volume-speed sum | Provisional VOF volume flux; drives MULES, not the future phase-mass KT flux family |
| `alphaL` | `createFields.H`; `alphaEqn.H` MULES | Resolved liquid volume fraction; current interface transport is provisional for five-equation conservation |
| `alphaG` | `createFields.H`; alpha headers set `1-alphaL` | Resolved gas volume fraction, no independent equation; excludes parcel volume |
| `alphaPhi` | `createFields.H` storage; `alphaEqn.H` limited flux; `alphaSubCycle.H` average | Provisional liquid volume flux including compression/limiter, not yet proven compatible with future `F_mG/F_mL/F_E` |
| `rhoL` | `rhosprayVoFMixture::correct()` queries `SLGThermo.liquids().rho(pGas,TGas,X)` | **Diagnostic** liquid property estimate only; gas `T` is a query coordinate, not future `TL` |
| `rhoMix` | `rhosprayVoFMixture::correct()` | Diagnostic `alphaL*rhoL+alphaG*rhoG`; never assigned to active `rho` |
| `muL/CpL/kappaL` | M4 liquid database query at gas `p,T` | Diagnostic intrinsic-liquid property estimates only |
| `muMix/CpMix/kappaMix` | `rhosprayVoFMixture::correct()` | Diagnostic mixtures; not active transport coefficients |
| `sigma`, `K`, `vofSurfaceTensionForce` | OF7 `interfaceProperties` and M3 output | Interface geometry/CSF diagnostic; no current momentum source |
| DPM mass/species/momentum/energy sources | OF7 `basicSprayCloud` transfer storage after `parcels.evolve()` | Existing `Srho/SYi/SU/Sh` placement unchanged. Cloud carrier density now receives `rhoG` view, which is the same legacy object |

There is no mandatory `constant/vofLiquidReference`, `rhoL0`, fixed `TL0`,
`p_rgh` or pressure-correction flow core. The M4 liquid property estimate is
not an EOS and cannot recover liquid pressure or sound speed from conserved
energy. `rhosprayLiquidThermo` remains a compiled, **uninstantiated EOS
candidate**, not an accepted model.

## Future five-equation ownership (not runtime fields)

| State/primitive | Future owner and definition |
|---|---|
| `alphaL`, `alphaG` | Material field and algebraic complement; nonconservative alpha closure must be consistent with phase-mass fluxes |
| `mG`, `mL` | Conserved gas and liquid partial densities: `mG=alphaG*rhoG`, `mL=alphaL*rhoL` |
| `rhoMix` | Derived authoritative mixture density `mG+mL`; no independent third mass equation |
| `M` | Conserved common momentum `rhoMix*U` |
| `Et` | Conserved mixture total energy `mG*eG+mL*eL+0.5*rhoMix*|U|²` after energy-reference alignment |
| `rhoG`, `rhoL` | Intrinsic densities recovered from partial masses and fractions with pure-phase regularization; current `rhoG` alias and M4 `rhoL` diagnostic are transitional only |
| `p` | Common pressure recovered from the conserved state and phase EOSs; no `p_rgh` pressure equation |
| `TG`, `TL` | Separate phase temperatures; mechanical equilibrium does not imply equal temperature |
| `cG`, `cL`, `cMix` | Phase and mixture acoustic speeds after liquid EOS selection and common-pressure closure |
| Gas `Yi` | Gas composition only; future conserved species quantity is `mG*Yi`, not `rhoMix*Yi` |
| DPM carrier | Intrinsic gas `rhoG`, common `U`, gas thermo and species; source restructuring belongs to M8 |

The future conservative vector is
`Qc=[mG,mL,Mx,My,Mz,Et]`, plus nonconservative/material `alphaL`.
`twoPhaseKTState.H` is the active **design contract** for these names but
creates no mesh field and changes no runtime equation. `m5aFluxDiagnostics.H`
is an active reference diagnostic file, not currently included by the solver.
