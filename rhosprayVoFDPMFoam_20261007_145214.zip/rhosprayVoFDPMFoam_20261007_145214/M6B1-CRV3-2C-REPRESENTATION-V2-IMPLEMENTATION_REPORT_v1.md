# M6B1-CRV3-2C REPRESENTATION-V2 IMPLEMENTATION REPORT v1

进行中快照：迁移硬阻塞已复现，合同决策与真实入口补充全程验证待闭合。

## 1. status

INCOMPLETE / RESTART_V3_BLOCKER / LEGACY_NMINUS1_EXACT_CLOSURE_INCOMPATIBILITY。当前合同决策待用户回复，完整真实入口运W行继续。不是 representation 全门 PASS，也不是VWV physical PASS。

## 2. 2C_PRE identity

2B实际封存基线：116 source、2个exe；161个2B artifact复核PASS。physics SHA=b2846067bec5f1ea1e4f9bc51ee6fd6279172474a53a3f7ab539238b5ab90239；design SHA=b89c06acbf72a46690e31710aea5c97c4dcc2ead6eb59f404944a8f2de502c51。历史2A exe=4e7dd57774ae4a23e9212f5a461f38ea109bdc9773d32cf1af26ea497b24c718。

## 3. source delta

14个PRE文件变化，逐项before/after SHA见source_delta_current.json；新增7个表示/IO/ledger/export/migration helper，Make选项新增恢复入口诊断wrap。release_validation_manifest.json记录实际编译源，保留运行中旧快照，不冒充binary identity。

## 4. ScaledDD implementation

normalized hi/lo+int64 exp2；53bit nearest-even hi与残差lo，canonical+0、唯一24-byte big-endian wire，位解码避免FTZ原始tiny运算。348oracle PASS；另14项边界在FTZ off/on通过，含INT64附近、负低残差归零和direct subnormal halfway。

## 5. accumulator implementation

SparseExponentAccumulator使用任意精度整数与指数map保留有限dyadic精确项；重叠/可证明领先项比较，不对巨大指数间隔稠密对齐。局部update和global ledger round-once，1e12指数强相消与INT64范围边界PASS。ScaledDD本身不被称为任意相消exact accumulator。

## 6. authority scalar

NORMAL_DOUBLE/SCALED_DD tag是唯一读写分支；normal保留原始signed-zero bits；不精确可存double时自动promotion，extended sticky，exact zero回到normal+0。不存在独立recovery-only影子权威。

## 7. P2-v2

PURE_GAS/PURE_LIQUID/LIQUID_MINORITY/GAS_MINORITY，Side决定presence；mixed q>0且q<=.5。canonical/Side不合法拒绝。q解码0不会改成pure。

## 8. phase-mass authority

mG/mL统一tagged authority贯穿face flux、cell update、positivity、recovery、restart和ledger。M/Et继续binary64 authority；rhoMix由exact mG+mL取得certified view。

## 9. species authority

所有气体N−1 independent amount采用同一tagged类型，gas-dominant trace species动态PASS；dependent=exact mG−mY0−mY1。无Yi normalization。新运行的P2/species闭合PASS，但旧合法state的universal exact migration硬门FAILED，详见第30项。

## 10. complement/residual expressions

ComplementExpr(q)不提前把1−q舍成1；ResidualExpr保留独立组分和gas amount的exact sparse差。任何primitive需要double时从exact rational取得nearest-even view。

## 11. alpha transport

strategy0全fraction difference/product为scaled/expression-aware；KT权重仍是原normal primitive。总transport/source sparse sum在new q上只舍入一次，无decode-then-evolve。

## 12. K/source

K_PE物理公式不改；exact rational numerator q·dominant·(AG−AL)，denominator bAL+aAG，实现稳定K/q因式数学而不提前用double K。K_scaled及K·divU保留tiny贡献；历史witness K指数−1077、source−1076。

## 13. phase-mass flux

同一canonical ScaledDD face flux在owner/neighbour共享；局部V固定update使用原binary64 dt/V系数，但量与flux累加为exact sparse。pure receiver收到<DBL_TRUE_MIN正液体量并变mixed PASS。

## 14. species flux

每个独立species使用scaled共享face flux；dependent flux为gas flux减independent flux的exact residual。Gas dominant与gas minority trace tests通过；旧double flux槽为views，V2 update不读取它们。

## 15. positivity/joint dt

exact量/outgoing ratios给物理边界，Side与exact signs给presence/positivity，无dtRepresentation。原TD1 growth/connected/rescue与CRV3预黏性cap adjustment保持。冻结step300锚点新canonical flux可接受原物理cap约1.50636516787916e-7；历史精确方向量在uniform runtime也接受full cap3.1002440856734068e-7。

## 16. R1

m·e、m·beta和Eint residual先exact sparse再certified double；present两相均查询原native EOS与共同p interval。root iteration、pressure/energy tolerances及EOS hard rules未放宽。历史208rhoL=727.43296054532061；历史300rhoL=702.40494296577947。

## 17. cPE

AL/AG使用冻结EOS double primitive products；weighted denominator及rho为exact authority expressions。c² certified nearest-even rational view后使用原sqrt；normal K相对差2.2364957106304679e-16、cPE相对差2.0350031110991827e-16。不存在mixed view-zero pure shortcut。

## 18. normal equivalence

非bit-identical：更高有效精度/round-once改变舍入顺序。21 normal states初始p最大差2.7939677238464355e-9 Pa，原预算PASS。1344 accepted control rows dt最大差1.81603863891322e-18 s；6shock最大p差9.778887033462524e-8 Pa、T差1.6257217794191092e-11 K。所有原normal/native/strict/1e-10 conservation/5%contact/2e-6 acoustic门未改；normal_output_comparison.json保存Q views与bounds差异。

## 19. deep-exponent suite

1e-325/350/500/1000×both minority×U0/±3000的encode/recovery/zero-netflux检查PASS；binary −3322/−10000 both minorities PASS。重启包含全部decimal both minorities及−10000 both minorities；动态1e-500/1000级four cases×40 steps共2560接受单元checks PASS。

## 20. pure/tiny transitions

exact pure receiver接收scaled flux后mixed PRESENT；gas dominant independent species~1e-500保留；normal↔extended sticky及exact zero demotion边界PASS。

## 21. minority switches

10项Side tie/.5/cross/zero测试PASS，按exact authority比较，不按解码view。pure ±zero和both-half重启位级精确。

## 22. step300 witness

冻结recorded direction vector：alpha≈3.131775720308425e-325、mL≈2.199774746204852e-322，active ratio≈702.40494296577947，EOS/R1与K/source保留。历史向量与重新计算的canonical flux不是同一数值；不宣称相同。新coupled step301接受完整物理cap；uniform历史向量full-cap及两层restart PASS。

## 23. full trajectory/endTime

coupled driver fresh到原endTime=.00055 PASS，3652 accepted steps，0reject。该driver起始request=1e-7；为严格保留原controlDict起始deltaT，又启动真实入口完整验证，目前step约638、t约9.6256734227478697e-05，尚未关闭该补充门。旧半dt终点观察已保留，V2入口精确终点循环已修正。

## 24. min exponents

已完成coupled driver：q最低-1277、phase mass最低-1268、independent species最低-522；最终800 extended cells、2400 promotions。

## 25. temporal statistics

内部最小dt=1.5063651678790901e-07；内部selected/anchorCap最低=0.99999999999999456，微小差来自原预黏性cap重计算。首步request1e-7及终点截断7.660465706628254e-8单独记录，0拒绝，无representation微步长。

## 26. authority conservation

fresh driver及deep动态每接受步精确exponent-aware global reduction，通过冻结2^-103 local accumulated roundoff门。真实入口同样接入每接受步ledger。double/long-double常规积分只作对照。

## 27. P2/species

fresh/core/deep动态source states exact Side/sign/N−1 closure通过，viscous分量固定。legacy closure反例证明旧binary64合法域比new exact residual合法域更大，不能把有限迁移fixtures PASS概括为universal PASS。

## 28. FTZ/DAZ

348oracle authority/view/wire off/on逐位一致，relativeMax=5.536818551873063e-33，2^-103预算不变；14boundary off/on PASS。只隔离诊断harness修改MXCSR，production不修改。

## 29. restart-v3

实现双层Side、tag、normal bits/hi-lo-exp2、M/Et、time/lastDt/step、known old clock、physics/EOS/species/design/schema SHA256与canonical LF checksum。最终mesh-v1记录串行固定uniform periodic unit-area topology及两层volume SHA。32 normal/decimal/binary/witness往返、signedzero/half/208矩阵、deep真实两层clock、坏checksum/unknown version拒绝PASS。production restart仍NOT CERTIFIED。

## 30. migration

普通v1/v2 exact archive/explicit current-identity activation与lossless reverse测试PASS；历史model激活拒绝，deep lossy reverse拒绝。通用门FAILED：actual frozen旧exe接受mY0=mG,mY1=mG·2^-54,mY2=0；新精确residual必负，gap/budget=2^49。RESTART_V3_BLOCKER。精确归档全部旧文件、仅新闭合合法状态激活的合同替代已备审，但未授权/未偷偷采纳。

## 31. output/view contract

registry alpha/P2/mass/species明确lossy publications，presence来自Side。科学checkpoint=v3；authority CSV输出Side、presence、mantissa bits、exp2、tags、underflow flags和时钟。旧回归Q-bits CSV在V2中是view bits，不能当权威wire。

## 32. consumer audit

CONSUMER_AUDIT_v1.md逐路径A/B/C/excluded分类，本轮serial strategy0 active graph D=0。higher-order/ALE/2D/MPI/DPM不被该审计资格覆盖。

## 33. CRV3-1 regression

336 controls、53760 native=strict、contact、9acoustic、6fixed-mu shocks、heating/work/rollback/jointdt/restartidentity原门PASS；CRV3-1 scoped COMPLETE preserved。这些shock参考不是独立VV证据。

## 34. performance

PERFORMANCE ISSUE / soft：隔离10k (a*b+a)/b benchmark normal extended arithmetic约0.0204s、binary64等价式0.0000395s，约516x microbenchmark开销，不等于完整PDE倍数。-1661/-3322约0.0189/0.0179s；每10k有30k scaled-round、38,998 roundRatio、48,998 sparse multiply等计数，max2 bins。巨大指数相消10k约0.00122s；40-step deep dynamic实测14.31s、47,428KB RSS。未通过删trace优化。

## 35. hashes

最终候选exe b3055c14eb9d78484d2b924d6fee7ecc80e16423bfb5c11f84bbcce722302f2c；oracle exe b2501c30a8c850b526630345d28df2d8d92a5ed96f0dee118ed70f940010b52d；已完成driver exe 3fc1eaf11515c5141c99340220a12c1a1d905af6188cf5a99f5c1938791302bb。actual source manifests、historical exe、EOS/physics/design/TD1 selection hashes分别保存；不可用当前source SHA冒充早期运行。

## 36. hard blockers

RESTART_V3_BLOCKER / LEGACY_NMINUS1_EXACT_CLOSURE_INCOMPATIBILITY已native+封存exe复现。非EOS、R1、指数耗尽、temporal或conservation失败。完整真实入口补充验证仍运行；这不是已失败的门。性能仅soft issue。

## 37. CRV3-2C COMPLETE?

NO。universal legacy migration hard gate失败，不能根据其余PASS改判COMPLETE。待合同决策及完整真实入口收尾。

## 38. CRV3-2 resumed?

NO。仅2C全部硬门完成才可按原授权自动恢复physical qualification。

## 39. CRV3-2 status

INCOMPLETE / VV未资格，尚未新建physical qualification report v3。独立mixed行波、resolved fixed-mu、mu ladders/two paths/unique VV limit仍待后续自动恢复条件。

## 40. M6B.1 status

PARTIAL；M6B也未关闭。历史MC5/TD1、CRV3-1及2A/2B封存证据保留。

## 41. milestone matrix

MC5/TD1 COMPLETE preserved；CRV3-1 scoped COMPLETE preserved；2A INCOMPLETE historical；2B DESIGN COMPLETE preserved；2C INCOMPLETE / MIGRATION BLOCKER；2 physical INCOMPLETE；CRV3-3 NOT AUTHORIZED；M6B.1/M6B PARTIAL。
