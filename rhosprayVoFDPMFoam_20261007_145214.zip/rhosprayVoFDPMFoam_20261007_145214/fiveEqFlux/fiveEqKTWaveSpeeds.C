#include "fiveEqKTWaveSpeeds.H"
#include <algorithm>
#include <cmath>
#include <stdexcept>
namespace fiveEq {
fiveEqKTWaveSpeeds ktWaveSpeeds(const Foam::vector& UL,const Foam::vector& UR,
    double cL,double cR,const Foam::vector& Sf,double meshPhi,KTScheme scheme) {
    const double area=Foam::mag(Sf);
    if(!std::isfinite(area)||area<=0||!std::isfinite(meshPhi)
       ||!std::isfinite(cL)||!std::isfinite(cR)||cL<=0||cR<=0)
        throw std::invalid_argument("Invalid KT geometry/acoustics");
    fiveEqKTWaveSpeeds w;
    w.qPlus=(UL & Sf)-meshPhi;w.qMinus=(UR & Sf)-meshPhi;
    if(!std::isfinite(w.qPlus)||!std::isfinite(w.qMinus))
        throw std::invalid_argument("Nonfinite relative velocity");
    w.ap=std::max({w.qPlus+cL*area,w.qMinus+cR*area,0.});
    w.am=std::min({w.qPlus-cL*area,w.qMinus-cR*area,0.});
    w.aPos=w.ap/(w.ap-w.am);w.aSf=w.am*w.aPos;
    if(scheme==KTScheme::Tadmor){w.aPos=.5;w.aSf=-.5*std::max(std::abs(w.ap),std::abs(w.am));}
    w.aNeg=1-w.aPos;
    w.Aplus=w.aPos*w.qPlus-w.aSf;w.Aminus=w.aNeg*w.qMinus+w.aSf;
    w.phiRelStar=w.Aplus+w.Aminus;w.phiPhysStar=w.phiRelStar+meshPhi;
    if(!std::isfinite(w.Aplus)||!std::isfinite(w.Aminus))
        throw std::invalid_argument("Nonfinite KT coefficient");
    return w;
}
}
