#include "fiveEqKTFaceFlux.H"
namespace fiveEq {
fiveEqKTFaceFlux fiveEqKTFaceFluxKernel::evaluate(const fiveEqRuntimeInput& L,
    const fiveEqRuntimeInput& R,const Foam::vector& Sf,double meshPhi,KTScheme scheme) const {
    fiveEqKTFaceFlux f;
    const bool leftOK=bridge_.recoverFaceState(L,f.left,f.leftDiagnostic);
    const bool rightOK=bridge_.recoverFaceState(R,f.right,f.rightDiagnostic);
    if(!leftOK||!rightOK){f.status=!leftOK?(!rightOK?FaceFluxStatus::BOTH_INVALID:FaceFluxStatus::LEFT_INVALID):FaceFluxStatus::RIGHT_INVALID;return f;}
    if(speciesCount_<=0||(L.mG.value()>0&&L.YG.size()!=speciesCount_)
       ||(R.mG.value()>0&&R.YG.size()!=speciesCount_)){
        f.status=FaceFluxStatus::INVALID_SPECIES_LAYOUT;return f;
    }
    try {f.wave=ktWaveSpeeds(f.left.U,f.right.U,f.left.thermo.cMix,
        f.right.thermo.cMix,Sf,meshPhi,scheme);}
    catch(const std::invalid_argument&){f.status=FaceFluxStatus::INVALID_GEOMETRY;return f;}
    const auto& w=f.wave;const double pL=f.left.thermo.p,pR=f.right.thermo.p;
    const double pStar=w.aPos*pL+w.aNeg*pR;
    f.mGPhi=w.Aplus*L.mG.value()+w.Aminus*R.mG.value();
    f.mLPhi=w.Aplus*L.mL.value()+w.Aminus*R.mL.value();
    f.momentumPhi=w.Aplus*L.M.value()+w.Aminus*R.M.value()+pStar*Sf;
    f.energyPhi=w.Aplus*(L.Et.value()+pL)+w.Aminus*(R.Et.value()+pR)
        +w.aSf*pL-w.aSf*pR+meshPhi*pStar;
    f.alphaPhiCandidate=w.Aplus*L.alphaL.value()+w.Aminus*R.alphaL.value();
    f.speciesPhi=Foam::scalarField(speciesCount_,0);
    for(Foam::label i=0;i<speciesCount_;++i){
        const double left=L.mG.value()>0?L.mG.value()*L.YG[i]:0;
        const double right=R.mG.value()>0?R.mG.value()*R.YG[i]:0;
        f.speciesPhi[i]=w.Aplus*left+w.Aminus*right;
    }
    f.status=FaceFluxStatus::OK;return f;
}
}
