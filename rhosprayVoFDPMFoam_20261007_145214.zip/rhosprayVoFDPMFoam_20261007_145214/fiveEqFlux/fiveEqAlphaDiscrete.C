#include "fiveEqAlphaDiscrete.H"
#include <limits>
#include <stdexcept>
#include <cmath>
namespace fiveEq {
fiveEqAlphaStep alphaEulerStep(double a,double V,double dt,double FL,double FR,
    const fiveEqKTWaveSpeeds& L,const fiveEqKTWaveSpeeds& R,double meshL,double meshR){
    if(!std::isfinite(a)||!std::isfinite(V)||!std::isfinite(dt)||V<=0||dt<0)
        throw std::invalid_argument("Invalid alpha step input");
    fiveEqAlphaStep s;s.volume=V+dt*(meshR-meshL);
    if(!std::isfinite(s.volume)||s.volume<=0)throw std::invalid_argument("Nonpositive GCL volume");
    s.sourceIntegral=dt*a*(R.phiPhysStar-L.phiPhysStar);
    s.centerWeight=V+dt*(-L.Aplus+R.Aminus+meshR-meshL);
    // Algebraically equal to (V*a-dt*(FR-FL)+sourceIntegral)/Vnew.
    // Cancelling the GCL term symbolically preserves exact alpha=0/1 plateaus,
    // without clipping or changing any phase mass/energy.
    const double relativeDivergence=R.phiRelStar-L.phiRelStar;
    s.alpha=a+dt*(-(FR-FL)+a*relativeDivergence)/s.volume;
    // Deliberately no clipping; caller must respect the joint timestep bounds.
    return s;
}
double alphaPositiveDtBound(double V,const fiveEqKTWaveSpeeds& L,
    const fiveEqKTWaveSpeeds& R,double meshL,double meshR){
    const double out=L.Aplus-R.Aminus-(meshR-meshL);
    return out>0?V/out:std::numeric_limits<double>::infinity();
}
double massPositiveDtBound(double V,const fiveEqKTWaveSpeeds& L,const fiveEqKTWaveSpeeds& R){
    const double out=R.Aplus-L.Aminus;
    return out>0?V/out:std::numeric_limits<double>::infinity();
}
}
