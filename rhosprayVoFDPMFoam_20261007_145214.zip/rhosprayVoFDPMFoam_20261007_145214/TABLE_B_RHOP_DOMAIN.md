# TABLE-B rho,p admissibility contract (candidate only)

For pressure inside HARD, define rhoHardCold(p)=1/g_p(p,285), rhoHardHot(p)=1/g_p(p,320).
For pressure inside NORMAL, define rhoNormalCold(p)=1/g_p(p,295), rhoNormalHot(p)=1/g_p(p,305).
Require rhoHardHot <= rho <= rhoHardCold before any T solve. Outside is INVALID.
Inside NORMAL pressure and density curves is NORMAL; the remaining HARD domain is BUFFER.
These are candidate model curves, not a rectangle in rho,p. Runtime never calls CoolProp.
Reference curves are separately stored in reference_boundary_curves.json; error, slopes,
classification disagreement and endpoint behavior are in rho_p_domain_crosscheck.json.
Strict comparisons have no thermodynamic tolerance band. Boundary-safe root numerical
residuals and binary64 ties are documented in M6A1B2B3A_HARD_DOMAIN_REPAIR.md, sections 15–16.
Current reference-domain inclusion FAILS. This contract is not promoted to a production EOS.
