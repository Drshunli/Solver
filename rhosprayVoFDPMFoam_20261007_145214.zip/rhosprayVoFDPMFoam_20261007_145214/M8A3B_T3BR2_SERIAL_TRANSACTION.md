# M8A.3B-T3B-R2 — Serial transaction completion gate

Evidence profile: Foundation OF7 / serial / R2.4. Final status: PARTIAL.

# 1. T3B-R2 status

**PARTIAL**。选定原生模型图的串行组件测试通过，但完整 runtime support crossing 和纯液体全过程拒绝门槛未关闭。冻结 StableCommittedCarrierView::prepare 对全部单元恢复气相；任何气相缺失槽都会抛出 DPM_GAS_ABSENT_NO_CARRIER_VIEW。因此无法从真实混合 Q 启动小步合法接受、大步跨越不合法支持域拒绝、随后小步重试的全过程。本轮未修改该冻结 owner，未用全气相影子 Q、虚构气相、掩码、重归一化或最近气相外推绕过。

# 2. transactionState-v1 completeness

新增 `tests/fiveEqDPMTransactionR2/stateCodec.H`，wire tag 为 `transactionState-v1/OF7-DP-Int32/serial/P2/R2.4`。完整记录选定模型图的演化边界状态：P2 双精度位、各 cell 全部十个 Q 分量、generation/sequence/time/dt/allocator；确定 parcel 顺序、origProc/origId、native topology stream 和 36 scalar+Y 的 typed IEEE overlay；RNG/cache、solution mutable history、force flags、Cone injection history/cached tet、wall counters、cloud ambient/average mass/TMax、source accumulators、theta internal/boundary 和 pending output bytes。配置/mesh/thermal 数据作为 context pin。浮点采用位编码，包含负零和 nextafter 探针；checksum/truncation/layout 校验受控拒绝。

只认证固定静止 mesh、DP/Int32、串行、所选八模型、NoHeatTransfer/NoPhaseChange/radiation off 的演化边界。临时 tracking stack、派生 occupancy/interpolation、不可变缓存不属于持久状态；非选定模型图/MPI/生产 restart 未认证，不将此结论扩展到它们。

# 3. RNG codec

PASS：记录实际 OF7 generator 的完整 x_ 状态、normal 缓存 flag/value 位。A/B/C evolve 后重建，200 组 normal+uniform draws 一致；两种缓存 flag 另各 100 次 draw 一致，后续 >=10 次 stochastic renewals 一致。有限 probe 没有替代 codec。

# 4. duplicate-ID disposition

已关闭当前 project-local harness 问题。原因是 cloud 构造读取 uniform properties 改写全局 particleCount_，此前未被 TrialScope 隔离；本轮构造、导入和演化均约束 allocator，重建不分配/重编号已有身份，检查 (origProc,origId) 唯一。local ID 采用 canonical traversal rank；OF7 没有另一个独立 native local-ID 成员。未归因于 ORourke，历史 O1 原证据保持不变。

# 5. ConeInjection result

PASS（选定配置）：从真实非零 native injection history 开始，大步发生真实出生后拒绝；discard 与 pre-trial 位相等；小步重试与直接接受逐位相等，并继续 10 个完整 native cloud.evolve。包含 parcel/count/IDs、birth mass、native counters、RNG 和未来注入进度。

# 6. Injection ledger

出生 observer 在 native setNumberOfParticles 完成后、实际移动前记录 represented mass、momentum、species 和 H-pV+KE。标记 external TEST_DPM population supply，出生本身不映射 dmG/dmYi/carrier dM/dEt；随后真实 drag 等独立 carrier exchange 仍走 frozen strict adapter。TEST_DPM_INLET 不改变未来 Eulerian production nozzle 独占供液契约。

# 7. Stochastic result

PASS：真实 native dispersion update 后拒绝/重试，精确恢复 UTurb/tTurb 和完整 RNG/cache；>=10 次 future 随机更新及载气 query tuple 相等。

# 8. SphereDrag result

PASS：真实非零 UTrans，冻结 momentum/energy adapter 更新 QTrial，prepare/publish coherent carrier generation；大步拒绝、小步重试、10 次未来接受及输出相等。未应用 ORourke 例外。

# 9. BlobsSheet result

PASS：在实际 native calc 事件中核对同一 parcel 的 liquidCore >0.5 到 <0.5 真实转变；rollback/retry/future 相等。模型参数无独立演化持久历史，事件历史在 parcel 中：STATELESS-BUT-EVENT-TRANSACTION-VERIFIED。

# 10. ReitzKHRT result

PASS：在 parent native calc 内捕获真实新 child origProc/origId，不以注入导致 count 增长冒充 KH child。拒绝 child 消失，重试 child 身份相等，继续 10 次完整 native future。KHindex/tc/ms 等 parcel history 已入 codec。

# 11. ORourke native accepted result

PASS：另用原生 branch fixture，A/B/C 全部真实触发 no collision、grazing、coalescence 和正质量 cleanup/count reduction；native reference 与接受事务一致。专项 A=3415, B=3415, C=3415 checks，均 0 failures。通用 all-gas event matrix 的 OR 标签不单独作为真实碰撞 branch 证据。

# 12. ORourke rollback result

PASS：真实 native collision 已修改 trial 后拒绝；parcels/IDs/multiplicity/RNG/source/Q/generation/output ticket 全 codec 恢复，不保留 rejected output。

# 13. ORourke retry result

PASS：四分支各 direct-small 与 rejected-large+retry-small 一致，随后每路径 10 个完整 native evolve；首个 collision kernel 后通过完整 native injection phase 消化相应 injection 时间历史，不直接编辑 counters。

# 14. ORourke native residual diagnostics

全部 native residual 继续输出，标记 KNOWN_NATIVE_MODEL_LIMITATION_NOT_COMPENSATED。无任何 compensating gas source。以下为最新专项 retry 第一个原生事件；species residual 另见各 *_events.txt（单液体组分下与 mass residual 对应）。grazing 保持 native 320 K，不使用历史 O2 热化解释。

| State | Native event | Mass residual kg | Momentum residual kg m/s | KE change J |
|---|---|---|---|---|
| A | none | 0 | (0 0 0) | 0 |
| A | grazing | 0 | (0 0 0) | -2.1532675918842419e-09 |
| A | coalescence | -8.0779356694631609e-28 | (-1.4110386815062296e-12 0 0) | -1.5883021654901483e-13 |
| A | cleanup | -2.1118921563492686e-16 | (1.6222420075267023e-15 0 0) | -2.7216951968247001e-16 |
| B | none | 0 | (0 0 0) | 0 |
| B | grazing | 0 | (0 0 0) | -3.9540935965880217e-09 |
| B | coalescence | -1.2116903504194741e-27 | (-9.8660026689526761e-13 0 0) | -2.1996218851971998e-13 |
| B | cleanup | -3.8797858017279831e-16 | (1.3745887130686945e-15 0 0) | -4.3141382219472991e-16 |
| C | none | 0 | (0 0 0) | 0 |
| C | grazing | 0 | (0 0 0) | -9.7794519015651874e-09 |
| C | coalescence | -1.2116903504194741e-27 | (-3.8125937310726331e-14 0 0) | -3.4816252175197137e-14 |
| C | cleanup | -9.632359953274453e-16 | (1.0013623138955448e-15 0 0) | -5.1703906111568321e-16 |

# 15. Rebound result

PASS：真实 tracking 到 native wall face，native patchData 和 StandardWallInteraction correct 完成反弹。后续拒绝/重试、wall counters/parcel state/native sources/output/future 相等。未以自写反射函数替代。

# 16. Wall-event ledger

记录实际 patch identity、parcel 前后和 external boundary impulse ΔP、mechanical work ΔKE；不把 wall impulse 当 gas source，不加虚构气相反冲。该事件的 carrier dm/dM/dEt 维持实际 native 零源；另行发生的 drag 仍独立核对。

# 17. ThermoParcel deletion result

PASS：独立 1e-16 kg represented parcel 的 native minParcelMass 路径实际删除。native rhoTrans 回收同一质量，species 和 momentum residual 为零，energy 走冻结 sensible/formation/KE 转换，不继承 ORourke 例外。未发现新的 unexplained physical loss。详见 minimum_mass_deletion_ledger.txt 和独立事件 direct/retry。

# 18. Runtime support retry

**BLOCKER**：actual cellPoint contributor map 在 setCellValues 和 native calc 入口由 P2+mG+thermo authority 检查，合法区域中实际 hook 已执行。载气在 trial 内保持 Q^n 视图，QTrial 累计源后于 prepare 恢复/发布；fixture boundaryQ=ownerQ 是该离线零梯度测试的边界 oracle，未认证 production BC。但完整混合 Q crossing retry 未执行/未通过。冻结 StableCommittedCarrierView::prepare 对全部单元恢复气相；任何气相缺失槽都会抛出 DPM_GAS_ABSENT_NO_CARRIER_VIEW。因此无法从真实混合 Q 启动小步合法接受、大步跨越不合法支持域拒绝、随后小步重试的全过程。本轮未修改该冻结 owner，未用全气相影子 Q、虚构气相、掩码、重归一化或最近气相外推绕过。

# 19. Trace-gas result

PASS（限定 trace probe）：alphaG=1e-20，真实 parcel query 和 stochastic 事件、QTrial commit/discard，保留 signed P2 位及 carrier recovery，未用补量失精度。该 probe 为零源 stochastic；不宣称极小气体质量可接受任意非零 drag 源。

# 20. Pure-liquid result

**完整门槛未关闭**。alphaG=mG=0 authority 的 setCellValues guard 受控拒绝、无 captured interpolation tuple、Q/codec 不变、未合成气相。这仅是插值入口探针，不是 coherent pure-liquid cloud transaction。本机 ThermoParcelTrackingDataI.H 的 trackingData 构造函数先调用 cloud.thermo().thermo().Cp() 和 kappa()，随后才到 setCellValues 插值入口。因此现有局部 guard 不能证明拒绝发生在所有气相物性求值之前。

# 21. Combined-event result

PASS（限定 all-gas fixture）：持续注入、native stochastic/drag/breakup/碰撞调度、非零 native transfer 等真实完整 evolve 后 deliberate reject，small retry 的全状态/query/output/future 与 direct 相等。真实墙和四 collision branches 分别由专项证明，不把 combined 调度自动声称为所有事件同时触发。

# 22. Canonical direct/retry result

PASS：A/B/C core 各 13 个 event pairs，专项各 4 个 collision pairs。每 pair 保存版本化 pretrial/after_discard、direct/retry step_0..10 .bin；独立解析 layout/checksum/IDs 并比较位相等及 accepted output tree 字节。

# 23. Future equivalence

PASS（选定合法载气域）：初始 evolved A/B/C codec reconstruction 后各 >=10 完整原生 evolve；各核心和真实 collision event commit 后另继续 10 个 accepted steps，比较全 packet、实际 carrier tuples 和确定性输出，非仅 parcel count。

# 24. Persistent-output architecture

新增 outputCommit.H/serialClosure.H：prepareCommit 校验路径/命名/字段，完整序列化并 close/flush/fsync dedicated staging；physics validation 后交换 Q/cloud/载气 generation，再 same-filesystem rename accepted/step_N。7 类 artifacts：timeMetadata、positions、parcelFields、nativeSources、voidFraction、eventLedger、carrierQueries。仅 harness schema，非 production/native restart。prepare failure 可 discard；post-physics IO failure 保留 physics 和 pending ticket，下一物理 trial 被阻止，flush 可重试。已测试注入错误及真实目标 regular-file 冲突；不宣称内存+磁盘联合原子性或断电持久性。

# 25. Accepted exactly-once result

PASS：每 accepted sequence 一个完整目录；第二次 publish 核对已有内容，不重写/增加 publication count。100 个连续 accepted step 各发布一次。

# 26. Rejected-output result

PASS：rejected/prepare-failed trial 删除仅自身 staging，不出现 permanent accepted artifact；独立 audit staging leftovers 为空。普通 log/diagnostic 与 simulation-like output 分开。

# 27. Retry-output result

PASS：所有 deterministic direct/retry accepted artifact trees 字节相等，含 actual theta 和 carrier queries。

# 28. VoidFraction result

PASS：native CloudFunctionObject 沿 postMove 轨迹累计；独立 observer 核对 theta=Σ(dt_segment*nParticle*Vparcel)/(dt_step*Vcell)，并明确测试它与 final occupancy 不同。theta 状态及输出进入 codec/ticket，拒绝大步轨迹积分不进入 accepted output。

# 29. Sequential commit result

PASS：每 A/B/C、每最终 suite 100 个真实非零 momentum source 接受并发布输出；另 core 12 次完整耦合 evolve 接受。不把零源 role swap 当该证据。

# 30. Alternating lifecycle result

PASS：100 accept/reject 交替，reject 实际非零源且已 prepare；每 fixture 再做 1000 complete-codec clone/mutate/discard，抽样 registry/RSS，Q/cloud/RNG/allocator/generation/tickets 无 drift。

# 31. Registry result

PASS（harness）：记录 mesh registry 数量并保持常数，两个 owner roles 交替；临时 interpolation 随 stack scope 销毁，output staging 无残留。未单独以全局计数器测量每个 transient interpolation instance 或非 registry heap 对象；不宣称生产注册表/内存证明。

# 32. RNG state result

PASS：完整 cache/state 随 trial codec 复制；reject 后逐位 anchor 不变，retry 和未来随机序列无漂移。

# 33. Allocator result

PASS：保存原生全局 particleCount_、检验 next allocation 及每角色 decode 后身份唯一；拒绝 trial 出生/child 不消费 committed allocator。无 post-hoc renumber。

# 34. Carrier-generation result

PASS（合法载气域）：accepted 时 coherent Q/cloud/载气 generation 同步，discard 不推进；重放世界为独立 test oracle setup，可恢复初始 generation，这不是生产允许回退 committed generation。

# 35. Memory result

下表为采样 RSS，页按 Linux 4 KiB；/usr/bin/time peak 另在各 log.resource。registry 和 output staging 稳定，但 allocator/RSS 不必回到启动值，不将采样范围当无泄漏数学证明。

Core：

| State | Registry counts | sampled min KiB | sampled max KiB |
|---|---|---|---|
| A | [63] | 122284 | 122308 |
| B | [63] | 165364 | 165392 |
| C | [63] | 137016 | 137080 |

Native collision：

| State | Registry counts | sampled min KiB | sampled max KiB |
|---|---|---|---|
| A | [63] | 120784 | 120808 |
| B | [63] | 113012 | 113036 |
| C | [63] | 121560 | 121620 |

保留早期超大 RSS/中断证据：孤立 action 推进时间但未处理 native injection history，下一极小 dt 导致补跟踪海量 segment/诊断记录。修正为完整 native evolve，collision 使用 native injection phase；未用改物理或静默丢记录解决。50,000 observation 工作上限仅受控拒绝病态测试，不接受截断物理。

# 36. Eight-model capability matrix

| Model | 已通过的选定串行组件测试 | 完整范围能力标签 |
|---|---|---|
| coneInjection | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| sphereDrag | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| stochasticDispersionRAS | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| blobsSheetAtomization | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| ReitzKHRT | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| ORourke | native event / rollback / retry / 10 future steps PASS；保留原生物理限制 | BLOCKER |
| rebound | native event / rollback / retry / 10 future steps PASS | BLOCKER |
| voidFraction | native event / rollback / retry / 10 future steps PASS | BLOCKER |

所有 BLOCKER 共用 mixed-carrier-absence / early-thermo gate；各行 PASS 是组件事实，不能替代完整 scope certification。没有 FULL-CONSERVATION-SAFE 声称。

# 37. Native ORourke limitation status

原生 Foundation OF7 ORourke 源码/概率/pair/RNG/grazing/coalescence/cleanup/T/energy 行为均未改。正质量截断、原生 momentum semantic offset、未跟踪 KE 仍是 KNOWN_NATIVE_MODEL_LIMITATIONS，仅 ORourke 例外。本轮早先实际核对的 live hashes 在 native_collision_live.sha256；观察 calc specialization 去掉 hooks、还原 type aliases 后与 native body SHA 相同（native_calc_body_comparison.json）。最终追加的一次 WSL 重复哈希核对未执行，因额度限制自动审批无法完成审查；没有绕过审批，不把该追加操作记为 PASS。详见 FINAL_RECHECK_NOT_EXECUTED.txt。

# 38. Source/energy frozen regression

9288 PASS / 0 failures；8 energy golden 与 R1 byte-identical。所有非 OR native carrier exchange 继续 frozen source/energy contract；Birth/Wall 属外部 population/boundary ledger，并非碰撞例外扩展。

# 39. M8A.3A regression

6375 PASS / 0 failures；A/B/C 各 2125。

# 40. T2 regression

1725880 native interpolation comparisons PASS；max error 3.84593e-16；all-gas 21000/21000。support classifier authority/原算法冻结。

# 41. T3A regression

64395 PASS / 0 failures；A/B/C 各 21465，含 generation/129 swaps/1000 discard 原测试。新增 gate 不改旧 owner。

# 42. P2/R1 regression

105775 PASS / 0 failures；P2-v1 / recovery / R1 保持冻结。O1/O2/O2A/O2B 历史文件逐 SHA 不变，本轮未重新解释其物理结论；O1 未重新运行。

# 43. temporal/restart regression

9663 PASS / 0 failures；fiveEqRestart-v1 不变，transaction codec 不是 production restart 扩展。

# 44. Active solver impact

**NONE**。保护审计 14420 个既有文件，只有本轮允许追加 MILESTONE_STATUS.md；active solver/cloud.evolve/strict adapter/fiveEq thermo/active Make 未改。仅新增 tests/fiveEqDPMTransactionR2/{test .C,stateCodec,nativeObservedCalc,eventLedger,outputCommit,serialClosure,eventActions,README,Make}、新 stage 离线工具/数据/日志及本报告/能力矩阵。Foundation OF7 standalone wmake PASS，最终 core A=3729, B=3729, C=3729 checks 和 collision A=3415, B=3415, C=3415 checks 均 0 failures。旧失败/中断日志保留，未算入最终 PASS。

# 45. Production mesh/BC impact

**NONE**。300_2D 全部 96 个受保护文件不变；测试 fixtures 与 R1 相同；未创建 production nozzle patch。standalone Time/fvMesh/cloud 只运行离线组件测试，无 blockMesh/checkMesh/PDE solver/CFD。

# 46. Whether T3B-R2 COMPLETE

**NO — PARTIAL**。混合支持域 crossing retry 未通过；纯液体拒绝的 pre-thermodynamic-construction 要求未证明。不能通过更宽 tolerance 或假气相关闭 gate。

# 47. Whether T3B COMPLETE

**NO — PARTIAL**。R2 全部门槛未关闭；selected graph codec 和已通过事件不会自动使整体完成。

# 48. Whether T3 COMPLETE

**NO — PARTIAL**。T3A COMPLETE，但 T3B 仍 PARTIAL。

# 49. T4/M8A/M6B permissions

**T4 NO；M8A PARTIAL；M6B.0 NO；M6B.1 NO。**下一工作只应提出/审核 material-aware carrier view + trackingData 前的 gas-valid thermodynamic construction 方案，明确 optional gas validity 和真正 mixed Q 事务契约，并保留 frozen T3A 路径；本轮不实施该 owner 迁移、不激活 solver。

# 50. Updated milestone matrix

| Milestone | 状态 |
|---|---|
| M8A source/energy | PASS / FROZEN |
| M8A.3A | COMPLETE |
| T1 | COMPLETE / DESIGN ONLY |
| T2 | COMPLETE / STRICT-SUPPORT FEASIBLE |
| T3A | COMPLETE |
| O1 | COMPLETE / NATIVE CONSERVATION BLOCKER，历史保留 |
| O2 | COMPLETE / research/design audit only，历史保留 |
| O2A / O2B | PARTIAL，历史阻塞保留 |
| O2D | COMPLETE / NATIVE_OF7_OROURKE_FIRST_ACTIVATION |
| T3B-R1 | PARTIAL，历史保留 |
| T3B-R2 | PARTIAL / MIXED-CARRIER-ABSENCE AND EARLY-THERMO GATE |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B.0 / M6B.1 | NO |

STOP：本轮不执行 T4/M6B/CFD。
