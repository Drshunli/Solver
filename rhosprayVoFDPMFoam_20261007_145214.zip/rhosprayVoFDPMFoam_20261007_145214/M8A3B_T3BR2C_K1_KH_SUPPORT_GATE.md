# M8A.3B-T3B-R2C-K1 — final report

Date: 2026-10-04. Full machine-readable evidence: `fitting/dpm/m8a3b_t3br2c_k1_v1/final_audit.json`.

## 1. K1 status

COMPLETE / PATH 2. Fresh selected gates: 264,750 checks, 0 failures. No active solver or CFD execution.

## 2. Native KH child birth semantics

Actual installed OF7 SprayParcel copy constructs a child from parent, assigns new origId and adopts it after native force/history/dispersion operations. The frozen local implementation adds exception-safe child ownership and independent lazy preflight without changing KH formulas. Native and local semantics are distinguished in the contract source audit.

## 3. Parent pose

First final audit record: position=(0.503,0.5,0.5), cell=0, face=-1, tetFace=0, tetPt=1; coordinates=(0.994,0.003,0,0.003). Recorded full precision in `KH_valid_final/KH_identity_audit.jsonl`.

## 4. Child pose

Identical to parent in position, cell, face, tet and coordinates for all 92 audited birth transitions. No relocation or pose perturbation.

## 5. Parent/child identity

First parent origId=107, child origId=320, origProc=0. Distinct actual object addresses recorded in each run. Addresses are observational and not canonical-state content.

## 6. Support-token invalidation

Frozen local source invalidates the shared session before the child query and again before restoring parent authority. Pose equality includes object address and origId, so the parent token cannot grant child authority. Instrumentation also rejects the child directly against the old parent provider token, before clearing provider validity.

## 7. Independent child preflight

92 independent preflights PASS, All=255, generation and preflight count recorded. First record count=1408, carrierGeneration=1. Cached parent spatial data is not accepted as child identity authority.

## 8. Birth support result

PASS at the same valid spatial pose. Spatial-invalid-at-birth=false. The expected physical result is valid support plus separate identity validation.

## 9. Why immediate spatial invalid is unreachable

Fixed support map/generation and identical pose/requirements imply identical spatial admissibility. A new ID does not make spatial support invalid. Proof and applicable scope are in `KH_CHILD_SUPPORT_CONTRACT_v1.md`.

## 10. Test-only identity failpoint status

`IDENTITY_REVALIDATION_TEST`: 92 stale-parent-authority negative assertions, zero thermo calls. No forced child support rejection was enabled in K1. The prior R1 test-only KH rejection remains historical evidence and is not reclassified as real spatial invalidity.

## 11. Post-birth movement path

After `cloud.addParticle(childOwner.release())`, child is an ordinary cloud-owned parcel. Installed Cloud iterates `p.move`; frozen LazyKinematicParcel uses trackToFace, invalidation, actual stencil preflight and controlled reject. No KH-specific post-adoption movement/query dispatcher exists.

## 12. Post-birth invalid-support result

Frozen mixed/pure fixture: dtBirth=1e-5, validBirthPopulation=217, then native motion dt=0.1. Parent origId=107 fails first. `POST_BIRTH_INVALID FIXTURE_UNREACHABLE` for child-first rejection in this tested path. PATH 1 NOT PROVEN; no universal impossibility claim. PATH 2 satisfies the user's alternative completion criterion.

## 13. First invalid owner/stencil

KH reachability attempt: owner cell=1, alphaG=0.5, mG=6.5019509848922681, All=255; actual current-tet U-cellPoint stencil includes entities18–21 with alphaG=mG=0 and nonzero weights. Error `GAS_SUPPORT_INVALID:EXACT_GAS_ABSENT`. It is a real parent spatial failure.

Fresh generic strict run: owner cell1 alphaG=1, mG=13.003901969784536, same absent contributor class. Fresh pure owner run: cell2 alphaG=mG=0. Full stencils are saved separately.

## 14. Property counters

KH reachability at/after: rho6/6, T6/6, Y6/6, Cp12/12, mu6/6, kappa6/6. All six increments zero. Generic strict also 6,6,6,12,6,6 unchanged; pure owner all zero. Cp includes the native kappa calculation's internal Cp call; no minimal per-model requirement profile is claimed.

## 15. Child ownership result

Pre-adoption unique_ptr, post-adoption cloud ownership. KH valid and reachability runs each finish 11,562 ctor=11,562 dtor, live=0. Trial boundaries verify no unowned live child; discard restores baseline.

## 16. Parent ownership result

Parent remains trial-cloud-owned. Discard releases trial parent/children; accepted parent/population remain byte-identical under transactionState-v1. Lifetime equality holds.

## 17. Rollback

Canonical accepted snapshot and carrier snapshot equal before/after discard. Parcel bits/history, parent/child population, IDs, sources, generation, output and pending tickets are included in the frozen codec. Both prepared-event discard and real spatial rejection/discard paths PASS.

## 18. Allocator

Transaction act saves/restores global particleCount; discard restores accepted allocator. Allocator is included in canonical snapshot and subsequent accepted equality.

## 19. RNG

Frozen codec serializes model Random state including cached-normal state. Rollback and 11 accepted direct/retry state comparisons PASS; observation draws no random values.

## 20. Source

Source adapter, ledger and native source semantics unchanged. Invalid support means trial rejection, not physical parcel deletion or a compensating source. Discard publishes no trial source; accepted source content is equal in canonical state and output.

## 21. Output

Zero rejected accepted publication; accepted publication exactly once (duplicate publish is checked idempotent). KH direct/retry accepted output directories each contain 77 files with exact paired equality. Observational JSONL is outside accepted physics/output tickets. This is a serial harness protocol, not crash-safe production restart certification.

## 22. Direct/retry

KH valid: direct-small vs prepared-large-event discard and small retry. KH reachability: valid birth then large native-motion parent support rejection/discard vs direct-small. Both compare transactionState-v1 exactly; the latter is not claimed to be child-triggered rejection.

## 23. Future >=10-step equality

Each KH run checks first acceptance plus 10 future accepted steps. Independently reread archived binaries: 11 paired canonical states per scenario identical. Queries, carrier snapshots and output also equal.

## 24. Generic runtime-support equivalence

Fresh strict/pure87/87, R2B252194, I1 matrix12083/nativefalse18/retry61, all zero failures and final live=0 where measured. Pure owner crossing uses native geometric track + actual query, not full kinetic travel beyond the earlier strict invalid stencil. Source type/control-flow audit plus 5,694 later child queries supports the PATH 2 equivalence.

## 25. Revised KH support contract

New: independent birth identity/support revalidation AND generic support contract for every later child query. All identity/support-first/ownership/rollback/later-movement safety requirements remain. User sections14/21/23 supply revision authority.

## 26. Whether old gate is formally retired

YES, only identical-valid-birth-pose spatial-invalid requirement. Closure reason `REACHABILITY-CONTRACT REVISION`. The actual lack of child-first spatial-invalid trajectory is recorded, not erased. Previous R1 PARTIAL report remains immutable historical evidence.

## 27. Eight-model matrix impact

| Model | R2C transaction gate | Physical/activation limit |
|---|---|---|
| coneInjection | PASS; frozen I1 + fresh ownership/retry | Native physics unchanged |
| sphereDrag | PASS; inherited R1 + fresh generic runtime | Native physics unchanged |
| stochasticDispersionRAS | PASS; frozen R1 evidence | No physics activation |
| blobsSheetAtomization | PASS; frozen R1 evidence | No physics activation |
| ReitzKHRT | PASS via revised PATH 2 + fresh K1 | No fabricated child spatial failure |
| ORourke | PASS; frozen four branches | NATIVE-PHYSICS-LIMITATION; not FULL-CONSERVATION-SAFE |
| rebound | PASS; frozen actual rebound/invalid evidence | Native physics unchanged |
| voidFraction | PASS; frozen owned-output evidence | Selected BoundCloud graph only |

This is an acceptance-matrix closure, not production model activation. Frozen R1's13,969/0 and complete historical regression set are inherited, not all freshly replayed in K1.

## 28. Whether K1 COMPLETE

YES via PATH 2: birth unreachability/source proof, post-adoption generic path proof, independent birth PASS, fresh generic support PASS and ownership/rollback PASS.

## 29. Whether R2C COMPLETE

YES within revised passive serial selected-graph acceptance scope. The previous final audit had only this open item and no mandatory stop condition; all other frozen model/regression gates PASS. K1 rechecks frozen145/30/240/113/288 and1192 previous source/evidence entries unchanged. Installed OF7 6717 entries and native parcel19 entries remain unchanged. C1 remains historical PARTIAL; C2 remains frozen semantic contract. Production restart remains NOT CERTIFIED.

## 30. Whether R2-FINAL may start NEXT ROUND ONLY

Eligible as next-round scope after a new explicit user instruction. Not executed or implicitly started here. No T4, M6B, two-phase activation or CFD.

## 31. Updated milestone matrix

| Milestone | Current status |
|---|---|
| R2B | COMPLETE / FROZEN |
| R2C-I1 | COMPLETE / FROZEN |
| R2C-C1 | HISTORICAL PARTIAL |
| R2C-C2 | COMPLETE / FROZEN |
| R2C-R1 | historical PARTIAL; old sole gate retired by K1 |
| R2C-K1 | COMPLETE / PATH 2 |
| R2C | COMPLETE / revised passive serial contract |
| R2-FINAL | NEXT ROUND ONLY / NOT EXECUTED |
| T3B / T3 | PARTIAL |
| T4 | NO |
| M8A | PARTIAL |
| M6B | NO |
| CFD | NO |

Engineering changes: new isolated `tests/fiveEqDPMKHSupportK1`, observational provider and harness, LF-only runners/offline audit tools, this report, KH contract and appended milestone status. Active equations/parcel family/library source/adapter/ledger/serializer/production mesh and BC are unchanged. Two standalone wmake builds PASS; warnings remain inherited compiler warnings. Initial runner lacked its output parent directory; corrected locally before fresh replay. First independent archive audit used event filename convention for runtime files; corrected to actual frozen runtime names, then all assertions PASS. These tooling corrections did not modify physics or frozen evidence.

STOP at K1. Checkpoint manifest and integrity result accompany the evidence directory.
