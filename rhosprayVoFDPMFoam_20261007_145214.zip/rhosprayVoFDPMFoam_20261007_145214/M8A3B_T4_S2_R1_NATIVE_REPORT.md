# M8A.3B-T4-S2-R1-NATIVE

**T4-S2 = PARTIAL / MPI_OWNERSHIP_BLOCKER. STOP.**

本轮为独立两 rank、固定网格和分区的 passive parcel 测试。没有 CFD 流场方程推进。N1、S1、serial 后端、Foundation、active solver、production 网格/BC 均未修改。

## 已闭合的迁移观察

新增独立目标 `tests/fiveEqDPMMigrationR1Native`。原生 `cloud.evolve()`、`Cloud::move`、processor tracking、transfer lists、buffers、streams、iNew、addParticle 均继续承担运输。只在项目 parcel 的 prepare/correct 薄委托前后写只读观测；委托仍调用继承的 Foundation 实现。原 N1 的 latch/move/quarantine 实现未改。C2 semantic helper 只作离线 oracle，不进入迁移序列化。

观察点依次为 SEND_BEFORE_PREPARE、SEND_AFTER_PREPARE、RECEIVE_BEFORE_CORRECT、RECEIVE_AFTER_CORRECT。native stream 前后比较 C2 所列全部 scalar bits、active/typeId 及原生 particle ASCII 语义（含 behind/nBehind、stepFraction、IDs）。面局部化和 cell/tet 重建单列；当前轴对齐四边形 processor face 下，reflect 交换 barycentric c/d，tetPt 按反向编号映射。实际位置误差要求 <1e-12 m；物理字段/持久历史为 bit equality。未比较 padding、pointer、cache/token。

正常正向和反向各 1 次 PASS；droplet continuation 1 次 PASS；同一 core parcel 连续 32 次 native evolve 内 **38 次真实穿越（19 正向、19 反向）PASS**。返向来自 native wall rebound，无重定位、手动方向翻转或迁移控制。普通 KH 短/长步轨迹各 1 次 PASS，但没有子出生，不能证明父子 gate。最终 KH K1 工况的父 parcel `(0,0)` 与 source 自然产生的 child `(0,1)` 共 2 次边界 stream 比较 PASS；其后的物理延续发生身份冲突，整项 FAIL。

`QueryObserver` 只先调用冻结 S1CarrierBridge，再对同一 pose 调用冻结 stencil 的只读 build 记录 contributor。它不给物性、不改变 ticket 或 weight、不增加 query-time 通信。droplet 在 destination 第一次实际 preflight 的 cell=0/tetFace=20/tetPt=2，9 个 prerequisite entries 中 4 个为 remote contributors。S1 实际 materialize 保持原实现。

prepare/correct 前后同 rank RNG.x_/stored-normal flag/value 精确一致。随机模型使用冻结 adapter 委托真实 stochasticDispersionRAS；droplet destination 最终 calls=120、实际 RNG 更新计数=4、UTurb 非零。未建立跨 rank RNG 流，也未要求两 rank 的独立 RNG 状态相等。额外的 next-real-result 对照认证没有在 blocker 后执行；此项不能扩展为完整 MPI 随机模型闭合。

## 真正的 STOP blocker

`fitting/dpm/m8a3b_t4_s2_r1_native_v1/kh_boundary_k1` 复用冻结 K1 父粒子初始历史类别：d=0.0003 m、nParticle=1e6、U=(1000,0,0)、KHindex=1、tc=-great、ms=0.21*averageParcelMass、tTurb=1。初始位置 x=3.9999 m，载气 S1 p=3 MPa/TG=800 K，dt=1e-5 s。均为测试输入；没有手造 child 或移动已有 parcel。RT 参数在测试 dictionary 设 CRT=1e9 以隔离 KH；这不属于 production 校准。

第一步 native evolve 返回后，rank1 的 native cloud 中有 6 个 trial parcels，实际身份：

| origProc | origId | 同时存活数量 |
|---|---|---|
|0|0|2|
|0|1|2|
|0|2|1|
|0|3|1|

这是逻辑身份冲突；不是原 parcel transport 被重复发送的证据。source 边界恰有 `(0,0)` 和 `(0,1)` 两次发送，receiver 的重建快照精确保留两者。冲突出现在目标 rank 上自然产生后续 KH children 的阶段。

本机 Foundation `SprayParcel.C:286–287`：child copy parent，随后仅 `child->origId() = this->getNewParticleID()`。`particleI.H:111–121` 的 getNewParticleID 使用本 rank 的静态 particleCount_。项目冻结 C2 对应分支保持该 identity 行为，并加入 K1 support/ownership 包装。迁移 parent 保留 origProc=0，而 rank1 的 native allocator 从自身初始状态起计数；因此新 child 的 inherited origProc 与 rank-local origId 组合会重用迁入身份。**源码规则和本轮同 rank 重复身份观测一致；尚未执行未适配 native cloud 的独立对照，不能声称完整 upstream 缺陷认证。**

诊断在第一步记录了 `MPI_OWNERSHIP_BLOCKER.txt`。当前实验 harness 只累计失败，没有在该步立即 break；它又进入下一步，随后 SIGFPE，job exit=136。只读符号解析将异常首帧定位到原生 ReitzKHRT::update；优化构建没有精确源码行，具体算术表达式及其与重复 ID 的因果关系未证明。**不能把 SIGFPE 当 clean reject，也不能声称该次 trial 完成 discard/lifetime restoration。** 本轮读取证据后停止所有推进，未重跑、修正 identity、屏蔽异常或伪造 PASS。该 harness 作为失败证据冻结，禁止将其作为 fail-fast production 实现使用。

下一轮若明确授权，先单独处理 newborn identity policy：保持 migrated parent 的 identity；评估能否沿用 OF7 新建粒子的 `(birth rank, native local ID)` 约定，作为项目 K1 新生对象最薄适配。不能直接改 frozen C2/K1，也不需要先建立 global ID 服务。必须先审计恢复/allocator 和自然多代出生的碰撞风险，并增加安全测试终止边界。SIGFPE 另立问题审计。**本轮没有实施此方案，S3 不可开始。**

## 原有组件及新增项理由

| 项目 | 用途 / 为什么需要本地项 |
|---|---|
|MPIFailureLatch / N1 / S1 / serial / transactionState-v1 / I1|全部使用冻结实现；原文件不改|
|MigrationObserver.H|Foundation 无项目 C2/fiveEq 语义记录；外置只读 callback，无 parcel 成员、随机调用或通信|
|parcel/LazySprayParcel.H 的 prepare/correct delegates|模板调用允许在项目类观察精确边界；直接委托 native，不复制运输算法；N1 move body 原样|
|QueryObserver.H|冻结 bridge 无公开 ticket 观察接口；仅复制相同 pose 的只读 stencil 输出，不提供新插值或 authority|
|testNativeMigration.C|独立测试编排、native model 计数、native Cloud membership 诊断；不链接 active solver|
|auditS2R1Boundary.py|离线比较已有 C2 bits 和 native geometry，非 runtime serializer|
|prepareS2R1Native.py|初次测试准备历史脚本；其忽略规则曾误漏 C10H22，失败副本保留，后续副本已补齐；不应重用为 production 工具|
|Make/files/options、localTypes/registrations/symbols|沿用冻结 N1 的实际模板实例化和 library 依赖，新增独立 executable 名称；无新增 library|

初次副本缺 C10H22/Ydefault 读取失败保存为 boundary_forward；补齐后的 boundary_forward_v2 PASS。编译 v3 的 DimensionedField 只读接口错误在 v4 修复。最终 v6 wmake PASS。前期 v3 正常控制使用较早构建；源版本保存为 attempt*.C，但未逐次保存旧 executable hash。没有在 blocker 后将全部控制重跑为最终 v6 结果。最终执行 KH 失败的源码/executable SHA 另存。

## 本轮要求的 39 项报告

|#|项目|结果|
|---|---|---|
|1|T4-S2 status|PARTIAL / MPI_OWNERSHIP_BLOCKER|
|2|Native OF7 components reused|tracking、Cloud::move、processor transfer、prepare/correct、buffers、streams、iNew、addParticle、Random、native models/Pstream|
|3|Any new project code|仅独立 observer/fixture/offline oracle；见上表|
|4|Why unavoidable|项目语义不在 Foundation 中；只读 hook 避免 fork 或替代运输|
|5|Native migration path|原生唯一 authority，未新建 transport/serializer/queue|
|6|Sender snapshot|真实 prepare 前/后采集 PASS|
|7|Receiver snapshot|真实 correct 前/后、model evolution 前采集 PASS|
|8|Semantic equality|正常选定轨迹 PASS；最终 KH 两次 stream PASS，后续 identity FAIL|
|9|Identity|简单迁移保持；自然 KH 后代出现 `(0,0)`、`(0,1)` 重复，FAIL|
|10|Ownership|正常轨迹一身份一 Cloud owner；KH 6 个 cloud-owned objects 中 identity 不唯一，gate FAIL|
|11|Destination geometry|native cell/tet/face 及 barycentric reflection PASS，无自建 locator|
|12|Destination S1 support|current-rank pose 重新 preflight/materialize；无 source token 传输|
|13|Coupled query|真实 migrated droplet 首次查询含 4 个 remote contributors，PASS|
|14|Invalid destination regression|冻结 N1 正反 fresh replay normal exit0/assertions0、thermo/recovery0、discard PASS|
|15|RNG audit|prepare/correct 未 draw；rank-local semantics 保留；完整 next-result 对照未完成|
|16|Stochastic continuation|destination native calls120/random更新4/非零 UTurb；限定观察 PASS|
|17|SphereDrag continuation|destination native calls240、Ux 非零更新；本地源观测代码，不认证全球源账本|
|18|BlobsSheet continuation|core native atomization 在迁移后持续执行；core 长度设大，仅认证调用延续，不证明完整主雾化转变|
|19|KH boundary|真实 source child 及 parent 跨界；目标后代 identity 冲突，FAIL，后续 SIGFPE|
|20|Injection/native case|因 STOP 未执行；不能引用 serial regression 代替 MPI injection gate|
|21|ORourke note|边界相关字段保持；单 parcel 正常轨迹无 pair collision；full MPI closure 属 S3，NATIVE-PHYSICS-LIMITATION|
|22|Rebound|core 轨迹自然 rebound→crossing；无人工反弹/翻转|
|23|VoidFraction|真实 source/destination segments 的 native moves 有记录；未完成完整 Theta 质量/时间积分 closure|
|24|>=10 crossings|同一 parcel 38 次有效 native crossings、双方向，PASS|
|25|>=1000 valid crossings|NOT EXECUTED；仅准备 core_stress 副本，N1 1000 failures 不作替代|
|26|Lifetime|已完成正常轨迹 ctor=dtor+live、discard 回到 baseline；最终 KH fatal 无 restoration certificate|
|27|Registry|32-step 正常轨迹 warmup 后 registry 恒定61；最终 fatal batch 不作 stress PASS|
|28|Communication/deadlock|正常控制/N1 regression 正常退出；KH exit136 非 timeout/clean rejection；无残留测试进程|
|29|S1 regressions|fresh topology/support/audit 和 frozen serial phase PASS；实际结果保留，S1 不改|
|30|Serial regressions|R2B252194/I112083/C217 assertions，均0failure；serial phase17 PASS|
|31|Foundation hashes|6717 source +19 native parcel hashes PASS|
|32|Project hashes|2742 protected entries 全部一致，除随后获授权的 milestone append；新目标独立 hashes|
|33|Active solver impact|NONE|
|34|Production mesh/BC impact|NONE|
|35|S2 COMPLETE?|NO|
|36|S3 next round?|NO；先解除 S2 blocker 并全部满足 S2 gate|
|37|T4|PARTIAL|
|38|M8A/M6B/CFD|PARTIAL /NO /NO；production restart NOT CERTIFIED|
|39|Milestone matrix|见下表及 append-only MILESTONE_STATUS.md|

## Milestone matrix

|Milestone|Status|
|---|---|
|R2-FINAL / T3|COMPLETE / FROZEN，serial passive scope|
|T4-S1|COMPLETE / FROZEN，two-rank support scope|
|T4-S2-C1-N1|COMPLETE / FROZEN，原限定通信失败收尾范围不变|
|T4-S2-R1-NATIVE|PARTIAL / MPI_OWNERSHIP_BLOCKER|
|T4-S2|PARTIAL|
|T4-S3|NOT AUTHORIZED|
|T4 / M8A|PARTIAL / PARTIAL|
|M6B / CFD|NO / NO|
|Production restart|NOT CERTIFIED|

STOP. 不执行 S3、global MPI transaction、active integration、M6B、production restart 或 CFD。
