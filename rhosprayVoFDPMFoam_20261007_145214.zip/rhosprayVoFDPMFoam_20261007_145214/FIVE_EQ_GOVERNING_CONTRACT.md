# Final five-equation governing contract — M5B.1

Design only; no fields or equations are activated. This contract refines M5B
and is authoritative for future activation. First activation = ALLAIRE_BASELINE.

## Independent state and meaning

    alphaG = 1-alphaL
    mG = alphaG*rhoG; mL = alphaL*rhoL
    rho = mG+mL; M = rho*U
    Qc = [mG,mL,Mx,My,Mz,Et]
    material state = alphaL

Masses are mass per total Eulerian volume (kg/m3), not per-cell kg or intrinsic
densities. M has momentum/volume units; Et is J/m3. In 3D there are six
conservative scalar components plus one material scalar; "five equations"
counts two phase mass laws, one vector momentum law, energy and alpha.
Gas species add mG*YG_j; gas composition is frozen for acoustic/root evaluation.
The name YG is reserved for gas species; use wG=mG/rho for gas material mass
fraction in acoustics to avoid confusion.

    Et = mG*eG(rhoG,p,YG)+mL*eL(rhoL,p)+|M|^2/(2*rho)

There is common p and U; TG and TL need not agree. A mixture temperature is
not a primary state or closure. Energy references must be canonical and
documented before M6A2. Interface cell mixing is a diffuse material closure,
not a vapor/liquid equilibrium or cavitation EOS.

## Source-free inviscid PDE baseline

    dt(mG)+div(mG*U)=0
    dt(mL)+div(mL*U)=0
    dt(M)+div(M tensor U+p*I)=0
    dt(Et)+div((Et+p)*U)=0
    dt(alphaL)+U.grad(alphaL)=0               [Allaire]

Optional later Kapila material law replaces only the final equation with
Dt(alphaL)=K_L*div(U), with matched Kapila acoustics. Viscosity, heat conduction,
capillary force/work, DPM sources, phase change and transfer are **separate
later operator contracts**; no unapproved sources are implied by these PDEs.
When DPM is enabled its gas material sources must close an Eulerian/parcel
ledger; DPM does not appear in alphaG+alphaL=1.

## Shared KT conservative face family

Recover each common reconstructed state (Qc+,alphaL+,YG+) and (Qc-,alphaL-,YG-).
Use admissible EOSs, the selected model's cMix and the same reconstruction,
time level and geometry for all fluxes. With outward face vector Sf:

    q+ = U+.Sf-meshPhi; q- = U-.Sf-meshPhi
    ap=max(q++cMix+*|Sf|,q-+cMix-*|Sf|,0)
    am=min(q+-cMix+*|Sf|,q--cMix-*|Sf|,0)
    a+=ap/(ap-am); a-=1-a+; aSf=am*a+
    A+=a+*q+-aSf; A-=a-*q-+aSf
    F_mG=A+*mG+ + A-*mG-
    F_mL=A+*mL+ + A-*mL-
    F_rho=F_mG+F_mL
    pHat=a+*p+ + a-*p-
    F_M=A+*M+ + A-*M- + pHat*Sf
    F_E=A+*(Et++p+) + A-*(Et-+p-) + aSf*(p+-p-)
        + meshPhi*pHat                         [moving mesh]

meshPhi=0 for a fixed mesh. This preserves absolute pressure work while mass
transport is relative to mesh motion. It is the algebra of the current
phi/phiUp/phiEp family, not a new Riemann flux. Preserve the existing Tadmor
option's half weights/spectral bound if retained; handle zero wave denominator
with an explicit consistent limiting branch, never 0/0. No final mass flux
may be reconstructed as rhoL*alphaPhi+rhoG*(phiV-alphaPhi).

## Nonconservative discrete contract and remaining activation proof

The PDE above is frozen. Its KT alpha numerical flux/velocity trace/source
must be derived together with this conservative family in M5C/M6B. A consistent
candidate uses common weights/dissipation for alpha and a shared velocity
trace; no MFC Riemann velocity may be pasted into it. MULES corrections and
subcycling cannot create unmatched phase-mass/energy updates. The precise
limiter/path discretization remains an explicit activation gate, not a claimed
completed implementation. No discrete contact preservation is inferred from
common weights alone. See FIVE_EQ_UNIT_TEST_CONTRACT.md.

## Pure limits and regression scope

At exact pure gas mL=alphaL=0: rho=rhoG, Et=rhoE, cMix=cG and gas thermo
recovers p. At exact pure liquid: gas EOS is never called; pressure follows
liquid EOS/Et and cMix=cL. With identical directional face states, wave speeds,
reconstruction, limiter and energy reference, the gas flux family must match
legacy phi,phiUp,phiEp including moving-mesh work. Existing gas face pressure
uses independently reconstructed rho*(1/psi); generic recovery of reconstructed
Qc can differ for nonlinear JANAF. Therefore pure-gas equality is conditional
on **identical reconstructed states**, and changed reconstruction needs a
separate regression decision; it must not be claimed automatic.

## Acoustic CFL and later physics

Face spectral scales use max(|q+|+cMix+*|Sf|,|q-|+cMix-*|Sf|). A conservative
unstructured acoustic budget is dt*sum_f(lambda_f)/V <= selected CFL,
with the exact legacy Courant normalization retained in pure-gas regression.
Do not use gas sound speed in liquid-rich cells. This is no unconditional
positivity guarantee; later alpha/source/viscous/capillary/tracking restrictions
must also hold. M7 capillary force acts on mixture M with consistent total-energy
work (and surface-energy accounting choice). DPM carrier view is rhoG,U,TG,YG.
