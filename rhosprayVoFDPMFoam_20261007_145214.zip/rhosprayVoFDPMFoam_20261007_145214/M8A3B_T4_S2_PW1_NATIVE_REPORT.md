# M8A.3B-T4-S2-PW1-NATIVE

Date: 2026-10-04. Qualification of native computational-parcel weighting only.
Evidence: `fitting/dpm/m8a3b_t4_s2_pw1_native_v1/PW1_gate.json`.
Final independent target: `tests/fiveEqDPMPW1Native/testPW1Native`.
Final executable SHA256: `250b22a14b1d70350046752105e52d5f74a778f1567c56dc82befabe7be7be48`.

## 1. PW1 status

**COMPLETE / OF7-NATIVE WEIGHTED PARCEL QUALIFIED**. 57 evidence gates PASS,
zero failed gates. No R1 FINAL promotion. S2 remains PARTIAL.

## 2. OF7 native weighting source audit

Actual local Foundation7 InjectionModel.H/.C, ConeInjection.C, fixedValue.C,
VoidFraction.C and ReactingParcel.C were read with line numbers. See
OF7_PARCEL_WEIGHTING_AUDIT_v1.md and native_source_audit.txt. No source from a
different OpenFOAM branch was substituted. Native weighting is AVAILABLE.

## 3. Exact native dictionary semantics

`parcelBasisType mass` selects pbMass. Other actual options are `number` and
`fixed`; fixed additionally reads `nParticle` and ignores massTotal.
Transient `massTotal` is event physical mass; steady massFlowRate uses Function1.
Cone requested count is `floor(parcelsPerSecond*time1-parcelsAddedTotal)` with
time relative to SOI. Duration bounds and zero-count interval carry-over apply.
Selected mass basis sets

`nParticle = intervalFraction*(massTotal/rho)/(Nrequested*pi*d^3/6)`.

The interval fraction is the native integrated flow profile divided by total
profile integral plus rootVSmall. fixedValueDistribution `{ value 0.00025; }`
is confirmed from the local distribution implementation.

## 4. Whether custom code was needed

No custom weighting/merging/superparcel/native injection implementation.
The frozen existing ExceptionSafeConeInjection/ConeState orchestration remains
present and unchanged; its weighting method delegates to native InjectionModel.
New test main reads the existing birth hook, counts native requests, exports state,
and uses existing transactionState-v1 plus serial R2A/S1 query bindings.
PW1FaceObserver is a read-only test observer over the existing trajectory check;
it delegates native postFace and does not change keepParticle, parcel, RNG or theta.
It is not a new physical model or transport mechanism. Actual isolated target
delta consists of main and Make/files only; all copied parcel/model headers match.

## 5. Physical injection mass definition

For each computational parcel:

`representedMass = nParticle*rho*pi*d^3/6 = nParticle*parcel.mass()`.

Birth data are captured from the actual native returned weight and initialized
parcel state before first evolution. Remaining cloud mass is checked separately.
No mass renormalization or post-injection deletion is used.

Deterministic control: 0.0001s window, mass5.262723452e-8kg, corresponding to the
historical test's mass rate0.0005262723452kg/s; all four levels use identical
physical state, native velocity rule, fixed250um diameter and300K composition.
Actual birth density725.21967199798883kg/m3 comes from native C10H22 properties,
not nominal730. Birth velocity53.75355658461136m/s. Control geometry is explicitly
an isolated eight-cell migration fixture, not the production injector geometry.

An earlier control retained the full1s event mass in0.0001s and produced an
undesirably high native velocity; its normal-exit data remain under ladder_* and
high_mass_rate_attempt.json. It is not the accepted control. A missing C10H22
initial-field copy attempt and two harness initialization attempts are retained
as labeled logs; no physics repair was inferred from them.

## 6. Ncomp=1 result

Requested/actual1/1; mass5.2627234520000005e-8kg; relative error1.2574e-16;
mean birth nParticle8.8699735486846. Positive/finite, unique identity, exit0.

## 7. Ncomp=10 result

Requested/actual10/10; mass5.262723452e-8kg; relative error0;
mean birth nParticle0.8869973548684598. Positive/finite, unique identities, exit0.

## 8. Ncomp=100 result

Requested/actual100/100; mass5.2627234520000005e-8kg; relative error1.2574e-16;
mean birth nParticle0.088699735486846. Positive/finite, unique identities, exit0.

## 9. Ncomp=1000 result

Requested/actual1000/1000; mass5.262723452000001e-8kg; relative error2.5148e-16;
mean birth nParticle0.008869973548684601. Positive/finite, unique identities, exit0.

## 10. nParticle scaling

Mean birth multiplicity scales inversely with computational count, preserving
physical mass. Native scalar multiplicity can be fractional; positivity is the
required gate, not nParticle==1 or nParticle>=1. N1 and the bounded candidate
directly demonstrate computational objects representing multiple droplets.
Actual post-evolution weights may change through native diameter/mass handling;
all individual birth values, allocator and RNG states are retained in CSV.

## 11. Total represented mass

All ladder levels have the same target5.262723452e-8kg, maximum injection relative
error2.5148e-16, below1e-12 without any correction.
Candidate integrates the full historical mass0.0005262723452kg exactly in the
offline sum. Candidate remaining cloud mass differs only at roundoff scale after
native evolution. Its total target is not a new production fuel-flow definition.

## 12. Identity

Native origProc/origId used; no droplet/subparticle/packet IDs. Ladder birth IDs
unique globally; native per-step MPI ownership checks pass. Candidate50 distinct
identities each have one complete send/receive quartet.

## 13. Allocator

Actual particle::particleCount_ captured at every birth and step. Constructor and
stream paths remain native/frozen ID1. Candidate per-step lifetime counters balance;
transaction discard restores accepted allocator exactly. No custom ID assignment.

## 14. Native tracking

All evolution is cloud.evolve with frozen parcel/native tracking methods. No
teleport, manual transfer, hand-flipped velocity or post-injection count cap.
Final eight-run matrix uses one executable hash. Per-step finite/tet/cell/state,
lifetime, generation and registry gates pass.

## 15. Native MPI migration

Candidate50 successful0→1 processor crossings, normal exit. Reverse0: both
directions were desirable but not the required>=10 gate. These are native
Cloud::move / prepare-correct / streams-iNew transfers of actual parcel objects.
No bulk packet scheme. Historical4,244,131 batch evidence is untouched.

## 16. Multiplicity migration parity

All50 quartet comparisons preserve nParticle, d, rho, U, T, Y and physical/history
scalar bits through send-after-prepare→receive-before-correct and send-before→
receive-after-correct. Represented mass therefore has no migration multiplier.

Serial/MPI single weighted parcel spot: same identity at corresponding x=4
internal/processor face; all compared physical/history fields bit-equal except
tMom0.04828619230320206 vs0.04828619230320203 (4ULP). Comparison permits only
native double roundoff for that field, bounded by32machine-epsilon relative;
multiplicity remains bit-exact. MPI transmitted fields themselves are bit-exact.

At final time, nParticle,d,T,Y/identity and nonstochastic histories match; U,
UTurb and tMom differ after rank-local native stochastic continuation. Values
are tabulated in PW1_gate.json. No full serial/MPI stochastic trajectory parity
or R1 RNG-next certificate is claimed. RNG was not synchronized or altered.

## 17. Source weighting

Actual local N1 drag/source spot has native source momentum magnitude
1.4754029889580382e-9kg*m/s and represented-momentum balance residual
3.1482494113768233e-21kg*m/s, normalized1.1129e-15 by initial represented momentum.
All ladder source checks pass; largest normalized residual3.2634e-14.
Single-parcel control remains in one cell without rebound/processor crossing,
so this is a local native event/interval observation, not an S3 global ledger.
The candidate's aggregate momentum diagnostic includes wall impulse and multiple
steps: it is explicitly NOT treated as a zero-external-impulse source residual.

## 18. VoidFraction weighting

Native theta uses `sum(dt*nParticle*singleDropletVolume)/(deltaT*cellVolume)`.
Existing TrajectoryVF computes a separate expected residence and checks actual
theta per cell bitwise. Ladder observed native postMove segments8/62/620/6200;
all native trajectory checks pass, including candidate. These counts are
segments, not numbers of parcels or Cloud::move calls. No extra theta weighting.

## 19. Double-weighting audit

Injection delegates setNumberOfParticles; native source np0 is applied once;
nativeCellTransfer reads already aggregated source fields without multiplicity;
SourceAdapter.convert has no nParticle factor. Parcel endpoints use multiplicity
once for independently represented conservation quantities. Theta expectation
is read-only. Deferred helper is not layered onto native theta. Breakup child
weight uses represented child mass/single-droplet mass, not another source factor.
Selected numbered project source and SHA records saved in project_adapter_audit.txt
and adapter_source_sha.json. No DOUBLE_WEIGHTING_BLOCKER found.

## 20. KH/breakup compatibility

Native atomization and KH execute with positive finite weighted states. Candidate
actual diameter changes and both-rank KH counters recorded; population remains50,
so no fresh KH child event is claimed. Existing K1/ID1 child path and ZS1 exact-zero
policy remain hash-protected, not retested/promoted as a new R1 FINAL gate here.
No native ReitzKHRT source change or breakup-after-merge mechanism.

## 21. ORourke limitation note

Native ORourke configuration and implementation retained. Fewer computational
parcels change stochastic collision sampling resolution: NATIVE-PHYSICS-LIMITATION.
No collision-statistics convergence or new physical collision-model certificate.

## 22. Stochastic limitation note

Native stochasticDispersionRAS executes with finite state. Rank-local RNG semantics
remain native and serialized by existing transaction handling; observations do not
draw additional RNG samples. Fewer samples do not establish converged spray statistics.

## 23. Rollback

rollback_final starts with a real natively injected weighted accepted parcel,
then evolves an ordinary disposable trial and prepares pending output before discard.
Accepted before/after parcel serialization exactly equal on both ranks. Full
transactionState-v1 key/carrier snapshot, RNG, sources, identities/multiplicity,
allocator, registry/lifetime and no-publication gates pass. No weighted codec added.

## 24. Bounded R1 candidate

Only changed dictionary entry versus original exact replay: parcelsPerSecond
21220659→50 in isolated role dictionaries. SOI1s, duration1s, massTotal,
RosinRammler200–300um distribution, composition,300K, cone geometry, flow profile,
native flowRateAndDischarge/Cd velocity rule and all physical model coefficients
are unchanged. No seed parcel; all candidate parcels originate by native injection.
Original high-population fixture and checkpoints remain immutable.

## 25. Parcel population

Per-step requests/actual additions0,0,0,0,0,10,10,10,10,10,0,0.
Global cloud population0,0,0,0,0,10,20,30,40,50,50,50.
No millions batch, uncontrolled post-event growth, runtime cap or manual deletion.
Per-step requested/actual count, mass, query calls, elapsed evolution time,
allocator/RNG and model counters recorded. Birth mean nParticle1471.5246314660292.

## 26. Crossing count

50 candidate crossings plus one separate weighted MPI parity spot.
PW1 >=10 gate PASS using candidate50 alone. This is NOT the>=1000 R1 FINAL stress.

## 27. Runtime/timeout

Final external wall seconds including process start/exit:

| Fixture | Wall s | Exit |
|---|---:|---:|
| N1 | 1.13 | 0 |
| N10 | 0.75 | 0 |
| N100 | 0.84 | 0 |
| N1000 | 1.40 | 0 |
| Candidate12steps | 1.34 | 0 |
| Weighted rollback | 0.76 | 0 |
| Serial spot | 0.28 | 0 |
| MPI spot | 0.82 | 0 |

All under the unchanged55s watchdog. These are bounded fixture measurements,
not a production-performance or speedup prediction. Earlier failed harness setup
attempts are retained separately and not counted as physical compatibility failures.

## 28. Foundation hashes

Fresh post-test6717Foundation checks and19native parcel checks PASS.
No InjectionModel/ConeInjection/Cloud/native model/parcel IO/Foundation modification.

## 29. Project hashes

24232 protected entries unchanged at pre-append audit. Shared source delta NONE;
new isolated main/Make target and read-only tooling/documents only. Milestone history
is appended, with original prefix length/SHA verified at checkpoint closing.
Earlier reports, test binaries, ZS1/ID1/S1/N1/C2/transaction certificates preserved.

## 30. Active solver impact

NONE. No thermo/EOS/pressure/KT/VOF/DPM runtime activation.

## 31. Production input impact

NONE. 300_2D mesh, BC, injection schedule and dictionaries unchanged.50/s is a test
fixture sampling rate, not a production selection. Native fractional ladder weights
do not authorize a production parcel budget without later CFD convergence studies.

## 32. Whether PW1 COMPLETE

YES, limited to native weighted representation, basic model/source/theta compatibility,
rollback and migration semantics documented above. No merging architecture needed.

## 33. Whether R1 FINAL may resume NEXT ROUND ONLY

Qualified bounded candidate is available for a separately authorized R1 FINAL
round. RNG-next, dedicated fresh stochastic/drag, repeatedVF, >=1000 valid crossings,
final registry/lifetime and full S1/N1/serial matrices were not executed as final gates.
Future stress should use independent bounded runs with normal exit and native ownership,
not millions of parcels in one process. No automatic resume in this round.

## 34. T4-S2 status

PARTIAL until R1 FINAL closes. PW1 does not upgrade earlier partial certificates.

## 35. T4/M8A/M6B/CFD matrix

| Stage | State |
|---|---|
| R2-FINAL/T3; T4-S1; C1-N1; ZS1; ID1 | Existing COMPLETE/FROZEN scopes retained |
| KH-FPE1/FPE2; TIMEOUT-D1 | Existing DIAGNOSIS ONLY scopes retained |
| PW1 | COMPLETE / OF7-NATIVE WEIGHTED PARCEL QUALIFIED |
| R1 FINAL / T4-S2 | PARTIAL / PARTIAL |
| T4 / M8A | PARTIAL / PARTIAL |
| S3 | NOT AUTHORIZED / NOT EXECUTED |
| M6B / CFD | NO / NO |
| Production restart | NOT CERTIFIED |

STOP. No production convergence, runtime merging, remaining R1 FINAL,
>=1000 final stress, S3, active integration, M6B, production restart or CFD executed.
