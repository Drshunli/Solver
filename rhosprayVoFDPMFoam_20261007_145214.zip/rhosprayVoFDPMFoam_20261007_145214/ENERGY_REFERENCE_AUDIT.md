# M6A1 gas, Eulerian liquid, and DPM energy-reference audit

## M6A1b-2A.2 actual reference-EOS query (30 September 2026)

CoolProp 8.0.0 HEOS n-Decane native DEF was queried without changing its reference state. At 3 MPa, 300 K it gives e=-369296.369049 J/kg, h=-365172.277674 J/kg, s=-993.782257318 J/(kg K), rho=727.432960546 kg/m3. These are **REFERENCE-EOS GENERATED** native-relative quantities, not experimental absolute/formation energies. Negative e/h do not invalidate this reference. `h-e-p/rho` is approximately -2.4e-6 J/kg.

The zero is operationally pinned by the exact fluid-definition hash and ideal Helmholtz coefficients (lead a1=13.9361966549, a2=-10.5265128286), with a numerical anchor h=-425742.187419 J/kg and s=-1191.008351 J/(kg K) for saturated liquid at 273.15 K. This is not assumed equal to IIR, NBP, gas JANAF or parcel sensible zero. Snapshot: `fitting/n-Decane_backend_definition.json`; query evidence: `fitting/M6A1b2A2_reference_queries.json`. [CoolProp reference-state documentation](https://coolprop.org/coolprop/HighLevelAPI.html#reference-states).

An explicit constant Delta can shift both e and h to a declared ledger zero without changing p/rho, Cp, Cv, c or mechanical derivatives. The mathematical possibility is verified by the identities, but no numerical gas/liquid/parcel mapping, q or solver Et initialization is performed. Delta and transfer/source energy reconciliation remain pre-M6A2/M8 gates. The selected liquid adiabatic-mechanical scope does not require mapping these native negative values into active runtime energy this round.

The current `300_2D/constant/thermophysicalProperties` configures `hePsiThermo/reactingMixture/janaf/perfectGas/sensibleInternalEnergy`; `createFields.H` binds `e=thermo.he()` and constructs `rhoE=rho*(e+|U|^2/2)`. The gas JANAF coefficients, including gas C10H22, are in `300_2D/constant/thermal.dat`.

## M6A1b-1 energy-reference gate (29 September 2026)

Re-read the local Foundation 7 implementation at
`/home/zsl/software/OpenFOAM/OpenFOAM-7/OpenFOAM-7/src/thermophysicalModels/specie/thermo/janaf/janafThermoI.H` (lines 200 onward), `thermo/thermo/HtoEthermo.H`, `thermophysicalProperties/liquidProperties/liquidProperties/liquidPropertiesI.H` (lines 102–126), and `lagrangian/intermediate/submodels/Reacting/CompositionModel/CompositionModel/CompositionModel.C` (lines 331 onward). `janafThermo::Hs=Ha-Hc`; `Hc` evaluates the low-temperature JANAF enthalpy at `Tstd`. `HtoEthermo::Es=Hs-p/rho`. The base `liquidProperties::Ha` and `Hs` both return `h(p,T)` and its `Hc()` returns zero. In contrast, for a liquid parcel, `CompositionModel::Hs` is `liquid.h(p,T)-liquid.h(p,298.15)` and its `Hc` is `liquid.h(p,298.15)`. These definitions confirm that neither a raw OF7 liquid `h` nor the gas `Es` is an automatically shared absolute energy zero.

The local `lagrangian/intermediate/submodels/Reacting/PhaseChangeModel/LiquidEvaporationBoil/LiquidEvaporationBoil.C` `dh()` selects `liquid.hl(p,T)` for latent-heat transfer or `carrier.Ha(p,T)-liquid.h(p,T)` for enthalpy-difference transfer. This was checked in source; it must be reconciled with parcel sensible `Hs` when phase change is eventually activated.

The current case still sets `heatTransferModel none` and `phaseChangeModel none`; the liquid parcel thermal path and latent enthalpy are inactive for the present purely mechanical breakup case. That does not remove the energy-reference gate for future five-equation total-energy pressure recovery, parcel creation, evaporation or reaction. In particular, measured `Cp(T,p)` determines enthalpy **differences** after integration, not absolute `h`/`e`; the 2017 calorimetry table supplies no value for `q`.

**Status: unresolved.** No `(pRef,TLRef,rhoLRef,eLRef)` jointly aligned to gas JANAF and parcel liquid reference has been approved. The local candidate formula `q=eLRef-Cv*TLRef-pInf/rhoLRef` is an identity only, and the constant-SG model is now structurally rejected. Its `q` must not be set or promoted. For a replacement EOS, first declare its enthalpy/internal-energy zero, the gas JANAF `Hs/Hc` convention and the parcel `h/hl` convention; verify the phase-change enthalpy jump before any VOF↔DPM energy transfer.

## M6A1b-2A selected strategy: native offsets plus explicit transfer correction

Two options were compared. A single physical absolute/formation reference for all phases is elegant but would require changing or translating the existing OF7 gas JANAF sensible-energy and parcel liquid APIs throughout runtime immediately. **Selected design B:** preserve each backend's native energy convention, declare a canonical *ledger* reference and store an explicit offset `Delta_k` for gas species, Eulerian liquid and DPM liquid so `e_k,canon=e_k,native+Delta_k`; the gas-mixture offset is composition-weighted from species offsets. This is a design choice, not a numerical offset. For a phase/material transfer `delta_m` from donor `d` to receiver `r`, the native-energy source bookkeeping must include the offset difference `delta_m*(Delta_d-Delta_r)` (with matching enthalpy/flow-work treatment) so canonical total energy is conserved. The same mapping is needed for evaporation, VOF→DPM and DPM→VOF.

With phase masses separately conserved and no interphase mass/heat transfer, a consistent constant offset can be carried in the initialized/advected total energy and does not change a pure-phase mechanical EOS. It **does** alter common-pressure recovery if only the EOS energy is shifted while `Et` is not. Before M6A2, freeze the ledger reference, map JANAF `Hs/Hc`, OF7 parcel `h/hl` and the selected liquid EOS `e/h`, then test pure-gas and pure-liquid pressure recovery under equivalent energy-zero shifts. No formation or latent offset has been guessed here.

Foundation 7 `specie/thermo/janaf/janafThermoI.H` defines `Hs=Ha-Hc`, with `Hc` evaluated at `Tstd`. `specie/thermo/thermo/HtoEthermo.H` defines `Es=Hs-p/rho`; `sensibleInternalEnergy.H` selects `Es` as `HE`. Thus the active gas `e` excludes the JANAF chemical enthalpy `Hc`, **but** its pure-species value at `Tstd` is `-p/rho` (for the configured perfect gas, `-R_i*Tstd`), not identically zero. Composition and reaction/source conventions must be preserved during future phase-energy exchange.

Foundation 7 `liquidProperties/liquidProperties/liquidPropertiesI.H` returns the correlation `h(p,T)` from both `Ha` and `Hs`, and `Hc=0`. Its liquid `h` is a separate correlation, not automatically on the same zero as gas `Es`; `hl` is latent heat. Spray parcels continue to use the existing `SLGThermo/liquidMixtureProperties` conventions. They are not changed here.

In the candidate Eulerian stiffened gas, `q` fixes the internal-energy zero: `e=q+Cv*TL+pInf/rhoL`. It must be calibrated so phase energies and any future vaporization/VOF-to-DPM transfer share a declared reference state. A material identity match (`component=C10H22`) alone does not determine `q`. Before M6A2/M8 activation, specify `(pRef,TRef,rhoRef,eRef)` and how `eRef` relates to the gas JANAF sensible energy and liquid parcel enthalpy/latent heat; check the interface energy jump and source bookkeeping. No reference-energy constant was guessed in C++ or in a case dictionary.

Mechanical equilibrium (`pG=pL`) does not require `TG=TL`. In M4 the gas `T` is only used to query a provisional liquid property diagnostic. Future liquid `TL` must come from its own thermo state. The proposed phase-energy sum `mG*eG+mL*eL` is meaningful only after the reference convention is fixed.

## M6A1b source-level clarification

Local Foundation OF7 `etc/controlDict` standard SI `Tstd` is 298.15 K.
`lagrangian/intermediate/submodels/Reacting/CompositionModel/CompositionModel/CompositionModel.C`
distinguishes parcel phases as follows:

| API | Gas C10H22 | Liquid C10H22 |
|---|---|---|
| `H` | carrier `Ha(p,T)` | `liquidProperties::h(p,T)` |
| `Hs` | carrier `Hs(p,T)` | `h(p,T)-h(p,298.15)` |
| `Hc` | carrier JANAF `Hc()` | `h(p,298.15)` |

Thus the liquid parcel **sensible enthalpy zero** is explicitly 298.15 K
in this composition model, even though the base `liquidProperties::Hs`
method itself returns `h(p,T)`; consumers must not conflate the two APIs.
`SprayParcel.C` updates parcel `Cp`, `sigma`, `rho`, and `mu` through the
`liquids()` database. `ReactingParcel.C` deposits carrier-species `Hs`
with evaporated/absorbed mass into `hsTrans`; `ThermoCloud::Sh` converts
that storage to a gas energy source. The active case sets both
`heatTransferModel none` and `phaseChangeModel none`; the configured
`liquidEvaporationBoilCoeffs.enthalpyTransfer enthalpyDifference` is dormant.
If enabled later, OF7 `LiquidEvaporationBoil::dh` uses either `hl(p,T)` or
`carrier.Ha(p,T)-liquid.h(p,T)` according to its configured mode.

### Proposed common **sensible** convention, pending validation

Choose explicit `(pRef,TRef)`, preferably `TRef=298.15 K` to match both
OF7 JANAF `Tstd` and parcel liquid `CompositionModel::Hs` subtraction.
For the same physical liquid, define a reference liquid sensible enthalpy
`hL,sens,ref = hOF7(pRef,TRef)-hOF7(pRef,298.15)` (zero if `TRef=298.15 K`).
Then define `eL,ref = hL,sens,ref - pRef/rhoL,ref` and, once a calibrated
`rhoL,ref` and `(gamma,pInf,Cv)` exist,

```text
q = eL,ref - Cv*TRef - pInf/rhoL,ref.
```

The gas counterpart is `eG,sens=Hs,JANAF-p/rhoG`; its reference value is
not zero even where `Hs,JANAF=0`. This proposal aligns **sensible** phase
enthalpy labels; it does not assert that gas and liquid formation enthalpies
or latent heat vanish. The difference `Hc,gas-Hc,liquid` and the active
energy/source implementation must be checked before evaporation or
VOF-to-DPM transfer. No numeric `q` is accepted until the pressure,
temperature, density reference and chosen energy convention are approved.

## M6A1b-2A.3 coordinate-offset QA

Native CoolProp DEF e/h are retained. The gas/Eulerian liquid/DPM absolute reference mapping and production q remain UNRESOLVED. For constant Delta, e'=e+Delta and h'=h+Delta imply p'(rho,e')=p(rho,e'-Delta). Thus dp/drho at fixed e, dp/de at fixed rho, de/dp at fixed rho, c and the physical PT domain are invariant. Offline QA uses deliberately arbitrary Delta=1e6 J/kg and obtains zero relative difference at the reference state; this test value is NOT a chosen physical offset, does not reset backend reference state and does not initialize solver energy. Negative native e/h are legal. 2A completion is a design-domain gate only; canonical energy mapping remains a separate pre-M6A2 requirement.

## M6A1b-2B explicit sensible ledger mapping

The reference mapping is now numerically defined, using a declared sensible enthalpy anchor at 3 MPa / 298.15 K: C_L_reference=369229.953724952764 J/kg. See fitting/competition/ndecane_m6a1b2b_v1/energy_reference_mapping.json for candidate-specific offsets, gas Delta=0, DPM Hs/raw-h translations and caloric mismatch. This is a common sensible ledger, not measured common absolute formation energy. No candidate accepted, so production-specific offset remains unpromoted. Gas JANAF chemical Hc and latent/enthalpyDifference source treatment remain separate; no conversion/source activated. Existing earlier UNRESOLVED notes are historical; current numerical reference mapping is explicit, production model selection is still open.

## M6A1b-2B.3A candidate offsets and DPM ledger

Reference offset retained. Model-specific candidate offsets and invariance checks are in fitting/competition/ndecane_m6a1b2b_3a_v1/candidate_energy_offsets.json. No production offset promoted because HARD coverage fails. VOF-to-DPM conversion still requires a state-dependent physical energy ledger; equal-temperature sensible enthalpy is not made identical by a constant shift. No transfer/evaporation implementation added.


## M6A1b-2B.3B frozen standalone model reference (current)

Production ndecane_gibbs_v1 C_L=369229.9537234281 J/kg, defined as -h_native_model at p=3 MPa,T=298.15 K. This model-specific constant shifts e and h identically. Reference-EOS C_L=369229.95372495276 J/kg remains a separate reference datum, not the production constant. Default standalone API uses the production sensible ledger; offset0 is native-validation-only. Gas JANAF Es and gas offset0 are unchanged. OF7 DPM Hs remains unchanged; its state-dependent caloric difference, pressure work and kinetic-energy transfer require a future conservative ledger. No conversion, evaporation coupling, common-pressure recovery or active solver mapping was implemented. The former unresolved liquid constant is resolved for this frozen standalone EOS; future cross-model energy transfer remains open. See liquidEOS/ndecane_gibbs_v1/energy_reference.json and API_CONTRACT.md.


## M6A2.1 standalone completion

M6A2.1 uses native OF7 JANAF Es for gas and frozen model-specific liquid C_L inside the standalone adapter. Offset-invariance tests pass. DPM caloric mismatch remains unresolved and blocks later DPM energy transfer, but user excluded that coupling from this standalone gate. See M6A2_1_STANDALONE_STATE_RECOVERY.md and tests/fiveEqRecovery/test_results.json.

## M5C.3 temporal/source ledger audit (2026-10-01, NOT ACTIVE)

The local Foundation7 StandardChemistryModel::Qdot implementation is -sum(Hc_i*RR_i), while laminar::R(Yi) supplies RR_i and its correct() integrates/calculates chemistry before legacy species solves. noCombustion::R/Qdot are zero; the current three-species case has no enabled reactions. Gas Es=Hs-p/rho and Hs=Ha-Hc remain unchanged. Future bulk gas species source S_i must pair Et_sens source -sum(Hc_i*S_i), preserving Et_sens+sum(mYi*Hc_i) for a closed mass-conserving chemistry substep. Intrinsic gas-volume rates require alphaG conversion once; already bulk-integrated rates must not be weighted again. A passive actual-Hc identity test passes, including trace weighting. This does not validate reaction integration or transport.

The future source stage must recover a complete new Q/P2 tuple and reject it atomically on failure. Reactive activation is a PRE-M6B BLOCKER until a real mechanism, gas-state rate/volume adapter and coupled source-step tests exist; otherwise chemistry-on is explicitly rejected. DPM hsTrans remains an enthalpy transfer ledger, not automatically Et; pressure work, mass/kinetic/drag work and DPM-to-production liquid reference/caloric mapping belong to mandatory M8A. No q, gas JANAF zero, production liquid offset, recovery numerical order or active source placement changed. See docs/FIVE_EQ_SOURCE_OWNERSHIP_AUDIT.md.


## M8A conservative DPM source gate (2026-10-01)

Standalone candidate uses actual raw OF7 parcel h and JANAF Hc. dEt=HB-HA-sum(Hc_i dmYi)+KB-KA+p*(VA-VB) at held p, plus explicitly modeled external heat/work (zero in unit tests). Pressure work is internal, never an invented external residual. Native hsTrans, frozen-Cp, KE omission, U0 alias and deletion approximations are separated by explicit corrections. Eulerian C_L is not used for vapor sources. See docs/DPM_EULERIAN_ENERGY_REFERENCE_LEDGER.md and M8A_DPM_SOURCE_ENERGY_GATE.md. M8A remains PARTIAL due to real production carrier-path guard and complete cloud transaction blockers. No active source/chemistry change.
