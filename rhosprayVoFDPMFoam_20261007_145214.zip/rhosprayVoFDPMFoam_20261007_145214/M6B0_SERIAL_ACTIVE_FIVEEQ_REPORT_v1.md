# 1. M6B.0 status

**COMPLETE / SERIAL ACTIVE FIVE-EQUATION BOOTSTRAP**；316项PASS。仅一维周期串行固定单位截面积micro-case认证；不是production CFD validation。

# 2. Active authority

实际solver -serialFiveEq分支中的accepted Q/P2为唯一authority。rhoMix=mG+mL，U=M/rhoMix，Et=mG eG+mL eL+½rhoMix|U|²。

# 3. Old-core isolation

前置return在旧createFields/cloud/interface前；old rho/rhoU/rhoE方程不执行，原方程字节unchanged。详见authority audit。

# 4. Active fields

| Field / state | Owner | Created / updated | Meaning |
|---|---|---|---|
| P2 | TemporalState.committed[i].fraction | exact P2Bits fresh input; frozen advanced() | signed binary64 minority; +0 pure gas / -0 pure liquid |
| mG / mL | q[1/2] | frozen shared KT candidate and whole commit | phase partial densities |
| M | q[3:6] | same transaction | mixture momentum density |
| Et | q[6] | same transaction | mG eG+mL eL+0.5 rhoMix U² |
| mY_C10H22 / mY_O2 | q[7/8] | shared species flux | N-1 independent species |
| mY_N2 | q[9] | algebraic residual, then revalidate | mG-mY_C10H22-mY_O2; no normalization |
| q[0] / alphaL | P2 decoded mirror | frozen P2 trial / accepted publication | not a second alpha authority |
| alphaG | P2.gasValue() | accepted publication | not 1-rounded alphaL; preserves trace gas |
| rhoG / rhoL | frozen R1 | whole accepted-state recovery | absent phase output=0, no fake phase |
| rhoMix / U / p / TG / TL / YG_* | accepted Q/recovery | publish only after all recoveries succeed | derived, no independent PDE |
| 20 volScalar/VectorFields | runSerialFiveEq | register once, lookup owner checks | OpenFOAM output mirrors of accepted Q |
| old rho / rhoU / rhoE / phi | isolated legacy branch | not created by serialFiveEq | frozen historical reference |


# 5. P2 authority

精确signed binary64 P2Bits初始化，冻结advanced()更新。+0/-0和±1e−20精确保留；alphaL/alphaG派生，无第二authority。

# 6. Pressure recovery

冻结R1：Eint=Et−½M·U；R=mG eG(rhoG,p,YG)+mL eL(rhoL,p)−Eint，R′=mG betaG+mL betaL。Pure-phase原分支unchanged；无pEqn/PIMPLE/替代root/new EOS fallback。

# 7. Gas thermo

冻结fiveEqGasThermoEvaluator复用Foundation7 specie/perfectGas/JANAF/sensibleInternalEnergy、C10H22/O2/N2 local mass-weighted mixture，沿用reactingMixture已审计的热力学组合及数据。active没有新建旧global reactingMixture field object；不激活反应/旧thermo.correct，不换gas package。

# 8. Liquid EOS

ndecane_gibbs_v1 TABLE-B standalone Chebyshev，C_L=369229.9537234281 J/kg，e/h_solver=e/h_native+C_L。factory/evaluator冻结unchanged，无CoolProp runtime。

# 9. Gas-only uniform

10步PASS，conservative/primitive漂移0，p相对误差4.440892e-16，liquidQueries=0，mL=0，P2=+0。

# 10. Liquid-only uniform

10步PASS，conservative/primitive漂移0，p相对误差1.728617e-13，gasQueries=0，mG=0，P2=-0，无fake gas。

# 11. Mixed states

alphaL=.1/.5/.9各10步PASS；p=3MPa，U=(47,0,0)，TG=800K，TL=300K。状态和P2保存，最大p相对误差1.860068e-12。

# 12. Trace state

液相1e−20与gas-minority P2=-1e−20各10步PASS，P2位串和trace不变，phase mass均正。负P2时alphaL输出舍入成1不删除气相，alphaG直接由P2.gasValue()派生。

# 13. Contact

M5C.3/M5C.2结构common-p/U pure gas/liquid接触，实际solver10步，最大p相对误差2.156053e-13<预先给定1e−8，无调参。

# 14. Species contact

alphaL=.1，两侧YG=(0,.228,.772)/(.1,.2,.7)，10步PASS。p相对误差8.215650e-15，N2 residual无normalize/clip。

# 15. Alpha advection

20步：alphaL=.5+.02sin(2πi/20)，U47m/s，dt1e−5s，周期长20m。冻结K=0、无MULES/compression。实际alpha最大变化9.572836e-05；对解析平移全过程最大绝对误差9.564115e-05。bounded，1次合法P2 branch切换；不声称网格收敛阶/长期精度认证。

# 16. mG conservation

周期闭域，无外部通量/源项；最终各分量最大缩放误差：5.677514e-17。全过程见accepted_steps.csv；分母max(|初始积分|,1 SI)，零初始分量按该尺度报告，trace均匀积分误差0。

# 17. mL conservation

周期闭域，无外部通量/源项；最终各分量最大缩放误差：6.636006e-17。全过程见accepted_steps.csv；分母max(|初始积分|,1 SI)，零初始分量按该尺度报告，trace均匀积分误差0。

# 18. Momentum conservation

周期闭域，无外部通量/源项；最终各分量最大缩放误差：4.932888e-17, 0.000000e+00, 0.000000e+00。全过程见accepted_steps.csv；分母max(|初始积分|,1 SI)，零初始分量按该尺度报告，trace均匀积分误差0。

# 19. Energy conservation

周期闭域，无外部通量/源项；最终各分量最大缩放误差：8.048047e-17。全过程见accepted_steps.csv；分母max(|初始积分|,1 SI)，零初始分量按该尺度报告，trace均匀积分误差0。

# 20. Species conservation

周期闭域，无外部通量/源项；最终各分量最大缩放误差：6.483870e-18, 7.489136e-17, 1.313958e-16。全过程见accepted_steps.csv；分母max(|初始积分|,1 SI)，零初始分量按该尺度报告，trace均匀积分误差0。

# 21. Recovery counters

全部R1调用159000，iterations 761010，失败0（含limiter probes）；accepted publication calls 2400，失败0。state class/query计数逐例记录。--wrap只读，不改算法。

# 22. Timestep logic

复用冻结driver joint acoustic/alpha/mass/species约束、connectedDt与16次retry；先candidate验证再commit，当前全部rejectedTrials=0，dt1e−5s。不声称本轮又做failed candidate回滚试验。

# 23. KT flux authority

复用PrecisionReconstruction strategy1、PrecisionOperator::face和fiveEqTemporalDriver。所有守恒量共享left/right state、KT wave/weights/Sf，不新增第二flux。

# 24. Sound speed

冻结Allaire：xi_k=rho_k beta_k，w_k=m_k/rhoMix；cA²=(wG xiG cG²+wL xiL cL²)/(alphaG xiG+alphaL xiL)。Pure-phase用该相sound speed。

# 25. ALE compatibility

冻结meshPhi/API不改，本轮Umesh=0。质量mk(U−Umesh)·Sf，动量M(U−Umesh)·Sf+pSf，能量Et(U−Umesh)·Sf+pU·Sf；alpha physical divU。移动mesh/GCL未运行未认证。

# 26. Boundaries exercised

仅一维等距单位面积cyclic x、横向empty；非该geometry拒绝。fixedValue/zeroGradient、任意2D/3D、多维inlet/wall/nozzle未认证。

# 27. DPM disabled proof

提前return，不创建cloud/SLGThermo，不调用evolve/SU/Sh/Srho或M8A source adapter。10cases无sprayCloudProperties仍正常运行。legacy DPM库可链接但不执行。

# 28. Surface tension disabled

不创建interfaceProperties，不计算sigma/曲率/表面力，无MULES。DPM=false/ST=false/K=0启动guard。

# 29. Serial-only proof

最终10日志nProcs:1，直接执行actual solver，无mpirun/decomposition；parRun guard拒绝MPI。T4-S2不升级active MPI。

# 30. Compile result

最终wclean+fresh wmake exit0，errors0/warnings0。最终binary重跑10cases全部exit0/normal exit/no timeout。首次relative path IO failure、dimensionSet赋值startup failure日志保留；只修新适配层，未改冻结物理算法。

# 31. Executable SHA

`2dfd64d29408e4467a2278fe96cd80ebb3d9903c9754620a4cc4f9db0d3a9487`。installed及封存runtime binary、运行前后SHA相同；55个linked libraries SHA另存。

# 32. Foundation hashes

重新核对6717源码/Make和19 native parcel项全部PASS；实际gas/patch源码8文件读取并记录SHA；系统OpenFOAM无修改。

# 33. Project hashes

30,618 frozen baseline、72 compiled project dependencies。manifest SHA `436e923cd6bc82e4d0274958800bd2f7491ab37c9ca9c8d2ff0af9945d359931`。逐项差异见frozen_delta_audit.json，附compiled_sources；冻结模块源码unchanged。

# 34. Active source deltas

改main前置dispatch、Make/files/options；新增serialFiveEq/runSerialFiveEq.H/.C、recoveryObservation.H/.C及输入/审计/报告工具；编译现有冻结Precision/Flux/Reconstruction C。不建新库、不改frozen C/H。active_source.patch可复核。

# 35. Production input impact

NONE：300/300_2D/原rhosprayFoam共132文件unchanged。未运行生产jet/crossflow/atomization/MPI/restart。目标active solver源码和binary有本轮授权变化，不标其impact NONE。

# 36. Whether M6B.0 COMPLETE

YES，仅串行1D periodic bootstrap。所有请求的uniform/pure/mixed/trace/contact/species/alpha/守恒/编译/隔离gate通过；非通用多维、moving mesh、restart reader或production认证。

# 37. Next permitted milestone

M6B.1 NEXT ROUND ONLY，可在后续用户授权范围讨论serial Eulerian wave/contact/shock；当前未执行。多维网格适配和边界认证需单独计划；active DPM/T4-S3后置。

# 38. T4 status

T4-S1/S2 COMPLETE/FROZEN；T4-S3 DEFERRED/NOT CERTIFIED/NOT EXECUTED；T4 PARTIAL，global MPI transaction未认证。本轮owner路线切换优先于旧报告M6BNO。

# 39. M8A/M6B status

M8A PARTIAL；M6B.0 COMPLETE；M6B PARTIAL；既有T3/R2/S1/S2/PW1冻结证据不改。

# 40. Updated milestone matrix

| Milestone | Status |
|---|---|
| M0–M4 / M5A/B / frozen EOS/R1/P2 / M5C.1/.2/.3 | 保持既有状态，不重新升级 |
| T3 / T4-S1 / T4-S2 | COMPLETE / FROZEN |
| T4-S3 | DEFERRED / NOT CERTIFIED / NOT EXECUTED |
| T4 / M8A | PARTIAL |
| M6B.0 | COMPLETE / SERIAL ACTIVE FIVE-EQUATION BOOTSTRAP（周期1D） |
| M6B | PARTIAL |
| M6B.1 | NEXT ROUND ONLY / NOT EXECUTED |
| production restart / MPI / CFD | NOT CERTIFIED |

STOP；未进入M6B.1、active DPM、T4-S3、surface tension、VOF→DPM或production。

## Micro-case evidence

| Case | Steps | Max relative p error | Max scaled conservation error | Accepted recovery failures |
|---|---:|---:|---:|---:|
| gas | 10 | 4.440892e-16 | 0.000000e+00 | 0 |
| liquid | 10 | 1.728617e-13 | 0.000000e+00 | 0 |
| mixed01 | 10 | 3.996803e-15 | 0.000000e+00 | 0 |
| mixed05 | 10 | 3.752554e-14 | 0.000000e+00 | 0 |
| mixed09 | 10 | 1.860068e-12 | 0.000000e+00 | 0 |
| traceLiquid | 10 | 2.220446e-16 | 0.000000e+00 | 0 |
| traceGas | 10 | 8.459899e-14 | 0.000000e+00 | 0 |
| contact | 10 | 2.156053e-13 | 1.513712e-16 | 0 |
| speciesContact | 10 | 8.215650e-15 | 3.962658e-17 | 0 |
| smooth | 20 | 9.159340e-14 | 8.986963e-17 | 0 |

Evidence: fitting/integration/m6b0_serial_active_v1/cases_final; gate M6B0_gate.json（316PASS）。
