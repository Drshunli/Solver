# M8A kinetic energy and momentum

Native dUTrans=-massEff*deltaUcoupled per physical droplet; cloud multiplies
by nParticle. Native UTrans has no total-energy counterpart. In a closed
drag-only event without mass loss/external force:

```
dM = -Delta(mParcel*UParcel)
dEt = -Delta(0.5*mParcel*|UParcel|^2)
```

For a finite impulse, simply using gas U dot dM is not exact: the gas common
velocity kinetic energy changes by its full finite difference. Updating common
M and Et together, followed by recovery, leaves the appropriate sensible
energy including dissipation. Do not add another kinetic-energy source after
this total-energy increment. For mass transfer use the complete before/after
parcel momentum and KE, not a constant-mass formula.

The native ReactingParcel U0 reference alias makes simultaneous mass+drag
native UTrans differ from the exact endpoint momentum by dm*(Uold-Unew).
The candidate exposes that correction explicitly. It is not alphaG-weighted
after accumulation, since that would violate the parcel/Eulerian impulse
ledger. In the common-velocity model, impulse changes common M, so the resolved
liquid also accelerates through the model's velocity constraint. Reading gas
carrier properties does not produce independent liquid/gas velocities.

Real sphereDrag, no-force, evaporation+drag, disappearance and multiple-parcel
tests use actual parcel endpoints. No CFD or active momentum equation edit.
