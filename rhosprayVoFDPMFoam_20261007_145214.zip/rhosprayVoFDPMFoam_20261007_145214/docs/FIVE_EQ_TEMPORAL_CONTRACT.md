# M5C.3 temporal contract v1 — passive

Selected reconstruction: R1-P2-residualSpecies-v1; production liquid EOS ndecane_gibbs_v1; ONE physical alpha DOF. First activation design is **global-step, fixed-mesh, forward Euler**, first order in time. Spatial second-order results do not imply second-order time accuracy. LTS, RK, mesh adaptation/motion and physical sources are not implemented by the new driver.

## Authority and ordering

For every committed/stage/trial state, the complete tuple is `(P2,mG,mL,M,Et,mYi,V,timeIndex)`. q[0] is a decoded compatibility view, never restart/recovery alpha authority. p/TG/TL/rhoG/rhoL/cMix/U/Y are recovered or decoded caches stamped with the tuple's generation. A cache from n cannot answer an EOS query for n+1. oldTime owns a full immutable previous tuple, including P2 coordinate bits and geometry; no decode/reencode.

1. Read-only committed Qn → recover all cell thermodynamics.
2. Preliminary acoustic/user dt constraints from Qn and geometry; prepare boundary data at the committed time.
3. R1-P2 reconstruction; recover both owner face states; compute **one shared KT flux per face**.
4. Refine flux-dependent dtAcoustic, dtAlpha, dtMG, dtML, dtSpecies, dtVolume; this refinement necessarily follows face construction. No circular use of new Q to compute old-stage flux.
5. Compute the nonconservative alpha divergence source from these same face wave/physical volume fluxes. It is part of the alpha operator, not a separate lagged legacy solve.
6. Form conservative trial and P2 alpha trial in separate buffers from identical Qn. `PrecisionOperator::trial` retains the frozen evaluation order, including compensated minority update and mesh/GCL cancellation.
7. Recover **all** trial cells; accept only if every state is admissible. On acceptance atomically assign old=Qn, committed=trial, time+=dt, step++, lastDt=dt. No partial cell/stage commit.
8. Output/restart only accepted tuples. Derived caches are refreshed from accepted Q.

Frozen alpha operator is material advection written `d(alphaL)/dt+div(alphaL U)=alphaL div(U)` (plus its ALE/GCL discrete form). M5C.3 does not introduce an untested Kapila K div(U) term. If the final physical five-equation specification requires a different nonconservative closure, that is an explicit pre-activation design/revalidation requirement, not an IO change.

## dt and rejection

Algebraic bound: `min(dtAcoustic,.95dtAlpha,.95dtMG,.95dtML,.95dtSpecies,.95dtVolume,userDt)` using frozen operator formulas. Unbounded components may be +infinity; final requested dt must be finite and positive. Face admissibility is checked before trial.

Thermo admissibility is nonlinear and assessed by whole trial recovery. On an interior invalid trial, preserve Qn/old/time/volumes/face fluxes, refine each connected admissible interval with the frozen 32 samples +52 bisections, take global minimum dtThermo, retry from Qn. No claim that finite sampling proves every continuum dt point. Driver limit:16 attempts; exhausted budget produces controlled stop, not state repair. No arbitrary positive dt floor.

At **certified** pure-liquid EOS boundaries the frozen D adapter distinguishes high-only outward (whole-operator R0 rollback using one globally shared R0 face family) from high+low outward (EOS domain exhausted → stop). Zero connected dt without certified metadata must stop as `NO_CONNECTED_DT_REQUIRES_DOMAIN_CLASSIFICATION`, **never** invent an EOS-boundary certificate or force a tiny step. Boundary classification remains tested in its separate frozen harness; the periodic synthetic driver does not fabricate it.

## Sources and future atomicity

The current driver has no nonzero physical sources. Future first-order source splitting is flux stage → recover complete flux trial → source stage → recover complete source trial → atomic commit. Each source operates on the complete tuple and must return all ledger changes together. A failed source stage rejects the entire proposal back to Qn. Chemistry species/chemical heat update together; M8A parcel state and transfer ledgers must be rollback-safe or parcel evolution deferred until acceptance. No cloud mutation on a rejected proposal. Implicit diffusive sources require a coupled admissibility-tested solve, not independent legacy overwrites.

Future ALE adds coherent Vn/Vtrial, shared mesh flux and conservative remap; source dt/capillary/parcel constraints join the global minimum only after their owners are implemented. No active Time index increment, fv field oldTime mutation, cloud evolve or disk write before proposal acceptance. This differs deliberately from the legacy loop.

## Tests and scope

`tests/fiveEqTemporalContract` executes real gas/liquid recovery, R1 reconstruction, shared KT flux, current bounds, trial/recovery, retry/commit, restart/reload/continue. Four periodic manufactured profiles (sharp contact, trace gas, trace liquid, alpha around .5),100 steps each. One deliberately oversized real trial is rejected and retried. `tests/fiveEqP2OldTime` checks installed OF7 field oldTime directly. No source or general mesh driver has been activated.
