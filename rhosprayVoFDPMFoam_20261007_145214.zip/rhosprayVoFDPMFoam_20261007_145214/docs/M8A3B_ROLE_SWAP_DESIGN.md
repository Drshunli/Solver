# M8A.3B selected architecture: dual-cloud logical role swap

Status: DESIGN FROZEN; implementation and closure gates pending.

## Selection and identity audit

Architecture A is selected. A future transaction owns one aggregate committed
State and one independent candidate State. Publication swaps the aggregate
role handle, not individual model members. No copy-back hybrid is permitted.

The actual active createClouds.H constructs a stack basicSprayCloud named
sprayCloud. Main/equation includes use the lexical parcels object directly:
storeGlobalPositions/evolve, Srho, SYi, SU and Sh. This active interface cannot
perform logical role swap as written. A later separately authorized activation
must use a stable role accessor and obtain source/model references afresh.
None of these active files is changed here.

Internal model owner/properties/RNG references bind to the newly reconstructed
cloud through frozen M8A.3A adapters. Role publication does not move the cloud
object itself, so its own internal references continue pointing to that object.
Carrier fields, mesh, SLGThermo and constitutive data have separate lifetime
requirements. A candidate must not reuse a mutable committed carrier view.
Carrier views derived from candidate Q must be owned by the candidate aggregate
or kept immutable for its entire lifetime; raw cloud construction references
cannot be rebound by swapping a pointer. Cached external Cloud&, model&,
parcel/source-field references across publication are forbidden in this design.
The future harness must detect stale references, not merely document them.

## Required aggregate and publication

State owns exact P2/Q (mG,mL,M,Et,mYi), the ordered cloud population and native
identities, model/runtime histories, complete root Random value including
normal cache, rank-local allocator snapshot, native transfers and coefficients,
derived support cache generation, pending accepted output, and distributed
trial protocol state. The full native parcel serialized state remains required.

Begin: independently construct/import the candidate using unchanged M8A.3A
semantics; capture allocator and committed-state canonical dump.
Evolve: validate support before each carrier query, evolve native models into
candidate-owned storage, collect candidate native transfers, use unchanged
frozen source conversion, recover candidate Q, stage output. No permanent IO.
Decision: drain current distributed communication, then collective all-valid.
Commit: publish exactly one complete aggregate after precommit validation.
Discard: destroy candidate, restore process allocator/scheduling state, and
prove the canonical committed dump unchanged. Derived cache belongs to the
state generation and is invalidated after accepted Q/P2 changes.

Canonical output naming is distinct from temporary objectRegistry naming.
Renaming native cloud members in place is not a demonstrated solution. Future
output staging must preserve the real VoidFraction trajectory integral and
publish it once without re-running trajectory integration.

This is a requirements/design contract, not implemented atomic cloud/Q code.
No claim of exception-safe filesystem publication or MPI drain is made.

## Blocking prerequisite

The actual intended 300_2D liquid column and its boundary P2 states are missing.
The diagnostic plane maps cannot freeze production support policy. Required
inputs are liquid column position/extent/topology and the independent DPM
injection relationship/expected spray region. No masked weights, extrapolation,
renormalization or artificial trace-gas creation is authorized.
