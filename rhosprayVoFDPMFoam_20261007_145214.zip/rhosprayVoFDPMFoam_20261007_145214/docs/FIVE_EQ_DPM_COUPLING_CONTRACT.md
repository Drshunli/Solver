# M8A candidate coupling and applicability contract v1

## Ownership and units

`fiveEqDPMSourceAdapter` accepts extensive native accumulators and audited full
parcel endpoints, returning timestep-integrated dmG [kg], dM [kg m/s], dEt
[J], dmYi [kg]. It maps runtime species by the real cloud composition IDs and
canonical thermochemical evaluator map; tests include an actual reordered
reaction dictionary. Current frozen Q has three species; extension is an
explicit future change, not silent truncation of more species.

`trial(Q,V,source)` copies coherent Q, updates mG/M/Et/mYi together, leaves
mL/P2 bitwise unchanged and runs frozen recovery. Invalid state fails. A zero
source preserves every bit. It neither clips nor creates a tiny fraction.
`fiveEqDPMTrialSource` begins, validates by accumulateSources, commits Q and
parcel endpoint together, or discards both. This mock is not full cloud state.

## Carrier and physical domain A (frozen)

Only PRESENT and TRACE_PRESENT gas can carry DPM. `gasCarrier` obtains intrinsic
rhoG,TG,p,common U and runtime YG from coherent recovery. No rhoMix carrier,
no substituted TL, no alpha floor. Exact absent gas rejects BEFORE tracking,
even for a zero source. Nonzero source trial also rejects pure liquid: dmG>0
with unchanged alphaG=0 would make rhoG=mG/alphaG undefined. B (alpha phase
creation source) is NOT implemented.

Check mask at injection, every interpolation/trajectory segment and each
source event. A cell-only post-evolve rejection is insufficient. A failed mask
rejects the entire trial and restores cloud, all source fields and Eulerian
state; never delete/reflect/skip a parcel to hide the conflict. Exact-cell
interpolation is the standalone fixture's supported policy. Interface
crossing/patch and nonlocal interpolation need a proven production guard.
That guard is currently a PRE-M6B HARD BLOCKER.

Trace alphaG=1e-20 remains in signed P2 and sources are tested with event
amount scaled to available gas. This does not certify arbitrary finite source
loading in arbitrarily small gas mass; recovery may reject it. Single Et
double precision cannot resolve every arbitrarily small gas heat increment
against dominant liquid energy. No precision/source floor is invented.

## Stage ordering and rollback

Freeze first-order split: snapshot committed Eulerian Q/oldTime/clock, full
cloud and source arrays -> flux trial + coherent recovery -> validate carrier
mask -> parcel trial + aggregate DPM source -> coherent Q source trial +
recovery -> separate chemistry trial + coherent recovery -> final validation
-> atomic whole-step commit. Any failed stage discards all stages and retries
smaller dt; no partial source/parcel commit. Source event volume belongs to
the source stage, independent of meshPhi; ALE kinematics remains flux owned.

Native cloud clone+restore needs explicit source snapshots (rhoTrans,
UTrans,UCoeff,hsTrans,hsCoeff). NativeDPMSourceSnapshot tests nonzero arrays and
coefficients, rejects radiation (its extra arrays are unsupported). Current
production injector, dispersion, breakup, collision, functions, IDs/output
metadata, occupancy, time and mesh side effects are not all validated. No
atomic runtime readiness is inferred from the simple unit cloud.

## Scope restrictions

Held-pressure, single-C10H22 parcel caloric exactification is a candidate.
Non-coupled work/radiation/multi-component deletion/varying-pressure events
need separately audited contracts. Present case's heat/phase change remain
disabled. Native mass-only diagnostic with heat none exposes omitted latent
cooling; it is not promoted into a physical evaporation configuration.
Chemistry source RR/Qdot is separate; reaction-enabled integration is not done.
No active solver, EOS, pressure recovery, KT, surface tension or VOF transfer edit.
