# M8A.3B-T3 serial transaction design and stop gate

Selected architecture: **A — dual-cloud logical role swap**. No import-back
hybrid is implemented. The production stack cloud is untouched.

## Implemented prototype

`tests/fiveEqDPMSerialTransaction/serialTransaction.H` owns a committed State
and an independent trial State. Native reconstruction uses the unchanged
M8A.3A adapters. Begin snapshots Q/P2, logical allocator, scheduling metadata,
and a committed-state sentinel. Trial evolution scopes the process allocator
and Time changes, restores both on return, and suppresses native permanent
output through the unchanged passive output-isolation specializations.

Nested begin, unvalidated commit, double discard and commit without a trial
are rejected. Validation seals the candidate dump; publication rejects changes
after validation. Publication is a unique_ptr role swap of the whole aggregate,
not separate cloud/Q swaps. This publication path has NOT passed its gate.

Sources and coefficient fields belong to the reconstructed cloud. A same-cell,
unchanged ordered population can use actual aggregate native parcel endpoints,
native accumulated transfers, the frozen source adapter, and full Q recovery.
Admission/deletion/cell crossing is rejected because aggregate endpoint changes
alone do not identify exchange versus injection, wall impulse or parcel motion.
No fabricated external work, injected mass residual or source clipping is used.

## Actual stop condition

Native rho/U and native ThermoCloud p/T are construction-time references.
The current reconstruction constructor takes source.rho(), source.U() and the
same SLGThermo. Merely publishing a reconstructed cloud does not make these
references resolve from the newly recovered Q.

The guard rejects any exact Q change requiring a refreshed carrier-view bank.
This is a conservative implementation guard, NOT proof that every bit-level Q
change necessarily changes every recovered primitive, NOT EOS invalidity, and
NOT a demonstration that role swapping is fundamentally impossible.

The legal tiny-step source probe records its actual endpoint-remapped increment
and before/after Q. It is not relabelled a zero source and is not rounded away
to pass the gate. Until candidate-owned carrier views and their native binding
are implemented, accepted nonzero-source publication remains blocked.

## Work required to close the gate

1. Extend the project-local construction path to bind candidate-owned rho/U,
   p/T, viscosity and thermodynamic carrier fields while preserving native model
   semantics. Audit SLGThermo, thermo/carrier registry lifetimes and parcel mesh
   references; no placement or byte patch of C++ references.
2. Add event-local endpoint accounting around real injection, movement,
   breakup/child creation, collision/deletion and patch events. Separate parcel
   admission/exit and external wall work from DPM-to-gas exchange.
3. Rebuild carrier views from committed Q for the next transaction. Reuse T2
   native contributor support without modifying its criterion or weights.
4. Complete an authoritative transactionState-v1 codec. The prototype currently
   keeps native traversal order and full parcel streaming, exact Q/P2 bits,
   injector/wall state, sources, scheduling and pending theta. The inherited
   128-call RNG future probe is NOT a complete RNG-state serializer or general
   proof of hidden-state equality. Add sorted identity view and output metadata.
5. Stage native accepted outputs and publish exactly once. The current staged
   theta string is memory only; file publication and ghost-file retry goldens
   are not complete. Preserve the native trajectory-time integral.
6. Rerun all forced-event direct-small/rejected-large/small-retry gates and 100
   accepted promotions from each evolved A/B/C state. No T4 or M6B follows a
   PARTIAL result.

All eight model capabilities remain BLOCKER for FULL-SERIAL-TRANSACTION-SAFE.
This denotes incomplete transaction proof, not a rejection of the frozen
M8A.3A independence result or of the production physical models.
