# Five-equation DPM execution contract v2 — M8A.2 PARTIAL

The frozen source/energy contract and P2 representation remain unchanged.

## Carrier domain

CELL GAS SUPPORT requires consistent P2/mG and recoverable intrinsic gas
thermodynamics (PRESENT or TRACE_PRESENT). Exact alphaG=mG=0 is absent.
DPM CARRIER SUPPORT additionally requires every contributor used by the
actual queried interpolation operation to have a legal gas state.

Current production scalar selectors rho/T/Cp/mu/kappa/p/Y use `cell`.
U uses `cellPoint`, including point reconstruction, physical boundary values
and point constraints. Mandatory scalar cell reads remain mandatory when the
U cell coefficient is zero. Tensor coefficients are tested component by
component against exact floating zero; there is no norm threshold, masking,
renormalization, fabricated gas, nearest-cell substitution or relocation.

DPM usable region = pre-existing gas region with complete valid carrier
stencil. A gas-present cell alone does not establish DPM applicability.

## Prototype implemented in this round

The independently constructed native cloud owns its models and transfer
fields. Its name is trialCloud in the isolated harness. The current exact
stencil extractor rejects MPI and more than 256 cell/boundary entities.
Thus the installed hooks are a native-path prototype, not a production-mesh
implementation. No runtime cloud has been switched in the active solver.

Injection is checked after constrained location and before retained parcel
allocation/thermo initialization. Native position searching can allocate
temporary particles; the allocator scope encloses construction and searching.
Tracking is checked at KinematicParcel::setCellValues before its first carrier
read, including the basicSprayCloud and KinematicCloud collision call forms.
Support failure throws and discards the isolated trial; it does not change
physical parcel treatment.

The rank/process-local particle allocator is shared by all clouds. Exclusive
serial ownership is required. Trial restart-property loading is suppressed;
discard restores the exact saved counter and commit retains advancement.
Nested allocator transactions fail. Thread-safe interleaving is unsupported.

The fresh constructor only establishes INITIAL model state. It does not
capture an evolved committed cloud. The initial-state replay harness must
not be used as a continuation transaction factory.

## Output and VoidFraction

Actual VoidFraction::write and native postEvolve output paths are suppressed
in the prototype scope. Successful trial writes are zero in the tested
writeTime case. Accepted-output release is NOT implemented.

VoidFraction is diagnostic in the audited selected production models. Native
meaning is sum(postMove dt*nParticle*volume)/(carrierDt*cellVolume).
Endpoint occupancy is not equivalent. fiveEqDeferredVoidFraction preserves
the residence integral and permits one commit but is not connected to the
native postMove/output pipeline. Future acceptance must release this trial
integral once; recomputation requires retaining accepted trajectory samples.

## Required logical commit (not yet implemented)

1. Successful evolution and all support hooks.
2. Native trial transfers -> unchanged frozen source conversion.
3. Valid deposit P2/mG and coherent recovered trial Q.
4. Source/chemistry ordering satisfied.
5. All-rank AND acceptance after native processor transfer buffers drain.
6. One cloud/Q/allocator state publication; accepted output exposure afterward.

Failure destroys trial parcels/models/sources/Q, restores each rank's saved
allocator and publishes nothing. No alpha source or volume creation is added.

Missing exact model continuation, combined commit, scalable stencils,
accepted output and MPI particle transfer are hard PRE-M6B blockers.
