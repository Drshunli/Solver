# M8A.1 strict gas-support and transaction scope v1

First version: DPM interacts only with pre-existing PRESENT/TRACE_PRESENT gas.
Support derives from authoritative signed P2 plus mG consistency, then frozen
full thermo recovery. Exact alphaG=mG=0 is invalid before carrier queries,
injection allocation or source deposition. alphaG=1e-20 remains detectable even
if decoded alphaL rounds to1. No alpha floor, dummy rhoG/TG/YG, nearest-gas
copy, extrapolation, masked weights or gas-volume creation source.

fiveEqDPMCarrierSupport owns immutable committed Q/P2 and authoritative patch
state snapshots. Rejected trial never updates these. Caller must construct a
new support generation after a committed Q change. All cell/stencil/injection/
tracking/deposition APIs call the same classifier; sourceTrial wraps the
UNCHANGED M8A source adapter and frozen recovery. Returned invalid statuses
are controlled failures, not FatalError.

STRICT stencil: all actual nonzero vector coefficient contributors and every
mandatory scalar cell read must have valid gas support. Patch states come
from their authoritative boundary owner; no automatic owner-cell substitution.
The exact serial native operator probe is diagnostic-only and bounded, not a
production stencil hook. Coupled/MPI constraints need validated support exchange.

Required hook ordering: injection location/tet/stencil guard BEFORE new parcel;
every actual tracking segment guard BEFORE setCellValues; source-cell guard
BEFORE accumulation; coherent Q source trial followed by recovery. Pure-liquid
crossing fails the whole trial, without deletion, rebound, moving the parcel,
dropping a source or altering P2. Probe-level caller checks are implemented;
legacy injection/move/source callbacks remain unmodified and are NOT guarded.

Caller owns begin/evolve/extract/convert/build/validate/commit/discard. Production
cloud/Q/support/time/output must remain untouched until atomic acceptance.
Commit/discard are terminal and cannot repeat. Current lifecycle capability
gate returns UNSUPPORTED for the actual raw production-cloud transaction.
It neither commits a cloud nor hides missing rollback implementation.

Native clone retains original owner references; raw restore sets allocator0,
omits sources/full solution/output dictionaries, loses private theta, and
cannot undo emitted files. Model caches/occupancy and enabled breakup/collision
creation/deletion need tested closure. No oversized-step/small-step golden
transaction is certified until these are fixed. Serial global ID restoration
also requires exclusive allocator ownership across clouds. Processor transfer
requires collective acceptance, ownership/message-buffer snapshots and global
discard; current probe is serial-only: PRE-M6B MPI BLOCKER.

Frozen energy ledger, ordinary dmG/dmYi/dM/dEt mapping and Allaire K=0 are
unchanged. No alpha source. Future parcel-induced gas creation is a separate
physical model stage. M6B.0/M6B.1 are blocked. No CFD performed.
