# M8A: actual Foundation 7 DPM source audit

Scope: passive standalone candidate only. Source snapshots and hashes are in
`fitting/dpm/m8a_v1/source_audit`. No OpenFOAM library or active solver edit.

## Actual type and path

`basicSprayCloud` is SprayCloud<ReactingCloud<ThermoCloud<KinematicCloud<Cloud<basicSprayParcel>>>>>.
`basicSprayParcel` is SprayParcel<ReactingParcel<ThermoParcel<KinematicParcel<particle>>>>.
Active createClouds.H constructs it with rhoG,U,g,SLGThermo; rhoG currently
belongs to the legacy carrier, not a runtime five-equation intrinsic field.

Native update: SprayParcel sets liquid rho/Cp/sigma/mu -> ReactingParcel
phase-change mass and Sh -> composition/mass/d change -> deletion branch or
heat integration -> velocity integration -> integrated transfer accumulation
-> SprayParcel updates rho and d preserving remaining mass -> atomization/breakup.
The native harness calls the real public setCellValues/calc APIs; it does not
solve Eulerian equations, move a mesh or run a CFD case.

## Units and signs

| Native quantity | Units | Meaning |
|---|---|---|
| rhoTrans[i] | kg | cell/time-step integrated vapor mass; includes parcel multiplicity |
| UTrans | kg m/s | integrated carrier momentum gain |
| UCoeff | kg | momentum linearization coefficient |
| hsTrans | J | integrated sensible-enthalpy source, NOT total energy |
| hsCoeff | J/K | thermal linearization coefficient |
| Srho() | kg/(m3 s) | sum(rhoTrans)/(dt V) |
| Explicit Srho(rho), SYi, SU, Sh matrix source | kg/s, kg/s, N, W | negative transfer/dt; RHS uses minus matrix.source |

Adapter quantities stay extensive; Q increments divide by event volume once,
never multiply/divide by dt a second time. Native semi-implicit paths use
implicit negative-mass source coefficients, UCoeff, and h-based Cp conversion.
These cannot be treated as extra explicit increments. Harness exercises the
actual explicit source APIs, matching the present case's explicit 1 schemes.

## Important native approximations

* ReactingParcel stores `const vector& U0 = this->U_`; after velocity assignment,
  this aliases Unew. Mass momentum uses dm*Unew. For coupled sphere drag the
  endpoint-conservative correction is dm*(Uold-Unew), not another dm*Uold.
* KinematicParcel's dUTrans is the opposite coupled impulse; its accumulators
  do not provide a complete kinetic-energy exchange. Non-coupled forces must
  be recorded separately as external impulse/work, not swallowed into drag.
* ThermoParcel freezes mCp while integrating T. Exact raw liquid h(T) and
  p/rho(T) changes differ from that native approximation. TMin/TMax clipping
  must invalidate the candidate event; it is never silently repaired.
* Reacting deletion transfers full old mass, new Y, old U and gas Hs(Told),
  bypassing ordinary heat/velocity integration. Single-C10H22 deletion is tested;
  multi-component depletion/deletion needs an original-species endpoint ledger.
* Phase-change Sh=-sum(dm*dh)/dt; enthalpyDifference dh=gas.Ha-liquid.h;
  latentHeat uses liquid.hl. Heat-transfer `none` returns before using Sh.
  The mass-only fixture exposes this diagnostic behavior; it is not approval
  of a production evaporation model with latent cooling disabled.

## Current case versus diagnostic fixture

300_2D has heatTransfer none, phaseChange none, sphereDrag, stochastic dispersion,
blobsSheetAtomization, ReitzKHRT, ORourke, voidFraction and
cellValueSourceCorrection on. The isolated fixture enables selected actual
RanzMarshall/liquidEvaporation APIs and disables injection, tracking dispersion,
atomization, breakup, collision, radiation and cloud output functions. These
fixture model settings are NOT copied back to the case.

`cellValueSourceCorrection` uses rho*V as available carrier mass. In a mixed
cell the appropriate gas mass is mG*V=alphaG*rhoG*V, with coherent Q recovery.
Leaving native correction on with intrinsic rhoG alone is incorrect. Its
replacement/guard remains a pre-activation blocker.

## Real rollback

SprayCloud storeState clones the cloud. restoreState calls cloudReset. Parcel,
RNG and cloned model reset paths are present; UTrans/UCoeff/hsTrans/hsCoeff/
rhoTrans are not restored by cloudReset. The real unit probe confirms this,
then confirms exact replay after explicit source reset. A separate nonzero
source+coefficient snapshot probe tests NativeDPMSourceSnapshot.

This does NOT prove rollback of the current production injector, collisions,
stochastic dispersion, cloudFunctions, IDs/outputProperties, cell occupancy,
time, mesh or external output. Complete production rollback/preview isolation
is a PRE-M6B HARD BLOCKER, not an assumption hidden by the mock transaction.
