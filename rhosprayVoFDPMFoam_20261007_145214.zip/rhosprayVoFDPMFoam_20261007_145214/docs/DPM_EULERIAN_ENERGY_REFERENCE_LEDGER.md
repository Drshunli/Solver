# M8A DPM / Eulerian energy reference ledger

Frozen gas energy is OF7 JANAF Es=Ha-Hc-p/rho. JANAF Hs=Ha-Hc and
Hc=low-temperature NASA polynomial enthalpy at Tstd=298.15 K. Chemical Hc is
excluded from gas sensible Et and tracked separately for source accounting.
OF7 liquid CompositionModel::H is raw liquidProperties.h; liquid Hs subtracts
h(p,298.15 K), liquid Hc is that raw reference h. Those labels are not
interchangeable with gas Hs. Native enthalpyDifference uses gas Ha-liquid h.

Let B/A be full parcel endpoints for one held-pressure local event, including
physical multiplicities and all participating parcels. Define

```
HP = sum(mParcel * hOF7(p,T))
VP = sum(mParcel / rhoOF7(p,T))
KP = sum(0.5*mParcel*|UParcel|^2)
EP = HP - p*VP + KP
chi = sum(HcGas_i * dmYi)
dmG = sum(dmYi) = mP_B - mP_A
dM = PParcel_B - PParcel_A + externalImpulse
dEt = HP_B-HP_A - chi + KP_B-KP_A
      + p*(VP_A-VP_B) + externalHeat + externalWork
```

Therefore dEt+chi+EP_A-EP_B=externalHeat+externalWork. No residual is named
external heat/work. All unit contexts use ZERO external terms (gravity,
radiation and non-coupled forces off). For varying pressure the endpoint pV
and path work need a new audited contract; do not reuse held-pressure formula.

The adapter starts with actual native hsTrans and exposes separately:

```
caloricCorrection = HP_B-HP_A-chi + externalHeat - hsTrans
kineticCorrection = KP_B-KP_A + externalWork
pressureWork = p*(VP_A-VP_B)
dEt = hsTrans + caloricCorrection + kineticCorrection + pressureWork
momentumCorrection = dM - nativeUTrans
```

This is explicit conservative exactification, not a claim that legacy native
Sh already obeyed the nonlinear caloric ledger. The caloric correction can be
large on disappearance. Source model scope and upgrade must be reviewed before
activation; no runtime source was changed here.

Eulerian liquid C_L=369229.9537234281 J/kg belongs ONLY to frozen Gibbs EOS
e/h coordinates. It is not added to DPM->gas vapor mass. Ordinary DPM coupling
does not change Eulerian mL or P2. Future VOF/DPM cross-model conversion remains
separate and requires its own caloric/reference mapping.

## JANAF chemistry compatibility

The actual StandardChemistryModel Qdot is -sum(Hc_i*RR_i). Vapor addition
changes chemical ledger by +chi; the adapter subtracts chi once from sensible
Et. A later reaction changes chemical ledger by sum(Hc_i*dmiChem) and sensible
Et by its negative. Thus the two source families are disjoint and no formation
enthalpy is counted twice. The harness checks the algebra with actual runtime
Hc; its mass-conserving RR direction is explicitly synthetic, not a physical
C10H22 reaction. Current reactions/thermal.dat only contain C10H22/O2/N2,
with no active reaction/products; a physical reaction-enabled compatibility
test is NOT established and remains separate from this algebraic identity.

Golden actual API values at p=3MPa, TL=285/300/305/320 K, including raw h,
Hs/Hc, gas Ha/Hs/Es/Hc, hl and enthalpyDifference, are stored in
fitting/dpm/m8a_v1/*/golden_energy.csv. These are native-model values, not
experimental liquid data or a new EOS/reference table.
