# M8A.3 evolved state inventory and ownership blocker

Status: MODEL_TRANSACTION_BLOCKER; M8A.3 PARTIAL.

## Required snapshot

S_cloud consists of the ordered native parcel container, identities,
all native parcel fields, every selected model's mutable state, full Random
value, cloudSolution runtime state, outputProperties/model-property state,
native transfers/coefficients, and accepted diagnostic trajectory integrals.
S_total additionally includes exact Q/P2, rank-local allocator, pending output
and distributed trial communication/decision state. The following inventory
defines requirements; it is NOT an implemented complete snapshot format.

| State / object | Classification | Required action | Current evidence |
|---|---|---|---|
| Parcel ordering, membership, identities and all native serialized fields | Authoritative | Exact ordered deep copy | A/B/C native clone serialization equal |
| Parcel active/velocity/thermal/composition/turbulence/spray breakup history | Authoritative | Preserve all declared fields, no endpoint reconstruction | Parcel serialization equal; forced histories not proven |
| origProc/origId and shared process-local particleCount_ | Authoritative | Preserve identities and exact counter transaction | Prior component proof retained, no evolved transaction |
| InjectionModel massInjected_, nInjections_, parcelsAddedTotal_, time0_, timeStep0_ | Authoritative | Copy exact values, bind to new owner | Native copy can retain values but owner is unsafe |
| ConeInjection sizeDistribution_ and nested Random& | Nested ownership/configuration + RNG dependency | Reconstruct/rebind with copied full Random | Native clone retains old RNG reference |
| Random x_, scalarNormalStored_, scalarNormalValue_ | Authoritative | Copy the entire Random value | Native cloud copy does copy Random value; injector uses original instead |
| Dispersion model owner and parcel UTurb/tTurb | Authoritative references/history | New owner + copied parcel state | Native clone owner aliases committed |
| Dispersion k/epsilon caches | Derived, only if recomputed from identical immutable fields | Rebuild at trial preEvolve, validate future equivalence | Full proof absent |
| sphereDrag owner/switch/cache and parcel/source response | Config + runtime derived data/references | New owner, preserve switches, validate accepted baseline | Native force owner aliases committed |
| BlobsSheet/Reitz coefficients | Immutable configuration | Share/copy immutable values | Not a substitute for parent/child state transaction |
| Parent breakup variables, created children and allocation sequence | Authoritative | Deep ordered copy and transactional creation | Forced child transaction absent |
| ORourke pair-list occupancy | Derived from ordered parcels | Deterministic rebuild preserving pair order | Native source constructs local pair lists; retry proof absent |
| ORourke parcel mutation/deletion and Random decisions | Authoritative | Preserve parcel state and correct RNG ownership | Native owner aliases committed |
| ORourke liquids_ reference | Immutable constitutive data if proven immutable | Sharing may be safe; lifetime must remain valid | Not automatically a mutable-state bug; owner alias still unsafe |
| Rebound parcel state and interaction/model statistics | Authoritative + output state | Preserve both, new owner/properties binding | Native owner aliases committed |
| subModelBase properties_ dictionary reference | Mutable model-property store | Bind to trial outputProperties, copy dictionary contents | Copy retains smb.properties_ |
| outputProperties_ | Output/statistics store with possible restart relevance | Own trial copy and bind every nested model to it | Cloud dictionary copy does NOT rebind model properties_ |
| cloudSolution iter_/trackTime_/runtime switches | Authoritative runtime scheduling | Copy/retain exact state; no fresh initialization | Native cloud copy exists; native restore completeness still insufficient |
| rhoTrans species arrays, UTrans/UCoeff, hsTrans/hsCoeff | Authoritative trial source/coefficients | Deep trial-owned copy/reset according to frozen ordering | A/B/C source initialization equal; future source isolation unsafe through owners |
| pAmbient_ | Runtime cloud value | Preserve/recompute only with demonstrated equivalence | Not declared freely rebuildable without proof |
| cellOccupancyPtr_ / cellLengthScale_ | Derived mesh/ordered-parcel cache | Rebuild deterministically; validate order | No full evolved retry proof |
| VoidFraction thetaPtr_ trajectory-time integral | Output-only diagnostic state | Preserve accepted trial integral, defer release once | Native copy discards pointer state; prior source evidence retained |
| TrackingData / interpolation objects | Ephemeral derived objects | New trial tracking data, immutable carrier references | Must not carry committed mutable transfer pointers |
| Mesh and fixed carrier fields during a trial | Immutable shared input | Lifetime and no-write guarantee | Shared inputs in standalone audit |
| SLGThermo/composition constitutive tables/configuration | Immutable only where established | Explicit safe sharing or new owned model | Owner-bearing mutable submodels still need rebind |
| Q/P2 and source increment | Authoritative Eulerian state | Exact snapshot, coherent recovery, one logical publication | Not created/committed by this audit |
| Pending files/statistics/diagnostics | Output-only pending state | No permanent trial IO, release after successful commit | Full evolved output commit absent |
| MPI trial parcels/buffers/decision | Authoritative distributed execution | Trial receivers only, drain, collective accept/discard | Full protocol/test absent |

## Proven reference chain

Actual Foundation OF7 sources:

- CloudSubModelBase copy: owner_(smb.owner_).
- subModelBase copy: properties_(smb.properties_).
- ConeInjection copy: sizeDistribution_(im.sizeDistribution_().clone().ptr()).
- distributionModel copy: rndGen_(p.rndGen_).
- KinematicCloud copy: rndGen_(c.rndGen_), but model cloning preserves the
  old references above.

Consequently a separately copied Random value and exact parcel/source copies
do not establish isolation. In evolved states A/B/C, invoking the cloned
injector's real setProperties changes committed RNG but leaves clone RNG
unchanged. Native clone is rejected as a transaction candidate.

## Supported conclusion and stop

The current model/clone API lacks a complete owner/properties/nested-RNG
rebinding contract for copying arbitrary evolved clouds. The project has no
validated versioned adapter that supplies that contract. This is a current
implementation blocker, not proof that these physical models can never be
transactional. Per user section 51, development stops at this blocker.

Recommended next decision: project-local versioned model/cloud adapters
with explicit new-owner, new-properties and new-RNG binding. A proposed
cloneForTrial(owner, properties, random) API is DESIGN ONLY and is not an
existing OF7 function. It must preserve injection timing/counters, all
parcel history, Random normal-cache state, cloudSolution and source/output
state and pass evolved native/reference versus trial future equivalence.
Reassigning C++ references, raw memory copying, const_cast reparenting and
fresh dictionary reconstruction are not accepted substitutes.

No selected model is disabled. Scope reduction requires a separate user
decision; it is not performed in this round.
