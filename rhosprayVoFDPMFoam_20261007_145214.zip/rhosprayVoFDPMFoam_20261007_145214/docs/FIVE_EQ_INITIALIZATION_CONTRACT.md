# M5C.3 initialization and startup contract v1

`fiveEqInitialStateBuilder` delegates to the coherent boundary state constructor. Cold start: physical primitive/material data → real phase EOS → complete Q/P2 → recover every cell → assign oldTime=committed → derive all views/caches → reconstruct/recover faces. No legacy rho/rhoE plus independently read alpha mixing. Only present phases require their T/Y; absent phase masses/species exactly zero. No guessed gamma/Rair/nominal liquid density or CoolProp runtime initializer.

Initial reference liquid: pL_ref=3 MPa,TL=300 K using production ndecane_gibbs_v1; rhoL≈727.432960545318 kg/m³,eL_solver≈-66.4153259710411 J/kg (negative sensible reference energy is legal). Gas engineering initializer p=188330.307 Pa,TG=400 K,Y(C10H22,O2,N2)=(0,.228,.772): actual OF7 rhoG≈1.63268590011162 kg/m³,eG≈-11812.9587301765 J/kg. Supplied nominal rho1.6338 is not imposed over EOS. These are initializer calculations, not new CFD results. Legacy case values differ.

Mixed initialization uses common p, common U,independent TG/TL and authoritative minority input. Momentum/energy use rhoMix=mG+mL. Gas species stored in runtime order; final dependent runtime species residual as frozen. Roundtrip checks p within1e-8 relative (or1e-4 Pa absolute),U1e-7 m/s,TG/TL1e-8 relative,Y1e-12; recovery internal tolerances remain untouched. These are inherited contact/representation gates, not a new EOS fitting tolerance.

## Frozen startup ownership

Future fields are owned in memory by the one complete committed tuple. Exact record is the normative disk authority; standard output fields are diagnostic exports of the same tuple, not a second restart source.

| Item | Cold start | Restart | Write/role |
|---|---|---|---|
| fiveEqInitialConditions (physical inputs, phase minority tags) |MUST_READ|NO_READ|configuration; optionally spatial physical input fields referenced explicitly|
| fiveEqRestart-v1 complete bundle +partition/global-address manifest |NO_READ|MUST_READ|accepted-state exact record; P2 and all Q plus oldTime,geometry,time|
| mesh/geometry and thermo/species/EOS configuration |MUST_READ|MUST_READ; match identity|normal mesh/config ownership; complete-state/mesh consistency required|
| phaseFractionCoordinate (P2 runtime scalar) |NO_READ,from initializer|NO_READ,from exact record|NO_WRITE ordinary scalar; exact-record output only|
| mG,mL,M,Et,mYi (conservative runtime fields) |NO_READ,from initializer|NO_READ,from exact record|AUTO_WRITE views of authoritative tuple; not independent restart inputs|
| alphaL,alphaG,rhoMix,U,Yi |NO_READ,decode|NO_READ,decode|AUTO_WRITE diagnostic views; dominant alpha may round to1|
| p,TG,TL,rhoG,rhoL,cG,cL,cMix,Kthermo |NO_READ,recover|NO_READ,recover|AUTO_WRITE; absent-phase data explicitly tagged unavailable|
| phi/F_mG/F_mL/F_M/F_E/F_mYi and alpha operator fluxes |NO_READ,recompute|NO_READ,recompute|optional AUTO_WRITE; stage generation stamped|
| prior diagnostic outputs |optional READ_IF_PRESENT by verification utility only|same|compare/report then overwrite from authoritative recovery; never modify Q|
| cloud parcel records/transfer metadata |existing ownership until M8A|M8A must define synchronized accepted restart|mandatory pre-M6B source/IO adapter; not added here|

Restart flow: validate schema/identity/addressing → load all authoritative levels → recover whole committed/old tuples → reconstruct derived caches → validate boundary physical specifications and recover boundary Q → recompute flux/dt. Do not use stale p as pressure authority. No mixed startup combines only selected new fields with legacy fields. Missing exact P2/Q data causes failure, not READ_IF_PRESENT fallback.

The bundle reading policy avoids duplicated field authority. Actual M6B IOobject wiring, field registry, patch classes and atomic mesh/parcel checkpoint publishing are still unactivated; their implementation must obey this table. Standard `alphaL` visualization output is not a restart field.
