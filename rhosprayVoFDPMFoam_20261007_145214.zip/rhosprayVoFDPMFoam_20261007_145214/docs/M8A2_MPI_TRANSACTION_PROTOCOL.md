# MPI transaction protocol — design only except allocator test

Open MPI 4.1.2 and mpic++ are available locally. Environment is NOT a blocker.
testMPIAllocator tests the actual OF7 static particle counter plus all-rank
AND rejection/acceptance on two ranks (2002 checks). It neither transfers
parcels nor evolves spray models. Full processor-crossing test remains required.

## Begin

All ranks agree transaction generation, committed time, dt and ordering.
Each rank saves its exact process-local particle::particleCount_. Identity is
(origProc,origId), preserved across native processor transfer. No ID remapping.
Each rank constructs an independent owned trial from its committed cloud,
models, RNG, sources and Q. No committed occupancy/list is touched.

## Evolution/transfer

Sender removes parcels only from its trial container, serializes the full
native parcel identity/state, and receiver inserts only into its trial.
Both source accumulators remain rank-local; decomposition volume factors
are used once by the frozen adapter. Receiver validates its actual local
and coupled-boundary interpolation stencil before querying the carrier.

A local support/model/recovery failure marks the rank invalid. It MUST NOT
throw out of a collective particle-transfer loop while peers still enter
that collective: propagate failure via a synchronized cancellation protocol,
drain pending transfer buffers, and reach a collective decision. This is not
implemented by the current serial exception hook.

## Decision

All ranks reduce validity by logical AND, with outstanding communications
completed. Any invalid rank forces every rank to discard trial state/Q and
restore its own counter. Retry repeats from the same generation/ordering.
Only unanimous acceptance publishes trial cloud and Q and retains counters.
Perform collective uniqueness checks on (origProc,origId), global mass/species/
momentum/Et ledger checks and deterministic ordering checks in the harness.

## Output

No rank writes trial files/statistics. Accepted output is released after the
collective logical commit. A post-commit I/O failure is reported as an I/O
failure, never retroactively treated as a reversible physics trial.

## Required integration harness

Two ranks, a manufactured decomposed mesh, real native cloud processor
crossing, nonzero source deposition, rejection on only one rank, global
discard, smaller retry versus direct-small-step, identity uniqueness and
byte-exact golden parcel/model/source/Q/P2/output comparisons. NOT EXECUTED.
