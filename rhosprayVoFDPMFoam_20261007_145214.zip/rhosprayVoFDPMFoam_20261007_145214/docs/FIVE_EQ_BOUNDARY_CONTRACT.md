# M5C.3 boundary contract v1 — passive

`fiveEqBoundaryStateBuilder::build(BoundaryPrimitive)` takes authoritative P2 plus common p, common vector U, TG/TL for present phases and canonical gas Y. It generates complete Q from the installed JANAF/perfectGas sensibleInternalEnergy evaluator and frozen production liquid EOS; residual runtime species is computed by the frozen constructor. `recoverBoundaryState` uses the P2-aware recovery, identical to face recovery, and rejects incoherent states. No alpha/pressure/EOS clamp. A state builder is **not** a complete characteristic patch implementation.

Pure gas: P2=+0,mL=0,mG=rhoG(p,TG,Y), M=mG U, Et=mG eG+kinetic,mYi=mG Yi. Pure liquid: P2=-0,mG=mYi=0,mL=rhoL(p,TL), M=mL U,Et=mL eL_solver+kinetic. Mixed: mG=alphaG rhoG,mL=alphaL rhoL,Et=mG eG+mL eL_solver+kinetic; TG may differ from TL. Specify trace using `(minorityPhase,minorityValue)`/signed P2; decoded alphaL=1 cannot encode alphaG=1e-20.

## Injector contract

Locked physical intent: one round hole,d=.3 mm, no internal nozzle, C10H22,mdot=1.09609e-4 kg/s,TL=300 K. 3 MPa is the **reference/initial** liquid pressure, not a third fixed boundary condition. Patch outward normal n; incoming integrated `sum(F_mL)=-mdot`. The real KT mass flux is constrained; setting rhoU to mdot/A alone is insufficient when KT dissipation contributes.

Future patch unknowns include responding p and normal velocity. Solve jointly:

`sum_faces F_mL^KT(Q_interior,Q_boundary(p,u_n,TL),S,meshPhi) + mdot = 0`

`C_out(Q_boundary,Q_interior,geometry,time) = 0`

with TL fixed, pure-liquid P2=-0, prescribed injection direction/tangential velocities and production rho/e. C_out is the outgoing acoustic characteristic compatibility relation, built using actual EOS derivatives; it must not use a guessed constant liquid gamma/Riemann invariant. Once solved: mL=rhoL(p,300),M=mL U,Et=mL eL+kinetic, recover all faces. Two acoustic unknowns/two relations; entropy/temperature and tangential incoming data complete the subsonic state. Pressure responds to the domain, rather than setting p=p_inf or p=supply pressure. Nonuniform multi-face patch requires a declared distribution and one global integrated constraint; no per-face overconstraint.

This round-hole 3D mass flow **cannot silently become** a 2D per-depth flow; reduced-case extrusion depth/represented area and physical-to-computational mdot scale must be specified before activation. Normal velocity sanity from the production reference density is about2.132 m/s; it is not a fixed-velocity BC. The characteristic/integrated KT inlet solver is designed here, not implemented/validated. Reverse flow or loss of a subsonic regime requires controlled regime switching/stop, not pressure clipping.

## Characteristic count (outward normal, ALE relative velocity)

Principal eigenvalues: un-cMix,u (material/composition/entropy/tangential modes),un+cMix. Use the actual full material state, not gas Mach alone at a mixed patch.

| Regime | Boundary input | Domain input |
|---|---|---|
| Supersonic inflow: un+cMix<0 | all independent primitive/material data; build/recover Q | none required for incoming characteristics |
| Supersonic outflow: un-cMix>0 | no independent p/T/U values | coherent extrapolated complete Q/P2 |
| Subsonic inflow | incoming advected data plus one acoustic specification (mdot or suitable acoustic condition) | outgoing acoustic compatibility determining responding p |
| Subsonic outflow | one incoming acoustic condition (e.g. external static pressure) | outgoing characteristics/material data |

Current legacy fixedValue p/T/U inlet and waveTransmissive pressure outlet are not automatically valid fiveEq BC combinations. Common pressure makes independently imposing two phase pressures invalid. Gas high-Mach supplied engineering scenario is approximately M5.02; actual stored case is a different scenario as audited.

## Wall, symmetry, empty, wedge, processor

Inviscid stationary wall/symmetry: copy P2,masses,Et,species; reflect normal momentum (Mghost=M-2(M·n)n); recover ghost. Frozen shared KT flux then has zero material/energy normal flux, pressure traction remains in momentum. Moving wall uses relative normal no penetration and corresponding pressure work; not tested/implemented here. Viscous wall must separately provide velocity no-slip/slip, wall heat condition and phase-resolved stress/conduction law; do not reuse gas-only alphaEff as mixed closure. Contact angle belongs to M7 and must not change conservative masses.

empty: suppress out-of-plane faces, preserve scalar payload and in-plane M; require valid 2D mesh/motion. wedge: scalars/P2 copied bitwise, M rotated by the geometric orthogonal transform; Et unchanged under a pure coordinate rotation. symmetry is orthogonal reflection. processor: authoritative coordinate bytes and all conservative fields exchanged; momentum rotated only for a transforming coupled patch. Never average signed coordinates across opposite branches. Standalone reflection and IO/pack/partition tests support these contracts; actual new patch classes/decomposePar/reconstructPar hooks remain future integration work.
