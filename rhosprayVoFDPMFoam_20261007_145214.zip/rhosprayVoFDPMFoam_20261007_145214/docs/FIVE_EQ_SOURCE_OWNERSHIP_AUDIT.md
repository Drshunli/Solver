# M5C.3 source ownership audit and passive ledger

Audited active main/createFields/rhoEqn/rhoUEqn/rhoYEqn/rhoEEqn/interfaceGeometry, installed Foundation7 cloud/chemistry/thermo sources. No active source relocation. Current physical case chemistry,radiation,parcel heat transfer and phase change are none; parcel drag and tracking remain active. Commented expressions are not active sources.

| Source/operator | Actual legacy target and placement | Future owner/target | Temporal contract and blocker |
|---|---|---|---|
| Gas convection |phi→rho;phiUp→rhoU;phiEp→rhoE;multivariate phi Yi→rhoYi |shared two-material KT→mG,mL,M,Et,mYi |R1 face stage; retire all independent legacy convective solves atomically at authorized M6B|
| Pressure traction/work |inside phiUp/phiEp; ALE absolute pressure work added |same shared KT→M/Et |already flux ownership; no additional grad p or p work source|
| Alpha divergence/compression |legacy MULES +alpha div(phiV),interface compression/subcycling |P2 discrete material alpha operator |same stage wave/volume flux; legacy MULES must not update authoritative P2|
| Viscous stress |U correction:muEff laplacian +div tauMC; rhoU rewritten |resolved stress owner→M |after inviscid flux in coherent source solve; constitutive gas/liquid/common-U closure must be specified before enabling|
| Viscous work |div sigmaDotU in conservative rhoE solve |same stress owner→Et |paired traction/work discretization, no duplicate dissipation; source-stage recovery|
| Heat conduction |viscous e correction laplacian(alphaEff,e); rhoE rewritten |phase heat model→Et (and thermal closure) |TG≠TL means one e diffusion is insufficient; disable pending explicit thermal-model closure|
| Species diffusion |muEff Yi laplacian in viscous branch |gas diffusion owner→mYi;associated energy flux→Et |αG/intrinsic gas basis and total ΣJ=0; enthalpy/energy diffusion ledger pre-enable blocker|
| Chemistry species |reaction.correct beforeYi;reaction.R(Yi) RHS |gas chemistry adapter→mYi; ΣS_i=0→no netmG |source stage; rates gas-volume→bulk usingαG if rates evaluated per gas volume; do not weight already bulk-integrated rates again|
| Chemical heat |reaction.Qdot in rhoE |same chemistry adapter→Et |paired −ΣHc_i S_mYi; sensible-reference identity below|
| Turbulence |muEff/alphaEff diffusion; turbulence.correct afterenergy |closure owner→stress/thermal/species source coefficients, auxiliary k/omega |must sample recovered gas/material state; legacy gas-only kOmegaSST is not certified as two-material LES/RAS; pre-enable blocker|
| fvOptions |object created; active equation files have no fvOptions source/constrain/correct calls |typed source registry→explicit requested Q components |reject unspecified field targeting/independent primitive overwrite; currently none|
| Radiation |radiation.Sh(thermo,e) in viscous e correction;modelnone |gas radiation adapter→Et |source stage; clear gas-volume/bulk units, TG and chemical reference; disabled until specified|
| Gravity force |rho g only in viscous U correction |body-force owner→M=S=(mG+mL)g |source stage; include paired U·S in Et; must not disappear when inviscid|
| Gravity work |rho U·g only in viscous e correction |same body-force owner→Et |total-energy work pairing; no addition to both internal and total ledgers|
| Parcel mass |parcels.Srho(rho) in rho solve |M8A→mG,ΣmYi |gas-carried; mL unchanged unless separately authorized transfer; no duplicate species/mass deposition|
| Parcel momentum |parcels.SU(U) only viscous correction |M8A→commonM from gas interaction ledger |sampling intrinsic rhoG/TG/gastransport; common-velocity response is shared mixture momentum, not direct liquid drag law|
| Parcel sensible heat/enthalpy |parcels.Sh(e) only viscous e correction |M8A→Et |hsTrans is not automatically total energy: mass enthalpy,pressure/kinetic/drag work and reference mapping require conservation audit|
| Parcel species |parcels.SYi(i,Yi) inYi solve |M8A→mYi;ΣS_mYi=S_mG |same accepted parcel event; no additional S_mG weighting if ledger already integrated|
| Surface tension |interfaceProperties force onlydiagnostic;noequationRHS |M7→M and pairedEt work/interfaceenergy |not active; curvature/sigma alone do not close discrete energy|
| VOF↔DPM |absent |future conservative transfer→all relevant ledgers/P2 |not part of M5C.3/M8A; no volume/mass double count|

## Chemistry and energy reference

Actual Foundation7 JANAF `Hs=Ha-Hc`, gas `Es=Hs-p/rho`; sensibleInternalEnergy selects Es. Hc is the species reference chemical enthalpy. It is excluded from current gas Et. Installed `StandardChemistryModel.C::Qdot()` computes **−ΣHc_i RR_i**, and laminar::R(Y) returns RR_i; laminar::correct integrates/calculate chemistry before carrierYi. noCombustion::R is zero matrix,Qdot zero. Current three-species dictionary has no enabled reaction mechanism.

For a future coherent chemistry substep with gas bulk species sources S_i:

`d(mYi)/dt=S_i`, `ΣS_i=0`, `dEt_sens/dt=−ΣHc_i S_i`.

Thus `d[Et_sens+ΣmYi Hc_i]/dt=0` in a closed chemical substep (no external work/heat); liquid production reference is unchanged. This identity does **not** mean setting chemical heat to zero. Kinetics must use actual intrinsic gas state, runtime species mapping and volume normalization. `fiveEqSourceOwnership.H` is a passive implementation of this identity, tested with actual OF7 Hc and gas-volume weighting. It does not integrate a reaction or change Et in runtime.

Current nonreacting ledger is closed. **Pre-M6B reactive-mode blocker:** a real mass-conserving mechanism, gas-volume chemistry adapter, paired source-step recovery/positivity and diffusion/chemistry ledger tests are needed before enabling reacting fiveEq; otherwise first activation must explicitly reject chemistry-on. No fresh JANAF energy offset or guessed formation energy introduced.

## DPM/M8A mandatory interface

Per accepted cell/event: `(ΔmG,ΔM,ΔEt,ΔmYi)` withΣΔmYi=ΔmG, and an equal/opposite parcel ledger plus any declared external injection contribution. Normalize **once** by bulk cell V and accepted dt. Do not multiply an already integrated ledger byαG again; gas weighting pertains to interaction model/sample availability, not destroying a conserved transfer. If gas absent or trace model invalid, use explicit event policy/controlled stop, not mass disappearance or carrier rhoMix. P2/phase-volume response to gas mass/energy injection and reference/kinetic work must be derived in M8A.

`ReactingParcel.C` accumulates rhoTrans,dm U0 and dm carrier.Hs plus dragUTrans and heat hsTrans; Cloud Srho/SYi/SU/Sh form dimensional source matrices with volume/dt normalization and optional implicit parts. This is why blindly copying matrix Sh to Et is prohibited. Full definitions are captured in the audit source folder. Eulerian liquid e is production-reference sensible energy; DPM liquid h/Hs reference and caloric differences remain a mandatory M8A audit.

## Future source ordering

Flux proposal→complete-Q recover→(gravity/stress/diffusion/chemistry/parcel/radiation/capillary source stages, only explicitly enabled owners)→whole-Q recovery→commit. Source order/implicit grouping is configuration-versioned, not inherited include order. First inviscid nonreacting mechanical activation has zero unsupported physical sources; current viscous/RAS case cannot be advertised as unchanged fiveEq physics without these adapters. Enabling unsupported sources is a configuration failure, not silent omission. M8A is mandatory before M6B permission is reconsidered; M7 remains future capillary stage.
