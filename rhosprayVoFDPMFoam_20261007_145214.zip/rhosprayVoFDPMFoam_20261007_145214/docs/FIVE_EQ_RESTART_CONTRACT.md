# M5C.3 restart/communication contract v1

## Authoritative format

Standalone implementation: `fiveEqP2IO.H`. Schema `fiveEqRestart-v1`, fraction encoding `P2-v1`, architecture `binary64-hex-msb`, EOS `ndecane_gibbs_v1`, runtime species-order signature. IEEE binary64 required; each floating datum uses16 exact hexadecimal bits. Records contain accepted step/time/lastDt,N, two complete levels (committed and oldTime), stable local cell IDs, volumes,P2 coordinate,mG,mL,Mxyz,Et,mYi. q[0] is omitted and regenerated as a non-authoritative view. Only one physical alpha DOF.

Byte order is represented numerically with most significant hex digit first, independent of host memory endianness. FNV-1a64 checksum detects accidental corruption, **not** malicious tampering. Unknown version/architecture/EOS/species order, incomplete/trailing payload, nonfinite data, illegal coordinate, bad volume or EOS-invalid complete tuple cause controlled failure. Reload recovers all cells and both levels before returning. Schema uses the frozen production default energy offset; native-validation/other-offset EOS must not read it as the same production model.

Standalone writer is direct-file and checksum-checked on read; production checkpoint publishing must add temp-file +atomic rename/manifest across partitions, and bind mesh/global addressing, gas thermo/production coefficients/energy-reference fingerprints. This is activation integration plumbing, not claimed as implemented. A partial write is rejected; it cannot produce an accepted restart state.

## Actual Foundation7 stream comparison

16 coordinates: both sides of0,1e-20,1e-16,1e-12,1e-8,.12345678901234567,nextafter(.5,0),.5. Tests use **Foam::OFstream/IFstream and scalarField**, not a substitute decimal parser.

| Mode | Precision | Coordinate bit mismatches | P2 authority allowed |
|---|---:|---:|---|
| Current case ASCII |6|5/16|NO|
| Maximum decimal binary64 round-trip precision ASCII |17|1/16 (-0)|NO|
| OF7 binary scalarField, local DP architecture |17 (irrelevant binary)|0/16|Only with version/architecture metadata and verified exact payload path|
| Implemented exact-bit record |exact|0|YES, chosen normative restart|

ASCII17 emits `-0` but OF7 tokenized reading returns +0; phase encoding changes even though scalar equality says equal. Other nonzero ASCII17 entries round-trip here. Binary preserves -0 and all tested trace payloads. A custom nonstandard ASCII `-0.0` policy is not validated or permitted by this schema; exact hex avoids parser ambiguity entirely. Ordinary `writePrecision` has no effect on the normative record.

## Restart policy

Legacy alphaL-only/gas-rho restart: reject as non-fiveEq. Cold-start conversion, if separately requested, must explicitly declare loss of dominant-side trace and generate Q through production EOS from physical inputs; never treat missing information as recovered. Derived output p/T/rho/c/U/Y cannot repair or overwrite conservative restart authority. Comparison may flag stale diagnostics; all output caches are overwritten by recovery.

Only accepted states serialize. Trial buffers are local and cannot appear in oldTime/disk state. Both time levels are exact; time/lastDt exact; restart is not a request to reinitialize Et from old primitive files. New Euler driver restart-continuation checks all Q fields,P2,volumes,oldTime,time and step bitwise.

## MPI and offline partitioning

`packP2/unpackP2`: exactly8 network-order bytes, version negotiated outside buffer; no decoded alpha. Offline tests split complete states into3 addressed partitions, write/destroy/reload/merge and compare bits. Future decomposePar/reconstructPar must carry exact records with stable global cell/face addressing and manifest, reject missing/duplicate IDs and schema mismatch. Standard scalar ASCII utilities cannot be applied to authoritative P2; no signed-coordinate interpolation or decoded-field re-encoding. No MPI CFD/decomposition utilities were run here.
