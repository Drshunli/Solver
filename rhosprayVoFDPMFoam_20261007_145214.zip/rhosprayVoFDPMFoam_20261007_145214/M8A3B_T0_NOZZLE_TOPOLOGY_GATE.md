# M8A.3B-T0：喷孔几何、初始拓扑及 DPM 所有权审计

日期：2026-10-01。实际输入：`D:/DATA/Solver/300_2D`。
只读审计证据：`fitting/dpm/m8a3b_t0_v1/audit.json`。

## 1. M8A.3B-T0 status

**PARTIAL / 2D_INJECTION_MAPPING_BLOCKER**。
实际网格没有 Eulerian liquid hole-exit patch。旧 DPM 等效面积存在，
但没有冻结用于物理喷孔质量预算的 Eulerian 二维映射。
按用户第 3 节停止规则，不创建 synthetic liquid cores，不继续完整事务。

## 2. Actual coordinate system

实际压缩 ASCII points/faces/owner/neighbour 全部读取。
21000 cells、42622 points、84310 faces、41690 internal faces。
米制直角坐标：x=[0,0.080]、y=[0,0.030]、z=[0.014975,0.015025]。
二维计算面 x-y，z 中心 0.015m，单层厚度 **50μm**，frontAndBack 为 empty。
实际 0/U 内部及 inlet 为 (517.6,0,0)，气流方向 **+x**。
这是 legacy 文件值，不是已确认未来工况 U∞=2013.039m/s；不修改它。
旧 DPM direction=(0,1,0) 只定义 parcel 注入方向，不定义 Eulerian 喷孔法向。

## 3. Injection wall/patch

actual boundary 只有下列五项；用实际面顶点积分确认面积及外法向。

| Patch | Plane | Faces | Dimensions | Area (m²) | Outward normal |
|---|---|---:|---|---:|---|
| inlet |x=0|100|30mm × 50μm|1.5e-6|(-1,0,0)|
| outlet |x=80mm|100|30mm × 50μm|1.5e-6|(1,0,0)|
| bottomWall |y=0|210|80mm × 50μm|4e-6|(0,-1,0)|
| top |y=30mm|210|80mm × 50μm|4e-6|(0,1,0)|
| frontAndBack |z=14.975/15.025mm|42000|每侧80mm × 30mm|两侧合计4.8e-3|(0,0,±1)|

bottomWall/top 的 U 均为 noSlip，p/T 为 zeroGradient。
没有从 bottomWall 中分割的喷孔 patch；不能把整个 bottomWall 或气体 inlet
指定为液体入口。bottomWall 的整体面积/中心不是喷孔面积/中心。
system/blockMeshDict:154 与 actual boundary:32 一致。
snappyHexMeshDict、topoSetDict、createPatchDict 在 system/constant 均不存在。
唯一 mesh set `twoInternalFacesCells` 是四个 cell IDs 的 cellSet，不是喷孔 faceSet，
也没有用于材料赋值的字典调用。set 内容已另存证据。

## 4. Hole center

**UNRESOLVED**。无 hole-exit patch，无法从真实 mesh 提取中心。
不得由 DPM 点反推 (0.015,0,0.015) 是真实喷孔中心。

## 5. Hole normal

**UNRESOLVED**。bottomWall 外法向已确认为 -y，DPM 方向已确认 +y，
两者不能代替不存在的 hole-exit patch 法向。

## 6. Physical hole diameter

用户确认：**单个圆孔，D=0.3mm**，internalNozzleIncluded=false。
三维物理截面积 `πD²/4 = 7.068583470577e-8 m²`。
这是物理目标，不意味着 actual mesh 有圆孔或等面积槽。

## 7. 2D equivalent mapping

actual sprayCloudProperties:88 明确写：
`π*dOuter²/4 = (300μm)*(50μm)`，dOuter=138.1976598μm。
离线几何核对得到 `π*dOuter²/4 = 1.5000000002489e-8m²`，
与注释槽面积 1.5e-8m² 一致。

**该证据属于 legacy point-cone DPM injector**：它使用 injectionMethod point，
并未定义 mesh 上 300μm 宽的入口 face 集合。面积是物理圆孔面积的
0.2122065908 倍，不是原圆孔的等面积二维替代。
因此生产 Eulerian 的槽宽、所代表的三维份额/深度和质量流量归一化
尚未同时冻结，不能直接继承这条注释为 production mapping。
本轮不选择全孔质量流量映射或截面份额缩放中的任何一种。

## 8. Effective inlet area

**Production Eulerian inlet area = UNRESOLVED/null**。
已知 50μm mesh extrusion depth 和 legacy 1.5e-8m² DPM 等效面积，
不等于已有 Eulerian inlet area。没有创建 patch 或改边界条件。

## 9. mdot consistency

物理目标保持 `ṁ=1.09609e-4kg/s`、TL=300K。
入口应满足 `ṁ_in = ∫_A ρL U·n_in dA`；n_in 指向域内。
缺少真实入口 A 和物理→二维质量预算规则，故 **integrated Eulerian flux 未验证**。
实际 bottomWall noSlip，当前边界没有液体注入通量，不能称目标流量已实现。

legacy DPM massTotal=0.0005262723452kg，duration=1s，
恒定 profile=(1,1)；配置对应平均注入率 5.262723452e-4kg/s，
为新物理目标的 **4.801360702 倍**。这是配置审计值，不是运行实测流量。
未使用历史错误的 2.62583 作为缩放因子，未修改旧值。

未来 BC 冻结为 prescribed ṁ + TL；压力响应机械波。
pL_ref=3MPa 仅 reference/initial state，不作为第三个独立 Dirichlet。
既不指定正式 UL，也不设置 mdot+TL+p 三重固定条件。

## 10. Initial alpha topology

正式记录 **INITIAL_TOPOLOGY_V1：initial interior = gas**。
未来液体只能由 Eulerian inlet 进入；入口 patch 尚未定义。
actual 0 无 alphaL/alphaG/rho*/mG/mL/P2；只有 alphat，量纲为
[1 -1 -1 0 0 0 0]，不是相体积分数。
0/theta=0，0/C10H22=0；后者是 gas species field，不是液体 alpha。
thermo 为 perfectGas carrier；constant 中 liquids/C10H22 是 DPM 物性表。
该拓扑是审计后的初始化合同，**未生成 fiveEq/P2 初始场**。

## 11. Whether a prefilled liquid column exists

**不存在 case 文件明确指定的 Eulerian prefilled liquid region**。
setFieldsDict 仅设置 T/p/U/species；未设置液体 alpha 或五方程相质量。
Td=300 是诊断温度字段，不证明液柱存在。

setFieldsDict 还含历史 H2/C7H16 物种项及 +z 速度赋值；第二 box 的
z∈[0,0.001] 与实际 mesh z∈[0.014975,0.015025] 不相交。
这些均不构成液体初始化，且未运行 setFields 去改变现有 0 场。
controlDict 仍为 application rhosprayVoFFoam、startFrom latestTime；
本轮讨论 t=0 输入，不把已有 1e-06 输出当作初始液柱或新运行结果。

## 12. If yes, actual length/shape

不适用。未根据旧 DPM atomization 的“液芯长度”注释建立 Eulerian 液芯；
parcel liquid-core history 与预填 Eulerian liquid region 是不同对象。

## 13. If no, initial column length = 0 confirmation

**initial interior Eulerian liquid-column L=0**，已按本轮指令冻结。
没有增加任何任意长度、半径或液相体积。

## 14. Synthetic runtime topology family

**NOT CREATED / MAPPING BLOCKER**。
保留待满足的规范：以 actual hole-exit patch 为起点，沿 injection normal，
L/D=1/2/5/10，横截 footprint 使用真实批准的二维映射，另含 1/2/3-cell
TRACE_PRESENT buffer，由 P2 构造，标签 SUPPORT STRESS TOPOLOGIES。
目前中心、法向和 footprint 不全，不能实例化几何。
这不影响 L=0 的物理初始合同；未来 stress core 不属于真实初始条件。

## 15. Existing DPM point location

`TEST_DPM_INLET=(0.015,5e-6,0.015)m`。
距真实 bottomWall **5μm**，距两 empty 面各 **25μm**。
点的 x=0.015 正好在两个单元共有内部面上。
从实际 owner/neighbour/points 提取包围盒：

| Cell |x范围(m)|y范围(m)|z范围(m)|
|---:|---|---|---|
|1514|[0.01495,0.015]|[0,7.61879793e-6]|[0.014975,0.015025]|
|1515|[0.015,0.01505]|同上|同上|

上一轮同一 mesh 的 native findCell 选择 **1514**；本轮几何重读确认点接触
1514/1515，并不声称在共享面上具有唯一几何 containing cell。

## 16. DPM point relation to nozzle

到 hole center 距离 **UNRESOLVED**；与 Eulerian inlet patch 关系 **UNDEFINED**。
没有 actual nozzle patch，不能认定同孔或指定投影点为孔心。

## 17. DPM point strict-support result

本轮未重跑新 topology 的 strict-support scan，因为 mapping gate 已阻塞。
历史 m8a3b_v1 原生位置 stencil 共 6 实体；其 all-gas **存在性筛查**通过。
这不是 rho/p/T/Cp/mu/kappa/Y 全属性生产合法性认证。
历史 x-plane sharp/trace 诊断图不是本轮要求的 nozzle-origin core family，
不转用其结果为新 family 的 PASS/FAIL。
未来若独立 DPM 点落在纯液芯而失去 gas support，应记录预期不兼容，
不能 bounce/delete/mask，也不能据此把物理 nozzle 改为双重注入。

## 18. DPM inlet ownership

冻结所有权合同：旧 point injector 为 **TEST_DPM_INLET**，仅 standalone/
regression/passive 测试源，排除最终 physical nozzle mass budget。
production physical nozzle mass 由 Eulerian VOF/fiveEq inlet 独占。
最终生产 independent DPM nozzle 默认 OFF；**当前 case 的 active=true 未修改**。
未来 DPM 来源为后续 VOF→DPM milestone，转换本轮未实现。

## 19. Production anti-double-injection rule

同一物理孔的 1.09609e-4kg/s 不得同时由 Eulerian inlet 和 independent
DPM injector 供给。只有用户显式另定义独立物理 DPM source 才可计入另一预算。
这是生产设计合同，尚未通过 runtime 配置校验器强制执行。

## 20. Full support scan result

**NOT RUN THIS MILESTONE**。保留上一轮 census/native comparison 历史证据不变；
没有把历史扫描计作新 topology 完整 strict-support rerun。
本轮只读几何工具的 7 项一致性检查通过，case 和 active 文件哈希未变化。
无 C++ 改动，不需要 wmake；没有 blockMesh/checkMesh/solver 调用。

## 21. Exclusion-band result

本轮 nozzle-core exclusion band **UNRESOLVED**。
上一轮平面诊断的中心距离指标不能代替尚未定义的真实 footprint 周围排除带。

## 22. Whether M8A.3B may resume

**NO**。按第 3/17 节，需先冻结 actual nozzle patch/center/normal、production
2D mapping 与质量流量预算规则，之后才构造 family 并完成逐属性支撑扫描。
这需要下一轮单独授权几何/边界设计；本轮不能改 mesh/case 来补齐。
未继续完整事务、MPI 或 M6B。

## 23. Active solver impact

**NONE**。新增只读 Python 审计、JSON 合同/证据、本报告和阶段状态追加。
active .C/.H/Make 文件及整个 300_2D 的前后 SHA-256 相同；
保留既有 M8A.3A/M8A.3B 代码、报告、结果和检查点。
无 FOAM_SRC 修改、权重修改、CFD 或参数调整。

## 24. Updated milestone matrix

| Milestone | Status |
|---|---|
| M5C.1–M5C.3 | COMPLETE / NOT ACTIVE |
| M8A source/energy | PASS / FROZEN |
| M8A.3A | COMPLETE / frozen serial scope |
| M8A.3B | PARTIAL |
| M8A.3B-T0 | PARTIAL / 2D_INJECTION_MAPPING_BLOCKER |
| INITIAL_TOPOLOGY_V1 | gas interior / L=0 contract frozen; field not generated |
| DPM ownership | TEST_DPM_INLET contract frozen; case not changed |
| M8A overall | PARTIAL |
| M6B.0 | BLOCKED |
| M6B.1 | NO |

STOP。不继续 transaction，不执行 M6B，不运行 CFD。
