# M5C.2 reconstruction and coupled admissibility gate

## 1. M5C.2 status

**PARTIAL / R0 ADMISSIBILITY GATE FAILED**. The low-order prerequisite fails;
this is not a high-order activation-ready result. User section 3 requires R0 to
pass before high-order limiter work, so R1/R2 are withheld. No M5C.3/M8A/M6B/CFD.
Detailed derivation and witnesses: `M5C2_R0_BASELINE_FAILURE_AUDIT.md`.

## 2. Reconstruction candidates

R0 piecewise-constant conservative faces implemented and tested. R1 common-theta
conservative and R2 contact/thermodynamic reconstruction remain requested
candidates, NOT implemented/compared/accepted after the R0 gate failure.

## 3. R0 baseline

Actual cell-to-face copy -> real recoverFaceState -> frozen M5C.1 KT flux ->
explicit trial -> real cell recovery -> commit only if ALL cells valid.
405 uniform pure/near-pure face/update cases PASS; 45,040 stencil faces valid.
42 evolving scenarios: 21 finish, 21 stop. All initial cells valid. R0 is an
experimental reference, NOT an accepted admissible production fallback yet.

## 4. R1 shared-theta formulation

Required Qface=Qcell+theta*deltaQ, one cell theta for every conservative/material
increment and both contributed faces. NOT IMPLEMENTED because R0 prerequisite
failed. No independent alpha or mass scaling was introduced.

## 5. R2 assessment

NOT STARTED. Initial-state construction from EOS p/T is not mislabeled as R2
reconstruction. No comparison or selection claim, including cost/legacy semantics.

## 6. Selected reconstruction variables

Cell authority remains alpha,mG,mL,M,Et,mYi. R0 copies them. p/T/rhoG/rhoL/U/cMix
are derived. Production R1/R2 selection is unresolved. Three species mass slots
follow actual runtime name order in this case-specific offline interface.

## 7. Pure-gas reconstruction regression

Full cell-to-face legacy Minmod/MinmodV comparison NOT RUN. Actual OF7 headers
were audited; none were approximated and claimed equivalent. Frozen M5C.1
supplied-face regression rerun PASS (34,902 assertions); that does not close
R1/R2 reconstruction compatibility.

## 8. Contact reconstruction result

R0 face p/U are recovered from unchanged valid cell states; constant-contact
pressure/velocity checks pass before invalid cell trials. Multistep failures are
separately recorded, not attributed to a nonexistent high-order reconstruction.

## 9. Shock-state reconstruction result

R0 pure-gas and mixed-shock faces are valid/finite until a cell-update failure.
Pure-gas shock-like evolution completes 100/10/10 requested steps. Mixed shock
evolution stops after 8 accepted steps in every cell count. No R1 shock test.

## 10. Alpha face-bound result

R0 faces copy 0<=alpha<=1 from validated cell averages. All tested faces and
trial cells stay within strict bounds; no alpha clipping. No R1 bound guarantee.

## 11. Partial-mass positivity result

R0 tested face and trial mG/mL remain nonnegative with positive total density.
Trace masses are never deleted. This does not imply the frozen presence predicate
or the EOS root will accept all positive states.

## 12. Species reconstruction/closure

Store mYi, derive intrinsic Yi only for present gas. Check nonnegative mYi and
sum(mYi)=mG, reject inconsistent absent-gas species; no normalization. Tested
updates preserve closure. R1 N-1 closure strategy NOT implemented/frozen.

## 13. EOS-domain reconstruction limiter

R0 uses real recovery and has no extrapolation. A high-order EOS/theta limiter
is NOT implemented. Post-update recovery finds both presence-policy rejections
and genuine no-root states; these categories remain distinct.

## 14. Theta-search algorithm

NOT IMPLEMENTED. R0 has no slope increments or theta search. Trace-policy
witnesses demonstrate that monotone/convex admissibility cannot be assumed for
a future bisection search; a valid observed endpoint must always be rechecked.

## 15. Limiter statistics

R0 valid stencil faces=45,040; theta statistics and R1 limiting categories=NA.
Face recovery uses 590,528 gas / 778,088 liquid queries. These exclude initial,
uniform-matrix and post-update recovery queries. Cell update diagnostics distinguish
PHASE_PRESENCE_INCONSISTENT from NO_PRESSURE_ROOT. No invented theta=1 result.

## 16. Alpha timestep derivation

Let D=meshPhiR-meshPhiL, N=-delta(Falpha)+alpha*delta(phiRel).
alphaNew=alpha+dt*N/(V+dt D). Lower/upper constraints give:

```
dtAlpha=min(B(alpha*V,-alpha*D-N),
            B((1-alpha)*V,N-(1-alpha)*D))
B(z,r)=z/r when r>0, otherwise infinity
```

Fixed-grid reduction: (1-alpha)/Lalpha for Lalpha>0, alpha/(-Lalpha) for
Lalpha<0. Physical alpha*divU source is included via GCL cancellation.

## 17. mG/mL timestep bounds

For each phase zNew=(Vz-dt*deltaFz)/(V+dt D). With positive new volume,
dtZ=B(Vz,deltaFz). Implemented separately for mG and mL, without repair.

## 18. Species timestep bound

dtSpecies=min_i B(V*mYi,deltaFmYi). Tested with nonnegative closed gas species;
no post-update max(mYi,0) or species renormalization.

## 19. Acoustic timestep interaction

dtAcoustic=0.15*2V/(waveMaxLeft+waveMaxRight), using mesh-relative KT acoustics.
All 1119 attempted global steps were acoustic-controlled. Legal scalar bounds
plus this CFL still do NOT guarantee a common-pressure root.

## 20. Final joint timestep formula

Experimental R0 candidate:

```
dt=min(dtAcoustic, .95*dtAlpha, .95*dtMG, .95*dtML,
       .95*dtSpecies, .95*dtVolume)
dtVolume=V/(-D) for D<0, otherwise infinity
```

Constants fixed before tests. **NOT accepted as a complete activation timestep**:
presence/EOS path protection is unresolved; no magic thermo factor added.

## 21. Post-update thermo validity

FAIL. Six ordinary sharp-contact/ALE runs hit the frozen presence predicate;
three mixed-shock runs have no root in their legal pressure intervals;
twelve HARD-loading runs exit the EOS image on their first trial.
Trace witness: alphaL=6.92414e-15,mL=5.03684e-12, physically consistent phase
densities/energy at 3 MPa but predicate rejects it. Mixed-shock witness has both
pressure-bracket energy residuals positive. Detailed CSV and source audit retained.

## 22. Multiple-step synthetic tests

42 profiles/cell-count combinations; 21 finish, 21 fail recovery; 1098 accepted
steps. 20-cell ordinary profiles request 100 steps, 60/200 request 10. No skipped
failures, widened tolerance, automatic repair or CFD case execution.

## 23. Stationary contact evolution

20 cells: 100 steps PASS. 60/200: 9 steps accepted; tenth proposal rejected by
PHASE_PRESENCE_INCONSISTENT. Density and energy witnesses remain consistent with
the original constant intrinsic phase state. This is not a pressure spike.

## 24. Moving contact evolution

20 cells: 100 steps PASS; 60/200 stop before step 10 on trace presence. Maximum
contact pressure relative error over all recoverable profiles=2.47392e-11, below
frozen 1e-8. Pressure accuracy before failure does not certify the full evolution.

## 25. Compression/expansion results

Mild smooth +/-0.1 m/s profiles pass at all three sizes. HARD outward-loading
profiles fail; real-state tangents point outside p/T limits. Diagnostic dt scan
down to 1e-6 of the candidate does not fix them. No universal positivity/domain
claim, EOS extension or extrapolation.

## 26. ALE result

Uniform ALE state passes 100/10/10 steps. ALE contacts have the same trace
presence failure at 60/200 cells. Matching mesh fluxes/volume updates are used;
full ALE admissibility gate remains FAIL.

## 27. Conservation ledger

Accepted multistep mG,mL,M,Et,mYi integrals: maximum normalized drift=4.60103e-15.
Shared face pairing remains conservative. Rejected trial fluxes also telescope,
but are not committed or called valid thermodynamic states.

## 28. Alpha discrete balance

Integral alpha change minus cumulative physical source integral <=8.52651e-14
over accepted steps, within frozen 5e-12*N allowance. Alpha integral itself is
not required to be conserved. No alpha/mass/energy/pressure clipping.

## 29. dt cost statistics

6440 first/final-step cell samples; 1503 finite alpha/acoustic ratios,
4937 infinity (alpha constraint inactive). Nearest-rank statistics:

| Population | Minimum | Median | P5 | P95 |
|---|---:|---:|---:|---:|
| All | 9.65881 | infinity | 2569.1503 | infinity |
| Finite only | 9.65881 | 31503.5603 | 53.2331 | 3.32205e7 |

This matrix is acoustic-controlled. It is not a high-Mach production-cost estimate
or proof that other profiles cannot be alpha-controlled.

## 30. Whether coupled flux limiter was required

Update-level protection **REQUIRED**; a no-correction activation route is not
accepted. A standard high/low coupled limiter cannot be certified until its R0
low-order anchor is admissible. It is NOT IMPLEMENTED, so M5C.2 stays PARTIAL.

## 31. Coupled limiter formulation if applicable

The requested Flow+lambda*(Fhigh-Flow) remains a future candidate, with common
lambda for all conservative corrections and compatible phiPhys/divU/alpha source.
In the observed failures lambda=0 selects the already-invalid low-order update.
No false proof of feasible lambda or custom limiter called MULES.

## 32. cAlpha status

OFF in standalone five-equation transport. Active provisional M2 remains unchanged.

## 33. MULES status

Not used in this standalone baseline. Active M2 MULES remains unchanged.

## 34. Added files

`fiveEqReconstruction/fiveEqReconstruction.H/.C`,
`fiveEqTimeStepBounds.H/.C`; standalone test/Make/README under
`tests/fiveEqAdmissibility`; this report, failure audit, summary/record tools and
frozen/test/hash/CSV evidence under fitting/reconstruction/m5c2_v1.
No R1/R2/admissibility-limiter/coupled-flux-limiter file fabricated as complete.

## 35. Compile/test status

Foundation OF7 standalone wmake PASS with -Werror. R0 run returns **1 / gate FAIL**.
368,617 implementation/linear/ledger/contact assertions have zero failures;
405 uniform cases pass, but 21 evolution recovery failures prevent acceptance.
The initial indentation compile warning was fixed; its log remains. Frozen M5C.1
regression rerun PASS: 34,902 checks,0 failures.

## 36. Active solver impact

**NONE**. Protected active source/build files and all six M5C.1 flux source files
remain byte-identical. No actual timestep, equations, fields, cloud, source
placement, surface tension, production EOS or recovery policy changed.

## 37. Remaining blockers

Trace-presence/transport compatibility; EOS/presence path admissibility or another
proven low-order update; controlled physical HARD-domain exit policy; then R1/R2,
theta/closure/search, legacy reconstruction compatibility and coupled corrections.
The 26-item gate is recorded individually; no blanket COMPLETE declaration.

## 38. M5C.3 start condition

**NOT MET**. First close the R0 prerequisite and all remaining M5C.2 items.
Only then define time stages/boundaries/startup/restart. No M5C.3 execution here.

## 39. M6B permission

**NO**. The requested sequence remains M5C.2 -> M5C.3 -> M8A source adapter ->
M6B atomic activation. No permission is inferred from compilation.

## 40. Updated milestone matrix

| Stage | Status |
|---|---|
| M0–M4 / M5A / M5B / M5B.1 | COMPLETE / existing reference/design |
| M6A1 / production EOS | COMPLETE / frozen standalone |
| M6A2.1 / M6A2.2 | COMPLETE historical standalone/passive gates; new trace compatibility finding unresolved |
| M5C.1 | COMPLETE / STANDALONE / NOT ACTIVE; original gate rerun passes |
| M5C.2 | PARTIAL / R0 ADMISSIBILITY GATE FAILED |
| M5C.3 | BLOCKED / NOT STARTED |
| M8A | BLOCKED / NOT STARTED |
| M6B | BLOCKED / NOT STARTED |
| M7 / M9–M15 | NOT STARTED |
| M8 legacy coexistence | PARTIAL; existing DPM unchanged |

**STOP at the failed M5C.2 prerequisite.** The explicit user section 3 instruction
prevents continuing to high-order limiting without a passing R0 anchor. All failed
proposals, witnesses and unresolved work remain reviewable; no prohibited repair
or later milestone was used to make this stage appear complete.
