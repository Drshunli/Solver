# T4-S2 FINAL AUTHORITY MATRIX v1

**36 mandatory gates PASS. T4-S2 COMPLETE / FROZEN within passive, fixed-mesh, two-rank native scope.**

所有模型证据均为继承；本轮只重新读取与校验哈希/边界记录。SHA-set 标签逐一对应文末的完整 executable/source SHA 与源文件清单；机器可读矩阵还列出每一个证据文件的独立 SHA。

| Gate | Requirement | Authority | Exact evidence | Executable/source SHA-set | Fresh/inherited | Scope / result |
|---|---|---|---|---|---|---|
| 1 | Native migration semantics | R1 FINAL / ZS1 / C2 | [boundary_reaudit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/boundary_reaudit.json)<br>[R1_boundary.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/R1_boundary.csv)<br>[R1_boundary.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_boundary.csv) | R1_NATIVE, ZS1, C2 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; same native sender/receiver fields/history; identity/nParticle; geometry; RNG |
| 2 | Valid forward crossing | R1 FINAL | [R1_boundary.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/independent_runs/run_00/processor0/R1_boundary.csv)<br>[boundary.run_00.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/boundary.run_00.json) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; real native 0→1; no manual send |
| 3 | Valid reverse crossing | ZS1 | [exit.mpi_zero.txt](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1/exit.mpi_zero.txt)<br>[native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1/mpi_zero/processor0/native_crossing_result.json)<br>[native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1/mpi_zero/processor1/native_crossing_result.json)<br>[boundary_reaudit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/boundary_reaudit.json)<br>[compatibility_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/compatibility_audit.json) | ZS1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; INHERIT PASS: real native 1→0; current shared source identical; not N1 invalid rejection |
| 4 | ≥1000 successful crossings | R1 FINAL | [R1_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/R1_FINAL_gate.json)<br>[S2_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/S2_FINAL_gate.json)<br>[stress.sh](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/stress.sh) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; 20 independent runs ×50 forward crossings; all exit0; no timeout; historical failures excluded |
| 5 | Ownership / no loss | R1 FINAL / ID1 / N1 | [S2_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/S2_FINAL_gate.json)<br>[identity_acceptance_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1/identity_acceptance_audit.json)<br>[native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_forward/processor1/native_crossing_result.json) | R1_NATIVE, ID1, N1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; per-run full identity exactly one cloud owner; birth set equals final main-run owner set |
| 6 | Identity / allocator | ID1 / K1 / R1 | [KHNewbornIdentityV1.H](D:/DATA/Solver/rhosprayVoFDPMFoam/dpmFiveEq/KHNewbornIdentityV1.H)<br>[identity_acceptance_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1/identity_acceptance_audit.json)<br>[identity_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/regressions/k1/identity_result.json) | ID1, K1, R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; migration pair preserved; physical newborn birth rank + native getNewParticleID; no receive renumber |
| 7 | S1 destination rebuild | R1 FINAL / S1 | [R1_queries.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_queries.csv)<br>[R1_continuation.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_continuation.csv) | R1_NATIVE, S1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; new destination support session; no source support token transferred |
| 8 | Mixed / trace / absent / stale | R1 FINAL fresh S1 | [support_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/reg_fixture_s1/processor0/support_result.json)<br>[support_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/reg_fixture_s1/processor1/support_result.json) | S1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; mixed .1/.5/.9; trace 1e-20; absent; generation and pose invalidation |
| 9 | Invalid destination forward/reverse | R1 FINAL fresh N1 | [C1_latch.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_forward/processor1/C1_latch.json)<br>[C1_latch.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_reverse/processor0/C1_latch.json) | N1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; EXACT_GAS_ABSENT; zero dependent thermo calls at refused destination; no fake gas |
| 10 | Communication-safe reject | C1-N1 / R1 FINAL | [C1_phases.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_forward/processor1/C1_phases.csv)<br>[C1_phases.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_reverse/processor0/C1_phases.csv)<br>[S2_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/S2_FINAL_gate.json) | N1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; native move returns; post-evolve reduce; local discard; normal exit; no global commit assertion |
| 11 | Migration RNG semantics | R1 FINAL / ZS1 | [boundary_reaudit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/boundary_reaudit.json)<br>[R1_boundary.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_boundary.csv) | R1_NATIVE, ZS1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; prepare/correct no draw; rank RNG not synchronized |
| 12 | RNG next-result | R1 FINAL | [R1_rng_next.jsonl](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_rng_next.jsonl)<br>[R1_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/R1_FINAL_gate.json) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; 50/50 exact full RNG/cache/UTurb/tTurb/update-return paired continuation; local serial no-migration reference |
| 13 | Fresh stochasticDispersionRAS | R1 FINAL | [R1_fresh_models.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/R1_fresh_models.csv)<br>[R1_continuation.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_continuation.csv)<br>[R1_rng_next.jsonl](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_rng_next.jsonl) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; 6503 recorded calls; 462 RNG-consuming-update counter; nonzero UTurb; finite; no convergence claim |
| 14 | Fresh sphereDrag | R1 FINAL | [R1_fresh_drag.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/R1_fresh_drag.csv)<br>[R1_fresh_drag.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_fresh_drag.csv) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; actual local non-roundoff momentum/source; 32 segment witnesses; not global source ledger |
| 15 | Native weighted parcel | PW1 / R1 FINAL | [PW1_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_pw1_native_v1/PW1_gate.json)<br>[PW1_births.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/PW1_births.csv) | PW1, R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; mass basis; Ncomp 1/10/100/1000 ladder; represented mass; finite positive nParticle |
| 16 | No double weighting | PW1 / R1 FINAL | [R1_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/R1_FINAL_gate.json)<br>[R1_fresh_drag.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/R1_fresh_drag.csv)<br>[PW1_void.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/PW1_void.csv) | PW1, R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; native birth and physical nParticle updates retained; no extra coupling multiplier or merge |
| 17 | VoidFraction repeated | R1 FINAL | [PW1_void.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/PW1_void.csv)<br>[PW1_void.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/PW1_void.csv)<br>[R1_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/R1_FINAL_gate.json) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; 7380 native trajectory segments; rank/cell/step theta bit oracle; local segmentation only |
| 18 | blobsSheetAtomization | R1 FINAL | [R1_continuation.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_continuation.csv)<br>[R1_boundary.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_boundary.csv)<br>[modelAdapters.H](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMParcelC2/modelAdapters.H) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; 50 native atomization calls; core>0.5 branch; all weighted migrated cores reach0; finite; no statistics certification |
| 19 | ReitzKHRT bounded domain | R1 FINAL / ZS1 | [ZS1_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1/ZS1_gate.json)<br>[source_delta.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1/source_delta.json)<br>[R1_continuation.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_continuation.csv) | R1_NATIVE, ZS1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; unchanged Foundation; frozen exact-zero policy; CRT=.1 bounded native path; FPE1/FPE2 diagnosis remains |
| 20 | KH physical newborn | ID1 / fresh K1 / ZS1 | [identity_acceptance_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1/identity_acceptance_audit.json)<br>[identity_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/regressions/k1/identity_result.json)<br>[trajectory_birth_parity.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_kh_zs1_native_v1/trajectory_birth_parity.json) | ID1, K1, ZS1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; real birth; local allocator; independent child preflight; rollback; fresh92 child identity checks; spatial-invalid-at-birth not claimed |
| 21 | Native coneInjection | PW1 / R1 FINAL | [pilot.sh](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot.sh)<br>[PW1_steps.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/PW1_steps.csv)<br>[PW1_births.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/PW1_births.csv) | PW1, R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; native injected weighted births; no manual seed; requested=added; global population≤50 |
| 22 | ORourke bounded state | R1 FINAL / frozen T3 | [R1_fresh_models.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_fresh_models.csv)<br>[SERIAL_DPM_KNOWN_LIMITATIONS_v1.md](D:/DATA/Solver/rhosprayVoFDPMFoam/SERIAL_DPM_KNOWN_LIMITATIONS_v1.md) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; migration/state compatibility PASS; NATIVE-PHYSICS-LIMITATION; NOT FULL-CONSERVATION-SAFE |
| 23 | Native rebound | R1 FINAL fresh wall evidence | [R1_fresh_models.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_fresh_models.csv)<br>[modelAdapters.H](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMParcelC2/modelAdapters.H) | R1_NATIVE | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; INHERITED from R1: 2357 native Rebound::correct delegates; real wall fixture; no artificial U flip |
| 24 | Lifetime | R1 FINAL / ID1 / N1 | [native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor0/native_crossing_result.json)<br>[native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/rollback_bounded/processor1/native_crossing_result.json)<br>[native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_reverse/processor0/native_crossing_result.json)<br>[identity_acceptance_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1/identity_acceptance_audit.json) | R1_NATIVE, R1_ROLLBACK, N1, ID1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; constructed=destroyed+baseline; no leak/orphan; committed baseline10 retained in rollback |
| 25 | Registry | R1 FINAL / N1 | [R1_final_stability.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/R1_final_stability.csv)<br>[N1_discard.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/rollback_bounded/processor1/N1_discard.csv)<br>[N1_discard.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_forward/processor1/N1_discard.csv) | R1_NATIVE, R1_ROLLBACK, N1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; stable registry; discard delta0; bindings cleared; owner/latch scope teardown |
| 26 | Rollback | R1 FINAL / ID1 | [PW1_accepted_before.txt](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/rollback_bounded/processor1/PW1_accepted_before.txt)<br>[PW1_accepted_after_discard.txt](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/rollback_bounded/processor1/PW1_accepted_after_discard.txt)<br>[N1_discard.csv](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/rollback_bounded/processor1/N1_discard.csv)<br>[identity_acceptance_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1/identity_acceptance_audit.json) | R1_ROLLBACK, ID1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; nonempty weighted accepted codec/RNG/allocator/identity/source/view/pending restoration; rank-local only |
| 27 | Serial regressions | R1 FINAL | [test_results.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/regressions/r2b/test_results.json)<br>[gate_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/regressions/i1/gate_result.json)<br>[basic_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/regressions/c2/basic_result.json)<br>[event_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/regressions/k1/event_result.json) | R2B, I1, C2, K1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; fresh-in-R1 252194/12083/17/108 checks; failures0; current source compatible; no rerun |
| 28 | S1 regressions | R1 FINAL | [support_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/reg_fixture_s1/processor0/support_result.json)<br>[support_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/reg_fixture_s1/processor1/support_result.json)<br>[topology_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/reg_fixture_topology/processor0/topology_result.json)<br>[topology_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/reg_fixture_topology/processor1/topology_result.json) | S1, TOPOLOGY | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; 20051 support +3364 topology; zero errors; real remote contributors and exact native weights |
| 29 | N1 regressions | R1 FINAL | [native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_valid/processor0/native_crossing_result.json)<br>[native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_forward/processor1/native_crossing_result.json)<br>[native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/n1_reverse/processor0/native_crossing_result.json) | N1 | INHERITED; source/hash reverified this seal; fresh model/regression evidence in R1 FINAL where stated | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; valid and forward/reverse invalid; globalFailures0; not a valid-reverse substitute |
| 30 | Foundation unchanged | Final seal / frozen Foundation baseline | [installed_source_verification.txt](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/installed_source_verification.txt)<br>[native_parcel_verification.txt](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/native_parcel_verification.txt)<br>[foundation_native_source_manifest.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/foundation_native_source_manifest.json) | FOUNDATION | FRESH READ-ONLY AUDIT | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; fresh read-only 6717/19 SHA PASS; native ownership files inspected; no physics replay |
| 31 | No custom MPI infrastructure | Architecture source audit | [foundation_native_source_read.txt](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/foundation_native_source_read.txt)<br>[LazySprayParcel.H](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedNative/parcel/LazySprayParcel.H)<br>[KHNewbornIdentityV1.H](D:/DATA/Solver/rhosprayVoFDPMFoam/dpmFiveEq/KHNewbornIdentityV1.H)<br>[authority_provenance.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/authority_provenance.json) | R1_NATIVE, FOUNDATION | FRESH READ-ONLY AUDIT | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; certified path uses Cloud::move/native streams-iNew; no custom MPI transport/packer/global ID/RNG/merge/superparcel |
| 32 | Active solver unchanged | Source protection audit | [active_source_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/active_source_audit.json)<br>[common_source_chain.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/common_source_chain.json) | SOURCE_AUDIT | FRESH READ-ONLY AUDIT | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; main and 5 equation files equal historical bytes; no active runtime edit or integration |
| 33 | Production unchanged | Frozen records / seal activity scope | [S2_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/S2_FINAL_gate.json)<br>[frozen_before.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/frozen_before.json) | SOURCE_AUDIT | FRESH READ-ONLY AUDIT | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; no production mesh/BC/injection writes, execution, or new production inputs |
| 34 | No global transaction claim | R1 FINAL / ID1 scope | [native_crossing_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/pilot_corrected/processor1/native_crossing_result.json)<br>[identity_acceptance_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_id1_fixture_native_v1/identity_acceptance_audit.json)<br>[S2_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/S2_FINAL_gate.json) | R1_NATIVE, ID1 | FRESH READ-ONLY AUDIT | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; globalMPITransactionCertified=false; S3 global commit/reject/ledger/output explicitly excluded |
| 35 | No restart claim | Final seal scope | [S2_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/S2_FINAL_gate.json) | SOURCE_AUDIT | FRESH READ-ONLY AUDIT | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; production restart NOT CERTIFIED |
| 36 | No CFD | Final seal scope / inherited noCFD receipts | [S2_FINAL_gate.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/S2_FINAL_gate.json)<br>[event_result.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_r1_final_qualified_native_v1/regressions/k1/event_result.json) | SOURCE_AUDIT | FRESH READ-ONLY AUDIT | PASS — passive/offline; fixed mesh; Foundation7 DP/Int32; two ranks; native parcel fixtures; new physics runs0; new compilations0; no CFD; no S3/M6B |

## Exact executable/source SHA sets

### R1_NATIVE

Executable: [testR1QualifiedNative](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedNative/testR1QualifiedNative)

SHA-256: `bd57c297f4ebfae477f253d0031aff18ccfae06cc487ac87c898b670c3d90fdf`

Project source manifest: [R1_NATIVE.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/R1_NATIVE.json)

SHA-256: `bfd9b677ca8ce56ec6d14fdec144fb436ad11df9f305ee46895a5181b4c68713` (90 resolved files)


### R1_ROLLBACK

Executable: [testR1QualifiedRollback](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedRollback/testR1QualifiedRollback)

SHA-256: `47a0b7c8f167ce6bbbe923f9a07cdf70bae76f9f55959b99c8285a5ce22ef71c`

Project source manifest: [R1_ROLLBACK.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/R1_ROLLBACK.json)

SHA-256: `ccec455ec5946a802404f9650325ca7392b644588d33db4699399a8f9da5cfee` (90 resolved files)


### K1

Executable: [testKHSupportK1](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedK1/testKHSupportK1)

SHA-256: `4621c1ea41722067eb2e803782a33144c6f8236b3a5472bad909a2d71086793e`

Project source manifest: [K1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/K1.json)

SHA-256: `e850848a09207df8e8a81b2d2f8cd86e1db0f6417acd7ceaed93f1f50aacc191` (88 resolved files)


### C2

Executable: [testParcelCodec](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedC2/testParcelCodec)

SHA-256: `5ec795608dc08c2ad800a22192ef509e734d5e9c51d4acee2300ee6b77a856be`

Project source manifest: [C2.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/C2.json)

SHA-256: `0f841a5253e9528ba93cc3a9700b464bfcdca938538fe97168ef4b439b75dcc5` (89 resolved files)


### I1

Executable: [testI1Gate](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedI1/testI1Gate)

SHA-256: `5ca3ab703db4aef0cbfd235060fa218b5cd11d599169e0edee288858ed29cacd`

Project source manifest: [I1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/I1.json)

SHA-256: `539588e599a5ac4daf59fce09f4c6f2f3c91c5117b409b5f1c2d0cabd538ecd4` (87 resolved files)


### R2B

Executable: [testLazyCarrier](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedR2B/testLazyCarrier)

SHA-256: `9ca6158a581886d09e6c3aeb84a982c890bbcab950f32d7e1e287ea369031bbd`

Project source manifest: [R2B.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/R2B.json)

SHA-256: `493766ebf68b65940aa2b2d249cc5a97b3dbeb90da2593eed777742067f4262d` (76 resolved files)


### N1

Executable: [testFailureDisposition](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedN1/testFailureDisposition)

SHA-256: `fb39721d415618534197ea1e00293e96602f9f9e9a74e298f859f6957d578ee6`

Project source manifest: [N1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/N1.json)

SHA-256: `fdbf71f725eed87d74f786b92318964b19f785bd262e6353683104844172d1e2` (89 resolved files)


### S1

Executable: [testSupport](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedS1Support/testSupport)

SHA-256: `3a8da2b4de11fe59226ac66682917a4643702de5d478d302fee7a2b72495533b`

Project source manifest: [S1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/S1.json)

SHA-256: `54a6e999dae66e7197ee1b8274d6e465a8e070d6fa138404aacdb4a706bb56e5` (44 resolved files)


### TOPOLOGY

Executable: [testTopology](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMR1QualifiedS1Topology/testTopology)

SHA-256: `e576e0bc0bd42a24cc659e653f961959c7dc1631fe8c0abea729ada4c57fab06`

Project source manifest: [TOPOLOGY.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/TOPOLOGY.json)

SHA-256: `ec9b1192a79ad943db030cbdf02b7e9d53df83550d441c0ea5fa901db87653ce` (19 resolved files)


### PW1

Executable: [testPW1Native](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMPW1Native/testPW1Native)

SHA-256: `250b22a14b1d70350046752105e52d5f74a778f1567c56dc82befabe7be7be48`

Project source manifest: [PW1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/PW1.json)

SHA-256: `1c8f49fd8e49cf35c26697856316a38a424f556c4e234ad540a9ac438c95cca9` (90 resolved files)


### ZS1

Executable: [testZS1Native](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMZS1Native/testZS1Native)

SHA-256: `e9216f76a3e5ba5d158cf2020e4d2f48ac33c61df8dafe98d077863af2a45f69`

Project source manifest: [ZS1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/ZS1.json)

SHA-256: `36523481820c308b398b60f914c008917ffab0009d7e71e78fa24cc951746fad` (90 resolved files)


### ID1

Executable: [testID1FixtureNative](D:/DATA/Solver/rhosprayVoFDPMFoam/tests/fiveEqDPMID1FixtureNative/testID1FixtureNative)

SHA-256: `c91dd67face8f97ac721464e552ee256105dc43f2c7683d14327da07c72700b7`

Project source manifest: [ID1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/source_manifests/ID1.json)

SHA-256: `ef29837a9fbb13db3935c2d1b9acaa0e776f9671c224dd8fa920e6d23eb7a9cd` (90 resolved files)


### FOUNDATION

[foundation_native_source_manifest.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/foundation_native_source_manifest.json) — SHA-256 `bfc3a37565e7b0502570007c670886c02b1bb5c82b9ef88227cddbd4a12f83fe`. Executable: NONE; read-only audit.

### SOURCE_AUDIT

[active_source_audit.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/active_source_audit.json) — SHA-256 `025ab7626f449c6fe1f857043581698c527fc2c416c709a8de87ce1011db29e8`. Executable: NONE; read-only audit.

## Provenance boundary

[common_source_chain.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/common_source_chain.json) pins the 34 shared dependencies omitted from the prior R1 list through frozen T3 dependency metadata → C2 complete archive → R2B archive → historical R2 protected-source snapshot. The historical PARTIAL archive supplies source bytes/hashes only; none of its failed cases or status supplies a PASS gate. ID1 differs only by the already frozen ZS1 call-site policy, bridged by exact accepted-birth payload parity.

transactionState-v1 remains an existing **local transaction/checkpoint codec**, explicitly owned by the project; it is not an MPI parcel serializer. This matrix certifies absence of custom MPI transport/serialization in the selected S2 path, not absence of all local checkpoint codecs or historical test artifacts.

[T4_S2_FINAL_AUTHORITY_MATRIX_v1.json](D:/DATA/Solver/rhosprayVoFDPMFoam/fitting/dpm/m8a3b_t4_s2_final_seal_v1/T4_S2_FINAL_AUTHORITY_MATRIX_v1.json) contains full paths and SHA values for every row. No global commit, distributed source ledger, output exactly-once, production restart, or CFD certificate. STOP.
